import { TimeSpan } from "../../feature/execution-and-tracking/audit-operations/audit-operations.component";

export class UserModel {
    public userId: number;
    public username: string;
    public facilityName: string;
    public email: string;
    public firstName: string;
    public lastName: string;
    public plantId?: number;
    public shiftID: number;
    public shiftType: string;
    public hoursPerDay: number;
    public leadDirectPerc: number;
    public passDirectPerc: number;
    public employeeId: number;
    public lamntId: string;
    public roles: string;
    public shiftStartTime: TimeSpan;
}

export class Plant {
    public plantName: string;
    public plantId: number;
}

export class UserRunningOperationModel {
    public workRecordID: number;
    public pilotProductID: number;
    public operationID: number;
    public operationDescription: string;
    public startTimestamp: Date;
    public isRework: boolean;
    public isAudit: boolean;
    public zoneID: number;
    public porIsBeingEdited: boolean;
    public isBeingEditedByID: number;
}
