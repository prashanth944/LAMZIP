import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { MenuBarComponent } from "./menu-bar/menu-bar.component";
import { LayoutModule } from "@progress/kendo-angular-layout";
import { IndicatorsModule } from "@progress/kendo-angular-indicators";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { IconsModule } from "@progress/kendo-angular-icons";
import { NavigationModule } from "@progress/kendo-angular-navigation";
import { MenusModule } from "@progress/kendo-angular-menu";
import { RouterModule } from "@angular/router";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { AppStoreService } from "./app-store.service";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";

@NgModule({
    declarations: [MenuBarComponent],
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        LayoutModule,
        IndicatorsModule,
        InputsModule,
        IconsModule,
        NavigationModule,
        MenusModule,
        RouterModule,
        ButtonsModule,
        DropDownsModule,
    ],
    exports: [MenuBarComponent],
    providers: [AppStoreService],
})
export class CoreModule {}
