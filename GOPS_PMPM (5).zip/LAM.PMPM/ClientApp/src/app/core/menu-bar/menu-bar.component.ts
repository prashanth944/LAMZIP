import { HttpClient } from "@angular/common/http";
import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { Router } from "@angular/router";
import { MsalService } from "@azure/msal-angular";
import { AppStoreService } from "../app-store.service";
import { Plant, UserModel } from "../model/user.model";
import { environment } from "../../../environments/environment.dev_server";
import { role, uiScreen, userRoles } from "../model/common.constant";

const GRAPH_ENDPOINT =
  "https://graph.microsoft.com/v1.0/me/?$select=givenName,surname,mail,onPremisesSamAccountName,EmployeeID";
interface siteValue {
  text: string;
  value: number;
}

@Component({
  selector: "pmpm-menu-bar",
  templateUrl: "./menu-bar.component.html",
  styleUrls: ["./menu-bar.component.css"],
  encapsulation: ViewEncapsulation.None,
})
export class MenuBarComponent implements OnInit {
  public kendokaAvatar =
    "https://www.telerik.com/kendo-angular-ui-develop/components/navigation/appbar/assets/kendoka-angular.png";

  public items: any[] = [];
  public multiLayerPath = "";
  public icon = "k-icon k-i-globe-outline k-icon-md";
  public sites: Plant[] = [];
  public sitesDropDown: siteValue[] = [];
  data: any[] = [
    {
      text: "Log Out",
    },
  ];
  public show = false;
  public userName = "";
  public userDetails: any;
  public isAccess = false;
  public roles: string[] = [];
  profile: any;
  userRoles: string[] = userRoles;
  public found = false;
  site: Plant;
  canChangeSite = true; //User Story 36768: Not allow Tech, Lead and PASS to change plant

  constructor(
    private router: Router,
    private http: HttpClient,
    private appStoreService: AppStoreService,
    private authService: MsalService
  ) {
    this.items = this.mapItems(router.config);
    this.items = this.items.filter((data) => data.text !== undefined);
  }

  readonly getGroupsApi = "/security/groups";

  ngOnInit() {
    this.getProfile();
    this.appStoreService.getAllPlants().subscribe((res) => {
      this.sitesDropDown = [];
      if (res && res.length > 0) {
        this.sites = res;
        this.sites.forEach((s) => {
          this.sitesDropDown.push({
            text: s.plantName,
            value: s.plantId,
          });
          this.sitesDropDown = this.sitesDropDown?.sort(function (
            a,
            b
          ) {
            const textA = a?.text.toUpperCase();
            const textB = b?.text.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
          });
        });
        this.appStoreService.getLoggedInUser().subscribe((res) => {
          if (res && res?.mail?.length > 0) {
            this.userDetails = res;
            this.userName = res.givenName + " " + res.surname;
            this.appStoreService
              .getUserDetails(this.userDetails.mail)
              .subscribe((res) => {
                if (
                  res &&
                  res.username?.length > 0 &&
                  res.employeeId !== null &&
                  res.lamntId !== null
                ) {
                  if (
                    res.plantId === null ||
                    res.plantId === undefined
                  ) {
                    const req = new UserModel();
                    req.username = this.userDetails?.mail;
                    this.appStoreService
                      .GetPlantOfNewUser(
                        this.userDetails.mail
                      )
                      .subscribe((res) => {
                        if (res != null) {
                          req.plantId = res.plantID;
                          req.facilityName =
                            this.sites.filter(
                              (item) =>
                                item.plantId ===
                                res.plantID
                            )[0].plantName;
                          this.site =
                            this.sites.filter(
                              (item) =>
                                item.plantId ===
                                res.plantID
                            )[0];

                          this.appStoreService.setCurrentSite$(
                            this.site
                          );
                          this.appStoreService
                            .updateWorkRecord(req)
                            .subscribe();
                        } else {
                          this.site =
                            this.sites.filter(
                              (item) =>
                                item.plantName ===
                                "Fremont"
                            )[0];
                          req.facilityName =
                            this.site.plantName;
                          req.plantId =
                            this.site.plantId;

                          this.appStoreService.setCurrentSite$(
                            this.site
                          );
                          this.appStoreService
                            .updateWorkRecord(req)
                            .subscribe();
                        }
                      });
                    this.appStoreService
                      .updateWorkRecord(req)
                      .subscribe();
                    this.appStoreService.setCurrentSite$(
                      this.site
                    );
                  } else {
                    this.site = {
                      plantName: res.facilityName,
                      plantId: res.plantId,
                    };
                    this.appStoreService.setCurrentSite$(
                      this.site
                    );
                  }
                } else {
                  const req = new UserModel();
                  req.firstName = this.userDetails.givenName;
                  req.lastName = this.userDetails.surname;
                  req.email = this.userDetails.mail;
                  req.username = this.userDetails.mail;
                  req.employeeId =
                    +this.userDetails.employeeId;
                  req.lamntId =
                    this.userDetails.onPremisesSamAccountName;
                  this.appStoreService
                    .GetPlantOfNewUser(
                      this.userDetails.mail
                    )
                    .subscribe((res) => {
                      if (res != null) {
                        req.plantId = res.plantID;
                        req.facilityName =
                          this.sites.filter(
                            (item) =>
                              item.plantId ===
                              res.plantID
                          )[0].plantName;
                        this.site = this.sites.filter(
                          (item) =>
                            item.plantId ===
                            res.plantID
                        )[0];

                        this.appStoreService.setCurrentSite$(
                          this.site
                        );
                        this.appStoreService
                          .updateWorkRecord(req)
                          .subscribe();
                      } else {
                        this.site = this.sites.filter(
                          (item) =>
                            item.plantName ===
                            "Fremont"
                        )[0];
                        req.facilityName =
                          this.site.plantName;
                        req.plantId = this.site.plantId;

                        this.appStoreService.setCurrentSite$(
                          this.site
                        );
                        this.appStoreService
                          .updateWorkRecord(req)
                          .subscribe();
                      }
                    });
                  this.appStoreService.setCurrentSite$(
                    this.site
                  );
                  this.appStoreService
                    .updateWorkRecord(req)
                    .subscribe();
                }
              });
          }
        });
        this.appStoreService
          .getCurrentAccessRights()
          .subscribe((res) => {
            this.isAccess = res;
          });
      }
    });

    this.multiLayerPath = "";
    this.appStoreService.setCurrentTimeView$("Weekly");

    this.appStoreService.getUserRoles().subscribe((res) => {
      if (res && res.length > 0) {
        if (res.includes(role.Technician)) {
          this.items = this.items.filter(
            (d) =>
              d.text !== "Master Production Schedule" &&
              d.text !== "Capacity Planning"
          );
        }
        if (!res.includes(role.SuperUser) && !res.includes(role.Manager)) {
          this.items.forEach(item => {
            if (item.text === 'Labor Hour Tracking') {
              item.items = item.items.filter(i => i.text !== 'Pilot Calendar');
            }
          });
        }
        this.appStoreService
          .checkUserAccessRight(res, uiScreen.ChangeSite)
          .subscribe((result) => {
            this.canChangeSite = result;
          });
      }
    });
  }
  getProfile() {
    this.http
      .get(GRAPH_ENDPOINT)
      .toPromise()
      .then((profile) => {
        this.profile = profile;
        this.userName =
          this.profile?.givenName + " " + this.profile?.surname;
        this.appStoreService.setLoggedInUser$(this.profile);
        this.getGroups();
      });
  }
  getGroups() {
    const newUserRoles: string[] = [];
    this.http
      .get(`${environment.apiUrl}${this.getGroupsApi}`)
      .toPromise()
      .then((x) => {
        const res: any = x;
        if (res && res.length > 0) {
          res.forEach((item) => {
            newUserRoles.push(item.displayName);
            this.getUserRoles(newUserRoles);
          });
          this.appStoreService.setUserRoles$(newUserRoles);
          const req = new UserModel();
          req.plantId = this.site?.plantId;
          req.roles = newUserRoles?.join(",");
          req.username = this.userDetails?.mail;
          this.appStoreService.updateWorkRecord(req).subscribe();
          this.found = newUserRoles.some((r) =>
            this.userRoles.includes(r)
          );
          this.appStoreService.setCurrentAccessRights$(this.found);
        } else {
          this.appStoreService.setUserRoles$(["new user"]);
        }
      });
  }
  getUserRoles(userRoles: string[]) {
    this.roles = [];
    userRoles.forEach((item) => {
      let roleItem = "";
      switch (item) {
        case role.SuperUser:
          roleItem = "Super User";
          break;
        case role.Manager:
          roleItem = "Manager/Director";
          break;
        case role.Supervisor:
          roleItem = "Supervisor";
          break;
        case role.Leads:
          roleItem = "Leads";
          break;
        case role.Technician:
          roleItem = "Technician";
          break;
        case role.PassTeamMember:
          roleItem = "Pass Team Member";
          break;
        case role.ProductOwner:
          roleItem = "Product Owner";
          break;
        case role.Engineer:
          roleItem = "Engineer";
          break;
        case role.ViewOnly:
          roleItem = "View Only";
          break;
        case role.ProjectManager:
          roleItem = "Project Manager";
          break;
      }
      this.roles.push(roleItem);
    });
  }
  private mapItems(routes: any[], path?: string): any[] {
    return routes.map((item) => {
      const result: any = {
        text: item.text,
        path:
          this.multiLayerPath.split("/").pop() === path &&
            this.multiLayerPath != ""
            ? `${this.multiLayerPath}/` + item.path
            : (path ? `${path}/` : "") + item.path,
      };

      if (item.children) {
        this.multiLayerPath = result.path;
        result.items = this.mapItems(item.children, item.path);
      }

      return result;
    });
  }

  public onSelect({ item }: any): void {
    if (item.text == "Training Documents") {
      const url =
        "http://lamresearch.sharepoint.com/sites/PMPM/PMPM%20Documentation/Forms/AllItems.aspx?id=%2fsites%2fPMPM%2fPMPM%20Documentation%2fPMPM%20Super%20User%20Documentation&viewid=51bf6b44-de9b-4ff7-8a07-3c293a15a426";
      window.open(url, "_blank");
    } else if (!item.items) {
      this.router.navigate([item.path]);
    }
  }

  navigateToHome() {
    this.router.navigate(["/home"]);
  }

  onChangeSite(site: siteValue) {
    const tempSite: Plant = { plantName: site.text, plantId: site.value };
    this.site = {
      plantName: tempSite.plantName,
      plantId: tempSite.plantId,
    };
    const req = new UserModel();
    req.firstName = this.userDetails.givenName;
    req.lastName = this.userDetails.surname;
    req.email = this.userDetails.mail;
    req.username = this.userDetails.mail;
    req.facilityName = this.site.plantName;
    req.plantId = this.site.plantId;
    this.appStoreService.updateWorkRecord(req).subscribe((res) => {
      this.appStoreService.setCurrentSite$(tempSite);
    });
  }

  logout() {
    this.authService.logout();
  }
  public onToggle(): void {
    this.show = !this.show;
  }
}
