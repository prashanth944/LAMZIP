import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable, of } from "rxjs";
import { environment } from "../../environments/environment.dev_server";
import { PSNorBEN } from "../feature/labor-hour-tracking/models/add-labor-hours.model";
import { role, route, uiScreen } from "./model/common.constant";
import {
  Plant,
  UserModel,
  UserRunningOperationModel,
} from "./model/user.model";

@Injectable()
export class AppStoreService {
  constructor(private http: HttpClient) { }

  _currentSite$ = new BehaviorSubject<Plant>(undefined);
  _currentTimeView$ = new BehaviorSubject<string>("");
  _currentDateView$ = new BehaviorSubject<string>("");
  _colorView$ = new BehaviorSubject<string>("");

  _currentLoggedInUser$ = new BehaviorSubject<any>("");

  _currentAccessRights$ = new BehaviorSubject<boolean>(false);
  _userRoles$ = new BehaviorSubject<string[]>([]);
  _currentOperation$ = new BehaviorSubject<boolean>(true);

  _laborHardConstraint$ = new BehaviorSubject<boolean>(true);
  _bayHardConstraint$ = new BehaviorSubject<boolean>(true);

  _planCreatedBy$ = new BehaviorSubject<string>("");

  _currentBENForLH$ = new BehaviorSubject<PSNorBEN>(undefined);
  _multipleBENForLH$ = new BehaviorSubject<PSNorBEN[]>([]);
  _currentEditBENForLH$ = new BehaviorSubject<PSNorBEN>(undefined);
  _multipleEditBENForLH$ = new BehaviorSubject<PSNorBEN[]>([]);
  _currentPilotProductIDForLH$ = new BehaviorSubject<number>(0);

  setCurrentSite$(site: Plant) {
    this._currentSite$.next(site);
  }
  getCurrentSite(): Observable<Plant> {
    return this._currentSite$;
  }
  setCurrentTimeView$(time: string) {
    this._currentTimeView$.next(time);
  }
  getCurrentTimeView(): Observable<string> {
    return this._currentTimeView$;
  }
  setCurrentDateView$(time: string) {
    this._currentDateView$.next(time);
  }
  getCurrentDateView(): Observable<string> {
    return this._currentDateView$;
  }

  setColorView$(value: string) {
    this._colorView$.next(value);
  }
  getColorView(): Observable<string> {
    return this._colorView$;
  }

  setLaborHardConstraint$(value: boolean) {
    this._laborHardConstraint$.next(value);
  }
  getLaborHardConstraint(): Observable<boolean> {
    return this._laborHardConstraint$;
  }

  setBayHardConstraint$(value: boolean) {
    this._bayHardConstraint$.next(value);
  }
  getBayHardConstraint(): Observable<boolean> {
    return this._bayHardConstraint$;
  }

  setLoggedInUser$(profile: any) {
    this._currentLoggedInUser$.next(profile);
  }
  getLoggedInUser(): Observable<any> {
    return this._currentLoggedInUser$;
  }
  setCurrentAccessRights$(rights: boolean) {
    this._currentAccessRights$.next(rights);
  }
  getCurrentAccessRights(): Observable<boolean> {
    return this._currentAccessRights$;
  }
  setUserRoles$(roles: string[]) {
    this._userRoles$.next(roles);
  }
  getUserRoles(): Observable<string[]> {
    return this._userRoles$;
  }
  setPlanCreatedBy$(userName: string) {
    this._planCreatedBy$.next(userName);
  }
  getPlanCreatedBy(): Observable<string> {
    return this._planCreatedBy$;
  }
  checkUserAccessRight(roles: string[], screen: string): Observable<boolean> {
    let isAccess = false;
    switch (screen) {
      case uiScreen.MPS:
        isAccess = true;
        break;
      case uiScreen.CP:
        isAccess = true;
        break;
      case uiScreen.Bays:
        if (roles.includes(role.Manager)) isAccess = true;
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.Supervisor)) isAccess = true;
        break;
      case uiScreen.Labor:
        if (roles.includes(role.Manager)) isAccess = true;
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.Supervisor)) isAccess = true;
        break;
      case uiScreen.AdjustModule:
        isAccess = true;
        if (roles.includes(role.Technician)) isAccess = false;
        if (roles.includes(role.PassTeamMember)) isAccess = false;
        break;
      case uiScreen.CreateCP:
        if (roles.includes(role.Manager)) isAccess = true;
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.ProjectManager)) isAccess = true;
        if (roles.includes(role.Supervisor)) isAccess = true;
        break;
      case uiScreen.AdjustCapacity:
        if (roles.includes(role.Manager)) isAccess = true;
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.ProjectManager)) isAccess = true;
        if (roles.includes(role.Supervisor)) isAccess = true;
        if (roles.includes(role.Leads)) isAccess = true;
        break;
      case uiScreen.SpecialSubassembly:
        if (roles.includes(role.Manager)) isAccess = true;
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.Supervisor)) isAccess = true;
        if (roles.includes(role.PassTeamMember)) isAccess = true;
        if (roles.includes(role.Engineer)) isAccess = true;
        if (roles.includes(role.Technician)) isAccess = true;
        break;
      case uiScreen.Compare:
        isAccess = true;
        break;
      case uiScreen.ModifyModule:
        isAccess = true;
        break;
      case uiScreen.ENT:
        isAccess = true;
        break;
      case uiScreen.EditModHome:
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.Manager)) isAccess = true;
        if (roles.includes(role.Supervisor)) isAccess = true;
        if (roles.includes(role.ProjectManager)) isAccess = true;
        if (roles.includes(role.Leads)) isAccess = true;
        if (roles.includes(role.PassTeamMember)) isAccess = true;
        if (roles.includes(role.Technician)) isAccess = true;
        if (roles.includes(role.Engineer)) isAccess = true;
        break;
      case uiScreen.EditModOp:
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.Supervisor)) isAccess = true;
        if (roles.includes(role.Leads)) isAccess = true;
        if (roles.includes(role.Technician)) isAccess = true;
        break;
      case uiScreen.EditModSchedule:
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.Supervisor)) isAccess = true;
        if (roles.includes(role.Manager)) isAccess = true;
        if (roles.includes(role.ProjectManager)) isAccess = true;
        if (roles.includes(role.Leads)) isAccess = true;
        if (roles.includes(role.PassTeamMember)) isAccess = true;
        if (roles.includes(role.Technician)) isAccess = true;
        break;
      case uiScreen.MyModule:
        isAccess = true;
        break;
      case uiScreen.LogProgress:
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.Technician)) isAccess = true;
        if (roles.includes(role.Supervisor)) isAccess = true;
        if (roles.includes(role.Leads)) isAccess = true;
        break;
      case uiScreen.RND:
        isAccess = true;
        break;
      case uiScreen.Other:
        isAccess = true;
        break;
      case uiScreen.Admin:
        if (roles.includes(role.Manager)) isAccess = true;
        if (roles.includes(role.SuperUser)) isAccess = true;
        break;
      case uiScreen.AddToWIPHomePage:
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.ProjectManager)) isAccess = true;
        if (roles.includes(role.Manager)) isAccess = true;
        break;
      case uiScreen.AuditOperation:
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.Supervisor)) isAccess = true;
        if (roles.includes(role.Leads)) isAccess = true;
        if (roles.includes(role.Technician)) isAccess = true;
        break;
      case uiScreen.ActionButtonsEditModOp:
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.Supervisor)) isAccess = true;
        if (roles.includes(role.Leads)) isAccess = true;
        if (roles.includes(role.Technician)) isAccess = true;
        break;
      case uiScreen.TOI:
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.Supervisor)) isAccess = true;
        if (roles.includes(role.Leads)) isAccess = true;
        if (roles.includes(role.Technician)) isAccess = true;
        if (roles.includes(role.Manager)) isAccess = true;
        if (roles.includes(role.ProjectManager)) isAccess = true;
        break;
      case uiScreen.EditModRemoveFromWIP:
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.Supervisor)) isAccess = true;
        if (roles.includes(role.Leads)) isAccess = true;
        if (roles.includes(role.Manager)) isAccess = true;
        if (roles.includes(role.ProjectManager)) isAccess = true;
        break;
      case uiScreen.EditModAdmin:
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.Supervisor)) isAccess = true;
        if (roles.includes(role.Leads)) isAccess = true;
        if (roles.includes(role.Manager)) isAccess = true;
        if (roles.includes(role.ProjectManager)) isAccess = true;
        break;
      case uiScreen.AuditItemsStartWork:
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.Supervisor)) isAccess = true;
        if (roles.includes(role.Leads)) isAccess = true;
        if (roles.includes(role.Technician)) isAccess = true;
        break;
      case uiScreen.AuditItemsDeleteFile:
        if (roles.includes(role.SuperUser)) isAccess = true;
        break;
      case uiScreen.LHNT:
        isAccess = true;
        break;
      case uiScreen.VerifyHours:
        if (roles.includes(role.Technician)) isAccess = true;
        if (roles.includes(role.Leads)) isAccess = true;
        if (roles.includes(role.PassTeamMember)) isAccess = true;
        if (roles.includes(role.Manager)) isAccess = true;
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.Supervisor)) isAccess = true;
        break;
      case uiScreen.PFC:
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.Manager)) isAccess = true;
        break;
      case uiScreen.AddLH:
        isAccess = true;
        break;
      case uiScreen.Passdown:
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.Leads)) isAccess = true;
        if (roles.includes(role.Technician)) isAccess = true;
        if (roles.includes(role.Supervisor)) isAccess = true;
        if (roles.includes(role.PassTeamMember)) isAccess = true;
        break;
      case uiScreen.Defaults:
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.Manager)) isAccess = true;
        break;
      case uiScreen.AddEditReports:
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.Manager)) isAccess = true;
        break;
      case uiScreen.OpsMgmt:
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.Supervisor)) isAccess = true;
        if (roles.includes(role.Leads)) isAccess = true;
        if (roles.includes(role.Manager)) isAccess = true;
        if (roles.includes(role.ProjectManager)) isAccess = true;
        if (roles.includes(role.Engineer)) isAccess = true;
        if (roles.includes(role.Technician)) isAccess = true;
        if (roles.includes(role.PassTeamMember)) isAccess = true;
        break;
      case uiScreen.DataMismatch:
        isAccess = true;
        break;
      case uiScreen.TechDashboard:
        if (roles.includes(role.Technician)) isAccess = true;
        if (roles.includes(role.SuperUser)) isAccess = true;
        break;
      case uiScreen.PassDashboard:
        if (roles.includes(role.PassTeamMember)) isAccess = true;
        if (roles.includes(role.Leads)) isAccess = true;
        if (roles.includes(role.SuperUser)) isAccess = true;
        break;
      case uiScreen.SupDashboard:
        if (roles.includes(role.Supervisor)) isAccess = true;
        if (roles.includes(role.Leads)) isAccess = true;
        if (roles.includes(role.SuperUser)) isAccess = true;
        break;
      case uiScreen.WipReoprt:
        isAccess = true;
        break;
      case uiScreen.ManagerDashboard:
        if (roles.includes(role.Manager)) isAccess = true;
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.Supervisor)) isAccess = true;
        break;
      case uiScreen.EditReworkLog:
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.Supervisor)) isAccess = true;
        break;
      case uiScreen.EditLogProgress:
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.Supervisor)) isAccess = true;
        if (roles.includes(role.Leads)) isAccess = true;
        if (roles.includes(role.Technician)) isAccess = true;
        break;
      case uiScreen.EditWorkRecord:
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.Supervisor)) isAccess = true;
        if (roles.includes(role.Leads)) isAccess = true;
        break;
      case uiScreen.EditBuildStyle:
        if (roles.includes(role.SuperUser)) isAccess = true;
        break;
      case uiScreen.EditBuildType:
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.ProjectManager)) isAccess = true;
        break;
      case uiScreen.CompleteBtnEditModOp:
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.Supervisor)) isAccess = true;
        if (roles.includes(role.Leads)) isAccess = true;
        break;
      case uiScreen.ChangeSite:
        isAccess = true;
        if (roles.includes(role.Technician)) isAccess = false;
        if (roles.includes(role.Leads)) isAccess = false;
        if (roles.includes(role.PassTeamMember)) isAccess = false;
        break;
      case uiScreen.EditPOR:
        isAccess = true;
        if (roles.includes(role.Supervisor)) isAccess = false;
        break;
      case uiScreen.EditModCPPOR:
        if (roles.includes(role.Manager)) isAccess = true;
        if (roles.includes(role.SuperUser)) isAccess = true;
        if (roles.includes(role.ProjectManager)) isAccess = true;
        break;
    }
    return of(isAccess);
  }

  getUserDetails(userId: string, currenttime?: Date): Observable<UserModel> {
    if (currenttime == undefined) {
      return new Observable<UserModel>((observer) => {
        this.http
          .get<UserModel>(
            `${environment.apiUrl}${route.getuser}` + userId
          )
          .subscribe((res) => {
            observer.next(res);
          });
      });
    } else {
      return new Observable<UserModel>((observer) => {
        this.http
          .get<UserModel>(
            `${environment.apiUrl}${route.getuser}` +
            userId +
            "/" +
            currenttime
          )
          .subscribe((res) => {
            observer.next(res);
          });
      });
    }
  }

  GetPlantOfNewUser(email: string): Observable<any> {
    return new Observable<number>((observer) => {
      this.http
        .get<any>(
          `${environment.apiUrl}${route.getPlantOfNewUser}` + email
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  updateWorkRecord(userModel: UserModel): Observable<number> {
    return new Observable<number>((observer) => {
      this.http
        .post<number>(
          `${environment.apiUrl}${route.updateuser}`,
          userModel
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  getAllPlants(): Observable<Plant[]> {
    return new Observable<Plant[]>((observer) => {
      this.http
        .get<Plant[]>(`${environment.apiUrl}${route.getallplants}`)
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }
  setOperrationLogDetails$(op: boolean) {
    this._currentOperation$.next(op);
  }
  getsetOperrationLogDetails(): Observable<boolean> {
    return this._currentOperation$;
  }
  getrunningoperation(userId: number): Observable<UserRunningOperationModel> {
    return new Observable<UserRunningOperationModel>((observer) => {
      this.http
        .get<UserRunningOperationModel>(
          `${environment.apiUrl}${route.getrunningoperation}` + userId
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  getPORProductionPlanID(plantId): Observable<any[]> {
    return new Observable<any[]>((observer) => {
      this.http
        .get<any[]>(
          `${environment.apiUrl}${route.getPORProductionPlanID}` +
          plantId
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  setCurrentBENForLH$(ben: PSNorBEN) {
    this._currentBENForLH$.next(ben);
  }
  getCurrentBENForLH(): Observable<PSNorBEN> {
    return this._currentBENForLH$;
  }

  setMultipleBENForLH$(ben: PSNorBEN[]) {
    this._multipleBENForLH$.next(ben);
  }
  getMultipleBENForLH(): Observable<PSNorBEN[]> {
    return this._multipleBENForLH$;
  }

  setEditCurrentBENForLH$(ben: PSNorBEN) {
    this._currentEditBENForLH$.next(ben);
  }
  getEditCurrentBENForLH(): Observable<PSNorBEN> {
    return this._currentEditBENForLH$;
  }

  setEditMultipleBENForLH$(ben: PSNorBEN[]) {
    this._multipleEditBENForLH$.next(ben);
  }
  getEditMultipleBENForLH(): Observable<PSNorBEN[]> {
    return this._multipleEditBENForLH$;
  }
}
