import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { MsalService } from "@azure/msal-angular";
import { AppStoreService } from "./core/app-store.service";
import { UserRunningOperationModel } from "./core/model/user.model";
import { EditService } from "./feature/service/edit.service";
@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styles: [
    `
            .app-flex-conatiner {
                display: flex;
                justify-content: center;
                cursor: pointer;
            }
             .app-flex-conatiner-wip {
                display: flex;
                justify-content: center;
                cursor: pointer;
                width: 100%;
                background-color: white;
                position: fixed;
                overflow: hidden;
                top: 52px;
                height: 35px;
                z-index: 1;
            }

            .log-progress-top-bar {
                display: flex;
                margin-bottom: 2px;
                border-radius: 5px;
                border: 1px solid black;
                color: white;
                justify-content: center;
                height: 22px;
                font-size: small;
                background-color: #c25129;
                cursor: pointer;
                margin-top: 5px;
            }

            .por-top-bar {
                display: flex;
                margin-top: 5px;
                margin-bottom: 2px;
                border-radius: 5px;
                border: 1px solid black;
                color: white;
                justify-content: center;
                width: 90%;
                height: 22px;
                font-size: small;
                background-color: #c25129;
                cursor: pointer;
            }
        `,
  ],
})
export class AppComponent implements OnInit {
  title = "app";
  show = false;
  operation: UserRunningOperationModel;
  tabIndex = 0;
  isWIPPage = false;

  constructor(
    private authService: MsalService,
    private appStoreService: AppStoreService,
    private router: Router,
    private editService: EditService
  ) {

    this.router.events.subscribe((val) => {
      this.editService.cancelChanges();
      if (this.router.url.indexOf('/WIPReport') > -1) {
        this.isWIPPage = true;
      } else {
        this.isWIPPage = false;
      }
    });    
  }
  ngOnInit() {   
    this.authService.instance.handleRedirectPromise().then((res) => {
      if (res !== null && res.account !== null) {
        localStorage.setItem("token", res.accessToken);
        this.authService.instance.setActiveAccount(res.account);
      }
    });

    this.appStoreService.getsetOperrationLogDetails().subscribe((res) => {
      this.show = res;
      if (this.show) this.getOperations();
    });
  }

  getOperations() {
    this.appStoreService.getLoggedInUser().subscribe((res) => {
      this.appStoreService.getUserDetails(res.mail).subscribe((user) => {
        if (user && user.username?.length > 0) {
          this.appStoreService
            .getrunningoperation(user.userId)
            .subscribe((op) => {
              this.operation = op;
              this.tabIndex =
                this.operation !== null &&
                  this.operation.isRework === true
                  ? 2
                  : 0;
            });
        }
      });
    });
  }

  isLoggedIn() {
    return this.authService.instance.getActiveAccount() !== null;
  }
  login() {
    this.authService.loginRedirect();
  }
  logout() {
    this.authService.logout();
  }
  goToLogProgress() {
    this.router.navigate([
      "/log-progress/" +
      this.operation?.pilotProductID +
      "/" +
      this.operation?.operationID +
      "/" +
      this.tabIndex,
    ]);
  }

  goToAuditOp() {
    this.router.navigate([
      "/audit-operations/" +
      this.operation?.pilotProductID +
      "/" +
      this.operation?.operationID +
      "/" +
      this.operation?.zoneID +
      "/" +
      this.tabIndex,
    ]);
  }
  goToMPS() {
    this.router.navigate(["/mps"]);
  }
}
