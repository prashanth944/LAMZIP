import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { AdjustCapacityComponent } from "./feature/capacity-planning/adjust-capacity/adjust-capacity.component";
import { AdjustModuleComponent } from "./feature/capacity-planning/adjust-module/adjust-module.component";
import { CapcityPlanningComponent } from "./feature/capacity-planning/capacity-planning.component";
import { CheckCapacityRequirementComponent } from "./feature/capacity-planning/check-capacity-requirement/check-capacity-requirement.component";
import { ExecutionAndTrackingComponent } from "./feature/execution-and-tracking/execution-and-tracking.component";
import { ReportingAndDashboardComponent } from "./feature/reporting-and-dashboards/reporting-and-dashboards.component";
import { HomeComponent } from "./feature/home-page/home-page.component";
import { MasterProductionScheduleComponent } from "./feature/master-production-schedule/master-production-schedule.component";
import { OtherComponent } from "./feature/other/other.component";
import { EditModuleDetailsComponent } from "./feature/execution-and-tracking/edit-module-details/edit-module-details.component";
import { AdminComponent } from "./feature/other/admin/admin.component";
import { WipReportComponent } from "./feature/execution-and-tracking/wip-report/wip-report.component";
import { MyModulesComponent } from "./feature/execution-and-tracking/my-modules/my-modules.component";
import { MsalGuard } from "@azure/msal-angular";
import { LogProgressComponent } from "./feature/execution-and-tracking/log-progress/log-progress.component";
import { WorkSummaryComponent } from "./feature/execution-and-tracking/work-summary/work-summary.component";
import { RequestApprovalComponent } from "./feature/request-approval/request-approval.component";
import { CreateCapacityPlanComponent } from "./feature/capacity-planning/check-capacity-requirement/create-capacity-plan/create-capacity-plan.component";
import { CanDeactivateGuard } from "./feature/service/rotuer-guard-service";
import { OtherUserPlansComponent } from "./feature/capacity-planning/check-capacity-requirement/other-user-plans/other-user-plans.component";
import { ScheduleGeneratedComponent } from "./feature/schedule-generated/schedule-generated.component";
import { DownloadFileComponent } from "./feature/download-file/download-file.component";
import { ActionItemsComponent } from "./feature/execution-and-tracking/edit-module-details/action-items/action-items.component";
import { AuditOperationsComponent } from "./feature/execution-and-tracking/audit-operations/audit-operations.component";
import { ViewTOIComponent } from "./feature/execution-and-tracking/edit-module-details/action-items/toi/view-toi/view-toi.component";
import { GenPassdownsComponent } from "./feature/execution-and-tracking/edit-module-details/passdowns/gen-passdowns/gen-passdowns.component";
import { DateTrackingSearchComponent } from "./feature/reporting-and-dashboards/date-tracking-search/date-tracking-search.component";
import { DateTrackingModComponent } from "./feature/reporting-and-dashboards/date-tracking-mod/date-tracking-mod.component";
import { ComparePlansComponent } from "./feature/capacity-planning/check-capacity-requirement/compare-plans/compare-plans.component";
import { LaborHourTrackingComponent } from "./feature/labor-hour-tracking/labor-hour-tracking.component";
import { SharedCalendarComponent } from "./feature/labor-hour-tracking/shared-calendar/shared-calendar.component";
import { AddLaborHoursComponent } from "./feature/labor-hour-tracking/add-labor-hours/add-labor-hours.component";
import { VerifyHoursComponent } from "./feature/labor-hour-tracking/verify-hours/verify-hours.component";
import { PilotFiscalCalendarComponent } from "./feature/labor-hour-tracking/pilot-fiscal-calendar/pilot-fiscal-calendar.component";
import { DataMismatchComponent } from "./feature/reporting-and-dashboards/data-mismatch/data-mismatch.component";
import { TOIDashboardComponent } from "./feature/reporting-and-dashboards/toi-dashboard/toi-dashboard.component";
import { EditLaborHourComponent } from "./feature/labor-hour-tracking/edit-labor-hours/edit-labor-hours.component";
import { MenuBarComponent } from "./core/menu-bar/menu-bar.component";
import { OperationDetailsComponent } from "./feature/execution-and-tracking/operation-details/operation-details.component";
import { EditCycleTimeComponent } from "./feature/labor-hour-tracking/verify-hours/edit-cycle-time/edit-cycle-time.component";
import { LaborHourSummaryComponent } from "./feature/labor-hour-tracking/verify-hours/labor-hour-summary/labor-hour-summary.component";
import { SerializationNumbersComponent } from "./feature/execution-and-tracking/edit-module-details/tags-sns-docs/serialization-numbers/serialization-numbers.component";

const routes = [
    { path: "home", component: HomeComponent, canActivate: [MsalGuard] },
    {
        path: "mps",
        component: MasterProductionScheduleComponent,
        text: "Master Production Schedule",
        canActivate: [MsalGuard],
        canDeactivate: [CanDeactivateGuard],
    },
    {
        path: "capacity",
        component: CapcityPlanningComponent,
        text: "Capacity Planning",
        canActivate: [MsalGuard],
        children: [
            {
                path: "check-capacity",
                component: CheckCapacityRequirementComponent,
                text: "Scheduling",
                canActivate: [MsalGuard],
            },
            {
                path: "adjust-module",
                component: AdjustModuleComponent,
                text: "Modify Module/Tool Type Data",
                canActivate: [MsalGuard],
            },
            {
                path: "adjust-capacity",
                component: AdjustCapacityComponent,
                text: "Capacity Resources",
                canActivate: [MsalGuard],
                children: [
                    {
                        path: "labor",
                        component: AdjustCapacityComponent,
                        text: "Labor",
                        canActivate: [MsalGuard],
                    },
                    {
                        path: "bay",
                        component: AdjustCapacityComponent,
                        text: "Bays",
                        canActivate: [MsalGuard],
                    },
                ],
            },
        ],
    },
    {
        path: "execution-and-tracking",
        component: ExecutionAndTrackingComponent,
        text: "Execution And Tracking",
        canActivate: [MsalGuard],
        children: [
            {
                path: "WIPReport",
                component: WipReportComponent,
                text: "WIP Report",
                canActivate: [MsalGuard],
            },
            {
                path: "MyModules",
                component: MyModulesComponent,
                text: "My Modules",
                canActivate: [MsalGuard],
            },
        ],
    },
    {
        path: "reporting-and-dashboard",
        component: ReportingAndDashboardComponent,
        text: "Reporting And Dashboards",
        canActivate: [MsalGuard],
    },
    {
        path: "labor-hour-tracking",
        component: LaborHourTrackingComponent,
        text: "Labor Hour Tracking",
        canActivate: [MsalGuard],
        children: [
            {
                path: "shared-calendar",
                component: SharedCalendarComponent,
                text: "Shared Calendar",
                canActivate: [MsalGuard],
            },
            {
                path: "add-labor-hours",
                component: AddLaborHoursComponent,
                text: "Add Labor Hours",
                canActivate: [MsalGuard],
            },
            {
                path: "verify-hours",
                component: VerifyHoursComponent,
                text: "Verify Hours",
                canActivate: [MsalGuard],
            },
            {
                path: "pilot-calendar",
                component: PilotFiscalCalendarComponent,
                text: "Pilot Calendar",
                canActivate: [MsalGuard],
            },
        ],
    },
    {
        path: "other",
        component: OtherComponent,
        text: "Other",
        canActivate: [MsalGuard],
        children: [
            {
                path: "admin",
                component: AdminComponent,
                text: "Admin",
                canActivate: [MsalGuard],
            },
            {
                path: "training-documents",
                component: MenuBarComponent,
                text: "Training Documents",
                canActivate: [MsalGuard],
            },
        ],
    },
    {
        path: "edit-module/:id/:tabId",
        component: EditModuleDetailsComponent,
        canActivate: [MsalGuard],
    },
    {
        path: "log-progress/:id/:operationId/:tabIndexId",
        component: LogProgressComponent,
        canActivate: [MsalGuard],
        canDeactivate: [CanDeactivateGuard],
    },
    {
        path: "log-progress/:id/:operationId/:tabIndexId/:isEdit/:workRecordID",
        component: LogProgressComponent,
        canActivate: [MsalGuard],
        canDeactivate: [CanDeactivateGuard],
    },
    {
        path: "work-summary/:id/:operationId",
        component: WorkSummaryComponent,
        canDeactivate: [CanDeactivateGuard],
        canActivate: [MsalGuard],
    },
    {
        path: "operation-summary/:id/:operationId",
        component: OperationDetailsComponent,
        canDeactivate: [CanDeactivateGuard],
        canActivate: [MsalGuard],
    },
    {
        path: "request-approval",
        component: RequestApprovalComponent,
        canActivate: [MsalGuard],
    },
    {
        path: "create-capacity-plan/:id/:tabId",
        component: CreateCapacityPlanComponent,
        canDeactivate: [CanDeactivateGuard],
        canActivate: [MsalGuard],
    },
    {
        path: "other-user-plans",
        component: OtherUserPlansComponent,
        canActivate: [MsalGuard],
    },
    {
        path: "compare-plans",
        component: ComparePlansComponent,
        canActivate: [MsalGuard],
    },
    {
        path: "schedule-generated/:id",
        component: ScheduleGeneratedComponent,
        canActivate: [MsalGuard],
    },
    {
        path: "downloadFromURL/:GUID/:beforeOrAfter/:file",
        component: DownloadFileComponent,
        canActivate: [MsalGuard],
    },
    {
        path: "log-progress/:GUID",
        component: LogProgressComponent,
        canActivate: [MsalGuard],
    },
    {
        path: "action-items/:id/:tabId",
        component: ActionItemsComponent,
        canActivate: [MsalGuard],
    },
    {
        path: "audit-operations/:id/:operationId/:zoneId/:tabIndexId",
        component: AuditOperationsComponent,
        canActivate: [MsalGuard],
    },
    {
        path: "view-toi/:toiId",
        component: ViewTOIComponent,
        canActivate: [MsalGuard],
    },
    {
        path: "view-toi/:toiId/:pilotProductId",
        component: ViewTOIComponent,
        canActivate: [MsalGuard],
    },
    {
        path: "gen-passdowns/:pilotProductId/:passdownId",
        component: GenPassdownsComponent,
        canActivate: [MsalGuard],
    },
    {
        path: "date-tracking",
        component: DateTrackingSearchComponent,
        canActivate: [MsalGuard],
    },
    {
        path: "date-tracking-mod/:pilotProductID",
        component: DateTrackingModComponent,
        canActivate: [MsalGuard],
    },
    {
        path: "data-mismatch",
        component: DataMismatchComponent,
        canActivate: [MsalGuard],
    },
    {
        path: "toi-dashboard",
        component: TOIDashboardComponent,
        canActivate: [MsalGuard],
    },
    {
        path: "edit-labor-hour",
        component: EditLaborHourComponent,
        canActivate: [MsalGuard],
    },
    {
        path: "add-labor-hours/:laborHourId",
        component: AddLaborHoursComponent,
        canActivate: [MsalGuard],
    },
    {
        path: "edit-cycle-time/:type",
        component: EditCycleTimeComponent,
        canActivate: [MsalGuard],
    },
    {
        path: "labor-hour-suumary/:type/:lamId",
        component: LaborHourSummaryComponent,
        canActivate: [MsalGuard],
    },
    {
        path: "serialization-numbers/:pilotProductID",
        component: SerializationNumbersComponent,
        canActivate: [MsalGuard],
    },
    { path: "", redirectTo: "home", pathMatch: "full" },
    { path: "**", redirectTo: "home", pathMatch: "full" },
];

const isIframe = window !== window.parent && !window.opener;

@NgModule({
    imports: [
        RouterModule.forRoot(routes, {
            relativeLinkResolution: "legacy",
            initialNavigation: !isIframe ? "enabled" : "disabled",
        }),
    ],
    exports: [RouterModule],
})
export class AppRoutingModule {}
