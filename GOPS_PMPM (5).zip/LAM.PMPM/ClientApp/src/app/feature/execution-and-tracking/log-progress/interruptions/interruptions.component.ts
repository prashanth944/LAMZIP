import {
    Component,
    Input,
    OnChanges,
    OnInit,
    SimpleChanges,
    ViewEncapsulation,
} from "@angular/core";
import { DataServiceEandTService } from "../../data-service-eand-t.service";
import { InterruptionsSummary } from "../../Models/interruptionsSummary";

@Component({
    selector: "pmpm-interruptions",
    templateUrl: "./interruptions.component.html",
    styleUrls: ["./interruptions.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class InterruptionsComponent implements OnInit, OnChanges {
    @Input() gridDataForInterruption: InterruptionsSummary[] = [];
    public interruptionCategory: any[] = [];

    constructor(private service: DataServiceEandTService) {}

    ngOnInit() {
        this.interruptionCategory = [];
    }
    ngOnChanges(changes: SimpleChanges): void {
        if (
            changes["gridDataForInterruption"] &&
            changes["gridDataForInterruption"] !== null &&
            changes["gridDataForInterruption"].currentValue
        ) {
            this.gridDataForInterruption =
                changes["gridDataForInterruption"].currentValue;
        }
    }
}
