import {
    ChangeDetectorRef,
    Component,
    OnInit,
    ViewEncapsulation,
    ChangeDetectionStrategy,
    OnDestroy,
    SimpleChanges,
    OnChanges,
    ViewChild,
    ViewContainerRef,
} from "@angular/core";
import { ActivatedRoute, Router, RouterStateSnapshot } from "@angular/router";
import { Subject, interval, Observable } from "rxjs";
import { AppStoreService } from "../../../core/app-store.service";
import { DataServiceEandTService } from "../data-service-eand-t.service";
import {
    InterruptionCategory,
    InterruptionModel,
    InterruptionsSummary,
} from "../Models/interruptionsSummary";
import {
    OperationLogDetail,
    ReworkCategoryViewModel,
    ReworkCauseViewModel,
    StandardTimeExceptionViewModel,
    StepDetail,
} from "../Models/ModuleSummary";
import { Plant, UserModel } from "../../../core/model/user.model";
import * as moment from "moment";
import { DataService } from "../../other/admin/Services/DataService";
import { Operations } from "../../other/Models/defaults.model";
import { NotificationService } from "@progress/kendo-angular-notification";
import { HttpClient } from "@angular/common/http";
import { environment } from "../../../../environments/environment.dev_server";
import { CycleTimeUpdateViewModel } from "../../labor-hour-tracking/models/edit-cycle-time.model";
import { LaborHourTrackingService } from "../../labor-hour-tracking/service/labor-hour-tracking.service";
declare let require: any;

export interface Entry {
    created: Date;
    id: string;
}
export interface TimeSpan {
    hours: number;
    minutes: number;
    seconds: number;
}

@Component({
    selector: "pmpm-log-progress",
    templateUrl: "./log-progress.component.html",
    styleUrls: ["./log-progress.component.css"],
    encapsulation: ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LogProgressComponent implements OnInit, OnDestroy, OnChanges {
    @ViewChild("appendTo", { read: ViewContainerRef })
    public appendTo: ViewContainerRef;

    readonly apiUrl = `${environment.apiUrl}`;
    private destroyed$ = new Subject();
    entry: Entry = {
        id: "Total Working Time:",
        created: new Date(new Date().getTime()),
    };
    interruption: Entry;
    selectedTab = 0;
    public hours = 0;
    public minutes = 0;
    public seconds = 0;
    public interruptionHours = 0;
    public interruptionMinutes = 0;
    public interruptionSeconds = 0;
    public tempHours = 0;
    public tempMinutes = 0;
    public tempSeconds = 0;
    public pilotProductId: number;
    public operationId: number;
    public gridDataForSteps: StepDetail[] = [];
    public gridDataForReworkSteps: StepDetail[] = [];
    public operationLogDetail: OperationLogDetail;
    public gridDataForInterruption: InterruptionsSummary[] = [];
    public interruptionNotes = "";
    public interruptionCategory: InterruptionCategory[] = [];
    public categoryIndex: number;
    public selectedCategoryId: number;
    public selectedCategoryName: string;
    public standardTimeExceptionCategory: StandardTimeExceptionViewModel[] = [];
    public STECategoryId: number;
    public selectedSTECategoryId: number;
    public selectedSTECategoryName: string;
    public stepsNote = "";
    public isThresholdExceeded?: boolean = null;
    public standardTime = "";
    public totalSteps: number;
    public totalReworkSteps: number;
    public totalWorkingTimeInMinutes: number;
    public totalFixedWorkingTimeInMinutes: number;
    public tempOperationLogDetail: OperationLogDetail;
    public soeLink = "";
    site: Plant;
    public difference: number;
    public lowThreshold: number;
    public highThreshold: number;
    public show = false;
    public missingNotesError = false;
    public missingInterruptionNote = false;
    public user: UserModel;
    public fillInterruptionFormError = true;
    public fillFormError = true;
    public disableEndRework = true;
    public interruptionClicked = false;
    public workRecordId: number;
    public isDirty: boolean;
    public TWTInMinutes: any;
    public editReworkLogs = false;
    public isRework = false;
    public interruptionStartTime: any = null;
    public interruptionEndTime: any = null;
    public totalInterruptionTime: any = null;
    public counter = 0;
    public disableSOELinkBtn = false;
    public stepDetails: StepDetail[] = [];
    public reworkStepDetails: any = [];
    public updateStepsObj: StepDetail[] = [];
    public saveFormData = false;

    //STE
    public STEPercentage: Operations[] = [];
    public opTimeSTELow = 0;
    public opTimeSTEHigh = 0;
    public isOpRunning = true;

    //Rework form
    public reworkCategories: ReworkCategoryViewModel[];
    public OBCOptions = [];
    public PilotOrSupplierOptions = [];
    public OBCOptionIndex: number;
    public RWCauseIndex: number;
    public reworkFormData = {
        OBC: undefined,
        PilotOrSupplier: undefined,
        ReworkCategoryId: undefined,
        description: "",
        missingReworkNote: true,
        reworkFormError: true,
    };
    public beforeFiles: any;
    public afterFiles: any;
    public disableAfterPicButton = true;
    public editWorkRecordID: number;
    public endTime: any = null;
    public readonly = false;
    public guid: string = null;
    public afterFileList: FileList = null;
    public beforeFileList: FileList = null;
    public cancelClicked = false;
    public editReworkCancelClicked = false;
    public showConfirmationPopup = false;
    public leavePageWarning = false;
    public navigationOff = true;
    public redirectUrl = "";

    constructor(
        private changeDetector: ChangeDetectorRef,
        private router: Router,
        private route: ActivatedRoute,
        private http: HttpClient,
        private laborService: LaborHourTrackingService,
        private service: DataServiceEandTService,
        private appStore: AppStoreService,
        private setDefualtsService: DataService,
        private notificationService: NotificationService
    ) {}
    ngOnInit() {
        this.route.params.subscribe((param) => {
            this.editReworkLogs = param.isEdit;
            this.pilotProductId = param.id;
            this.operationId = param.operationId;
            this.guid = param.GUID;
            if (this.afterFiles && this.afterFiles.length > 0) {
                this.disableAfterPicButton = false;
            } else {
                this.disableAfterPicButton = true;
            }

            if (
                this.pilotProductId != undefined &&
                this.operationId != undefined
            ) {
                this.getoperationlogdetails();
            }
            if (param.workRecordID) {
                this.editWorkRecordID = +param.workRecordID;
            }
            if (param.isEdit) {
                this.getReworkWorkRecord(false);
            }

            if (param.GUID) {
                this.readonly = true;
                this.selectedTab = 2;
                this.isRework = true;
                this.getoperationlogdetails();
                this.getReworkFormOptions();
                this.getReworkWorkRecordByGUID(param.GUID);
            } else {
                this.getInterruptionCategory();
                this.getStandardTimeExceptionCategory();
                this.selectedTab = param.tabIndexId;
                if (this.selectedTab == 0)
                    // Steps tab
                    this.getStepDetails();
                else if (this.selectedTab == 2) {
                    //Rework tab
                    this.getReworkFormOptions();
                    this.getReworkStepDetails();
                    this.isRework = true;
                }
            }
        });
        this.appStore.getCurrentSite().subscribe((site) => {
            if (site) {
                this.site = {
                    plantName: site.plantName,
                    plantId: site.plantId,
                };
                this.getSTEPercentage();
            }
        });
        interval(1000).subscribe(() => {
            this.changeDetector.detectChanges();
        });
    }
    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (
            changes["totalWorkingTimeInMinutes"] &&
            changes["totalWorkingTimeInMinutes"] !== null &&
            changes["totalWorkingTimeInMinutes"].currentValue
        ) {
            this.totalWorkingTimeInMinutes =
                changes["totalWorkingTimeInMinutes"].currentValue;
        }
        if (
            changes["workRecordId"] &&
            changes["workRecordId"] !== null &&
            changes["workRecordId"].currentValue
        ) {
            this.workRecordId = changes["workRecordId"].currentValue;
        }
    }

    getSTEPercentage() {
        this.setDefualtsService.GetOperationsDefaultData().subscribe((res) => {
            if (res) {
                this.opTimeSTELow = res.filter(
                    (x) => x.plantID == this.site.plantId
                )[0].opTimeSTELow;
                this.opTimeSTEHigh = res.filter(
                    (x) => x.plantID == this.site.plantId
                )[0].opTimeSTEHigh;
            }
        });
    }

    getReworkStepDetails() {
        this.service
            .getReworkStepDetails(this.pilotProductId, this.operationId)
            .subscribe((res) => {
                if (res && res.length > 0) {
                    this.gridDataForReworkSteps = res;
                    this.totalReworkSteps = res.length;
                }
            });
    }

    getStepDetails() {
        this.service
            .getstepsdetails(this.pilotProductId, this.operationId)
            .subscribe((res) => {
                if (res && res.length > 0) {
                    this.gridDataForSteps = res;
                    this.totalSteps = res.length;
                }
            });
    }
    getInterruptionCategory() {
        this.service.getInterruptionCategory().subscribe((res) => {
            if (res && res.length > 0) {
                this.interruptionCategory = res;
            }
        });
    }

    getoperationlogdetails() {
        this.appStore.getLoggedInUser().subscribe((res) => {
            this.appStore.getUserDetails(res.mail).subscribe((user) => {
                if (user && user.username?.length > 0) {
                    this.user = user;
                    const isRework = this.selectedTab == 2 ? true : false;
                    this.service
                        .getoperationlogdetails(
                            this.pilotProductId,
                            this.operationId,
                            user.userId,
                            isRework
                        )
                        .subscribe((details) => {
                            this.operationLogDetail = details;
                            this.workRecordId =
                                this.operationLogDetail.workRecordId;
                            this.tempOperationLogDetail = details;
                            this.beforeFiles =
                                this.operationLogDetail.beforePicture;
                            if (
                                this.operationLogDetail.isRunning &&
                                this.operationLogDetail.afterPicture.length > 0
                            ) {
                                const lastIndex = this.afterFiles.length - 1;
                                for (
                                    let fileIndex = 0;
                                    fileIndex < this.afterFiles.length;
                                    fileIndex++
                                ) {
                                    this.deleteUnsavedAfterFiles(
                                        "a",
                                        this.afterFiles[fileIndex],
                                        fileIndex,
                                        lastIndex
                                    );
                                }
                            } else {
                                this.afterFiles =
                                    this.operationLogDetail.afterPicture;
                            }

                            if (
                                this.operationLogDetail.description
                                    .trim()
                                    .includes("Cart Audit")
                            ) {
                                this.disableSOELinkBtn = true;
                            }
                            if (this.guid == null) {
                                this.isOpRunning =
                                    this.operationLogDetail.isRunning;
                            }
                            this.soeLink = details.soeLink;
                            if (!this.editReworkLogs && !this.guid) {
                                this.appStore.setOperrationLogDetails$(true);
                            }
                            if (details.totalInterruptionSeconds > 0) {
                                const startTime =
                                    (new Date().getTime() -
                                        new Date(details.startTime).getTime()) /
                                    1000;
                                const newStartTime =
                                    startTime -
                                    details.totalInterruptionSeconds;
                                const time = new Date(
                                    Date.now() - newStartTime * 1000
                                );
                                this.entry = {
                                    id: "Total Working Time:",
                                    created: new Date(new Date(time).getTime()),
                                };
                            } else {
                                this.entry = {
                                    id: "Total Working Time:",
                                    created: new Date(
                                        new Date(details.startTime).getTime()
                                    ),
                                };
                            }
                            this.standardTime =
                                Math.floor(details.cycleTimeMinutes / 60) +
                                " Hours" +
                                (details.cycleTimeMinutes % 60 > 0
                                    ? ", " +
                                      (details.cycleTimeMinutes % 60) +
                                      " Minutes"
                                    : "");
                            if (details.isInterrupted) {
                                if (details.totalInterruptionSeconds > 0) {
                                    const startTime =
                                        (new Date(
                                            details.latestInterruptionTime
                                        ).getTime() -
                                            new Date(
                                                details.startTime
                                            ).getTime()) /
                                        1000;
                                    const newStartTime =
                                        startTime -
                                        details.totalInterruptionSeconds;
                                    const time = new Date(
                                        Date.now() - newStartTime * 1000
                                    );
                                    this.entry = {
                                        id: "Total Working Time:",
                                        created: new Date(
                                            new Date(time).getTime()
                                        ),
                                    };
                                } else {
                                    this.entry = {
                                        id: "Total Working Time:",
                                        created: new Date(
                                            new Date(
                                                details.startTime
                                            ).getTime()
                                        ),
                                    };
                                }
                                this.interruption = {
                                    id: "Total Working Time:",
                                    created: new Date(
                                        new Date(
                                            details.latestInterruptionTime
                                        ).getTime()
                                    ),
                                };
                                this.onInterruptionClick(true);
                            }
                        });
                }
            });
        });
    }
    getInterruptionTime(entry: Entry): TimeSpan {
        let totalSeconds = Math.floor(
            (new Date().getTime() - entry.created.getTime()) / 1000
        );
        this.interruptionHours = 0;
        this.interruptionMinutes = 0;
        this.interruptionSeconds = 0;

        if (totalSeconds >= 3600) {
            this.interruptionHours = Math.floor(totalSeconds / 3600);
            totalSeconds -= 3600 * this.interruptionHours;
        }

        if (totalSeconds >= 60) {
            this.interruptionMinutes = Math.floor(totalSeconds / 60);
            totalSeconds -= 60 * this.interruptionMinutes;
        }

        this.interruptionSeconds = totalSeconds;

        return {
            hours: this.interruptionHours,
            minutes: this.interruptionMinutes,
            seconds: this.interruptionSeconds,
        };
    }

    onTabSelect(e) {
        if (e.index === 1) {
            if (
                this.operationLogDetail &&
                this.operationLogDetail.workRecordId
            ) {
                this.getInterruption();
            }
        }
    }

    onLoadStepDetails(stepDetails: any) {
        if (this.stepDetails.length > 0) {
            const isNew = this.stepDetails.filter(
                (x) => x?.stepNo == stepDetails[0]?.stepNo
            );
            if (isNew.length == 0) {
                this.stepDetails.push(stepDetails[0]);
            } else {
                const spliceIndex = this.stepDetails.findIndex(
                    (x) => x?.stepNo == stepDetails[0]?.stepNo
                );
                this.stepDetails.splice(spliceIndex, 1);
                this.stepDetails.push(stepDetails[0]);
            }
        } else {
            this.stepDetails.push(stepDetails[0]);
        }
    }

    onLoadReworkStepDetails(reworkStepDetails: any) {
        if (this.reworkStepDetails.length > 0) {
            const isNew = this.reworkStepDetails.filter(
                (x) => x.stepNo == reworkStepDetails[0].stepNo
            );
            if (isNew.length == 0) {
                this.reworkStepDetails.push(reworkStepDetails[0]);
            } else {
                const spliceIndex = this.reworkStepDetails.findIndex(
                    (x) => x.stepNo == reworkStepDetails[0].stepNo
                );
                this.reworkStepDetails.splice(spliceIndex, 1);
                this.reworkStepDetails.push(reworkStepDetails[0]);
            }
        } else {
            this.reworkStepDetails.push(reworkStepDetails[0]);
        }
        this.disableAfterPicButton =
            this.reworkStepDetails.filter(
                (x) => x.reworked == true && x.reworkedById == this.user.userId
            ).length > 0
                ? false
                : true;

        this.onChange(false);
    }

    onInterruptionClick(isExistingInterruption: boolean) {
        this.counter = this.counter + 1;
        this.interruptionStartTime = new Date();
        this.fillInterruptionFormError = true;
        this.fillFormError = true;
        this.selectedTab = 1;
        this.interruptionClicked = true;
        this.interruptionNotes = "";
        this.categoryIndex = undefined;
        this.selectedCategoryId = undefined;
        if (isExistingInterruption) {
            let totalSeconds = Math.floor(
                (new Date().getTime() - this.entry?.created?.getTime()) / 1000
            );
            this.tempHours = 0;
            this.tempMinutes = 0;
            this.tempSeconds = 0;
            if (totalSeconds >= 3600) {
                this.tempHours = Math.floor(totalSeconds / 3600);
                totalSeconds -= 3600 * this.tempHours;
            }
            if (totalSeconds >= 60) {
                this.tempMinutes = Math.floor(totalSeconds / 60);
                totalSeconds -= 60 * this.tempMinutes;
            }
            this.tempSeconds = totalSeconds;
        }

        if (!isExistingInterruption) {
            this.tempHours = this.hours;
            this.tempMinutes = this.minutes;
            this.tempSeconds = this.seconds;
            this.hours = 0;
            this.minutes = 0;
            this.seconds = 0;
            this.interruption = {
                id: "Total Working Time:",
                created: new Date(new Date().getTime()),
            };
            const request = new InterruptionModel();
            request.operationId = +this.operationId;
            request.pilotProductId = +this.pilotProductId;
            request.userId = this.user?.userId;
            request.interruptionStartTime = new Date(
                new Date().getTime() - new Date().getTimezoneOffset() * 60000
            );
            request.workRecordId = this.operationLogDetail.workRecordId;
            request.notes = "";
            this.service.startEndInterruption(request).subscribe((res) => {});
        }
        this.getInterruption();
    }
    getInterruption() {
        this.gridDataForInterruption = [];
        this.service
            .getinterrupts(this.operationLogDetail.workRecordId)
            .subscribe((res) => {
                if (res && res.length > 0) {
                    res.forEach((item) => {
                        if (item.interruptTime !== null)
                            this.gridDataForInterruption.push(item);
                    });
                }
            });
    }

    onEndInterruptionClick() {
        this.interruptionEndTime = new Date();
        if (this.counter == 0) {
            this.totalInterruptionTime =
                this.interruptionStartTime.getTime() -
                this.interruptionEndTime.getTime();
        } else if (this.counter > 0) {
            this.totalInterruptionTime =
                this.totalInterruptionTime +
                (this.interruptionEndTime.getTime() -
                    this.interruptionStartTime.getTime());
        }
        this.tempHours = 0;
        this.tempMinutes = 0;
        this.tempSeconds = 0;
        if (this.isRework) this.selectedTab = 2;
        else this.selectedTab = 0;

        this.interruptionClicked = false;
        this.fillInterruptionFormError = false;

        const request = new InterruptionModel();
        request.operationId = +this.operationId;
        request.pilotProductId = +this.pilotProductId;
        request.userId = this.user?.userId;
        request.interruptionEndTime = new Date(
            new Date().getTime() - new Date().getTimezoneOffset() * 60000
        );
        request.workRecordId = this.operationLogDetail.workRecordId;
        request.notes = this.interruptionNotes;
        request.interruptionCategoryId = this.selectedCategoryId;
        this.service.startEndInterruption(request).subscribe((res) => {
            if (res) this.getInterruption();
        });
    }

    onCategoryIdSelect(category: InterruptionCategory, index: number) {
        this.fillInterruptionFormError = false;
        this.categoryIndex = index;
        this.selectedCategoryId = category.interruptionCategoryId;
        this.selectedCategoryName = category.optionName;
        if (
            category.optionName === "Other" &&
            this.interruptionNotes?.length < 1
        ) {
            this.missingInterruptionNote = true;
        } else this.missingInterruptionNote = false;
    }

    getStandardTimeExceptionCategory() {
        this.service.getStandardTimeExceptionCategory().subscribe((res) => {
            if (res && res.length > 0) {
                this.standardTimeExceptionCategory = res;
            }
        });
    }

    onStandardTimeExceptionSelect(
        category: StandardTimeExceptionViewModel,
        index: number
    ) {
        this.fillFormError = false;
        this.STECategoryId = index;
        this.selectedSTECategoryId = category.standardTimeExceptionCategoryId;
        this.selectedSTECategoryName = category.optionName;
        if (category.optionName === "Other" && this.stepsNote?.length < 1) {
            this.missingNotesError = true;
        } else {
            this.missingNotesError = false;
        }
    }

    onSelectThresholdExceeded(value: number, entry: Entry) {
        if (value) {
            this.isThresholdExceeded = true;
            this.isDirty = false;
            this.totalWorkingTimeInMinutes = this.minutes;
        } else {
            this.totalFixedWorkingTimeInMinutes =
                this.hours * 60 + this.minutes;
            this.isThresholdExceeded = false;
        }
    }

    updateLogWorkRecord() {
        this.navigationOff = false;
        //call update steps api
        this.updateStepsObj = [];
        if (this.stepDetails && this.stepDetails.length > 0) {
            this.stepDetails.forEach((val) => {
                const step: StepDetail = {
                    stepRecordId: val.stepRecordId,
                    stepNo: val.stepNo,
                    completed: val.completed,
                    skipped: val.skipped,
                    excluded: val.excluded,

                    completedBy: val.completedBy,
                    completedById: val.completedById,
                    skippedById: val.skippedById,
                    excludedById: val.excludedById,

                    technicianNotes: val.technicianNotes,

                    numberofSteps: val.numberofSteps,
                    operationId: val.operationId,
                    cycleTimeMinutes: val.cycleTimeMinutes,
                    pilotProductId: val.pilotProductId,
                    isOnlyTechNote: false,

                    reworked: null,
                    reworkedBy: null,
                    reworkedById: null,
                };
                this.updateStepsObj.push(step);
            });
            this.service
                .updateallsteprecord(this.updateStepsObj)
                .subscribe((res) => {
                    this.update();
                });
        } else {
            this.update();
        }
    }

    update() {
        this.fillFormError = false;
        this.show = false;
        const logWorkRecord = {
            StandardTimeExceptionCategoryId: this.selectedSTECategoryId,
            WorkRecordId: this.operationLogDetail.workRecordId,
            Notes: this.stepsNote,
            EndTime: new Date(
                new Date().getTime() - new Date().getTimezoneOffset() * 60000
            ),
        };

        if (this.isDirty) {
            const startTime = new Date(this.operationLogDetail.startTime);
            const newEndTime = moment(startTime)
                .add(this.TWTInMinutes, "m")
                .toDate();
            logWorkRecord.EndTime = new Date(
                newEndTime.getTime() - newEndTime.getTimezoneOffset() * 60000
            );
        }

        this.service
            .updateLogWorkRecord(logWorkRecord, logWorkRecord.WorkRecordId)
            .subscribe((req) => {
                if (req) {
                    this.appStore.setOperrationLogDetails$(false);
                    if (
                        this.isDirty &&
                        this.totalFixedWorkingTimeInMinutes > 0
                    ) {
                        const request = new CycleTimeUpdateViewModel();
                        request.workRecordID =
                            this.operationLogDetail.workRecordId;
                        request.workRecordInterruptionId = null;
                        request.endMinutes =
                            this.totalFixedWorkingTimeInMinutes;
                        let date: any = new Date();
                        date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
                        this.laborService
                            .UpdateCycleTime(request, date)
                            .subscribe((res) => {});
                    }
                    this.router.navigate([
                        "/edit-module/" + this.pilotProductId + "/" + 2,
                    ]);
                }
            });
    }

    onOpenSOEClick() {
        this.service
            .getSOELink(
                this.site.plantId,
                +this.operationId,
                +this.pilotProductId
            )
            .subscribe((res) => {
                if (res && res.url.length > 0) {
                    this.soeLink = res.url;
                    window.open(this.soeLink, "_blank");
                }
            });
    }

    onSaveAndEndClick() {
        /* show STE section when total working time is below 10% or Above 10% of Threshold Time
   consider example of 120 min threshold time  if(108 - 122) then dont show else show */

        this.lowThreshold =
            this.operationLogDetail.cycleTimeMinutes *
            (this.opTimeSTELow / 100);
        this.highThreshold =
            this.operationLogDetail.cycleTimeMinutes *
            (this.opTimeSTEHigh / 100);

        const checkLowTime =
            this.operationLogDetail.cycleTimeMinutes - this.lowThreshold;
        const checkHighTime =
            this.operationLogDetail.cycleTimeMinutes + this.highThreshold;
        this.totalFixedWorkingTimeInMinutes = this.totalWorkingTimeInMinutes;

        if (
            this.totalWorkingTimeInMinutes < checkLowTime ||
            this.totalWorkingTimeInMinutes > checkHighTime
        ) {
            this.show = true;
        }
        if (!this.show) {
            this.updateLogWorkRecord();
        }
    }

    onSaveClick() {
        //save the threshold data
        this.updateLogWorkRecord();
    }

    onCancelClicked() {
        this.cancelClicked = true;
        this.navigationOff = false;
    }

    onCancel() {
        this.navigationOff = false;
        this.cancelClicked = false;
        this.isThresholdExceeded = null;
        this.selectedSTECategoryId = null;
        this.stepsNote = "";
        this.service
            .logoperationdelete(this.operationLogDetail.workRecordId)
            .subscribe((res) => {
                this.appStore.setOperrationLogDetails$(false);
                this.router.navigate([
                    "/edit-module/" + this.pilotProductId + "/" + 2,
                ]);
            });
    }

    goToEditModOperations() {
        this.navigationOff = false;
        this.router.navigate(["/edit-module/" + this.pilotProductId + "/" + 2]);
    }

    onTecniciannotes(note) {
        if (this.selectedSTECategoryName === "Other") {
            if (this.stepsNote.length > 0) {
                this.missingNotesError = false;
            } else {
                this.missingNotesError = true;
            }
        } else this.missingNotesError = false;
    }
    onInterruptionTecniciannotes(note) {
        if (this.selectedCategoryName === "Other") {
            if (this.interruptionNotes.length > 0) {
                this.missingInterruptionNote = false;
            } else {
                this.missingInterruptionNote = true;
            }
        } else this.missingInterruptionNote = false;
    }

    updateReworkWorkRecord(reworkData) {
        //call update steps api
        this.updateStepsObj = [];
        this.reworkStepDetails.forEach((val) => {
            const step: StepDetail = {
                stepRecordId: val.stepRecordId,
                stepNo: val.stepNo,
                completed: val.completed,
                skipped: val.skipped,
                excluded: val.excluded,

                completedBy: val.completedBy,
                completedById: val.completedById,
                skippedById: val.skippedById,
                excludedById: val.excludedById,

                technicianNotes: val.technicianNotes,

                numberofSteps: val.numberofSteps,
                operationId: val.operationId,
                cycleTimeMinutes: val.cycleTimeMinutes,
                pilotProductId: val.pilotProductId,
                isOnlyTechNote: false,

                reworked: val.reworked,
                reworkedBy: val.reworkedBy,
                reworkedById: val.reworkedById,
            };
            this.updateStepsObj.push(step);
        });
        this.service
            .updateallsteprecord(this.updateStepsObj)
            .subscribe((res) => {
                this.fillFormError = false;
                this.show = false;
                const reworkWorkRecord = {
                    IsOBC: reworkData.OBC,
                    WorkRecordId: this.operationLogDetail.workRecordId,
                    PilotOrSupplier: reworkData.PilotOrSupplier,
                    ReworkCategoryId:
                        reworkData.ReworkCategoryId != undefined
                            ? reworkData.ReworkCategoryId.id
                            : null,
                    ReworkDescription: reworkData.description,
                    EndTime: new Date(
                        new Date().getTime() -
                            new Date().getTimezoneOffset() * 60000
                    ),
                };
                if (this.editReworkLogs) {
                    const endTime = new Date(
                        new Date(this.operationLogDetail.endTime).getTime() -
                            new Date(
                                this.operationLogDetail.endTime
                            ).getTimezoneOffset() *
                                60000
                    );
                    reworkWorkRecord.EndTime = endTime;
                    reworkWorkRecord.WorkRecordId = this.editWorkRecordID;
                }
                this.service
                    .updateReworkWorkRecord(
                        reworkWorkRecord,
                        reworkWorkRecord.WorkRecordId
                    )
                    .subscribe((req) => {
                        if (req && req["value"] === "Updated Successfully") {
                            this.appStore.setOperrationLogDetails$(false);
                            this.router.navigate([
                                "/edit-module/" + this.pilotProductId + "/" + 2,
                            ]);
                        }
                    });
            });
    }

    disableEndReworkButton(reworkData: ReworkCauseViewModel): boolean {
        if (
            reworkData.reworkFormError === false &&
            reworkData.missingReworkNote === false
        ) {
            this.disableEndRework = false;
        } else {
            this.disableEndRework = true;
        }
        return this.disableEndRework;
    }

    onEndReworkClick() {
        if (this.disableEndReworkButton(this.reworkFormData) === false) {
            this.saveFormData = true;
            this.navigationOff = false;
            this.updateReworkWorkRecord(this.reworkFormData);
        }
        this.saveFormData = this.disableEndReworkButton(this.reworkFormData);
    }

    checkIfDirty(value) {
        this.isDirty = value.dirty;
        this.TWTInMinutes = value.viewModel;
    }

    getElapsedTime(entry: Entry): TimeSpan {
        if (
            this.interruptionStartTime != undefined &&
            this.interruptionEndTime != undefined
        ) {
            const totalSeconds = Math.floor(
                (new Date().getTime() -
                    entry.created.getTime() -
                    this.totalInterruptionTime) /
                    1000
            );
            return this.getTime(totalSeconds);
        } else {
            const totalSeconds = Math.floor(
                (new Date().getTime() - entry.created.getTime()) / 1000
            );
            return this.getTime(totalSeconds);
        }
    }

    getTime(totalSeconds) {
        this.hours = 0;
        this.minutes = 0;
        this.seconds = 0;

        if (totalSeconds >= 3600) {
            this.hours = Math.floor(totalSeconds / 3600);
            totalSeconds -= 3600 * this.hours;
        }

        if (totalSeconds >= 60) {
            this.minutes = Math.floor(totalSeconds / 60);
            totalSeconds -= 60 * this.minutes;
        }

        this.seconds = totalSeconds;
        this.totalWorkingTimeInMinutes = this.hours * 60 + this.minutes;
        return {
            hours: this.hours,
            minutes: this.minutes,
            seconds: this.seconds,
        };
    }

    public deleteInterruptions() {
        this.service
            .deleteInterruptions(this.operationLogDetail.workRecordId)
            .subscribe((res) => {
                if (this.isRework) {
                    this.selectedTab = 2;
                    this.interruptionClicked = false;
                    this.getReworkStepDetails();
                } else {
                    this.selectedTab = 0;
                    this.getStepDetails();
                }
            });
    }

    public showSuccess(msg: string): void {
        this.notificationService.show({
            appendTo: this.appendTo,
            content: msg,
            position: { horizontal: "left", vertical: "bottom" },
            animation: { type: "fade", duration: 600 },
            type: { style: "success", icon: true },
        });
    }

    getReworkFormOptions() {
        this.OBCOptions = [
            { DisplayText: "Yes", flag: true },
            { DisplayText: "No", flag: false },
        ];
        this.PilotOrSupplierOptions = [
            { DisplayText: "Pilot", flag: "P" },
            { DisplayText: "Supplier", flag: "S" },
        ];
        this.service.getReworkCategory().subscribe((res) => {
            if (res.length > 0) {
                this.reworkCategories = res;
            }
        });
    }

    onSelectOBC(option, index: number) {
        this.OBCOptionIndex = index;
        this.reworkFormData.OBC = option.flag;
        this.reworkFormData.reworkFormError =
            this.reworkFormData.OBC == true ? false : true;
        this.reworkFormData.PilotOrSupplier = undefined;
        this.RWCauseIndex = undefined;
        this.reworkFormData.ReworkCategoryId = undefined;
        this.onChange(false);
    }

    onRWCauseSelect(option, index: number) {
        this.RWCauseIndex = index;
        this.reworkFormData.PilotOrSupplier = option.flag;
        this.reworkFormData.reworkFormError =
            this.reworkFormData.PilotOrSupplier == "P" ? true : false;
        if (this.reworkFormData.PilotOrSupplier == "S") {
            this.reworkFormData.ReworkCategoryId = undefined;
        }
        this.onChange(false);
    }

    onRWCategoryChange(categoryId) {
        this.reworkFormData.ReworkCategoryId = categoryId;
        if (this.reworkFormData.PilotOrSupplier) {
            this.reworkFormData.reworkFormError =
                this.reworkFormData.ReworkCategoryId == undefined
                    ? true
                    : false;
        }
        this.onChange(false);
    }

    onChange(disableSave) {
        if (
            this.reworkFormData.description != null &&
            this.reworkFormData.description.length > 0
        ) {
            this.reworkFormData.missingReworkNote = false;
        } else {
            this.reworkFormData.missingReworkNote = true;
        }

        if (disableSave == true) {
            this.disableEndRework = true;
        } else {
            if (
                this.reworkFormData.missingReworkNote == false &&
                this.reworkFormData.reworkFormError == false &&
                this.reworkStepDetails.length > 0
            ) {
                this.disableEndRework = false;
            } else {
                this.disableEndRework = true;
            }
        }
    }

    onFileChange(beforeOrAfter: string, files: FileList) {
        switch (beforeOrAfter) {
            case "a":
                this.afterFileList = files;
                const after = Array.from(files);
                this.afterFiles = after.map((x) => x.name);
                if (this.afterFileList.length > 0) {
                    this.uploadFiles("a", this.afterFileList);
                }
                break;
            case "b":
                this.beforeFileList = files;
                const before = Array.from(files);
                this.beforeFiles = before.map((x) => x.name);
                if (this.beforeFileList.length > 0) {
                    this.uploadFiles("b", this.beforeFileList);
                }
                break;
            default:
                break;
        }
    }

    uploadFiles(beforeOrAfter, files) {
        const formData: FormData = new FormData();
        for (let i = 0; i < files.length; i++) {
            formData.append("fileKey", files[i], files[i].name);
        }

        this.service
            .uploadReworkfile(this.workRecordId, beforeOrAfter, formData)
            .subscribe((req) => {
                if (req && req["value"] === "Updated Successfully") {
                }
            });
    }

    download(beforeOrAfter, file) {
        this.http
            .get(
                this.apiUrl +
                    "/Log/downloadfile/" +
                    this.workRecordId +
                    "/" +
                    beforeOrAfter +
                    "/" +
                    file,
                { responseType: "blob" }
            )
            .subscribe((result: any) => {
                if (result) {
                    const blob = new Blob([result]);
                    const saveAs = require("file-saver");
                    const fileName = file;
                    saveAs(blob, fileName);
                } else {
                    alert("File not found in Blob!");
                }
            });
    }

    getReworkWorkRecord(disableSave) {
        this.service
            .getReworkWorkRecord(this.editWorkRecordID)
            .subscribe((res) => {
                if (res) {
                    this.reworkFormData.OBC = res.isOBC;
                    this.OBCOptionIndex = res.isOBC == true ? 0 : 1;
                    this.reworkFormData.PilotOrSupplier = res.pilotOrSupplier;
                    this.RWCauseIndex = res.pilotOrSupplier == "P" ? 0 : 1;
                    this.reworkFormData.ReworkCategoryId = {
                        id: res.reworkCategoryId,
                        category: res.reworkCategory,
                    };
                    this.reworkFormData.description = res.reworkDescription;
                    this.afterFiles = res.afterPicture;
                    if (this.afterFiles.length > 0) {
                        this.disableAfterPicButton = false;
                    } else {
                        this.disableAfterPicButton = true;
                    }
                    this.beforeFiles = res.beforePicture;
                    this.reworkFormData.reworkFormError = false;
                    this.endTime = res.endTime;
                    this.onChange(disableSave);
                }
            });
    }

    getReworkWorkRecordByGUID(GUID) {
        this.service.getReworkWorkRecordByGUID(GUID).subscribe((res) => {
            if (res) {
                this.reworkFormData.OBC = res.isOBC;
                this.OBCOptionIndex = res.isOBC == true ? 0 : 1;
                this.reworkFormData.PilotOrSupplier = res.pilotOrSupplier;
                this.RWCauseIndex = res.pilotOrSupplier == "P" ? 0 : 1;
                this.reworkFormData.ReworkCategoryId = {
                    id: res.reworkCategoryId,
                    category: res.reworkCategory,
                };
                this.reworkFormData.description = res.reworkDescription;
                this.afterFiles = res.afterPicture;
                if (this.afterFiles.length > 0) {
                    this.disableAfterPicButton = false;
                } else {
                    this.disableAfterPicButton = true;
                }
                this.beforeFiles = res.beforePicture;
                this.pilotProductId = res.pilotProductId;
                this.operationId = res.operationId;
                this.getReworkStepDetails();
                this.reworkFormData.reworkFormError = false;
                this.reworkFormData.missingReworkNote = false;
                this.isOpRunning = true;
            }
        });
    }

    public cancelEditedReworkLogData() {
        this.getReworkStepDetails();
        this.getReworkWorkRecord(false);
    }

    reworkCategoryChange(categoryId) {
        this.reworkFormData.ReworkCategoryId = categoryId;
        if (this.reworkFormData.PilotOrSupplier) {
            this.reworkFormData.reworkFormError =
                this.reworkFormData.ReworkCategoryId == undefined
                    ? true
                    : false;
        }
        this.onChange(false);
    }

    cancelRework() {
        this.navigationOff = false;
        this.editReworkCancelClicked = false;
        this.router.navigate(["/edit-module/" + this.pilotProductId + "/" + 4]);
    }

    deleteUnsavedAfterFiles(beforeOrAfter, fileName, index, lastIndex) {
        const workRecordId = this.workRecordId;
        this.service
            .deleteReworkFile(workRecordId, beforeOrAfter, fileName)
            .subscribe((req) => {
                if (req && req["value"] === "Deleted Successfully") {
                    if (index == lastIndex) {
                        this.afterFiles = [];
                        this.disableAfterPicButton = true;
                    }
                }
            });
    }

    deleteFile(beforeOrAfter, fileName, index) {
        let workRecordId = null;
        if (this.editReworkLogs == true) workRecordId = this.editWorkRecordID;
        else workRecordId = this.workRecordId;

        this.service
            .deleteReworkFile(workRecordId, beforeOrAfter, fileName)
            .subscribe((req) => {
                if (req && req["value"] === "Deleted Successfully") {
                    if (beforeOrAfter == "a") {
                        const after = Array.from(this.afterFiles);
                        after.splice(index, 1);
                        this.afterFiles = after;
                    } else if (beforeOrAfter == "b") {
                        const before = Array.from(this.beforeFiles);
                        before.splice(index, 1);
                        this.beforeFiles = before;
                    }
                } else {
                    console.log("An Error occured deleting some files.");
                }
            });
    }

    canDeactivate(
        nextState: RouterStateSnapshot
    ): Observable<boolean> | Promise<boolean> | boolean {
        if (this.navigationOff && !nextState.url.includes("log-progress")) {
            this.leavePageWarning = true;
            this.redirectUrl = nextState.url;
            this.changeDetector.detectChanges();
            return false;
        } else {
            return true;
        }
    }

    leavePage() {
        this.navigationOff = false;
        if (this.redirectUrl != "") {
            this.router.navigate([this.redirectUrl]);
            this.redirectUrl = "";
        }
    }
}
