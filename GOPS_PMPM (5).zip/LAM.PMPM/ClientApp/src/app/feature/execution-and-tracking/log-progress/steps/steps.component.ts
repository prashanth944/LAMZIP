import {
    Component,
    EventEmitter,
    Input,
    OnChanges,
    OnInit,
    Output,
    SimpleChanges,
    ViewEncapsulation,
} from "@angular/core";
import { FormArray, FormBuilder, FormControl, FormGroup } from "@angular/forms";
import { State } from "@progress/kendo-data-query";
import { StepDetail } from "../../Models/ModuleSummary";
import { EditService } from "../../../service/edit.service";
import { DataServiceEandTService } from "../../data-service-eand-t.service";
import { AppStoreService } from "../../../../core/app-store.service";
import * as moment from "moment";
import { UserModel } from "../../../../core/model/user.model";

@Component({
    selector: "pmpm-steps",
    templateUrl: "./steps.component.html",
    styleUrls: ["./steps.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class StepsComponent implements OnInit, OnChanges {
    @Input() gridDataForSteps: StepDetail[] = [];
    @Output() stepDetails: EventEmitter<any> = new EventEmitter<any>();

    public loadTable = true;
    public gridState: State = {
        sort: [],
        skip: 0,
        take: 10,
    };
    notesDataItem: StepDetail;
    addOpened = false;
    notesValue = "";
    userDetails: UserModel;

    public formGroups: FormGroup = new FormGroup({ items: new FormArray([]) });

    constructor(
        private editService: EditService,
        private formBuilder: FormBuilder,
        private service: DataServiceEandTService,
        private appStore: AppStoreService
    ) {}

    ngOnInit() {
        if (this.gridDataForSteps && this.gridDataForSteps.length > 0)
            this.loadTable = false;
        else this.loadTable = true;

        this.appStore.getLoggedInUser().subscribe((res) => {
            this.appStore.getUserDetails(res.mail).subscribe((user) => {
                if (user && user.username?.length > 0) {
                    this.userDetails = user;
                }
            });
        });
    }
    ngOnChanges(changes: SimpleChanges): void {
        if (
            changes["gridDataForSteps"] &&
            changes["gridDataForSteps"] !== null &&
            changes["gridDataForSteps"].currentValue
        ) {
            this.gridDataForSteps = changes["gridDataForSteps"].currentValue;
            if (this.gridDataForSteps && this.gridDataForSteps.length > 0) {
                this.gridDataForSteps.forEach((item) => {
                    item.technicianNotes = this.getTechNotesInDifferentLines(
                        item.technicianNotes
                    );
                });
                this.loadTable = false;
            }
        }
    }
    public onStateChangeForBuild(state: State) {
        this.gridState = state;
    }
    public cellClickHandlerForBuild({
        sender,
        rowIndex,
        columnIndex,
        dataItem,
        isEdited,
    }) {
        if (!isEdited) {
            sender.editCell(
                rowIndex,
                columnIndex,
                this.createFormGroupForBuild(dataItem)
            );
        }
    }
    public createFormGroupForBuild(dataItem: any): FormGroup {
        return this.formBuilder.group({
            stepRecordId: new FormControl(dataItem.stepRecordId),
            stepNo: new FormControl(dataItem.stepNo),
            completed: new FormControl(dataItem.completed),
            skipped: new FormControl(dataItem.skipped),
            excluded: new FormControl(dataItem.excluded),
            completedBy: new FormControl(dataItem.completedBy),
            completedById: new FormControl(dataItem.completedById),
            skippedById: new FormControl(dataItem.skippedById),
            excludedById: new FormControl(dataItem.excludedById),
            technicianNotes: new FormControl(dataItem.technicianNotes),
            numberofSteps: new FormControl(dataItem.numberofSteps),
            operationId: new FormControl(dataItem.operationId),
            cycleTimeMinutes: new FormControl(dataItem.cycleTimeMinutes),
            pilotProductId: new FormControl(dataItem.pilotProductId),
        });
    }

    public cellCloseHandlerForBuild(args: any) {
        const { formGroup, dataItem } = args;
        if (!formGroup.valid) {
            args.preventDefault();
        } else if (formGroup.dirty) {
            this.editService.assignValues(dataItem, formGroup.value);
            this.onChecked(args.column.field, dataItem);
            this.editService.update(dataItem, "Step Details");
        } else {
            this.onChecked(args.column.field, dataItem);
            this.editService.update(dataItem, "Step Details");
        }
        const updatedData = this.editService.saveChanges();
        this.stepDetails.emit(updatedData[0]);
    }

    public cancelHandlerForBuild({ sender, rowIndex }) {
        sender.closeRow(rowIndex);
    }

    public saveHandlerForBuild({ sender, formGroup, rowIndex }) {
        if (formGroup.valid) {
            this.editService.create(formGroup.value);
            sender.closeRow(rowIndex);
        }
    }

    onChecked(col: string, data: StepDetail) {
        switch (col) {
            case "completed":
                if (data.completed) {
                    data.skipped = false;
                    data.excluded = false;
                    data.completedBy =
                        this.userDetails.firstName +
                        " " +
                        this.userDetails.lastName;
                    data.completedById = this.userDetails.userId;
                } else {
                    data.completedBy = null;
                    data.completedById = null;
                }
                break;
            case "skipped":
                if (data.skipped) {
                    data.completed = false;
                    data.excluded = false;
                    data.completedBy = "";
                    data.skippedById = this.userDetails.userId;
                }
                break;
            case "excluded":
                if (data.excluded) {
                    data.completed = false;
                    data.skipped = false;
                    data.completedBy = "";
                    data.excludedById = this.userDetails.userId;
                }
                break;
        }
    }

    openAddNotes(dataItem: StepDetail) {
        this.notesDataItem = dataItem;
        this.addOpened = true;
    }
    closeAddNotes() {
        this.notesValue = "";
        this.addOpened = false;
    }
    getTechNotesInDifferentLines(data) {
        let newNotes = "";
        if (data != null) {
            const notesArr = data.split("|");
            notesArr.forEach((val) => {
                if (val.trim() != "") newNotes = newNotes + val.trim() + "\n";
            });
        }
        return newNotes;
    }
    onAddNote() {
        this.addOpened = false;
        const newNote =
            "[" +
            moment(new Date()).format("MM-DD-yyyy hh:mm A").toString() +
            ", " +
            this.userDetails.username +
            "]: " +
            this.notesValue +
            "\n";
        this.notesDataItem.technicianNotes =
            this.notesDataItem.technicianNotes != null
                ? this.notesDataItem.technicianNotes + newNote
                : newNote;
        this.editService.update(this.notesDataItem, "Step Details");
        const updatedData = this.editService.saveChanges();
        this.stepDetails.emit(updatedData[0]);
        this.notesValue = "";
    }

    public getFormControl(dataItem: StepDetail, field: string): FormControl {
        // return the FormControl for the respective column editor
        return <FormControl>(
            (this.formGroups?.get("items") as FormArray).controls
                .find((i) => i.value.operationId === dataItem.operationId)
                ?.get(field)
        );
    }

    onChangeCompleted(dataItem: StepDetail) {
        dataItem.completed =
            dataItem.completed !== null ? !dataItem.completed : true;
        this.onChecked("completed", dataItem);
        this.editService.update(dataItem, "Step Details");

        const updatedData = this.editService.saveChanges();
        this.stepDetails.emit(updatedData[0]);
    }

    onChangeSkipped(dataItem: StepDetail) {
        dataItem.skipped = dataItem.skipped !== null ? !dataItem.skipped : true;
        this.onChecked("skipped", dataItem);
        this.editService.update(dataItem, "Step Details");

        const updatedData = this.editService.saveChanges();
        this.stepDetails.emit(updatedData[0]);
    }
    onChangeExcluded(dataItem: StepDetail) {
        dataItem.excluded =
            dataItem.excluded !== null ? !dataItem.excluded : true;
        this.onChecked("excluded", dataItem);
        this.editService.update(dataItem, "Step Details");

        const updatedData = this.editService.saveChanges();
        this.stepDetails.emit(updatedData[0]);
    }
}
