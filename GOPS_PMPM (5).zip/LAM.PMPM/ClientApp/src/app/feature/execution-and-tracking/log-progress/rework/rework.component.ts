import { HttpClient } from "@angular/common/http";
import {
    Component,
    EventEmitter,
    Input,
    OnInit,
    Output,
    SimpleChanges,
    ViewChild,
    ViewContainerRef,
    ViewEncapsulation,
} from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";
import { State } from "@progress/kendo-data-query";
import * as moment from "moment";
import { AppStoreService } from "../../../../core/app-store.service";
import { UserModel } from "../../../../core/model/user.model";
import { EditService } from "../../../service/edit.service";
import { DataServiceEandTService } from "../../data-service-eand-t.service";
import { StepDetail } from "../../Models/ModuleSummary";
import { environment } from "../../../../../environments/environment.dev_server";
import { NotificationService } from "@progress/kendo-angular-notification";
declare let require: any;

@Component({
    selector: "pmpm-rework",
    templateUrl: "./rework.component.html",
    styleUrls: ["./rework.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class ReworkComponent implements OnInit {
    @Input() gridDataForSteps: StepDetail[] = [];
    @Input() workRecordId = 0;
    @Output() reworkStepDetails: EventEmitter<any> = new EventEmitter<any>();

    @ViewChild("appendTo", { read: ViewContainerRef })
    public appendTo: ViewContainerRef;

    readonly apiUrl = `${environment.apiUrl}`;
    public loadTable = true;

    public gridState: State = {
        sort: [],
        skip: 0,
        take: 10,
    };
    notesDataItem: StepDetail;
    addOpened = false;
    notesValue = "";
    userDetails: UserModel;
    public readonly = false;
    public pilotProductId: number;
    public operationId: number;
    public gridDataForReworkSteps: StepDetail[] = [];
    public totalReworkSteps: number;
    public editWorkRecordID: number;
    public isEdit = false;
    public endTime: any = null;
    public disableAfterPicButton = true;

    constructor(
        private appStore: AppStoreService,
        private service: DataServiceEandTService,
        private editService: EditService,
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private http: HttpClient,
        private notificationService: NotificationService
    ) {}

    ngOnInit(): void {
        this.appStore.getLoggedInUser().subscribe((res) => {
            this.appStore.getUserDetails(res.mail).subscribe((user) => {
                if (user && user.username?.length > 0) {
                    this.userDetails = user;
                }
            });
        });

        if (this.gridDataForSteps && this.gridDataForSteps.length > 0)
            this.loadTable = false;
        else this.loadTable = true;
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (
            changes["gridDataForSteps"] &&
            changes["gridDataForSteps"] !== null &&
            changes["gridDataForSteps"].currentValue
        ) {
            this.gridDataForSteps = changes["gridDataForSteps"].currentValue;
            if (this.gridDataForSteps && this.gridDataForSteps.length > 0) {
                this.gridDataForSteps.forEach((item) => {
                    item.technicianNotes = this.getTechNotesInDifferentLines(
                        item.technicianNotes
                    );
                });
                this.loadTable = false;
            }
        }
    }

    public createFormGroupForSteps(dataItem: any): FormGroup {
        return this.formBuilder.group({
            stepRecordId: dataItem.stepRecordId,
            stepNo: dataItem.stepNo,
            reworked: dataItem.reworked,
            completedBy: dataItem.completedBy,
            completedById: dataItem.completedById,
            previousReworkedkBy: dataItem.previousReworkedkBy,
            previousReworkedkById: dataItem.previousReworkedkById,
            reworkedBy: dataItem.reworkedBy,
            reworkedById: dataItem.reworkedById,
            technicianNotes: dataItem.technicianNotes,
            numberofSteps: dataItem.numberofSteps,
            operationId: dataItem.operationId,
            cycleTimeMinutes: dataItem.cycleTimeMinutes,
            pilotProductId: dataItem.pilotProductId,
        });
    }

    public onStateChangeForSteps(state: State) {
        this.gridState = state;
    }

    public cellClickHandler({
        sender,
        rowIndex,
        columnIndex,
        dataItem,
        isEdited,
    }) {
        if (dataItem.completed === false) {
            sender.closeCell();
        } else {
            if (!isEdited) {
                sender.editCell(
                    rowIndex,
                    columnIndex,
                    this.createFormGroupForSteps(dataItem)
                );
            }
        }
    }

    openAddNotes(dataItem: StepDetail) {
        this.notesDataItem = dataItem;
        this.addOpened = true;
    }

    closeAddNotes() {
        this.notesValue = "";
        this.addOpened = false;
    }

    getTechNotesInDifferentLines(data) {
        let newNotes = "";
        if (data != null) {
            const notesArr = data.split("|");
            notesArr.forEach((val) => {
                if (val.trim() !== "") newNotes = newNotes + val.trim() + "\n";
            });
        }
        return newNotes;
    }
    onAddNote() {
        this.addOpened = false;
        const newNote =
            "[" +
            moment(new Date()).format("MM-DD-yyyy hh:mm A").toString() +
            ", " +
            this.userDetails.username +
            "]: " +
            this.notesValue +
            "\n";
        this.notesDataItem.technicianNotes =
            this.notesDataItem.technicianNotes !== null
                ? this.notesDataItem.technicianNotes + newNote
                : newNote;
        this.editService.update(this.notesDataItem, "Step Details");
        const updatedData = this.editService.saveChanges();
        this.reworkStepDetails.emit(updatedData[0]);
        this.notesValue = "";
    }

    onChangeReworked(dataItem: any) {
        dataItem.reworked = !dataItem.reworked;

        this.editService.update(dataItem, "Step Details");
        const updatedData = this.editService.saveChanges();
        if (updatedData && updatedData.length > 0) {
            if (dataItem.reworked) {
                updatedData[0][0].reworkedById = updatedData[0][0].reworked
                    ? this.userDetails.userId
                    : null;
                updatedData[0][0].reworkedBy = updatedData[0][0].reworked
                    ? this.userDetails.firstName +
                      " " +
                      this.userDetails.lastName
                    : null;
            } else {
                updatedData[0][0].reworkedById = null;
                updatedData[0][0].reworkedBy = null;
            }
            this.reworkStepDetails.emit(updatedData[0]);
        }
    }
}
