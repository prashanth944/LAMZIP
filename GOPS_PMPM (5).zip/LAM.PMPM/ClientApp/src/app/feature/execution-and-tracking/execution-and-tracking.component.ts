import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { AppStoreService } from "../../core/app-store.service";
import { uiScreen } from "../../core/model/common.constant";

@Component({
    selector: "pmpm-execution-and-tracking",
    templateUrl: "./execution-and-tracking.component.html",
    styleUrls: ["./execution-and-tracking.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class ExecutionAndTrackingComponent implements OnInit {
    public isUserAccess = false;
    isLoading = true;

    constructor(private appStoreService: AppStoreService) {}

    ngOnInit() {
        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.ENT)
                    .subscribe((result) => {
                        this.isUserAccess = result;
                        this.isLoading = false;
                    });
            }
        });
    }
}
