import {
    Component,
    Input,
    OnDestroy,
    OnInit,
    ViewChild,
    ViewContainerRef,
    ViewEncapsulation,
} from "@angular/core";
import { State, process, SortDescriptor } from "@progress/kendo-data-query";
import { DataServiceEandTService } from "./../data-service-eand-t.service";
import { EditService } from "./edit.service";
import {
    FormArray,
    FormBuilder,
    FormControl,
    FormGroup,
    Validators,
} from "@angular/forms";
import { Observable, Subscription } from "rxjs";
import { GridComponent, GridDataResult } from "@progress/kendo-angular-grid";
import { map } from "rxjs/operators";
import { AppStoreService } from "../../../core/app-store.service";
import { Plant } from "../../../core/model/user.model";
import { Router } from "@angular/router";
import { ExcelExportData } from "@progress/kendo-angular-excel-export";
import * as moment from "moment";
import { TooltipDirective } from "@progress/kendo-angular-tooltip";
import { role, uiScreen } from "../../../core/model/common.constant";
import { MultiSelectComponent } from "@progress/kendo-angular-dropdowns";
import { NotificationService } from "@progress/kendo-angular-notification";
import { DomSanitizer, SafeStyle } from "@angular/platform-browser";

const cloneData = (data: any[]) => data.map((item) => Object.assign({}, item));

@Component({
    selector: "app-wip-report",
    templateUrl: "./wip-report.component.html",
    styleUrls: ["./wip-report.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class WipReportComponent implements OnInit, OnDestroy {
    @Input() buildStyleID = 0;
    @Input() vaBuildID = 0;
    @Input() fromHomePage = false;
    @ViewChild(TooltipDirective) public tooltipDir: TooltipDirective;
    @ViewChild("multiselect") public multiselect: MultiSelectComponent;
    @ViewChild("appendTo", { read: ViewContainerRef })
    public appendTo: ViewContainerRef;
    @ViewChild("TualatinGrid") TualatinGrid: GridComponent;
    @ViewChild("FremontGrid") FremontGrid: GridComponent;

    public AllProductType: Observable<any>;
    public SelProductType: any;

    public AllBuildTypes: Observable<any>;
    public SelBuildTypes: any;

    public AllToolType: Observable<any>;
    public SelToolType: any;

    public AllCustomers: Observable<any[]>;
    public SelCustomers: any;

    public AllPilotRisk: Observable<any>;
    private DefMCSDRisk: any[] = ["", "LOW", "MEDIUM", "HIGH", "MISS"];
    public SelPilotRisk: any;

    public listStatus: string[] = [];

    public modAtRisk: Observable<any>;
    criticalModules: Observable<number>;
    gatingModules: Observable<number>;

    private textSearch = "";

    public view: Observable<GridDataResult>;
    public originalView: Observable<GridDataResult>;

    public isFilterSet = false;

    public sortU: SortDescriptor[] = [
        { field: "wipPriority" },
        { field: "pilotRisk" },
        { field: "fcid" },
        { field: "pilotSerialNumber" },
        { field: "ben" },
        { field: "status" },
        { field: "completePerc" },
        { field: "dayShift" },
        { field: "opsApprovedForShift" },
        { field: "bldg" },
        { field: "toolType" },
        { field: "buildType" },
        { field: "productType" },
        { field: "launchCommit" },
        { field: "launch" },
        { field: "integrationStart" },
        { field: "committedIntegrationStart" },
        { field: "integrationDelta" },
        { field: "testStartComited" },
        { field: "testStart" },
        { field: "testStartDelta" },
        { field: "testCompleteCommit" },
        { field: "testEngineer" },
        { field: "mfgComplete" },
        { field: "mdgCompleteDelta" },
        { field: "mcsd" },
        { field: "mcsdDelta" },
        { field: "crd" },
        { field: "shortagesAtLaunch" },
        { field: "comments" },
        { field: "earliestStartDate" },
        { field: "launchDelta" },
        { field: "manufacturingEngineer" },
        { field: "pbom" },
        { field: "customer" },
        { field: "tsd" },
    ];
    public noSort: SortDescriptor[] = [];

    public gridState: State = {
        sort: this.sortU,
        // Initial filter descriptor
        filter: {
            logic: "and",
            filters: [],
        },
    };

    site: Plant;
    isViewChart = false;
    planID: string;
    private subscription: Subscription[] = [];
    public UniqueWIPPriority: [] = [];
    public columns: any = [];
    public message = "";
    public showConfirmation = false;
    public buildingDDL: any[] = [];

    //Authentication
    canUserView = false; //View for all
    canUserEdit = false; //Task 20438: Edit button - Edit for Manager/Director, Supervisor, Task 20439: "End of Shift" Email button - Edit for Manager/Director, Supervisor,Task 20437: "Priority Reset" Button - Edit for Manager/Director, Supervisor
    canEditStaffed = false; //Task 41402: "Staffed" column - Edit for Super user, Supervisor, Lead
    canEditBldg = false; // US 36050: WIP Report - Make Building column editable
    canEditPR = false; //Task 41417: Remove supervisor from accessing priority reset button
    canEditEOS = false; //US 38169: WIP Report - Email Icon Add visibility to lead role
    canEditStatus = false; //US 51390: WIP Report - allow lead to edit [Status] and [Comment]
    canEditComments = false; //US 51753: WIP Report - allow PM to edit [Comment]

    public formGroups: FormGroup = new FormGroup({ items: new FormArray([]) });
    public hoverMessage = "";
    isExpanded = false;
    public askForConfirmation = false; //US 38490: WIP Email confirmation after clicking button
    public grid: any = [];
    public modulesInWIP: number;

    constructor(
        private router: Router,
        private appStoreService: AppStoreService,
        private dataService: DataServiceEandTService,
        public editService: EditService,
        private formBuilder: FormBuilder,
        private notificationService: NotificationService,
        private sanitizer: DomSanitizer
    ) {
        this.allData = this.allData.bind(this);
    }

    ngOnDestroy(): void {
        this.subscription.forEach((sub) => sub.unsubscribe());
        window.removeEventListener("scroll", this.scrollFixed);
    }

    ngOnInit() {
        this.noSort = JSON.parse(JSON.stringify(this.sortU));
        this.listStatus = [
            "On Time",
            "Delayed",
            "Early",
            "Waiting on Material",
        ];

        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.WipReoprt)
                    .subscribe((result) => {
                        this.canUserView = result;
                        if (
                            res.includes(role.SuperUser) ||
                            res.includes(role.Manager) ||
                            res.includes(role.Supervisor)
                        ) {
                            this.canUserEdit = true;
                        }
                        if (
                            res.includes(role.SuperUser) ||
                            res.includes(role.Manager) ||
                            res.includes(role.Supervisor) ||
                            res.includes(role.Leads)
                        ) {
                            this.canEditEOS = true;
                            this.canEditStatus = true;
                        }
                        if (
                            res.includes(role.SuperUser) ||
                            res.includes(role.Manager) ||
                            res.includes(role.Supervisor) ||
                            res.includes(role.Leads) ||
                            res.includes(role.ProjectManager)
                        ) {
                            this.canEditComments = true;
                        }
                        if (
                            res.includes(role.SuperUser) ||
                            res.includes(role.Manager)
                        ) {
                            this.canEditPR = true;
                        }
                        if (
                            res.includes(role.SuperUser) ||
                            res.includes(role.Supervisor) ||
                            res.includes(role.Leads)
                        ) {
                            this.canEditStaffed = true;
                        }
                        if (
                            res.includes(role.SuperUser) ||
                            res.includes(role.Manager) ||
                            res.includes(role.ProjectManager) ||
                            res.includes(role.Supervisor)
                        ) {
                            this.canEditBldg = true;
                        }
                    });
            }
        });

        this.subscription.push(
            this.appStoreService.getCurrentSite().subscribe((site) => {
                if (site) {
                    this.site = {
                        plantName: site.plantName,
                        plantId: site.plantId,
                    };
                    this.clearFilters();
                    this.editService.cancelChanges();
                    this.updateModules(this.site.plantId);
                    this.getPORPlanId();
                    this.getBuilding();
                }
            })
        );
    }

    getPORPlanId() {
        this.appStoreService
            .getPORProductionPlanID(this.site.plantId)
            .subscribe((res) => {
                if (res) {
                    this.planID = res[0].productionPlanID;
                }
            });
    }

    public updateModules(plantId) {
        this.view = this.editService.pipe(
            map((data) => process(data, this.gridState))
        );

        this.originalView = Object.assign([], this.view);

        this.view.subscribe((res) => {
            this.modulesInWIP =
                res.data.length > 0 ? res.data[0].modulesInWIP : 0;
        });

        this.AllPilotRisk = this.editService.pipe(
            map((data) => this.GetUniques(data, "pilotRisk"))
        );
        this.AllProductType = this.editService.pipe(
            map((data) => this.GetUniques(data, "productType"))
        );

        this.AllBuildTypes = this.editService.pipe(
            map((data) => this.GetUniques(data, "buildType"))
        );

        this.AllToolType = this.editService.pipe(
            map((data) => this.GetUniques(data, "toolType"))
        );

        this.AllCustomers = this.editService.pipe(
            map((data) => this.GetUniques(data, "customer"))
        );

        this.modAtRisk = this.editService.pipe(
            map(
                (data) =>
                    data.filter((value) => value["pilotRisk"] === "HIGH").length
            )
        );

        this.criticalModules = this.editService.pipe(
            map(
                (data) =>
                    data.filter((value) => value["isCritical"] === true).length
            )
        );

        this.gatingModules = this.editService.pipe(
            map(
                (data) =>
                    data.filter((value) => value["isGating"] === true).length
            )
        );

        this.editService.read(plantId, this.buildStyleID, this.vaBuildID);
    }

    public GetUniques(data: any[], colName: string) {
        const uniqueData: any = data
            .map((item) => item[colName])
            .filter((value, index, self) => self.indexOf(value) === index)
            .map((val) => ({ text: val, value: val }));
        uniqueData.forEach((item) => {
            if (item.value === "") item.text = "BLANK";
        });
        uniqueData.sort(function (a, b) {
            const textA = a?.text.toUpperCase();
            const textB = b?.text.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
        });
        return uniqueData;
    }

    //Task 20336: Make the WIP drop down filters with multiselect
    public updateFromFilter() {
        this.gridState["filter"] = {
            logic: "and",
            filters: [],
        };

        if (this.SelProductType && this.SelProductType.length > 0) {
            const PT: any[] = [];
            this.SelProductType.forEach((item) => {
                PT.push({
                    field: "productType",
                    operator: this.getOperator(item.value),
                    value: item.value,
                });
            });
            this.gridState["filter"].filters.push({
                logic: "or",
                filters: [...PT],
            });
            this.isFilterSet = true;
        }
        if (this.SelBuildTypes && this.SelBuildTypes.length > 0) {
            const BT: any[] = [];
            this.SelBuildTypes.forEach((item) => {
                BT.push({
                    field: "buildType",
                    operator: this.getOperator(item.value),
                    value: item.value,
                });
            });
            this.gridState["filter"].filters.push({
                logic: "or",
                filters: [...BT],
            });
            this.isFilterSet = true;
        }
        if (this.SelToolType && this.SelToolType.length > 0) {
            const TT: any[] = [];
            this.SelToolType.forEach((item) => {
                TT.push({
                    field: "toolType",
                    operator: this.getOperator(item.value),
                    value: item.value,
                });
            });
            this.gridState["filter"].filters.push({
                logic: "or",
                filters: [...TT],
            });
            this.isFilterSet = true;
        }
        if (this.SelCustomers && this.SelCustomers.length > 0) {
            const customer: any[] = [];
            this.SelCustomers.forEach((item) => {
                customer.push({
                    field: "customer",
                    operator: this.getOperator(item.value),
                    value: item.value,
                });
            });
            this.gridState["filter"].filters.push({
                logic: "or",
                filters: [...customer],
            });
            this.isFilterSet = true;
        }
        if (this.SelPilotRisk && this.SelPilotRisk.length > 0) {
            const PR: any[] = [];
            this.SelPilotRisk.forEach((item) => {
                PR.push({
                    field: "pilotRisk",
                    operator: this.getOperator(item.value),
                    value: item.value,
                });
            });
            this.gridState["filter"].filters.push({
                logic: "or",
                filters: [...PR],
            });
            this.isFilterSet = true;
        }

        if (this.textSearch) {
            this.isFilterSet = true;
            if (this.site.plantName === "Tualatin") {
                this.gridState["filter"].filters.push({
                    logic: "or",
                    filters: [
                        {
                            field: "ben",
                            operator: "contains",
                            value: this.textSearch.trim(),
                        },
                        {
                            field: "fcid",
                            operator: "contains",
                            value: this.textSearch.trim(),
                        },
                    ],
                });
            }
            if (this.site.plantName === "Fremont") {
                this.gridState["filter"].filters.push({
                    logic: "or",
                    filters: [
                        {
                            field: "fcid",
                            operator: "contains",
                            value: this.textSearch.trim(),
                        },
                        {
                            field: "fremontID",
                            operator: "contains",
                            value: this.textSearch.trim(),
                        },
                        {
                            field: "pilotSerialNumber",
                            operator: "contains",
                            value: this.textSearch.trim(),
                        },
                    ],
                });
            }
        }
        if (this.gridState["filter"].filters.length === 0) {
            this.gridState["filter"].filters = [];
            this.isFilterSet = false;
        }

        this.editService.read(
            this.site.plantId,
            this.buildStyleID,
            this.vaBuildID
        );
    }

    clearFilters() {
        this.SelPilotRisk = undefined;
        this.SelProductType = undefined;
        this.SelBuildTypes = undefined;
        this.SelToolType = undefined;
        this.SelCustomers = undefined;
        this.textSearch = "";
        this.gridState["filter"].filters = [];
        this.updateFromFilter();
        this.isFilterSet = false;
        this.sortChange(this.noSort);
    }

    public onFilter(inputValue: string): void {
        this.textSearch = inputValue;
        if (inputValue != "") {
            this.isFilterSet = true;
        }
        this.updateFromFilter();
    }
    public getValue(event: Event): string {
        return (event.target as HTMLInputElement).value;
    }

    public saveChanges(): void {
        this.editService.saveChanges(
            this.site.plantId,
            this.buildStyleID,
            this.vaBuildID
        );
    }

    public cancelChanges(grid: any): void {
        this.editService.cancelChanges();
    }

    public cancelHandler({ sender, rowIndex }) {
        sender.closeRow(rowIndex);
    }

    public saveHandler({ sender, formGroup, rowIndex }) {
        if (formGroup.valid) {
            this.editService.create(formGroup.value);
            sender.closeRow(rowIndex);
        }
    }

    public routeToEditModule(pilotProductID: number) {
        this.router.navigate(["/edit-module/" + pilotProductID + "/" + 0]);
    }

    public cellClickHandler({
        sender,
        rowIndex,
        columnIndex,
        dataItem,
        isEdited,
    }) {
        if (!isEdited) {
            sender.editCell(
                rowIndex,
                columnIndex,
                this.createFormGroup(dataItem)
            );
        }
    }

    public cellCloseHandler(args: any) {
        const { formGroup, dataItem } = args;

        if (!formGroup.valid) {
            // prevent closing the edited cell if there are invalid values.
            args.preventDefault();
        } else if (formGroup.dirty) {
            if (args.column.field === "wipPriority") {
                const notNullWIPPriority = this.view["destination"].data.filter(
                    (x) => x.wipPriority
                );
                const UniqueWIPPriority = [
                    ...new Set(
                        notNullWIPPriority.map((obj) => obj.wipPriority)
                    ),
                ];
                const checkIfDuplicate = UniqueWIPPriority.find(
                    (x) => x === args.formGroup.value.wipPriority
                );
                if (checkIfDuplicate) {
                    formGroup.controls["wipPriority"].setErrors({
                        incorrect: true,
                    });
                    args.preventDefault();
                } else {
                    formGroup.value.staffed = args.dataItem.staffed;
                    this.editService.assignValues(dataItem, formGroup.value);
                    this.editService.update(dataItem);
                    this.editService.saveChanges(
                        this.site.plantId,
                        this.buildStyleID,
                        this.vaBuildID
                    );
                    if (this.editService.isSaved) {
                        this.showSuccess("Saved");
                        this.updateModules(this.site.plantId);
                    } else {
                        this.showError("Error");
                    }
                }
            } else if (args.column.field === "bldg") {
                args.dataItem.bldg = formGroup.value.bldg.buildingName;
                args.dataItem.buildingId = formGroup.value.bldg.buildingID;
                formGroup.value.buildingId = formGroup.value.bldg.buildingID;
                const buildingName = formGroup.value.bldg.buildingName;
                formGroup.value.bldg = buildingName;
                this.editService.assignValues(dataItem, formGroup.value);
                this.editService.update(dataItem);
                this.editService.saveChanges(
                    this.site.plantId,
                    this.buildStyleID,
                    this.vaBuildID
                );
                if (this.editService.isSaved) {
                    this.showSuccess("Saved");
                    this.updateModules(this.site.plantId);
                } else {
                    this.showError("Error");
                }
            }

            if (args.column.field != "wipPriority") {
                formGroup.value.staffed = args.dataItem.staffed;
                this.editService.assignValues(dataItem, formGroup.value);
                this.editService.update(dataItem);
                this.editService.saveChanges(
                    this.site.plantId,
                    this.buildStyleID,
                    this.vaBuildID
                );
                if (this.editService.isSaved) {
                    this.showSuccess("Saved");
                    this.updateModules(this.site.plantId);
                } else {
                    this.showError("Error");
                }
            }
        }
    }

    onViewChart() {
        this.isViewChart = !this.isViewChart;
    }

    public createFormGroup(dataItem: any): FormGroup {
        return this.formBuilder.group({
            pilotProductID: dataItem.pilotProductID,
            comments: dataItem.comments,
            pilotRisk: dataItem.pilotRisk,
            status: dataItem.status,
            staffed: new FormControl(dataItem.staffed),
            wipPriority: [
                dataItem.wipPriority,
                Validators.compose([
                    Validators.pattern("^(?!0+$)(?!Q0+$)[Q]?[0-9]{1,3}"),
                ]),
            ],
            bldg: dataItem.bldg,
            buildingId: dataItem.buildingId,
        });
    }

    priorityReset() {
        this.sortChange(this.noSort);
        //call reset api
        this.dataService.priorityReset(this.site.plantId).subscribe((data) => {
            if (data && data["value"] === "Updated Successfully") {
                this.editService.read(
                    this.site.plantId,
                    this.buildStyleID,
                    this.vaBuildID
                );
            }
        });
    }

    public allData(): ExcelExportData {
        const excelData = JSON.parse(
            JSON.stringify(this.view["destination"].data)
        );
        for (let i = 0; i < this.view["destination"].data.length; i++) {
            //Staffed
            excelData[i].staffed =
                this.view["destination"].data[i].staffed === true
                    ? true
                    : false;
            //CG
            excelData[i].isCritical =
                this.view["destination"].data[i].isCritical === true ||
                this.view["destination"].data[i].isGating === true
                    ? true
                    : false;
            //Day Shift Only
            excelData[i].dayShiftOnly =
                this.view["destination"].data[i].dayShiftOnly === true
                    ? "Yes"
                    : "No";
            //Building
            excelData[i].buildingId = this.view["destination"].data[i].bldg;
            //Shortages at Launch
            excelData[i].shortagesAtLaunch =
                this.view["destination"].data[i].shortagesAtLaunch === null
                    ? 0
                    : this.view["destination"].data[i].shortagesAtLaunch;
        }
        const result: ExcelExportData = {
            data: process(excelData, this.gridState).data,
        };
        return result;
    }

    public exportToExcel(
        TualatinGrid: GridComponent,
        FremontGrid: GridComponent
    ): void {
        if (this.site.plantName === "Tualatin") TualatinGrid.saveAsExcel();
        else FremontGrid.saveAsExcel();
    }

    routeToTOI(pilotProductID: number) {
        let tabId = 0;
        if (this.site.plantName === "Fremont") tabId = 5;
        else tabId = 6;
        this.router
            .navigateByUrl("/", { skipLocationChange: true })
            .then(() => {
                this.router.navigate([
                    "/action-items/" + pilotProductID + "/" + tabId,
                ]);
            });
    }

    showAskForConfirmationPopup(TualatinGrid: any, FremontGrid: any) {
        if (this.site.plantName === "Tualatin") this.grid = TualatinGrid;
        else this.grid = FremontGrid;

        this.askForConfirmation = true;
    }

    sendEmail(grid: any) {
        this.askForConfirmation = false;
        this.columns = [];
        this.grid.columns._results.forEach((item) => {
            if (!item.hidden) this.columns.push(item.title);
        });

        if (this.columns.length > 0) {
            let date: any = new Date();
            date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
            this.dataService
                .SendWIPEmail(this.columns, this.site.plantId, date)
                .subscribe((req) => {
                    if (req && req["value"] === "Updated Successfully") {
                        this.message = "The email has been sent.";
                        this.showConfirmation = true;
                    } else {
                        this.message =
                            "Error encountered while sending email, please try again.";
                        this.showConfirmation = true;
                    }
                });
        }
    }

    private getOperator(value) {
        const options = {
            null: "isnull",
            "": "isempty",
        };
        return options[value] || "eq";
    }

    public tagMapper(tags: any[]): any[] {
        tags.sort(function (a, b) {
            const textA = a?.text.toUpperCase();
            const textB = b?.text.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
        });
        return tags;
    }

    public getBuilding() {
        this.dataService.getBuilding(this.site.plantId).subscribe((res) => {
            this.buildingDDL = res;
        });
    }

    public building(id: number): any {
        return this.buildingDDL.find((x) => x.buildingID === id);
    }

    filterHighRiskModules() {
        this.SelPilotRisk = [];
        this.SelPilotRisk.push({ text: "HIGH", value: "HIGH" });
        this.updateFromFilter();
    }

    public sortChange(sort: SortDescriptor[]): void {
        this.sortU = sort;
        this.gridState["sort"] = sort;

        this.view = this.editService.pipe(
            map((data) =>
                process(this.view["destination"].data, this.gridState)
            )
        );
    }

    onChangeStaffed(dataItem: any) {
        dataItem.staffed = !dataItem.staffed;
        const currentDateTime = new Date();
        const currentHour = currentDateTime.getHours();
        const currentMinutes = currentDateTime.getMinutes();
        if (this.site.plantName === "Fremont") {
            //Shift time is 4am, 4pm
            if (currentHour >= 4 && currentHour <= 16 && currentMinutes >= 0) {
                dataItem.shift = "D";
                dataItem.currentDayShift = dataItem.staffed ? true : false;
            } else {
                dataItem.shift = "N";
                dataItem.currentNightShift = dataItem.staffed ? true : false;
            }
        } else if (this.site.plantName === "Tualatin") {
            //Shift time is 7.45am, 7.45pm
            if (
                (currentHour === 7 && currentMinutes >= 45) ||
                (currentHour === 19 && currentMinutes <= 45) ||
                (currentHour > 7 && currentHour < 19)
            ) {
                dataItem.shift = "D";
                dataItem.currentDayShift = dataItem.staffed ? true : false;
            } else {
                dataItem.shift = "N";
                dataItem.currentNightShift = dataItem.staffed ? true : false;
            }
        }

        if (
            (dataItem.currentDayShift &&
                dataItem.lastNightShift &&
                dataItem.shift === "D") ||
            (dataItem.currentNightShift &&
                dataItem.lastDayShift &&
                dataItem.shift === "N")
        ) {
            dataItem.idle = "D/N";
        } else if (
            (dataItem.currentDayShift &&
                !dataItem.lastNightShift &&
                dataItem.shift === "D") ||
            (!dataItem.currentNightShift &&
                dataItem.lastDayShift &&
                dataItem.shift === "N")
        ) {
            dataItem.idle = "D";
        } else if (
            (!dataItem.currentDayShift &&
                dataItem.lastNightShift &&
                dataItem.shift === "D") ||
            (dataItem.currentNightShift &&
                !dataItem.lastDayShift &&
                dataItem.shift === "N")
        ) {
            dataItem.idle = "N";
        } else if (
            (!dataItem.currentDayShift &&
                !dataItem.lastNightShift &&
                dataItem.shift === "D") ||
            (!dataItem.currentNightShift &&
                !dataItem.lastDayShift &&
                dataItem.shift === "N")
        ) {
            dataItem.idle = "";
        }

        this.editService.update(dataItem);
        this.editService.saveChanges(
            this.site.plantId,
            this.buildStyleID,
            this.vaBuildID
        );
        if (this.editService.isSaved) {
            this.showSuccess("Saved");
            this.updateModules(this.site.plantId);
        } else {
            this.showError("Error");
        }
    }

    public getFormControl(dataItem: any, field: string): FormControl {
        // return the FormControl for the respective column editor
        return <FormControl>(
            (this.formGroups?.get("items") as FormArray).controls
                .find((i) => i.value.pilotProductID === dataItem.pilotProductID)
                ?.get(field)
        );
    }

    ngAfterViewInit() {
        window.addEventListener("scroll", this.scrollFixed);
    }

    private scrollFixed() {
        let grid;
        let header;

        grid = <HTMLElement>document?.querySelector(".wip-grid-not-expanded");
        if (grid === null) {
            grid = <HTMLElement>document?.querySelector(".wip-grid-expanded");
            header = <HTMLElement>(
                grid?.querySelector(".wip-grid-expanded .k-grid-header")
            );
        } else {
            header = <HTMLElement>(
                grid?.querySelector(".wip-grid-not-expanded .k-grid-header")
            );
        }
        const stickyContainer = <HTMLElement>(
            document?.querySelector(".wip-filter-container-sticky")
        );

        const offset = window.scrollY - (70 / 100) * window.scrollY;
        const tableOffsetTop = grid?.offsetTop;
        const tableOffsetBottom =
            tableOffsetTop +
            grid?.clientHeight -
            header?.clientHeight -
            stickyContainer?.clientHeight;

        header.classList.add("fixed-header");
        header.style.width = grid?.clientWidth + "px";
    }

    onPanelExpand(event) {
        this.isExpanded = !this.isExpanded;
    }

    public showSuccess(msg: string): void {
        this.notificationService.show({
            appendTo: this.appendTo,
            content: msg,
            position: { horizontal: "left", vertical: "bottom" },
            animation: { type: "fade", duration: 600 },
            type: { style: "success", icon: true },
        });
    }

    public showError(msg: string): void {
        this.notificationService.show({
            appendTo: this.appendTo,
            content: msg,
            position: { horizontal: "left", vertical: "bottom" },
            animation: { type: "fade", duration: 600 },
            type: { style: "error", icon: true },
        });
    }
    public dateColorCode(dataItem: any, columnName: string): SafeStyle {
        let result = "#ffffff";
        if (dataItem) {
            if (dataItem[columnName] === null) {
                result = "#ffffff";
            } else {
                if (columnName.toLowerCase().includes("launch")) {
                    if (dataItem.currentStage === null) {
                        //Future stage
                        if (columnName === "launchDelta") {
                            if (dataItem.launchDelta <= -2)
                                //Delta - Dark Red
                                result = "#c05046";
                            else if (dataItem.launchDelta === -1)
                                //Delta - Dark Yellow
                                result = "#ffc000";
                            else if (dataItem.launchDelta >= 0)
                                // Delta - Dark Green
                                result = "#789440";
                        } else {
                            result = "#ffffff";
                        }
                    } else {
                        //Current or Past stage
                        result = "#d8d8d8";
                    }
                } else if (columnName.toLowerCase().includes("integration")) {
                    if (dataItem.currentStage === null) {
                        //Future stage
                        if (columnName === "integrationDelta") {
                            if (dataItem.integrationDelta <= -2)
                                //Delta - Dark Red
                                result = "#c05046";
                            else if (dataItem.integrationDelta === -1)
                                //Delta - Dark Yellow
                                result = "#ffc000";
                            else if (dataItem.integrationDelta >= 0)
                                // Delta - Dark Green
                                result = "#789440";
                        } else {
                            result = "#ffffff";
                        }
                    } else if (dataItem.currentStage === "Integration") {
                        //Current stage
                        result = "#d8d8d8";
                    } else if (dataItem.currentStage === "Launch") {
                        // Current + 1 stage
                        if (dataItem.integrationDelta <= -2) {
                            //Actual, Planned - Red, Delta - Dark Red
                            if (columnName === "integrationDelta")
                                result = "#c05046";
                            else result = "#e5b9b5";
                        } else if (dataItem.integrationDelta === -1) {
                            //Actual, Planned - Yellow, Delta - Dark Yellow
                            if (columnName === "integrationDelta")
                                result = "#ffc000";
                            else result = "#fee599";
                        } else if (dataItem.integrationDelta >= 0) {
                            //Actual, Planned - Green, Delta - Dark Green
                            if (columnName === "integrationDelta")
                                result = "#789440";
                            else result = "#d7e3bf";
                        }
                    } else {
                        //Past stage
                        result = "#d8d8d8";
                    }
                } else if (columnName.toLowerCase().includes("test")) {
                    if (
                        dataItem.currentStage === "Mfg" ||
                        dataItem.currentStage === "Test"
                    ) {
                        //Past stage or Current Stage
                        result = "#d8d8d8";
                    } else if (dataItem.currentStage === "Integration") {
                        //Current + 1 Stage
                        if (dataItem.testStartDelta <= -2) {
                            //Actual, Planned - Red, Delta - Dark Red
                            if (columnName === "testStartDelta")
                                result = "#c05046";
                            else result = "#e5b9b5";
                        } else if (dataItem.testStartDelta === -1) {
                            //Actual, Planned - Yellow, Delta - Dark Yellow
                            if (columnName === "testStartDelta")
                                result = "#ffc000";
                            else result = "#fee599";
                        } else if (dataItem.testStartDelta >= 0) {
                            //Actual, Planned - Green, Delta - Dark Green
                            if (columnName === "testStartDelta")
                                result = "#789440";
                            else result = "#d7e3bf";
                        }
                    } else {
                        //Future stage
                        if (columnName === "testStartDelta") {
                            if (dataItem.testStartDelta <= -2)
                                //Delta - Dark Red
                                result = "#c05046";
                            else if (dataItem.testStartDelta === -1)
                                //Delta - Dark Yellow
                                result = "#ffc000";
                            else if (dataItem.testStartDelta >= 0)
                                // Delta - Dark Green
                                result = "#789440";
                        } else {
                            result = "#ffffff";
                        }
                    }
                } else if (
                    columnName.toLowerCase().includes("manufacturingcomplete")
                ) {
                    if (dataItem.currentStage === "Mfg") {
                        //Current stage
                        result = "#d8d8d8";
                    } else if (dataItem.currentStage === "Test") {
                        //Current + 1 Stage
                        if (dataItem.manufacturingCompleteDelta <= -2) {
                            //Actual, Planned - Red, Delta - Dark Red
                            if (columnName === "manufacturingCompleteDelta")
                                result = "#c05046";
                            else result = "#e5b9b5";
                        } else if (dataItem.manufacturingCompleteDelta === -1) {
                            //Actual, Planned - Yellow, Delta - Dark Yellow
                            if (columnName === "manufacturingCompleteDelta")
                                result = "#ffc000";
                            else result = "#fee599";
                        } else if (dataItem.manufacturingCompleteDelta >= 0) {
                            //Actual, Planned - Green, Delta - Dark Green
                            if (columnName === "manufacturingCompleteDelta")
                                result = "#789440";
                            else result = "#d7e3bf";
                        }
                    } else {
                        // Future stage
                        if (columnName === "manufacturingCompleteDelta") {
                            if (dataItem.manufacturingCompleteDelta <= -2)
                                //Delta - Dark Red
                                result = "#c05046";
                            else if (dataItem.manufacturingCompleteDelta === -1)
                                //Delta - Dark Yellow
                                result = "#ffc000";
                            else if (dataItem.manufacturingCompleteDelta >= 0)
                                // Delta - Dark Green
                                result = "#789440";
                        } else {
                            result = "#ffffff";
                        }
                    }
                }
            }
        }
        return this.sanitizer.bypassSecurityTrustStyle(result);
    }

    public deltaColorCode(dataItem: any, columnName: string): SafeStyle {
        let result = "#000000";
        if (dataItem) {
            if (dataItem[columnName] === null) {
                result = "#ffffff";
            } else {
                if (
                    dataItem.currentStage === "Launch" &&
                    (columnName === "integrationDelta" ||
                        columnName === "testStartDelta" ||
                        columnName === "manufacturingCompleteDelta")
                ) {
                    result = "#ffffff";
                } else if (
                    dataItem.currentStage === "Integration" &&
                    (columnName === "testStartDelta" ||
                        columnName === "manufacturingCompleteDelta")
                ) {
                    result = "#ffffff";
                } else if (
                    dataItem.currentStage === "Test" &&
                    columnName === "manufacturingCompleteDelta"
                ) {
                    result = "#ffffff";
                } else if (
                    dataItem.currentStage === null &&
                    (columnName === "launchDelta" ||
                        columnName === "integrationDelta" ||
                        columnName === "testStartDelta" ||
                        columnName === "manufacturingCompleteDelta")
                ) {
                    result = "#ffffff";
                }
            }
        }
        return this.sanitizer.bypassSecurityTrustStyle(result);
    }

    public borderColor(dataItem: any, columnName: string): SafeStyle {
        let result = "none";
        if (dataItem) {
            if (dataItem[columnName] === null) {
                result = "none";
            } else {
                if (dataItem.currentStage === null) {
                    if (
                        columnName === "actualLaunch" &&
                        dataItem.actualLaunchHover != null &&
                        dataItem.actualLaunchHover.includes("-")
                    )
                        //Green border
                        result = "solid #008000";
                    else if (
                        columnName === "actualLaunch" &&
                        dataItem.actualLaunchHover != null &&
                        dataItem.actualLaunchHover.includes("+")
                    )
                        //Red border
                        result = "solid #c00101";
                    else if (
                        columnName === "actualIntegrationStart" &&
                        dataItem.actualIntegrationStarthHover != null &&
                        dataItem.actualIntegrationStarthHover.includes("-")
                    )
                        //Green border
                        result = "solid #008000";
                    else if (
                        columnName === "actualIntegrationStart" &&
                        dataItem.actualIntegrationStarthHover != null &&
                        dataItem.actualIntegrationStarthHover.includes("+")
                    )
                        result = "solid #c00101";
                    else if (
                        columnName === "actualTestStart" &&
                        dataItem.actualTestStartHover != null &&
                        dataItem.actualTestStartHover.includes("-")
                    )
                        //Green border
                        result = "solid #008000";
                    else if (
                        columnName === "actualTestStart" &&
                        dataItem.actualTestStartHover != null &&
                        dataItem.actualTestStartHover.includes("+")
                    )
                        result = "solid #c00101";
                    else if (
                        columnName === "actualManufacturingComplete" &&
                        dataItem.actualManufacturingCompletetHover != null &&
                        dataItem.actualManufacturingCompletetHover.includes("-")
                    )
                        //Green border
                        result = "solid #008000";
                    else if (
                        columnName === "actualManufacturingComplete" &&
                        dataItem.actualManufacturingCompletetHover != null &&
                        dataItem.actualManufacturingCompletetHover.includes("+")
                    )
                        result = "solid #c00101";
                } else if (dataItem.currentStage === "Launch") {
                    if (
                        columnName === "actualIntegrationStart" &&
                        dataItem.actualIntegrationStarthHover != null &&
                        dataItem.actualIntegrationStarthHover.includes("-")
                    )
                        //Green border
                        result = "solid #008000";
                    else if (
                        columnName === "actualIntegrationStart" &&
                        dataItem.actualIntegrationStarthHover != null &&
                        dataItem.actualIntegrationStarthHover.includes("+")
                    )
                        result = "solid #c00101";
                    else if (
                        columnName === "actualTestStart" &&
                        dataItem.actualTestStartHover != null &&
                        dataItem.actualTestStartHover.includes("-")
                    )
                        //Green border
                        result = "solid #008000";
                    else if (
                        columnName === "actualTestStart" &&
                        dataItem.actualTestStartHover != null &&
                        dataItem.actualTestStartHover.includes("+")
                    )
                        result = "solid #c00101";
                    else if (
                        columnName === "actualManufacturingComplete" &&
                        dataItem.actualManufacturingCompletetHover != null &&
                        dataItem.actualManufacturingCompletetHover.includes("-")
                    )
                        //Green border
                        result = "solid #008000";
                    else if (
                        columnName === "actualManufacturingComplete" &&
                        dataItem.actualManufacturingCompletetHover != null &&
                        dataItem.actualManufacturingCompletetHover.includes("+")
                    )
                        result = "solid #c00101";
                } else if (dataItem.currentStage === "Integration") {
                    if (
                        columnName === "actualTestStart" &&
                        dataItem.actualTestStartHover != null &&
                        dataItem.actualTestStartHover.includes("-")
                    )
                        //Green border
                        result = "solid #008000";
                    else if (
                        columnName === "actualTestStart" &&
                        dataItem.actualTestStartHover != null &&
                        dataItem.actualTestStartHover.includes("+")
                    )
                        result = "solid #c00101";
                    else if (
                        columnName === "actualManufacturingComplete" &&
                        dataItem.actualManufacturingCompletetHover != null &&
                        dataItem.actualManufacturingCompletetHover.includes("-")
                    )
                        //Green border
                        result = "solid #008000";
                    else if (
                        columnName === "actualManufacturingComplete" &&
                        dataItem.actualManufacturingCompletetHover != null &&
                        dataItem.actualManufacturingCompletetHover.includes("+")
                    )
                        result = "solid #c00101";
                } else if (dataItem.currentStage === "Test") {
                    if (
                        columnName === "actualManufacturingComplete" &&
                        dataItem.actualManufacturingCompletetHover != null &&
                        dataItem.actualManufacturingCompletetHover.includes("-")
                    )
                        //Green border
                        result = "solid #008000";
                    else if (
                        columnName === "actualManufacturingComplete" &&
                        dataItem.actualManufacturingCompletetHover != null &&
                        dataItem.actualManufacturingCompletetHover.includes("+")
                    )
                        result = "solid #c00101";
                }
            }
        }
        return this.sanitizer.bypassSecurityTrustStyle(result);
    }
}
