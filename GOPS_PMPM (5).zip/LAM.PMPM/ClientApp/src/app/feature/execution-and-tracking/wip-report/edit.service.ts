import { Injectable } from "@angular/core";
import * as moment from "moment";
import { BehaviorSubject, zip } from "rxjs";
import { HomePageService } from "../../home-page/service/home-page.service";
import { DataServiceEandTService } from "../data-service-eand-t.service";

const itemIndex = (item: any, data: any[]): number => {
    for (let idx = 0; idx < data.length; idx++) {
        if (data[idx].pilotProductID === item.pilotProductID) {
            return idx;
        }
    }

    return -1;
};

const cloneData = (data: any[]) => data.map((item) => Object.assign({}, item));

@Injectable({
    providedIn: "root",
})
export class EditService extends BehaviorSubject<any[]> {
    private data: any[] = [];
    private originalData: any[] = [];
    private createdItems: any[] = [];
    private updatedItems: any[] = [];
    private deletedItems: any[] = [];
    public isSaved = true;

    constructor(
        private dataService: DataServiceEandTService,
        private service: HomePageService
    ) {
        super([]);
    }

    public read(plantID, buildStyleID, vaBuildID) {
        this.data = [];
        if (buildStyleID === 0) {
            let date: any = new Date();
            date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
            this.dataService.getModule(plantID, date).subscribe((data) => {
                this.data = data;
                //Replace html tags with ""
                this.data.forEach((item) => {
                    if (item.comments !== null)
                        item.comments = item.comments.replace(
                            /(<([^>]+)>)/gi,
                            ""
                        );

                    if (item.productType === null) item.productType = "";
                    if (item.buildType === null) item.buildType = "";
                    if (item.toolType === null) item.toolType = "";
                    if (item.customer === null) item.customer = "";
                    if (item.pilotRisk === null) item.pilotRisk = "";

                    //Deltas - Convert 99999 to null to handle background color coding
                    if (item.launchDelta === 99999) item.launchDelta = null;
                    if (item.integrationDelta === 99999)
                        item.integrationDelta = null;
                    if (item.testStartDelta === 99999)
                        item.testStartDelta = null;
                    if (item.manufacturingCompleteDelta === 99999)
                        item.manufacturingCompleteDelta = null;
                    if (item.mcsdDelta === 99999) item.mcsdDelta = null;

                    //Dates - Task: 41411 Hide year for every date but MCSD

                    if (item.actualLaunch !== null) {
                        item.actualLaunch = moment(item.actualLaunch).format(
                            "M-D"
                        );
                    }
                    if (item.plannedLaunch !== null) {
                        item.plannedLaunch = moment(item.plannedLaunch).format(
                            "M-D"
                        );
                    }
                    if (item.actualIntegrationStart !== null) {
                        item.actualIntegrationStart = moment(
                            item.actualIntegrationStart
                        ).format("M-D");
                    }
                    if (item.plannedIntegrationStart !== null) {
                        item.plannedIntegrationStart = moment(
                            item.plannedIntegrationStart
                        ).format("M-D");
                    }
                    if (item.actualTestStart !== null) {
                        item.actualTestStart = moment(
                            item.actualTestStart
                        ).format("M-D");
                    }
                    if (item.plannedTestStart !== null) {
                        item.plannedTestStart = moment(
                            item.plannedTestStart
                        ).format("M-D");
                    }
                    if (item.actualManufacturingComplete !== null) {
                        item.actualManufacturingComplete = moment(
                            item.actualManufacturingComplete
                        ).format("M-D");
                    }
                    if (item.plannedManufacturingComplete !== null) {
                        item.plannedManufacturingComplete = moment(
                            item.plannedManufacturingComplete
                        ).format("M-D");
                    }
                    if (item.mcsd !== null) {
                        item.mcsd = moment(item.mcsd).format("M-D-YY");
                    }
                    if (item.crd !== null) {
                        item.crd = moment(item.crd).format("M-D");
                    }
                });

                this.originalData = cloneData(data);
                super.next(data);
            });
        } else {
            this.data = [];
            let newData = [];
            let newVAData = [];
            this.service
                .getHomeWIPbuild(plantID, buildStyleID)
                .subscribe((data) => {
                    newData = [];
                    newData = data;
                    if (vaBuildID > 0) {
                        this.service
                            .getHomeWIPbuild(plantID, vaBuildID)
                            .subscribe((vaData) => {
                                newVAData = [];
                                newVAData = vaData;
                                this.originalData = cloneData([
                                    ...newData,
                                    ...newVAData,
                                ]);
                                super.next([...newData, ...newVAData]);
                            });
                    } else {
                        this.originalData = cloneData([
                            ...newData,
                            ...newVAData,
                        ]);
                        super.next([...newData, ...newVAData]);
                    }
                });
        }
    }

    public create(item: any): void {
        this.createdItems.push(item);
        this.data.unshift(item);

        super.next(this.data);
    }

    public update(item: any): void {
        if (!this.isNew(item)) {
            const index = itemIndex(item, this.updatedItems);
            if (index !== -1) {
                this.updatedItems.splice(index, 1, item);
            } else {
                this.updatedItems.push(item);
            }
        } else {
            const index = this.createdItems.indexOf(item);
            this.createdItems.splice(index, 1, item);
        }
    }

    public remove(item: any): void {
        let index = itemIndex(item, this.data);
        this.data.splice(index, 1);

        index = itemIndex(item, this.createdItems);
        if (index >= 0) {
            this.createdItems.splice(index, 1);
        } else {
            this.deletedItems.push(item);
        }

        index = itemIndex(item, this.updatedItems);
        if (index >= 0) {
            this.updatedItems.splice(index, 1);
        }

        super.next(this.data);
    }

    public isNew(item: any): boolean {
        return !item.pilotProductID;
    }

    public hasChanges(): boolean {
        return Boolean(
            this.deletedItems.length ||
                this.updatedItems.length ||
                this.createdItems.length
        );
    }

    public saveChanges(plantID, buildStyleID, vaBuildID): void {
        if (!this.hasChanges()) {
            return;
        }

        const completed = [];
        if (this.deletedItems.length) {
        }

        if (this.updatedItems.length) {
            completed.push(
                this.dataService
                    .editModule(this.updatedItems)
                    .subscribe((res) => {
                        if (res) this.isSaved = true;
                        else this.isSaved = false;
                    })
            );
        }

        if (this.createdItems.length) {
        }

        this.reset();

        zip(...completed).subscribe(() =>
            this.read(plantID, buildStyleID, vaBuildID)
        );
    }

    public cancelChanges(): void {
        this.reset();

        this.data = this.originalData;
        this.originalData = cloneData(this.originalData);
        super.next(this.data);
    }

    public assignValues(target: any, source: any): void {
        Object.assign(target, source);
    }

    private reset() {
        this.data = [];
        this.deletedItems = [];
        this.updatedItems = [];
        this.createdItems = [];
    }

    private serializeModels(data?: any): string {
        return data ? `&models=${JSON.stringify(data)}` : "";
    }
}
