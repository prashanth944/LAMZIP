export class Shortages {
    public partNumber: string;
    public description: string;
    public qty: number;
    public supplies: string;
    public status: string;
    public dueDate: Date;
    public needDate: Date;
    public op: number;
}
