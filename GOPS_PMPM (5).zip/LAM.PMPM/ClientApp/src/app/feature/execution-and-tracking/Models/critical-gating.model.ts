export class CG {
    public pilotProductID: number;
    public pilotSerialNumber: string;
    public ben: string;
    public productionOrderNum: string;
    public urgency: string;
    public title: string;
    public issueDescription: string;
    public issueDescriptionWithoutTag: string;
    public expectedCloseDate: Date;
    public gatingDate: Date;
    public comments: string;
}
