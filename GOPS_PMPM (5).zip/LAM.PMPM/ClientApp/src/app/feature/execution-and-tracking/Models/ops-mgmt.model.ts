export class ModuleProcess {
    public moduleProcessID: number;
    public moduleProcess: string;
    public expanded = false;
}

export class Zones {
    public zoneID: number;
    public zoneDescription: string;
}

export class OpsMgmtPercent {
    public pilotProductID: number;
    public assemblyPercent: number;
    public testPercent: number;
    public postTestPercent: number;
}

export class Operations {
    public dayNightApproved: string;
    public modDayShiftOnly: boolean;
    public status: string;
    public opPercent: number;
    public description: string;
    public actualPlannedStartDate: Date;
    public calculatedFinish: Date;
    public stUpdatedBy: string;
    public calculatedStandardTimeDays: number;
    public averageCycleTimeHours: number;
    public totalCycleTimeHours: number;
    public totalReworkHours: number;
    public zoneID: number;
    public order: number;
    public hoursPerDay: number;
    public pilotProductID: number;
    public operationID: number;
    public manualOpPercent: number;
    public dayShiftOnly: boolean;
    public nightShiftOnly: boolean;
    public standardTimeHours: number;
    public stOverrideReason: string;
    public stUpdatedById: number;
}

export class OperationsList {
    public operations: Operations[];
}

export class OperationsForEngineers {
    public pilotProductID: number;
    public operationID: number;
    public status: string;
    public opPercent: number;
    public description: string;
    public actualPlannedStartDate: Date;
    public calculatedFinish: Date;
    public totalDirectHours: number;
    public totalRework: number;
    public totalInterrupt: number;
    public totalCycleTime: number;
    public zoneID: number;
    public calculatedStandardTimeDays: number;
    public order: number;
}

export class OpsManagementSubassembly {
    public PilotProductID: number;
    public AssemblyPercent: number;
    public TestPercent: number;
    public PostTestPercent: number;
    public SubassemblyBuildHours: number;
    public TestBuildHours: number;
    public ModuleProcessIdForSubassembly: number;
    public ModuleProcessIdForTest: number;
    public PilotMEApproved: boolean;
    public SOELink: string;
    public MfgApproved: boolean;
    public CA10ShortageFree: boolean;
    public PercentType: string;
    public inWIP: boolean;
}

export class OpsManagementEditModel {
    public pilotProductID: number;
    public assemblyPercent: number;
    public testPercent: number;
    public postTestPercent: number;
    public opsmgOperationEditFields: OperationsEditModel[];
}

export class OperationsEditModel {
    public pilotProductID: number;
    public operationID: number;
    public manualOpPercent: number;
    public dayShiftOnly: boolean;
    public nightShiftOnly: boolean;
    public standardTimeHours: number;
    public stOverrideReason: string;
    public stUpdatedById: number;
}
