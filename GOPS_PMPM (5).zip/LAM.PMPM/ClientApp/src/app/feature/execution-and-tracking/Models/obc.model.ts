export class OBCView {
    public status: string;
    public id: string;
    public partCost: number;
    public materialDescription: string;
    public lineItemNumber: string;
    public operation: string;
    public requiredQty: number;
    public withdrawnQty: number;
    public variance: number;
    public scrapVal: string;
    public longText: string;
    public completionDate: Date;
    public varianceType: string;
    public type: string;
    public recID: number;
}

export class OBCDetails {
    public obcadd: OBCView[];
    public obcrts: OBCView[];
}

export class IssueLogView {
    public status: string;
    public recID: number;
    public issueLog: string;
    public dateCreated: Date;
    public urgency: string;
    public issueType: string;
    public issueTitle: string;
    public part: string;
    public issueDetail: string;
    public issueDisposition: string;
    public statusforCount: string;
    public count: number;
    public divisionID: number;
    public divisionName: string;
}

export class NCIView {
    public status: string;
    public dateOpened: Date;
    public requestor: string;
    public title: string;
    public partNumber: string;
    public impact: string;
    public pom: string;
    public pomDescripton: string;
    public symptom: string;
    public symptomDetail: string;
    public id: number;
    public isClosed: string;
    public recID: number;
    public partDescription: string;
    public quantity: number;
    public reasonCode: string;
    public purchOrd: string;
    public creDate: Date;
    public lineDown: string;
    public investigationGroup: string;
    public investigationGroupDetail: string;
    public resolution: string;
}
