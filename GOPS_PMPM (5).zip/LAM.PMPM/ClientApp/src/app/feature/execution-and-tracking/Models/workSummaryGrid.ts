export class WorkSummaryGrid {
    StepRecordId: number;
    Id: number; //step no
    Complete: boolean;
    Skipped: boolean;
    ExcludedOption: boolean;

    Reworked: boolean; 

    completedBy: string;
    completedById: number;
    skippedById: number;
    excludedById: number;

    TechnicianNotes: string;

    numberofSteps: number;
    operationId: number;
    cycleTimeMinutes: number;
    pilotProductId: number;
}

export class WIPRelease {
    public pilotproductID: number;
    public buildSchedule: number;
    public actualLaunchDate: Date;
    public plannedLaunchDate: Date;
    public moduleColor: string;
    public targetTestDays: number;
    public chamberReleased: boolean;
    public subFrameReleased: boolean;
    public enclosureReleased: boolean;
    public topPlateReleased: boolean;
    public wipPriority: string;
    public isLaunched: boolean;
    public dayShiftOnly: boolean;
    public countOfShortages: number;
    public buildStyle: string;
    public buildStyleID: number;
    public buildType: string;
    public buildTypeID: number;
    public beNorPSNReconfiguredFrom: string;
    public reworkPO: string;
    public addPO: string;
    public deletePO: string;
    public currentPartNumber: string;
    public newPartNumber: string;
    public buildingID: number;
    public chamberReleasedDays: number;
    public subFrameReleasedDays: number;
    public enclosureReleasedDays: number;
    public topPlateReleasedDays: number;
    public moduleVFDs: ModuleVFD[];
    public processModule: number;
    public modifiedOn: Date;
    public modifiedBy: number;
}

export class SOELink {
    url: string;
}

export class ModuleVFD {
    public moduleVFDId: number;
    public pilotProductId: number;
    public vfdZoneId: number;
    public statusId: number;
    public bayName: string;
    public assignable: boolean;
    public numberOfDays: number;
    public vfdZoneName: string;
    public isRequired: boolean;
}
