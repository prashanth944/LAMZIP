import { List } from "@amcharts/amcharts4/core";

export class Cause {
    public auditCauseId?: number;
    public optionName: string;
}

export class Category {
    public auditCategoryId?: number;
    public optionName: string;
}

export class AuditItem {
    public auditItemId?: number;
    public description?: string;
    public auditCategoryID?: number;
    public auditCauseID?: number;
    public pilotProductID?: number;
    public createdOn?: Date;
    public zoneID?: number;
    public userId?: number;
    public operationID?: number;
}

export class Item {
    public auditCategory?: string;
    public auditCause?: string;
    public action?: string;
    public isOpen?: boolean;
    public operationDescription?: string;
    public zoneDescription?: string;
    public zoneName?: string;
    public workRecordID?: number;
    public userId?: number;
    public beforePicture?: [];
    public afterPicture?: [];
    public tempBeforePicture?: [];
    public tempAfterPicture?: [];
    public startTimestamp?: string;
    public auditItemId?: number;
    public description?: string;
    public auditCategoryID?: number;
    public auditCauseID?: number;
    public pilotProductID?: number;
    public zoneID?: number;
    public operationID?: number;
}

export class AuditOp {
    public open: List<Item>;
    public close: List<Item>;
    public workRecordID?: number;
    public userId?: number;
}
