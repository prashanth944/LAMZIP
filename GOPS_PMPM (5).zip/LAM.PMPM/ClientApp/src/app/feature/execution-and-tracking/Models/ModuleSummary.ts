import { ModuleVFD } from "./workSummaryGrid";

export interface ModuleSummary {
  ModuleInfo: {
    PO: string;
    SO: string;
    BOMItem: string;
    BEN: string;
    FCID: string;
    ProductType: string;
    PilotSerialNumber: string;
    PilotProductID: number;
    Active: number;
    CommitLaunch: Date;
    WIPFlag: boolean;
    BuildStyleId: number;
    BuildStyle: string;
    FremontID: string;
    IsWorkedOn: boolean;
  };
  Zones: {
    ZoneDescription: string;
    Progress: number;
    ZoneID: number;
    ModuleProcess: string;
    ModuleProcessID: number;
    ZoneOrder: number;
  }[];
  Integration: number;
  SubAssemblyPercentage: number;
  IntegrationPercentage: number;
  TestPercentage: number;
  PostTestPercentage: number;
  ModuleProcess: string;
}

export class EditModuleViewModel {
  public ben: string;
  public mpsName: string;
  public toolTypeName: string;
  public recordType: string;
  public revenueCode: string;
  public capacityPlanningColor: string;
  public pilotProductID: number;
  public toolTypeID: number;
  public buildTypeID: number;
  public buildStyleId: number;
  public buildStyle: string;
  public pilotSerialNumber: string;
  public fcid: string;
  public pilotRiskLevel: string;
  public buildTypeName: string;
  public productionStatus: string;
  public productGroupId: number;
  public productName: string;
  public customer: string;
  public productManager: string;
  public programManager: string;
  public systemProjectManager: string;
  public manufacturingEngineer: string;
  public testEngineertoolTypeID: string;
  public note: string;
  public scheduler: string;
  public purchaseOrderNumber: string;
  public salesOrderNumber: string;
  public bomNumber: string;
  public status: string;
  public testEngineer: string;
  public pilotToolType: string;
  public fremontID: number;
  public testDate: Date;
  public inWIP: boolean;
  public divisionName: string;
  public divisionID: number;

  public po: string;
  public partNumber: string;
  public serialNum: string;
  public qty: number;
  public demandTypeID: number;
  public partDescription: string;
  public pcwoReleased: boolean;
  public hot: boolean;
  public rework: boolean;
  public spclProcess: boolean;
  public plannerName: string;
  public engineeringPOC: string;
  public techBuild: string;
  public techTest: string;
  public auditor: string;
  public beNorPSNReconfiguredFrom: string;
  public processModule: number;
  public modifiedOn: Date;
  public modifiedBy: number;
}

export class CustomerViewModel {
  public customer: string;
  public productionStatus: string;
}

export class ModulesSummaryWip {
  public pilotProductID: number;
  public pilotRisk: string;
  public comments: string;
  public status: string;
  public wipPriority: string;
}

export class WorkRecordViewModel {
  public UserId: number;
  public PilotProductID: number;
  public OperationId: number;
  public StartDateTime: Date;
  public EndDateTime: Date;
  public EndOrResume: boolean;
  public IsRework: boolean;
}

export class OperationViewModel {
  public OPSDescription: string;
  public UserId?: number;
  public PilotProductID?: number;
  public OperationId?: number;
  public numberOfSteps?: number;
  public CycleTimeHours?: number;
  public OPPercent?: number;
  public ModuleProcess: string;
  public ZoneDescription: string;
  public Action: string;
  public WorkRecordId?: number;
  public StepsCompleteTime?: number;
  public TotalStepsTime?: number;
  public ZoneId?: number;
  public ModuleProcessId?: number;
}

export class OperationPercentViewModel {
  public moduleProcess?: string;
  public percent?: number;
}

export class StepDetail {
  public stepRecordId: number;
  public stepNo: number;
  public completed: boolean;
  public skipped: boolean;
  public excluded: boolean;
  public completedBy: string;
  public completedById: number;
  public reworkedById: number;
  public skippedById: number;
  public excludedById: number;
  public technicianNotes: string;
  public numberofSteps: number;
  public operationId: number;
  public cycleTimeMinutes: number;
  public pilotProductId: number;
  public reworked: boolean;
  public reworkedBy: string;
  public isOnlyTechNote = false;
}

export class LogProgressView {
  public stepNo: number;
  public completed: number;
  public skipped: number;
  public excluded: number;
  public userID: number;
  public technicianNote: string;
}
export class OperationLogDetail {
  public operationId: number;
  public description: string;
  public cycleTimeMinutes: number;
  public originalStartTime: string;
  public startTime: string;
  public endTime: string;
  public isRunning: boolean;
  public isInterrupted: boolean;
  public latestInterruptionTime: string;
  public totalInterruptionMinutes: number;
  public totalInterruptionSeconds: number;
  public numberOfSteps: number;
  public workRecordId: number;
  public soeLink: string;
  public pilotSerialNumber: string;
  public ben: string;
  public beforePicture: Array<string> = null;
  public afterPicture: Array<string> = null;
  public buildStyleID: number;
  public buildStyleName: string;
}
export class OperationLogDetailGeneral {
  public description: string;
  public minStartTime: string;
  public lastEndTime: string;
  public totalInterruptionMinutes: number;
  public totalDurationMinutes: number;
  public pilotSerialNumber: string;
  public ben: string;
}

export class StandardTimeExceptionViewModel {
  public standardTimeExceptionCategoryId: number;
  public optionName: string;
}

export class LogWorkRecordViewModel {
  public StandardTimeExceptionCategoryId?: number;
  public WorkRecordId?: number;
  public Notes: string;
  public EndTime: Date;
}

export class ReworkCategoryViewModel {
  public id: number;
  public category: string;
}

export class ReworkWorkRecordViewModel {
  public WorkRecordId?: number;
  public IsOBC?: number;
  public PilotOrSupplier: string;
  public ReworkCategoryId?: number;
  public ReworkDescription: string;
  public EndTime?: Date;
}

export class ReworkCauseViewModel {
  public OBC: boolean;
  public Pilot?: string;
  public selectedReworkCategory?: number;
  public description?: string;
  public reworkFormError: boolean;
  public missingReworkNote: boolean;
  public PilotOrSupplier?: string;
  public ReworkCategoryId?: number;
}

export class Zones {
  ModuleProcess: string;
  ModuleProcessID: number;
  Progress: number;
  ZoneDescription: string;
  ZoneID: number;
  ZoneOrder: number;
}
export class EditModuleAdminViewModel {
  public pilotProductID: number;
  public pilotSerialNumber: string;
  public buildPlanPacketLoaded: boolean;
  public code: string;
  public pom: string;
  public chamberReleased: boolean;
  public subFrameReleased: boolean;
  public enclosureReleased: boolean;
  public topPlateReleased: boolean;
  public status: string;
  public productionStatus: string;
  public inWip: boolean;
}

export class BayName {
  bayName: string;
}
export class EditModuleAdminViewModelStandard {
  public pilotProductId: number;
  public moduleVFDs: ModuleVFD[];
}
export class EditModuleAdminVFDAssignmentTable {
  public pilotProductID: number;
  public vfdZoneID: number;
  public zoneName: string;
  public vfdStatusID: number;
  public status: string;
  public bayName: string;
  public assignable: boolean;
  public isAssignable: boolean;
  public capacityPlanningColor: string;
}

export class VFDRelease {
  public vfdZoneId: number;
  public vfdZoneName: string;
}

export class SerializationNumbers {
  public serializationNumberToolsID: number;
  public category: string;
  public zone: string;
  public toolName: string;
  public active: boolean;
  public partNum: string;
  public serialNum: string;
}

export class SerialNumbers {
  public serialNumbers: SerializationNumbers[];
}

export class SerializationRequest {
  public serializationNumberToolsID: number;
  public pilotproductid: number;
  public partNum: string;
  public serialNum: string;
}


export class Reconfig {
  public partNumber: string;
  public description: string;
  public qty: number;
  public qtyAdded: number;
  public technicianComments: string;
  public status: string;
  public statusId: number;
  public addOrRTSProdOrder: string;
}

export class ReconfigData {
  public reconfig: Reconfig[];
  public prodOrderCount: number;
}

export class ReconfigEditFields {
  public addOrRTSProdOrder: string;
  public partNumber: string;
  public qtyAddedReturned: number;
  public status: number;
  public technicianComments: string;
}

export class ReconfigStatus {
  public statusId: number;
  public status: string;
}
