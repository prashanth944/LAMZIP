export class MTT {
    public partNumber: string;
    public partDescription: string;
    public quantity: number;
    public reasonCode: string;
    public status: string;
    public purchOrd: string;
    public creDate: number;
    public recID: number;
    public technicianNotes: string;
    public addorRemoved: string;
    public mttNo;
}
