export class SafetyLinedown {
  public serialNo: string;
  public status: string;
  public urgency: string;
  public issueLogNum: string;
  public ben: string;
  public issueTitle: string;
  public dateCreated: Date;
  public issueType: string;
  public productDesignCategory: string;
  public toolSerial: string;
  public pilotProductID: number;
}
