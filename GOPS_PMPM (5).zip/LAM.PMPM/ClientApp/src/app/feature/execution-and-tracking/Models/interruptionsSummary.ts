export class InterruptionsSummary {
    interruptionCategoryId: number;
    interruptionCategory: string;
    notes: string;
    interruptTime: number;
}

export class InterruptionsInfo {
    category: string;
    userName: string;
    interruptionStartTime: string;
    interruptionEndTime: string;
    interruptionMinutes: number;
    notes: string;
}

export class InterruptionModel {
    public operationId: number;
    public pilotProductId: number;
    public userId: number;
    public interruptionStartTime: Date;
    public interruptionEndTime: Date;
    public workRecordId: number;
    public notes: string;
    public interruptionCategoryId: number;
}

export class InterruptionCategory {
    public interruptionCategoryId: number;
    public optionName: string;
}
