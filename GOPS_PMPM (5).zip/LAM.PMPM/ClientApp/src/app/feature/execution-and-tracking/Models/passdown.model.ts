import { Item } from "../../model/item";

export class PassdownTabs {
    public zoneId: number;
    public tabName: string;
    public orders: number;
}
export class OperationDetail {
    public operationId: number;
    public description: string;
}
export class PassdownOperation {
    public operationId: number;
    public description: string;
    public isComplete: boolean;
}

export class PassdownOperationStep {
    public operationId: number;
    public description: string;
    public skippedStepNumber: number;
}
export class PassdownRework {
    public operationId: number;
    public description: string;
    public reworkDescription: string;
}
export class PassdownAuditItem {
    public auditItemId: number;
    public description: string;
}

export class PassdownZoneOperationDetail {
    public completedPassdownOperations: PassdownOperation[];
    public progressedPassdownOperations: PassdownOperation[];
    public passdownOperationSteps: PassdownOperationStep[];
    public passdownAuditItems: PassdownAuditItem[];
    public nextOperationsToComplete: OperationDetail[];
    public passdownReworks: PassdownRework[];
    public zoneNotes: string;
    public otherTasksToComplete: string;
    public nextOperationToCompleteId: number;
    public passdownZoneOperationDetailId: number;
}
export class PassdownLOTO {
    public passdownLOTOId: number;
    public facilityLock: boolean;
    public lotoFacilityLock: Item;
    public description: string;
    public reasonForLOTO: string;
    public createdById: number;
    public createdBy: string;
    public passdownId: number;
}

export class PassdownTOI {
    public toiId: number;
    public criticalOrGating: string;
    public title: string;
    public issueDescription: string;
    public comments: string;
    public statusID: number;
    public isOpen: boolean;
    public issueDescriptionWithoutTag: string;
}

export class PassdownIssueLog {
    public dateModified: Date;
    public issueTitle: string;
    public recID: number;
    public issueLogNum: string;
    public status: string;
}

export class PassdownNCI {
    public title: string;
    public status: string;
    public isClosed: boolean;
    public iqmsId: number;
}

export class PassdownOBC {
    public recID: number;
    public lineItemNumber: string;
    public type: string;
    public longText: string;
    public isOpen: string;
}

export class BuildStyleDetail {
    public buildStyleId: number;
    public buildStyle: string;
}

export class PassdownActionItemsDetail {
    public passdownLOTOs: PassdownLOTO[];
    public openCriticalGatingTOIs: PassdownTOI[];
    public openTOIs: PassdownTOI[];
    public closeTOIs: PassdownTOI[];
    public passdownIssueLogs: PassdownIssueLog[];
    public openNCIs: PassdownNCI[];
    public closedNCIs: PassdownNCI[];
    public openOBCs: PassdownOBC[];
    public closedOBCs: PassdownOBC[];
    public buildStyleDetail: BuildStyleDetail;
    public editButtonDetail: EditButtonDetail;
}

export class EditButtonDetail {
    public isEditable: boolean;
}

export class PassdownAssemblyOperationDetail {
    public opCompleted: string;
    public opProgressed: string;
    public opSkipped: string;
    public nextSteps: string;
    public rework: string;
    public notes: string;
    public passdownAuditItems: PassdownAuditItem[];
    public passdownAssemblyId: number;
    public passdownId: number;
}

export class PassdownTestDetail {
    public opCompleted: string;
    public opProgressed: string;
    public opSkipped: string;
    public nextSteps: string;
    public specialInstructions: string;
    public notes: string;
    public passdownId: number;
    public passdownTestId: number;
}

export class Passdown {
    public passdownId: number;
    public passdownDate: Date;
    public pilotProductId: number;
    public shiftId: number;
    public createdById: number;
    public createdOn: Date;
    public modifiedById: number;
    public modifiedOn: Date;
}

export class PassdownZoneOperationTextDetail {
    public passdownZoneOperationDetailId: number;
    public passdownId: number;
    public zoneId: number;
    public zone: string;
    public zoneNotes: string;
    public otherTasksToComplete: string;
    public nextOperationToCompleteId: number;
    public nextStepOpsData: Item;
    public nextOpToComplete: string;
}

export class PassdownGenerateOrEdit {
    public passdownId: number;
    public passdownDate: Date;
    public pilotProductId: number;
    public shiftId: number;
    public createdById: number;
    public createdOn: Date;
    public modifiedById: number;
    public modifiedOn: Date;
    public passdownLOTOs: PassdownLOTO[];
    public passdownZoneOperationTextDetails: PassdownZoneOperationTextDetail[];
    public passdownAssemblyOperationDetail: PassdownAssemblyOperationDetail;
    public passdownTestDetail: PassdownTestDetail;
}

export class ModulePassdown {
    public ben: string;
    public createdBy: string;
    public createdById: number;
    public createdOn: Date;
    public modifiedById: number;
    public modifiedOn: Date;
    public passdownDate: Date;
    public passdownId: number;
    public pilotProductId: number;
    public pilotSerialNumber: string;
    public productName: string;
    public shiftId: number;
    public shiftType: string;
    public toolTypeName: string;
    public isEditable: boolean;
    public isExpand: boolean;
}

export class PassdownZoneOperationDetailWithZone {
    public zoneId: number;
    public zone: string;
    public completedPassdownOperations: PassdownOperation[];
    public progressedPassdownOperations: PassdownOperation[];
    public passdownOperationSteps: PassdownOperationStep[];
    public passdownAuditItems: PassdownAuditItem[];
    public passdownReworks: PassdownRework[];
    public passdownZoneOperationTextDetails: PassdownZoneOperationTextDetail[];
}

export class PassdownModuleProcess {
    public moduleProcess: string;
    public passdownZoneOperationDetailWithZones: PassdownZoneOperationDetailWithZone[];
}

export class PassdownAssemblyOperationAuditItemsDetail {
    public opCompleted: string;
    public opProgressed: string;
    public opSkipped: string;
    public nextSteps: string;
    public rework: string;
    public notes: string;
    public passdownAuditItems: PassdownAuditItem[];
    public passdownAssemblyId: number;
    public passdownId: number;
}

export class PassdownDisplay {
    public issues: PassdownActionItemsDetail;
    public moduleProcesses: PassdownModuleProcess[];
    public passdownAssemblyOperationAuditItemsDetail: PassdownAssemblyOperationAuditItemsDetail;
    public passdownTestDetail: PassdownTestDetail;
}
