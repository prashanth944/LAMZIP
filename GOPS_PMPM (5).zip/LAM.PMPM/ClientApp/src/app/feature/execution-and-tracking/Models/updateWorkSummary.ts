export class UpdateWorkSummary {
    stepRecordId: number;
    stepNo: number; 
    completed: boolean;
    skipped: boolean;
    excluded: boolean;

    completedBy: string;
    completedById: number;
    skippedById: number;
    excludedById: number;

    technicianNotes: string;

    numberofSteps: number;
    operationId: number;
    cycleTimeMinutes: number;
    pilotProductId: number;
}
