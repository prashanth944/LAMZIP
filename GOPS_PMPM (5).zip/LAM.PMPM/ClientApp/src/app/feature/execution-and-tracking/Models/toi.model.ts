export class TOI {
    public toiid: number;
    public pilotProductID: number;
    public ben: string;
    public title: string;
    public issueDescription: string;
    public statusID: number;
    public status: string;
    public isCritical: boolean;
    public isGating: boolean;
    public comments: string;
    public files: string[];
    public expectedCloseDate: Date;
    public gatingDate: Date;
    public criticalGating: string;
    public zoneID: number;
    public zoneName: string;
    public issueDescriptionWithoutTag: string;
    public pilotSerialNumber: string;
    public createdOnDate: Date;
    public updatedOnDate: Date;
    public createdBy: string;
    public createdById: number;
    public updatedBy: string;
    public updatedById: number;
}
export class TOIDashboard {
    public toiid: number;
    public pilotProductID: number;
    public ben: string;
    public title: string;
    public issueDescription: string;
    public statusID: number;
    public status: string;
    public isCritical: boolean;
    public isGating: boolean;
    public comments: string;
    public files: string[];
    public expectedCloseDate: string;
    public gatingDate: Date;
    public criticalGating: string;
    public zoneID: number;
    public zoneName: string;
    public issueDescriptionWithoutTag: string;
    public pilotSerialNumber: string;
    public createdOnDate: string;
    public updatedOnDate: string;
}
export class ZoneValueViewModel {
    public zoneID: number;
    public description: string;
    public pilotProductID: number;
}
