export const route = {
  getToolType: "/Bays/GetToolType",
  getModuleData: "/EditModule/GetMyModuleSummary/",
  getModuleColor: "/EditModuleHome/GetModuleColorDDL",
  getCustomer: "/EditModuleHome/GetCustomerDDL",
  getPilotRisk: "/EditModuleHome/GetPilotRiskDDL",
  getProductionStatus: "/EditModuleHome/GetProductionStatusDDL",
  updateModule: "/EditModule/UpdateMyModule",
  resetStaffPriority: "/Modules/resetstaffpriority/",

  getOperationsModule: "/EditModule/getmymoduleoperation",
  updateWorkRecord: "/EditModule/UpdateWorkRecord",
  updateOperation: "/EditModule/updateoperatonbyid",
  updateoperatonbyid: "/EditModule/updateoperatonbyid",
  updateauditcomplete: "/EditModule/updateauditcomplete/",
  getLogProgress: "/Log/GetLogProgress",
  getstepsdetails: "/Log/getstepsdetails/",
  updatesteprecord: "/Log/updatesteprecord",
  updateallsteprecord: "/Log/updateallsteprecord",

  getoperationlogdetails: "/Log/getoperationlogdetails/",
  getoperationlogdetailsGeneral: "/Log/getoperationlogdetailsGeneral/",
  getoperationpercent: "/EditModule/getoperationpercent/",

  getinterrupts: "/Log/getinterrupts/",
  getinterruptsByOperations: "/Log/GetInterruptsByOperationAndPPId/",
  deleteinterruption: "/Log/deleteinterruption/",
  getinterruptioncategory: "/Log/getinterruptioncategory",
  updateinterruption: "/Log/updateinterruption",

  getstandardtimeexceptioncategory: "/Log/getstandardtimeexceptioncategory",
  updateLogworkrecord: "/Log/updateworkrecord/",
  logoperationdelete: "/Log/logoperationdelete/",

  getRunningOperation: "/User/GetRunningOperation/",
  getBuildStyleDDL: "/Modules/GetBuildStyleDDL",

  getModuleInfoTag: "/Modules/GetModuleInfoTag/",

  //Rework
  getreworkcategory: "/Log/getreworkcategory",
  getstepsdetailsrework: "/Log/getstepsdetailsrework/",
  updateReworkWorkrecord: "/Log/updateworkrecordrework/",
  updatesteprecordrework: "/Log/updatesteprecordrework",
  uploadreworkfile: "/Log/uploadreworkfile/",
  downloadfile: "/Log/downloadfile/",
  deletereworkfile: "/Log/deletereworkfile/",
  getworkrecordrework: "/Log/getworkrecordrework/",
  getworkrecordreworkbyguid: "/Log/getworkrecordreworkbyguid/",

  //Edit Mod-Rework logs
  getreworklog: "/EditModule/getreworklog/",

  //Home pages
  getBuildScheduleDDL: "/Modules/GetBuildScheduleDDL",
  AddWIPRelease: "/HomeRole/AddWIPRelease/",
  getHomeSupLaborHours: "/HomeRole/GetHomeSupLaborHours/",
  getWIPRelease: "/HomeRole/GetWIPRelease/",
  getSOELink: "/Log/GetSOELink/",
  getSOELinkFileExtension: "/Log/GetSOELinkFileExtension/",
  updateSOELinkFileExtension: "/Log/UpdateSOELinkFileExtension/",
  getWIPStaffingMax: "/HomeRole/GetWIPStaffingMax/",

  //TOI
  addTOI: "/TOI/AddTOI",
  getTOIStatus: "/TOI/GetTOIStatus",
  getTOIView: "/TOI/GetTOIView/",
  gettoidetails: "/TOI/gettoidetails/",
  getEditModScheduledSummary: "/EditModuleHome/GetEditModScheduledSummary",
  getMissCategoryDDL: "/EditModuleHome/GetMissCategoryDDL",
  updateModScheduleSummary: "/EditModuleHome/UpdateModScheduleSummary",
  GetTOIZone: "/TOI/GetTOIZone/",
  uploadTOIfile: "/TOI/uploadTOIfile/",
  deleteTOIfile: "/TOI/deleteTOIfile/",

  // Audit Op
  getauditcause: "/AuditItem/getauditcause",
  getauditcategory: "/AuditItem/getauditcategory",
  createaudititem: "/AuditItem/createaudititem",
  uploadauditfile: "/AuditItem/uploadauditfile/",
  getauditopdetails: "/AuditItem/getauditopdetails/",
  deleteauditfile: "/AuditItem/deleteauditfile/",
  downloadauditfile: "/AuditItem/downloadfile",

  //Admin
  getEditModuleAdminSummary: "/EditModule/GetEditModuleAdminSummary/",
  getVFDAssignmentTable: "/EditModule/GetVFDAssignmentTable/",
  getVFDAssignmentStatusDLL: "/EditModule/GetVFDAssignmentStatusDLL",
  getVFDAssignmentBayDLL: "/EditModule/GetVFDAssignmentBayDLL",
  updateEditModAdmin: "/EditModule/UpdateEditModAdmin",
  updateEditModAdminVFDAssignment:
    "/EditModule/UpdateEditModAdminVFDAssignment",

  //Action Items
  getauditopdetailsbyzone: "/AuditItem/getauditopdetailsbyzone/",
  getOBCDetails: "/ActionItems/GetOBCDetails/",
  getRTSDetails: "/ActionItems/GetRTSDetails/",
  getMTTDetails: "/ActionItems/GetMTTDetails/",
  getMTTStatusDLL: "/ActionItems/GetMTTStatusDLL",
  getMTTAddRemoveDLL: "/ActionItems/GetMTTAddRemoveDLL",
  updateMTTData: "/ActionItems/UpdateMTTData",
  updateRTSStatus: "/ActionItems/UpdateRTSStatus",
  getIssueLogStatusCount: "/ActionItems/GetIssueLogStatusCount/",
  getIssueLogDetails: "/ActionItems/GetIssueLogDetails/",
  getNCIDetails: "/ActionItems/GetNCIDetails/",
  getShortagesDetails: "/ActionItems/GetShortagesDetails/",
  getpassdowntabs: "/Passdown/getpassdowntabs/",
  getzonedetails: "/Passdown/getzonedetails/",
  getactionitems: "/Passdown/getactionitems/",
  getassemblyoperations: "/Passdown/getassemblyoperations/",
  gettest: "/Passdown/gettest/",
  createpassdown: "/Passdown/createpassdown/",
  getpassdowns: "/Passdown/getpassdowns/",
  editpassdown: "/Passdown/editpassdown/",
  getdisplaypassdown: "/Passdown/getdisplaypassdown/",

  //WIP report
  sendWIPEmail: "/Modules/sendwipemail/",
  getBuilding: "/Bays/GetBuilding",

  //Edit Mod-Ops Mgmt
  getOpMgmtData: "/EditModule/getopmgdata/",
  getOpMgmtDataForEngineers: "/EditModule/getopmgengineerdata/",
  updateOpsMgmtData: "/EditModule/updateopsmgmt",
  getPercent: "/EditModule/getpercent/",

  //Home-pages
  getCriticalGating: "/HomeRole/GetCriticalGating/",
  getSafetyAndLineDown: "/HomeRole/GetSafetyAndLineDown/",

  //subassembly
  getScheduleSubassembly: "/EditModule/GetScheduleSubassembly/",
  updateScheduleSubassembly: "/EditModule/UpdateScheduleSubassembly",
  getOpsManagementSubassembly: "/EditModule/GetOpsManagementSubassembly/",
  updateOpsManagementSubassembly: "/EditModule/UpdateOpsManagementSubassembly",
  getbuilding: "/LaborHour/getbuilding/",
  getvfdreleases: "/HomeRole/getvfdreleases/",
  getmodulereleases: "/EditModule/getmodulereleases/",
  getpassdownbutton: "/Passdown/getpassdownbutton/",
  getSerializationNumbers: "/Modules/getSerializationNumbers/",
  updateSerializationNumbers: "/Modules/updateSerializationNumbers",
  getModuleSummary: "/EditModule/GetMyModuleSummary/",

  // S.A.F.E.
  getModuleVFDSummary: "/EditModule/GetModuleVFDSummary/",

  //Reconfig
  getReconfig: '/EditModuleHome/getReconfig/',
  getReconfigDelete: '/EditModuleHome/getReconfigDelete/',
  updateReconfig: '/EditModuleHome/updateReconfig',
  getReconfigStatus: '/EditModuleHome/getReconfigStatus',
};
