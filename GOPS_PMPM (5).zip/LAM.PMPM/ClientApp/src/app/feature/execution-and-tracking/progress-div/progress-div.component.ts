import { Component, Input } from "@angular/core";
import { LabelSettings } from "@progress/kendo-angular-progressbar";

@Component({
    selector: "pmpm-progress-div",
    templateUrl: "./progress-div.component.html",
    styleUrls: ["./progress-div.component.css"],
})
export class ProgressDivComponent {
    @Input() zoneList: any;
    public labelText = "N/A";
    constructor() {}

    public labelSettings: LabelSettings = {
        position: "end",
        format: () => this.labelText,
    };
}
