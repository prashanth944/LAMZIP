import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { environment } from "../../../environments/environment.dev_server";
import {
  CustomerViewModel,
  EditModuleViewModel,
  ModulesSummaryWip,
  ModuleSummary,
  OperationViewModel,
  WorkRecordViewModel,
  OperationPercentViewModel,
  StepDetail,
  LogProgressView,
  OperationLogDetail,
  ReworkCategoryViewModel,
  ReworkWorkRecordViewModel,
  EditModuleAdminViewModel,
  BayName,
  EditModuleAdminViewModelStandard,
  EditModuleAdminVFDAssignmentTable,
  OperationLogDetailGeneral,
  VFDRelease,
  SerialNumbers,
  SerializationRequest,
  Reconfig,
  ReconfigEditFields,
  ReconfigStatus,
  ReconfigData,
} from "./Models/ModuleSummary";
import { Observable, throwError } from "rxjs";
import {
  BuildType,
  LaborManagementProductGroupViewModel,
} from "../capacity-planning/adjust-capacity/labor/model/labor.model";
import { routes } from "../capacity-planning/adjust-capacity/labor/model/routes";
import { MasterRecords } from "../capacity-planning/adjust-capacity/bay/models/MasterRecords";
import { route } from "./Models/routes";
import {
  InterruptionCategory,
  InterruptionModel,
  InterruptionsInfo,
  InterruptionsSummary,
} from "./Models/interruptionsSummary";
import { ModuleVFD, SOELink, WIPRelease } from "./Models/workSummaryGrid";
import { TOI, ZoneValueViewModel } from "./Models/toi.model";
import { EditModSched, EditModSchedSubassembly } from "./Models/editModSched";
import { AuditItem, Category, Cause } from "./Models/audit.model";
import { IssueLogView, NCIView, OBCDetails, OBCView } from "./Models/obc.model";
import { MTT } from "./Models/mtt.model";
import { Shortages } from "./Models/shortages.model";
import {
  ModulePassdown,
  PassdownActionItemsDetail,
  PassdownAssemblyOperationDetail,
  PassdownDisplay,
  PassdownGenerateOrEdit,
  PassdownTabs,
  PassdownTestDetail,
  PassdownZoneOperationDetail,
} from "./Models/passdown.model";
import {
  OpsManagementSubassembly,
  OpsMgmtPercent,
} from "./Models/ops-mgmt.model";
import { CG } from "./Models/critical-gating.model";
import { SafetyLinedown } from "./Models/safety-linedown.model";
import { Building } from "../labor-hour-tracking/models/verify-labor-hours.model";

@Injectable({
  providedIn: "root",
})
export class DataServiceEandTService {
  constructor(private http: HttpClient) { }

  readonly apiUrl = `${environment.apiUrl}`;

  getModule(plantID: number, date: Date) {
    return this.http.get<any[]>(
      this.apiUrl + "/Modules/GetModuleWip/" + plantID + "/" + date
    );
  }

  editModule(ArrData: any[]) {
    return this.http.put<any>(
      this.apiUrl + "/Modules/UpdateModuleWip",
      ArrData
    );
  }

  SetModuleWIPFlat(ArrData: any) {
    return this.http.put<any>(
      this.apiUrl + "/Modules/UpdateModuleWIPFlat",
      ArrData
    );
  }

  getModuleSummary(plantID: number, userID: number) {
    return this.http.get<ModuleSummary[]>(
      this.apiUrl + "/Modules/GetModuleSummary/" + plantID + "/" + userID
    );
  }
  getModuleSummaryByID(pilotProductID: number) {
    return this.http.get<ModuleSummary[]>(
      this.apiUrl + "/Modules/GetModuleSummaryByID/" + pilotProductID
    );
  }

  getModuleSummaryInfoOnly(plantID: number) {
    return this.http.get<ModuleSummary[]>(
      this.apiUrl + "/Modules/GetModuleSummaryInfoOnly/" + plantID
    );
  }
  GetBuildType(plantID: number): Observable<BuildType[]> {
    return new Observable<BuildType[]>((observer) => {
      this.http
        .get<BuildType[]>(
          `${environment.apiUrl}${routes.getBuildType}` + plantID
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  GetProductTypeDDL(
    plantId: number
  ): Observable<LaborManagementProductGroupViewModel[]> {
    return new Observable<LaborManagementProductGroupViewModel[]>(
      (observer) => {
        this.http
          .get<LaborManagementProductGroupViewModel[]>(
            `${environment.apiUrl}${routes.getProductTypeDDL}` +
            plantId
          )
          .subscribe((res) => {
            observer.next(res);
          });
      }
    );
  }

  getToolTypeDDL(): Observable<any[]> {
    return new Observable<any[]>((observer) => {
      this.http
        .get<any[]>(`${environment.apiUrl}${route.getToolType}`)
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  getMyModuleSummary(
    pilotProductID: number
  ): Observable<EditModuleViewModel> {
    return new Observable<EditModuleViewModel>((observer) => {
      this.http
        .get<EditModuleViewModel>(
          `${environment.apiUrl}${route.getModuleData}` +
          pilotProductID
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  getModuleVFDSummary(pilotProductID: number) {
    return this.http.get<ModuleVFD[]>(`${environment.apiUrl}${route.getModuleVFDSummary}` + pilotProductID);
  }

  getModuleInfoForTag(
    pilotProductID: number,
    plantId: number,
    todaydate: Date
  ): Observable<any> {
    return new Observable<any>((observer) => {
      this.http
        .get<any>(
          `${environment.apiUrl}${route.getModuleInfoTag}` +
          pilotProductID +
          "/" +
          plantId +
          "/" +
          todaydate
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }
  getModuleColorDDL(): Observable<MasterRecords[]> {
    return new Observable<MasterRecords[]>((observer) => {
      this.http
        .get<MasterRecords[]>(
          `${environment.apiUrl}${route.getModuleColor}`
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }
  getCustomerDDL(): Observable<CustomerViewModel[]> {
    return new Observable<CustomerViewModel[]>((observer) => {
      this.http
        .get<CustomerViewModel[]>(
          `${environment.apiUrl}${route.getCustomer}`
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }
  getPilotRiskDDL(): Observable<ModulesSummaryWip[]> {
    return new Observable<ModulesSummaryWip[]>((observer) => {
      this.http
        .get<ModulesSummaryWip[]>(
          `${environment.apiUrl}${route.getPilotRisk}`
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }
  getProductionStatusDDL(): Observable<CustomerViewModel[]> {
    return new Observable<CustomerViewModel[]>((observer) => {
      this.http
        .get<CustomerViewModel[]>(
          `${environment.apiUrl}${route.getProductionStatus}`
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }
  getEditModScheduledSummary(
    pilotProductID: number,
    plantID: number,
    todaydate: Date
  ): Observable<any> {
    return new Observable<any>((observer) => {
      this.http
        .get<any>(
          `${environment.apiUrl}${route.getEditModScheduledSummary}` +
          "?pilotProductID=" +
          pilotProductID +
          "&plantID=" +
          plantID +
          "&todaydate=" +
          todaydate
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  getScheduleSubassembly(pilotProductID: number): Observable<any> {
    return new Observable<any>((observer) => {
      this.http
        .get<any>(
          `${environment.apiUrl}${route.getScheduleSubassembly}` +
          pilotProductID
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  getOpsManagementSubassembly(pilotProductID: number): Observable<any> {
    return new Observable<any>((observer) => {
      this.http
        .get<any>(
          `${environment.apiUrl}${route.getOpsManagementSubassembly}` +
          pilotProductID
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  getMissCategoryDDL(): Observable<MasterRecords[]> {
    return new Observable<MasterRecords[]>((observer) => {
      this.http
        .get<MasterRecords[]>(
          `${environment.apiUrl}${route.getMissCategoryDDL}`
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }
  updateModScheduleSummary(request: EditModSched): Observable<number> {
    return new Observable<number>((observer) => {
      this.http
        .put<number>(
          `${environment.apiUrl}${route.updateModScheduleSummary}`,
          request
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }
  updateScheduleSubassembly(
    request: EditModSchedSubassembly
  ): Observable<number> {
    return new Observable<number>((observer) => {
      this.http
        .put<number>(
          `${environment.apiUrl}${route.updateScheduleSubassembly}`,
          request
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }
  updateOpsManagementSubassembly(
    request: OpsManagementSubassembly
  ): Observable<number> {
    return new Observable<number>((observer) => {
      this.http
        .put<number>(
          `${environment.apiUrl}${route.updateOpsManagementSubassembly}`,
          request
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }
  updateMyModule(request: EditModuleViewModel): Observable<number> {
    return new Observable<number>((observer) => {
      this.http
        .put<number>(
          `${environment.apiUrl}${route.updateModule}`,
          request
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  getOperationsModuleData(
    pilotProductID: number,
    userId: number
  ): Observable<EditModuleViewModel> {
    return new Observable<EditModuleViewModel>((observer) => {
      this.http
        .get<EditModuleViewModel>(
          `${environment.apiUrl}${route.getOperationsModule}/` +
          pilotProductID +
          "/" +
          userId
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  updateWorkRecordData(data: any): Observable<number> {
    return new Observable<number>((observer) => {
      this.http
        .post<number>(
          `${environment.apiUrl}${route.updateWorkRecord}`,
          data
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  UpdateOperation(data: WorkRecordViewModel): Observable<number> {
    return new Observable<number>((observer) => {
      this.http
        .put<number>(
          `${environment.apiUrl}${route.updateWorkRecord}`,
          data
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  updateSteps(
    data: OperationViewModel,
    operationId: number
  ): Observable<number> {
    return new Observable<number>((observer) => {
      this.http
        .put<number>(
          `${environment.apiUrl}${route.updateoperatonbyid}/` +
          operationId,
          data
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  updateAuditOpPercent(
    operationId: number,
    pilotproductId: number
  ): Observable<number> {
    return new Observable<number>((observer) => {
      this.http
        .put<number>(
          `${environment.apiUrl}${route.updateauditcomplete}` +
          operationId +
          "/" +
          pilotproductId,
          null
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  getLogProgress(): Observable<LogProgressView[]> {
    return new Observable<LogProgressView[]>((observer) => {
      this.http
        .get<LogProgressView[]>(
          `${environment.apiUrl}${route.getLogProgress}`
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  getstepsdetails(
    pilotProductID: number,
    operationId: number
  ): Observable<StepDetail[]> {
    return new Observable<StepDetail[]>((observer) => {
      this.http
        .get<StepDetail[]>(
          `${environment.apiUrl}${route.getstepsdetails}` +
          pilotProductID +
          "/" +
          operationId
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  updatesteprecord(request: StepDetail): Observable<number> {
    return new Observable<number>((observer) => {
      this.http
        .post<number>(
          `${environment.apiUrl}${route.updatesteprecord}`,
          request
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  updateallsteprecord(request: any): Observable<number> {
    return this.http.post<number>(
      `${environment.apiUrl}${route.updateallsteprecord}`,
      request
    );
  }

  getoperationlogdetails(
    pilotproductId: number,
    operationId: number,
    userId: number,
    isRework: boolean
  ): Observable<OperationLogDetail> {
    return new Observable<OperationLogDetail>((observer) => {
      this.http
        .get<OperationLogDetail>(
          `${environment.apiUrl}${route.getoperationlogdetails}` +
          pilotproductId +
          "/" +
          operationId +
          "/" +
          userId +
          "/" +
          isRework
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  getOperationLogDetailsGeneral(
    pilotproductId: number,
    operationId: number
  ): Observable<OperationLogDetailGeneral> {
    return new Observable<OperationLogDetailGeneral>((observer) => {
      this.http
        .get<OperationLogDetailGeneral>(
          `${environment.apiUrl}${route.getoperationlogdetailsGeneral}` +
          pilotproductId +
          "/" +
          operationId
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  getTestOrPostTestPercent(
    pilotProductID: number
  ): Observable<OperationPercentViewModel> {
    return new Observable<OperationPercentViewModel>((observer) => {
      this.http
        .get<OperationPercentViewModel>(
          `${environment.apiUrl}${route.getoperationpercent}` +
          pilotProductID
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  getinterrupts(workRecordId: number): Observable<InterruptionsSummary[]> {
    return new Observable<InterruptionsSummary[]>((observer) => {
      this.http
        .get<InterruptionsSummary[]>(
          `${environment.apiUrl}${route.getinterrupts}` + workRecordId
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  getInterruptsByOperations(
    PPId: number,
    OperationId: number
  ): Observable<InterruptionsInfo[]> {
    return new Observable<InterruptionsInfo[]>((observer) => {
      this.http
        .get<InterruptionsInfo[]>(
          `${environment.apiUrl}${route.getinterruptsByOperations}` +
          "?PPId=" +
          PPId +
          "&OperationID=" +
          OperationId
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }
  // US 35741: Interruption form - Cancel should only cancel interruption but not the work record
  deleteInterruptions(
    workRecordId: number
  ): Observable<InterruptionsSummary[]> {
    return new Observable<InterruptionsSummary[]>((observer) => {
      this.http
        .delete<InterruptionsSummary[]>(
          `${environment.apiUrl}${route.deleteinterruption}` +
          workRecordId
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  getInterruptionCategory(): Observable<InterruptionCategory[]> {
    return new Observable<InterruptionCategory[]>((observer) => {
      this.http
        .get<InterruptionCategory[]>(
          `${environment.apiUrl}${route.getinterruptioncategory}`
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  startEndInterruption(request: InterruptionModel): Observable<number> {
    return new Observable<number>((observer) => {
      this.http
        .post<number>(
          `${environment.apiUrl}${route.updateinterruption}`,
          request
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  getStandardTimeExceptionCategory(): Observable<any[]> {
    return new Observable<any[]>((observer) => {
      this.http
        .get<any[]>(
          `${environment.apiUrl}${route.getstandardtimeexceptioncategory}`
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  updateLogWorkRecord(data: any, workRecordId: number): Observable<number> {
    return new Observable<number>((observer) => {
      this.http
        .put<number>(
          `${environment.apiUrl}${route.updateLogworkrecord}` +
          workRecordId,
          data
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  logoperationdelete(workRecordId: number) {
    return this.http.delete<any>(
      `${environment.apiUrl}${route.logoperationdelete}` + workRecordId
    );
  }

  getRunningOperation(userId: number, operationid: number) {
    return this.http.get<any>(
      `${environment.apiUrl}${route.getRunningOperation}` +
      userId +
      "/" +
      operationid
    );
  }

  getBuildStyleDDL(): Observable<MasterRecords[]> {
    return new Observable<MasterRecords[]>((observer) => {
      this.http
        .get<MasterRecords[]>(
          `${environment.apiUrl}${route.getBuildStyleDDL}`
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  //Log progess --> Rework tab
  getReworkCategory(): Observable<ReworkCategoryViewModel[]> {
    return new Observable<ReworkCategoryViewModel[]>((observer) => {
      this.http
        .get<ReworkCategoryViewModel[]>(
          `${environment.apiUrl}${route.getreworkcategory}`
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  getReworkStepDetails(
    pilotProductID: number,
    operationId: number
  ): Observable<StepDetail[]> {
    return new Observable<StepDetail[]>((observer) => {
      this.http
        .get<StepDetail[]>(
          `${environment.apiUrl}${route.getstepsdetailsrework}` +
          pilotProductID +
          "/" +
          operationId
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  updateReworkWorkRecord(
    data: ReworkWorkRecordViewModel,
    workRecordId: number
  ): Observable<string> {
    return new Observable<string>((observer) => {
      this.http
        .post<string>(
          `${environment.apiUrl}${route.updateReworkWorkrecord}` +
          workRecordId,
          data
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  getReworkWorkRecord(workRecordId: number): Observable<any> {
    return new Observable<any>((observer) => {
      this.http
        .get<any>(
          `${environment.apiUrl}${route.getworkrecordrework}` +
          workRecordId
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  getReworkWorkRecordByGUID(guid: string): Observable<any> {
    return new Observable<any>((observer) => {
      this.http
        .get<any>(
          `${environment.apiUrl}${route.getworkrecordreworkbyguid}` +
          guid
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  //Edit Mod-Rework logs
  getReworkLogs(pilotProductID: number): Observable<any[]> {
    return new Observable<any[]>((observer) => {
      this.http
        .get<any[]>(
          `${environment.apiUrl}${route.getreworklog}` +
          pilotProductID
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  updateReworkStepRecord(request: StepDetail): Observable<number> {
    return new Observable<number>((observer) => {
      this.http
        .post<number>(
          `${environment.apiUrl}${route.updatesteprecordrework}`,
          request
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  uploadReworkfile(
    workrecordId: number,
    beforeOrAfter: string,
    formBody: FormData
  ): Observable<string> {
    return new Observable<string>((observer) => {
      this.http
        .post<string>(
          `${environment.apiUrl}${route.uploadreworkfile}` +
          workrecordId +
          "/" +
          beforeOrAfter,
          formBody
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  deleteReworkFile(
    workrecordId: number,
    beforeOrAfter: string,
    fileName: string
  ): Observable<string> {
    return new Observable<string>((observer) => {
      this.http
        .delete<string>(
          `${environment.apiUrl}${route.deletereworkfile}` +
          workrecordId +
          "/" +
          beforeOrAfter +
          "/" +
          fileName
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  getBuildScheduleDDL(): Observable<any[]> {
    return new Observable<any[]>((observer) => {
      this.http
        .get<any[]>(`${environment.apiUrl}${route.getBuildScheduleDDL}`)
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }
  AddWIPRelease(request: WIPRelease, currentTime: Date): Observable<number> {
    return new Observable<number>((observer) => {
      this.http
        .post<number>(
          `${environment.apiUrl}${route.AddWIPRelease}` + currentTime,
          request
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  //Home pages
  getHomeSupLaborHours(plantID): Observable<any[]> {
    return new Observable<any[]>((observer) => {
      this.http
        .get<any[]>(
          `${environment.apiUrl}${route.getHomeSupLaborHours}` +
          plantID
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  deleteHomeSupRemoveUser(workRecordID: number): Observable<any[]> {
    return new Observable<any[]>((observer) => {
      this.http
        .delete<any[]>(
          `${environment.apiUrl}${route.logoperationdelete}` +
          workRecordID
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  getWIPRelease(pilotProductId: number): Observable<WIPRelease> {
    return new Observable<WIPRelease>((observer) => {
      this.http
        .get<WIPRelease>(
          `${environment.apiUrl}${route.getWIPRelease}` +
          pilotProductId
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  getMaxStaffingPriority(plantID: number) {
    return this.http.get<number>(
      `${environment.apiUrl}${route.getWIPStaffingMax}` + plantID
    );
  }

  getSOELink(
    plantID: number,
    operationId: number,
    pilotProductId: number
  ): Observable<SOELink> {
    return new Observable<SOELink>((observer) => {
      this.http
        .get<SOELink>(
          `${environment.apiUrl}${route.getSOELink}` +
          plantID +
          "/" +
          operationId +
          "/" +
          pilotProductId
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  GetSOELinkFileExtension(
    plantID: number,
    operationId: number,
    pilotProductId: number
  ) {
    return this.http.get<any>(
      `${environment.apiUrl}${route.getSOELinkFileExtension}` +
      plantID +
      "/" +
      operationId +
      "/" +
      pilotProductId,
      { responseType: "text" as "json" }
    );
  }

  UpdateSOELinkFileExtension(
    plantID: number,
    operationId: number,
    pilotProductId: number,
    selectedExtension: string
  ): Observable<any> {
    return new Observable<any>((observer) => {
      this.http
        .post<any>(
          `${environment.apiUrl}${route.updateSOELinkFileExtension}` +
          plantID +
          "/" +
          operationId +
          "/" +
          pilotProductId +
          "/" +
          selectedExtension,
          null
        )
        .subscribe(
          (res) => {
            observer.next(res);
          },
          (error) => {
            this.handleError(error);
          }
        );
    });
  }

  priorityReset(plantID: number): Observable<any> {
    return new Observable<any>((observer) => {
      this.http
        .post<any>(
          `${environment.apiUrl}${route.resetStaffPriority}` +
          plantID,
          null
        )
        .subscribe(
          (res) => {
            observer.next(res);
          },
          (error) => {
            this.handleError(error);
          }
        );
    });
  }

  //TOI
  public GetTOIDetails(
    status: string,
    pilotProductID: number
  ): Observable<TOI[]> {
    return new Observable<TOI[]>((observer) => {
      this.http
        .get<TOI[]>(
          `${environment.apiUrl}${route.gettoidetails}` +
          status +
          "/" +
          pilotProductID
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  public AddTOI(request: TOI): Observable<any> {
    return new Observable<any>((observer) => {
      this.http
        .post<any>(`${environment.apiUrl}${route.addTOI}`, request)
        .subscribe(
          (res) => {
            observer.next(res);
          },
          (error) => {
            this.handleError(error);
          }
        );
    });
  }

  public GetTOIStatus(): Observable<MasterRecords[]> {
    return new Observable<MasterRecords[]>((observer) => {
      this.http
        .get<MasterRecords[]>(
          `${environment.apiUrl}${route.getTOIStatus}`
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  public GetTOIView(TOIID: number): Observable<TOI[]> {
    return new Observable<TOI[]>((observer) => {
      this.http
        .get<TOI[]>(`${environment.apiUrl}${route.getTOIView}` + TOIID)
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  public GetTOIZone(
    PilotProductID: number
  ): Observable<ZoneValueViewModel[]> {
    return new Observable<ZoneValueViewModel[]>((observer) => {
      this.http
        .get<ZoneValueViewModel[]>(
          `${environment.apiUrl}${route.GetTOIZone}` + PilotProductID
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  uploadTOIfile(TOIId: number, formBody: FormData): Observable<string> {
    return new Observable<string>((observer) => {
      this.http
        .post<string>(
          `${environment.apiUrl}${route.uploadTOIfile}` + TOIId,
          formBody
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  deleteTOIfile(TOIId: number, filename: string): Observable<string> {
    return new Observable<string>((observer) => {
      this.http
        .delete<string>(
          `${environment.apiUrl}${route.deleteTOIfile}` +
          TOIId +
          "/" +
          filename
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  //Audit Operations
  public getAuditCause() {
    return this.http.get<Cause[]>(
      `${environment.apiUrl}${route.getauditcause}`
    );
  }

  public getAuditCategory() {
    return this.http.get<Category[]>(
      `${environment.apiUrl}${route.getauditcategory}`
    );
  }

  public createAuditItem(request: AuditItem): Observable<number> {
    return new Observable<any>((observer) => {
      this.http
        .post<any>(
          `${environment.apiUrl}${route.createaudititem}`,
          request
        )
        .subscribe(
          (res) => {
            observer.next(res);
          },
          (error) => {
            this.handleError(error);
          }
        );
    });
  }

  uploadAuditFile(
    auditItemID: number,
    beforeOrAfter: string,
    formBody: FormData
  ): Observable<string> {
    return new Observable<string>((observer) => {
      this.http
        .post<string>(
          `${environment.apiUrl}${route.uploadauditfile}` +
          auditItemID +
          "/" +
          beforeOrAfter,
          formBody
        )
        .subscribe(
          (res) => {
            observer.next(res);
          },
          (error) => {
            this.handleError(error);
          }
        );
    });
  }

  getAuditOpDetails(pilotProductID: number, zoneID: number) {
    return this.http.get<any[]>(
      `${environment.apiUrl}${route.getauditopdetails}` +
      pilotProductID +
      "/" +
      zoneID
    );
  }

  deleteAuditFile(
    auditItemID: number,
    beforeOrAfter: string,
    fileName: string
  ): Observable<string> {
    return new Observable<string>((observer) => {
      this.http
        .delete<string>(
          `${environment.apiUrl}${route.deleteauditfile}` +
          auditItemID +
          "/" +
          beforeOrAfter +
          "/" +
          fileName
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  downloadAuditFile(
    auditItemID: number,
    beforeOrAfter: string,
    fileName: string
  ): Observable<string> {
    return new Observable<string>((observer) => {
      this.http
        .get<string>(
          `${environment.apiUrl}${route.downloadauditfile}` +
          auditItemID +
          "/" +
          beforeOrAfter +
          "/" +
          fileName
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  //Edit-Mod: Admin

  GetEditModuleAdminSummary(
    pilotProductID: number
  ): Observable<EditModuleAdminViewModel> {
    return new Observable<EditModuleAdminViewModel>((observer) => {
      this.http
        .get<EditModuleAdminViewModel>(
          `${environment.apiUrl}${route.getEditModuleAdminSummary}` +
          pilotProductID
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  GetVFDAssignmentTable(
    pilotProductID: number
  ): Observable<EditModuleAdminVFDAssignmentTable[]> {
    return new Observable<EditModuleAdminVFDAssignmentTable[]>(
      (observer) => {
        this.http
          .get<EditModuleAdminVFDAssignmentTable[]>(
            `${environment.apiUrl}${route.getVFDAssignmentTable}` +
            pilotProductID
          )
          .subscribe((res) => {
            observer.next(res);
          });
      }
    );
  }

  GetVFDAssignmentStatusDLL(): Observable<MasterRecords[]> {
    return new Observable<MasterRecords[]>((observer) => {
      this.http
        .get<MasterRecords[]>(
          `${environment.apiUrl}${route.getVFDAssignmentStatusDLL}`
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  GetVFDAssignmentBayDLL(): Observable<BayName[]> {
    return new Observable<BayName[]>((observer) => {
      this.http
        .get<BayName[]>(
          `${environment.apiUrl}${route.getVFDAssignmentBayDLL}`
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  UpdateEditModAdmin(
    request: EditModuleAdminViewModelStandard
  ): Observable<number> {
    return new Observable<number>((observer) => {
      this.http
        .put<number>(
          `${environment.apiUrl}${route.updateEditModAdmin}`,
          request
        )
        .subscribe(
          (res) => {
            observer.next(res);
          },
          (error) => {
            this.handleError(error);
          }
        );
    });
  }

  UpdateEditModAdminVFDAssignment(
    request: EditModuleAdminVFDAssignmentTable[]
  ): Observable<number> {
    return new Observable<number>((observer) => {
      this.http
        .put<number>(
          `${environment.apiUrl}${route.updateEditModAdminVFDAssignment}`,
          request
        )
        .subscribe(
          (res) => {
            observer.next(res);
          },
          (error) => {
            this.handleError(error);
          }
        );
    });
  }

  //Action Items - Audit Items
  public getAuditItems(pilotProductID: number) {
    return this.http.get<any[]>(
      `${environment.apiUrl}${route.getauditopdetailsbyzone}` +
      pilotProductID
    );
  }

  public GetOBCDetails(status: string, BEN: string): Observable<OBCDetails> {
    return new Observable<OBCDetails>((observer) => {
      this.http
        .get<OBCDetails>(
          `${environment.apiUrl}${route.getOBCDetails}` +
          status +
          "/" +
          BEN
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  public GetRTSDetails(status: string, BEN: string): Observable<OBCView[]> {
    return new Observable<OBCView[]>((observer) => {
      this.http
        .get<OBCView[]>(
          `${environment.apiUrl}${route.getRTSDetails}` +
          status +
          "/" +
          BEN
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  //Action Items - MTT
  public GetMTTDetails(BEN: string): Observable<MTT[]> {
    return new Observable<MTT[]>((observer) => {
      this.http
        .get<MTT[]>(`${environment.apiUrl}${route.getMTTDetails}` + BEN)
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  public GetMTTStatusDLL() {
    return this.http.get<any[]>(
      `${environment.apiUrl}${route.getMTTStatusDLL}`
    );
  }

  public GetMTTAddRemoveDLL() {
    return this.http.get<any[]>(
      `${environment.apiUrl}${route.getMTTAddRemoveDLL}`
    );
  }

  public UpdateMTTData(request: MTT): Observable<any> {
    return new Observable<any>((observer) => {
      this.http
        .put<any>(
          `${environment.apiUrl}${route.updateMTTData}`,
          request
        )
        .subscribe(
          (res) => {
            observer.next(res);
          },
          (error) => {
            this.handleError(error);
          }
        );
    });
  }

  public UpdateRTSStatus(info: any): Observable<any> {
    return this.http.post<any>(
      `${environment.apiUrl}${route.updateRTSStatus}`,
      info
    );
  }

  public GetIssueLogStatusCount(
    id: string,
    plantID: number
  ): Observable<IssueLogView[]> {
    return new Observable<IssueLogView[]>((observer) => {
      this.http
        .get<IssueLogView[]>(
          `${environment.apiUrl}${route.getIssueLogStatusCount}` +
          id +
          "/" +
          plantID
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  GetIssueLogDetails(
    id: string,
    plantID: number
  ): Observable<IssueLogView[]> {
    return new Observable<IssueLogView[]>((observer) => {
      this.http
        .get<IssueLogView[]>(
          `${environment.apiUrl}${route.getIssueLogDetails}` +
          id +
          "/" +
          plantID
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }
  GetNCIDetails(
    status: string,
    id: string,
    plantID: number
  ): Observable<NCIView[]> {
    return new Observable<NCIView[]>((observer) => {
      this.http
        .get<NCIView[]>(
          `${environment.apiUrl}${route.getNCIDetails}` +
          status +
          "/" +
          id +
          "/" +
          plantID
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  GetShortagesDetails(id: string): Observable<Shortages[]> {
    return new Observable<Shortages[]>((observer) => {
      this.http
        .get<Shortages[]>(
          `${environment.apiUrl}${route.getShortagesDetails}` + id
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  GetPassdownTabs(pilotproductid: number): Observable<PassdownTabs[]> {
    return new Observable<PassdownTabs[]>((observer) => {
      this.http
        .get<PassdownTabs[]>(
          `${environment.apiUrl}${route.getpassdowntabs}` +
          pilotproductid
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  GetGeneratePassdownZonesDetail(
    pilotproductid: number,
    zoneid: number,
    shiftid: number,
    passdownid: number,
    currentTime: Date
  ): Observable<PassdownZoneOperationDetail> {
    return new Observable<PassdownZoneOperationDetail>((observer) => {
      this.http
        .get<PassdownZoneOperationDetail>(
          `${environment.apiUrl}${route.getzonedetails}` +
          pilotproductid +
          "/" +
          zoneid +
          "/" +
          shiftid +
          "/" +
          passdownid +
          "/" +
          currentTime
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  GetGeneratePassdownActionItems(
    pilotproductid: number,
    shiftid: number,
    passdownid: number,
    currentTime: Date
  ): Observable<PassdownActionItemsDetail> {
    return new Observable<PassdownActionItemsDetail>((observer) => {
      this.http
        .get<PassdownActionItemsDetail>(
          `${environment.apiUrl}${route.getactionitems}` +
          pilotproductid +
          "/" +
          shiftid +
          "/" +
          passdownid +
          "/" +
          currentTime
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  GetGeneratePassdownAssemblyOperations(
    pilotproductid: number,
    shiftid: number,
    passdownid: number
  ): Observable<PassdownAssemblyOperationDetail> {
    return new Observable<PassdownAssemblyOperationDetail>((observer) => {
      this.http
        .get<PassdownAssemblyOperationDetail>(
          `${environment.apiUrl}${route.getassemblyoperations}` +
          pilotproductid +
          "/" +
          shiftid +
          "/" +
          passdownid
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  GetPassdownTest(passdownid: number): Observable<PassdownTestDetail> {
    return new Observable<PassdownTestDetail>((observer) => {
      this.http
        .get<PassdownTestDetail>(
          `${environment.apiUrl}${route.gettest}` + passdownid
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  CreatePassdown(
    passdownGenerateOrEdit: PassdownGenerateOrEdit,
    currentTime: Date
  ): Observable<number> {
    return new Observable<number>((observer) => {
      this.http
        .post<number>(
          `${environment.apiUrl}${route.createpassdown}` +
          currentTime,
          passdownGenerateOrEdit
        )
        .subscribe(
          (res) => {
            observer.next(res);
          },
          (error) => {
            this.handlePassdownError(error);
          }
        );
    });
  }

  EditPassdown(
    passdownGenerateOrEdit: PassdownGenerateOrEdit,
    passdownid: number,
    currentTime: Date
  ): Observable<number> {
    return new Observable<number>((observer) => {
      this.http
        .put<number>(
          `${environment.apiUrl}${route.editpassdown}` +
          passdownid +
          "/" +
          currentTime,
          passdownGenerateOrEdit
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  GetPassdownsByPPId(
    pilotproductid: number,
    shiftID: number,
    currentTime: Date
  ): Observable<ModulePassdown[]> {
    return new Observable<ModulePassdown[]>((observer) => {
      this.http
        .get<ModulePassdown[]>(
          `${environment.apiUrl}${route.getpassdowns}` +
          pilotproductid +
          "/" +
          shiftID +
          "/" +
          currentTime
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  GetDisplayPassdown(
    pilotproductid: number,
    shiftid: number,
    passdownid: number,
    isEdit: boolean,
    currentTime: Date
  ): Observable<PassdownDisplay> {
    return new Observable<PassdownDisplay>((observer) => {
      this.http
        .get<PassdownDisplay>(
          `${environment.apiUrl}${route.getdisplaypassdown}` +
          pilotproductid +
          "/" +
          shiftid +
          "/" +
          passdownid +
          "/" +
          isEdit +
          "/" +
          currentTime
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  SendWIPEmail(data: any, plantID: number, date: Date): Observable<string> {
    return new Observable<string>((observer) => {
      this.http
        .post<string>(
          `${environment.apiUrl}${route.sendWIPEmail}` +
          plantID +
          "/" +
          date,
          data
        )
        .subscribe(
          (res) => {
            observer.next(res);
          },
          (error) => {
            this.handleError(error);
          }
        );
    });
  }

  //Ops- Mgmt
  GetOpMgmtData(pilotProductID: number, date: Date): Observable<any[]> {
    return new Observable<any[]>((observer) => {
      this.http
        .get<any[]>(
          `${environment.apiUrl}${route.getOpMgmtData}` +
          pilotProductID +
          "/" +
          date
        )
        .subscribe(
          (res) => {
            observer.next(res);
          },
          (error) => {
            this.handleError(error);
          }
        );
    });
  }

  GetOpMgmtDataForEngineers(
    pilotProductID: number,
    date: Date
  ): Observable<any[]> {
    return new Observable<any[]>((observer) => {
      this.http
        .get<any[]>(
          `${environment.apiUrl}${route.getOpMgmtDataForEngineers}` +
          pilotProductID +
          "/" +
          date
        )
        .subscribe(
          (res) => {
            observer.next(res);
          },
          (error) => {
            this.handleError(error);
          }
        );
    });
  }

  updateOpsMgmtData(request: any): Observable<number> {
    return new Observable<number>((observer) => {
      this.http
        .post<number>(
          `${environment.apiUrl}${route.updateOpsMgmtData}`,
          request
        )
        .subscribe(
          (res) => {
            observer.next(res);
          },
          (error) => {
            this.handleError(error);
          }
        );
    });
  }

  GetAssemblyTestPostTestPercent(
    pilotProductID: number
  ): Observable<OpsMgmtPercent> {
    return new Observable<OpsMgmtPercent>((observer) => {
      this.http
        .get<OpsMgmtPercent>(
          `${environment.apiUrl}${route.getPercent}` + pilotProductID
        )
        .subscribe(
          (res) => {
            observer.next(res);
          },
          (error) => {
            this.handleError(error);
          }
        );
    });
  }

  //Critical-Gating
  GetCriticalGating(plantID: number): Observable<CG[]> {
    return new Observable<CG[]>((observer) => {
      this.http
        .get<CG[]>(
          `${environment.apiUrl}${route.getCriticalGating}` + plantID
        )
        .subscribe(
          (res) => {
            observer.next(res);
          },
          (error) => {
            this.handleError(error);
          }
        );
    });
  }

  //Safety-Linedown
  GetSafetyAndLineDown(plantID: number): Observable<SafetyLinedown[]> {
    return new Observable<SafetyLinedown[]>((observer) => {
      this.http
        .get<SafetyLinedown[]>(
          `${environment.apiUrl}${route.getSafetyAndLineDown}` +
          plantID
        )
        .subscribe(
          (res) => {
            observer.next(res);
          },
          (error) => {
            this.handleError(error);
          }
        );
    });
  }

  GetBuildingOfUser(userid: number): Observable<Building[]> {
    return new Observable<Building[]>((observer) => {
      this.http
        .get<Building[]>(
          `${environment.apiUrl}${route.getbuilding}` + userid
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  getBuilding(plantID): Observable<any[]> {
    const param = "?plantID=" + plantID;
    return new Observable<any[]>((observer) => {
      this.http
        .get<any[]>(`${environment.apiUrl}${route.getBuilding}${param}`)
        .subscribe(
          (res) => {
            observer.next(res);
          },
          (error) => {
            this.handleError(error);
          }
        );
    });
  }

  public GetVFDReleases(plantId: number): Observable<VFDRelease[]> {
    return new Observable<VFDRelease[]>((observer) => {
      this.http
        .get<VFDRelease[]>(
          `${environment.apiUrl}${route.getvfdreleases}` + plantId
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  public GetModuleReleases(pilotProductId: number) {
    return new Observable<ModuleVFD[]>((observer) => {
      this.http
        .get<ModuleVFD[]>(
          `${environment.apiUrl}${route.getmodulereleases}` +
          pilotProductId
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  GetShowPassdownButtons(
    shiftId: number,
    currentTime: Date
  ): Observable<boolean> {
    return new Observable<boolean>((observer) => {
      this.http
        .get<boolean>(
          `${environment.apiUrl}${route.getpassdownbutton}` +
          shiftId +
          "/" +
          currentTime
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  GetSerializationNumbers(
    plantId: number,
    pilotProductId: number
  ): Observable<SerialNumbers[]> {
    return new Observable<SerialNumbers[]>((observer) => {
      this.http
        .get<SerialNumbers[]>(
          `${environment.apiUrl}${route.getSerializationNumbers}` +
          plantId +
          "/" +
          pilotProductId
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  updateSerializationNumbers(
    serializationRequest: SerializationRequest[]
  ): Observable<number> {
    return new Observable<number>((observer) => {
      this.http
        .post<number>(
          `${environment.apiUrl}${route.updateSerializationNumbers}`,
          serializationRequest
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  getModulesSummary(pilotProductID: number): Observable<EditModuleViewModel> {
    return new Observable<EditModuleViewModel>((observer) => {
      this.http
        .get<EditModuleViewModel>(
          this.apiUrl + route.getModuleSummary + pilotProductID
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  GetReconfig(status: string, ben: string, plantId: number): Observable<ReconfigData> {
    return new Observable<ReconfigData>((observer) => {
      this.http
        .get<ReconfigData>(
          this.apiUrl + route.getReconfig + status + '/' + ben + '/' + plantId
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  GetDeleteReconfig(status: string, ben: string, plantId: number): Observable<ReconfigData> {
    return new Observable<ReconfigData>((observer) => {
      this.http
        .get<ReconfigData>(
          this.apiUrl + route.getReconfigDelete + status + '/' + ben + '/' + plantId
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  UpdateReconfig(reconfigEdit: ReconfigEditFields[]) {
    return new Observable<number>((observer) => {
      this.http
        .post<number>(
          `${environment.apiUrl}${route.updateReconfig}`,
          reconfigEdit
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  GetReconfigStatus(): Observable<ReconfigStatus[]> {
    return new Observable<ReconfigStatus[]>((observer) => {
      this.http
        .get<ReconfigStatus[]>(
          this.apiUrl + route.getReconfigStatus
        )
        .subscribe((res) => {
          observer.next(res);
        });
    });
  }

  public handleError(error) {
    let errorMessage = "";
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }

  public handlePassdownError(error) {
    let errorMessage = "";
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
      if (error.status === 500) {
        alert(error.error.detail);
      }
    }
    return throwError(errorMessage);
  }
}
