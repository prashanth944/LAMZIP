import {
    ChangeDetectorRef,
    Component,
    OnInit,
    ViewEncapsulation,
    ChangeDetectionStrategy,
    AfterViewInit,
    TemplateRef,
    ViewChild,
    ViewContainerRef,
} from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { EditService } from "src/app/feature/service/edit.service";
import { State } from "@progress/kendo-data-query";
import { ActivatedRoute, Router, RouterStateSnapshot } from "@angular/router";
import { DataServiceEandTService } from "../data-service-eand-t.service";
import { WorkSummaryGrid } from "../Models/workSummaryGrid";
import { AppStoreService } from "../../../core/app-store.service";
import { UpdateWorkSummary } from "../Models/updateWorkSummary";
import * as moment from "moment";
import { NotificationService } from "@progress/kendo-angular-notification";
import { Observable } from "rxjs";
import { Plant } from "../../../core/model/user.model";
import { uiScreen } from "../../../core/model/common.constant";

@Component({
    selector: "pmpm-work-summary",
    templateUrl: "./work-summary.component.html",
    styleUrls: ["./work-summary.component.css"],
    encapsulation: ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WorkSummaryComponent implements OnInit, AfterViewInit {
    @ViewChild("template", { read: TemplateRef })
    public notificationTemplate: TemplateRef<any>;

    @ViewChild("appendTo", { read: ViewContainerRef })
    public appendTo: ViewContainerRef;

    workSummaryGridData: any[] = [];
    interruptionGridData: any[] = [];
    startTime = "09-03-2021 11:12PM";
    finishTime = "09-03-2021 11:12PM";
    totalWorkingTime = "2 hours 17 mins";
    totalInteruptionTime = "92 mins";
    WSDescription = "";
    editWorkSummary = false;
    updateWorkSummaryObj: UpdateWorkSummary[] = [];
    public addOpened = false;
    notesValue = "";
    public pilotProductId: number;
    public operationId: number;
    loadTable = false;
    public userId: number;
    public userName: string;
    public isChanged = false;
    notesDataItem: any;
    notesTobeAdded = "";
    days: any;
    PSN = "";
    notificationMsg = "Work record saved";
    public gridState: State = {
        sort: [],
        skip: 0,
        take: 10,
    };
    public newNote = "";
    site: Plant;
    BEN = "";
    public canEditWorkRecord = false;

    constructor(
        private changeDetector: ChangeDetectorRef,
        private appStoreService: AppStoreService,
        private formBuilder: FormBuilder,
        private editService: EditService,
        private router: Router,
        private route: ActivatedRoute,
        private service: DataServiceEandTService,
        private notificationService: NotificationService
    ) {}

    ngOnInit() {
        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                //Edit Work Record access
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.EditWorkRecord)
                    .subscribe((result) => {
                        this.canEditWorkRecord = result;
                    });
            }
        });
        this.loadTable = true;
        this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site) {
                this.site = {
                    plantName: site.plantName,
                    plantId: site.plantId,
                };
            }
        });
        this.editService.cancelChanges();
    }

    canDeactivate(
        nextState: RouterStateSnapshot
    ): Observable<boolean> | Promise<boolean> | boolean {
        if (this.editService.hasChanges()) {
            this.isChanged = true;
            this.changeDetector.detectChanges();
            return false;
        } else {
            return true;
        }
    }

    closeEdit() {
        this.isChanged = false;
    }

    discardChanges() {
        this.editService.cancelChanges();
        this.isChanged = false;
        this.onReturnToModuleClick();
    }

    ngAfterViewInit() {
        this.editService.cancelChanges();
        this.appStoreService.getLoggedInUser().subscribe((user) => {
            this.appStoreService.getUserDetails(user.mail).subscribe((res) => {
                this.userId = res?.userId;
                (this.userName = res?.firstName + " " + res?.lastName),
                    this.route.params.subscribe((param) => {
                        this.pilotProductId = param.id;
                        this.operationId = param.operationId;
                        this.getStepDetails();
                        this.getInterruptionDetails();
                    });
            });
        });
    }

    getStepDetails() {
        this.workSummaryGridData = [];
        this.service
            .getstepsdetails(this.pilotProductId, this.operationId)
            .subscribe((res) => {
                if (res && res.length > 0) {
                    this.loadTable = false;
                    res.forEach((val) => {
                        const gridSumm: WorkSummaryGrid = {
                            StepRecordId: val.stepRecordId,
                            Id: val.stepNo,
                            Complete: val.completed,
                            Skipped: val.skipped,
                            ExcludedOption: val.excluded,
                            Reworked: val.reworked,
                            TechnicianNotes: this.getTechNotesInDifferentLines(
                                val.technicianNotes
                            ),

                            completedBy: val.completedBy,
                            completedById: val.completedById,
                            excludedById: val.excludedById,
                            skippedById: val.skippedById,
                            operationId: val.operationId,
                            pilotProductId: val.pilotProductId,
                            numberofSteps: val.numberofSteps,
                            cycleTimeMinutes: val.cycleTimeMinutes,
                        };
                        this.workSummaryGridData.push(gridSumm);
                    });
                }
                this.changeDetector.detectChanges();
            });
    }
    getInterruptionDetails() {
        this.service
            .getoperationlogdetails(
                this.pilotProductId,
                this.operationId,
                this.userId,
                false
            )
            .subscribe((res) => {
                if (res) {
                    this.startTime =
                        res.startTime !== null
                            ? moment(res.startTime)
                                  .format("MM-DD-yyyy hh:mm A")
                                  .toString()
                            : null;
                    this.finishTime =
                        res.endTime !== null
                            ? moment(res.endTime)
                                  .format("MM-DD-yyyy hh:mm A")
                                  .toString()
                            : null;
                    this.totalWorkingTime = this.getTotalWorkingTime(
                        res.startTime,
                        res.endTime,
                        res.totalInterruptionMinutes
                    );
                    this.totalInteruptionTime =
                        res.totalInterruptionMinutes !== null
                            ? res.totalInterruptionMinutes.toString() +
                              " minutes"
                            : "";
                    this.WSDescription = res.description;
                    this.PSN = res.pilotSerialNumber;
                    this.BEN = res.ben;
                    this.changeDetector.detectChanges();
                    this.service
                        .getinterrupts(res.workRecordId)
                        .subscribe((res2) => {
                            if (res2) {
                                this.interruptionGridData = res2;
                                this.changeDetector.detectChanges();
                            }
                        });
                }
            });
    }

    getTotalWorkingTime(startTime, endTime, intMins) {
        let totalWorkingTime = "";
        const m1 = moment(new Date(startTime), "DD-MM-YYYY HH:mm");
        const m2 = moment(new Date(endTime), "DD-MM-YYYY HH:mm");
        const m3 = m2.diff(m1, "minutes") - intMins;

        if (m3 >= 0) {
            const numdays = Math.floor(m3 / 1440);
            const numhours = Math.floor((m3 % 1440) / 60);
            const numminutes = Math.floor((m3 % 1440) % 60);

            totalWorkingTime =
                numdays +
                " day(s) " +
                numhours +
                " hours " +
                numminutes +
                " minutes ";
        }
        return totalWorkingTime;
    }

    onEditWorkRecordClick() {
        this.editWorkSummary = !this.editWorkSummary;
    }
    onSaveWorkRecordClick(grid) {
        this.editWorkSummary = !this.editWorkSummary;
        this.saveChanges(grid);
    }

    public onStateChange(state: State) {
        this.gridState = state;
    }

    public cellClickHandler({
        sender,
        rowIndex,
        columnIndex,
        dataItem,
        isEdited,
    }: any) {
        if (!isEdited) {
            sender.editCell(
                rowIndex,
                columnIndex,
                this.createFormGroup(dataItem)
            );
        }
    }

    public cellCloseHandler(args: any) {
        const { formGroup, dataItem } = args;
        if (!formGroup.valid) {
            // prevent closing the edited cell if there are invalid values.
            args.preventDefault();
        } else if (formGroup.dirty) {
            this.editService.assignValues(dataItem, formGroup.value);
            this.editService.update(dataItem, "");
        } else {
            this.editService.update(dataItem, "");
        }
        this.setCheckbox(args.column.field, dataItem);
    }

    public cancelHandler({ sender, rowIndex }: any) {
        sender.closeRow(rowIndex);
    }

    public saveHandler({ sender, formGroup, rowIndex }: any) {
        if (formGroup.valid) {
            this.editService.create(formGroup.value);
            sender.closeRow(rowIndex);
        }
    }

    public removeHandler({ sender, dataItem }: any) {
        this.editService.remove(dataItem);

        sender.cancelCell();
    }

    public createFormGroup(dataItem: any): FormGroup {
        return this.formBuilder.group({
            StepRecordId: dataItem.StepRecordId,
            Complete: dataItem.Complete,
            Skipped: dataItem.Skipped,
            ExcludedOption: dataItem.ExcludedOption,
            TechnicianNotes: dataItem.TechnicianNotes,
        });
    }
    public saveChanges(grid: any): void {
        grid.closeCell();
        grid.cancelCell();
        const abc = this.editService.saveChanges();
        //call update api
        this.updateWorkSummaryObj = [];
        abc[0].forEach((val) => {
            const updWS: UpdateWorkSummary = {
                stepRecordId: val.StepRecordId,
                stepNo: val.Id,
                completed: val.Complete,
                skipped: val.Skipped,
                excluded: val.ExcludedOption,

                completedBy: val.completedBy,
                completedById: val.completedById,
                skippedById: val.skippedById,
                excludedById: val.excludedById,

                technicianNotes: val.TechnicianNotes,

                numberofSteps: val.numberofSteps,
                operationId: val.operationId,
                cycleTimeMinutes: val.cycleTimeMinutes,
                pilotProductId: val.pilotProductId,
            };
            this.updateWorkSummaryObj.push(updWS);
        });
        this.service
            .updateallsteprecord(this.updateWorkSummaryObj)
            .subscribe((res) => {
                if (res) {
                    this.newNote = "";
                    this.showSuccess();
                    this.getStepDetails();
                }
            });
    }
    setCheckbox(field, dataItem) {
        if (field === "Complete") {
            if (dataItem.Complete === true) {
                dataItem.Skipped = false;
                dataItem.ExcludedOption = false;
                dataItem.completedBy = this.userName;
                dataItem.completedById = this.userId;
            }
        } else if (field === "Skipped") {
            if (dataItem.Skipped === true) {
                dataItem.Complete = false;
                dataItem.ExcludedOption = false;
                dataItem.skippedById = this.userId;
            }
        } else if (field === "ExcludedOption") {
            if (dataItem.ExcludedOption === true) {
                dataItem.Complete = false;
                dataItem.Skipped = false;
                dataItem.excludedById = this.userId;
            }
        }
        this.editService.update(dataItem, "");
    }
    closeAdd(status: string) {
        this.notesValue = "";
        this.addOpened = false;
    }

    openAdd(dataItem) {
        this.notesDataItem = dataItem;
        this.addOpened = true;
    }
    onAddNote() {
        this.addOpened = false;
        const note =
            "[" +
            moment(new Date()).format("MM-DD-yyyy hh:mm A").toString() +
            ", " +
            this.userName +
            "]: " +
            this.notesValue +
            "\n";
        this.newNote +=
            "[" +
            moment(new Date()).format("MM-DD-yyyy hh:mm A").toString() +
            ", " +
            this.userName +
            "]: " +
            this.notesValue +
            "\n";
        this.notesDataItem.TechnicianNotes =
            this.notesDataItem.TechnicianNotes !== null
                ? this.notesDataItem.TechnicianNotes + note
                : note;
        this.editService.update(this.notesDataItem, "");

        this.notesValue = "";
    }
    getTechNotesInDifferentLines(data) {
        let newNotes = "";
        if (data !== null) {
            const notesArr = data.split("|");
            notesArr.forEach((val) => {
                if (val.trim() !== "") newNotes = newNotes + val.trim() + "\n";
            });
        }
        return newNotes;
    }

    onReturnToModuleClick() {
        this.router.navigate([
            "/edit-module/" + this.pilotProductId + "/" + "2",
        ]);
    }

    public showSuccess(): void {
        this.notificationService.show({
            appendTo: this.appendTo,
            content: "Saved",
            position: { horizontal: "left", vertical: "bottom" },
            animation: { type: "fade", duration: 600 },
            type: { style: "success", icon: true },
        });
    }
}
