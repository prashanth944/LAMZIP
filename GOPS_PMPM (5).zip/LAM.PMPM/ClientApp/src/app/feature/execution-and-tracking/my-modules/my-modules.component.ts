import { Component, Input, OnDestroy, OnInit } from "@angular/core";
import { ModuleSummary } from "../Models/ModuleSummary";
import { DataServiceEandTService } from "../data-service-eand-t.service";
import { AppStoreService } from "../../../core/app-store.service";
import { Subscription } from "rxjs";
import { process, State } from "@progress/kendo-data-query";
import { GridDataResult } from "@progress/kendo-angular-grid";
import { Plant, UserModel } from "../../../core/model/user.model";
import { role, uiScreen } from "../../../core/model/common.constant";
import { Router } from "@angular/router";
import { Item } from "../../model/item";

@Component({
    selector: "pmpm-my-modules",
    templateUrl: "./my-modules.component.html",
    styleUrls: ["./my-modules.component.css"],
})
export class MyModulesComponent implements OnInit, OnDestroy {
    @Input() isFromTechHomePage = false;
    @Input() buildStyleID = 0;
    @Input() vaBuildID = 0;

    gridData: ModuleSummary[] = [];
    public viewData: GridDataResult;
    site: Plant;
    private subscription: Subscription[] = [];

    public AllFCID: string[];
    public SelFCID: string;

    public AllProductType: string[];
    public SelProductType: string;
    public capacityPlanningColorHex: Item[] = [];

    public AllPilotSerialNumber: string[];
    public SelPilotSerialNumber: string;

    public AllBEN: string[];
    public SelBEN: string;

    public AllModOptions: string[] = [
        "Active modules",
        "Completed Modules",
        "Modules Worked On",
    ];
    public SelModOption: string;

    private textSearch = "";

    public subAssemblyCount = 0;
    public integrationCount = 0;
    public postTestCount = 0;
    public testCount = 0;
    public totalCount = 0;
    public reconfigCount = 0;
    public userDetail: UserModel;

    public gridState: State = {
        sort: [],
    };
    public isUserAccess = false;
    public isLoading = true;

    constructor(
        private dataService: DataServiceEandTService,
        private appStoreService: AppStoreService,
        private router: Router
    ) {}

    ngOnInit(): void {
        this.isLoading = true;
        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.MyModule)
                    .subscribe((result) => {
                        this.isUserAccess = result;
                    });

                if (res.includes(role.Technician)) {
                    this.SelModOption = "Modules Worked On";
                    this.updateFromFilter();
                }
            }
        });

        this.dataService.getModuleColorDDL().subscribe((mc) => {
            mc.forEach((val) => {
                const newMC: Item = {
                    value: val.value.trim(),
                    text: val.masterRecordName,
                };
                this.capacityPlanningColorHex.push(newMC);
                this.capacityPlanningColorHex =
                    this.capacityPlanningColorHex.sort(function (a, b) {
                        const textA = a?.text?.toUpperCase();
                        const textB = b?.text?.toUpperCase();
                        return textA < textB ? -1 : textA > textB ? 1 : 0;
                    });
            });
        });

        this.subscription.push(
            this.appStoreService.getLoggedInUser().subscribe((user) => {
                this.appStoreService
                    .getUserDetails(user.mail)
                    .subscribe((res) => {
                        this.userDetail = res;
                        this.appStoreService
                            .getCurrentSite()
                            .subscribe((site) => {
                                this.isLoading = true;
                                if (site) {
                                    this.site = {
                                        plantName: site.plantName,
                                        plantId: site.plantId,
                                    };
                                    this.dataService
                                        .getModuleSummary(
                                            this.site.plantId,
                                            this.userDetail.userId
                                        )
                                        .toPromise()
                                        .then((data) => {
                                            if (
                                                this.isFromTechHomePage &&
                                                this.buildStyleID > 0
                                            ) {
                                                let tempData = [];
                                                tempData = [
                                                    ...data.filter(
                                                        (item) =>
                                                            item.ModuleInfo
                                                                .BuildStyleId ===
                                                            this.buildStyleID
                                                    ),
                                                ];
                                                if (this.vaBuildID > 0) {
                                                    tempData = [
                                                        ...tempData,
                                                        ...data.filter(
                                                            (item) =>
                                                                item.ModuleInfo
                                                                    .BuildStyleId ===
                                                                this.vaBuildID
                                                        ),
                                                    ];
                                                    this.reconfigCount =
                                                        tempData.length;
                                                }
                                                this.gridData = tempData;
                                            } else this.gridData = data;
                                            this.totalCount =
                                                this.gridData.length;
                                            this.subAssemblyCount =
                                                this.gridData.filter(
                                                    (item) =>
                                                        item.ModuleProcess ===
                                                        "SUB ASSEMBLY"
                                                ).length;
                                            this.integrationCount =
                                                this.gridData.filter(
                                                    (item) =>
                                                        item.ModuleProcess ===
                                                        "INTEGRATION"
                                                ).length;
                                            this.postTestCount =
                                                this.gridData.filter(
                                                    (item) =>
                                                        item.ModuleProcess ===
                                                        "POST-TEST"
                                                ).length;
                                            this.testCount =
                                                this.gridData.filter(
                                                    (item) =>
                                                        item.ModuleProcess ===
                                                        "TEST"
                                                ).length;

                                            this.AllFCID = this.GetUniques(
                                                this.gridData,
                                                "FCID"
                                            );
                                            this.AllProductType =
                                                this.GetUniques(
                                                    this.gridData,
                                                    "ProductType"
                                                );
                                            this.AllPilotSerialNumber =
                                                this.GetUniques(
                                                    this.gridData,
                                                    "PilotSerialNumber"
                                                );
                                            this.AllBEN = this.GetUniques(
                                                this.gridData,
                                                "BEN"
                                            );

                                            this.viewData = process(
                                                this.gridData,
                                                this.gridState
                                            );
                                            this.isLoading = false;
                                        });
                                }
                            });
                    });
            })
        );
    }

    public GetUniques(data: any[], colName: string) {
        return data
            .map((item) => item.ModuleInfo[colName])
            .filter(
                (value, index, self) =>
                    self.indexOf(value) === index &&
                    value !== null &&
                    value !== ""
            );
    }

    ngOnDestroy(): void {
        this.subscription.forEach((sub) => sub.unsubscribe());
    }

    public onFilter(inputValue: string): void {
        this.textSearch = inputValue;
        this.updateFromFilter();
    }
    public getValue(event: Event): string {
        return (event.target as HTMLInputElement).value;
    }

    public updateFromFilter() {
        this.gridState["filter"] = {
            logic: "and",
            filters: [],
        };

        if (this.SelFCID && this.SelFCID !== "All FCID") {
            this.gridState["filter"].filters.push({
                field: "ModuleInfo.FCID",
                operator: "eq",
                value: this.SelFCID,
            });
        }
        if (this.SelProductType && this.SelProductType !== "All Product Type") {
            this.gridState["filter"].filters.push({
                field: "ModuleInfo.ProductType",
                operator: "eq",
                value: this.SelProductType,
            });
        }
        if (
            this.SelPilotSerialNumber &&
            this.SelPilotSerialNumber !== "All Pilot Serial Number"
        ) {
            this.gridState["filter"].filters.push({
                field: "ModuleInfo.PilotSerialNumber",
                operator: "eq",
                value: this.SelPilotSerialNumber,
            });
        }
        if (this.SelBEN && this.SelBEN !== "All BEN") {
            this.gridState["filter"].filters.push({
                field: "ModuleInfo.BEN",
                operator: "eq",
                value: this.SelBEN,
            });
        }
        if (this.SelModOption && this.SelModOption !== "All Modules") {
            if (this.SelModOption === "Active modules") {
                this.gridState["filter"].filters.push({
                    field: "ModuleInfo.Active",
                    operator: "eq",
                    value: 1,
                });
            } else if (this.SelModOption === "Completed Modules") {
                this.gridState["filter"].filters.push({
                    field: "ModuleInfo.Active",
                    operator: "eq",
                    value: 0,
                });
            } else if (this.SelModOption === "Modules Worked On") {
                this.gridState["filter"].filters.push({
                    field: "ModuleInfo.IsWorkedOn",
                    operator: "eq",
                    value: true,
                });
            }
        }

        if (this.textSearch) {
            if (this.site.plantName === "Tualatin") {
                this.gridState["filter"].filters.push({
                    logic: "or",
                    filters: [
                        {
                            field: "ModuleInfo.BEN",
                            operator: "contains",
                            value: this.textSearch.trim(),
                        },
                        {
                            field: "ModuleInfo.FCID",
                            operator: "contains",
                            value: this.textSearch.trim(),
                        },
                    ],
                });
            }
            if (this.site.plantName === "Fremont") {
                this.gridState["filter"].filters.push({
                    logic: "or",
                    filters: [
                        {
                            field: "ModuleInfo.FCID",
                            operator: "contains",
                            value: this.textSearch.trim(),
                        },
                        {
                            field: "ModuleInfo.FremontID",
                            operator: "contains",
                            value: this.textSearch.trim(),
                        },
                        {
                            field: "ModuleInfo.PilotSerialNumber",
                            operator: "contains",
                            value: this.textSearch.trim(),
                        },
                    ],
                });
            }
        }

        if (this.gridState["filter"].filters.length === 0) {
            delete this.gridState["filter"];
        }

        this.viewData = process(this.gridData, this.gridState);
    }

    navigateToHome() {
        this.router.navigate(["/home"]);
    }
}
