import {
    Component,
    Input,
    OnChanges,
    OnInit,
    SimpleChanges,
    ViewChildren,
    ViewEncapsulation,
} from "@angular/core";
import { ExpansionPanelComponent } from "@progress/kendo-angular-layout";
import { AppStoreService } from "../../../../core/app-store.service";
import { DataServiceEandTService } from "../../data-service-eand-t.service";
import {
    EditModuleViewModel,
    OperationPercentViewModel,
    WorkRecordViewModel,
} from "../../Models/ModuleSummary";
import { EditService } from "src/app/feature/service/edit.service";
import { Router } from "@angular/router";
import {
    process,
    State,
    aggregateBy,
    AggregateDescriptor,
    AggregateResult,
} from "@progress/kendo-data-query";
import {
    DataStateChangeEvent,
    GridDataResult,
} from "@progress/kendo-angular-grid";
import { Observable } from "rxjs";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Plant } from "../../../../core/model/user.model";
import { uiScreen } from "../../../../core/model/common.constant";

@Component({
    selector: "pmpm-edit-module-operations",
    templateUrl: "./edit-module-operations.component.html",
    styleUrls: ["./edit-module-operations.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class EditModuleOperationsComponent implements OnInit, OnChanges {
    @Input() moduleData: EditModuleViewModel;
    @ViewChildren(ExpansionPanelComponent)
    public userId: number;
    public operationsData: any;
    public tempModuleData: EditModuleViewModel;
    public moduleColorValue: { text: string; value: string };
    public isSaveEnabled = false;
    public isCollapsed = false;
    public testPercent: OperationPercentViewModel;
    public postTestPercent: OperationPercentViewModel;
    public message = "";
    public showDialogbox = false;

    // Grid
    public mySelection: string[] = [];
    state: DataStateChangeEvent;
    public total: AggregateResult;
    public view: Observable<GridDataResult>;
    public changes: any = {};
    public gridState: State = {
        sort: [],
        skip: 0,
        take: 10,
    };
    public site: Plant;
    public isUserAccess = false;
    public hasEditAccess = false;
    public canEditCompleteBtn = false; //US:35940 - Not allow Tech to mark audit op as complete
    isLoading = true;

    constructor(
        private service: DataServiceEandTService,
        private appStoreService: AppStoreService,
        public editService: EditService,
        private router: Router,
        private formBuilder: FormBuilder
    ) {}

    ngOnInit(): void {
        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                //Page access
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.EditModOp)
                    .subscribe((result) => {
                        this.isUserAccess = result;
                    });
                //Action button access
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.ActionButtonsEditModOp)
                    .subscribe((result) => {
                        this.hasEditAccess = result;
                    });
                //Complete button access
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.CompleteBtnEditModOp)
                    .subscribe((result) => {
                        this.canEditCompleteBtn = result;
                    });
            }
        });
        this.getColorCodes(this.moduleData?.capacityPlanningColor);

        this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site) {
                this.site = {
                    plantName: site.plantName,
                    plantId: site.plantId,
                };
            }
        });
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (
            changes["moduleData"] &&
            changes["moduleData"] !== null &&
            changes["moduleData"].currentValue
        ) {
            this.moduleData = changes["moduleData"].currentValue;
        }
        this.getOperationsData();
        this.getColorCodes(this.moduleData?.capacityPlanningColor);
    }

    public getOperationsData(): void {
        this.appStoreService.getLoggedInUser().subscribe((user) => {
            this.appStoreService.getUserDetails(user.mail).subscribe((res) => {
                if (res && res.username.length > 0) {
                    this.userId = res?.userId;
                    this.service
                        .getOperationsModuleData(
                            this.moduleData?.pilotProductID,
                            this.userId
                        )
                        .subscribe((res) => {
                            this.operationsData = res;
                            this.tempModuleData = res;
                            this.total = aggregateBy(
                                this.operationsData,
                                this.aggregates
                            );
                            this.isLoading = false;
                        });
                }
            });
        });

        if (this.moduleData != undefined) {
            this.service
                .getTestOrPostTestPercent(this.moduleData?.pilotProductID)
                .subscribe((res) => {
                    if (res.moduleProcess == null) {
                        this.testPercent = res;
                        this.postTestPercent = res;
                    } else if (res.moduleProcess == "Test") {
                        this.testPercent = res;
                    } else if (res.moduleProcess == "Post-Test") {
                        this.postTestPercent = res;
                    }
                });
        }
    }

    goToLogProgress(dataItem, workRecord, tabIndex, zoneId): void {
        //check if any operation is running for the loggedIn user or not
        this.service
            .getRunningOperation(workRecord.UserId, dataItem.operationId)
            .subscribe((res) => {
                // if this operation is running for the loggedIn user
                if (
                    res.operationID != null &&
                    res.operationID == dataItem.operationId
                ) {
                    // if the operation clicked is same as the one which is already running
                    this.router.navigate([
                        "/log-progress/" +
                            this.moduleData?.pilotProductID +
                            "/" +
                            dataItem?.operationId +
                            "/" +
                            tabIndex,
                    ]);
                } else {
                    this.service
                        .updateWorkRecordData(workRecord)
                        .subscribe((res) => {
                            if (res) {
                                // No operation is running for the loggedIn user
                                this.isSaveEnabled = false;
                                this.router.navigate([
                                    "/log-progress/" +
                                        this.moduleData?.pilotProductID +
                                        "/" +
                                        dataItem?.operationId +
                                        "/" +
                                        tabIndex,
                                ]);
                            } else {
                                this.message =
                                    "Different operation is already running, end that first to start another.";
                                this.showDialogbox = true;
                            }
                        });
                }
            });
    }

    onActionClick(dataItem, task, zoneId): void {
        this.appStoreService.getLoggedInUser().subscribe((res) => {
            this.appStoreService.getUserDetails(res.mail).subscribe((user) => {
                if (user && user.username?.length > 0) {
                    const workRecord = new WorkRecordViewModel();
                    workRecord.UserId = user.userId;
                    workRecord.PilotProductID = this.moduleData.pilotProductID;
                    workRecord.OperationId = dataItem.operationId;
                    workRecord.StartDateTime = new Date(
                        new Date().getTime() -
                            new Date().getTimezoneOffset() * 60000
                    );
                    workRecord.EndOrResume = false;
                    workRecord.IsRework = false;

                    if (task === "Rework") {
                        workRecord.IsRework = true;
                        this.goToLogProgress(dataItem, workRecord, 2, zoneId);
                    } else {
                        if (dataItem.action === "Resume") {
                            this.goToLogProgress(
                                dataItem,
                                workRecord,
                                0,
                                zoneId
                            );
                        } else {
                            this.service
                                .updateWorkRecordData(workRecord)
                                .subscribe((res) => {
                                    if (res != null) {
                                        this.isSaveEnabled = false;
                                        this.getOperationsData();
                                        this.router.navigate([
                                            "/log-progress/" +
                                                this.moduleData
                                                    ?.pilotProductID +
                                                "/" +
                                                dataItem?.operationId +
                                                "/" +
                                                0,
                                        ]);
                                    } else {
                                        this.message =
                                            "Different operation is already running, end that first to start another.";
                                        this.showDialogbox = true;
                                    }
                                });
                        }
                    }
                }
            });
        });
    }

    onPercentCompleteChange() {
        this.isSaveEnabled = true;
    }

    public getColorCodes(color: string) {
        switch (color?.trim()) {
            case "#000000":
            case "Black":
                this.moduleColorValue = { text: "Black", value: "#000000" };
                break;
            case "#a9a9a9":
            case "Dark Gray":
                this.moduleColorValue = { text: "Dark Gray", value: "#a9a9a9" };
                break;
            case "#ffffff":
            case "White":
                this.moduleColorValue = { text: "White", value: "#ffffff" };
                break;
            case "#d3d3d3":
            case "Light Gray":
                this.moduleColorValue = {
                    text: "Light Gray",
                    value: "#d3d3d3",
                };
                break;
            case "#0000ff":
            case "Blue":
                this.moduleColorValue = { text: "Blue", value: "#0000ff" };
                break;
            case "#add8e6":
            case "Light Blue":
                this.moduleColorValue = {
                    text: "Light Blue",
                    value: "#add8e6",
                };
                break;
            case "#008000":
            case "Green":
                this.moduleColorValue = { text: "Green", value: "#008000" };
                break;
            case "#00ffff":
            case "Cyan":
                this.moduleColorValue = { text: "Cyan", value: "#00ffff" };
                break;
            case "#90ee90":
            case "Light Green":
                this.moduleColorValue = {
                    text: "Light Green",
                    value: "#90ee90",
                };
                break;
            case "#ffff00":
            case "Yellow":
                this.moduleColorValue = { text: "Yellow", value: "#ffff00" };
                break;
            case "#a52a2a":
            case "Brown":
                this.moduleColorValue = { text: "Brown", value: "#a52a2a" };
                break;
            case "#ffa500":
            case "Orange":
                this.moduleColorValue = { text: "Orange", value: "#ffa500" };
                break;
            case "#d2b48c":
            case "Tan":
                this.moduleColorValue = { text: "Tan", value: "#d2b48c" };
                break;
            case "#ff0000":
            case "Red":
                this.moduleColorValue = { text: "Red", value: "#ff0000" };
                break;
            case "#800080":
            case "Purple":
                this.moduleColorValue = { text: "Purple", value: "#800080" };
                break;
            case "#ffc0cb":
            case "Pink":
                this.moduleColorValue = { text: "Pink", value: "#ffc0cb" };
                break;
            case "Unassigned":
                this.moduleColorValue = {
                    text: "Not Set",
                    value: "Unassigned",
                };
                break;
            default:
                this.moduleColorValue = {
                    text: "Not Set",
                    value: "Unassigned",
                };
                break;
        }
    }

    public createFormGroup(dataItem: any): FormGroup {
        return this.formBuilder.group({
            numberOfSteps: [
                dataItem.numberOfSteps,
                Validators.compose([
                    Validators.pattern("^(?!00)(?!000)[0-9]{1,3}"),
                ]),
            ],
        });
    }

    public cellClickHandler({
        sender,
        rowIndex,
        columnIndex,
        dataItem,
        isEdited,
    }) {
        //Prevent editing Steps for Audit operations
        if (
            !dataItem.opsDescription.includes("Cart Audit") &&
            !dataItem.opsDescription.includes("95% Audit")
        ) {
            if (!isEdited) {
                sender.editCell(
                    rowIndex,
                    columnIndex,
                    this.createFormGroup(dataItem)
                );
            }
        }
    }

    public cellCloseHandler(args: any) {
        const { formGroup, dataItem } = args;
        if (!formGroup.valid) {
            // prevent closing the edited cell if there are invalid values.
            args.preventDefault();
        } else if (formGroup.dirty) {
            this.editService.assignValues(dataItem, formGroup.value);
            this.editService.update(dataItem, "Edit-Mod-Operations");
            //call api to update steps
            this.service
                .updateSteps(dataItem, dataItem.operationId)
                .subscribe((res) => {
                    this.isSaveEnabled = true;
                    this.getOperationsData();
                });
        }
    }

    public aggregates: AggregateDescriptor[] = [
        { field: "opPercent", aggregate: "sum" },
        { field: "numberOfSteps", aggregate: "sum" },
        { field: "cycleTimeMinutes", aggregate: "sum" },
        { field: "cycleTimeMinutes", aggregate: "average" },
    ];

    public onStateChange(state: DataStateChangeEvent): void {
        this.state = state;
        this.operationsData = process(this.operationsData, this.state);
    }

    goToAuditOp(dataItem, zoneId) {
        this.router.navigate([
            "/audit-operations/" +
                this.moduleData?.pilotProductID +
                "/" +
                dataItem?.operationId +
                "/" +
                zoneId +
                "/" +
                0,
        ]);
    }

    OnComplete(dataItem) {
        dataItem.opPercent = 100;
        dataItem.status = "Green";
        this.service
            .updateAuditOpPercent(
                dataItem?.operationId,
                dataItem?.pilotProductID
            )
            .subscribe((res) => {
                if (res && res["value"] === "Updated Successfully") { }
            });
    }
}
