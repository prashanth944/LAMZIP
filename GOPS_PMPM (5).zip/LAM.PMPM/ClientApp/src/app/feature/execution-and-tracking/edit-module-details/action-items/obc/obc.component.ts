import {
    Component,
    Input,
    OnChanges,
    OnInit,
    SimpleChanges,
    ViewChild,
    ViewContainerRef,
    ViewEncapsulation,
} from "@angular/core";
import { Router } from "@angular/router";
import { Plant } from "../../../../../core/model/user.model";
import { DataServiceEandTService } from "../../../data-service-eand-t.service";
import { AppStoreService } from "../../../../../core/app-store.service";
import { OBCView } from "../../../Models/obc.model";
import {
    CompositeFilterDescriptor,
    distinct,
    filterBy,
} from "@progress/kendo-data-query";
import { process } from "@progress/kendo-data-query";
import { ModuleSummary } from "../../../Models/ModuleSummary";
import { TooltipDirective } from "@progress/kendo-angular-tooltip";
import { NotificationService } from "@progress/kendo-angular-notification";

@Component({
    selector: "pmpm-obc",
    templateUrl: "./obc.component.html",
    styleUrls: ["./obc.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class OBCComponent implements OnInit, OnChanges {
    @ViewChild(TooltipDirective) public tooltipDir: TooltipDirective;
    @Input() pilotProductId: number;
    @Input() site: Plant;

    public gridDataForOBCAddOpen: OBCView[] = [];
    public gridDataForOBCRTSOpen: OBCView[] = [];
    public gridDataForOBCAddComplete: OBCView[] = [];
    public gridDataForOBCRTSComplete: OBCView[] = [];

    public tempGridDataForOBCAddOpen: OBCView[] = [];
    public tempGridDataForOBCRTSOpen: OBCView[] = [];
    public tempGridDataForOBCAddComplete: OBCView[] = [];
    public tempGridDataForOBCRTSComplete: OBCView[] = [];

    public loadingCompleteTable = true;
    public loadingOpenTable = true;

    public filterAddOpenOBC: CompositeFilterDescriptor;
    public filterRTSOpenOBC: CompositeFilterDescriptor;
    public filterAddCompleteOBC: CompositeFilterDescriptor;
    public filterRTSCompleteOBC: CompositeFilterDescriptor;

    public rId: string;
    public moduleInfo: ModuleSummary = null;

    public optionsState = [
        "",
        "Not Started",
        "In Progress",
        "Removed",
        "Awaiting Lead Approval",
        "In Decon",
        "Ready for Disposition",
        "Scrapped",
        "Returned",
        "Bulk",
        "Installed",
        "Variance is an Error",
    ];
    @ViewChild("container", { read: ViewContainerRef })
    public container: ViewContainerRef;
    constructor(
        private service: DataServiceEandTService,
        private router: Router,
        private appStoreService: AppStoreService,
        private notificationService: NotificationService
    ) {}

    ngOnInit() {}
    ngOnChanges(changes: SimpleChanges) {
        if (
            changes["pilotProductId"] &&
            changes["pilotProductId"] !== null &&
            changes["pilotProductId"].currentValue
        ) {
            this.pilotProductId = changes["pilotProductId"].currentValue;
        }
        if (
            changes["site"] &&
            changes["site"] !== null &&
            changes["site"].currentValue
        ) {
            this.site = changes["site"].currentValue;
        }
        if (this.site !== undefined && this.pilotProductId !== undefined) {
            this.service
                .getModuleSummaryByID(+this.pilotProductId)
                .toPromise()
                .then((data) => {
                    if (data && data.length > 0) {
                        this.moduleInfo = data.filter(
                            (item) =>
                                +item.ModuleInfo.PilotProductID ===
                                +this.pilotProductId
                        )[0];
                        this.LoadDataForTables();
                    }
                });
        }
    }

    private LoadDataForTables() {
        if (
            this.site?.plantName === "Fremont" &&
            this.moduleInfo?.ModuleInfo?.PilotSerialNumber !== null
        ) {
            this.getOBCDetail(this.moduleInfo?.ModuleInfo?.PilotSerialNumber);
        } else if (
            this.site?.plantName !== "Fremont" &&
            this.moduleInfo?.ModuleInfo?.BEN !== null
        ) {
            this.getOBCDetail(this.moduleInfo?.ModuleInfo?.BEN);
        } else {
            this.loadingOpenTable = false;
            this.loadingCompleteTable = false;
        }
    }

    getOBCDetail(ben: string) {
        this.gridDataForOBCAddOpen = [];
        this.gridDataForOBCRTSOpen = [];
        this.service.GetOBCDetails("open", ben).subscribe((res) => {
            if (res && res.obcadd?.length > 0) {
                this.gridDataForOBCAddOpen = JSON.parse(
                    JSON.stringify(res.obcadd)
                );
                this.rId = this.gridDataForOBCAddOpen[0].id;
            }
            if (res && res.obcrts?.length > 0) {
                this.gridDataForOBCRTSOpen = JSON.parse(
                    JSON.stringify(res.obcrts)
                );
                this.rId = this.gridDataForOBCRTSOpen[0].id;
            }

            this.tempGridDataForOBCAddOpen = JSON.parse(
                JSON.stringify(this.gridDataForOBCAddOpen)
            );
            this.tempGridDataForOBCRTSOpen = JSON.parse(
                JSON.stringify(this.gridDataForOBCRTSOpen)
            );
            this.loadingOpenTable = false;
        });
        this.gridDataForOBCAddComplete = [];
        this.gridDataForOBCRTSComplete = [];
        this.service.GetOBCDetails("completed", ben).subscribe((res) => {
            if (res && res.obcadd?.length > 0) {
                this.gridDataForOBCAddComplete = res.obcadd;
                this.rId = this.gridDataForOBCAddComplete[0].id;
            }
            if (res && res.obcrts?.length > 0) {
                this.gridDataForOBCRTSComplete = res.obcrts;
                this.rId = this.gridDataForOBCRTSComplete[0].id;
            }

            this.tempGridDataForOBCAddComplete = JSON.parse(
                JSON.stringify(this.gridDataForOBCAddComplete)
            );
            this.tempGridDataForOBCRTSComplete = JSON.parse(
                JSON.stringify(this.gridDataForOBCRTSComplete)
            );
            this.loadingCompleteTable = false;
        });
    }

    onOBCLinkClick(recId: number) {
        if (this.site.plantName !== "Fremont") {
            const url =
                " https://lamresearch.quickbase.com/db/bprt8ii2f?a=er&rid=" +
                recId;
            window.open(url, "_blank");
        }
    }

    filterChangeAddOpenOBC(filter: CompositeFilterDescriptor): void {
        this.filterAddOpenOBC = filter;
        this.gridDataForOBCAddOpen = filterBy(
            this.tempGridDataForOBCAddOpen,
            filter
        );
    }

    filterChangeRTSOpenOBC(filter: CompositeFilterDescriptor): void {
        this.filterRTSOpenOBC = filter;
        this.gridDataForOBCRTSOpen = filterBy(
            this.tempGridDataForOBCRTSOpen,
            filter
        );
    }

    filterChangeAddCompleteOBC(filter: CompositeFilterDescriptor): void {
        this.filterAddCompleteOBC = filter;
        this.gridDataForOBCAddComplete = filterBy(
            this.tempGridDataForOBCAddComplete,
            filter
        );
    }

    filterChangeRTSCompleteOBC(filter: CompositeFilterDescriptor): void {
        this.filterRTSCompleteOBC = filter;
        this.gridDataForOBCRTSComplete = filterBy(
            this.tempGridDataForOBCRTSComplete,
            filter
        );
    }

    public distinctPrimitiveOpenAddOBC(fieldName: string): any {
        let data: any = distinct(this.tempGridDataForOBCAddOpen, fieldName).map(
            (item) => item[fieldName]
        );
        data = data.flatMap((f) => (f ? [f] : []));
        data.sort(function (a, b) {
            const textA = a?.toUpperCase();
            const textB = b?.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
        });
        return data;
    }
    public distinctPrimitiveOpenRTSOBC(fieldName: string): any {
        let data: any = distinct(this.tempGridDataForOBCRTSOpen, fieldName).map(
            (item) => item[fieldName]
        );
        data = data.flatMap((f) => (f ? [f] : []));
        data.sort(function (a, b) {
            const textA = a?.toUpperCase();
            const textB = b?.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
        });
        return data;
    }
    public distinctPrimitiveCompleteAddOBC(fieldName: string): any {
        let data: any = distinct(
            this.tempGridDataForOBCAddComplete,
            fieldName
        ).map((item) => item[fieldName]);
        data = data.flatMap((f) => (f ? [f] : []));
        data.sort(function (a, b) {
            const textA = a?.toUpperCase();
            const textB = b?.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
        });
        return data;
    }
    public distinctPrimitiveCompleteRTSOBC(fieldName: string): any {
        let data: any = distinct(
            this.tempGridDataForOBCRTSComplete,
            fieldName
        ).map((item) => item[fieldName]);
        data = data.flatMap((f) => (f ? [f] : []));
        data.sort(function (a, b) {
            const textA = a?.toUpperCase();
            const textB = b?.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
        });
        return data;
    }

    onSearchFilter(value) {
        this.onSearchOpenAddOBC(value);
        this.onSearchOpenRTSOBC(value);
        this.onSearchCompleteAddOBC(value);
        this.onSearchCompleteRTSOBC(value);
    }
    onSearchOpenAddOBC(value: string) {
        this.gridDataForOBCAddOpen = process(this.tempGridDataForOBCAddOpen, {
            filter: {
                logic: "or",
                filters: [
                    {
                        field: "id",
                        operator: "contains",
                        value: value,
                    },
                    {
                        field: "partNumber",
                        operator: "contains",
                        value: value,
                    },
                    {
                        field: "materialDescription",
                        operator: "contains",
                        value: value,
                    },
                ],
            },
        }).data;
    }
    onSearchOpenRTSOBC(value: string) {
        this.gridDataForOBCRTSOpen = process(this.tempGridDataForOBCRTSOpen, {
            filter: {
                logic: "or",
                filters: [
                    {
                        field: "id",
                        operator: "contains",
                        value: value,
                    },
                    {
                        field: "partNumber",
                        operator: "contains",
                        value: value,
                    },
                    {
                        field: "materialDescription",
                        operator: "contains",
                        value: value,
                    },
                ],
            },
        }).data;
    }
    onSearchCompleteAddOBC(value: string) {
        this.gridDataForOBCAddComplete = process(
            this.tempGridDataForOBCAddComplete,
            {
                filter: {
                    logic: "or",
                    filters: [
                        {
                            field: "id",
                            operator: "contains",
                            value: value,
                        },
                        {
                            field: "partNumber",
                            operator: "contains",
                            value: value,
                        },
                        {
                            field: "materialDescription",
                            operator: "contains",
                            value: value,
                        },
                    ],
                },
            }
        ).data;
    }
    onSearchCompleteRTSOBC(value: string) {
        this.gridDataForOBCRTSComplete = process(
            this.tempGridDataForOBCRTSComplete,
            {
                filter: {
                    logic: "or",
                    filters: [
                        {
                            field: "id",
                            operator: "contains",
                            value: value,
                        },
                        {
                            field: "partNumber",
                            operator: "contains",
                            value: value,
                        },
                        {
                            field: "materialDescription",
                            operator: "contains",
                            value: value,
                        },
                    ],
                },
            }
        ).data;
    }
    onOPenTraining() {
        const url =
            "https://lamresearch.sharepoint.com/:p:/r/sites/PilotMfg/_layouts/15/Doc.aspx?sourcedoc=%7BCEA313B1-CC3A-4FEE-A7DC-D3A4115331E8%7D&file=3006+-+Return+to+Stock.pptx&action=edit&mobileredirect=true&isSPOFile=1";
        window.open(url, "_blank");
    }
    public showTooltip(e: MouseEvent): void {
        const element = e.target as HTMLElement;
        if (
            (element.nodeName === "TD" || element.nodeName === "TH") &&
            element.offsetWidth < element.scrollWidth
        ) {
            this.tooltipDir.toggle(element);
        } else {
            this.tooltipDir.hide();
        }
    }
    onChangeState(idRow: any, event: any) {
        const newVal = event;
        
        this.service
            .UpdateRTSStatus({ Status: newVal, Id: idRow })
            .toPromise()
            .then(() => {
                this.LoadDataForTables();
                this.notificationService.show({
                    content: "Updated " + idRow,
                    appendTo: this.container,
                    position: { horizontal: "right", vertical: "top" },
                    type: { style: "success", icon: true },
                });
            })
            .catch((err) => {
                this.notificationService.show({
                    content: "Error",
                    appendTo: this.container,
                    position: { horizontal: "right", vertical: "top" },
                    type: { style: "error", icon: true },
                });
            });
    }
}
