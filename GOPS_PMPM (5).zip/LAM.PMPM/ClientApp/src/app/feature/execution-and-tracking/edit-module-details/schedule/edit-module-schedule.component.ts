import {
    ChangeDetectionStrategy,
    ChangeDetectorRef,
    Component,
    EventEmitter,
    Input,
    OnInit,
    Output,
    ViewChild,
    ViewContainerRef,
    ViewEncapsulation,
} from "@angular/core";
import { AppStoreService } from "../../../../core/app-store.service";
import { DataServiceEandTService } from "../../data-service-eand-t.service";
import {
    EditModuleViewModel,
    OperationPercentViewModel,
} from "../../Models/ModuleSummary";
import { EditService } from "src/app/feature/service/edit.service";
import { Router } from "@angular/router";
import { State, AggregateResult } from "@progress/kendo-data-query";
import {
    DataStateChangeEvent,
    GridDataResult,
} from "@progress/kendo-angular-grid";
import { Observable } from "rxjs";
import { FormBuilder } from "@angular/forms";
import { Plant, UserModel } from "../../../../core/model/user.model";
import { role, uiScreen } from "../../../../core/model/common.constant";
import { Item } from "../../../model/item";
import {
    EditModSched,
    EditModSchedSubassembly,
} from "../../Models/editModSched";
import { AdjustModuleService } from "../../../capacity-planning/adjust-module/adjust-module-service/adjustModule.service";
import * as moment from "moment";
import { NotificationService } from "@progress/kendo-angular-notification";

@Component({
    selector: "pmpm-edit-module-schedule",
    templateUrl: "./edit-module-schedule.component.html",
    styleUrls: ["./edit-module-schedule.component.css"],
    encapsulation: ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EditModuleScheduleComponent implements OnInit {
    @Input() moduleData: EditModuleViewModel;
    @Input() pilotProductID: number;
    @Output() isInWIP: EventEmitter<boolean> = new EventEmitter<boolean>();

    @ViewChild("appendTo", { read: ViewContainerRef })
    public appendTo: ViewContainerRef;

    public site: Plant;
    public userId: number;
    public operationsData: any;
    public tempModuleData: EditModuleViewModel;
    public moduleColorValue: { text: string; value: string };
    public isSaveEnabled = false;
    public isCollapsed = false;
    public testPercent: OperationPercentViewModel;
    public postTestPercent: OperationPercentViewModel;
    public message = "";
    public showDialogbox = false;
    public WIPFlag: boolean = null;
    public showRemoveFromWIPBtn = false;
    public Math: any;

    // Grid
    public mySelection: string[] = [];
    state: DataStateChangeEvent;
    public total: AggregateResult;
    public view: Observable<GridDataResult>;
    public changes: any = {};
    public gridState: State = {
        sort: [],
        skip: 0,
        take: 10,
    };

    editModuleSchedule: EditModSched;

    CommittedLaunchDateValue: Date;
    CommittedIntegrationDateValue: Date;
    CommittedTestStartDateValue: Date;
    CommittedTestCompleteDateValue: Date;
    CommittedPilotCompleteDateValue: Date;
    CommittedCrateCompleteDateValue: Date;

    ProjectedLaunchDateValue: Date;
    ProjectedIntegrationDateValue: Date;
    ProjectedTestStartDateValue: Date;
    ProjectedTestCompleteDateValue: Date;
    ProjectedPilotCompleteDateValue: Date;
    ProjectedCrateCompleteDateValue: Date;

    PlannedLaunchDateValue: Date;
    PlannedIntegrationDateValue: Date;
    PlannedTestStartDateValue: Date;
    PlannedTestCompleteDateValue: Date;
    PlannedPilotCompleteDateValue: Date;
    PlannedCrateCompleteDateValue: Date;

    ActualLaunchDateValue2: Date = new Date();
    ActualLaunchDateValue: Date;
    ActualIntegrationDateValue: Date;
    ActualTestStartDateValue: Date;
    ActualTestCompleteDateValue: Date;
    ActualPilotCompleteDateValue: Date;
    ActualCrateCompleteDateValue: Date;

    GapLaunchDateValue: number;
    GapIntegrationDateValue: number;
    GapTestStartDateValue: number;
    GapTestCompleteDateValue: number;
    GapPilotCompleteDateValue: number;
    GapCrateCompleteDateValue: number;

    TSDValue: Date;
    CRDValue: Date;
    MCSDValue: Date;
    PilotMCSDValue: Date;

    ActualCrateDateValue: Date;
    EarliestAllowedStartDateValue: Date;

    TargetTestDaysValue: number;
    IdleTestDaysValue: number;
    PostTestDaysValue = 1;

    prodStatusValue: { text: string; value: number };
    LaunchMissCategoryValue: { text: string; value: number };
    LaunchMissReasonValue: string;
    IntegrationMissCategoryValue: { text: string; value: number };
    IntegrationMissReasonValue: string;
    TestCompleteMissCategoryValue: { text: string; value: number };
    TestCompleteMissReasonValue: string;
    TeststartMissCategoryValue: { text: string; value: number };
    TeststartMissReasonValue: string;
    MfgCompleteMissCategoryValue: { text: string; value: number };
    MfgCompleteMissReasonValue: string;

    missCategoryItems: Item[] = [];
    buildScheduleItems: Item[] = [];

    public productionStatusItems: Item[] = [
        { text: "In Queue", value: 1 },
        { text: "In Assembly", value: 2 },
        { text: "In Test", value: 3 },
        { text: "In Post-Test", value: 5 },
        { text: "Crate Complete", value: 4 },
        { text: "On Hold", value: 6 },
    ];
    missCategoryValue: { text: string; value: number };
    buildScheduleValue: { text: string; value: number };
    missReasonValue = "";
    NoCapacityValue = true;
    InWip = false;

    public isUserAccess = false; //Authentication - Entire tab - View for Manager/Director, Project Manager, Supervisor, Lead
    canEditMissCat = false; //Authentication -US 36288: Miss Category, Miss Reason, Target Test Days, Idle Test Days - Edit for Manager / Director, Supervisor, Lead
    canModifyDates = false; //Authentication - Modify Dates - Edit for Manager/Director, Project Manager
    canModifyBsNoCap = false; //Authentication - Module Build Schedule, No Capacity Needed Checkbox, Prod Status - Edit for Manager / Director, Supervisor, Project Manager
    canModifyProdstatus = false; //Authentication -US 36288: Prod Status - Edit only for Manager/Director, Supervisor, Lead, Super user
    canModifyActualDates = false; //Authentication -US 36288: Actual Dates (Launch, Integration, Test) - Edit only for Manager/Director, Supervisor, Lead, Super user

    showDiffLaunch = true;
    showDiffIntegration = true;
    showDiffTestStart = true;
    showDiffTestComplete = true;
    showDiffMfgComplete = true;

    disableSave = true;

    minDate: Date = new Date(1900, 1, 1);
    userDetail: UserModel;

    //subassembly
    KitDeliveredDateValue: Date;
    KitRecievedDateValue: Date;
    ActualBuildCompleteValue: Date;
    ActualTestCompleteValue: Date;
    PilotMfgCompleteValue: Date;
    MfgCompleteValue: Date;
    CustomerReqDateValue: Date;
    //Authentication Subassembly
    rule1 = false; //Task 29163: Authentication - Schedule tab: [Date Delivered], [Kit Received Date], [Customer Request Date (CRD)] - Edit for PASS / PCFS, Manager / Director, Supervisor, Lead
    rule2 = false; //Task 29164: Authentication - Schedule tab: [Pilot Assembly Complete Date], [Pilot Test Complete Date], [Pilot Mfg Complete Date] - Edit for Manager / Director, Supervisor, Lead, Technician
    rule3 = false; //Task 29165: Authentication - Schedule tab: [Mfg Complete – Pilot Commit] - Edit for Manager/Director, Supervisor, Lead

    removeWIPConfirmation = false;

    public actualIntegrationStartIsManual = false;
    public actualTestStartIsManual = false;
    public actualTestCompleteIsManual = false;
    public actualManufacturingCompleteIsManual = false;

    public actualIntegrationStartManual: Date;
    public actualTestStartManual: Date;
    public actualTestCompleteManual: Date;
    public actualManufacturingCompleteManual: Date;

    constructor(
        private service: DataServiceEandTService,
        private appStoreService: AppStoreService,
        public editService: EditService,
        private router: Router,
        private formBuilder: FormBuilder,
        private notificationService: NotificationService,
        private changeDetector: ChangeDetectorRef,
        private adjustModuleService: AdjustModuleService
    ) {}

    ngOnInit(): void {
        this.Math = Math;
        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.EditModOp)
                    .subscribe((result) => {
                        this.isUserAccess = result;
                    });
            }
        });
        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.EditModSchedule)
                    .subscribe((result) => {
                        this.isUserAccess = result;

                        if (
                            res.includes(role.Manager) ||
                            res.includes(role.Leads) ||
                            res.includes(role.Supervisor) ||
                            res.includes(role.SuperUser)
                        ) {
                            this.canEditMissCat = true;
                        }
                        if (
                            res.includes(role.Manager) ||
                            res.includes(role.ProjectManager) ||
                            res.includes(role.SuperUser)
                        ) {
                            this.canModifyDates = true;
                        }
                        if (
                            res.includes(role.Manager) ||
                            res.includes(role.ProjectManager) ||
                            res.includes(role.Supervisor) ||
                            res.includes(role.SuperUser)
                        ) {
                            this.canModifyBsNoCap = true;
                        }
                        if (
                            res.includes(role.Manager) ||
                            res.includes(role.Supervisor) ||
                            res.includes(role.Leads) ||
                            res.includes(role.SuperUser)
                        ) {
                            this.canModifyProdstatus = true;
                        }
                        if (
                            res.includes(role.Manager) ||
                            res.includes(role.Leads) ||
                            res.includes(role.SuperUser)
                        ) {
                            this.canModifyActualDates = true;
                        }
                        if (
                            res.includes(role.Manager) ||
                            res.includes(role.Leads) ||
                            res.includes(role.Supervisor) ||
                            res.includes(role.SuperUser) ||
                            res.includes(role.PassTeamMember)
                        ) {
                            this.rule1 = true;
                        }
                        if (
                            res.includes(role.Manager) ||
                            res.includes(role.Leads) ||
                            res.includes(role.Supervisor) ||
                            res.includes(role.SuperUser) ||
                            res.includes(role.Technician)
                        ) {
                            this.rule2 = true;
                        }
                        if (
                            res.includes(role.Manager) ||
                            res.includes(role.Leads) ||
                            res.includes(role.Supervisor) ||
                            res.includes(role.SuperUser)
                        ) {
                            this.rule3 = true;
                        }
                    });
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.EditModRemoveFromWIP)
                    .subscribe((result) => {
                        this.showRemoveFromWIPBtn = true;
                    });
            }
        });
        this.appStoreService.getLoggedInUser().subscribe((user) => {
            this.appStoreService.getUserDetails(user.mail).subscribe((res) => {
                this.userDetail = res;
            });
        });
        if (this.moduleData?.inWIP) this.WIPFlag = true;
        else this.WIPFlag = false;

        this.getColorCodes(this.moduleData?.capacityPlanningColor);
        this.service.getMissCategoryDDL().subscribe((res) => {
            if (res) {
                res.forEach((val) => {
                    const it: Item = {
                        text: val.masterRecordName,
                        value: val.masterRecordID,
                    };
                    this.missCategoryItems.push(it);
                });
            }
        });
        this.adjustModuleService.getBuildScheduleDDL().subscribe((res) => {
            if (res) {
                res.forEach((val) => {
                    const bs: Item = {
                        text: val.masterRecordName.split(",")[0],
                        value: val.masterRecordID,
                    };
                    this.buildScheduleItems.push(bs);
                });
            }
        });
        this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site) {
                this.site = {
                    plantName: site.plantName,
                    plantId: site.plantId,
                };
                if (this.moduleData?.buildStyle !== "Special Subassembly") {
                    this.getEditModScheduledSummary();
                } else {
                    this.getScheduleSubassembly();
                }
            }
        });
    }

    getEditModScheduledSummary() {
        let date: any = new Date();
        date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
        this.service
            .getEditModScheduledSummary(
                this.pilotProductID,
                this.site.plantId,
                date
            )
            .subscribe((res) => {
                if (res) {
                    this.CommittedLaunchDateValue =
                        res.commitLaunch !== null
                            ? new Date(res.commitLaunch)
                            : null;
                    this.CommittedIntegrationDateValue =
                        res.committedIntegrationStart !== null
                            ? new Date(res.committedIntegrationStart)
                            : null;
                    this.CommittedTestStartDateValue =
                        res.committedTestStart !== null
                            ? new Date(res.committedTestStart)
                            : null;
                    this.CommittedTestCompleteDateValue =
                        res.committedTestComplete !== null
                            ? new Date(res.committedTestComplete)
                            : null;
                    this.CommittedPilotCompleteDateValue =
                        res.commitedManufacturingComplete !== null
                            ? new Date(res.commitedManufacturingComplete)
                            : null;
                    this.CommittedCrateCompleteDateValue = null;

                    this.ProjectedLaunchDateValue =
                        res.projectedLaunch !== null
                            ? new Date(res.projectedLaunch)
                            : null;
                    this.ProjectedIntegrationDateValue =
                        res.projectedIntegrationStart !== null
                            ? new Date(res.projectedIntegrationStart)
                            : null;
                    this.ProjectedTestStartDateValue =
                        res.projectedTestStart !== null
                            ? new Date(res.projectedTestStart)
                            : null;
                    this.ProjectedTestCompleteDateValue =
                        res.projectedTestComplete !== null
                            ? new Date(res.projectedTestComplete)
                            : null;
                    this.ProjectedPilotCompleteDateValue =
                        res.projectedManufacturingComplete !== null
                            ? new Date(res.projectedManufacturingComplete)
                            : null;
                    this.ProjectedCrateCompleteDateValue =
                        res.projectedCrateComplete !== null
                            ? new Date(res.projectedCrateComplete)
                            : null;

                    this.PlannedLaunchDateValue =
                        res.plannedLaunch !== null
                            ? new Date(res.plannedLaunch)
                            : null;
                    this.PlannedIntegrationDateValue =
                        res.plannedIntegrationStart !== null
                            ? new Date(res.plannedIntegrationStart)
                            : null;
                    this.PlannedTestStartDateValue =
                        res.plannedTestStart !== null
                            ? new Date(res.plannedTestStart)
                            : null;
                    this.PlannedTestCompleteDateValue =
                        res.plannedTestComplete !== null
                            ? new Date(res.plannedTestComplete)
                            : null;
                    this.PlannedPilotCompleteDateValue =
                        res.plannedManufacturingComplete !== null
                            ? new Date(res.plannedManufacturingComplete)
                            : null;
                    this.PlannedCrateCompleteDateValue =
                        res.plannedCrateComplete !== null
                            ? new Date(res.plannedCrateComplete)
                            : null;

                    this.ActualLaunchDateValue =
                        res.actualLaunch !== null
                            ? new Date(res.actualLaunch)
                            : null;
                    this.ActualIntegrationDateValue =
                        res.actualIntegrationStart !== null
                            ? new Date(res.actualIntegrationStart)
                            : null;
                    this.ActualTestStartDateValue =
                        res.actualTestStart !== null
                            ? new Date(res.actualTestStart)
                            : null;
                    this.ActualTestCompleteDateValue =
                        res.actualTestComplete !== null
                            ? new Date(res.actualTestComplete)
                            : null;
                    this.ActualPilotCompleteDateValue =
                        res.actualManufacturingComplete !== null
                            ? new Date(res.actualManufacturingComplete)
                            : null;
                    this.ActualCrateDateValue =
                        res.actualCrateComplete !== null
                            ? new Date(res.actualCrateComplete)
                            : null;

                    if (this.ActualTestCompleteDateValue !== null) {
                        this.PlannedTestCompleteDateValue =
                            this.ActualTestCompleteDateValue;
                    }

                    this.GapLaunchDateValue = this.getGap(
                        this.CommittedLaunchDateValue,
                        this.PlannedLaunchDateValue,
                        this.ActualLaunchDateValue
                    );
                    this.GapIntegrationDateValue = this.getGap(
                        this.CommittedIntegrationDateValue,
                        this.PlannedIntegrationDateValue,
                        this.ActualIntegrationDateValue
                    );
                    this.GapTestStartDateValue = this.getGap(
                        this.CommittedTestStartDateValue,
                        this.PlannedTestStartDateValue,
                        this.ActualTestStartDateValue
                    );
                    this.GapTestCompleteDateValue = this.getGap(
                        this.CommittedTestCompleteDateValue,
                        this.PlannedTestCompleteDateValue,
                        this.ActualTestCompleteDateValue
                    );
                    this.GapPilotCompleteDateValue = this.getGap(
                        this.CommittedPilotCompleteDateValue,
                        this.PlannedPilotCompleteDateValue,
                        this.ActualPilotCompleteDateValue
                    );
                    this.GapCrateCompleteDateValue = this.getGapCrate(
                        this.PlannedCrateCompleteDateValue,
                        this.ActualCrateDateValue
                    );

                    this.TSDValue =
                        res.targetShipDate !== null
                            ? new Date(res.targetShipDate)
                            : null;
                    this.PilotMCSDValue =
                        res.pilotManufacturingCommitedShipDate !== null
                            ? new Date(res.pilotManufacturingCommitedShipDate)
                            : null;
                    this.MCSDValue =
                        res.manufacturingCommitedShipDate !== null
                            ? new Date(res.manufacturingCommitedShipDate)
                            : null;
                    this.CRDValue =
                        res.customerRequestDate !== null
                            ? new Date(res.customerRequestDate)
                            : null;
                    this.ActualCrateDateValue =
                        res.actualCrateComplete !== null
                            ? new Date(res.actualCrateComplete)
                            : null;
                    this.EarliestAllowedStartDateValue =
                        res.earliestStartDate !== null
                            ? new Date(res.earliestStartDate)
                            : null;

                    this.TargetTestDaysValue = res.targetTestDays;
                    this.IdleTestDaysValue = res.idleTestDay;
                    this.PostTestDaysValue =
                        res.postTestDays !== null ? res.postTestDays : 1;

                    this.LaunchMissCategoryValue = {
                        text: res.launchMissCategory,
                        value: res.launchMissCategoryId,
                    };
                    this.LaunchMissReasonValue = res.launchMissReason;
                    this.IntegrationMissCategoryValue = {
                        text: res.integrationMissCategory,
                        value: res.integrationMissCategoryId,
                    };
                    this.IntegrationMissReasonValue = res.integrationMissReason;
                    this.TestCompleteMissCategoryValue = {
                        text: res.testCompleteMissCategory,
                        value: res.testCompleteMissCategoryId,
                    };
                    this.TestCompleteMissReasonValue =
                        res.testCompleteMissReason;
                    this.TeststartMissCategoryValue = {
                        text: res.teststartMissCategory,
                        value: res.teststartMissCategoryId,
                    };
                    this.TeststartMissReasonValue = res.teststartMissReason;
                    this.MfgCompleteMissCategoryValue = {
                        text: res.mfgCompleteMissCategory,
                        value: res.mfgCompleteMissCategoryId,
                    };
                    this.MfgCompleteMissReasonValue = res.mfgCompleteMissReason;

                    this.buildScheduleValue = {
                        text: res.buildScheduleName,
                        value: res.buildScheduleId,
                    };
                    this.NoCapacityValue = res.noCapacity;
                    this.prodStatusValue = {
                        text: res.productionStatus,
                        value: this.getValueFromText(
                            res.productionStatus,
                            "ps"
                        ),
                    };
                    this.InWip = res.inWIP !== null ? res.inWIP : false;
                    this.WIPFlag = res.inWIP !== null ? res.inWIP : false;
                    this.actualIntegrationStartIsManual =
                        res.actualIntegrationStartIsManual;
                    this.actualTestStartIsManual = res.actualTestStartIsManual;
                    this.actualTestCompleteIsManual =
                        res.actualTestCompleteIsManual;
                    this.actualManufacturingCompleteIsManual =
                        res.actualManufacturingCompleteIsManual;

                    this.CommittedLaunchDateValue =
                        res.commitLaunch !== null
                            ? new Date(res.commitLaunch)
                            : null;

                    this.actualIntegrationStartManual =
                        res.actualIntegrationStartManual !== null
                            ? new Date(res.actualIntegrationStartManual)
                            : null;
                    this.actualTestStartManual =
                        res.actualTestStartManual !== null
                            ? new Date(res.actualTestStartManual)
                            : null;
                    this.actualTestCompleteManual =
                        res.actualTestCompleteManual !== null
                            ? new Date(res.actualTestCompleteManual)
                            : null;
                    this.actualManufacturingCompleteManual =
                        res.actualManufacturingCompleteManual !== null
                            ? new Date(res.actualManufacturingCompleteManual)
                            : null;

                    this.onChangeTestDays();

                    this.changeDetector.detectChanges();
                }
            });
    }

    getScheduleSubassembly() {
        this.service
            .getScheduleSubassembly(this.pilotProductID)
            .subscribe((res) => {
                if (res) {
                    this.KitDeliveredDateValue =
                        res.kitDateDelivered !== null
                            ? new Date(res.kitDateDelivered)
                            : null;
                    this.KitRecievedDateValue =
                        res.kitReceivedDate !== null
                            ? new Date(res.kitReceivedDate)
                            : null;
                    this.ActualBuildCompleteValue =
                        res.actualTestStart !== null
                            ? new Date(res.actualTestStart)
                            : null;
                    this.ActualTestCompleteValue =
                        res.actualTestComplete !== null
                            ? new Date(res.actualTestComplete)
                            : null;
                    this.PilotMfgCompleteValue =
                        res.commitedManufacturingComplete !== null
                            ? new Date(res.commitedManufacturingComplete)
                            : null;
                    this.MfgCompleteValue =
                        res.pilotManufacturingCommitedShipDate !== null
                            ? new Date(res.pilotManufacturingCommitedShipDate)
                            : null;
                    this.CustomerReqDateValue =
                        res.customerRequestDate !== null
                            ? new Date(res.customerRequestDate)
                            : null;
                    this.InWip = res.inWIP;
                }
                this.changeDetector.detectChanges();
            });
    }
    getTextFromValue(id) {
        this.buildScheduleItems.forEach((val) => {
            if (val.value === id) {
                return val.text.split(",")[0];
            }
        });
        return "";
    }
    getTextFromValueMC(id) {
        this.missCategoryItems.forEach((val) => {
            if (val === id) {
                return val.text;
            }
        });
        return "";
    }
    getValueFromText(t, type) {
        let v = 0;
        if (type === "bs") {
            this.buildScheduleItems.forEach((val) => {
                if (val.text.split(",")[0] === t) {
                    v = val.value;
                }
            });
        }
        if (type === "ps") {
            this.productionStatusItems.forEach((val) => {
                if (val.text == t) {
                    v = val.value;
                }
            });
        }
        return v;
    }
    public getColorCodes(color: string) {
        switch (color?.trim()) {
            case "#000000":
            case "Black":
                this.moduleColorValue = { text: "Black", value: "#000000" };
                break;
            case "#a9a9a9":
            case "Dark Gray":
                this.moduleColorValue = { text: "Dark Gray", value: "#a9a9a9" };
                break;
            case "#ffffff":
            case "White":
                this.moduleColorValue = { text: "White", value: "#ffffff" };
                break;
            case "#d3d3d3":
            case "Light Gray":
                this.moduleColorValue = {
                    text: "Light Gray",
                    value: "#d3d3d3",
                };
                break;
            case "#0000ff":
            case "Blue":
                this.moduleColorValue = { text: "Blue", value: "#0000ff" };
                break;
            case "#add8e6":
            case "Light Blue":
                this.moduleColorValue = {
                    text: "Light Blue",
                    value: "#add8e6",
                };
                break;
            case "#008000":
            case "Green":
                this.moduleColorValue = { text: "Green", value: "#008000" };
                break;
            case "#00ffff":
            case "Cyan":
                this.moduleColorValue = { text: "Cyan", value: "#00ffff" };
                break;
            case "#90ee90":
            case "Light Green":
                this.moduleColorValue = {
                    text: "Light Green",
                    value: "#90ee90",
                };
                break;
            case "#ffff00":
            case "Yellow":
                this.moduleColorValue = { text: "Yellow", value: "#ffff00" };
                break;
            case "#a52a2a":
            case "Brown":
                this.moduleColorValue = { text: "Brown", value: "#a52a2a" };
                break;
            case "#ffa500":
            case "Orange":
                this.moduleColorValue = { text: "Orange", value: "#ffa500" };
                break;
            case "#d2b48c":
            case "Tan":
                this.moduleColorValue = { text: "Tan", value: "#d2b48c" };
                break;
            case "#ff0000":
            case "Red":
                this.moduleColorValue = { text: "Red", value: "#ff0000" };
                break;
            case "#800080":
            case "Purple":
                this.moduleColorValue = { text: "Purple", value: "#800080" };
                break;
            case "#ffc0cb":
            case "Pink":
                this.moduleColorValue = { text: "Pink", value: "#ffc0cb" };
                break;
            case "Unassigned":
                this.moduleColorValue = {
                    text: "Not Set",
                    value: "Unassigned",
                };
                break;
            default:
                this.moduleColorValue = {
                    text: "Not Set",
                    value: "Unassigned",
                };
                break;
        }
    }

    getDiffLaunch() {
        let diff = 0;
        if (this.showDiffLaunch) {
            if (
                this.ActualLaunchDateValue != null &&
                this.PlannedLaunchDateValue != null
            ) {
                this.ActualLaunchDateValue.setHours(0, 0, 0, 0);
                this.PlannedLaunchDateValue.setHours(0, 0, 0, 0);
                const m1 = moment(
                    new Date(this.ActualLaunchDateValue),
                    "DD-MM-YYYY"
                );
                const m2 = moment(
                    new Date(this.PlannedLaunchDateValue),
                    "DD-MM-YYYY"
                );
                diff = m2.diff(m1, "days");
            } else if (
                this.ProjectedLaunchDateValue != null &&
                this.PlannedLaunchDateValue != null
            ) {
                this.ProjectedLaunchDateValue.setHours(0, 0, 0, 0);
                this.PlannedLaunchDateValue.setHours(0, 0, 0, 0);
                const m1 = moment(
                    new Date(this.ProjectedLaunchDateValue),
                    "DD-MM-YYYY"
                );
                const m2 = moment(
                    new Date(this.PlannedLaunchDateValue),
                    "DD-MM-YYYY"
                );
                diff = m2.diff(m1, "days");
            }
        }
        if (diff >= 0) {
            this.LaunchMissReasonValue = "";
            this.LaunchMissCategoryValue = { text: "", value: 0 };
        }
        return diff;
    }
    getDiffIntegration() {
        let diff = 0;
        const date =
            this.actualIntegrationStartManual != null
                ? this.actualIntegrationStartManual
                : this.ActualIntegrationDateValue;
        if (date != null && this.PlannedIntegrationDateValue != null) {
            date.setHours(0, 0, 0, 0);
            this.PlannedIntegrationDateValue.setHours(0, 0, 0, 0);
            const m1 = moment(new Date(date), "DD-MM-YYYY");
            const m2 = moment(
                new Date(this.PlannedIntegrationDateValue),
                "DD-MM-YYYY"
            );
            diff = m2.diff(m1, "days");
        } else if (
            this.ProjectedIntegrationDateValue != null &&
            this.PlannedIntegrationDateValue != null
        ) {
            this.ProjectedIntegrationDateValue.setHours(0, 0, 0, 0);
            this.PlannedIntegrationDateValue.setHours(0, 0, 0, 0);
            const m1 = moment(
                new Date(this.ProjectedIntegrationDateValue),
                "DD-MM-YYYY"
            );
            const m2 = moment(
                new Date(this.PlannedIntegrationDateValue),
                "DD-MM-YYYY"
            );
            diff = m2.diff(m1, "days");
        }
        if (diff >= 0) {
            this.IntegrationMissReasonValue = "";
            this.IntegrationMissCategoryValue = { text: "", value: 0 };
        }
        return diff;
    }
    getDiffTestStart() {
        let diff = 0;
        const date =
            this.actualTestStartManual != null
                ? this.actualTestStartManual
                : this.ActualTestStartDateValue;
        if (date != null && this.PlannedTestStartDateValue != null) {
            date.setHours(0, 0, 0, 0);
            this.PlannedTestStartDateValue.setHours(0, 0, 0, 0);
            const m1 = moment(new Date(date), "DD-MM-YYYY");
            const m2 = moment(
                new Date(this.PlannedTestStartDateValue),
                "DD-MM-YYYY"
            );
            diff = m2.diff(m1, "days");
        } else if (
            this.ProjectedTestStartDateValue != null &&
            this.PlannedTestStartDateValue != null
        ) {
            this.ProjectedTestStartDateValue.setHours(0, 0, 0, 0);
            this.PlannedTestStartDateValue.setHours(0, 0, 0, 0);
            const m1 = moment(
                new Date(this.ProjectedTestStartDateValue),
                "DD-MM-YYYY"
            );
            const m2 = moment(
                new Date(this.PlannedTestStartDateValue),
                "DD-MM-YYYY"
            );
            diff = m2.diff(m1, "days");
        }
        if (diff >= 0) {
            this.TeststartMissReasonValue = "";
            this.TeststartMissCategoryValue = { text: "", value: 0 };
        }
        return diff;
    }
    getDiffTestComplete() {
        let diff = 0;
        const date =
            this.actualTestCompleteManual != null
                ? this.actualTestCompleteManual
                : this.ActualTestCompleteDateValue;
        if (date != null && this.PlannedTestCompleteDateValue != null) {
            date.setHours(0, 0, 0, 0);
            this.PlannedTestCompleteDateValue.setHours(0, 0, 0, 0);
            const m1 = moment(new Date(date), "DD-MM-YYYY");
            const m2 = moment(
                new Date(this.PlannedTestCompleteDateValue),
                "DD-MM-YYYY"
            );
            diff = m2.diff(m1, "days");
        } else if (
            this.ProjectedTestCompleteDateValue != null &&
            this.PlannedTestCompleteDateValue != null
        ) {
            this.ProjectedTestCompleteDateValue.setHours(0, 0, 0, 0);
            this.PlannedTestCompleteDateValue.setHours(0, 0, 0, 0);
            const m1 = moment(
                new Date(this.ProjectedTestCompleteDateValue),
                "DD-MM-YYYY"
            );
            const m2 = moment(
                new Date(this.PlannedTestCompleteDateValue),
                "DD-MM-YYYY"
            );
            diff = m2.diff(m1, "days");
        }
        if (diff >= 0) {
            this.TestCompleteMissReasonValue = "";
            this.TestCompleteMissCategoryValue = { text: "", value: 0 };
        }
        return diff;
    }
    getDiffMfgComplete() {
        let diff = 0;
        const date =
            this.actualManufacturingCompleteManual != null
                ? this.actualManufacturingCompleteManual
                : this.ActualPilotCompleteDateValue;
        if (date != null && this.PlannedPilotCompleteDateValue != null) {
            date.setHours(0, 0, 0, 0);
            this.PlannedPilotCompleteDateValue.setHours(0, 0, 0, 0);
            const m1 = moment(new Date(date), "DD-MM-YYYY");
            const m2 = moment(
              new Date(this.PlannedPilotCompleteDateValue),
                "DD-MM-YYYY"
            );
            diff = m2.diff(m1, "days");
        } else if (
            this.ProjectedPilotCompleteDateValue != null &&
            this.PlannedPilotCompleteDateValue != null
        ) {
            this.ProjectedPilotCompleteDateValue.setHours(0, 0, 0, 0);
            this.PlannedPilotCompleteDateValue.setHours(0, 0, 0, 0);
            const m1 = moment(
                new Date(this.ProjectedPilotCompleteDateValue),
                "DD-MM-YYYY"
            );
            const m2 = moment(
                new Date(this.PlannedPilotCompleteDateValue),
                "DD-MM-YYYY"
            );
            diff = m2.diff(m1, "days");
        }
        if (diff >= 0) {
            this.MfgCompleteMissReasonValue = "";
            this.MfgCompleteMissCategoryValue = { text: "", value: 0 };
        }
        return diff;
    }
    getFormattedDate(dt, flag = false) {
        if (
            this.checkInvalidYear(dt) > 1900 ||
            this.checkInvalidYear(dt) < 2099
        ) {
            if (dt != null && flag == true) {
                return moment(dt).format("M-D-YY");
            } else if (dt != null && flag == false) {
                return moment(dt).format("M-D");
            }
            return null;
        }
    }

    getFormattedDateForTestCompleteActual(flag = false) {
        if (this.TargetTestDaysValue < 0) this.TargetTestDaysValue = 0;
        if (this.IdleTestDaysValue < 0) this.IdleTestDaysValue = 0;

        const tt =
            this.TargetTestDaysValue != undefined
                ? this.TargetTestDaysValue
                : 0;
        const idtt =
            this.IdleTestDaysValue != undefined ? this.IdleTestDaysValue : 0;

        let date: Date;
        if (this.actualTestCompleteManual !== null) {
            date = this.actualTestCompleteManual;
        } else if (this.actualTestStartManual !== null) {
            date = new Date(
                moment(this.actualTestStartManual, "DD-MM-YYYY")
                    .add(tt + idtt, "days")
                    .toDate()
            );
        } else if (this.ActualTestStartDateValue !== null) {
            date = new Date(
                moment(this.ActualTestStartDateValue, "DD-MM-YYYY")
                    .add(tt + idtt, "days")
                    .toDate()
            );
        } else {
            date = this.ActualTestCompleteDateValue;
        }

        if (
            this.checkInvalidYear(date) > 1900 ||
            this.checkInvalidYear(date) < 2099
        ) {
            if (date != null && flag == true) {
                return moment(date).format("M-D-YY");
            } else if (date != null && flag == false) {
                return moment(date).format("M-D");
            }
            return null;
        }
    }

    getFormattedDateForPilotCompleteActual(flag = false) {
        if (this.TargetTestDaysValue < 0) this.TargetTestDaysValue = 0;
        if (this.IdleTestDaysValue < 0) this.IdleTestDaysValue = 0;
        if (this.PostTestDaysValue < 0) this.PostTestDaysValue = 0;

        const tt =
            this.TargetTestDaysValue != undefined
                ? this.TargetTestDaysValue
                : 0;
        const idtt =
            this.IdleTestDaysValue != undefined ? this.IdleTestDaysValue : 0;
        const ptd =
            this.PostTestDaysValue != undefined ? this.PostTestDaysValue : 0;

        let date: Date;
        if (this.actualManufacturingCompleteManual !== null) {
            date = this.actualManufacturingCompleteManual;
        } else if (this.actualTestCompleteManual !== null) {
            date = new Date(
                moment(this.actualTestCompleteManual, "DD-MM-YYYY")
                    .add(ptd, "days")
                    .toDate()
            );
        } else if (this.actualTestStartManual !== null) {
            date = new Date(
                moment(this.actualTestStartManual, "DD-MM-YYYY")
                    .add(tt + idtt + ptd, "days")
                    .toDate()
            );
        } else if (this.ActualTestStartDateValue !== null) {
            date = new Date(
                moment(this.ActualTestStartDateValue, "DD-MM-YYYY")
                    .add(tt + idtt + ptd, "days")
                    .toDate()
            );
        } else {
            date = this.ActualPilotCompleteDateValue;
        }

        if (
            this.checkInvalidYear(date) > 1900 ||
            this.checkInvalidYear(date) < 2099
        ) {
            if (date != null && flag == true) {
                return moment(date).format("M-D-YY");
            } else if (date != null && flag == false) {
                return moment(date).format("M-D");
            }
            return null;
        }
    }

    getGap(d1, d2, d3) {
        if (
            ((this.checkInvalidYear(d1) > 1900 ||
                this.checkInvalidYear(d1) < 2099) &&
                (this.checkInvalidYear(d2) > 1900 ||
                    this.checkInvalidYear(d2) < 2099) &&
                this.checkInvalidYear(d3) > 1900) ||
            this.checkInvalidYear(d3) < 2099
        ) {
            let diff = 0;
            if (d3 != null && d2 != null) {
                d3.setHours(0, 0, 0, 0);
                d2.setHours(0, 0, 0, 0);
                const m1 = moment(new Date(d3), "DD-MM-YYYY");
                const m2 = moment(new Date(d2), "DD-MM-YYYY");
                diff = m2.diff(m1, "days");
            }
            return diff;
        }
    }

    getGapCrate(d1, d2) {
        if (
            (this.checkInvalidYear(d1) > 1900 ||
                this.checkInvalidYear(d1) < 2099) &&
            (this.checkInvalidYear(d2) > 1900 ||
                this.checkInvalidYear(d2) < 2099)
        ) {
            let diff = 0;
            if (d2 != null && d1 != null) {
                d2.setHours(0, 0, 0, 0);
                d1.setHours(0, 0, 0, 0);
                const m1 = moment(new Date(d2), "DD-MM-YYYY");
                const m2 = moment(new Date(d1), "DD-MM-YYYY");
                diff = m2.diff(m1, "days");
            }
            return diff;
        }
    }

    onSaveChanges() {
        if (this.moduleData?.buildStyle !== "Special Subassembly") {
            this.saveEditModSchedule();
        } else {
            this.saveEditModSheduleSubassembly();
        }
    }
    saveEditModSchedule() {
        const editModSchedObj: EditModSched = {
            actualIntegrationStartManual: new Date(
                this.actualIntegrationStartManual?.getTime() -
                    new Date(
                        this.actualIntegrationStartManual
                    ).getTimezoneOffset() *
                        60000
            ),

            actualTestStartManual: new Date(
                this.actualTestStartManual?.getTime() -
                    new Date(this.actualTestStartManual).getTimezoneOffset() *
                        60000
            ),

            actualTestCompleteManual: new Date(
                this.actualTestCompleteManual?.getTime() -
                    new Date(
                        this.actualTestCompleteManual
                    ).getTimezoneOffset() *
                        60000
            ),

            actualManufacturingCompleteManual: new Date(
                this.actualManufacturingCompleteManual?.getTime() -
                    new Date(
                        this.actualManufacturingCompleteManual
                    ).getTimezoneOffset() *
                        60000
            ),

            ActualCrateComplete: new Date(
                this.ActualCrateDateValue?.getTime() -
                    new Date(this.ActualCrateDateValue).getTimezoneOffset() *
                        60000
            ),
            ActualIntegrationStart: new Date(
                this.ActualIntegrationDateValue?.getTime() -
                    new Date(
                        this.ActualIntegrationDateValue
                    ).getTimezoneOffset() *
                        60000
            ),
            ActualLaunch: new Date(
                this.ActualLaunchDateValue?.getTime() -
                    new Date(this.ActualLaunchDateValue).getTimezoneOffset() *
                        60000
            ),
            ActualManufacturingComplete: new Date(
                this.ActualPilotCompleteDateValue?.getTime() -
                    new Date(
                        this.ActualPilotCompleteDateValue
                    ).getTimezoneOffset() *
                        60000
            ),
            ActualTestComplete: new Date(
                this.ActualTestCompleteDateValue?.getTime() -
                    new Date(
                        this.ActualTestCompleteDateValue
                    ).getTimezoneOffset() *
                        60000
            ),
            ActualTestStart: new Date(
                this.ActualTestStartDateValue?.getTime() -
                    new Date(
                        this.ActualTestStartDateValue
                    ).getTimezoneOffset() *
                        60000
            ),
            BuildScheduleId: this.buildScheduleValue.value,
            CommitLaunch: new Date(
                this.CommittedLaunchDateValue?.getTime() -
                    new Date(
                        this.CommittedLaunchDateValue
                    ).getTimezoneOffset() *
                        60000
            ),
            CommittedIntegrationStart: new Date(
                this.CommittedIntegrationDateValue?.getTime() -
                    new Date(
                        this.CommittedIntegrationDateValue
                    ).getTimezoneOffset() *
                        60000
            ),
            CommittedTestComplete: new Date(
                this.CommittedTestCompleteDateValue?.getTime() -
                    new Date(
                        this.CommittedTestCompleteDateValue
                    ).getTimezoneOffset() *
                        60000
            ),
            CommittedTestStart: new Date(
                this.CommittedTestStartDateValue?.getTime() -
                    new Date(
                        this.CommittedTestStartDateValue
                    ).getTimezoneOffset() *
                        60000
            ),
            CrateCompleteGapDays: this.GapCrateCompleteDateValue,
            CRDCommited: new Date(
                this.CRDValue?.getTime() -
                    new Date(this.CRDValue).getTimezoneOffset() * 60000
            ),
            CustomerRequestDate: new Date(
                this.CRDValue?.getTime() -
                    new Date(this.CRDValue).getTimezoneOffset() * 60000
            ),
            EarliestStartDate: new Date(
                this.EarliestAllowedStartDateValue?.getTime() -
                    new Date(
                        this.EarliestAllowedStartDateValue
                    ).getTimezoneOffset() *
                        60000
            ),
            IdleTestDay: this.IdleTestDaysValue,
            InWIP: this.InWip,
            IntegrationGapDays: this.GapIntegrationDateValue,
            LaunchGapDays: this.GapLaunchDateValue,

            ManufacturingCommitedShipDate: new Date(
                this.MCSDValue?.getTime() -
                    new Date(this.MCSDValue).getTimezoneOffset() * 60000
            ),
            MCSDCommited: new Date(
                this.MCSDValue?.getTime() -
                    new Date(this.MCSDValue).getTimezoneOffset() * 60000
            ),
            NoCapacity: this.NoCapacityValue,
            PilotCompleteGapDays: this.GapPilotCompleteDateValue,
            PilotManufacturingCommitedShipDate: new Date(
                this.PilotMCSDValue?.getTime() -
                    new Date(this.PilotMCSDValue).getTimezoneOffset() * 60000 //changed from CommittedPilotCompleteDateValue
            ),
            PilotProductID: parseInt(this.pilotProductID.toString()),
            PlannedCrateComplete: new Date(
                this.PlannedCrateCompleteDateValue?.getTime() -
                    new Date(
                        this.PlannedCrateCompleteDateValue
                    ).getTimezoneOffset() *
                        60000
            ),
            PlannedIntegrationStart: new Date(
                this.PlannedIntegrationDateValue?.getTime() -
                    new Date(
                        this.PlannedIntegrationDateValue
                    ).getTimezoneOffset() *
                        60000
            ),
            PlannedLaunch: new Date(
                this.PlannedLaunchDateValue?.getTime() -
                    new Date(this.PlannedLaunchDateValue).getTimezoneOffset() *
                        60000
            ),
            PlannedManufacturingComplete: new Date(
                this.PlannedPilotCompleteDateValue?.getTime() -
                    new Date(
                        this.PlannedPilotCompleteDateValue
                    ).getTimezoneOffset() *
                        60000
            ),
            PlannedTestComplete: new Date(
                this.PlannedTestCompleteDateValue?.getTime() -
                    new Date(
                        this.PlannedTestCompleteDateValue
                    ).getTimezoneOffset() *
                        60000
            ),
            PlannedTestStart: new Date(
                this.PlannedTestStartDateValue?.getTime() -
                    new Date(
                        this.PlannedTestStartDateValue
                    ).getTimezoneOffset() *
                        60000
            ),
            PostTestDays: this.PostTestDaysValue,
            ProductionStatus: this.prodStatusValue.text,
            ProjectedCrateComplete: new Date(
                this.ProjectedCrateCompleteDateValue?.getTime() -
                    new Date(
                        this.ProjectedCrateCompleteDateValue
                    ).getTimezoneOffset() *
                        60000
            ),
            ProjectedIntegrationStart: new Date(
                this.ProjectedIntegrationDateValue?.getTime() -
                    new Date(
                        this.ProjectedIntegrationDateValue
                    ).getTimezoneOffset() *
                        60000
            ),
            ProjectedLaunch: new Date(
                this.ProjectedLaunchDateValue?.getTime() -
                    new Date(
                        this.ProjectedLaunchDateValue
                    ).getTimezoneOffset() *
                        60000
            ),
            ProjectedManufacturingComplete: new Date(
                this.ProjectedCrateCompleteDateValue?.getTime() -
                    new Date(
                        this.ProjectedCrateCompleteDateValue
                    ).getTimezoneOffset() *
                        60000
            ),
            ProjectedTestComplete: new Date(
                this.ProjectedTestCompleteDateValue?.getTime() -
                    new Date(
                        this.ProjectedTestCompleteDateValue
                    ).getTimezoneOffset() *
                        60000
            ),
            ProjectedTestStart: new Date(
                this.ProjectedTestStartDateValue?.getTime() -
                    new Date(
                        this.ProjectedTestStartDateValue
                    ).getTimezoneOffset() *
                        60000
            ),
            TargetShipDate: new Date(
                this.TSDValue?.getTime() -
                    new Date(this.TSDValue).getTimezoneOffset() * 60000
            ),
            TargetShipDateCommited: new Date(
                this.TSDValue?.getTime() -
                    new Date(this.TSDValue).getTimezoneOffset() * 60000
            ),
            TargetTestDays: this.TargetTestDaysValue,
            TestCompleteGapDays: this.GapTestCompleteDateValue,
            LaunchMissCategoryId:
                this.LaunchMissCategoryValue.value != 0
                    ? this.LaunchMissCategoryValue.value
                    : null,
            LaunchMissReason: this.LaunchMissReasonValue,
            IntegrationMissCategoryId:
                this.IntegrationMissCategoryValue.value != 0
                    ? this.IntegrationMissCategoryValue.value
                    : null,
            IntegrationMissReason: this.IntegrationMissReasonValue,
            TeststartMissCategoryId:
                this.TeststartMissCategoryValue.value != 0
                    ? this.TeststartMissCategoryValue.value
                    : null,
            TeststartMissReason: this.TeststartMissReasonValue,
            TestCompleteMissCategoryId:
                this.TestCompleteMissCategoryValue.value != 0
                    ? this.TestCompleteMissCategoryValue.value
                    : null,
            TestCompleteMissReason: this.TestCompleteMissReasonValue,
            MfgCompleteMissCategoryId:
                this.MfgCompleteMissCategoryValue.value != 0
                    ? this.MfgCompleteMissCategoryValue.value
                    : null,
            MfgCompleteMissReason: this.MfgCompleteMissReasonValue,
            TestDate:
                this.prodStatusValue?.text === "In Test" ||
                this.prodStatusValue?.text === "In Post-Test"
                    ? new Date(
                          new Date()?.getTime() -
                              new Date().getTimezoneOffset() * 60000
                      )
                    : new Date(),
            ModifiedBy: this.userDetail?.userId,
            ModifiedOn: new Date(
                new Date().getTime() - new Date().getTimezoneOffset() * 60000
            ),
        };
        this.service
            .updateModScheduleSummary(editModSchedObj)
            .subscribe((res) => {
                if (res) {
                    this.showSuccess("Saved");
                    this.disableSave = true;
                    this.getEditModScheduledSummary();
                }
            });
    }

    saveEditModSheduleSubassembly() {
        const editModSchedSubassemblyObj: EditModSchedSubassembly = {
            PilotProductID: +this.pilotProductID,
            KitDateDelivered: new Date(
                this.KitDeliveredDateValue?.getTime() -
                    new Date(this.KitDeliveredDateValue).getTimezoneOffset() *
                        60000
            ),
            KitReceivedDate: new Date(
                this.KitRecievedDateValue?.getTime() -
                    new Date(this.KitRecievedDateValue).getTimezoneOffset() *
                        60000
            ),
            ActualTestStart: new Date(
                this.ActualBuildCompleteValue?.getTime() -
                    new Date(
                        this.ActualBuildCompleteValue
                    ).getTimezoneOffset() *
                        60000
            ),
            ActualTestComplete: new Date(
                this.ActualTestCompleteValue?.getTime() -
                    new Date(this.ActualTestCompleteValue).getTimezoneOffset() *
                        60000
            ),
            CommitedManufacturingComplete: new Date(
                this.PilotMfgCompleteValue?.getTime() -
                    new Date(this.PilotMfgCompleteValue).getTimezoneOffset() *
                        60000
            ),
            PilotManufacturingCommitedShipDate: new Date(
                this.MfgCompleteValue?.getTime() -
                    new Date(this.MfgCompleteValue).getTimezoneOffset() * 60000
            ),
            CustomerRequestDate: new Date(
                this.CustomerReqDateValue?.getTime() -
                    new Date(this.CustomerReqDateValue).getTimezoneOffset() *
                        60000
            ),
            inWIP: this.InWip,
            ModifiedBy: this.userDetail?.userId,
            ModifiedOn: new Date(
                new Date().getTime() - new Date().getTimezoneOffset() * 60000
            ),
        };
        this.service
            .updateScheduleSubassembly(editModSchedSubassemblyObj)
            .subscribe((res) => {
                if (res) {
                    this.disableSave = true;
                    this.getEditModScheduledSummary();
                }
            });
    }
    public showSuccess(msg: string): void {
        this.notificationService.show({
            appendTo: this.appendTo,
            content: msg,
            position: { horizontal: "left", vertical: "bottom" },
            animation: { type: "fade", duration: 600 },
            type: { style: "success", icon: true },
        });
    }
    onChangeTestDays() {
        this.disableSave = false;
        if (this.TargetTestDaysValue < 0) this.TargetTestDaysValue = 0;
        if (this.IdleTestDaysValue < 0) this.IdleTestDaysValue = 0;
        if (this.PostTestDaysValue < 0) this.PostTestDaysValue = 0;

        const tt =
            this.TargetTestDaysValue != undefined
                ? this.TargetTestDaysValue
                : 0;
        const idtt =
            this.IdleTestDaysValue != undefined ? this.IdleTestDaysValue : 0;
        const ptd =
            this.PostTestDaysValue != undefined ? this.PostTestDaysValue : 0;

        const testStartDate =
            this.actualTestStartManual != null
                ? this.actualTestStartManual
                : this.ActualTestStartDateValue;

        if (testStartDate != null) {
            this.PlannedTestCompleteDateValue = new Date(
                moment(testStartDate, "DD-MM-YYYY")
                    .add(tt + idtt, "days")
                    .toDate()
            );
        } else if (this.PlannedTestStartDateValue != null) {
            this.PlannedTestCompleteDateValue = new Date(
                moment(this.PlannedTestStartDateValue, "DD-MM-YYYY")
                    .add(tt + idtt, "days")
                    .toDate()
            );
        }

        const testCompleteDate =
            this.actualTestCompleteManual != null
                ? this.actualTestCompleteManual
                : this.ActualTestCompleteDateValue;

        if (testCompleteDate != null) {
            this.PlannedPilotCompleteDateValue = new Date(
                moment(testCompleteDate, "DD-MM-YYYY").add(ptd, "days").toDate()
            );
        } else if (this.PlannedTestCompleteDateValue != null) {
            this.PlannedPilotCompleteDateValue = new Date(
                moment(this.PlannedTestCompleteDateValue, "DD-MM-YYYY")
                    .add(ptd, "days")
                    .toDate()
            );
        }
    }
    onChangeActualTestCompleteDays() {
        this.disableSave = false;
        this.onChangeTestDays();
        if (this.ActualTestCompleteDateValue == null) return;
        this.PlannedTestCompleteDateValue = this.ActualTestCompleteDateValue;
    }
    onChangeActualPilotCompleteDays() {
        this.disableSave = false;
        if (this.ActualPilotCompleteDateValue == null) return;
        this.PlannedPilotCompleteDateValue = this.ActualPilotCompleteDateValue;
    }
    removeFromWIP() {
        const dataToSend = {
            pilotProductID: +this.pilotProductID,
            wipFlat: false,
        };
        this.service
            .SetModuleWIPFlat(dataToSend)
            .toPromise()
            .then(() => {
                this.WIPFlag = false;
                this.InWip = false;
                this.removeWIPConfirmation = false;
                this.showSuccess("Removed from WIP");
                this.isInWIP.emit(true);
                this.changeDetector.detectChanges();
                this.disableSave = true;
            });
    }

    onPlannedLaunchDateChange(value: Date) {
        this.disableSave = false;
        if (
            this.checkInvalidYear(value) < 1900 ||
            this.checkInvalidYear(value) > 2099 ||
            value === null
        ) {
            this.PlannedLaunchDateValue = null;
            this.showDiffLaunch = false;
        } else {
            this.showDiffLaunch = true;
        }
    }
    onActualLaunchDateChange(value: Date) {
        this.disableSave = false;
        if (
            this.checkInvalidYear(value) < 1900 ||
            this.checkInvalidYear(value) > 2099 ||
            value === null
        ) {
            this.ActualLaunchDateValue = null;
            this.showDiffLaunch = false;
        } else {
            this.showDiffLaunch = true;
        }
    }
    onProjectedLaunchDateChange(value: Date) {
        this.disableSave = false;
        if (
            this.checkInvalidYear(value) < 1900 ||
            this.checkInvalidYear(value) > 2099 ||
            value === null
        ) {
            this.ProjectedLaunchDateValue = null;
            this.showDiffLaunch = false;
        } else {
            this.showDiffLaunch = true;
        }
    }

    onPlannedIntegrationDateChange(value: Date) {
        this.disableSave = false;
        if (
            this.checkInvalidYear(value) < 1900 ||
            this.checkInvalidYear(value) > 2099 ||
            value === null
        ) {
            this.PlannedIntegrationDateValue = null;
            this.showDiffIntegration = false;
        } else {
            this.showDiffIntegration = true;
        }
    }

    onActualIntegrationDateChange(value: Date) {
        this.disableSave = false;
        if (
            this.checkInvalidYear(value) < 1900 ||
            this.checkInvalidYear(value) > 2099 ||
            value === null
        ) {
            this.ActualIntegrationDateValue = null;
            this.showDiffIntegration = false;
        } else {
            this.showDiffIntegration = true;
        }
    }
    onProjectedIntegrationDateChange(value: Date) {
        this.disableSave = false;
        if (
            this.checkInvalidYear(value) < 1900 ||
            this.checkInvalidYear(value) > 2099 ||
            value === null
        ) {
            this.ProjectedIntegrationDateValue = null;
            this.showDiffIntegration = false;
        } else {
            this.showDiffIntegration = true;
        }
    }
    onPlannedTestStartDateChange(value: Date) {
        this.disableSave = false;
        this.onChangeTestDays();
        if (
            this.checkInvalidYear(value) < 1900 ||
            this.checkInvalidYear(value) > 2099 ||
            value === null
        ) {
            this.PlannedTestStartDateValue = null;
            this.showDiffTestStart = false;
        } else {
            this.showDiffTestStart = true;
        }
    }
    onActualTestStartDateChange(value: Date) {
        this.disableSave = false;
        this.onChangeTestDays();
        if (
            this.checkInvalidYear(value) < 1900 ||
            this.checkInvalidYear(value) > 2099 ||
            value === null
        ) {
            this.actualTestStartManual = null;
            this.showDiffTestStart = false;
        } else {
            this.onChangeTestDays();
            this.showDiffTestStart = true;
        }
    }
    onProjectedIntegrationTestDateChange(value: Date) {
        this.disableSave = false;
        this.onChangeTestDays();
        if (
            this.checkInvalidYear(value) < 1900 ||
            this.checkInvalidYear(value) > 2099 ||
            value === null
        ) {
            this.ProjectedIntegrationDateValue = null;
            this.showDiffTestStart = false;
        } else {
            this.onChangeTestDays();
            this.showDiffTestStart = true;
        }
    }
    onActualTestCompleteDateChange(value: Date) {
        this.disableSave = false;
        this.onChangeTestDays();
        if (
            this.checkInvalidYear(value) < 1900 ||
            this.checkInvalidYear(value) > 2099 ||
            value === null
        ) {
            this.ActualTestCompleteDateValue = null;
            this.showDiffTestComplete = false;
        } else {
            this.onChangeActualTestCompleteDays();
            this.showDiffTestComplete = true;
        }
    }
    onProjectedTestCompleteDateChange(value: Date) {
        this.disableSave = false;
        this.onChangeTestDays();
        if (
            this.checkInvalidYear(value) < 1900 ||
            this.checkInvalidYear(value) > 2099 ||
            value === null
        ) {
            this.ProjectedTestCompleteDateValue = null;
            this.showDiffTestComplete = false;
        } else {
            this.onChangeActualTestCompleteDays();
            this.showDiffTestComplete = true;
        }
    }
    onPlannedPilotCompleteDateChnage(value: Date) {
        this.disableSave = false;
        this.onChangeTestDays();
        if (
            this.checkInvalidYear(value) < 1900 ||
            this.checkInvalidYear(value) > 2099 ||
            value === null
        ) {
            this.PlannedPilotCompleteDateValue = null;
            this.showDiffMfgComplete = false;
        } else {
            this.onChangeActualPilotCompleteDays();
            this.showDiffMfgComplete = true;
        }
    }
    onActualPilotCompleteDateChnage(value: Date) {
        this.disableSave = false;
        this.onChangeTestDays();
        if (
            this.checkInvalidYear(value) < 1900 ||
            this.checkInvalidYear(value) > 2099 ||
            value === null
        ) {
            this.ActualPilotCompleteDateValue = null;
            this.showDiffMfgComplete = false;
        } else {
            this.onChangeActualPilotCompleteDays();
            this.showDiffMfgComplete = true;
        }
    }
    onProjectedPilotCompleteDateChnage(value: Date) {
        this.disableSave = false;
        this.onChangeTestDays();
        if (
            this.checkInvalidYear(value) < 1900 ||
            this.checkInvalidYear(value) > 2099 ||
            value === null
        ) {
            this.ProjectedPilotCompleteDateValue = null;
            this.showDiffMfgComplete = false;
        } else {
            this.onChangeActualPilotCompleteDays();
            this.showDiffMfgComplete = true;
        }
    }
    onTSDValueChange(value: Date) {
        if (
            this.checkInvalidYear(value) < 1900 ||
            this.checkInvalidYear(value) > 2099 ||
            value === null
        ) {
            this.TSDValue = null;
        }
        this.disableSave = false;
    }

    onMCSDValueChange(value: Date) {
        if (
            this.checkInvalidYear(value) < 1900 ||
            this.checkInvalidYear(value) > 2099 ||
            value === null
        ) {
            this.MCSDValue = null;
        }
        this.disableSave = false;
    }

    onCRDValueChange(value: Date) {
        if (
            this.checkInvalidYear(value) < 1900 ||
            this.checkInvalidYear(value) > 2099 ||
            value === null
        ) {
            this.CRDValue = null;
        }
        this.disableSave = false;
    }

    onActualCrateDateValueChange(value: Date) {
        if (
            this.checkInvalidYear(value) < 1900 ||
            this.checkInvalidYear(value) > 2099 ||
            value === null
        ) {
            this.ActualCrateDateValue = null;
        }
        this.disableSave = false;
    }
    onEarliestAllowedStartDateValueChange(value: Date) {
        if (
            this.checkInvalidYear(value) < 1900 ||
            this.checkInvalidYear(value) > 2099 ||
            value === null
        ) {
            this.EarliestAllowedStartDateValue = null;
        }
        this.disableSave = false;
    }

    onChange(value) {
        this.disableSave = false;
        this.onChangeTestDays();
    }
    onChangeMR(value) {
        this.disableSave = false;
    }
    onCancel() {
        this.disableSave = true;
        if (this.moduleData?.buildStyle !== "Special Subassembly") {
            this.getEditModScheduledSummary();
        } else {
            this.getScheduleSubassembly();
        }
    }

    private checkInvalidYear(data) {
        const date = new Date(data);
        return date.getFullYear();
    }

    openRemoveWIPConfirmation() {
        this.removeWIPConfirmation = true;
    }
    onCloseRemoveWIPConfirmation() {
        this.removeWIPConfirmation = false;
    }
}
