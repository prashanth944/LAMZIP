import { HttpClient } from "@angular/common/http";
import { Component, Input, OnInit, ViewEncapsulation } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { environment } from "../../../../../../../environments/environment.dev_server";
import { AppStoreService } from "../../../../../../core/app-store.service";
import { Plant } from "../../../../../../core/model/user.model";
import { DataServiceEandTService } from "../../../../data-service-eand-t.service";
import { TOI } from "../../../../Models/toi.model";
declare let require: any;

@Component({
    selector: "pmpm-view-toi",
    templateUrl: "./view-toi.component.html",
    styleUrls: ["./view-toi.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class ViewTOIComponent implements OnInit {
    readonly apiUrl = `${environment.apiUrl}`;
    public toiId: number;
    public toiDetails: TOI;
    public site: Plant;
    public toiComments = "";
    public toiDescription = "";
    public expectedCloseDate: Date;
    public gatingDate: Date;
    public minDate = new Date();
    public pilotProductId: number;
    public toiTitle = "";
    public uploadedFiles: string[] = [];

    constructor(
        private service: DataServiceEandTService,
        private route: ActivatedRoute,
        private appStoreService: AppStoreService,
        private router: Router,
        private http: HttpClient
    ) {}

    ngOnInit() {
        this.route.params.subscribe((param) => {
            this.toiId = param.toiId;
            this.pilotProductId = param.pilotProductId;
        });
        this.service.GetTOIView(this.toiId).subscribe((res) => {
            if (res && res.length > 0) {
                this.toiDetails = res[0];
                if (this.toiDetails.isCritical)
                    this.toiDetails.criticalGating = "Critical";
                else if (this.toiDetails.isGating)
                    this.toiDetails.criticalGating = "Gating";
                else this.toiDetails.criticalGating = "";
                this.toiDetails.comments = this.getNotesInDifferentLines(
                    this.toiDetails.comments
                );
                this.toiComments = this.toiDetails.comments;
                this.toiDescription = this.toiDetails.issueDescription;
                this.toiTitle = this.toiDetails.title;
                this.uploadedFiles = JSON.parse(
                    JSON.stringify(this.toiDetails.files)
                );
                if (this.toiDetails.expectedCloseDate !== null)
                    this.expectedCloseDate = new Date(
                        this.toiDetails.expectedCloseDate
                    );
                if (this.toiDetails.gatingDate !== null)
                    this.gatingDate = new Date(this.toiDetails.gatingDate);
            }
        });
        this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site) {
                this.site = {
                    plantName: site.plantName,
                    plantId: site.plantId,
                };
            }
        });
    }
    getNotesInDifferentLines(data) {
        let newNotes = "";
        if (data != null) {
            const notesArr = data.split("|");
            notesArr.forEach((val) => {
                if (val.trim() != "") newNotes = newNotes + val.trim() + "\n";
            });
        }
        return newNotes;
    }
    goBackToTOI() {
        let tabId = 0;
        if (this.site.plantName == "Fremont") tabId = 5;
        else tabId = 6;
        this.router
            .navigateByUrl("/", { skipLocationChange: true })
            .then(() => {
                this.router.navigate([
                    "/action-items/" + this.pilotProductId + "/" + tabId,
                ]);
            });
    }
    onGoToEditModHome() {
        this.router.navigate(["/edit-module/" + this.pilotProductId + "/" + 0]);
    }
    download(file: string) {
        this.http
            .get(
                this.apiUrl + "/TOI/downloadTOIfile/" + this.toiId + "/" + file,
                { responseType: "blob" }
            )
            .subscribe((result: any) => {
                if (result) {
                    const blob = new Blob([result]);
                    const saveAs = require("file-saver");
                    const fileName = file;
                    saveAs(blob, fileName);
                } else {
                    alert("File not found in Blob!");
                }
            });
    }
}
