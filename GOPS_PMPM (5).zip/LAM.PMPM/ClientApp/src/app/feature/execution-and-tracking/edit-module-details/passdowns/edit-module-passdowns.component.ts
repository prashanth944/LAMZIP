import {
  Component,
  Input,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from "@angular/core";
import { Router } from "@angular/router";
import { MultiSelectComponent } from "@progress/kendo-angular-dropdowns";
import {
  CompositeFilterDescriptor,
  distinct,
  filterBy,
} from "@progress/kendo-data-query";
import * as moment from "moment";
import { AppStoreService } from "../../../../core/app-store.service";
import { uiScreen } from "../../../../core/model/common.constant";
import { Plant, UserModel } from "../../../../core/model/user.model";
import { DataServiceEandTService } from "../../data-service-eand-t.service";
import {
  ModulePassdown,
  PassdownDisplay,
  PassdownTabs,
} from "../../Models/passdown.model";

@Component({
  selector: "pmpm-edit-module-passdowns",
  templateUrl: "./edit-module-passdowns.component.html",
  styleUrls: ["./edit-module-passdowns.component.css"],
  encapsulation: ViewEncapsulation.None,
})
export class EditModulePassdownsComponent implements OnInit {
  @ViewChild("multiselect") public multiselect: MultiSelectComponent;
  @Input() pilotProductId: number;
  passdowns: ModulePassdown[] = [];
  tempPassdowns: ModulePassdown[] = [];
  userDetail: UserModel;
  passdownDetails: PassdownDisplay;
  passdownTabs: PassdownTabs[] = [];
  searchText = "";
  filter: CompositeFilterDescriptor;
  dateValueItem: string[] = [];
  tempDateValueItem: string[] = [];
  dateDataItem: string[];
  isUserAccess = false;
  isLoading = true;
  site: Plant;
  showAddEditButton = false;

  constructor(
    private appStoreService: AppStoreService,
    private service: DataServiceEandTService,
    private router: Router
  ) { }

  ngOnInit() {
    this.appStoreService.getCurrentSite().subscribe((site) => {
      if (site) {
        this.site = {
          plantName: site.plantName,
          plantId: site.plantId,
        };
      }
    });

    this.appStoreService.getUserRoles().subscribe((res) => {
      if (res && res.length > 0) {
        this.appStoreService
          .checkUserAccessRight(res, uiScreen.Passdown)
          .subscribe((result) => {
            this.isUserAccess = result;
          });
      }
    });

    this.appStoreService.getLoggedInUser().subscribe((user) => {
      this.appStoreService.getUserDetails(user.mail).subscribe((res) => {
        if (res) {
          this.userDetail = res;
          let date: any = new Date();
          date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
          this.service
            .GetShowPassdownButtons(this.userDetail.shiftID, date)
            .subscribe((res) => {
              this.showAddEditButton = res;
              this.getPassdown();
            });
        }
      });
    });

    this.service.GetPassdownTabs(+this.pilotProductId).subscribe((res) => {
      if (res && res.length > 0) this.passdownTabs = res;
    });
  }
  getPassdown() {
    let date: any = new Date();
    date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
    this.service
      .GetPassdownsByPPId(
        +this.pilotProductId,
        this.userDetail?.shiftID,
        date
      )
      .subscribe((res) => {
        if (res) {
          this.passdowns = res;
          this.tempPassdowns = JSON.parse(
            JSON.stringify(this.passdowns)
          );
          this.dateValueItem = [];
          this.tempDateValueItem = [];
          const data = distinct(
            this.tempPassdowns,
            "passdownDate"
          ).map((item) => item["passdownDate"]);
          if (data.length > 0) {
            data.forEach((item) => {
              this.dateValueItem.push(
                moment(item).format("MM-DD-yyyy")
              );
            });
            this.tempDateValueItem = JSON.parse(
              JSON.stringify(this.dateValueItem)
            );
          }
        }
        this.isLoading = false;
      });
  }

  onPanelChange(event, passdown: ModulePassdown) {
    let date: any = new Date();
    date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
    this.passdownDetails = null;
    if (event[0]?.expanded) {
      this.service
        .GetDisplayPassdown(
          +this.pilotProductId,
          this.userDetail?.shiftID,
          passdown.passdownId,
          false,
          date
        )
        .subscribe((res) => {
          this.passdownDetails = res;
          if (
            this.passdownDetails?.issues?.openCriticalGatingTOIs
              ?.length > 0
          ) {
            this.passdownDetails?.issues?.openCriticalGatingTOIs.forEach(
              (item) => {
                item.issueDescriptionWithoutTag =
                  item.issueDescription.replace(
                    /<[^>]*>/g,
                    ""
                  );
              }
            );
          }
        });
    }
    this.passdowns.forEach((item) => {
      if (item.passdownId !== passdown.passdownId) {
        item.isExpand = false;
      } else {
        item.isExpand = true;
      }
    });
    this.searchText = "";
  }

  goToGenPassdown(passdownId) {
    this.router.navigate([
      "/gen-passdowns/" + this.pilotProductId + "/" + passdownId,
    ]);
  }

  isShowSubAssemblySection(): boolean {
    return (
      this.passdownTabs.filter((item) => item.tabName === "Assembly")
        ?.length > 0 &&
      this.passdownDetails &&
      this.passdownDetails?.passdownAssemblyOperationAuditItemsDetail !==
      undefined &&
      this.passdownDetails?.passdownAssemblyOperationAuditItemsDetail !==
      null &&
      (this.passdownDetails?.passdownAssemblyOperationAuditItemsDetail
        .nextSteps !== null ||
        this.passdownDetails?.passdownAssemblyOperationAuditItemsDetail
          .notes !== null ||
        this.passdownDetails?.passdownAssemblyOperationAuditItemsDetail
          .opCompleted !== null ||
        this.passdownDetails?.passdownAssemblyOperationAuditItemsDetail
          .rework !== null ||
        this.passdownDetails?.passdownAssemblyOperationAuditItemsDetail
          .opProgressed !== null ||
        this.passdownDetails?.passdownAssemblyOperationAuditItemsDetail
          .opSkipped !== null)
    );
  }
  isShowTestSection(): boolean {
    return (
      this.passdownTabs.filter((item) => item.tabName === "Test")
        ?.length > 0 &&
      this.passdownDetails &&
      this.passdownDetails?.passdownTestDetail !== undefined &&
      this.passdownDetails?.passdownTestDetail !== null &&
      (this.passdownDetails?.passdownTestDetail.opCompleted !== null ||
        this.passdownDetails?.passdownTestDetail.nextSteps !== null ||
        this.passdownDetails?.passdownTestDetail.notes !== null ||
        this.passdownDetails?.passdownTestDetail.opProgressed !==
        null ||
        this.passdownDetails?.passdownTestDetail.opSkipped !== null ||
        this.passdownDetails.passdownTestDetail.specialInstructions !==
        null)
    );
  }

  handleDateFilter(value) {
    if (value.length >= 0) {
      this.dateValueItem = this.tempDateValueItem.filter(
        (s) => s?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
      );
    } else {
      this.multiselect.toggle(false);
    }
  }
  onSearchFilter() {
    const filter: CompositeFilterDescriptor = { filters: [], logic: "and" };

    if (this.dateDataItem && this.dateDataItem.length > 0) {
      const data2: any[] = [];
      this.dateDataItem.forEach((item) => {
        data2.push({
          field: "passdownDate",
          operator: "contains",
          value: moment(item).format("yyyy-MM-DD"),
        });
      });
      filter.filters.push({ filters: [...data2], logic: "or" });
    }

    this.filter = filter;
    this.passdowns = filterBy(this.tempPassdowns, filter);
  }

  onSearchPassdown() {
    if (this.searchText && this.searchText.length > 0) {
      if (this.site?.plantName === 'Fremont') {
        this.passdowns = [
          ...this.tempPassdowns.filter(
            (item) =>
              (
                item.pilotSerialNumber +
                " - " +
                item?.toolTypeName +
                " - " +
                item.shiftType +
                " Shift Passdown - " +
                moment(item.passdownDate).format("MM-DD-yyyy")
              ).toLowerCase().indexOf(this.searchText.toLowerCase()) !== -1
          ),
        ];
      } else {
        this.passdowns = [
          ...this.tempPassdowns.filter(
            (item) =>
              (
                item.ben +
                " - " +
                item?.toolTypeName +
                " - " +
                item.shiftType +
                " Shift Passdown - " +
                moment(item.passdownDate).format("MM-DD-yyyy")
              ).toLowerCase().indexOf(this.searchText.toLowerCase()) !== -1
          ),
        ];
      }

      if (this.passdowns && this.passdowns.length > 0) {
        this.passdowns[0].isExpand = true;
        let date: any = new Date();
        date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
        this.passdownDetails = null;
        this.service
          .GetDisplayPassdown(
            +this.pilotProductId,
            this.userDetail?.shiftID,
            this.passdowns[0].passdownId,
            false,
            date
          )
          .subscribe((res) => {
            this.passdownDetails = res;
            if (
              this.passdownDetails?.issues?.openCriticalGatingTOIs
                ?.length > 0
            ) {
              this.passdownDetails?.issues?.openCriticalGatingTOIs.forEach(
                (item) => {
                  item.issueDescriptionWithoutTag =
                    item.issueDescription.replace(
                      /<[^>]*>/g,
                      ""
                    );
                }
              );
            }
          });
      } else {
        this.passdowns.forEach((item) => {
          item.isExpand = false;
        });
      }
    } else {
      this.passdowns = [...this.tempPassdowns];
      this.passdowns.forEach((item) => {
        item.isExpand = false;
      });
    }
  }

  goToTOI(toiid: number) {
    this.router.navigate([
      "/view-toi/" + toiid + "/" + this.pilotProductId,
    ]);
  }

  goToIssueLog(recId: number) {
    if (this.site?.plantName === "Fremont") {
      window.open(
        "https://lamresearch.quickbase.com/db/bgmh64wg7?a=dr&rid=" +
        recId,
        "_blank"
      );
    } else {
      window.open(
        "https://lamresearch.quickbase.com/db/bhmqdixgx?a=dr&rid=" +
        recId,
        "_blank"
      );
    }
  }

  goToNCI(iQMSID: number) {
    window.open(
      "https://trackwise.lamresearch.com/trackwise/Gateway.html?" +
      iQMSID,
      "_blank"
    );
  }

  goToOBC(recId: number) {
    if (this.site?.plantName !== "Fremont") {
      const url =
        " https://lamresearch.quickbase.com/db/bprt8ii2f?a=er&rid=" +
        recId;
      window.open(url, "_blank");
    }
  }

  getIsEditable() {
    return this.passdowns.filter(item => item.createdById === this.userDetail.userId)[0].isEditable
  }
}
