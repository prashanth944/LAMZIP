import { HttpClient } from "@angular/common/http";
import {
    Component,
    EventEmitter,
    Input,
    OnChanges,
    OnInit,
    Output,
    SimpleChanges,
    ViewEncapsulation,
} from "@angular/core";
import { environment } from "../../../../../../../environments/environment.dev_server";
import { AppStoreService } from "../../../../../../core/app-store.service";
import { uiScreen } from "../../../../../../core/model/common.constant";
import { UserModel } from "../../../../../../core/model/user.model";
import { DataServiceEandTService } from "../../../../data-service-eand-t.service";
import {
    CompositeFilterDescriptor,
    distinct,
    filterBy,
} from "@progress/kendo-data-query";
import * as moment from "moment";
declare let require: any;

@Component({
    selector: "pmpm-complete-items",
    templateUrl: "./complete-items.component.html",
    styleUrls: ["./complete-items.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class CompleteItemsComponent implements OnInit, OnChanges {
    @Input() completeItems: any = [];
    @Input() userDetails: UserModel;
    @Output() reload: EventEmitter<any> = new EventEmitter<any>();

    //photos
    readonly apiUrl = `${environment.apiUrl}`;
    public auditItemId: number;
    public hasDeleteAccess = false;
    public tempCompleteItems: any = [];
    public filter: CompositeFilterDescriptor;
    public currentRowData: any;
    public showDialogbox = false;
    public message = "";

    constructor(
        private http: HttpClient,
        private service: DataServiceEandTService,
        private appStore: AppStoreService
    ) {}

    ngOnInit(): void {
        this.appStore.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                this.appStore
                    .checkUserAccessRight(res, uiScreen.AuditItemsDeleteFile)
                    .subscribe((result) => {
                        this.hasDeleteAccess = result;
                    });
            }
        });
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (
            changes["completeItems"] &&
            changes["completeItems"] !== null &&
            changes["completeItems"].currentValue
        ) {
            this.completeItems = changes["completeItems"].currentValue;
            this.tempCompleteItems = JSON.parse(
                JSON.stringify(this.completeItems)
            );
        }
    }

    //Photos
    handleCompletedFiles(
        beforeOrAfter: string,
        files: FileList,
        inputType: string
    ) {
        if (files != undefined && files.length > 0) {
            for (let i = 0; i < files.length; i++) {
                if (
                    this.currentRowData.afterPicture != undefined &&
                    this.currentRowData.afterPicture.indexOf(files[i].name) >= 0
                ) {
                    (<HTMLInputElement>(
                        document.getElementById(inputType)
                    )).value = "";
                    this.message = "Duplicate file name(s) are not allowed.";
                    this.showDialogbox = true;
                    break;
                }
            }
        }

        if (files != undefined && files.length > 0) {
            this.uploadFiles(this.auditItemId, beforeOrAfter, files);
        }
    }

    castToDate(info: string) {
        if (info) {
            return moment(info).format("MM-DD-YY HH:mm:ss a");
        } else {
            return "";
        }
    }

    uploadFiles(auditItemID, beforeOrAfter, files) {
        const formData: FormData = new FormData();
        for (let i = 0; i < files.length; i++) {
            formData.append("fileKey", files[i], files[i].name);
        }

        this.service
            .uploadAuditFile(auditItemID, beforeOrAfter, formData)
            .subscribe((req) => {
                if (req && req["value"] === "Updated Successfully") {
                    this.reload.emit(true);
                }
            });
    }

    deleteFile(auditItemID, beforeOrAfter, file, inputType) {
        this.service
            .deleteAuditFile(auditItemID, beforeOrAfter, file)
            .subscribe((req) => {
                if (req && req["value"] === "Deleted Successfully") {
                    (<HTMLInputElement>(
                        document.getElementById(inputType)
                    )).value = "";
                    this.reload.emit(true);
                } else {
                    console.log("An Error occured deleting some files.");
                }
            });
    }

    download(auditItemID, beforeOrAfter, file) {
        this.http
            .get(
                this.apiUrl +
                    "/AuditItem/downloadfile/" +
                    auditItemID +
                    "/" +
                    beforeOrAfter +
                    "/" +
                    file,
                { responseType: "blob" }
            )
            .subscribe((result: any) => {
                if (result) {
                    const blob = new Blob([result]);
                    const saveAs = require("file-saver");
                    const fileName = file;
                    saveAs(blob, fileName);
                } else {
                    alert("File not found in Blob!");
                }
            });
    }

    setAuditItemId(dataItem, inputType) {
        this.currentRowData = dataItem;
        this.auditItemId = dataItem.auditItemId;
        const input = document.getElementById(inputType);
        input.click();
    }

    public filterChange(filter: CompositeFilterDescriptor): void {
        this.filter = filter;
        this.completeItems = filterBy(this.tempCompleteItems, filter);
    }

    public distinctPrimitive(fieldName: string): any {
        return distinct(this.tempCompleteItems, fieldName).map(
            (item) => item[fieldName]
        );
    }
}
