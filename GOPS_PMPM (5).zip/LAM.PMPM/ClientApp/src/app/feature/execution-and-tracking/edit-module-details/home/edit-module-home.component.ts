import {
    Component,
    EventEmitter,
    Input,
    OnChanges,
    OnInit,
    Output,
    ViewChild,
    ViewContainerRef,
    ViewEncapsulation,
} from "@angular/core";
import { NotificationService } from "@progress/kendo-angular-notification";
import { AppStoreService } from "../../../../core/app-store.service";
import { role, uiScreen } from "../../../../core/model/common.constant";
import { Plant, UserModel } from "../../../../core/model/user.model";
import { AdjustModuleService } from "../../../capacity-planning/adjust-module/adjust-module-service/adjustModule.service";
import { Item } from "../../../model/item";
import { DataServiceEandTService } from "../../data-service-eand-t.service";
import { EditModuleViewModel } from "../../Models/ModuleSummary";

@Component({
    selector: "pmpm-edit-module-home",
    templateUrl: "./edit-module-home.component.html",
    styleUrls: ["./edit-module-home.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class EditModuleHomeComponent implements OnInit, OnChanges {
    @ViewChild("appendTo", { read: ViewContainerRef })
    public appendTo: ViewContainerRef;
    @Input() pilotProductID: number;
    @Output() buildStyle: EventEmitter<string> = new EventEmitter<string>();
    public value = 35;
    public moduleData: EditModuleViewModel;
    public tempModuleData: EditModuleViewModel;
    public site: Plant;
    public buildType: Item[] = [];
    public productTypeGroup: Item[] = [];
    public buildTypeValue: { text: string; value: number };
    public productTypeValue: { text: string; value: number };
    public moduleColor: Item[] = [];
    public customer: Item[] = [];
    public buildStyleItem: Item[] = [];
    public productionStatusValue: { text: string; value: number };
    public pilotRiskLevelValue: { text: string; value: number };
    public customerValue: { text: string; value: number };
    public moduleColorValue: { text: string; value: string };
    public productManager = "";
    public programManager = "";
    public pilotToolType = "";
    public systemProjectManager = "";
    public scheduler = "";
    public mfgEngineer = "";
    public testEngineer = "";
    public note = "";
    public isSaveEnabled = false;
    public isCancelEnabled = false;
    public pilotRiskLevel: Item[] = [
        { text: "", value: 0 },
        { text: "LOW", value: 1 },
        { text: "MEDIUM", value: 2 },
        { text: "HIGH", value: 3 },
        { text: "MISS", value: 4 },
    ];
    public prodction: Item[] = [
        { text: "In Queue", value: 1 },
        { text: "In Assembly", value: 2 },
        { text: "In Test", value: 3 },
        { text: "In Post-Test", value: 5 },
        { text: "Crate Complete", value: 4 },
        { text: "On Hold", value: 6 },
    ];
    public isUserAccess = false;
    public canUserView = false;
    public isLoading = true;
    public canEditBuildStyle = false; //Task 25383: Authentication - "Build Style" and "Build Type" dropdowns - Edit for Super User
    public canEditBuildType = false;
    public showRemoveFromWIPBtn = false;
    public buildStyleValue: { text: string; value: number };
    public WIPFlag: boolean = null;
    public demandType: Item[] = [];
    public po: string;
    public partNumber: string;
    public serialNum: string;
    public qty: number;
    public demandTypeID: number;
    public demandTypeValue: { text: string; value: number };
    public partDescription: string;
    public PCWOReleased: boolean;
    public hot: boolean;
    public rework: boolean;
    public spclProcess: boolean;
    public plannerName: string;
    public engineeringPOC: string;
    public techBuild: string;
    public techTest: string;
    public auditor: string;

    //Authentication Edit mod home subassembly
    rule1 = false; //Task 29155: Authentication - Home tab: [PC WO Released] - Edit for PASS/PCFS
    rule2 = false; //Task 29156: Authentication - Home tab: [PO/WO #], [Hot], [Rework], [SPCL Process], [Demand Type], [Qty], [Planner] - Edit for PASS / PCFS, Manager / Director, Supervisor, Lead
    rule3 = false; //Task 29157: Authentication - Home tab: [Production Color] - Edit for Manager/Director, Supervisor, Lead
    rule4 = false; //Task 29158: Authentication - Home tab: [Serial #], [Technician – Build], [Technician – Test] - Edit for Manager / Director, Supervisor, Lead, Technician
    rule5 = false; //Task 29159: Authentication - Home tab: [Engineering POC] - Edit for Engineer, Manager/Director, Supervisor, Lead

    moduleProcessList: number[] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
    moduleProcess: number;
    userDetail: UserModel;

    constructor(
        private appStoreService: AppStoreService,
        private service: DataServiceEandTService,
        private adjustModuleService: AdjustModuleService,
        private notificationService: NotificationService
    ) {}

    ngOnInit() {
        this.canEditBuildStyle = false;
        this.canEditBuildType = false;
        this.isLoading = true;
        this.appStoreService.getLoggedInUser().subscribe((user) => {
            this.appStoreService.getUserDetails(user.mail).subscribe((res) => {
                this.userDetail = res;
            });
        });
        this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site) {
                this.site = {
                    plantName: site.plantName,
                    plantId: site.plantId,
                };
                this.service
                    .GetBuildType(this.site?.plantId)
                    .subscribe((res) => {
                        this.buildType = [];
                        if (res && res.length > 0) {
                            res.forEach((val) => {
                                const newStatus: Item = {
                                    value: val.buildTypeID,
                                    text: val.buildTypeName,
                                };
                                this.buildType.push(newStatus);
                            });
                        }
                    });
                this.service
                    .GetProductTypeDDL(this.site?.plantId)
                    .subscribe((res) => {
                        if (res && res.length > 0) {
                            res.forEach((val) => {
                                const newStatus: Item = {
                                    value: val.productGroupID,
                                    text: val.productName,
                                };
                                this.productTypeGroup.push(newStatus);
                            });
                        }
                    });
            }
        });

        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.EditModHome)
                    .subscribe((result) => {
                        this.canUserView = result;
                        this.isLoading = false;
                        if (
                            res.includes(role.SuperUser) ||
                            res.includes(role.Manager) ||
                            res.includes(role.Supervisor) ||
                            res.includes(role.ProjectManager)
                        ) {
                            this.isUserAccess = true;
                        }

                        if (
                            res.includes(role.SuperUser) ||
                            res.includes(role.PassTeamMember)
                        ) {
                            this.rule1 = true;
                        }
                        if (
                            res.includes(role.SuperUser) ||
                            res.includes(role.PassTeamMember) ||
                            res.includes(role.Manager) ||
                            res.includes(role.Supervisor) ||
                            res.includes(role.Leads)
                        ) {
                            this.rule2 = true;
                        }
                        if (
                            res.includes(role.SuperUser) ||
                            res.includes(role.Manager) ||
                            res.includes(role.Supervisor) ||
                            res.includes(role.Leads)
                        ) {
                            this.rule3 = true;
                        }
                        if (
                            res.includes(role.SuperUser) ||
                            res.includes(role.Manager) ||
                            res.includes(role.Supervisor) ||
                            res.includes(role.Leads) ||
                            res.includes(role.Technician)
                        ) {
                            this.rule4 = true;
                        }
                        if (
                            res.includes(role.SuperUser) ||
                            res.includes(role.Manager) ||
                            res.includes(role.Supervisor) ||
                            res.includes(role.Leads) ||
                            res.includes(role.Engineer)
                        ) {
                            this.rule5 = true;
                        }
                    });
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.EditModRemoveFromWIP)
                    .subscribe((result) => {
                        this.showRemoveFromWIPBtn = result;
                    });
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.EditBuildStyle)
                    .subscribe((result) => {
                        this.canEditBuildStyle = result;
                    });
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.EditBuildType)
                    .subscribe((result) => {
                        this.canEditBuildType = result;
                    });
            }
        });

        this.service.getBuildStyleDDL().subscribe((res) => {
            if (res && res.length) {
                res.forEach((val) => {
                    const newStatus: Item = {
                        value: val.masterRecordID,
                        text: val.masterRecordName,
                    };
                    this.buildStyleItem.push(newStatus);
                });
            }
        });

        this.service.getModuleColorDDL().subscribe((res) => {
            if (res && res.length) {
                res.forEach((val) => {
                    const newStatus: Item = {
                        value: val.value,
                        text: val.masterRecordName,
                    };
                    this.moduleColor.push(newStatus);
                });
            }
        });
        this.service.getCustomerDDL().subscribe((res) => {
            if (res && res.length) {
                res.forEach((val) => {
                    const newStatus: Item = {
                        value: val.productionStatus,
                        text: val.customer,
                    };
                    this.customer.push(newStatus);
                });
            }
        });
        this.adjustModuleService.getMRPDemand().subscribe((res) => {
            if (res && res.length) {
                res.forEach((val) => {
                    const dt: Item = {
                        value: val.masterRecordID,
                        text: val.masterRecordName,
                    };
                    this.demandType.push(dt);
                });
            }
        });
    }

    ngOnChanges() {
        if (this.pilotProductID && this.pilotProductID > 0) {
            this.getModuleData();
        }
    }

    onBuildTypeMgGroupChange(value, data: EditModuleViewModel) {
        data.buildTypeName = value;
    }

    getColorCodes(color: string) {
        switch (color?.trim()) {
            case "#000000":
            case "Black":
                this.moduleColorValue = { text: "Black", value: "#000000" };
                break;
            case "#a9a9a9":
            case "Dark Gray":
                this.moduleColorValue = { text: "Dark Gray", value: "#a9a9a9" };
                break;
            case "#ffffff":
            case "White":
                this.moduleColorValue = { text: "White", value: "#ffffff" };
                break;
            case "#d3d3d3":
            case "Light Gray":
                this.moduleColorValue = {
                    text: "Light Gray",
                    value: "#d3d3d3",
                };
                break;
            case "#0000ff":
            case "Blue":
                this.moduleColorValue = { text: "Blue", value: "#0000ff" };
                break;
            case "#add8e6":
            case "Light Blue":
                this.moduleColorValue = {
                    text: "Light Blue",
                    value: "#add8e6",
                };
                break;
            case "#008000":
            case "Green":
                this.moduleColorValue = { text: "Green", value: "#008000" };
                break;
            case "#00ffff":
            case "Cyan":
                this.moduleColorValue = { text: "Cyan", value: "#00ffff" };
                break;
            case "#90ee90":
            case "Light Green":
                this.moduleColorValue = {
                    text: "Light Green",
                    value: "#90ee90",
                };
                break;
            case "#ffff00":
            case "Yellow":
                this.moduleColorValue = { text: "Yellow", value: "#ffff00" };
                break;
            case "#a52a2a":
            case "Brown":
                this.moduleColorValue = { text: "Brown", value: "#a52a2a" };
                break;
            case "#ffa500":
            case "Orange":
                this.moduleColorValue = { text: "Orange", value: "#ffa500" };
                break;
            case "#d2b48c":
            case "Tan":
                this.moduleColorValue = { text: "Tan", value: "#d2b48c" };
                break;
            case "#ff0000":
            case "Red":
                this.moduleColorValue = { text: "Red", value: "#ff0000" };
                break;
            case "#800080":
            case "Purple":
                this.moduleColorValue = { text: "Purple", value: "#800080" };
                break;
            case "#ffc0cb":
            case "Pink":
                this.moduleColorValue = { text: "Pink", value: "#ffc0cb" };
                break;
            case "Unassigned":
                this.moduleColorValue = {
                    text: "Not Set",
                    value: "Unassigned",
                };
                break;
            default:
                this.moduleColorValue = {
                    text: "Not Set",
                    value: "Unassigned",
                };
                break;
        }
    }

    onSaveEditModule() {
        const req = new EditModuleViewModel();
        req.pilotProductID = this.moduleData.pilotProductID;
        req.buildStyleId = this.buildStyleValue.value;
        req.productionStatus = this.productionStatusValue?.text;
        req.pilotRiskLevel = this.pilotRiskLevelValue?.text;
        req.buildTypeID = this.buildTypeValue?.value;
        req.toolTypeID = this.moduleData.toolTypeID;
        req.productName = this.productTypeValue?.text;
        req.productGroupId = this.moduleData.productGroupId;
        req.customer = this.customerValue?.text;
        req.recordType = this.moduleData.recordType;
        req.capacityPlanningColor = this.moduleColorValue?.value;
        req.productManager = this.productManager;
        req.programManager = this.programManager;
        req.pilotToolType = this.pilotToolType;
        req.systemProjectManager = this.systemProjectManager;
        req.scheduler = this.scheduler;
        req.manufacturingEngineer = this.mfgEngineer;
        req.testEngineer = this.testEngineer;
        req.note = this.note;
        req.processModule = this.moduleProcess;
        req.po = this.po;
        req.qty = this.qty;
        req.demandTypeID = this.demandTypeValue.value;
        req.serialNum = this.serialNum;
        req.pcwoReleased = this.PCWOReleased;
        req.hot = this.hot;
        req.rework = this.rework;
        req.spclProcess = this.spclProcess;
        req.plannerName = this.plannerName;
        req.engineeringPOC = this.engineeringPOC;
        req.techBuild = this.techBuild;
        req.techTest = this.techTest;
        req.auditor = this.auditor;

        if (
            this.productionStatusValue?.text === "In Test" ||
            this.productionStatusValue?.text === "In Post-Test"
        ) {
            req.testDate = new Date(
                new Date().getTime() - new Date().getTimezoneOffset() * 60000
            );
        }
        req.modifiedBy = this.userDetail.userId;
        req.modifiedOn = new Date(
            new Date().getTime() - new Date().getTimezoneOffset() * 60000
        );
        this.service.updateMyModule(req).subscribe((res) => {
            this.isSaveEnabled = false;
            this.isCancelEnabled = false;
            this.showSuccess("Saved");
            this.getModuleData();
        });
    }

    getModuleData() {
        this.isSaveEnabled = false;
        this.isCancelEnabled = false;
        this.service
            .getMyModuleSummary(this.pilotProductID)
            .subscribe((res) => {
                this.moduleData = JSON.parse(JSON.stringify(res));
                this.tempModuleData = JSON.parse(JSON.stringify(res));
                this.buildTypeValue = {
                    text: this.moduleData?.buildTypeName,
                    value: this.moduleData?.buildTypeID,
                };
                this.productTypeValue = {
                    text: this.moduleData?.productName,
                    value: this.moduleData?.productGroupId,
                };
                const prodValue = this.prodction.filter(
                    (item) =>
                        item?.text?.toLowerCase() ===
                        this.moduleData?.productionStatus?.toLowerCase()
                )[0];
                this.productionStatusValue = {
                    text: prodValue?.text,
                    value: prodValue?.value,
                };
                this.getColorCodes(this.moduleData?.capacityPlanningColor);
                const value = this.pilotRiskLevel.filter(
                    (item) =>
                        item?.text?.toLowerCase() ===
                        this.moduleData?.pilotRiskLevel?.toLowerCase()
                )[0];
                this.pilotRiskLevelValue = {
                    text: value?.text,
                    value: value?.value,
                };
                this.productManager = this.moduleData?.productManager;
                this.programManager = this.moduleData?.programManager;
                this.pilotToolType = this.moduleData?.pilotToolType;
                this.buildStyleValue = {
                    text: this.moduleData?.buildStyle,
                    value: this.moduleData?.buildStyleId,
                };
                this.systemProjectManager =
                    this.moduleData?.systemProjectManager;
                this.scheduler = this.moduleData?.scheduler;
                this.mfgEngineer = this.moduleData?.manufacturingEngineer;
                this.testEngineer = this.moduleData?.testEngineer;
                this.note = this.moduleData?.note;
                this.WIPFlag = this.moduleData?.inWIP;
                this.buildStyle.emit(this.moduleData?.buildStyle);

                this.po = this.moduleData?.po;
                this.partNumber = this.moduleData?.partNumber;
                this.serialNum = this.moduleData?.serialNum;
                this.qty = this.moduleData?.qty;
                this.demandTypeID = this.moduleData?.demandTypeID;
                this.demandTypeValue = {
                    text: this.getValueFromText(
                        this.demandType,
                        this.moduleData?.demandTypeID
                    ),
                    value: this.moduleData?.demandTypeID,
                };
                this.partDescription = this.moduleData?.partDescription;
                this.PCWOReleased = this.moduleData?.pcwoReleased;
                this.hot = this.moduleData?.hot;
                this.rework = this.moduleData?.rework;
                this.spclProcess = this.moduleData?.spclProcess;
                this.plannerName = this.moduleData?.plannerName;
                this.engineeringPOC = this.moduleData?.engineeringPOC;
                this.techBuild = this.moduleData?.techBuild;
                this.techTest = this.moduleData?.techTest;
                this.auditor = this.moduleData?.auditor;
                this.moduleProcess = this.moduleData?.processModule;
            });
    }
    onCancel() {
        this.isSaveEnabled = false;
        this.isCancelEnabled = false;
        if (this.productionStatusValue) {
            const prodValue = this.prodction.filter(
                (item) =>
                    item?.text?.toLowerCase() ===
                    this.tempModuleData?.productionStatus?.toLowerCase()
            )[0];
            this.productionStatusValue = {
                text: prodValue?.text,
                value: prodValue?.value,
            };
        }

        if (this.pilotRiskLevelValue) {
            const value = this.pilotRiskLevel.filter(
                (item) =>
                    item?.text?.toLowerCase() ===
                    this.tempModuleData?.pilotRiskLevel?.toLowerCase()
            )[0];
            this.pilotRiskLevelValue = {
                text: value?.text,
                value: value?.value,
            };
        }

        if (this.buildTypeValue) {
            this.buildTypeValue = {
                text: this.tempModuleData.buildTypeName,
                value: this.tempModuleData.buildTypeID,
            };
        }
        if (this.productTypeValue) {
            this.productTypeValue = {
                text: this.tempModuleData.productName,
                value: this.tempModuleData.productGroupId,
            };
        }
        if (this.customerValue)
            this.customerValue = {
                text: this.tempModuleData.customer,
                value: 0,
            };
        if (this.moduleColorValue) {
            this.getColorCodes(this.tempModuleData.capacityPlanningColor);
        }
        if (this.buildStyleValue) {
            const buildValue = this.buildStyleItem.filter(
                (item) => item?.value === this.tempModuleData?.buildStyleId
            )[0];
            this.buildStyleValue = {
                text: buildValue?.text,
                value: buildValue?.value,
            };
        }
        this.productManager = this.tempModuleData.productManager;
        this.programManager = this.tempModuleData.programManager;
        this.pilotToolType = this.tempModuleData.pilotToolType;
        this.systemProjectManager = this.tempModuleData.systemProjectManager;
        this.scheduler = this.tempModuleData.scheduler;
        this.mfgEngineer = this.tempModuleData.manufacturingEngineer;
        this.testEngineer = this.tempModuleData.testEngineer;
        this.note = this.tempModuleData.note;
        this.moduleProcess = this.tempModuleData.processModule;
    }
    getValueFromText(ddl, id) {
        let txt = "";
        ddl.forEach((val) => {
            if (val.value == id) {
                txt = val.text;
            }
        });
        return txt;
    }
    prodctionChange(value) {
        this.isSaveEnabled = true;
        this.isCancelEnabled = true;
    }
    onPilotRiskChange(value) {
        this.pilotRiskLevelValue = value;
        this.isSaveEnabled = true;
        this.isCancelEnabled = true;
    }
    buildTypeChange(value) {
        this.isSaveEnabled = true;
        this.isCancelEnabled = true;
    }
    productTypeChange(value) {
        this.isSaveEnabled = true;
        this.isCancelEnabled = true;
    }
    moduleColorChange(value) {
        this.isSaveEnabled = true;
        this.isCancelEnabled = true;
    }
    moduleModuleProcessChange(value) {
        this.isSaveEnabled = true;
        this.isCancelEnabled = true;
    }
    onProductChange(value) {
        this.isSaveEnabled = true;
        this.isCancelEnabled = true;
    }
    onProgramChange(value) {
        this.isSaveEnabled = true;
        this.isCancelEnabled = true;
    }
    onSystemChange(value) {
        this.isSaveEnabled = true;
        this.isCancelEnabled = true;
    }
    onPilotToolTypeChange(value) {
        this.isSaveEnabled = true;
        this.isCancelEnabled = true;
    }
    onBuildStyleChange(value) {
        this.isSaveEnabled = true;
        this.isCancelEnabled = true;
    }
    onSchedulerChange(value) {
        this.isSaveEnabled = true;
        this.isCancelEnabled = true;
    }
    onMfgChange(value) {
        this.isSaveEnabled = true;
        this.isCancelEnabled = true;
    }
    onTestChange(value) {
        this.isSaveEnabled = true;
        this.isCancelEnabled = true;
    }
    onNoteChange(value) {
        this.isSaveEnabled = true;
        this.isCancelEnabled = true;
    }

    removeFromWIP() {
        const dataToSend = {
            pilotProductID: +this.pilotProductID,
            wipFlat: false,
        };
        this.service
            .SetModuleWIPFlat(dataToSend)
            .toPromise()
            .then(() => {
                this.WIPFlag = false;
            });
    }
    onChangeQty(value) {
        this.isSaveEnabled = true;
        this.isCancelEnabled = true;
    }
    onPOWOChange(value) {
        this.isSaveEnabled = true;
        this.isCancelEnabled = true;
  }

    onPartNumberChange(value) {
        this.isSaveEnabled = true;
        this.isCancelEnabled = true;
    }
    onSerialNumChange(value) {
        this.isSaveEnabled = true;
        this.isCancelEnabled = true;
    }
    demandTypeChange(value) {
        this.isSaveEnabled = true;
        this.isCancelEnabled = true;
    }
    onChangeModuleTeam(value) {
        this.isSaveEnabled = true;
        this.isCancelEnabled = true;
    }
    public showSuccess(msg: string): void {
        this.notificationService.show({
            appendTo: this.appendTo,
            content: msg,
            position: { horizontal: "left", vertical: "bottom" },
            animation: { type: "fade", duration: 600 },
            type: { style: "success", icon: true },
        });
    }
}
