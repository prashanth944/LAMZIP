import {
    Component,
    Input,
    OnInit,
    ViewChild,
    ViewEncapsulation,
} from "@angular/core";
import { Plant, UserModel } from "../../../../../core/model/user.model";
import { MTT } from "../../../Models/mtt.model";
import {
    CompositeFilterDescriptor,
    distinct,
    filterBy,
} from "@progress/kendo-data-query";
import { DataServiceEandTService } from "../../../data-service-eand-t.service";
import { ModuleSummary } from "../../../Models/ModuleSummary";
import { TooltipDirective } from "@progress/kendo-angular-tooltip";
import { FormBuilder, FormGroup } from "@angular/forms";
import { EditService } from "../../../../service/edit.service";
import { AppStoreService } from "../../../../../core/app-store.service";
import { MultiSelectComponent } from "@progress/kendo-angular-dropdowns";

@Component({
    selector: "pmpm-mtt",
    templateUrl: "./mtt.component.html",
    styleUrls: ["./mtt.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class MttComponent implements OnInit {
    @Input() pilotProductId: number;
    @Input() site: Plant;
    @ViewChild(TooltipDirective) public tooltipDir: TooltipDirective;
    @ViewChild("multiselect") public multiselect: MultiSelectComponent;

    //grid
    public moduleInfo: ModuleSummary = null;
    public gridDataForMTT: MTT[] = [];
    public tempGridDataForMTT: MTT[] = [];
    public loadingTable = true;
    public hoverMessage = "";
    statusDDL: any = [];
    userDetails: UserModel;

    //search and filter
    public filter: CompositeFilterDescriptor;
    public searchText = "";
    public PNDataItem: any[] = [];
    public PNFilteredList: any[] = [];
    public tempPNFilteredList: any[] = [];
    public statusDataItem: any[] = [];
    public statusFilteredList: any[] = [];
    public tempStatusFilteredList: any[] = [];

    constructor(
        private service: DataServiceEandTService,
        private formBuilder: FormBuilder,
        private editService: EditService,
        private appStore: AppStoreService
    ) {}

    ngOnInit() {
        this.editService.cancelChanges();
        this.appStore.getLoggedInUser().subscribe((res) => {
            this.appStore.getUserDetails(res.mail).subscribe((user) => {
                if (user && user.username?.length > 0) {
                    this.userDetails = user;
                }
            });
        });
        this.getDropdownValues();
        this.getModuleInfo();
    }

    public getDropdownValues() {
        this.service.GetMTTStatusDLL().subscribe((res) => {
            this.statusDDL = res.map((item, index, arr) => {
                return item.masterRecordName;
            });
        });
    }

    getModuleInfo() {
        this.service
            .getModuleSummaryByID(+this.pilotProductId)
            .toPromise()
            .then((data) => {
                if (data && data.length > 0) {
                    this.moduleInfo = data.filter(
                        (item) =>
                            +item.ModuleInfo.PilotProductID ===
                            +this.pilotProductId
                    )[0];
                    if (
                        this.site?.plantName === "Fremont" &&
                        this.moduleInfo?.ModuleInfo?.PilotSerialNumber !== null
                    )
                        this.getMTTDetails(
                            this.moduleInfo?.ModuleInfo?.PilotSerialNumber
                        );
                    else if (
                        this.site?.plantName !== "Fremont" &&
                        this.moduleInfo?.ModuleInfo?.BEN !== null
                    )
                        this.getMTTDetails(this.moduleInfo?.ModuleInfo?.BEN);
                    else {
                        this.loadingTable = false;
                    }
                }
            });
    }

    getMTTDetails(ben: string) {
        this.gridDataForMTT = [];
        this.service.GetMTTDetails(ben).subscribe((res) => {
            if (res && res.length > 0) {
                this.gridDataForMTT = res;
            }
            this.tempGridDataForMTT = JSON.parse(
                JSON.stringify(this.gridDataForMTT)
            );
            this.loadingTable = false;
            this.getFilterList();
        });
    }

    public distinctPrimitive(fieldName: string): any {
        let data: any = distinct(this.tempGridDataForMTT, fieldName).map(
            (item) => item[fieldName]
        );
        data = data.flatMap((f) => (f ? [f] : []));
        data.sort(function (a, b) {
            const textA = a?.toUpperCase();
            const textB = b?.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
        });
        return data;
    }

    onMTTLinkClick(recID: number) {
        const url =
            "https://lamresearch.quickbase.com/db/bprt8ii2f?a=er&rid=" + recID;
        window.open(url, "_blank");
    }

    public showTooltip(e: MouseEvent): void {
        const element = e.target as HTMLElement;
        if (
            element.nodeName === "TH" &&
            element.textContent == "Date Created"
        ) {
            this.hoverMessage = "Created date from SAP";
            this.tooltipDir.toggle(element);
        } else if (
            (element.nodeName === "TH" || element.nodeName === "TD") &&
            element.offsetWidth < element.scrollWidth
        ) {
            this.hoverMessage = element.textContent;
            this.tooltipDir.toggle(element);
        } else {
            this.tooltipDir.hide();
        }
    }

    public createFormGroup(dataItem: any): FormGroup {
        return this.formBuilder.group({ status: dataItem.status });
    }

    public cellClickHandler({
        sender,
        rowIndex,
        columnIndex,
        dataItem,
        isEdited,
    }) {
        if (!isEdited) {
            sender.editCell(
                rowIndex,
                columnIndex,
                this.createFormGroup(dataItem)
            );
        }
    }

    public cellCloseHandler(args: any) {
        const { formGroup, dataItem } = args;

        if (!formGroup.valid) {
            // prevent closing the edited cell if there are invalid values.
            args.preventDefault();
        } else if (formGroup.dirty) {
            this.editService.assignValues(dataItem, formGroup.value);
            this.editService.update(dataItem, "MTT");
        }
    }

    public cancelHandler({ sender, rowIndex }) {
        sender.closeRow(rowIndex);
    }

    public saveHandler({ sender, formGroup, rowIndex }) {
        if (formGroup.valid) {
            this.editService.create(formGroup.value);
            sender.closeRow(rowIndex);
        }
    }

    public saveChanges(grid: any): void {
        grid.closeCell();
        grid.cancelCell();
        const updatedMTTData = this.editService.saveChanges();
        this.service.UpdateMTTData(updatedMTTData[0]).subscribe((res) => {
            this.getModuleInfo();
        });
    }

    public cancelChanges(grid: any): void {
        grid.cancelCell();
        this.editService.cancelChanges();
        this.gridDataForMTT = JSON.parse(
            JSON.stringify(this.tempGridDataForMTT)
        );
    }

    getFilterList() {
        const PN: any = distinct(this.tempGridDataForMTT, "partNumber")
            .map((item) => item["partNumber"])
            .map((val) => ({ text: val, value: val }));
        PN.forEach((item) => {
            if (item.value === "") item.text = "BLANK";
            else if (item.value === null) {
                item.text = "NULL";
            }
        });
        PN.sort(function (a, b) {
            const textA = a?.text.toUpperCase();
            const textB = b?.text.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
        });
        this.PNFilteredList = [...PN];
        this.tempPNFilteredList = JSON.parse(
            JSON.stringify(this.PNFilteredList)
        );

        const status: any = distinct(this.tempGridDataForMTT, "status")
            .map((item) => item["status"])
            .map((val) => ({ text: val, value: val }));
        status.forEach((item) => {
            if (item.value === "") item.text = "BLANK";
            else if (item.value === null) {
                item.text = "NULL";
            }
        });
        status.sort(function (a, b) {
            const textA = a?.text.toUpperCase();
            const textB = b?.text.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
        });
        this.statusFilteredList = [...status];
        this.tempStatusFilteredList = JSON.parse(
            JSON.stringify(this.statusFilteredList)
        );
    }

    //Search
    onSearchFilter() {
        const filter: CompositeFilterDescriptor = { filters: [], logic: "and" };
        if (this.searchText && this.searchText.length > 0) {
            const searchFilter = [
                {
                    field: "partNumber",
                    operator: "contains",
                    value: this.searchText.trim(),
                },
                {
                    field: "partDescription",
                    operator: "contains",
                    value: this.searchText.trim(),
                },
            ];
            filter.filters.push({ filters: [...searchFilter], logic: "or" });
        }
        if (this.PNDataItem && this.PNDataItem.length > 0) {
            const PN: any[] = [];
            this.PNDataItem.forEach((item) => {
                PN.push({
                    field: "partNumber",
                    operator: this.getOperator(item.value),
                    value: item.value.trim(),
                });
            });
            filter.filters.push({ filters: [...PN], logic: "or" });
        }
        if (this.statusDataItem && this.statusDataItem.length > 0) {
            const status: any[] = [];
            this.statusDataItem.forEach((item) => {
                status.push({
                    field: "status",
                    operator: this.getOperator(item.value),
                    value: item.value.trim(),
                });
            });
            filter.filters.push({ filters: [...status], logic: "or" });
        }

        this.filter = filter;
        this.gridDataForMTT = filterBy(this.tempGridDataForMTT, filter);
    }

    //Filters
    handlePNFilter(value) {
        if (value.length >= 0) {
            this.PNFilteredList = this.tempPNFilteredList.filter(
                (s) => s?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
            );
        } else {
            this.multiselect.toggle(false);
        }
    }

    handleStatusFilter(value) {
        if (value.length >= 0) {
            this.statusFilteredList = this.tempStatusFilteredList.filter(
                (s) => s?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
            );
        } else {
            this.multiselect.toggle(false);
        }
    }

    private getOperator(value) {
        const options = {
            null: "isnull",
            "": "isempty",
        };
        return options[value] || "eq";
    }

    public tagMapper(tags: any[]): any[] {
        tags.sort(function (a, b) {
            const textA = a?.text.toUpperCase();
            const textB = b?.text.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
        });
        return tags;
    }
}
