import {
    ChangeDetectorRef,
    Component,
    EventEmitter,
    Input,
    OnInit,
    Output,
    ViewChild,
    ViewContainerRef,
    ViewEncapsulation,
} from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { NotificationService } from "@progress/kendo-angular-notification";
import * as moment from "moment";
import { AppStoreService } from "../../../../core/app-store.service";
import { role, uiScreen } from "../../../../core/model/common.constant";
import { Plant, UserModel } from "../../../../core/model/user.model";
import { EditService } from "../../../service/edit.service";
import { DataServiceEandTService } from "../../data-service-eand-t.service";
import {
    OpsManagementEditModel,
    OpsManagementSubassembly,
} from "../../Models/ops-mgmt.model";

@Component({
    selector: "pmpm-ops-mgmt",
    templateUrl: "./ops-mgmt.component.html",
    styleUrls: ["./ops-mgmt.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class OpsMgmtComponent implements OnInit {
    @Input() pilotProductID: number;
    @Input() buildStyle: string;
    @Input() InWip = false;
    @Output() isInWIP: EventEmitter<boolean> = new EventEmitter<boolean>();

    @ViewChild("appendTo", { read: ViewContainerRef })
    public appendTo: ViewContainerRef;

    //access
    public isUserAccess = false;
    public canEditTestnPostTest = false;
    public isLoading = true;
    public site: Plant;
    public userDetail: UserModel;
    public currentRole: string[] = [];
    public isEngineer = false;

    //Assembly, Test, Post-Test Percent
    public assemblyPercent = 0;
    public testPercent = 0;
    public postTestPercent = 0;

    //grid
    public gridData: any = [];
    public originalGridData: any = [];
    public gridDataForEngineers: any = [];
    public updatedList: any[] = [];
    public canEditNonEngineerGrid = false;

    //Special Subassmebly
    public WIPFlag: boolean = null;
    public showRemoveFromWIPBtn = false;
    disableSave = true;
    pilotMEApprovedValue: boolean;
    mfgApprovedValue: boolean;
    ca10ShortageFreeValue: boolean;
    soeLinkValue: string;
    moduleProcessIdForSubassembly: number;
    moduleProcessIdForTest: number;
    percentType: string;
    subassemblyHoursValue: number;
    testHoursValue: number;
    pilotAssemblyCompleteDate: Date;
    pilotTestCompleteDate: Date;
    pilotMfgCompleteDate: Date;
    showNA = false;

    //Special Subassmebly Authentication
    rule1 = false; //Task 29160: Authentication - Ops Mgmt tab: [Subassembly Hours], [Test Hours], [Pilot ME Approved], [SOE Link] - Edit for Engineer, Manager / Director, Supervisor, Lead
    rule2 = false; //Task 29161: Authentication - Ops Mgmt tab: [Assembly %], [Test %], [Post-Test %][Assembly %], [Test %], [Post-Test %], [Mfg Approved] - Edit for Manager / Director, Supervisor, Technician, Lead
    rule3 = false; //Task 29162: Authentication - Ops Mgmt tab: [CA10 Shortage Free] - Edit for PASS/PCFS, Manager/Director, Supervisor, Lead

    removeWIPConfirmation = false;

    constructor(
        private appStoreService: AppStoreService,
        private formBuilder: FormBuilder,
        private editService: EditService,
        public service: DataServiceEandTService,
        private notificationService: NotificationService,
        private changeDetector: ChangeDetectorRef
    ) {}

    ngOnInit(): void {
        this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site) {
                this.site = {
                    plantName: site.plantName,
                    plantId: site.plantId,
                };
            }
        });

        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                if (res) {
                    this.currentRole = res;
                    this.appStoreService
                        .checkUserAccessRight(res, uiScreen.OpsMgmt)
                        .subscribe((result) => {
                            this.isUserAccess = result;
                            if (this.isUserAccess) {
                                if (res.includes(role.Engineer))
                                    this.isEngineer = true;

                                if (
                                    res.includes(role.Supervisor) ||
                                    res.includes(role.Leads) ||
                                    res.includes(role.Manager) ||
                                    res.includes(role.SuperUser)
                                ) {
                                    this.canEditTestnPostTest = true;
                                }

                                if (
                                    res.includes(role.Supervisor) ||
                                    res.includes(role.Leads) ||
                                    res.includes(role.Manager) ||
                                    res.includes(role.ProjectManager) ||
                                    res.includes(role.SuperUser)
                                ) {
                                    this.canEditNonEngineerGrid = true;
                                }

                                if (
                                    res.includes(role.Supervisor) ||
                                    res.includes(role.Leads) ||
                                    res.includes(role.Manager) ||
                                    res.includes(role.Engineer) ||
                                    res.includes(role.SuperUser)
                                ) {
                                    this.rule1 = true;
                                }
                                if (
                                    res.includes(role.Supervisor) ||
                                    res.includes(role.Leads) ||
                                    res.includes(role.Manager) ||
                                    res.includes(role.Technician) ||
                                    res.includes(role.SuperUser)
                                ) {
                                    this.rule2 = true;
                                }
                                if (
                                    res.includes(role.Supervisor) ||
                                    res.includes(role.Leads) ||
                                    res.includes(role.Manager) ||
                                    res.includes(role.PassTeamMember) ||
                                    res.includes(role.SuperUser)
                                ) {
                                    this.rule3 = true;
                                }
                            }
                        });
                }
            }
            this.appStoreService
                .checkUserAccessRight(res, uiScreen.EditModRemoveFromWIP)
                .subscribe((result) => {
                    this.showRemoveFromWIPBtn = true;
                });
        });

        this.appStoreService.getLoggedInUser().subscribe((user) => {
            this.appStoreService.getUserDetails(user.mail).subscribe((res) => {
                if (res && res.username.length > 0) {
                    this.userDetail = res;
                }
            });
        });

        this.getParentGridData();
        if (this.buildStyle == "Special Subassembly") {
            this.fillSpecialSubassemblyOps();
        }
    }

    public getAssemblyTestPostTestPercent() {
        this.service
            .GetAssemblyTestPostTestPercent(this.pilotProductID)
            .subscribe((res) => {
                if (res) {
                    this.assemblyPercent =
                        res.assemblyPercent != null
                            ? +res.assemblyPercent.toFixed(2)
                            : 0.0;
                    this.testPercent =
                        res.testPercent !== null
                            ? +res.testPercent.toFixed(2)
                            : 0.0;
                    this.postTestPercent =
                        res.postTestPercent !== null
                            ? +res.postTestPercent.toFixed(2)
                            : 0.0;
                }
            });
    }

    public getOpMgmtData() {
        this.WIPFlag = this.InWip != null ? this.InWip : false;
        if (this.isEngineer) {
            let date: any = new Date();
            date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
            this.service
                .GetOpMgmtDataForEngineers(this.pilotProductID, date)
                .subscribe((res) => {
                    if (res && res.length > 0) {
                        this.gridDataForEngineers = res;
                    }
                    this.isLoading = false;
                });
        } else {
            let date: any = new Date();
            date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
            this.service
                .GetOpMgmtData(this.pilotProductID, date)
                .subscribe((res) => {
                    if (res && res.length > 0) {
                        this.gridData = res;
                        this.originalGridData = JSON.parse(
                            JSON.stringify(this.gridData)
                        );
                    }
                    this.isLoading = false;
                });
        }
    }

    public getParentGridData() {
        this.updatedList = [];
        this.getOpMgmtData();
        this.getAssemblyTestPostTestPercent();
    }

    public createFormGroup(dataItem: any): FormGroup {
        return this.formBuilder.group({
            manualOpPercent: dataItem.manualOpPercent,
            dayShiftOnly: dataItem.dayShiftOnly,
            nightShiftOnly: dataItem.nightShiftOnly,
            standardTimeHours: dataItem.standardTimeHours,
            stOverrideReason: dataItem.stOverrideReason,
        });
    }

    public cellClickHandler({
        sender,
        rowIndex,
        columnIndex,
        dataItem,
        isEdited,
    }) {
        if (!isEdited) {
            sender.editCell(
                rowIndex,
                columnIndex,
                this.createFormGroup(dataItem)
            );
        }
    }

    public cellCloseHandler(args: any) {
        const { formGroup, dataItem } = args;

        if (!formGroup.valid) {
            // prevent closing the edited cell if there are invalid values.
            args.preventDefault();
        } else if (formGroup.dirty) {
            args.dataItem.stUpdatedById = this.userDetail.userId;
            if (args.column.field == "standardTimeHours") {
                if (formGroup.value.standardTimeHours) {
                    args.dataItem.stUpdatedBy =
                        this.userDetail.firstName +
                        " " +
                        this.userDetail.lastName;
                }
            }
            this.editService.assignValues(dataItem, formGroup.value);
            this.editService.update(dataItem, "Ops-Mgmt");
            const updatedData = this.editService.saveChanges();
            if (updatedData?.length > 0) {
                this.disableSave = false;
                const isNew = this.updatedList.filter(
                    (x) => x.operationID == updatedData[0][0].operationID
                );
                if (isNew.length === 0) {
                    this.updatedList.push(updatedData[0][0]);
                } else {
                    const spliceIndex = this.updatedList.indexOf(
                        updatedData[0][0].operationID
                    );
                    this.updatedList.splice(spliceIndex, 1);
                    this.updatedList.push(updatedData[0][0]);
                }
            } else {
                this.disableSave = true;
            }
        }
    }

    fillSpecialSubassemblyOps() {
        this.service
            .getOpsManagementSubassembly(this.pilotProductID)
            .subscribe((res) => {
                if (res) {
                    this.pilotMEApprovedValue = res.pilotMEApproved;
                    this.mfgApprovedValue = res.mfgApproved;
                    this.ca10ShortageFreeValue = res.cA10ShortageFree;
                    this.soeLinkValue = res.soeLink;
                    this.moduleProcessIdForSubassembly =
                        res.moduleProcessIdForSubassembly;
                    this.moduleProcessIdForTest = res.moduleProcessIdForTest;
                    this.assemblyPercent = res.assemblyPercent;
                    this.testPercent = res.testPercent;
                    this.postTestPercent = res.postTestPercent;
                    this.subassemblyHoursValue = res.subassemblyBuildHours;
                    this.testHoursValue = res.testBuildHours;
                    this.InWip = res.inWIP;
                    this.WIPFlag = res.inWIP !== null ? res.inWIP : false;
                    this.showNA =
                        res.testBuildHours === 0 || res.testBuildHours === null
                            ? true
                            : false;
                }
            });
    }

    removeFromWIP() {
        const dataToSend = {
            pilotProductID: +this.pilotProductID,
            wipFlat: false,
        };
        this.service
            .SetModuleWIPFlat(dataToSend)
            .toPromise()
            .then(() => {
                this.WIPFlag = false;
                this.InWip = false;
                this.removeWIPConfirmation = false;
                this.showSuccess("Removed from WIP");
                this.changeDetector.detectChanges();
                this.isInWIP.emit(true);
            });
    }
    public showSuccess(msg: string): void {
        this.notificationService.show({
            appendTo: this.appendTo,
            content: msg,
            position: { horizontal: "left", vertical: "bottom" },
            animation: { type: "fade", duration: 600 },
            type: { style: "success", icon: true },
        });
    }
    onSaveChanges() {
        const opsManagementSubassemblyObj: OpsManagementSubassembly = {
            PilotProductID: +this.pilotProductID,
            AssemblyPercent: +this.assemblyPercent,
            TestPercent: +this.testPercent,
            PostTestPercent: +this.postTestPercent,
            SubassemblyBuildHours: +this.subassemblyHoursValue,
            TestBuildHours: +this.testHoursValue,
            ModuleProcessIdForSubassembly: this.moduleProcessIdForSubassembly,
            ModuleProcessIdForTest: this.moduleProcessIdForTest,
            PilotMEApproved: this.pilotMEApprovedValue,
            SOELink: this.soeLinkValue,
            MfgApproved: this.mfgApprovedValue,
            CA10ShortageFree: this.ca10ShortageFreeValue,
            PercentType: this.percentType,
            inWIP: this.InWip,
        };
        this.service
            .updateOpsManagementSubassembly(opsManagementSubassemblyObj)
            .subscribe((res) => {
                if (res) {
                    this.disableSave = true;
                }
            });
    }
    onCancel() {
        this.disableSave = true;
        if (this.buildStyle === "Special Subassembly") {
            this.fillSpecialSubassemblyOps();
        }
    }
    onChange() {
        this.disableSave = false;
    }
    onChangeAssembly() {
        if (this.assemblyPercent === 100) {
            this.pilotAssemblyCompleteDate = new Date();
        } else {
            this.pilotAssemblyCompleteDate = null;
        }
    }
    onChangeTest() {
        if (this.testPercent < 100) {
            this.postTestPercent = 0;
        }
        if (this.testPercent === 100) {
            this.pilotTestCompleteDate = new Date();
        } else {
            this.pilotTestCompleteDate = null;
        }
    }
    onChangePostTest() {
        if (this.postTestPercent > 0) {
            this.testPercent = 100;
        }
        if (this.postTestPercent === 100) {
            this.pilotMfgCompleteDate = new Date();
        } else {
            this.pilotMfgCompleteDate = null;
        }
    }

    onTestHoursChange() {
        if (this.testHoursValue === 0) {
            this.showNA = true;
            this.testPercent = 0;
            this.postTestPercent = 0;
        } else {
            this.showNA = false;
        }
    }

    updateChanges() {
        const request = new OpsManagementEditModel();
        request.assemblyPercent = this.assemblyPercent;
        request.testPercent = this.testPercent;
        request.postTestPercent = this.postTestPercent;
        request.pilotProductID = this.pilotProductID;
        request.opsmgOperationEditFields = [];
        this.updatedList.forEach((item) => {
            request.opsmgOperationEditFields.push({
                pilotProductID: item.pilotProductID,
                operationID: item.operationID,
                dayShiftOnly: item.dayShiftOnly,
                nightShiftOnly: item.nightShiftOnly,
                manualOpPercent: item.manualOpPercent,
                standardTimeHours: item.standardTimeHours,
                stOverrideReason: item.stOverrideReason,
                stUpdatedById: this.userDetail?.userId,
            });
        });
        this.service.updateOpsMgmtData(request).subscribe((res) => {
            if (res) {
                this.disableSave = true;
                this.showSuccess("Saved");
                this.getParentGridData();
            }
        });
    }

    cancelChanges() {
        this.disableSave = true;
        this.getParentGridData();
    }

    openRemoveWIPConfirmation() {
        this.removeWIPConfirmation = true;
    }
    onCloseRemoveWIPConfirmation() {
        this.removeWIPConfirmation = false;
    }
}
