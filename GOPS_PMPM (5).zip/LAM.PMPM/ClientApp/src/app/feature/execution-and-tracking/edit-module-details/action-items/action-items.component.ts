import { Component, OnInit, ViewChild, ViewEncapsulation } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { AppStoreService } from "../../../../core/app-store.service";
import { Plant, UserModel } from "../../../../core/model/user.model";
import { DataServiceEandTService } from "../../data-service-eand-t.service";
import { ModuleSummary, Zones } from "../../Models/ModuleSummary";
import { SelectEvent, TabStripComponent } from "@progress/kendo-angular-layout";

@Component({
    selector: "pmpm-action-items",
    templateUrl: "./action-items.component.html",
    styleUrls: ["./action-items.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class ActionItemsComponent implements OnInit {
    @ViewChild("tabstrip") public tabstrip: TabStripComponent;
    public moduleInfo: ModuleSummary = null;
    public site: Plant;
    public pilotProductId: number;
    public tabTitle = "Issue Log";
    public tabId = 0;
    public ben = "";
    public zones: Zones[] = [];
    public userDetails: UserModel;

    constructor(
        private appStoreService: AppStoreService,
        private route: ActivatedRoute,
        private service: DataServiceEandTService,
        private router: Router
    ) {}

    ngOnInit() {
        this.route.params.subscribe((param) => {
            this.pilotProductId = param.id;
            this.tabId = param.tabId;
            this.getTabTitle();
        });
        this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site) {
                this.site = {
                    plantName: site.plantName,
                    plantId: site.plantId,
                };
                this.service
                    .getModuleSummaryByID(+this.pilotProductId)
                    .toPromise()
                    .then((data) => {
                        if (data && data.length > 0) {
                            this.moduleInfo = data.filter(
                                (item) =>
                                    +item.ModuleInfo.PilotProductID ===
                                    +this.pilotProductId
                            )[0];
                            this.zones = this.moduleInfo.Zones;
                            if (this.site?.plantName === "Fremont")
                                this.ben =
                                    this.moduleInfo?.ModuleInfo?.PilotSerialNumber;
                            else this.ben = this.moduleInfo?.ModuleInfo?.BEN;
                        }
                    });
            }
        });

        this.appStoreService.getLoggedInUser().subscribe((res) => {
            this.appStoreService.getUserDetails(res.mail).subscribe((user) => {
                if (user && user.username?.length > 0) {
                    this.userDetails = user;
                }
            });
        });
    }

    onSelectTab(e: SelectEvent) {
        this.tabTitle = e.title;
        this.tabId = e.index;
    }

    getTabTitle() {
        switch (+this.tabId) {
            case 0:
                this.tabTitle = "Issue Log";
                break;
            case 1:
                this.tabTitle = "Audit Items";
                break;
            case 2:
                this.tabTitle = "NCIs";
                break;
            case 3:
                this.tabTitle = "BOM Changes";
                break;
            case 4:
                this.tabTitle = "RTS";
                break;
            case 5:
                this.tabTitle = "Shortages";
                break;
            case 6:
                this.tabTitle = "TOIs";
                break;
            case 7:
                this.tabTitle = "MITs";
                break;
            case 8:
                this.tabTitle = "Grey Material";
                break;
            case 9:
                this.tabTitle = "S.A.F.E";
                break;
        }
    }

    goToEditModHome() {
        this.router.navigate(["/edit-module/" + this.pilotProductId + "/" + 0]);
    }
}
