import {
    Component,
    OnInit,
    ViewChild,
    ViewContainerRef,
    ViewEncapsulation,
} from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { SelectEvent } from "@progress/kendo-angular-layout";
import { AppStoreService } from "../../../../../core/app-store.service";
import { Plant } from "../../../../../core/model/user.model";
import { DataServiceEandTService } from "../../../data-service-eand-t.service";
import {
    EditModuleViewModel,
    ModuleSummary,
    SerializationRequest,
} from "../../../Models/ModuleSummary";
import { NotificationService } from "@progress/kendo-angular-notification";

@Component({
    selector: "pmpm-serialization-numbers",
    templateUrl: "./serialization-numbers.component.html",
    styleUrls: ["./serialization-numbers.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class SerializationNumbersComponent implements OnInit {
    @ViewChild("appendTo", { read: ViewContainerRef })
    public appendTo: ViewContainerRef;

    site: Plant;
    public moduleInfo: ModuleSummary = null;
    divisionInfo: EditModuleViewModel;
    serializationNumbers: any[] = [];
    tabIndex = 0;
    selectedTab: any[] = [];
    subTabs: string[] = [];
    serialNumberList: any[] = [];
    pilotProductId: number;
    serializationToBeUpdated: SerializationRequest[] = [];
    showSaveAndCancel = false;
    openConfirmationPopup = false;
    notes =
        "Part Numbers and Serial Numbers are no longer being recorded for the items below with grey entry boxes.\nIf you come across SOE that instructs you to serialize a component that has been greyed-out, please submit an";

    constructor(
        private appStoreService: AppStoreService,
        private service: DataServiceEandTService,
        private router: Router,
        private route: ActivatedRoute,
        private notificationService: NotificationService
    ) {}

    ngOnInit(): void {
        this.route.params.subscribe((param) => {
            this.pilotProductId = +param.pilotProductID;
        });
        this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site) {
                this.site = {
                    plantName: site.plantName,
                    plantId: site.plantId,
                };
                this.service
                    .getModuleSummaryByID(this.pilotProductId)
                    .toPromise()
                    .then((data) => {
                        if (data && data.length > 0) {
                            this.moduleInfo = data.filter(
                                (item) =>
                                    +item.ModuleInfo.PilotProductID ===
                                    this.pilotProductId
                            )[0];
                        }
                    });
                this.service
                    .getModulesSummary(this.pilotProductId)
                    .subscribe((res) => {
                        if (res) {
                            this.divisionInfo = res;
                        }
                    });
                this.getSerializationNumbers();
            }
        });
    }

    getSerializationNumbers() {
        this.serializationNumbers = [];
        this.service
            .GetSerializationNumbers(this.site?.plantId, this.pilotProductId)
            .subscribe((res) => {
                if (res && res.length > 0) {
                    this.serializationNumbers = res;
                    this.serializationNumbers.forEach((item) => {
                        item.forEach((i) => {
                            if (!i.active) {
                                i.partNum = "No longer being recorded";
                                i.serialNum = "No longer being recorded";
                            }
                        });
                    });
                    this.tabIndex = 0;
                    this.selectedTab = this.groupArrayOfObjects(
                        this.serializationNumbers[0],
                        "zone"
                    );
                    this.subTabs = [];
                    for (const o in this.selectedTab) {
                        this.subTabs.push(o);
                    }
                    const subTab = this.subTabs[0];
                    this.serialNumberList = [];
                    this.serializationNumbers[this.tabIndex]?.forEach(
                        (item) => {
                            if (item.zone === subTab) {
                                this.serialNumberList.push(item);
                            }
                        }
                    );
                }
            });
    }

    updateSerializationNumbers() {
        if (
            this.serializationToBeUpdated &&
            this.serializationToBeUpdated.length > 0
        ) {
            this.service
                .updateSerializationNumbers(this.serializationToBeUpdated)
                .subscribe((res) => {
                    if (res) {
                        this.showSaveAndCancel = false;
                        this.showSuccess("Saved");
                        this.serializationToBeUpdated = [];
                        setTimeout(() => {
                            this.goToEditModHome();
                        }, 1000);
                    }
                });
        }
    }

    goToEditModHome() {
        this.router.navigate(["/edit-module/" + this.pilotProductId + "/" + 0]);
    }

    onSelectTab(e: SelectEvent) {
        this.tabIndex = e.index;
        this.selectedTab = this.groupArrayOfObjects(
            this.serializationNumbers[e.index],
            "zone"
        );
        this.subTabs = [];
        for (const o in this.selectedTab) {
            this.subTabs.push(o);
        }

        const subTab = this.subTabs[0];
        this.serialNumberList = [];
        this.serializationNumbers[this.tabIndex]?.forEach((item) => {
            if (item.zone === subTab) {
                this.serialNumberList.push(item);
            }
        });
    }

    onSelectSubTab(e: SelectEvent) {
        const subTab = this.subTabs[e.index];
        this.serialNumberList = [];
        this.serializationNumbers[this.tabIndex]?.forEach((item) => {
            if (item.zone === subTab) {
                this.serialNumberList.push(item);
            }
        });
    }

    groupArrayOfObjects(list, key) {
        return list.reduce(function (rv, x) {
            (rv[x[key]] = rv[x[key]] || []).push(x);
            return rv;
        }, {});
    }
    onCancel() {
        const currentUrl = this.router.url;
        this.router
            .navigateByUrl("/", { skipLocationChange: true })
            .then(() => {
                this.router.navigate([currentUrl]);
            });
    }

    onChangePartNum(part: any) {
        if (
            this.serializationToBeUpdated &&
            this.serializationToBeUpdated.length > 0
        ) {
            const itemIndex = this.getItemIndex(part);
            if (itemIndex !== -1)
                this.serializationToBeUpdated.splice(itemIndex, 1, {
                    serializationNumberToolsID: part.serializationNumberToolsID,
                    pilotproductid: this.pilotProductId,
                    partNum: part.partNum,
                    serialNum: part.serialNum,
                });
            else
                this.serializationToBeUpdated.push({
                    serializationNumberToolsID: part.serializationNumberToolsID,
                    pilotproductid: this.pilotProductId,
                    partNum: part.partNum,
                    serialNum: part.serialNum,
                });
        } else
            this.serializationToBeUpdated.push({
                serializationNumberToolsID: part.serializationNumberToolsID,
                pilotproductid: this.pilotProductId,
                partNum: part.partNum,
                serialNum: part.serialNum,
            });

        this.showSaveAndCancel = this.serializationToBeUpdated?.length > 0;
    }

    onChangeSerialNum(serial: any) {
        if (
            this.serializationToBeUpdated &&
            this.serializationToBeUpdated.length > 0
        ) {
            const itemIndex = this.getItemIndex(serial);
            if (itemIndex !== -1)
                this.serializationToBeUpdated.splice(itemIndex, 1, {
                    serializationNumberToolsID:
                        serial.serializationNumberToolsID,
                    pilotproductid: this.pilotProductId,
                    partNum: serial.partNum,
                    serialNum: serial.serialNum,
                });
            else
                this.serializationToBeUpdated.push({
                    serializationNumberToolsID:
                        serial.serializationNumberToolsID,
                    pilotproductid: this.pilotProductId,
                    partNum: serial.partNum,
                    serialNum: serial.serialNum,
                });
        } else
            this.serializationToBeUpdated.push({
                serializationNumberToolsID: serial.serializationNumberToolsID,
                pilotproductid: this.pilotProductId,
                partNum: serial.partNum,
                serialNum: serial.serialNum,
            });

        this.showSaveAndCancel = this.serializationToBeUpdated?.length > 0;
    }

    getItemIndex(part: any): number {
        for (let i = 0; i < this.serializationToBeUpdated.length; i++) {
            if (
                this.serializationToBeUpdated[i].serializationNumberToolsID ===
                part.serializationNumberToolsID
            ) {
                return i;
            }
        }
        return -1;
    }

    public showSuccess(msg: string): void {
        this.notificationService.show({
            appendTo: this.appendTo,
            content: msg,
            position: { horizontal: "left", vertical: "bottom" },
            animation: { type: "fade", duration: 600 },
            type: { style: "success", icon: true },
        });
    }

    onOpenConfirmationPopup() {
        if (
            this.serializationToBeUpdated &&
            this.serializationToBeUpdated.length > 0
        )
            this.openConfirmationPopup = true;
        else this.goToEditModHome();
    }

    goToSOELink() {
        if (this.site?.plantName !== "Fremont") {
            window.open(
                "https://lamresearch.quickbase.com/db/bhmqdixgx?a=nwr&_fid_129=" +
                    this.moduleInfo.ModuleInfo.BEN +
                    "&_fid_16=SOE%20Error",
                "_blank"
            );
        } else {
            window.open(
                "https://lamresearch.quickbase.com/db/bgmh64wg7?a=nwr&_fid_11=" +
                    this.divisionInfo.divisionName +
                    "&_fid_50=" +
                    this.moduleInfo.ModuleInfo.FCID +
                    "&_fid_147=" +
                    this.moduleInfo.ModuleInfo.PilotSerialNumber +
                    "&_fid_16=SOE%20Error",
                "_blank"
            );
        }
    }
}
