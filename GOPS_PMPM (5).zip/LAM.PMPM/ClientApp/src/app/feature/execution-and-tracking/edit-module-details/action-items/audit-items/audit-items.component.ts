import { HttpClient } from "@angular/common/http";
import {
    Component,
    Input,
    OnChanges,
    SimpleChanges,
    ViewEncapsulation,
} from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { AppStoreService } from "../../../../../core/app-store.service";
import { UserModel } from "../../../../../core/model/user.model";
import { DataServiceEandTService } from "../../../data-service-eand-t.service";

@Component({
    selector: "pmpm-audit-items",
    templateUrl: "./audit-items.component.html",
    styleUrls: ["./audit-items.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class AuditItemsComponent implements OnChanges {
    @Input() pilotProductId: number;
    @Input() userDetails: UserModel;
    canStartWork: boolean;
    public dataItems: string[] = ["Critical", "Gating"];
    public dataValue: string[] = [];

    //Grid
    public gridData: any;

    constructor(
        private router: Router,
        private route: ActivatedRoute,
        private service: DataServiceEandTService,
        private appStore: AppStoreService,
        private http: HttpClient
    ) {}

    ngOnChanges(changes: SimpleChanges): void {
        if (
            changes["pilotProductId"] &&
            changes["pilotProductId"] !== null &&
            changes["pilotProductId"].currentValue
        ) {
            this.pilotProductId = changes["pilotProductId"].currentValue;
            this.getGridData();
        }
        if (
            changes["userDetails"] &&
            changes["userDetails"] !== null &&
            changes["userDetails"].currentValue
        ) {
            this.userDetails = changes["userDetails"].currentValue;
            this.getGridData();
        }
    }

    getGridData() {
        this.service.getAuditItems(this.pilotProductId).subscribe((items) => {
            this.gridData = items;
            if (
                this.gridData.workRecordID > 0 &&
                this.gridData.userId == this.userDetails.userId
            )
                this.canStartWork = false;
            else this.canStartWork = true;
        });
    }

    reloadPage(event) {
        if (event) {
            this.getGridData();
        }
    }
}
