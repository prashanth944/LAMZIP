import {
    AfterViewInit,
    Component,
    OnInit,
    ViewChild,
    ViewEncapsulation,
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SelectEvent, TabStripComponent } from '@progress/kendo-angular-layout';
import { AppStoreService } from '../../../core/app-store.service';
import { Plant } from '../../../core/model/user.model';
import { Item } from '../../model/item';
import { DataServiceEandTService } from '../data-service-eand-t.service';
import { EditModuleViewModel, ModuleSummary } from '../Models/ModuleSummary';

@Component({
    selector: 'pmpm-edit-module-details',
    templateUrl: './edit-module-details.component.html',
    styleUrls: ['./edit-module-details.component.css'],
    encapsulation: ViewEncapsulation.None,
})
export class EditModuleDetailsComponent implements OnInit, AfterViewInit {
    @ViewChild('tabstrip') public tabstrip: TabStripComponent;
    public moduleInfo: ModuleSummary = null;
    public site: Plant;
    public buildType: Item[] = [];
    public productTypeGroup: Item[] = [];
    public toolTypeItems: Item[] = [];
    public moduleData: EditModuleViewModel;
    public buildStyle = '';
    public pilotProductId: number;
    public tabId = 0;

    constructor(
        private appStoreService: AppStoreService,
        private service: DataServiceEandTService,
        private route: ActivatedRoute,
        private router: Router
    ) {}
    ngOnInit() {
        this.route.params.subscribe((param) => {
            this.pilotProductId = +param.id;
            this.tabId = +param.tabId;
            this.service
                .getMyModuleSummary(this.pilotProductId)
                .subscribe((res) => {
                    this.moduleData = res;
                });
        });
        this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site) {
                this.site = {
                    plantName: site.plantName,
                    plantId: site.plantId,
                };
                this.service
                    .getModuleSummaryByID(+this.pilotProductId)
                    .toPromise()
                    .then((data) => {
                        if (data && data.length > 0) {
                            this.moduleInfo = data.filter(
                                (item) =>
                                    +item.ModuleInfo.PilotProductID ===
                                    +this.pilotProductId
                            )[0];
                            this.buildStyle =
                                this.moduleInfo.ModuleInfo.BuildStyle;
                        }
                    });
            }
        });
    }

    public ngAfterViewInit() {
        Promise.resolve(null).then(() => this.tabstrip.selectTab(this.tabId));
    }

    getBuildStyle(buildStyle: string) {
        this.buildStyle = buildStyle;
    }

    public onSelect(e: SelectEvent) {
        this.tabId = e.index;
        if (this.tabId === 2) {
            // Operations Tab
            this.service
                .getMyModuleSummary(this.pilotProductId)
                .subscribe((res) => {
                    this.moduleData = res;
                });
        } else if (this.tabId === 1) {
            // Schedule Tab
            this.service
                .getMyModuleSummary(this.pilotProductId)
                .subscribe((res) => {
                    this.moduleData = res;
                });
        }
        if (
            (this.buildStyle?.toLowerCase() === 'reconfig' &&
                this.tabId === 4) ||
            (this.buildStyle?.toLowerCase() !== 'reconfig' &&
                this.buildStyle?.toLowerCase() !== 'special subassembly' &&
                this.tabId === 3) ||
            (this.buildStyle?.toLowerCase() === 'special subassembly' &&
                this.tabId === 2)
        ) {
            this.router.navigate([
                '/action-items/' + this.pilotProductId + '/' + 0,
            ]);
        }

        // Code to manage the hide of the SAFE tab
        //if (this.tabId > 6 && this.site.plantName !== 'Tualatin' ){
        //  this.tabId = this.tabId + 1;
        //}
    }
    removedWIPFlag(event) {
        this.moduleData.inWIP = false;
    }
}
