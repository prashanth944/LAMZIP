import { Component, OnInit, ViewChild, ViewEncapsulation } from "@angular/core";
import { Router } from "@angular/router";
import { MultiSelectComponent } from "@progress/kendo-angular-dropdowns";
import { TooltipDirective } from "@progress/kendo-angular-tooltip";
import {
    CompositeFilterDescriptor,
    distinct,
    filterBy,
} from "@progress/kendo-data-query";
import { AppStoreService } from "../../../../../core/app-store.service";
import { Plant } from "../../../../../core/model/user.model";
import { DataServiceEandTService } from "../../../data-service-eand-t.service";
import { SafetyLinedown } from "../../../Models/safety-linedown.model";

@Component({
    selector: "pmpm-safety-linedown",
    templateUrl: "./safety-linedown.component.html",
    styleUrls: ["./safety-linedown.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class SafetyLinedownComponent implements OnInit {
    @ViewChild(TooltipDirective) public tooltipDir: TooltipDirective;
    @ViewChild("multiselect") public multiselect: MultiSelectComponent;

    public gridData = [];
    public userData: any;
    public site: Plant;
    public userId: number;
    public isLoading = true;
    public originalData = [];
    public hoverMessage = "";
    public searchText = "";
    public filter: CompositeFilterDescriptor;
    public issueTypeDataItem: string[] = [];
    public issueTypeList: string[] = [];
    public tempFilteredList: string[] = [];

    constructor(
        private service: DataServiceEandTService,
        private appStoreService: AppStoreService,
        private router: Router
    ) {}

    ngOnInit(): void {
        this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site) {
                this.site = {
                    plantName: site.plantName,
                    plantId: site.plantId,
                };
                this.getSafetyAndLineDown();
            }
        });

        this.appStoreService.getLoggedInUser().subscribe((user) => {
            this.appStoreService.getUserDetails(user.mail).subscribe((res) => {
                if (res && res.username.length > 0) {
                    this.userData = res;
                }
            });
        });
    }

    public getSafetyAndLineDown() {
        this.service
            .GetSafetyAndLineDown(this.site.plantId)
            .subscribe((res) => {
                if (res && res.length > 0) {
                    this.gridData = res;
                    this.originalData = JSON.parse(
                        JSON.stringify(this.gridData)
                    );
                    this.getFilterList();
                }
                this.isLoading = false;
            });
    }

    getFilterList() {
        let issueType: any = distinct(this.originalData, "issueType").map(
            (item) => item["issueType"]
        );
        issueType = issueType.flatMap((f) => (f ? [f] : []));
        issueType.sort(function (a, b) {
            const textA = a?.toUpperCase();
            const textB = b?.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
        });
        this.issueTypeList = [...issueType];
        this.tempFilteredList = JSON.parse(JSON.stringify(this.issueTypeList));
    }

    public routeToEditModule(dataItem: SafetyLinedown) {
        this.router.navigate([
            "/edit-module/" + dataItem.pilotProductID + "/" + 0,
        ]);
    }

    //Tooltip
    public showTooltip(e: MouseEvent): void {
        const element = e.target as HTMLElement;
        if (
            (element.nodeName === "TH" || element.nodeName === "TD") &&
            element.offsetWidth < element.scrollWidth
        ) {
            this.hoverMessage = element.textContent;
            this.tooltipDir.toggle(element);
        } else {
            this.tooltipDir.hide();
        }
    }

    //Search
    onSearchFilter() {
        const filter: CompositeFilterDescriptor = { filters: [], logic: "and" };
        if (this.searchText && this.searchText.length > 0) {
            if (this.site.plantName == "Fremont") {
                const searchFilter = [
                    {
                        field: "fcidPilotSerial",
                        operator: "contains",
                        value: this.searchText.trim(),
                    },
                    {
                        field: "toolSerial",
                        operator: "contains",
                        value: this.searchText.trim(),
                    },
                    {
                        field: "issueTitle",
                        operator: "contains",
                        value: this.searchText.trim(),
                    },
                    {
                        field: "issueType",
                        operator: "contains",
                        value: this.searchText.trim(),
                    },
                    {
                        field: "productDesignCategory",
                        operator: "contains",
                        value: this.searchText.trim(),
                    },
                ];
                filter.filters.push({
                    filters: [...searchFilter],
                    logic: "or",
                });
            } else {
                const searchFilter = [
                    {
                        field: "ben",
                        operator: "contains",
                        value: this.searchText.trim(),
                    },
                    {
                        field: "toolSerial",
                        operator: "contains",
                        value: this.searchText.trim(),
                    },
                    {
                        field: "issueTitle",
                        operator: "contains",
                        value: this.searchText.trim(),
                    },
                    {
                        field: "issueType",
                        operator: "contains",
                        value: this.searchText.trim(),
                    },
                    {
                        field: "productDesignCategory",
                        operator: "contains",
                        value: this.searchText.trim(),
                    },
                ];
                filter.filters.push({
                    filters: [...searchFilter],
                    logic: "or",
                });
            }
        }

        if (this.issueTypeDataItem && this.issueTypeDataItem.length > 0) {
            const issueType: any[] = [];
            this.issueTypeDataItem.forEach((item) => {
                issueType.push({
                    field: "issueType",
                    operator: "contains",
                    value: item,
                });
            });
            filter.filters.push({ filters: [...issueType], logic: "or" });
        }

        this.filter = filter;
        this.gridData = filterBy(this.originalData, filter);
    }

    //Filter
    handleFilter(value) {
        if (value.length >= 0) {
            this.issueTypeList = this.tempFilteredList.filter(
                (s) => s?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
            );
        } else {
            this.multiselect.toggle(false);
        }
    }
}
