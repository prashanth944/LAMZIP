import {
    Component,
    Input,
    OnInit,
    ViewChild,
    ViewEncapsulation,
} from "@angular/core";
import { Router } from "@angular/router";
import { Plant, UserModel } from "../../../../../core/model/user.model";
import { DataServiceEandTService } from "../../../data-service-eand-t.service";
import { TOI } from "../../../Models/toi.model";
import { process } from "@progress/kendo-data-query";
import { MultiSelectComponent } from "@progress/kendo-angular-dropdowns";
import { AppStoreService } from "../../../../../core/app-store.service";
import { role, uiScreen } from "../../../../../core/model/common.constant";
import { HttpClient } from "@angular/common/http";
import { environment } from "../../../../../../environments/environment.dev_server";
import * as moment from "moment";
declare let require: any;

interface Item {
    text: string;
    value: number;
}

@Component({
    selector: "pmpm-toi",
    templateUrl: "./toi.component.html",
    styleUrls: ["./toi.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class TOIComponent implements OnInit {
    @ViewChild("multiselect") public multiselect: MultiSelectComponent;
    @Input() pilotProductId: number;
    @Input() ben = "";
    @Input() site: Plant;
    readonly apiUrl = `${environment.apiUrl}`;
    public gridDataForTOIOpen: TOI[] = [];
    public gridDataForTOICompleted: TOI[] = [];
    public tempGridDataForTOIOpen: TOI[] = [];
    public tempGridDataForTOICompleted: TOI[] = [];
    public addTOIOpened = false;
    public toiStatusData: Item[] = [];
    public toiCGData = [" ", "Critical", "Gating"];
    public toiStatus: Item;
    public toiCG = " ";
    public fileToUpload: File[] = [];
    public uploadedFiles: string[] = [];
    public toiTitle = "";
    public toiDescription = "";
    public toiComments = "";
    public disableSaveBtn = true;
    public loadOpenTable = true;
    public loadCompleteTable = true;
    public addEditText = "";
    public minDate = new Date();
    public expectedCloseDate: Date;
    public gatingDate: Date;
    public toiId: number;
    public dateValue = new Date();
    public zoneData: Item[] = [];
    public toiZone: Item;
    public disableUpload = false;
    public urgencyDataItems: string[] = ["Critical", "Gating"];
    public tempUrgencyDataItems: string[] = ["Critical", "Gating"];
    public urgencyDataValue: string[] = [];
    public isUserAccess = false;
    public showCompletedSection = false;
    public lessThanTodayExpectedDateError = false;
    public lessThanTodayGatingDateError = false;
    public userDetails: UserModel;
    public searchText = "";
    public canEditCriticalGating = false;
    public criticalGatingError = false;
    public expectedDateError = false;
    public gatingDateError = false;
    public sameFileError = false;
    public sameFileErrorMessage = "";

    constructor(
        private service: DataServiceEandTService,
        private router: Router,
        private appStoreService: AppStoreService,
        private http: HttpClient
    ) {}

    ngOnInit() {
        this.zoneData = [];
        this.appStoreService.getLoggedInUser().subscribe((res) => {
            this.appStoreService.getUserDetails(res.mail).subscribe((user) => {
                if (user && user.username?.length > 0) {
                    this.userDetails = user;
                    this.getTOIDetails();
                }
            });
        });
        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.TOI)
                    .subscribe((result) => {
                        this.isUserAccess = result;
                        if (
                            res.includes(role.Manager) ||
                            res.includes(role.Leads) ||
                            res.includes(role.Supervisor) ||
                            res.includes(role.ProjectManager) ||
                            res.includes(role.SuperUser)
                        )
                            this.canEditCriticalGating = true;
                    });
            }
        });
        this.service.GetTOIStatus().subscribe((res) => {
            if (res && res.length > 0) {
                this.toiStatusData = [];
                res.forEach((item) => {
                    this.toiStatusData.push({
                        text: item.masterRecordName,
                        value: item.masterRecordID,
                    });
                });
                this.toiStatus = this.toiStatusData[0];
            }
        });
        this.service.GetTOIZone(+this.pilotProductId).subscribe((res) => {
            if (res && res.length > 0) {
                res.forEach((item) => {
                    this.zoneData.push({
                        text: item.description,
                        value: item.zoneID,
                    });
                    this.zoneData.sort(function (a, b) {
                        const textA = a?.text?.toUpperCase();
                        const textB = b?.text?.toUpperCase();
                        return textA < textB ? -1 : textA > textB ? 1 : 0;
                    });
                });
            }
        });
    }

    getTOIDetails() {
        this.loadOpenTable = true;
        this.loadCompleteTable = true;
        this.gridDataForTOIOpen = [];
        this.gridDataForTOICompleted = [];
        this.tempGridDataForTOIOpen = [];
        this.tempGridDataForTOICompleted = [];
        this.service
            .GetTOIDetails("Open", +this.pilotProductId)
            .subscribe((res) => {
                this.loadOpenTable = false;
                if (res && res.length > 0) {
                    res.forEach((item) => {
                        item.issueDescriptionWithoutTag =
                            item.issueDescription.replace(/(<([^>]+)>)/gi, "");
                        item.comments = this.getNotesInDifferentLines(
                            item.comments
                        );
                        if (item.isCritical) item.criticalGating = "Critical";
                        else if (item.isGating) item.criticalGating = "Gating";
                        else item.criticalGating = "";
                    });
                    this.gridDataForTOIOpen = res;
                    this.tempGridDataForTOIOpen = JSON.parse(
                        JSON.stringify(this.gridDataForTOIOpen)
                    );
                }
            });
        this.service
            .GetTOIDetails("Complete", +this.pilotProductId)
            .subscribe((res) => {
                this.loadCompleteTable = false;
                if (res && res.length > 0) {
                    res.forEach((item) => {
                        item.issueDescriptionWithoutTag =
                            item.issueDescription.replace(/(<([^>]+)>)/gi, "");
                        item.comments = this.getNotesInDifferentLines(
                            item.comments
                        );
                        if (item.isCritical) item.criticalGating = "Critical";
                        else if (item.isGating) item.criticalGating = "Gating";
                        else item.criticalGating = "";
                    });
                    this.gridDataForTOICompleted = res;
                    this.tempGridDataForTOICompleted = JSON.parse(
                        JSON.stringify(this.gridDataForTOICompleted)
                    );
                }
            });
    }

    getNotesInDifferentLines(data) {
        let newNotes = "";
        if (data != null) {
            const notesArr = data.split("|");
            notesArr.forEach((val) => {
                if (val.trim() != "") newNotes = newNotes + val.trim() + "\n";
            });
        }
        return newNotes;
    }

    onItemClick(value) {
        value.checked = !value.checked;
        if (value.checked) {
            this.gridDataForTOIOpen = process(this.tempGridDataForTOIOpen, {
                filter: {
                    logic: "or",
                    filters: [
                        {
                            field: "criticalGating",
                            operator: "eq",
                            value: value.text,
                        },
                    ],
                },
            }).data;

            this.gridDataForTOICompleted = process(
                this.tempGridDataForTOICompleted,
                {
                    filter: {
                        logic: "or",
                        filters: [
                            {
                                field: "criticalGating",
                                operator: "eq",
                                value: value.text,
                            },
                        ],
                    },
                }
            ).data;
        }
    }

    onAddTOI() {
        this.addEditText = "Add";
        this.addTOIOpened = true;
    }
    onCloseAddTOI() {
        this.addTOIOpened = false;
        this.resetAddTOIForm();
    }
    handleFileInput(files: FileList) {
        this.sameFileError = false;
        this.sameFileErrorMessage = "";
        if (
            this.uploadedFiles.length > 6 ||
            files.length > 6 ||
            this.uploadedFiles.length + files.length > 6
        ) {
            this.disableUpload = true;
        } else {
            this.disableUpload = false;
            const item = Array.from(files);
            item.forEach((f) => {
                if (!this.uploadedFiles?.includes(f.name)) {
                    this.fileToUpload.push(f);
                    this.uploadedFiles.push(f.name);
                } else {
                    this.sameFileError = true;
                    this.sameFileErrorMessage +=
                        (this.sameFileErrorMessage.length > 0 ? ", " : "") +
                        f.name;
                }
            });
        }
    }

    uploadFiles(files) {
        const formData: FormData = new FormData();
        for (let i = 0; i < files.length; i++) {
            formData.append("fileKey", files[i], files[i].name);
        }

        this.service.uploadTOIfile(this.toiId, formData).subscribe((req) => {
            if (req && req["value"] === "Updated Successfully") {
                this.resetAddTOIForm();
                this.getTOIDetails();
            }
        });
    }

    download(file: string) {
        this.http
            .get(
                this.apiUrl + "/TOI/downloadTOIfile/" + this.toiId + "/" + file,
                { responseType: "blob" }
            )
            .subscribe((result: any) => {
                if (result) {
                    const blob = new Blob([result]);
                    const saveAs = require("file-saver");
                    const fileName = file;
                    saveAs(blob, fileName);
                } else {
                    alert("File not found in Blob!");
                }
            });
    }

    removeFile(file: string, index) {
        if (this.fileToUpload.filter((f) => f.name === file)?.length === 0) {
            if (this.toiId !== null && this.toiId !== undefined)
                this.service
                    .deleteTOIfile(this.toiId, file)
                    .subscribe((req) => {});
        }
        const after = Array.from(this.uploadedFiles);
        after.splice(index, 1);
        this.uploadedFiles = JSON.parse(JSON.stringify(after));
        this.fileToUpload.splice(index, 1);
    }

    onInputTitle() {
        if (
            this.toiTitle?.trim()?.length > 0 &&
            this.toiDescription.trim().length > 0
        )
            this.disableSaveBtn = false;
        else this.disableSaveBtn = true;
    }
    onInputDescription() {
        if (
            this.toiTitle?.trim()?.length > 0 &&
            this.toiDescription.trim().length > 0
        )
            this.disableSaveBtn = false;
        else this.disableSaveBtn = true;
    }

    onSaveTOI() {
        const request = new TOI();
        request.isGating = this.toiCG === "Gating";
        request.isCritical = this.toiCG === "Critical";
        if (
            (request.isCritical || request.isGating) &&
            (this.expectedCloseDate === null ||
                this.expectedCloseDate === undefined)
        ) {
            this.expectedDateError = true;
        } else if (
            (request.isCritical || request.isGating) &&
            (this.gatingDate === null || this.gatingDate === undefined)
        ) {
            this.gatingDateError = true;
        } else {
            request.pilotProductID = +this.pilotProductId;
            request.ben = this.ben;
            request.title = this.toiTitle;
            request.issueDescription = this.toiDescription;

            request.statusID = this.toiStatus?.value;

            const com = this.toiComments.split("]");
            if (com && com.length > 1) {
                const com1 = com[1].split("\n");
                if (com1 && com1.length > 1) this.toiComments = com1[1];
            }
            const comment =
                this.toiComments?.length > 0
                    ? "[" +
                      moment(new Date()).format("MMM-DD-yyyy").toString() +
                      ", " +
                      this.userDetails.firstName +
                      " " +
                      this.userDetails.lastName +
                      "]: " +
                      this.toiComments
                    : "";
            request.comments = comment;

            if (
                this.expectedCloseDate !== null &&
                this.expectedCloseDate !== undefined
            ) {
                request.expectedCloseDate = new Date(
                    this.expectedCloseDate.getTime() -
                        new Date(this.expectedCloseDate).getTimezoneOffset() *
                            60000
                );
            }
            if (this.gatingDate !== null && this.gatingDate !== undefined) {
                request.gatingDate = new Date(
                    this.gatingDate.getTime() -
                        new Date(this.gatingDate).getTimezoneOffset() * 60000
                );
            }
            if (this.toiZone) {
                request.zoneID = this.toiZone.value;
                request.zoneName = this.toiZone.text;
            }
            if (this.fileToUpload?.length > 0) {
                request.toiid = this.addEditText !== "Add" ? this.toiId : null;
                if (this.addEditText === "Add") {
                    request.createdBy =
                        this.userDetails?.firstName +
                        " " +
                        this.userDetails?.lastName;
                    request.createdById = this.userDetails?.userId;
                    request.createdOnDate = new Date(
                        new Date().getTime() -
                            new Date().getTimezoneOffset() * 60000
                    );
                } else {
                    request.updatedBy =
                        this.userDetails?.firstName +
                        " " +
                        this.userDetails?.lastName;
                    request.updatedById = this.userDetails?.userId;
                    request.updatedOnDate = new Date(
                        new Date().getTime() -
                            new Date().getTimezoneOffset() * 60000
                    );
                }
                this.service.AddTOI(request).subscribe((res) => {
                    if (res && res.data) {
                        this.toiId = res.data;
                        this.addTOIOpened = false;
                        this.searchText = "";
                        this.urgencyDataValue = [];
                        this.uploadFiles(this.fileToUpload);
                    }
                });
            } else {
                request.toiid = this.addEditText !== "Add" ? this.toiId : null;
                if (this.addEditText === "Add") {
                    request.createdBy =
                        this.userDetails?.firstName +
                        " " +
                        this.userDetails?.lastName;
                    request.createdById = this.userDetails?.userId;
                    request.createdOnDate = new Date(
                        new Date().getTime() -
                            new Date().getTimezoneOffset() * 60000
                    );
                } else {
                    request.updatedBy =
                        this.userDetails?.firstName +
                        " " +
                        this.userDetails?.lastName;
                    request.updatedById = this.userDetails?.userId;
                    request.updatedOnDate = new Date(
                        new Date().getTime() -
                            new Date().getTimezoneOffset() * 60000
                    );
                }
                this.service.AddTOI(request).subscribe((res) => {
                    this.getTOIDetails();
                });
                this.addTOIOpened = false;
                this.searchText = "";
                this.urgencyDataValue = [];
                this.resetAddTOIForm();
            }
        }
    }

    resetAddTOIForm() {
        this.toiTitle = "";
        this.toiDescription = "";
        this.toiComments = "";
        this.toiStatus = this.toiStatusData[0];
        this.toiCG = " ";
        this.uploadedFiles = [];
        this.disableSaveBtn = true;
        this.expectedCloseDate = null;
        this.gatingDate = null;
        this.toiZone = undefined;
        this.fileToUpload = [];
        this.disableUpload = false;
        this.lessThanTodayExpectedDateError = false;
        this.lessThanTodayGatingDateError = false;
        this.criticalGatingError = false;
        this.expectedDateError = false;
        this.gatingDateError = false;
        this.sameFileError = false;
        this.sameFileErrorMessage = "";
    }

    onEditTOI(dataItem: TOI) {
        this.addEditText = "Edit";
        this.toiId = dataItem.toiid;
        this.toiTitle = dataItem.title;
        this.toiDescription = dataItem.issueDescription;
        this.toiComments = "";
        const statusValue = this.toiStatusData.filter(
            (item) => item.text === dataItem.status
        )[0].value;
        this.toiStatus = {
            text: dataItem.status,
            value: statusValue,
        };
        this.toiZone = {
            text: dataItem.zoneName,
            value: dataItem.zoneID,
        };
        this.toiCG = this.toiCGData.filter(
            (item) => item === dataItem.criticalGating
        )[0];
        if (this.toiCG === undefined || this.toiCG === null) {
            this.toiCG = " ";
        }
        if (dataItem.expectedCloseDate !== null)
            this.expectedCloseDate = new Date(dataItem.expectedCloseDate);
        if (dataItem.gatingDate !== null)
            this.gatingDate = new Date(dataItem.gatingDate);
        if (dataItem.files.length > 0) {
            this.uploadedFiles = JSON.parse(JSON.stringify(dataItem.files));
        }
        this.ben =
            this.site.plantName === "Fremont"
                ? dataItem.pilotSerialNumber
                : dataItem.ben;
        this.disableSaveBtn = false;
        this.addTOIOpened = true;
    }

    onViewTOI(dataItem: TOI) {
        this.router.navigate([
            "/view-toi/" + dataItem.toiid + "/" + this.pilotProductId,
        ]);
    }
    public onSearchFilter(
        inputValue: string,
        openData: TOI[],
        completeData: TOI[],
        isCalledInside: boolean
    ): void {
        this.searchText = inputValue;
        const data1 = JSON.parse(
            JSON.stringify(this.onSearchOpen(inputValue, openData))
        );
        const data2 = JSON.parse(
            JSON.stringify(this.onSearchComplete(inputValue, completeData))
        );
        if (!isCalledInside) {
            if (this.urgencyDataValue.length > 0) {
                this.onUrgencyChange(this.urgencyDataValue, data1, data2, true);
            }
        }
    }
    onSearchOpen(inputValue: string, openData: TOI[]) {
        this.gridDataForTOIOpen = process(openData, {
            filter: {
                logic: "or",
                filters: [
                    {
                        field: "toiid",
                        operator: "contains",
                        value: inputValue,
                    },
                    {
                        field: "title",
                        operator: "contains",
                        value: inputValue,
                    },
                ],
            },
        }).data;
        return this.gridDataForTOIOpen;
    }

    onSearchComplete(inputValue: string, completeData: TOI[]) {
        this.gridDataForTOICompleted = process(completeData, {
            filter: {
                logic: "or",
                filters: [
                    {
                        field: "toiid",
                        operator: "contains",
                        value: inputValue,
                    },
                    {
                        field: "title",
                        operator: "contains",
                        value: inputValue,
                    },
                ],
            },
        }).data;
        return this.gridDataForTOICompleted;
    }

    handleUrgencyFilter(value) {
        if (value.length >= 0) {
            this.urgencyDataItems = this.tempUrgencyDataItems.filter(
                (s) => s?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
            );
        } else {
            this.multiselect.toggle(false);
        }
    }

    onUrgencyChange(
        value: string[],
        openData: TOI[],
        completeData: TOI[],
        isCalledInside: boolean
    ) {
        this.gridDataForTOIOpen = [];
        this.gridDataForTOICompleted = [];
        if (value.length > 0) {
            value.forEach((item) => {
                const data1 = openData.filter((i) => i.criticalGating === item);
                this.gridDataForTOIOpen = [
                    ...this.gridDataForTOIOpen,
                    ...data1,
                ];
                const data2 = completeData.filter(
                    (i) => i.criticalGating === item
                );
                this.gridDataForTOICompleted = [
                    ...this.gridDataForTOICompleted,
                    ...data2,
                ];
            });
        } else {
            this.gridDataForTOICompleted = JSON.parse(
                JSON.stringify(this.tempGridDataForTOICompleted)
            );
            this.gridDataForTOIOpen = JSON.parse(
                JSON.stringify(this.tempGridDataForTOIOpen)
            );
        }
        if (!isCalledInside) {
            if (this.searchText.length > 0) {
                this.onSearchFilter(
                    this.searchText,
                    JSON.parse(JSON.stringify(this.gridDataForTOIOpen)),
                    JSON.parse(JSON.stringify(this.gridDataForTOICompleted)),
                    true
                );
            }
        }
    }
    onClickCompletedSection() {
        this.showCompletedSection = !this.showCompletedSection;
    }

    onExpectedDateChange(value: Date) {
        this.minDate.setHours(0, 0, 0, 0);
        if (value === null || value === undefined) {
            this.expectedDateError = true;
            this.lessThanTodayExpectedDateError = false;
        } else {
            this.expectedDateError = false;
            if (value?.getTime() < this.minDate?.getTime()) {
                this.lessThanTodayExpectedDateError = true;
            } else {
                this.lessThanTodayExpectedDateError = false;
            }
        }
    }
    onGatingDateChange(value: Date) {
        this.minDate.setHours(0, 0, 0, 0);
        if (value === null || value === undefined) {
            this.gatingDateError = true;
            this.lessThanTodayExpectedDateError = false;
        } else {
            this.gatingDateError = false;
            if (value?.getTime() < this.minDate?.getTime()) {
                this.lessThanTodayGatingDateError = true;
            } else {
                this.lessThanTodayGatingDateError = false;
            }
        }
    }

    onValueChange(value: string) {
        if (value?.trim()?.length === 0) {
            this.expectedCloseDate = null;
            this.gatingDate = null;
            this.lessThanTodayExpectedDateError = false;
            this.lessThanTodayGatingDateError = false;
            this.expectedDateError = false;
            this.gatingDateError = false;
        } else {
            this.criticalGatingError = false;
        }
    }
    upload() {
        const input = document.getElementById("file");
        input.click();
    }
}
