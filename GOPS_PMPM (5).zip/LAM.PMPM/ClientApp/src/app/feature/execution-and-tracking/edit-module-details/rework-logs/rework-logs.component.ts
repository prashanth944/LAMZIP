import { Component, Input, OnInit, ViewEncapsulation } from "@angular/core";
import { Router } from "@angular/router";
import { AppStoreService } from "../../../../core/app-store.service";
import { uiScreen } from "../../../../core/model/common.constant";
import { DataServiceEandTService } from "../../data-service-eand-t.service";

@Component({
    selector: "pmpm-rework-logs",
    templateUrl: "./rework-logs.component.html",
    styleUrls: ["./rework-logs.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class ReworkLogsComponent implements OnInit {
    @Input() pilotProductId: number;

    public gridData: any = [];

    //Authentication
    canUserEdit = false; //Task 24219: Entire Page - Edit for Supervisor, Lead, Technician

    constructor(
        private service: DataServiceEandTService,
        private router: Router,
        private appStoreService: AppStoreService
    ) {}

    ngOnInit(): void {
        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.EditReworkLog)
                    .subscribe((result) => {
                        this.canUserEdit = result;
                    });
            }
        });

        this.service.getReworkLogs(this.pilotProductId).subscribe((res) => {
            if (res.length > 0) {
                this.gridData = res;
            }
        });
    }

    goToLogProgressRework(dataItem) {
        //navigate to Log Progress --> Rework tab
        const isEdit = true;
        this.router.navigate([
            "/log-progress/" +
                dataItem?.pilotProductID +
                "/" +
                dataItem?.operationID +
                "/" +
                2 +
                "/" +
                isEdit +
                "/" +
                dataItem?.workRecordID,
        ]);
    }
}
