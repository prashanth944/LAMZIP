import {
  Component,
  Input,
  OnChanges,
  OnInit,
  SimpleChanges,
  ViewChild,
  ViewEncapsulation,
} from "@angular/core";
import { Plant, UserModel } from "../../../../../core/model/user.model";
import { DataServiceEandTService } from "../../../data-service-eand-t.service";
import {
  CompositeFilterDescriptor,
  distinct,
  filterBy,
} from "@progress/kendo-data-query";
import { IssueLogView } from "../../../Models/obc.model";
import { ModuleSummary } from "../../../Models/ModuleSummary";
import { Item } from "../../../../model/item";
import { HttpClient } from "@angular/common/http";
import { environment } from "../../../../../../environments/environment.dev_server";
import * as moment from "moment";
import { TOI } from "../../../Models/toi.model";
import { AppStoreService } from "../../../../../core/app-store.service";
import { role, uiScreen } from "../../../../../core/model/common.constant";
import { MultiSelectComponent } from "@progress/kendo-angular-dropdowns";
import { Router } from "@angular/router";
declare let require: any;

@Component({
  selector: "pmpm-issues-log",
  templateUrl: "./issues-log.component.html",
  styleUrls: ["./issues-log.component.css"],
  encapsulation: ViewEncapsulation.None,
})
export class IssuesLogComponent implements OnInit, OnChanges {
  @ViewChild("multiselect") public multiselect: MultiSelectComponent;
  @Input() pilotProductId: number;
  @Input() site: Plant;

  readonly apiUrl = `${environment.apiUrl}`;

  public issueLogStatusCount: IssueLogView[] = [];
  public issueLogDetails: IssueLogView[] = [];
  public tempIssueLogDetails: IssueLogView[] = [];
  public loadingTable = true;

  public expandOpenTable = false;
  public expandClosedTable = false;
  public expandRejectedTable = false;
  public expandReviewedTable = false;
  public expandInProgressTable = false;
  public expandDeferredTable = false;
  public expandPrSubmittedTable = false;
  public expandNcrSubmittedTable = false;
  public lessThanTodayExpectedDateError = false;
  public lessThanTodayGatingDateError = false;
  public minDate = new Date();
  public zoneData: Item[] = [];
  public toiZone: Item;
  public toiComments = "";
  public toiId: number;
  public fileToUpload: File[] = [];
  public uploadedFiles: string[] = [];
  public disableUpload = false;

  public addTOIOpened = false;
  public toiStatus: Item;
  public toiTitle = "";
  public toiDescription = "";
  public disableSaveBtn = false;
  public toiStatusData: Item[] = [];
  public toiCGData = [" ", "Critical", "Gating"];
  public toiCG = " ";
  public expectedCloseDate: Date;
  public gatingDate: Date;
  public dateValue = new Date();
  public canEditCriticalGating = false;
  public userDetails: UserModel;

  public ben = "";
  public moduleInfo: ModuleSummary = null;

  public urgencyDataValue: string[] = [];
  public urgencyDataItems: string[] = [];
  public tempUrgencyDataItems: string[] = [];
  public issueTypeDataItems: string[] = [];
  public issueTypeDataValue: string[] = [];
  public tempIssueTypeDataItems: string[] = [];
  public partNumberItems: string[] = [];
  public tempPartNumberItems: string[] = [];
  public partNumberValue: string[] = [];

  public sections: string[] = [];
  public searchText = "";
  public filter: CompositeFilterDescriptor;
  public isUserAccess = false;
  public criticalGatingError = false;
  public expectedDateError = false;
  public gatingDateError = false;
  public sameFileError = false;
  public sameFileErrorMessage = "";

  constructor(
    private service: DataServiceEandTService,
    private http: HttpClient,
    private appStoreService: AppStoreService,
    private router: Router
  ) { }

  ngOnInit() {
    this.appStoreService.getLoggedInUser().subscribe((res) => {
      this.appStoreService.getUserDetails(res.mail).subscribe((user) => {
        if (user && user.username?.length > 0) {
          this.userDetails = user;
        }
      });
    });
    this.appStoreService.getUserRoles().subscribe((res) => {
      if (res && res.length > 0) {
        this.appStoreService
          .checkUserAccessRight(res, uiScreen.TOI)
          .subscribe((result) => {
            this.isUserAccess = result;
            if (
              res.includes(role.Manager) ||
              res.includes(role.Leads) ||
              res.includes(role.Supervisor) ||
              res.includes(role.SuperUser)
            )
              this.canEditCriticalGating = true;
          });
      }
    });
    this.service.GetTOIStatus().subscribe((res) => {
      if (res && res.length > 0) {
        this.toiStatusData = [];
        res.forEach((item) => {
          this.toiStatusData.push({
            text: item.masterRecordName,
            value: item.masterRecordID,
          });
        });
        this.toiStatus = this.toiStatusData[0];
      }
    });
    this.service.GetTOIZone(+this.pilotProductId).subscribe((res) => {
      if (res && res.length > 0) {
        res.forEach((item) => {
          this.zoneData.push({
            text: item.description,
            value: item.zoneID,
          });
          this.zoneData.sort(function (a, b) {
            const textA = a?.text?.toUpperCase();
            const textB = b?.text?.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
          });
        });
      }
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    if (
      changes["pilotProductId"] &&
      changes["pilotProductId"] !== null &&
      changes["pilotProductId"].currentValue
    ) {
      this.pilotProductId = changes["pilotProductId"].currentValue;
    }
    if (
      changes["site"] &&
      changes["site"] !== null &&
      changes["site"].currentValue
    ) {
      this.site = changes["site"].currentValue;
    }
    if (this.site !== undefined && this.pilotProductId !== undefined) {
      this.service
        .getModuleSummaryByID(+this.pilotProductId)
        .toPromise()
        .then((data) => {
          if (data && data.length > 0) {
            this.moduleInfo = data.filter(
              (item) =>
                +item.ModuleInfo.PilotProductID ===
                +this.pilotProductId
            )[0];
            if (
              this.site?.plantName === "Fremont" &&
              this.moduleInfo?.ModuleInfo?.PilotSerialNumber !==
              null
            ) {
              this.ben =
                this.moduleInfo?.ModuleInfo?.PilotSerialNumber;
              this.GetIssueLogStatusCount(
                this.moduleInfo?.ModuleInfo?.PilotSerialNumber
              );
              this.GetIssuLogDetails(
                this.moduleInfo?.ModuleInfo?.PilotSerialNumber
              );
            } else if (
              this.site?.plantName !== "Fremont" &&
              this.moduleInfo?.ModuleInfo?.BEN !== null
            ) {
              this.ben = this.moduleInfo?.ModuleInfo?.BEN;
              this.GetIssueLogStatusCount(
                this.moduleInfo?.ModuleInfo?.BEN
              );
              this.GetIssuLogDetails(
                this.moduleInfo?.ModuleInfo?.BEN
              );
            } else {
              this.loadingTable = false;
            }
          }
        });
    }
  }

  GetIssueLogStatusCount(id: string) {
    this.service
      .GetIssueLogStatusCount(id, this.site.plantId)
      .subscribe((res) => {
        if (res && res.length > 0) this.issueLogStatusCount = res;
      });
  }
  GetIssuLogDetails(id: string) {
    this.service
      .GetIssueLogDetails(id, this.site.plantId)
      .subscribe((res) => {
        if (res && res.length) {
          this.sections = distinct(res, "status").map(
            (item) => item["status"]
          );
          this.issueLogDetails = res;
          this.tempIssueLogDetails = JSON.parse(JSON.stringify(res));
          let data1: any = distinct(
            this.tempIssueLogDetails,
            "urgency"
          ).map((item) => item["urgency"]);
          data1 = data1.flatMap((f) => (f ? [f] : []));
          data1.sort(function (a, b) {
            const textA = a?.toUpperCase();
            const textB = b?.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
          });
          this.urgencyDataItems = data1;
          this.tempUrgencyDataItems = JSON.parse(
            JSON.stringify(data1)
          );

          let data2: any = distinct(
            this.tempIssueLogDetails,
            "issueType"
          ).map((item) => item["issueType"]);
          data2 = data2.flatMap((f) => (f ? [f] : []));
          data2.sort(function (a, b) {
            const textA = a?.toUpperCase();
            const textB = b?.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
          });
          this.issueTypeDataItems = data2;
          this.tempIssueTypeDataItems = JSON.parse(
            JSON.stringify(data2)
          );

          let data3: any = distinct(
            this.tempIssueLogDetails,
            "part"
          ).map((item) => item["part"]);
          data3 = data3.flatMap((f) => (f ? [f] : []));
          data3.sort(function (a, b) {
            const textA = a?.toUpperCase();
            const textB = b?.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
          });
          this.partNumberItems = data3;
          this.tempPartNumberItems = JSON.parse(
            JSON.stringify(data3)
          );
        }
      });
    this.loadingTable = false;
  }
  getGridData(section: string) {
    return this.issueLogDetails.filter(
      (item) => item.status.toUpperCase() === section.toUpperCase()
    );
  }
  openSection(issue: IssueLogView) {
    if (issue.count > 0) {
      switch (issue.statusforCount) {
        case "CLOSED":
          if (!this.expandClosedTable) {
            this.expandClosedTable = true;
            window.scrollTo(0, document.body.scrollHeight);
          }
          break;
        case "OPEN":
          if (!this.expandOpenTable) {
            this.expandOpenTable = true;
          }
          break;
        case "REJECTED":
          if (!this.expandRejectedTable) {
            this.expandRejectedTable = true;
            window.scrollTo(0, document.body.scrollHeight);
          }
          break;
        case "IN PROCESS":
          if (!this.expandInProgressTable) {
            this.expandInProgressTable = true;
            window.scrollTo(0, document.body.scrollHeight);
          }
          break;
        case "REVIEWED":
          if (!this.expandReviewedTable) {
            this.expandReviewedTable = true;
            window.scrollTo(0, document.body.scrollHeight);
          }
          break;
        case "PR SUBMITTED":
          if (!this.expandPrSubmittedTable) {
            this.expandPrSubmittedTable = true;
            window.scrollTo(0, document.body.scrollHeight);
          }
          break;
        case "NCR SUBMITTED":
          if (!this.expandNcrSubmittedTable) {
            this.expandNcrSubmittedTable = true;
            window.scrollTo(0, document.body.scrollHeight);
          }
          break;
        case "DEFERRED":
          if (!this.expandDeferredTable) {
            this.expandDeferredTable = true;
            window.scrollTo(0, document.body.scrollHeight);
          }
          break;
      }
    }
  }
  onAddTOI(dataItem: IssueLogView) {
    this.toiTitle = "Issue Log: " + dataItem.issueTitle;
    this.toiDescription =
      "Issue log number: " +
      dataItem.issueLog +
      " for " +
      dataItem.issueTitle +
      ". Issue Type: " +
      dataItem.issueType +
      " found at: " +
      moment(dataItem.dateCreated).format("MM-DD-yy HH:mm a") +
      (dataItem.part?.length > 0 ? " P/N: " + dataItem.part : "") +
      " Description: " +
      dataItem.issueDetail;
    this.addTOIOpened = true;
  }
  onCloseAddTOI() {
    this.addTOIOpened = false;
    this.resetAddTOIForm();
  }

  onInputTitle() {
    if (
      this.toiTitle?.trim()?.length > 0 &&
      this.toiDescription.trim().length > 0
    )
      this.disableSaveBtn = false;
    else this.disableSaveBtn = true;
  }

  onInputDescription() {
    if (
      this.toiTitle?.trim()?.length > 0 &&
      this.toiDescription.trim().length > 0
    )
      this.disableSaveBtn = false;
    else this.disableSaveBtn = true;
  }
  onValueChange(value: string) {
    if (value?.trim()?.length === 0) {
      this.expectedCloseDate = null;
      this.gatingDate = null;
      this.lessThanTodayExpectedDateError = false;
      this.lessThanTodayGatingDateError = false;
      this.expectedDateError = false;
      this.gatingDateError = false;
    } else {
      this.criticalGatingError = false;
    }
  }
  onExpectedDateChange(value: Date) {
    this.minDate.setHours(0, 0, 0, 0);
    if (value === null || value === undefined) {
      this.expectedDateError = true;
      this.lessThanTodayExpectedDateError = false;
    } else {
      this.expectedDateError = false;
      if (value?.getTime() < this.minDate?.getTime()) {
        this.lessThanTodayExpectedDateError = true;
      } else {
        this.lessThanTodayExpectedDateError = false;
      }
    }
  }
  onGatingDateChange(value: Date) {
    this.minDate.setHours(0, 0, 0, 0);
    if (value === null || value === undefined) {
      this.gatingDateError = true;
      this.lessThanTodayExpectedDateError = false;
    } else {
      this.gatingDateError = false;
      if (value?.getTime() < this.minDate?.getTime()) {
        this.lessThanTodayGatingDateError = true;
      } else {
        this.lessThanTodayGatingDateError = false;
      }
    }
  }
  upload() {
    const input = document.getElementById("file");
    input.click();
  }

  handleFileInput(files: FileList) {
    this.sameFileError = false;
    this.sameFileErrorMessage = "";
    if (
      this.uploadedFiles.length > 6 ||
      files.length > 6 ||
      this.uploadedFiles.length + files.length > 6
    ) {
      this.disableUpload = true;
    } else {
      this.disableUpload = false;
      const item = Array.from(files);
      item.forEach((f) => {
        if (!this.uploadedFiles?.includes(f.name)) {
          this.fileToUpload.push(f);
          this.uploadedFiles.push(f.name);
        } else {
          this.sameFileError = true;
          this.sameFileErrorMessage +=
            (this.sameFileErrorMessage.length > 0 ? ", " : "") +
            f.name;
        }
      });
    }
  }

  uploadFiles(files) {
    const formData: FormData = new FormData();
    for (let i = 0; i < files.length; i++) {
      formData.append("fileKey", files[i], files[i].name);
    }

    this.service.uploadTOIfile(this.toiId, formData).subscribe((req) => {
      if (req && req["value"] === "Updated Successfully") {
        this.resetAddTOIForm();
      }
    });
  }

  download(file: string) {
    this.http
      .get(
        this.apiUrl + "/TOI/downloadTOIfile/" + this.toiId + "/" + file,
        { responseType: "blob" }
      )
      .subscribe((result: any) => {
        if (result) {
          const blob = new Blob([result]);
          const saveAs = require("file-saver");
          const fileName = file;
          saveAs(blob, fileName);
        } else {
          alert("File not found in Blob!");
        }
      });
  }

  removeFile(file: string, index) {
    if (this.fileToUpload.filter((f) => f.name === file)?.length === 0) {
      if (this.toiId !== null && this.toiId !== undefined)
        this.service
          .deleteTOIfile(this.toiId, file)
          .subscribe((req) => { });
    }
    const after = Array.from(this.uploadedFiles);
    after.splice(index, 1);
    this.uploadedFiles = JSON.parse(JSON.stringify(after));
    this.fileToUpload.splice(index, 1);
  }
  resetAddTOIForm() {
    this.toiTitle = "";
    this.toiDescription = "";
    this.toiComments = "";
    this.toiStatus = this.toiStatusData[0];
    this.toiCG = " ";
    this.uploadedFiles = [];
    this.disableSaveBtn = false;
    this.expectedCloseDate = null;
    this.gatingDate = null;
    this.toiZone = undefined;
    this.fileToUpload = [];
    this.disableUpload = false;
    this.lessThanTodayExpectedDateError = false;
    this.lessThanTodayGatingDateError = false;
    this.criticalGatingError = false;
    this.expectedDateError = false;
    this.gatingDateError = false;
    this.sameFileError = false;
    this.sameFileErrorMessage = "";
  }
  onSaveTOI() {
    const request = new TOI();
    request.isGating = this.toiCG === "Gating";
    request.isCritical = this.toiCG === "Critical";
    if ((request.isCritical || request.isGating) &&
      (this.expectedCloseDate === null ||
        this.expectedCloseDate === undefined)
    ) {
      this.expectedDateError = true;
    } else if ((request.isCritical || request.isGating) && (this.gatingDate === null || this.gatingDate === undefined)) {
      this.gatingDateError = true;
    } else {
      request.pilotProductID = +this.pilotProductId;
      request.ben = this.ben;
      request.title = this.toiTitle;
      request.issueDescription = this.toiDescription;
      request.statusID = this.toiStatus?.value;

      const com = this.toiComments.split("]");
      if (com && com.length > 1) {
        const com1 = com[1].split("\n");
        if (com1 && com1.length > 1) this.toiComments = com1[1];
      }
      const comment =
        this.toiComments?.length > 0
          ? "[" +
          moment(new Date()).format("MMM-DD-yyyy").toString() +
          ", " +
          this.userDetails.firstName +
          " " +
          this.userDetails.lastName +
          "]: \n" +
          this.toiComments
          : "";
      request.comments = comment;

      if (
        this.expectedCloseDate !== null &&
        this.expectedCloseDate !== undefined
      ) {
        request.expectedCloseDate = new Date(
          this.expectedCloseDate.getTime() -
          new Date(this.expectedCloseDate).getTimezoneOffset() *
          60000
        );
      }
      if (this.gatingDate !== null && this.gatingDate !== undefined) {
        request.gatingDate = new Date(
          this.gatingDate.getTime() -
          new Date(this.gatingDate).getTimezoneOffset() * 60000
        );
      }
      if (this.toiZone) {
        request.zoneID = this.toiZone.value;
        request.zoneName = this.toiZone.text;
      }
      request.createdBy =
        this.userDetails?.firstName + " " + this.userDetails?.lastName;
      request.createdById = this.userDetails?.userId;
      if (this.fileToUpload?.length > 0) {
        this.service.AddTOI(request).subscribe((res) => {
          if (res && res.data) {
            this.toiId = res.data;
            this.addTOIOpened = false;
            this.uploadFiles(this.fileToUpload);
            if (this.site?.plantName !== "Fremont") {
              this.router
                .navigateByUrl("/", {
                  skipLocationChange: true,
                })
                .then(() => {
                  this.router.navigate([
                    "/action-items/" +
                    this.pilotProductId +
                    "/" +
                    6,
                  ]);
                });
            } else {
              this.router
                .navigateByUrl("/", {
                  skipLocationChange: true,
                })
                .then(() => {
                  this.router.navigate([
                    "/action-items/" +
                    this.pilotProductId +
                    "/" +
                    5,
                  ]);
                });
            }
          }
        });
      } else {
        this.service.AddTOI(request).subscribe((res) => { });
        this.addTOIOpened = false;
        this.resetAddTOIForm();
        if (this.site?.plantName !== "Fremont") {
          this.router
            .navigateByUrl("/", { skipLocationChange: true })
            .then(() => {
              this.router.navigate([
                "/action-items/" +
                this.pilotProductId +
                "/" +
                6,
              ]);
            });
        } else {
          this.router
            .navigateByUrl("/", { skipLocationChange: true })
            .then(() => {
              this.router.navigate([
                "/action-items/" +
                this.pilotProductId +
                "/" +
                5,
              ]);
            });
        }
      }
    }
  }
  onLinkToIssueLogClick() {
    if (this.site?.plantName === "Fremont") {
      window.open(
        "https://lamresearch.quickbase.com/db/bgmh64wg7?a=q&qid=251&nv=1&v0=" +
        this.ben,
        "_blank"
      );
    } else {
      window.open(
        "https://lamresearch.quickbase.com/db/bhmqdixgx?a=q&qid=1&nv=1&v0=" +
        this.ben,
        "_blank"
      );
    }
  }
  onAddIssueClick() {
    if (this.site?.plantName === "Fremont") {
      const division =
        this.issueLogDetails.length > 0
          ? this.issueLogDetails[0].divisionName
          : null;
      window.open(
        "https://lamresearch.quickbase.com/db/bgmh64wg7?a=nwr&_fid_11=" +
        division +
        "&_fid_50=" +
        this.moduleInfo?.ModuleInfo?.FCID +
        "&_fid_147=" +
        this.moduleInfo?.ModuleInfo?.PilotSerialNumber,
        "_blank"
      );
    } else {
      window.open(
        "https://lamresearch.quickbase.com/db/bhmqdixgx?a=nwr&_fid_129=" +
        this.ben,
        "_blank"
      );
    }
  }
  onViewClick(recId: number) {
    if (this.site?.plantName === "Fremont") {
      window.open(
        "https://lamresearch.quickbase.com/db/bgmh64wg7?a=dr&rid=" +
        recId,
        "_blank"
      );
    } else {
      window.open(
        "https://lamresearch.quickbase.com/db/bhmqdixgx?a=dr&rid=" +
        recId,
        "_blank"
      );
    }
  }

  getExpanded(issue: IssueLogView) {
    let isOpen = false;
    if (issue.count > 0) {
      switch (issue.statusforCount) {
        case "CLOSED":
          isOpen = this.expandClosedTable;
          break;
        case "OPEN":
          isOpen = this.expandOpenTable;
          break;
        case "REJECTED":
          isOpen = this.expandRejectedTable;
          break;
        case "IN PROCESS":
          isOpen = this.expandInProgressTable;
          break;
        case "REVIEWED":
          isOpen = this.expandReviewedTable;
          break;
        case "PR SUBMITTED":
          isOpen = this.expandPrSubmittedTable;
          break;
        case "NCR SUBMITTED":
          isOpen = this.expandNcrSubmittedTable;
          break;
        case "DEFERRED":
          isOpen = this.expandDeferredTable;
          break;
      }
    }
    return isOpen;
  }
  public onPanelChange(event: any[]) {
    event?.forEach((item) => {
      event?.forEach((item) => {
        switch (item.title?.toUpperCase()) {
          case "CLOSED":
            this.expandClosedTable = item.expanded;
            break;
          case "OPEN":
            this.expandOpenTable = item.expanded;
            break;
          case "REJECTED":
            this.expandRejectedTable = item.expanded;
            break;
          case "IN PROCESS":
          case "IN PROGRESS":
            this.expandInProgressTable = item.expanded;
            break;
          case "REVIEWED":
            this.expandReviewedTable = item.expanded;
            break;
          case "PR SUBMITTED":
            this.expandPrSubmittedTable = item.expanded;
            break;
          case "NCR SUBMITTED":
            this.expandNcrSubmittedTable = item.expanded;
            break;
          case "DEFERRED":
            this.expandDeferredTable = item.expanded;
            break;
        }
      });
    });
  }

  handleUrgencyFilter(value) {
    if (value.length >= 0) {
      this.urgencyDataItems = this.tempUrgencyDataItems.filter(
        (s) => s?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
      );
    } else {
      this.multiselect.toggle(false);
    }
  }
  handleIssueTypeFilter(value) {
    if (value.length >= 0) {
      this.issueTypeDataItems = this.tempIssueTypeDataItems.filter(
        (s) => s?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
      );
    } else {
      this.multiselect.toggle(false);
    }
  }
  handlePartFilter(value) {
    if (value.length >= 0) {
      this.partNumberItems = this.tempPartNumberItems.filter(
        (s) => s?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
      );
    } else {
      this.multiselect.toggle(false);
    }
  }
  onSearchFilter() {
    const filter: CompositeFilterDescriptor = { filters: [], logic: "and" };
    if (this.searchText && this.searchText.length > 0) {
      const data1 = [
        {
          field: "issueLog",
          operator: "contains",
          value: this.searchText,
        },
        {
          field: "issueTitle",
          operator: "contains",
          value: this.searchText,
        },
        {
          field: "part",
          operator: "contains",
          value: this.searchText,
        },
      ];
      filter.filters.push({ filters: [...data1], logic: "or" });
    }
    if (this.urgencyDataValue && this.urgencyDataValue.length > 0) {
      const data2: any[] = [];
      this.urgencyDataValue.forEach((item) => {
        data2.push({
          field: "urgency",
          operator: "contains",
          value: item,
        });
      });
      filter.filters.push({ filters: [...data2], logic: "or" });
    }
    if (this.issueTypeDataValue && this.issueTypeDataValue.length > 0) {
      const data3: any[] = [];
      this.issueTypeDataValue.forEach((item) => {
        data3.push({
          field: "issueType",
          operator: "contains",
          value: item,
        });
      });
      filter.filters.push({ filters: [...data3], logic: "or" });
    }
    if (this.partNumberValue && this.partNumberValue.length > 0) {
      const data4: any[] = [];
      this.partNumberValue.forEach((item) => {
        data4.push({
          field: "part",
          operator: "contains",
          value: item,
        });
      });
      filter.filters.push({ filters: [...data4], logic: "or" });
    }
    this.filter = filter;
    this.issueLogDetails = filterBy(this.tempIssueLogDetails, filter);
  }
}
