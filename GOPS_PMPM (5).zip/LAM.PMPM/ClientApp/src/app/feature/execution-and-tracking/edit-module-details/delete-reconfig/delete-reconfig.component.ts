import {
  Component,
  Input,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { MultiSelectComponent } from "@progress/kendo-angular-dropdowns";
import { TooltipDirective } from "@progress/kendo-angular-tooltip";
import { CompositeFilterDescriptor, distinct, filterBy } from "@progress/kendo-data-query";
import { AppStoreService } from "../../../../core/app-store.service";
import { Plant } from "../../../../core/model/user.model";
import { EditService } from "../../../service/edit.service";
import { DataServiceEandTService } from "../../data-service-eand-t.service";
import { Reconfig, ReconfigEditFields, ReconfigStatus } from "../../Models/ModuleSummary";

@Component({
  selector: "pmpm-delete-reconfig",
  templateUrl: "./delete-reconfig.component.html",
  styleUrls: ["./delete-reconfig.component.css"],
  encapsulation: ViewEncapsulation.None,
})
export class DeleteReconfigComponent implements OnInit {
  @ViewChild(TooltipDirective) public tooltipDir: TooltipDirective;
  @ViewChild("multiselect") public multiselect: MultiSelectComponent;
  @Input() ben = '';

  site: Plant;
  gridDataForDeleteReconfigComplete: Reconfig[] = [];
  gridDataForDeleteReconfigOpen: Reconfig[] = [];
  tempGridDataForDeleteReconfigComplete: Reconfig[] = [];
  tempGridDataForDeleteReconfigOpen: Reconfig[] = [];
  searchText = '';
  pnValueItem: string[] = [];
  descriptionValueItem: string[] = [];
  tempPNValueItem: string[] = [];
  tempDescriptionValueItem: string[] = [];  
  pnDataItem: string[] = [];
  descriptionDataItem: string[] = [];
  loadingTableForComplete = false;
  loadingTableForOpen = true;
  statusDDL: string[] = ['Open', 'Complete'];
  reconfigStatusList: ReconfigStatus[] = [];
  prodOrderCount: number;

  constructor(
    private appStoreService: AppStoreService,
    private service: DataServiceEandTService,
    private editService: EditService,
    private formBuilder: FormBuilder,
  ) { }

  ngOnInit() {    
    this.appStoreService.getCurrentSite().subscribe((site) => {
      if (site) {
        this.site = {
          plantName: site.plantName,
          plantId: site.plantId,
        };
        this.reconfigStatusList = [];
        this.service.GetReconfigStatus().subscribe(res => {
          if (res && res.length > 0) {
            this.reconfigStatusList = res;
            this.getReconfigData();
          }
        });        
      }
    });  
  }

  getReconfigData() {
    this.gridDataForDeleteReconfigOpen = [];
    this.gridDataForDeleteReconfigComplete = [];
    this.tempGridDataForDeleteReconfigComplete = [];
    this.tempGridDataForDeleteReconfigOpen = [];
    this.loadingTableForComplete = true;
    this.loadingTableForOpen = true;
    this.service.GetDeleteReconfig('Open', this.ben, this.site?.plantId).subscribe(res => {
      if (res) {
        this.prodOrderCount = res.prodOrderCount;
        if (res.prodOrderCount === 1) {
          this.gridDataForDeleteReconfigOpen = res.reconfig;
          this.tempGridDataForDeleteReconfigOpen = [...this.gridDataForDeleteReconfigOpen];
          this.getPNFilterList();
          this.getDescriptionFilterList();
        }
      }
      this.loadingTableForOpen = false;
    });
    this.service.GetDeleteReconfig('Complete', this.ben, this.site?.plantId).subscribe(res => {
      if (res) {
        this.prodOrderCount = res.prodOrderCount;
        if (res.prodOrderCount === 1) {
          this.gridDataForDeleteReconfigComplete = res.reconfig;
          this.tempGridDataForDeleteReconfigComplete = [...this.tempGridDataForDeleteReconfigComplete];
          this.getPNFilterList();
          this.getDescriptionFilterList();
        }
      }
      this.loadingTableForComplete = false;
    });
  }

  public showTooltip(e: MouseEvent): void {
    const element = e.target as HTMLElement;
    if (
      (element.nodeName === "TD" || element.nodeName === "TH") &&
      element.offsetWidth < element.scrollWidth
    ) {
      this.tooltipDir.toggle(element);
    } else {
      this.tooltipDir.hide();
    }
  }

  getPNFilterList() {
    let data1: any = distinct(this.tempGridDataForDeleteReconfigOpen, "partNumber").map(
      (item) => item["partNumber"]
    );
    data1 = data1.flatMap((f) => (f ? [f] : []));
    data1.sort(function (a, b) {
      const textA = a?.toUpperCase();
      const textB = b?.toUpperCase();
      return textA < textB ? -1 : textA > textB ? 1 : 0;
    });
    let data2: any = distinct(
      this.tempGridDataForDeleteReconfigComplete,
      "partNumber"
    ).map((item) => item["partNumber"]);
    data2 = data2.flatMap((f) => (f ? [f] : []));
    data2.sort(function (a, b) {
      const textA = a?.toUpperCase();
      const textB = b?.toUpperCase();
      return textA < textB ? -1 : textA > textB ? 1 : 0;
    });
    this.pnValueItem = [...data1, ...data2];
    this.pnValueItem = [...new Set(this.pnValueItem)];
    this.tempPNValueItem = JSON.parse(
      JSON.stringify(this.pnValueItem)
    );
  }
  getDescriptionFilterList() {
    let data1: any = distinct(this.tempGridDataForDeleteReconfigOpen, "description").map(
      (item) => item["description"]
    );
    data1 = data1.flatMap((f) => (f ? [f] : []));
    data1.sort(function (a, b) {
      const textA = a?.toUpperCase();
      const textB = b?.toUpperCase();
      return textA < textB ? -1 : textA > textB ? 1 : 0;
    });
    let data2: any = distinct(
      this.tempGridDataForDeleteReconfigComplete,
      "description"
    ).map((item) => item["description"]);
    data2 = data2.flatMap((f) => (f ? [f] : []));
    data2.sort(function (a, b) {
      const textA = a?.toUpperCase();
      const textB = b?.toUpperCase();
      return textA < textB ? -1 : textA > textB ? 1 : 0;
    });
    this.descriptionValueItem = [...data1, ...data2];
    this.descriptionValueItem = [...new Set(this.descriptionValueItem)];
    this.tempDescriptionValueItem = JSON.parse(
      JSON.stringify(this.descriptionValueItem)
    );
  }

  onSearchFilter() {
    const filter: CompositeFilterDescriptor = { filters: [], logic: "and" };
    if (this.searchText && this.searchText.length > 0) {
      const data1 = [
        {
          field: "partNumber",
          operator: "contains",
          value: this.searchText,
        },
        {
          field: "description",
          operator: "contains",
          value: this.searchText,
        },
      ];
      filter.filters.push({ filters: [...data1], logic: "or" });
    }
    if (this.pnDataItem && this.pnDataItem.length > 0) {
      const data2: any[] = [];
      this.pnDataItem.forEach((item) => {
        data2.push({
          field: "partNumber",
          operator: "eq",
          value: item,
        });
      });
      filter.filters.push({ filters: [...data2], logic: "or" });
    }
    if (this.descriptionDataItem && this.descriptionDataItem.length > 0) {
      const data3: any[] = [];
      this.descriptionDataItem.forEach((item) => {
        data3.push({
          field: "description",
          operator: "contains",
          value: item,
        });
      });
      filter.filters.push({ filters: [...data3], logic: "or" });
    }
    this.gridDataForDeleteReconfigOpen = filterBy(this.tempGridDataForDeleteReconfigOpen, filter);
    this.gridDataForDeleteReconfigComplete = filterBy(
      this.tempGridDataForDeleteReconfigComplete,
      filter
    );
  }

  handlePNFilter(value) {
    if (value.length >= 0) {
      this.pnValueItem = this.tempPNValueItem.filter(
        (s) => s?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
      );
    } else {
      this.multiselect.toggle(false);
    }
  }

  handleDescriptionFilter(value) {
    if (value.length >= 0) {
      this.descriptionValueItem = this.tempDescriptionValueItem.filter(
        (s) => s?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
      );
    } else {
      this.multiselect.toggle(false);
    }
  }

  public cellClickHandler({
    sender,
    rowIndex,
    columnIndex,
    dataItem,
    isEdited,
  }) {
    if (!isEdited) {
      sender.editCell(
        rowIndex,
        columnIndex,
        this.createFormGroup(dataItem)
      );
    }
  }

  public cellCloseHandler(args: any) {
    const { formGroup, dataItem } = args;

    if (!formGroup.valid) {
      // prevent closing the edited cell if there are invalid values.
      args.preventDefault();
    } else if (formGroup.dirty) {
      this.editService.assignValues(dataItem, formGroup.value);
      this.editService.update(dataItem, "ReconfigDelete");
    }
  }

  public cancelHandler({ sender, rowIndex }) {
    sender.closeRow(rowIndex);
  }

  public saveHandler({ sender, formGroup, rowIndex }) {
    if (formGroup.valid) {
      this.editService.create(formGroup.value);
      sender.closeRow(rowIndex);
    }
  }

  public createFormGroup(dataItem: any): FormGroup {
    return this.formBuilder.group({
      status: dataItem.status,
      qtyAdded: dataItem.qtyAdded,
      technicianComments: dataItem.technicianComments
    });
  }

  public saveChanges(): void {
    //grid.closeCell();
    //grid.cancelCell();
    const updatedReconfigData = this.editService.saveChanges();
    const req: ReconfigEditFields[] = [];
    updatedReconfigData[0].forEach(item => {
      req.push({ addOrRTSProdOrder: item.addOrRTSProdOrder, partNumber: item.partNumber, qtyAddedReturned: item.qtyAdded, status: (item.status === 'Open' ? this.reconfigStatusList.filter(i => i.status === 'Open')[0].statusId : this.reconfigStatusList.filter(i => i.status === 'Complete')[0].statusId ), technicianComments: item.technicianComments })
    });
    this.service.UpdateReconfig(req).subscribe((res) => {
      this.getReconfigData();
    });
  }

  public cancelChanges(): void {
    this.editService.cancelChanges();
    this.getReconfigData();
  }

  public CompleteCellClickHandler({
    sender,
    rowIndex,
    columnIndex,
    dataItem,
    isEdited,
  }) {
    if (!isEdited) {
      sender.editCell(
        rowIndex,
        columnIndex,
        this.CompleteCreateFormGroup(dataItem)
      );
    }
  }

  public CompleteCreateFormGroup(dataItem: any): FormGroup {
    return this.formBuilder.group({
      status: dataItem.status,
      qtyAdded: dataItem.qtyAdded,
      technicianComments: dataItem.technicianComments
    });
  }

  public CompleteCellCloseHandler(args: any) {
    const { formGroup, dataItem } = args;

    if (!formGroup.valid) {
      // prevent closing the edited cell if there are invalid values.
      args.preventDefault();
    } else if (formGroup.dirty) {
      this.editService.assignValues(dataItem, formGroup.value);
      this.editService.update(dataItem, "ReconfigDelete");
    }
  }

  public CompleteCancelHandler({ sender, rowIndex }) {
    sender.closeRow(rowIndex);
  }

  public CompleteSaveHandler({ sender, formGroup, rowIndex }) {
    if (formGroup.valid) {
      this.editService.create(formGroup.value);
      sender.closeRow(rowIndex);
    }
  }

  //public completeSaveChanges(): void  {
  //  //grid.closeCell();
  //  //grid.cancelCell();
  //  const updatedReconfigData = this.editService.saveChanges();
  //  const req: ReconfigEditFields[] = [];
  //  updatedReconfigData[0].forEach(item => {
  //    req.push({ addOrRTSProdOrder: item.addOrRTSProdOrder, partNumber: item.partNumber, qtyAddedReturned: item.qtyAdded, status: (item.status === 'Open' ? this.reconfigStatusList.filter(i => i.status === 'Open')[0].statusId : this.reconfigStatusList.filter(i => i.status === 'Complete')[0].statusId), technicianComments: item.technicianComment })
  //  });
  //  this.service.UpdateReconfig(req).subscribe((res) => {
  //    this.getReconfigData();
  //  });
  //}
  isChanged() {
    return this.editService.hasChanges();
  }
}
