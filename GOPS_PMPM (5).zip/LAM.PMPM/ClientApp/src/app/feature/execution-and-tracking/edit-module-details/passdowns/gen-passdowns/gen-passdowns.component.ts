import { Component, OnInit, ViewChild, ViewContainerRef, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AppStoreService } from '../../../../../core/app-store.service';
import { Plant, UserModel } from '../../../../../core/model/user.model';
import { Item } from '../../../../model/item';
import { DataServiceEandTService } from '../../../data-service-eand-t.service';
import { ModuleSummary } from '../../../Models/ModuleSummary';
import { BuildStyleDetail, PassdownActionItemsDetail, PassdownAssemblyOperationDetail, PassdownAuditItem, PassdownDisplay, PassdownGenerateOrEdit, PassdownLOTO, PassdownOperation, PassdownOperationStep, PassdownRework, PassdownTabs, PassdownTestDetail, PassdownTOI, PassdownZoneOperationDetail, PassdownZoneOperationDetailWithZone, PassdownZoneOperationTextDetail } from '../../../Models/passdown.model';
import * as moment from 'moment';
import { uiScreen } from '../../../../../core/model/common.constant';
import { NotificationService } from '@progress/kendo-angular-notification';


@Component({
  selector: 'pmpm-gen-passdowns',
  templateUrl: './gen-passdowns.component.html',
  styleUrls: ['./gen-passdowns.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class GenPassdownsComponent implements OnInit {
  @ViewChild('appendTo', { read: ViewContainerRef })
  public appendTo: ViewContainerRef;
  today = new Date();
  pilotProductId: number;
  passdownId = 0;
  site: Plant;
  moduleInfo: ModuleSummary = null;
  gridDataForAudit: PassdownAuditItem[] = [];
  gridDataForRework: PassdownRework[] = [];
  passdownTabsItems: PassdownTabs[] = [];
  passdownTabs: PassdownTabs[] = [];
  passdownDetails: PassdownZoneOperationDetail;
  userDetail: UserModel;
  nextStepOpsItems: Item[] = [];
  selectedTab: PassdownTabs;
  defaultNextOpsItem: Item = { text: '', value: 0 };
  nextStepOpsData: Item;
  lotoItems: Item[] = [{ text: 'Yes', value: true }, { text: 'No', value: false }];
  lotoData: Item;
  progressedOperation: PassdownOperation[] = [];
  completedOperation: PassdownOperation[] = [];
  skippedOperation: PassdownOperationStep[] = [];
  zoneNotes = '';
  otherTaskToComplete = '';
  LOTOList: PassdownLOTO[] = [];

  passdownActionItemDetails: PassdownActionItemsDetail;
  gridDataForOpenCriticalGatingTOIs: PassdownTOI[] = [];
  opCompletedTest = '';
  opProgressedTest = '';
  opSkippedTest = '';
  opNextStepTest = '';
  opSpecialInstructionTest = '';
  opNotesTest = '';

  opCompletedAssembly = '';
  opProgressedAssembly = '';
  opSkippedAssembly = '';
  opNextStepAssembly = '';
  opReworkAssembly = '';
  opNotesAssembly = '';
  gridDataForPassdownAuditItemsAssembly: PassdownAuditItem[];

  editPassdownModel: PassdownGenerateOrEdit;
  editLOTOPassdownObject: PassdownLOTO[] = [];
  passdownZoneOperationTextDetails: PassdownZoneOperationTextDetail[] = [{ passdownZoneOperationDetailId: 0, passdownId: this.passdownId, zoneId: 0, zone: '', zoneNotes: '', otherTasksToComplete: '', nextOperationToCompleteId: 0, nextStepOpsData: { text: '', value: 0 }, nextOpToComplete: '' }]
  passdownTestDetails: PassdownTestDetail = { opCompleted: '', opProgressed: '', opSkipped: '', nextSteps: '', specialInstructions: '', notes: '', passdownId: 0, passdownTestId: 0 };
  passdownAssemblyDetails: PassdownAssemblyOperationDetail = { opCompleted: '', opProgressed: '', opSkipped: '', nextSteps: '', rework: '', notes: '', passdownAuditItems: [], passdownId: 0, passdownAssemblyId: 0 };
 
  errorMessage = '';
  isShowError = false;
  buildStyle: BuildStyleDetail;
  addAssemblyNoteOpened = false;
  assemblyNotesValue = '';
  addTestNoteOpened = false;
  testNotesValue = '';
  zoneNotesValue = '';
  addZoneNoteOpened = false;
  selectedZoneIndex: number;

  disableSaveButton = true;

  isDisplayPassdown = false;
  displayPassdownDetails: PassdownDisplay;

  isUserAccess = false;
  isEditEnabled = false;

  constructor(private appStoreService: AppStoreService, private service: DataServiceEandTService, private route: ActivatedRoute, private router: Router, private notificationService: NotificationService) { }

  ngOnInit() {
    this.appStoreService.getUserRoles().subscribe(res => {
      if (res && res.length > 0) {
        this.appStoreService.checkUserAccessRight(res, uiScreen.Passdown).subscribe(result => {
          this.isUserAccess = result;
        });
      }
    });
    this.editPassdownModel = new PassdownGenerateOrEdit();
    this.route.params.subscribe(param => {
      this.pilotProductId = +param.pilotProductId;
      this.passdownId = +param.passdownId;
      this.appStoreService.getLoggedInUser().subscribe((user) => {
        this.appStoreService.getUserDetails(user.mail).subscribe((res) => {
          if (res) {
            this.userDetail = res;
            this.service.GetPassdownTabs(+this.pilotProductId).subscribe(res => {
              if (res && res.length > 0) {
                this.passdownTabs = JSON.parse(JSON.stringify(res));
                this.passdownTabsItems = res.filter(item => item.zoneId !== null);
                this.passdownZoneOperationTextDetails = [];
                this.passdownTabsItems?.forEach(item => {
                  this.passdownZoneOperationTextDetails.push({ passdownZoneOperationDetailId: 0, passdownId: this.passdownId, zoneId: 0, zone: '', zoneNotes: '', otherTasksToComplete: '', nextOperationToCompleteId: 0, nextStepOpsData: { text: '', value: 0 }, nextOpToComplete: '' });
                });
              }
            });
            this.gridDataForOpenCriticalGatingTOIs = [];
            this.getActionItems(+this.passdownId);
          }
        });
      });
    });

    this.appStoreService.getCurrentSite().subscribe((site) => {
      if (site) {
        this.site = { plantName: site.plantName, plantId: site.plantId };
        this.service.getModuleSummaryByID(+this.pilotProductId).toPromise()
          .then(data => {
            if (data && data.length > 0) {
              this.moduleInfo = data.filter(item => +item.ModuleInfo.PilotProductID === +this.pilotProductId)[0];
            }
          });
      }
    });
  }
  onTabSelect(tab) {
    if (tab.title === "Test") {
      if (this.passdownId !== 0) {
        this.service.GetPassdownTest(this.passdownId).subscribe(res => {
          if (res) {
            this.passdownTestDetails.passdownId = this.passdownId;
            this.passdownTestDetails.passdownTestId = res.passdownTestId !== null && res.passdownTestId !== undefined ? res.passdownTestId : 0;
            if (this.passdownTestDetails && this.passdownTestDetails.opCompleted.length === 0) {
              this.passdownTestDetails.opCompleted = res?.opCompleted;
            }
            if (this.passdownTestDetails && this.passdownTestDetails.opProgressed.length === 0) {
              this.passdownTestDetails.opProgressed = res?.opProgressed;
            }
            if (this.passdownTestDetails && this.passdownTestDetails.opSkipped.length === 0) {
              this.passdownTestDetails.opSkipped = res?.opSkipped;
            }
            if (this.passdownTestDetails && this.passdownTestDetails.nextSteps.length === 0) {
              this.passdownTestDetails.nextSteps = res?.nextSteps;
            }
            if (this.passdownTestDetails && this.passdownTestDetails.specialInstructions.length === 0) {
              this.passdownTestDetails.specialInstructions = res?.specialInstructions;
            }
            if (this.passdownTestDetails && this.passdownTestDetails.notes.length === 0) {
              this.passdownTestDetails.notes = res?.notes;
            }
          }
        });
      }
    }
    else if (tab.title === "Assembly") {
      this.service.GetGeneratePassdownAssemblyOperations(+this.pilotProductId, this.userDetail?.shiftID, this.passdownId).subscribe(res => {
        if (res) {
          this.passdownAssemblyDetails.passdownId = this.passdownId;
          this.passdownAssemblyDetails.passdownAssemblyId = res.passdownAssemblyId !== null && res.passdownAssemblyId !== undefined ? res.passdownAssemblyId : 0;
          if (this.passdownAssemblyDetails && this.passdownAssemblyDetails.opCompleted.length === 0) {
            this.passdownAssemblyDetails.opCompleted = res?.opCompleted;
          }
          if (this.passdownAssemblyDetails && this.passdownAssemblyDetails.opProgressed.length === 0) {
            this.passdownAssemblyDetails.opProgressed = res?.opProgressed;
          }
          if (this.passdownAssemblyDetails && this.passdownAssemblyDetails.opSkipped.length === 0) {
            this.passdownAssemblyDetails.opSkipped = res?.opSkipped;
          }
          if (this.passdownAssemblyDetails && this.passdownAssemblyDetails.nextSteps.length === 0) {
            this.passdownAssemblyDetails.nextSteps = res?.nextSteps;
          }
          if (this.passdownAssemblyDetails && this.passdownAssemblyDetails.rework.length === 0) {
            this.passdownAssemblyDetails.rework = res?.rework;
          }
          if (this.passdownAssemblyDetails && this.passdownAssemblyDetails.notes.length === 0) {
            this.passdownAssemblyDetails.notes = res?.notes;
          }
          this.passdownAssemblyDetails.passdownAuditItems = res.passdownAuditItems;
          this.gridDataForPassdownAuditItemsAssembly = this.passdownAssemblyDetails.passdownAuditItems;
        }
      })
    }
    else if (tab.title !== 'Action Items' && tab.title !== "Test" && tab.title !== "Assembly") {
      this.selectedTab = this.passdownTabs.filter(item => item.orders === tab.index + 1)[0];
      this.nextStepOpsItems = [];
      this.gridDataForAudit = [];
      this.gridDataForRework = [];
      this.progressedOperation = [];
      this.completedOperation = [];
      this.skippedOperation = [];
      let date: any = new Date();
      date = moment(date).format('MM-DD-yyyy HH:mm:ss a');
      this.service.GetGeneratePassdownZonesDetail(+this.pilotProductId, this.selectedTab?.zoneId, this.userDetail?.shiftID, this.passdownId, date).subscribe(res => {
        if (res) {
          this.passdownDetails = res;
          this.nextStepOpsItems.push(this.defaultNextOpsItem);
          this.passdownDetails?.nextOperationsToComplete.forEach(item => {
            this.nextStepOpsItems.push({ text: item.description, value: item.operationId });
          });

          let zoneDetails = new PassdownZoneOperationTextDetail();
          zoneDetails.zoneId = this.selectedTab.zoneId;
          zoneDetails.passdownZoneOperationDetailId = res.passdownZoneOperationDetailId !== null && res.passdownZoneOperationDetailId !== undefined ? res.passdownZoneOperationDetailId : 0;
          zoneDetails.passdownId = this.passdownId;
          zoneDetails.zoneNotes = res.zoneNotes;
          zoneDetails.otherTasksToComplete = res.otherTasksToComplete;
          zoneDetails.nextOperationToCompleteId = res.nextOperationToCompleteId;
          zoneDetails.nextStepOpsData = this.nextStepOpsItems?.filter(i => i.value === this.passdownDetails.nextOperationToCompleteId)[0];
          zoneDetails.nextOpToComplete = this.nextStepOpsItems?.filter(i => i.value === this.passdownDetails.nextOperationToCompleteId)[0]?.text;
          zoneDetails.zone = this.selectedTab.tabName;

          if (this.passdownZoneOperationTextDetails?.filter(item => item.zoneId === this.selectedTab.zoneId).length === 0) {
            this.passdownZoneOperationTextDetails.splice(tab.index - 1, 1);
            this.passdownZoneOperationTextDetails.splice(tab.index - 1, 0, zoneDetails);
            // this.editPassdownModel.passdownZoneOperationTextDetails = [...this.passdownZoneOperationTextDetails];
          }
          this.gridDataForAudit = this.passdownDetails?.passdownAuditItems;
          this.gridDataForRework = this.passdownDetails?.passdownReworks;
          this.progressedOperation = this.passdownDetails?.progressedPassdownOperations;
          this.completedOperation = this.passdownDetails?.completedPassdownOperations;
          this.skippedOperation = this.passdownDetails?.passdownOperationSteps;

          this.zoneNotes = this.passdownDetails?.zoneNotes;
          this.otherTaskToComplete = this.passdownDetails?.otherTasksToComplete;
          if (this.passdownDetails?.nextOperationToCompleteId !== null) {
            this.nextStepOpsData = this.nextStepOpsItems.filter(i => i.value === this.passdownDetails.nextOperationToCompleteId)[0];
          }
        } else {
          const zoneDetails: PassdownZoneOperationTextDetail = { passdownZoneOperationDetailId: 0, passdownId: this.passdownId, zoneId: this.selectedTab.zoneId, zone: this.selectedTab.tabName, zoneNotes: '', otherTasksToComplete: '', nextOperationToCompleteId: 0, nextStepOpsData: { text: '', value: 0 }, nextOpToComplete: '' };
          this.passdownZoneOperationTextDetails = [zoneDetails];
          //this.editPassdownModel.passdownZoneOperationTextDetails = [...this.passdownZoneOperationTextDetails];
        }
      });
    }
  }
  displayPassdown() {
    let date: any = new Date();
    date = moment(date).format('MM-DD-yyyy HH:mm:ss a');
    const isEdit = +this.passdownId === 0 ? false : true;
    this.service.GetDisplayPassdown(+this.pilotProductId, this.userDetail?.shiftID, +this.passdownId, isEdit, date).subscribe(res => {
      if (res) {
        this.displayPassdownDetails = res;
        if (this.displayPassdownDetails?.issues?.openCriticalGatingTOIs?.length > 0) {
          this.displayPassdownDetails?.issues?.openCriticalGatingTOIs.forEach(item => {
            item.issueDescriptionWithoutTag = item.issueDescription.replace(/<[^>]*>/g, '');
          });
        }

        if (this.displayPassdownDetails && this.displayPassdownDetails.issues && this.displayPassdownDetails.issues.passdownLOTOs && this.displayPassdownDetails.issues.passdownLOTOs.length > 0) {
          if (this.LOTOList?.length > 0) {
            this.displayPassdownDetails.issues.passdownLOTOs = [...this.LOTOList];
          }
        } else {
          this.displayPassdownDetails.issues.passdownLOTOs = [...this.LOTOList];
        }

        if (this.passdownZoneOperationTextDetails?.length > 0) {
          this.displayPassdownDetails?.moduleProcesses?.forEach(module => {            
            module?.passdownZoneOperationDetailWithZones?.forEach(zone => {
              if (this.passdownZoneOperationTextDetails?.filter(o => o?.zoneId === zone?.zoneId)?.length > 0) {
                zone.passdownZoneOperationTextDetails = [...this.passdownZoneOperationTextDetails?.filter(o => o?.zoneId === zone?.zoneId)];
              } 
            });
          });
        }

        if (this.passdownTestDetails !== null && this.passdownTestDetails !== undefined) {
          if (this.passdownTestDetails.opCompleted?.length > 0)
            this.displayPassdownDetails.passdownTestDetail.opCompleted = this.passdownTestDetails.opCompleted;

          if (this.passdownTestDetails.opProgressed?.length > 0)
            this.displayPassdownDetails.passdownTestDetail.opProgressed = this.passdownTestDetails.opProgressed;

          if (this.passdownTestDetails?.opSkipped?.length > 0)
            this.displayPassdownDetails.passdownTestDetail.opSkipped = this.passdownTestDetails.opSkipped;

          if (this.passdownTestDetails.nextSteps?.length > 0)
            this.displayPassdownDetails.passdownTestDetail.nextSteps = this.passdownTestDetails.nextSteps;

          if (this.passdownTestDetails.specialInstructions?.length > 0)
            this.displayPassdownDetails.passdownTestDetail.specialInstructions = this.passdownTestDetails.specialInstructions;

          if (this.passdownTestDetails.notes?.length > 0)
            this.displayPassdownDetails.passdownTestDetail.notes = this.passdownTestDetails.notes;
        }
        if (this.passdownAssemblyDetails !== null && this.passdownAssemblyDetails !== undefined) {
          if (this.passdownAssemblyDetails.opCompleted?.length > 0)
            this.displayPassdownDetails.passdownAssemblyOperationAuditItemsDetail.opCompleted = this.passdownAssemblyDetails?.opCompleted;

          if (this.passdownAssemblyDetails.opProgressed?.length > 0)
            this.displayPassdownDetails.passdownAssemblyOperationAuditItemsDetail.opProgressed = this.passdownAssemblyDetails?.opProgressed;

          if (this.passdownAssemblyDetails.opSkipped?.length > 0)
            this.displayPassdownDetails.passdownAssemblyOperationAuditItemsDetail.opSkipped = this.passdownAssemblyDetails?.opSkipped;

          if (this.passdownAssemblyDetails.nextSteps?.length > 0)
            this.displayPassdownDetails.passdownAssemblyOperationAuditItemsDetail.nextSteps = this.passdownAssemblyDetails?.nextSteps;

          if (this.passdownAssemblyDetails.rework?.length > 0)
            this.displayPassdownDetails.passdownAssemblyOperationAuditItemsDetail.rework = this.passdownAssemblyDetails?.rework;

          if (this.passdownAssemblyDetails.notes?.length > 0)
            this.displayPassdownDetails.passdownAssemblyOperationAuditItemsDetail.notes = this.passdownAssemblyDetails?.notes;
        }
        this.isDisplayPassdown = true;
      }
    });
  }
  closeDisplayPassdown() {
    this.isDisplayPassdown = false;
  }
  isShowSubAssemblySection(): boolean {
    //return this.passdownTabs.filter(item => item.tabName === 'Assembly')?.length > 0;
    return (this.passdownTabs.filter(item => item.tabName === 'Assembly')?.length > 0 && (this.displayPassdownDetails && this.displayPassdownDetails?.passdownAssemblyOperationAuditItemsDetail !== undefined && this.displayPassdownDetails?.passdownAssemblyOperationAuditItemsDetail !== null && (this.displayPassdownDetails?.passdownAssemblyOperationAuditItemsDetail.nextSteps !== null
      || this.displayPassdownDetails?.passdownAssemblyOperationAuditItemsDetail.notes !== null || this.displayPassdownDetails?.passdownAssemblyOperationAuditItemsDetail.opCompleted !== null || this.displayPassdownDetails?.passdownAssemblyOperationAuditItemsDetail.rework !== null || this.displayPassdownDetails?.passdownAssemblyOperationAuditItemsDetail.opProgressed !== null || this.displayPassdownDetails?.passdownAssemblyOperationAuditItemsDetail.opSkipped !== null)));
  }
  isShowTestSection(): boolean {
    //return this.passdownTabs.filter(item => item.tabName === 'Test')?.length > 0;
    return (this.passdownTabs.filter(item => item.tabName === 'Test')?.length > 0
      && (this.displayPassdownDetails && this.displayPassdownDetails?.passdownTestDetail !== undefined && this.displayPassdownDetails?.passdownTestDetail !== null
        && (this.displayPassdownDetails?.passdownTestDetail.opCompleted !== null || this.displayPassdownDetails?.passdownTestDetail.nextSteps !== null || this.displayPassdownDetails?.passdownTestDetail.notes !== null
          || this.displayPassdownDetails?.passdownTestDetail.opProgressed !== null || this.displayPassdownDetails?.passdownTestDetail.opSkipped !== null || this.displayPassdownDetails.passdownTestDetail.specialInstructions !== null)));
  }
  returnToModule() {
    if (this.moduleInfo.ModuleInfo.BuildStyle?.toLowerCase() === 'reconfig') {
      this.router.navigate([
        '/edit-module/' + this.pilotProductId + '/' + 5
      ]);
    }
    else if (this.moduleInfo.ModuleInfo.BuildStyle === 'Special Subassembly') {
      this.router.navigate([
        '/edit-module/' + this.pilotProductId + '/' + 3
      ]);
    }
    else {
      this.router.navigate([
        '/edit-module/' + this.pilotProductId + '/' + 5
      ]);
    }
  }

  isShowTab(tab: string): boolean {
    let isShow = false;
    switch (tab) {
      case 'Assembly':
        isShow = this.passdownTabs.filter(item => item.tabName === 'Assembly')?.length > 0;
        break;
      case 'Test':
        isShow = this.passdownTabs.filter(item => item.tabName === 'Test')?.length > 0;
        break;
      case 'Action Items':
        isShow = this.passdownTabs.filter(item => item.tabName === 'Action Items')?.length > 0;
        break;
    }
    return isShow;
  }
  addLOTOForm() {
    this.LOTOList.push({ passdownId: +this.passdownId, passdownLOTOId: 0, facilityLock: true, description: '', reasonForLOTO: '', createdById: this.userDetail.userId, createdBy: this.userDetail.firstName + ' ' + this.userDetail.lastName, lotoFacilityLock: { text: 'Yes', value: true } });
    this.disableSaveButton = false;
  }

  disableAddLOTOButton() {
    if (this.LOTOList?.length > 0) {
      if (this.LOTOList.filter(item => item.description === null || item.description === undefined || item.description === '')?.length > 0) {
        return true;
      }
      if (this.LOTOList.filter(item => item.reasonForLOTO === null || item.reasonForLOTO === undefined || item.reasonForLOTO === '')?.length > 0) {
        return true;
      }
    }
    return false;
  }

  removeLOTO(index) {
    this.LOTOList.splice(index, 1);
    this.disableSaveButton = false;
  }

  updateLotoFacilityLock(lockData: Item, index: number) {
    this.disableSaveButton = false;
  }

  updateLotoDescription(description, index: number) {
    this.disableSaveButton = false;
  }

  updateLotoReason(reason, index: number) {
    this.disableSaveButton = false;
  }

  getLotoById(loto: PassdownLOTO) {
    if (loto && loto?.passdownLOTOId)
      return loto.createdBy;
    else
      return this.userDetail.firstName + ' ' + this.userDetail.lastName;
  }
  onSavePassdown() {
    if (this.validationForCreatePassdow()) {
      this.editPassdownModel.passdownId = +this.passdownId;
      this.editPassdownModel.passdownDate = new Date(
        new Date().getTime() -
        new Date().getTimezoneOffset() * 60000
      );
      this.editPassdownModel.pilotProductId = +this.pilotProductId;
      this.editPassdownModel.shiftId = this.userDetail.shiftID;
      if (this.passdownTestDetails && this.passdownTestDetails.opCompleted !== '' && this.passdownTestDetails.opProgressed !== '' && this.passdownTestDetails.opSkipped !== ''
        && this.passdownTestDetails.nextSteps !== '' && this.passdownTestDetails.specialInstructions !== '' && this.passdownTestDetails.notes !== '') {
        this.editPassdownModel.passdownTestDetail = this.passdownTestDetails;
      }
      if (this.passdownAssemblyDetails && this.passdownAssemblyDetails.opCompleted !== '' && this.passdownAssemblyDetails.opProgressed !== '' && this.passdownAssemblyDetails.opSkipped !== ''
        && this.passdownAssemblyDetails.nextSteps !== '' && this.passdownAssemblyDetails.rework !== '' && this.passdownAssemblyDetails.notes !== '') {
        this.editPassdownModel.passdownAssemblyOperationDetail = this.passdownAssemblyDetails;
      }
      if (this.LOTOList.length === 0) {
        this.editPassdownModel.passdownLOTOs = [];
      } else {
        this.editPassdownModel.passdownLOTOs = this.LOTOList;
      }

      this.editPassdownModel.passdownZoneOperationTextDetails?.forEach(item => {
        if ((item.zoneNotes === null || item.zoneNotes === undefined || item.zoneNotes === '')
          && (item.otherTasksToComplete === null || item.otherTasksToComplete === undefined || item.otherTasksToComplete === '') && (item.nextStepOpsData === undefined || (item.nextStepOpsData && item.nextStepOpsData.value === 0))) {
          item.zoneId = 0;
        }
      });

      if (this.passdownId === 0) {
        this.editPassdownModel.createdById = this.userDetail.userId;
        this.editPassdownModel.createdOn = new Date(
          new Date().getTime() -
          new Date().getTimezoneOffset() * 60000
        );

        let date: any = new Date();
        date = moment(date).format('MM-DD-yyyy HH:mm:ss a');
        this.service.CreatePassdown(this.editPassdownModel, date).subscribe(res => {
          if (res && res > 0) {
            this.passdownId = res;
            this.disableSaveButton = true;
            this.showSuccess("Saved");
            this.getActionItems(res);
            this.isEditEnabled = false;
          }
        });
      }
      else {
        this.editPassdownModel.modifiedById = this.userDetail.userId;
        this.editPassdownModel.modifiedOn = new Date(
          new Date().getTime() -
          new Date().getTimezoneOffset() * 60000
        );        
        let date: any = new Date();
        date = moment(date).format('MM-DD-yyyy HH:mm:ss a');
        this.service.EditPassdown(this.editPassdownModel, this.passdownId, date).subscribe(res => {
          this.disableSaveButton = true;
          this.showSuccess("Saved");
          this.isEditEnabled = false;
        });
      }
    } else {
      this.isShowError = true;
    }
  }

  validationForCreatePassdow(): boolean {
    this.errorMessage = '';
    let errorMessageForLOTO = '';
    if (this.LOTOList?.length > 0) {
      this.LOTOList.forEach(item => {
        if (item.description === null || item.description === undefined || item.description === '')
          errorMessageForLOTO = 'LOTO Description is required! \n';
        if (item.reasonForLOTO === null || item.reasonForLOTO === undefined || item.reasonForLOTO === '')
          errorMessageForLOTO += 'Reason for LOTO is required! \n';
        if (item.facilityLock === null || item.facilityLock === undefined)
          errorMessageForLOTO += 'LOTO Facility Lock is required! \n';
      });
      this.errorMessage += errorMessageForLOTO;
    }
    return this.errorMessage.length === 0;
  }

  getActionItems(passdownId: number) {
    let date: any = new Date();
    date = moment(date).format('MM-DD-yyyy HH:mm:ss a');
    this.service.GetGeneratePassdownActionItems(+this.pilotProductId, +this.userDetail?.shiftID, passdownId, date).subscribe(res => {
      if (res) {
        this.isEditEnabled = res?.editButtonDetail?.isEditable;
        this.buildStyle = res.buildStyleDetail;
        this.passdownActionItemDetails = res;
        this.gridDataForOpenCriticalGatingTOIs = res.openCriticalGatingTOIs;
        if (this.gridDataForOpenCriticalGatingTOIs && this.gridDataForOpenCriticalGatingTOIs.length > 0) {
          this.gridDataForOpenCriticalGatingTOIs?.forEach(item => {
            item.issueDescriptionWithoutTag = item.issueDescription.replace(/<[^>]*>/g, '');
          });
        }
        if (res.passdownLOTOs && res.passdownLOTOs.length > 0) {          
          this.LOTOList = [];
          this.editLOTOPassdownObject = [];
          res.passdownLOTOs.forEach((item, index) => {
            item.lotoFacilityLock = { text: item.facilityLock ? 'Yes' : 'No', value: item.facilityLock };
            this.LOTOList.push(item);
          });
          this.editLOTOPassdownObject = res.passdownLOTOs;
          this.editPassdownModel.passdownLOTOs = [...this.editLOTOPassdownObject];
        } else {
          this.editLOTOPassdownObject = [];
          this.LOTOList = [];
        }
        this.isShowTab('Action Items');
      }
      else {
        this.editLOTOPassdownObject = [];
        this.LOTOList = [];
      }
    });
  }

  onCloseError() {
    this.isShowError = false;
  }

  onInputOtherTaskToComplete(value, zoneId: number) {
    if (this.passdownZoneOperationTextDetails.length > 0) {
      if (this.passdownZoneOperationTextDetails.filter(item => item.zoneId === zoneId)?.length > 0) {
        this.passdownZoneOperationTextDetails.filter(item => item.zoneId === zoneId)[0].otherTasksToComplete = value;
        this.editPassdownModel.passdownZoneOperationTextDetails = [...this.passdownZoneOperationTextDetails];
      }
    }
    else {
      const zoneDetails: PassdownZoneOperationTextDetail = { passdownZoneOperationDetailId: 0, passdownId: this.passdownId, zoneId: zoneId, zone: this.selectedTab.tabName, zoneNotes: '', otherTasksToComplete: value, nextOperationToCompleteId: 0, nextStepOpsData: { text: '', value: 0 }, nextOpToComplete: '' };
      this.passdownZoneOperationTextDetails.push(zoneDetails);
      this.editPassdownModel = new PassdownGenerateOrEdit();
      this.editPassdownModel.passdownZoneOperationTextDetails = [...this.passdownZoneOperationTextDetails];
    }
    this.disableSaveButton = false;
  }

  onInputZoneNotes(value, zoneId: number) {
    if (this.passdownZoneOperationTextDetails.length > 0) {
      if (this.passdownZoneOperationTextDetails.filter(item => item.zoneId === zoneId)?.length > 0) {
        this.passdownZoneOperationTextDetails.filter(item => item.zoneId === zoneId)[0].zoneNotes = value;
        this.editPassdownModel.passdownZoneOperationTextDetails = [...this.passdownZoneOperationTextDetails];
      }
    }
    else {
      const zoneDetails: PassdownZoneOperationTextDetail = { passdownZoneOperationDetailId: 0, passdownId: this.passdownId, zoneId: zoneId, zone: this.selectedTab.tabName, zoneNotes: value, otherTasksToComplete: '', nextOperationToCompleteId: 0, nextStepOpsData: { text: '', value: 0 }, nextOpToComplete: '' };
      this.passdownZoneOperationTextDetails.push(zoneDetails);
      this.editPassdownModel = new PassdownGenerateOrEdit();
      this.editPassdownModel.passdownZoneOperationTextDetails = [...this.passdownZoneOperationTextDetails];
    }
    this.disableSaveButton = false;
  }

  onChangeNextStep(nextStep: Item, zoneId) {
    if (this.passdownZoneOperationTextDetails.length > 0) {
      if (this.passdownZoneOperationTextDetails.filter(item => item.zoneId === zoneId)?.length > 0) {
        this.passdownZoneOperationTextDetails.filter(item => item.zoneId === zoneId)[0].nextOperationToCompleteId = nextStep.value === 0 ? null : nextStep.value;
        this.passdownZoneOperationTextDetails.filter(item => item.zoneId === zoneId)[0].nextOpToComplete = nextStep.text;
        this.passdownZoneOperationTextDetails.filter(item => item.zoneId === zoneId)[0].nextStepOpsData = nextStep;
        this.editPassdownModel.passdownZoneOperationTextDetails = [...this.passdownZoneOperationTextDetails];
      }
    }
    else {
      const zoneDetails: PassdownZoneOperationTextDetail = { passdownZoneOperationDetailId: 0, passdownId: this.passdownId, zoneId: zoneId, zone: this.selectedTab.tabName, zoneNotes: '', otherTasksToComplete: '', nextOperationToCompleteId: nextStep.value, nextStepOpsData: { text: nextStep.text, value: nextStep.value }, nextOpToComplete: '' };
      this.passdownZoneOperationTextDetails.push(zoneDetails);
      this.editPassdownModel = new PassdownGenerateOrEdit();
      this.editPassdownModel.passdownZoneOperationTextDetails = [...this.passdownZoneOperationTextDetails];
    }
    this.disableSaveButton = false;
  }

  goToTOI(toiid: number) {
    this.router.navigate([
      '/view-toi/' + toiid + '/' + this.pilotProductId
    ]);
  }

  goToIssueLog(recId: number) {
    if (this.site?.plantName === 'Fremont') {
      window.open('https://lamresearch.quickbase.com/db/bgmh64wg7?a=dr&rid=' + recId, "_blank");
    } else {
      window.open('https://lamresearch.quickbase.com/db/bhmqdixgx?a=dr&rid=' + recId, "_blank");
    }
  }

  goToNCI(iQMSID: number) {
    window.open('https://trackwise.lamresearch.com/trackwise/Gateway.html?' + iQMSID, "_blank");
  }

  goToOBC(recId: number) {
    if (this.site.plantName !== 'Fremont') {
      const url = ' https://lamresearch.quickbase.com/db/bprt8ii2f?a=er&rid=' + recId;
      window.open(url, "_blank");
    }
  }

  goToReworkLog() {
    if (this.moduleInfo.ModuleInfo.BuildStyle?.toLowerCase() === 'reconfig') {
      this.router.navigate([
        '/edit-module/' + this.pilotProductId + '/' + 5
      ]);
    } else {
      this.router.navigate([
        '/edit-module/' + this.pilotProductId + '/' + 4
      ]);
    }
  }

  openAddAssemblyNotes(note: string) {
    this.assemblyNotesValue = '';
    this.addAssemblyNoteOpened = true;
  }

  closeAddAssemblyNotes() {
    this.addAssemblyNoteOpened = false;
  }

  onAddAssemblyNote() {
    const note = this.assemblyNotesValue.length > 0 ? "[" + (moment(new Date).format('MMM-DD-yyyy').toString()) + ", " + this.userDetail?.firstName + ' ' + this.userDetail?.lastName + "]: " + this.assemblyNotesValue : '';
    this.passdownAssemblyDetails.notes = this.passdownAssemblyDetails.notes?.length > 0 ? this.passdownAssemblyDetails.notes + '\n' + note : note;
    this.addAssemblyNoteOpened = false;
    this.disableSaveButton = false;
  }

  openAddTestNotes(note: string) {
    this.testNotesValue = '';
    this.addTestNoteOpened = true;
  }

  closeAddTestNotes() {
    this.addTestNoteOpened = false;
  }

  onAddTestNote() {
    const note = this.testNotesValue.length > 0 ? "[" + (moment(new Date).format('MMM-DD-yyyy').toString()) + ", " + this.userDetail?.firstName + ' ' + this.userDetail?.lastName + "]: " + this.testNotesValue : '';
    this.passdownTestDetails.notes = this.passdownTestDetails.notes?.length > 0 ? this.passdownTestDetails.notes + '\n' + note : note;
    this.addTestNoteOpened = false;
    this.disableSaveButton = false;
  }

  openAddZoneNotes(note: string, index: number) {
    this.selectedZoneIndex = index;
    this.zoneNotesValue = '';
    this.addZoneNoteOpened = true;
  }

  closeAddZoneNotes() {
    this.selectedZoneIndex = null;
    this.addZoneNoteOpened = false;
  }

  onAddZoneNote() {
    const note = this.zoneNotesValue.length > 0 ? "[" + (moment(new Date).format('MMM-DD-yyyy').toString()) + ", " + this.userDetail?.firstName + ' ' + this.userDetail?.lastName + "]: " + this.zoneNotesValue : '';
    this.passdownZoneOperationTextDetails[this.selectedZoneIndex].zoneNotes = this.passdownZoneOperationTextDetails[this.selectedZoneIndex].zoneNotes?.length > 0 ? this.passdownZoneOperationTextDetails[this.selectedZoneIndex].zoneNotes + '\n' + note : note;
    this.closeAddZoneNotes();
    this.disableSaveButton = false;
  }
  onInputTestCompleted() {
    this.disableSaveButton = false;
  }
  onInputTestProgressed() {
    this.disableSaveButton = false;
  }
  onInputTestSkipped() {
    this.disableSaveButton = false;
  }
  onInputTestNextStep() {
    this.disableSaveButton = false;
  }
  onInputTestSpecialInstruction() {
    this.disableSaveButton = false;
  }

  onInputAssemblyCompleted() {
    this.disableSaveButton = false;
  }
  onInputAssemblyProgressed() {
    this.disableSaveButton = false;
  }
  onInputAssemblySkipped() {
    this.disableSaveButton = false;
  }
  onInputAssemblyNextStep() {
    this.disableSaveButton = false;
  }
  onInputAssemblyRework() {
    this.disableSaveButton = false;
  }
  getHowPassdownGenerateText(): string {
    let tooltipText = '';
    if (this.site?.plantName === 'Fremont')
      tooltipText = 'Passdowns are automatically populated based on\nthe shift type, i.e. day shift and night shift\n\nEach item is recorded into the passdown either\nbased on individual’s shift that completed /\nmodified the task or based on timestamp.For\nthose items that are not manual entry, listed\nbelow is the determination factor:\n- Operations: Shift\n- Audit Items: Shift\n- Rework: Shift\n- Critical / Gating TOIs: Time\n- TOIs: Shift\n- Issue Logs: Shift\n- Open NCis: Time\n- Closed NCis: Shift\n- BOM Changes: not currently being pulled into Fremont\n';
    else
      tooltipText = 'Passdowns are automatically populated based on\nthe shift type. i.e. day shift and night shift\n\nEach item is recorded into the passdown either\nbased on individual’s shift that completed /\nmodified the task or based on timestamp.For\nthose items that are not manual entry, listed\nbelow is the determination factor:\n- Operations: Shift\n- Audit Items: Shift\n- Rework: Shift\n- Critical / Gating TOIs: Time\n- TOIs: Shift\n- Issue Logs: Shift\n- Open NCis: Time\n- Closed NCis: Shift\n- Open BOM Changes: Time\n- Closed BOM Changes: Shift';
    return tooltipText;
  }
  public showSuccess(msg: string): void {
    this.notificationService.show({
      appendTo: this.appendTo,
      content: msg,
      position: { horizontal: "left", vertical: "bottom" },
      animation: { type: "fade", duration: 600 },
      type: { style: "success", icon: true },
    });
  }

  goToHome() {
    this.router.navigate([
      '/home'
    ]);
  }

  goToEditModHome() {
    this.router.navigate([
      '/edit-module/' + this.pilotProductId + '/' + 0
    ]);
  }
}
