import { HttpClient } from "@angular/common/http";
import {
  Component,
  Input,
  OnChanges,
  OnInit,
  SimpleChanges,
  ViewChild,
  ViewEncapsulation,
} from "@angular/core";
import { Router } from "@angular/router";
import { MultiSelectComponent } from "@progress/kendo-angular-dropdowns";
import { TooltipDirective } from "@progress/kendo-angular-tooltip";
import {
  CompositeFilterDescriptor,
  distinct,
  filterBy,
} from "@progress/kendo-data-query";
import * as moment from "moment";
import { environment } from "../../../../../../environments/environment.dev_server";
import { AppStoreService } from "../../../../../core/app-store.service";
import { role } from "../../../../../core/model/common.constant";
import { Plant, UserModel } from "../../../../../core/model/user.model";
import { Item } from "../../../../model/item";
import { DataServiceEandTService } from "../../../data-service-eand-t.service";
import { ModuleSummary } from "../../../Models/ModuleSummary";
import { Shortages } from "../../../Models/shortages.model";
import { TOI } from "../../../Models/toi.model";

@Component({
  selector: "pmpm-shortages",
  templateUrl: "./shortages.component.html",
  styleUrls: ["./shortages.component.css"],
  encapsulation: ViewEncapsulation.None,
})
export class ShortagesComponent implements OnInit, OnChanges {
  @Input() pilotProductId: number;
  @Input() site: Plant;
  @ViewChild(TooltipDirective) public tooltipDir: TooltipDirective;
  @ViewChild("multiselect") public multiselect: MultiSelectComponent;

  //access
  public userDetails: UserModel;
  public canEditCriticalGating = false;

  //grid
  public gridDataForShortages = [];
  public originalData = [];
  public hoverMessage = "";
  public moduleInfo: ModuleSummary = null;
  public isLoading = true;
  canAddTOI = false;
  public ben = "";

  //search and filter
  public filter: CompositeFilterDescriptor;
  public searchText = "";
  public PNDataItem: string[] = [];
  public PNFilteredList: string[] = [];
  public tempPNFilteredList: string[] = [];
  public OPDataItem: string[] = [];
  public OPFilteredList: string[] = [];
  public tempOPFilteredList: string[] = [];

  //Add TOI
  readonly apiUrl = `${environment.apiUrl}`;
  public lessThanTodayExpectedDateError = false;
  public lessThanTodayGatingDateError = false;
  public minDate = new Date();
  public zoneData: Item[] = [];
  public toiZone: Item;
  public toiComments = "";
  public toiId: number;
  public fileToUpload: File[] = [];
  public uploadedFiles: string[] = [];
  public disableUpload = false;

  public addTOIOpened = false;
  public toiStatus: Item;
  public toiTitle = "";
  public toiDescription = "";
  public disableSaveBtn = false;
  public toiStatusData: Item[] = [];
  public toiCGData = [" ", "Critical", "Gating"];
  public toiCG = " ";
  public expectedCloseDate: Date;
  public gatingDate: Date;
  public dateValue = new Date();
  public criticalGatingError = false;
  public expectedDateError = false;
  public gatingDateError = false;
  public sameFileError = false;
  public sameFileErrorMessage = "";

  constructor(
    private appStoreService: AppStoreService,
    private service: DataServiceEandTService,
    private http: HttpClient,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.appStoreService.getLoggedInUser().subscribe((res) => {
      this.appStoreService.getUserDetails(res.mail).subscribe((user) => {
        if (user && user.username?.length > 0) {
          this.userDetails = user;
        }
      });
    });
    this.appStoreService.getUserRoles().subscribe((res) => {
      if (res && res.length > 0) {
        if (
          res.includes(role.Technician) ||
          res.includes(role.Leads) ||
          res.includes(role.Supervisor) ||
          res.includes(role.SuperUser)
        )
          this.canAddTOI = true;
        if (
          res.includes(role.Manager) ||
          res.includes(role.Leads) ||
          res.includes(role.Supervisor) ||
          res.includes(role.SuperUser)
        )
          this.canEditCriticalGating = true;
      }
    });
    this.getDropdowns();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (
      changes["pilotProductId"] &&
      changes["pilotProductId"] !== null &&
      changes["pilotProductId"].currentValue
    ) {
      this.pilotProductId = changes["pilotProductId"].currentValue;
    }
    if (
      changes["site"] &&
      changes["site"] !== null &&
      changes["site"].currentValue
    ) {
      this.site = changes["site"].currentValue;
      if (this.site !== undefined && this.pilotProductId !== undefined) {
        this.service
          .getModuleSummaryByID(+this.pilotProductId)
          .toPromise()
          .then((data) => {
            if (data && data.length > 0) {
              this.moduleInfo = data.filter(
                (item) =>
                  +item.ModuleInfo.PilotProductID ===
                  +this.pilotProductId
              )[0];
              if (
                this.site?.plantName === "Fremont" &&
                this.moduleInfo?.ModuleInfo
                  ?.PilotSerialNumber !== null
              ) {
                this.ben =
                  this.moduleInfo?.ModuleInfo?.PilotSerialNumber;
                this.getShortagesDetails(
                  this.moduleInfo?.ModuleInfo
                    ?.PilotSerialNumber
                );
              } else if (
                this.site?.plantName !== "Fremont" &&
                this.moduleInfo?.ModuleInfo?.BEN !== null
              ) {
                this.ben = this.moduleInfo?.ModuleInfo?.BEN;
                this.getShortagesDetails(
                  this.moduleInfo?.ModuleInfo?.BEN
                );
              } else {
                this.isLoading = false;
              }
            }
          });
      }
    }
  }

  getDropdowns() {
    this.service.GetTOIStatus().subscribe((res) => {
      if (res && res.length > 0) {
        this.toiStatusData = [];
        res.forEach((item) => {
          this.toiStatusData.push({
            text: item.masterRecordName,
            value: item.masterRecordID,
          });
        });
        this.toiStatus = this.toiStatusData[0];
      }
    });

    this.service.GetTOIZone(+this.pilotProductId).subscribe((res) => {
      if (res && res.length > 0) {
        res.forEach((item) => {
          this.zoneData.push({
            text: item.description,
            value: item.zoneID,
          });
          this.zoneData.sort(function (a, b) {
            const textA = a?.text?.toUpperCase();
            const textB = b?.text?.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
          });
        });
      }
    });
  }

  getShortagesDetails(id: string) {
    this.service.GetShortagesDetails(id).subscribe((res) => {
      if (res && res.length > 0) {
        this.gridDataForShortages = res;
        this.originalData = JSON.parse(
          JSON.stringify(this.gridDataForShortages)
        );
        this.getFilterList();
      }
      this.isLoading = false;
    });
  }

  getFilterList() {
    let PN: any = distinct(this.originalData, "partNumber").map(
      (item) => item["partNumber"]
    );
    PN = PN.flatMap((f) => (f ? [f] : []));
    PN.sort(function (a, b) {
      const textA = a?.toUpperCase();
      const textB = b?.toUpperCase();
      return textA < textB ? -1 : textA > textB ? 1 : 0;
    });
    this.PNFilteredList = [...PN];
    this.tempPNFilteredList = JSON.parse(
      JSON.stringify(this.PNFilteredList)
    );

    let opNumber: any = distinct(this.originalData, "op").map(
      (item) => item["op"]
    );
    opNumber = opNumber.flatMap((f) => (f ? [f] : []));
    opNumber.sort(function (a, b) {
      const textA = a?.toUpperCase();
      const textB = b?.toUpperCase();
      return textA < textB ? -1 : textA > textB ? 1 : 0;
    });
    this.OPFilteredList = [...opNumber];
    this.tempOPFilteredList = JSON.parse(
      JSON.stringify(this.OPFilteredList)
    );
  }

  onPNClick(partNumber: string) {
    const url = "https://kmmatrix.fremont.lamrc.net/Search?q=" + partNumber;
    window.open(url, "_blank");
  }

  onQtyClick(partNumber: string) {
    const url =
      "https://lamresearch.quickbase.com/db/brw9d3sei?a=q&qid=5&nv=1&v0=" +
      partNumber;
    window.open(url, "_blank");
  }

  public showTooltip(e: MouseEvent): void {
    const element = e.target as HTMLElement;
    if (
      (element.nodeName === "TH" || element.nodeName === "TD") &&
      element.offsetWidth < element.scrollWidth
    ) {
      this.hoverMessage = element.textContent;
      this.tooltipDir.toggle(element);
    } else {
      this.tooltipDir.hide();
    }
  }

  //Integrating Add TOI button
  onAddTOI(dataItem: Shortages) {
    this.toiTitle =
      "Shortage: PN " +
      dataItem.partNumber +
      " - " +
      dataItem.description;
    this.toiDescription =
      dataItem.dueDate != null
        ? "Due " +
        moment(new Date(dataItem.dueDate))
          .format("MMM-DD-yyyy")
          .toString()
        : "Due " + dataItem.dueDate;
    this.addTOIOpened = true;
  }
  onCloseAddTOI() {
    this.addTOIOpened = false;
    this.resetAddTOIForm();
  }
  onInputTitle() {
    if (
      this.toiTitle?.trim()?.length > 0 &&
      this.toiDescription.trim().length > 0
    )
      this.disableSaveBtn = false;
    else this.disableSaveBtn = true;
  }
  onInputDescription() {
    if (
      this.toiTitle?.trim()?.length > 0 &&
      this.toiDescription.trim().length > 0
    )
      this.disableSaveBtn = false;
    else this.disableSaveBtn = true;
  }
  onValueChange(value: string) {
    if (value?.trim()?.length === 0) {
      this.expectedCloseDate = null;
      this.gatingDate = null;
      this.lessThanTodayExpectedDateError = false;
      this.lessThanTodayGatingDateError = false;
      this.expectedDateError = false;
      this.gatingDateError = false;
    } else {
      this.criticalGatingError = false;
    }
  }
  onExpectedDateChange(value: Date) {
    this.minDate.setHours(0, 0, 0, 0);
    if (value === null || value === undefined) {
      this.expectedDateError = true;
      this.lessThanTodayExpectedDateError = false;
    } else {
      this.expectedDateError = false;
      if (value?.getTime() < this.minDate?.getTime()) {
        this.lessThanTodayExpectedDateError = true;
      } else {
        this.lessThanTodayExpectedDateError = false;
      }
    }
  }
  onGatingDateChange(value: Date) {
    this.minDate.setHours(0, 0, 0, 0);
    if (value === null || value === undefined) {
      this.gatingDateError = true;
      this.lessThanTodayExpectedDateError = false;
    } else {
      this.gatingDateError = false;
      if (value?.getTime() < this.minDate?.getTime()) {
        this.lessThanTodayGatingDateError = true;
      } else {
        this.lessThanTodayGatingDateError = false;
      }
    }
  }
  upload() {
    const input = document.getElementById("file");
    input.click();
  }
  handleFileInput(files: FileList) {
    this.sameFileError = false;
    this.sameFileErrorMessage = "";
    if (
      this.uploadedFiles.length > 6 ||
      files.length > 6 ||
      this.uploadedFiles.length + files.length > 6
    ) {
      this.disableUpload = true;
    } else {
      this.disableUpload = false;
      const item = Array.from(files);
      item.forEach((f) => {
        if (!this.uploadedFiles?.includes(f.name)) {
          this.fileToUpload.push(f);
          this.uploadedFiles.push(f.name);
        } else {
          this.sameFileError = true;
          this.sameFileErrorMessage +=
            (this.sameFileErrorMessage.length > 0 ? ", " : "") +
            f.name;
        }
      });
    }
  }
  uploadFiles(files) {
    const formData: FormData = new FormData();
    for (let i = 0; i < files.length; i++) {
      formData.append("fileKey", files[i], files[i].name);
    }

    this.service.uploadTOIfile(this.toiId, formData).subscribe((req) => {
      if (req && req["value"] === "Updated Successfully") {
        this.resetAddTOIForm();
      }
    });
  }
  removeFile(file: string, index) {
    if (this.fileToUpload.filter((f) => f.name === file)?.length === 0) {
      if (this.toiId !== null && this.toiId !== undefined)
        this.service
          .deleteTOIfile(this.toiId, file)
          .subscribe((req) => { });
    }
    const after = Array.from(this.uploadedFiles);
    after.splice(index, 1);
    this.uploadedFiles = JSON.parse(JSON.stringify(after));
    this.fileToUpload.splice(index, 1);
  }
  resetAddTOIForm() {
    this.toiTitle = "";
    this.toiDescription = "";
    this.toiComments = "";
    this.toiStatus = this.toiStatusData[0];
    this.toiCG = " ";
    this.uploadedFiles = [];
    this.disableSaveBtn = false;
    this.expectedCloseDate = null;
    this.gatingDate = null;
    this.toiZone = undefined;
    this.fileToUpload = [];
    this.disableUpload = false;
    this.lessThanTodayExpectedDateError = false;
    this.lessThanTodayGatingDateError = false;
    this.criticalGatingError = false;
    this.expectedDateError = false;
    this.gatingDateError = false;
    this.sameFileError = false;
    this.sameFileErrorMessage = "";
  }
  onSaveTOI() {
    const request = new TOI();
    request.isGating = this.toiCG === "Gating";
    request.isCritical = this.toiCG === "Critical";
    if ((request.isCritical || request.isGating) &&
      (this.expectedCloseDate === null ||
        this.expectedCloseDate === undefined)
    ) {
      this.expectedDateError = true;
    } else if ((request.isCritical || request.isGating) && (this.gatingDate === null || this.gatingDate === undefined)) {
      this.gatingDateError = true;
    } else {
      request.pilotProductID = +this.pilotProductId;
      request.ben = this.ben;
      request.title = this.toiTitle;
      request.issueDescription = this.toiDescription;
      request.statusID = this.toiStatus?.value;

      const com = this.toiComments.split("]");
      if (com && com.length > 1) {
        const com1 = com[1].split("\n");
        if (com1 && com1.length > 1) this.toiComments = com1[1];
      }
      const comment =
        this.toiComments?.length > 0
          ? "[" +
          moment(new Date()).format("MMM-DD-yyyy").toString() +
          ", " +
          this.userDetails.firstName +
          " " +
          this.userDetails.lastName +
          "]: \n" +
          this.toiComments
          : "";
      request.comments = comment;

      if (
        this.expectedCloseDate !== null &&
        this.expectedCloseDate !== undefined
      ) {
        request.expectedCloseDate = new Date(
          this.expectedCloseDate.getTime() -
          new Date(this.expectedCloseDate).getTimezoneOffset() *
          60000
        );
      }
      if (this.gatingDate !== null && this.gatingDate !== undefined) {
        request.gatingDate = new Date(
          this.gatingDate.getTime() -
          new Date(this.gatingDate).getTimezoneOffset() * 60000
        );
      }
      if (this.toiZone) {
        request.zoneID = this.toiZone.value;
        request.zoneName = this.toiZone.text;
      }
      request.createdBy =
        this.userDetails?.firstName + " " + this.userDetails?.lastName;
      request.createdById = this.userDetails?.userId;
      if (this.fileToUpload?.length > 0) {
        this.service.AddTOI(request).subscribe((res) => {
          if (res && res.data) {
            this.toiId = res.data;
            this.addTOIOpened = false;
            this.uploadFiles(this.fileToUpload);
            if (this.site?.plantName !== "Fremont") {
              this.router
                .navigateByUrl("/", {
                  skipLocationChange: true,
                })
                .then(() => {
                  this.router.navigate([
                    "/action-items/" +
                    this.pilotProductId +
                    "/" +
                    6,
                  ]);
                });
            } else {
              this.router
                .navigateByUrl("/", {
                  skipLocationChange: true,
                })
                .then(() => {
                  this.router.navigate([
                    "/action-items/" +
                    this.pilotProductId +
                    "/" +
                    5,
                  ]);
                });
            }
          }
        });
      } else {
        this.service.AddTOI(request).subscribe((res) => { });
        this.addTOIOpened = false;
        this.resetAddTOIForm();
        if (this.site?.plantName !== "Fremont") {
          this.router
            .navigateByUrl("/", { skipLocationChange: true })
            .then(() => {
              this.router.navigate([
                "/action-items/" +
                this.pilotProductId +
                "/" +
                6,
              ]);
            });
        } else {
          this.router
            .navigateByUrl("/", { skipLocationChange: true })
            .then(() => {
              this.router.navigate([
                "/action-items/" +
                this.pilotProductId +
                "/" +
                5,
              ]);
            });
        }
      }
    }
  }

  //Search
  onSearchFilter() {
    const filter: CompositeFilterDescriptor = { filters: [], logic: "and" };
    if (this.searchText && this.searchText.length > 0) {
      const searchFilter = [
        {
          field: "partNumber",
          operator: "contains",
          value: this.searchText.trim(),
        },
        {
          field: "description",
          operator: "contains",
          value: this.searchText.trim(),
        },
      ];
      filter.filters.push({ filters: [...searchFilter], logic: "or" });
    }
    if (this.PNDataItem && this.PNDataItem.length > 0) {
      const PN: any[] = [];
      this.PNDataItem.forEach((item) => {
        PN.push({
          field: "partNumber",
          operator: "contains",
          value: item,
        });
      });
      filter.filters.push({ filters: [...PN], logic: "or" });
    }
    if (this.OPDataItem && this.OPDataItem.length > 0) {
      const op: any[] = [];
      this.OPDataItem.forEach((item) => {
        op.push({
          field: "op",
          operator: "contains",
          value: item,
        });
      });
      filter.filters.push({ filters: [...op], logic: "or" });
    }

    this.filter = filter;
    this.gridDataForShortages = filterBy(this.originalData, filter);
  }

  //Filters
  handlePNFilter(value) {
    if (value.length >= 0) {
      this.PNFilteredList = this.tempPNFilteredList.filter(
        (s) => s?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
      );
    } else {
      this.multiselect.toggle(false);
    }
  }

  handleOPFilter(value) {
    if (value.length >= 0) {
      this.OPFilteredList = this.tempOPFilteredList.filter(
        (s) => s?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
      );
    } else {
      this.multiselect.toggle(false);
    }
  }
}
