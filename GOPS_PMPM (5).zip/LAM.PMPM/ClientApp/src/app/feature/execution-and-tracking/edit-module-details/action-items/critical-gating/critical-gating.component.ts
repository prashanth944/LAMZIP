import { Component, OnInit, ViewChild, ViewEncapsulation } from "@angular/core";
import { Router } from "@angular/router";
import { TooltipDirective } from "@progress/kendo-angular-tooltip";
import {
    CompositeFilterDescriptor,
    filterBy,
} from "@progress/kendo-data-query";
import { AppStoreService } from "../../../../../core/app-store.service";
import { Plant } from "../../../../../core/model/user.model";
import { DataServiceEandTService } from "../../../data-service-eand-t.service";
import { CG } from "../../../Models/critical-gating.model";

@Component({
    selector: "pmpm-critical-gating",
    templateUrl: "./critical-gating.component.html",
    styleUrls: ["./critical-gating.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class CriticalGatingComponent implements OnInit {
    @ViewChild(TooltipDirective) public tooltipDir: TooltipDirective;

    public gridData = [];
    public userData: any;
    public site: Plant;
    public userId: number;
    public isLoading = true;
    public originalData = [];
    public hoverMessage = "";
    public searchText = "";
    public filter: CompositeFilterDescriptor;

    constructor(
        private service: DataServiceEandTService,
        private appStoreService: AppStoreService,
        private router: Router
    ) {}

    ngOnInit(): void {
        this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site) {
                this.site = {
                    plantName: site.plantName,
                    plantId: site.plantId,
                };
                this.getCriticalGating();
            }
        });

        this.appStoreService.getLoggedInUser().subscribe((user) => {
            this.appStoreService.getUserDetails(user.mail).subscribe((res) => {
                if (res && res.username.length > 0) {
                    this.userData = res;
                }
            });
        });
    }

    public getCriticalGating() {
        this.service.GetCriticalGating(this.site.plantId).subscribe((res) => {
            if (res && res.length > 0) {
                res.forEach((item) => {
                    item.issueDescriptionWithoutTag =
                        item.issueDescription.replace(/(<([^>]+)>)/gi, "");
                });
                this.gridData = res;
                this.originalData = JSON.parse(JSON.stringify(this.gridData));
            }
            this.isLoading = false;
        });
    }

    public routeToEditModule(dataItem: CG) {
        this.router.navigate([
            "/edit-module/" + dataItem.pilotProductID + "/" + 0,
        ]);
    }

    routeToTOI(dataItem: CG) {
        let tabId = 0;
        if (this.site.plantName == "Fremont") tabId = 5;
        else tabId = 6;
        this.router
            .navigateByUrl("/", { skipLocationChange: true })
            .then(() => {
                this.router.navigate([
                    "/action-items/" + dataItem.pilotProductID + "/" + tabId,
                ]);
            });
    }

    //Tooltip
    public showTooltip(e: MouseEvent): void {
        const element = e.target as HTMLElement;
        if (
            (element.nodeName === "TH" || element.nodeName === "TD") &&
            element.offsetWidth < element.scrollWidth
        ) {
            this.hoverMessage = element.textContent;
            this.tooltipDir.toggle(element);
        } else {
            this.tooltipDir.hide();
        }
    }

    //Search
    onSearchFilter() {
        const filter: CompositeFilterDescriptor = { filters: [], logic: "and" };
        if (this.searchText && this.searchText.length > 0) {
            if (this.site.plantName == "Fremont") {
                const searchFilter = [
                    {
                        field: "pilotSerialNumber",
                        operator: "contains",
                        value: this.searchText.trim(),
                    },
                    {
                        field: "productionOrderNum",
                        operator: "contains",
                        value: this.searchText.trim(),
                    },
                    {
                        field: "title",
                        operator: "contains",
                        value: this.searchText.trim(),
                    },
                    {
                        field: "issueDescription",
                        operator: "contains",
                        value: this.searchText.trim(),
                    },
                    {
                        field: "comments",
                        operator: "contains",
                        value: this.searchText.trim(),
                    },
                ];
                filter.filters.push({
                    filters: [...searchFilter],
                    logic: "or",
                });
            } else {
                const searchFilter = [
                    {
                        field: "ben",
                        operator: "contains",
                        value: this.searchText.trim(),
                    },
                    {
                        field: "productionOrderNum",
                        operator: "contains",
                        value: this.searchText.trim(),
                    },
                    {
                        field: "title",
                        operator: "contains",
                        value: this.searchText.trim(),
                    },
                    {
                        field: "issueDescription",
                        operator: "contains",
                        value: this.searchText.trim(),
                    },
                    {
                        field: "comments",
                        operator: "contains",
                        value: this.searchText.trim(),
                    },
                ];
                filter.filters.push({
                    filters: [...searchFilter],
                    logic: "or",
                });
            }
        }

        this.filter = filter;
        this.gridData = filterBy(this.originalData, filter);
    }
}
