import { Component, Input, OnInit } from "@angular/core";
import pdfMake from "pdfmake/build/pdfmake";
import pdfFonts from "pdfmake/build/vfs_fonts";
import { Plant } from "../../../../core/model/user.model";
import { DataServiceEandTService } from "../../data-service-eand-t.service";
import { DatePipe } from "@angular/common";
import { Router } from "@angular/router";
import * as moment from "moment";
pdfMake.vfs = pdfFonts.pdfMake.vfs;

@Component({
    selector: "pmpm-tags-sns-docs",
    templateUrl: "./tags-sns-docs.component.html",
    styleUrls: ["./tags-sns-docs.component.css"],
})
export class TagsSnsDocsComponent implements OnInit {
    @Input() site: Plant;
    @Input() pilotProductID: number;
    dialogOpened = false;
    messageonInput = "";
    private infoModule: any;

    constructor(
        private service: DataServiceEandTService,
        public datepipe: DatePipe,
        private router: Router
    ) {}

    ngOnInit(): void {
        // Load Info
        let date: any = new Date();
        date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
        this.service
            .getModuleInfoForTag(this.pilotProductID, this.site.plantId, date)
            .subscribe((data) => {
                this.infoModule = data;
                this.infoModule.plannedIntegrationStart =
                    data.plannedIntegrationStart !== null
                        ? new Date(data.plannedIntegrationStart)
                        : null;
                this.infoModule.plannedManufacturingComplete =
                    data.plannedManufacturingComplete !== null
                        ? new Date(data.plannedManufacturingComplete)
                        : null;
                this.infoModule.plannedTestComplete =
                    data.plannedTestComplete !== null
                        ? new Date(data.plannedTestComplete)
                        : null;
                this.infoModule.plannedTestStart =
                    data.plannedTestStart !== null
                        ? new Date(data.plannedTestStart)
                        : null;
                this.infoModule.actualLaunch =
                    data.actualLaunch !== null
                        ? new Date(data.actualLaunch)
                        : null;
                this.infoModule.actualManufacturingCompleteManual =
                    data.actualManufacturingCompleteManual !== null
                        ? new Date(data.actualManufacturingCompleteManual)
                        : null;
                this.infoModule.actualManufacturingComplete =
                    data.actualManufacturingComplete !== null
                        ? new Date(data.actualManufacturingComplete)
                        : null;
                this.infoModule.actualTestComplete =
                    data.actualTestComplete !== null
                        ? new Date(data.actualTestComplete)
                        : null;
                this.infoModule.actualTestCompleteManual =
                    data.actualTestCompleteManual !== null
                        ? new Date(data.actualTestCompleteManual)
                        : null;
                this.infoModule.actualTestStart =
                    data.actualTestStart !== null
                        ? new Date(data.actualTestStart)
                        : null;
                this.infoModule.actualTestStartManual =
                    data.actualTestStartManual !== null
                        ? new Date(data.actualTestStartManual)
                        : null;
                this.infoModule.actualIntegrationStart =
                    data.actualIntegrationStart !== null
                        ? new Date(data.actualIntegrationStart)
                        : null;
                this.infoModule.actualIntegrationStartManual =
                    data.actualIntegrationStartManual !== null
                        ? new Date(data.actualIntegrationStartManual)
                        : null;
                this.onChangeTestDays();
            });
    }
    castDate(date: any) {
        if (date === null) {
            return " ";
        }
        return this.datepipe.transform(date, "MM-dd-yyyy");
    }

    getPDFMakerCodeForFremont() {
        // playground requires you to assign document definition to a variable called dd

        const dd = {
            pageOrientation: "landscape",
            content: [
                {
                    text: "SERIAL NUMBER:",
                    style: "header",
                    alignment: "center",
                    decoration: ["underline"],
                },
                {
                    columns: [
                        { width: "*", text: "" },
                        {
                            width: "auto",
                            table: {
                                body: [
                                    [
                                        {
                                            text:
                                                this.infoModule
                                                    .pilotSerialNumber ?? " ",
                                            style: "header2",
                                        },
                                    ],
                                ],
                                alignment: "center",
                            },
                        },
                        { width: "*", text: "" },
                    ],
                },
                "\n",
                {
                    text:
                        "PM# POSITION: " +
                        (this.infoModule.processModule ?? " "),
                    style: "positionA",
                    alignment: "center",
                },
                "\n",
                {
                    columns: [
                        [
                            {
                                text: "Launch Date:",
                                style: "header",
                                decoration: ["underline"],
                                fontSize: 15,
                            },
                            {
                                table: {
                                    widths: [200],
                                    body: [
                                        [
                                            {
                                                text: this.castDate(
                                                    this.infoModule.actualLaunch
                                                ),
                                                style: "boxone",
                                                fontSize: 20,
                                            },
                                        ],
                                    ],
                                    alignment: "center",
                                },
                            },
                            {
                                text: "Sales Order:",
                                style: "header",
                                decoration: ["underline"],
                                fontSize: 15,
                            },
                            {
                                table: {
                                    widths: [200],
                                    body: [
                                        [
                                            {
                                                text:
                                                    this.infoModule
                                                        .salesOrder ?? "",
                                                style: "boxone",
                                                fontSize: 20,
                                            },
                                        ],
                                    ],
                                    alignment: "center",
                                },
                            },
                        ],
                        { text: "", width: 340 },
                        [
                            {
                                text: "Test Start:",
                                style: "header",
                                decoration: ["underline"],
                                fontSize: 15,
                            },
                            {
                                table: {
                                    widths: [200],
                                    body: [
                                        [
                                            {
                                                text: this.castDate(
                                                    this.infoModule
                                                        .plannedTestStart
                                                ),
                                                style: "boxone",
                                                fontSize: 20,
                                            },
                                        ],
                                    ],
                                    alignment: "center",
                                },
                            },
                            {
                                text: "Pilot Complete (Disconnect):",
                                style: "header",
                                decoration: ["underline"],
                                fontSize: 15,
                            },
                            {
                                table: {
                                    widths: [200],
                                    body: [
                                        [
                                            {
                                                text: this.castDate(
                                                    this.infoModule
                                                        .plannedManufacturingComplete
                                                ),
                                                style: "boxone",
                                                fontSize: 20,
                                            },
                                        ],
                                    ],
                                    alignment: "center",
                                },
                            },
                        ],
                    ],
                },
                "\n",
                {
                    text: "FCID NUMBER:",
                    style: "header",
                    alignment: "center",
                    decoration: ["underline"],
                },
                {
                    columns: [
                        { width: "*", text: "" },
                        {
                            width: "auto",
                            table: {
                                widths: [300],
                                body: [
                                    [
                                        {
                                            text: this.infoModule.fcid ?? " ",
                                            style: "boxone",
                                            alignment: "center",
                                        },
                                    ],
                                ],
                                alignment: "center",
                            },
                        },
                        { width: "*", text: "" },
                    ],
                },
                "\n",
                {
                    text: "Build location / Test Bay:",
                    style: "header",
                    alignment: "center",
                    decoration: ["underline"],
                },
                {
                    columns: [
                        { width: "*", text: "" },
                        {
                            width: "auto",
                            table: {
                                widths: [600],
                                body: [
                                    [
                                        {
                                            text: this.messageonInput ?? " ",
                                            style: "boxone",
                                            alignment: "center",
                                            fillColor: "#FFFF00",
                                        },
                                    ],
                                ],
                                alignment: "center",
                            },
                        },
                        { width: "*", text: "" },
                    ],
                },
            ],
            styles: {
                header: {
                    fontSize: 35,
                    bold: true,
                    alignment: "justify",
                    color: "#755920",
                },
                header2: {
                    alignment: "center",
                    fontSize: 35,
                    bold: true,
                    fillColor: "#FFFF00",
                    color: "#FF0000",
                },
                positionA: {
                    fontSize: 30,
                    bold: true,
                    color: "#FF0000",
                },
                boxone: {
                    fontSize: 30,
                    bold: true,
                    color: "#FF0000",
                },
            },
        };
        return dd;
    }

    getPDFMakerCodeForTualatin() {
        let colorFillCode = "#ffffff"; // White backgound color
        let colorFontCode = "#000000"; // White font color
        const colorModule =
            this.infoModule.capacityPlanningColor === null
                ? null
                : this.infoModule.capacityPlanningColor.trim();

        if (
            colorModule === null ||
            colorModule === "Unassigned" ||
            colorModule === "White" ||
            colorModule === "transparent" ||
            colorModule === "#ffffff"
        ) {
            colorFillCode = "#ffffff";
            colorFontCode = "#000000";
        } else if (colorModule === "Black") {
            colorFillCode = "#000000";
            colorFontCode = "#ffffff";
        } else if (colorModule === "Blue") {
            colorFillCode = "#0000ff";
            colorFontCode = "#ffffff";
        } else if (colorModule === "Cyan") {
            colorFillCode = "#00ffff";
            colorFontCode = "#ffffff";
        } else if (colorModule === "Dark Gray") {
            colorFillCode = "#a9a9a9";
            colorFontCode = "#000000";
        } else if (colorModule === "Light Gray") {
            colorFillCode = "#d3d3d3";
            colorFontCode = "#000000";
        } else if (colorModule === "Light Green") {
            colorFillCode = "#90ee90";
            colorFontCode = "#000000";
        } else if (colorModule === "Orange") {
            colorFillCode = "#FFA500";
            colorFontCode = "#ffffff";
        } else {
            colorFillCode = colorModule;
            colorFontCode = "#ffffff";
        }

        const dd = {
            pageOrientation: "landscape",
            content: [
                {
                    style: "tableExample",
                    table: {
                        widths: ["auto", "*"],
                        body: [
                            [
                                { text: "PO/SO", style: "textH" },
                                {
                                    text:
                                        (this.infoModule.purchaseOrderNumber ??
                                            "") +
                                        " / " +
                                        (this.infoModule.salesOrder ?? ""),
                                    style: "textHV",
                                },
                            ],
                            [
                                { text: "BEN/Item#", style: "text" },
                                {
                                    text:
                                        (this.infoModule.ben ?? "") +
                                        " / " +
                                        (this.infoModule.salesOrderNumber ??
                                            ""),
                                    style: "textV",
                                },
                            ],
                            [
                                { text: "PM/SN", style: "text" },
                                {
                                    text:
                                        "POS " +
                                        (this.infoModule.processModule ?? "") +
                                        " / " +
                                        (this.infoModule.pilotSerialNumber ??
                                            ""),
                                    style: "textV",
                                },
                            ],
                            [
                                { text: "Integration", style: "text2" },
                                {
                                    text: this.castDate(
                                        this.infoModule.plannedIntegrationStart
                                    ),
                                    style: "text2",
                                },
                            ],
                            [
                                { text: "Test Start", style: "text2" },
                                {
                                    text: this.castDate(
                                        this.infoModule.plannedTestStart
                                    ),
                                    style: "text2",
                                },
                            ],
                            [
                                { text: "Pilot Complete", style: "text2" },
                                {
                                    text: this.castDate(
                                        this.infoModule
                                            .plannedManufacturingComplete
                                    ),
                                    style: "text2",
                                },
                            ],
                            [
                                {
                                    colSpan: 2,
                                    text: this.infoModule.toolTypeName,
                                    style: "text3",
                                    decoration: ["underline"],
                                },
                            ],
                        ],
                    },
                    layout: {
                        hLineWidth: function (i, node) {
                            return i === 0 || i === node.table.body.length
                                ? 2
                                : 1;
                        },
                        vLineWidth: function (i, node) {
                            return i === 0 || i === node.table.widths.length
                                ? 2
                                : 1;
                        },
                        hLineColor: function (i, node) {
                            return i <= 2 || i === node.table.body.length
                                ? "black"
                                : "white";
                        },
                        vLineColor: function (i, node) {
                            return i === 0 || i === node.table.widths.length
                                ? "black"
                                : "white";
                        },
                    },
                },
            ],
            styles: {
                textH: {
                    alignment: "center",
                    fontSize: 35,
                    bold: true,
                    fillColor: colorFillCode,
                    color: colorFontCode,
                },
                textHV: {
                    alignment: "center",
                    fontSize: 55,
                    bold: true,
                    fillColor: colorFillCode,
                    color: colorFontCode,
                },
                text: {
                    alignment: "center",
                    fontSize: 35,
                    bold: true,
                },
                textV: {
                    alignment: "center",
                    fontSize: 45,
                    bold: true,
                },
                text2: {
                    alignment: "center",
                    fontSize: 15,
                    bold: true,
                },
                text3: {
                    alignment: "center",
                    fontSize: 35,
                    bold: true,
                },
            },
            defaultStyle: {},
        };
        return dd;
    }

    generatePDF() {
        let dd;
        if (this.site) {
            if (this.site.plantName === "Fremont") {
                dd = this.getPDFMakerCodeForFremont();
            } else {
                dd = this.getPDFMakerCodeForTualatin();
            }
        }
        pdfMake.createPdf(dd).print();
    }

    public requestPrintOfPdf() {
        if (this.site) {
            if (this.site.plantName === "Fremont") {
                this.display();
            } else {
                this.generatePDF();
            }
        }
    }

    public display(): void {
        this.dialogOpened = true;
        this.messageonInput = " ";
    }

    public close(answer: string): void {
        this.dialogOpened = false;
        if (answer === "print") {
            this.generatePDF();
        }
    }

    goToSerializationPage() {
        this.router
            .navigateByUrl("/", { skipLocationChange: true })
            .then(() => {
                this.router.navigate([
                    "/serialization-numbers/" + this.pilotProductID,
                ]);
            });
    }

    onChangeTestDays() {
        if (this.infoModule.targetTestDays < 0)
            this.infoModule.targetTestDays = 0;
        if (this.infoModule.idleTestDay < 0) this.infoModule.idleTestDay = 0;
        if (this.infoModule.postTestDays < 0) this.infoModule.postTestDays = 0;

        const tt =
            this.infoModule.targetTestDays !== undefined
                ? this.infoModule.targetTestDays
                : 0;
        const idtt =
            this.infoModule.idleTestDay !== undefined
                ? this.infoModule.idleTestDay
                : 0;
        const ptd =
            this.infoModule.postTestDays !== undefined
                ? this.infoModule.postTestDays
                : 0;

        const testStartDate =
            this.infoModule.actualTestStartManual !== null
                ? this.infoModule.actualTestStartManual
                : this.infoModule.actualTestStart;

        if (testStartDate !== null) {
            this.infoModule.plannedTestComplete = new Date(
                moment(testStartDate, "DD-MM-YYYY")
                    .add(tt + idtt, "days")
                    .toDate()
            );
        } else if (this.infoModule.plannedTestStart !== null) {
            this.infoModule.plannedTestComplete = new Date(
                moment(this.infoModule.plannedTestStart, "DD-MM-YYYY")
                    .add(tt + idtt, "days")
                    .toDate()
            );
        }

        const testCompleteDate =
            this.infoModule.actualTestCompleteManual !== null
                ? this.infoModule.actualTestCompleteManual
                : this.infoModule.actualTestComplete;

        if (testCompleteDate !== null) {
            this.infoModule.plannedManufacturingComplete = new Date(
                moment(testCompleteDate, "DD-MM-YYYY").add(ptd, "days").toDate()
            );
        } else if (this.infoModule.plannedTestComplete !== null) {
            this.infoModule.plannedManufacturingComplete = new Date(
                moment(this.infoModule.plannedTestComplete, "DD-MM-YYYY")
                    .add(ptd, "days")
                    .toDate()
            );
        }
    }
}
