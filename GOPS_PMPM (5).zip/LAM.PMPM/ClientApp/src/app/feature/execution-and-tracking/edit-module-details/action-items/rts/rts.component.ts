import {
    Component,
    Input,
    OnChanges,
    OnInit,
    SimpleChanges,
    ViewChild,
    ViewContainerRef,
    ViewEncapsulation,
} from "@angular/core";
import { Router } from "@angular/router";
import { Plant } from "../../../../../core/model/user.model";
import { DataServiceEandTService } from "../../../data-service-eand-t.service";
import { DomSanitizer } from "@angular/platform-browser";
import { ModuleSummary } from "../../../Models/ModuleSummary";
import {
    CompositeFilterDescriptor,
    distinct,
    filterBy,
} from "@progress/kendo-data-query";
import { OBCView } from "../../../Models/obc.model";
import { process } from "@progress/kendo-data-query";
import { NotificationService } from "@progress/kendo-angular-notification";

@Component({
    selector: "pmpm-rts",
    templateUrl: "./rts.component.html",
    styleUrls: ["./rts.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class RTSComponent implements OnInit, OnChanges {
    @Input() pilotProductId: number;
    @Input() site: Plant;

    public gridDataForRTSOpen: OBCView[] = [];
    public gridDataForRTSComplete: OBCView[] = [];

    public tempGridDataForRTSOpen: OBCView[] = [];
    public tempGridDataForRTSComplete: OBCView[] = [];

    public loadingTableForOpen = true;
    public loadingTableForComplete = true;
    public moduleInfo: ModuleSummary = null;

    public filterRTSOpen: CompositeFilterDescriptor;
    public filterRTSComplete: CompositeFilterDescriptor;

    public optionsState = [
        "",
        "Not Started",
        "In Progress",
        "Removed",
        "Awaiting Lead Approval",
        "In Decon",
        "Ready for Disposition",
        "Scrapped",
        "Returned",
        "Bulk",
        "Installed",
        "Variance is an Error",
    ];
    @ViewChild("container", { read: ViewContainerRef })
    public container: ViewContainerRef;

    constructor(
        private service: DataServiceEandTService,
        private router: Router,
        private sanitizer: DomSanitizer,
        private notificationService: NotificationService
    ) {}

    ngOnInit() {}
    ngOnChanges(changes: SimpleChanges) {
        if (
            changes["pilotProductId"] &&
            changes["pilotProductId"] !== null &&
            changes["pilotProductId"].currentValue
        ) {
            this.pilotProductId = changes["pilotProductId"].currentValue;
        }
        if (
            changes["site"] &&
            changes["site"] !== null &&
            changes["site"].currentValue
        ) {
            this.site = changes["site"].currentValue;
        }
        if (this.site !== undefined && this.pilotProductId !== undefined) {
            this.service
                .getModuleSummaryByID(+this.pilotProductId)
                .toPromise()
                .then((data) => {
                    if (data && data.length > 0) {
                        this.moduleInfo = data.filter(
                            (item) =>
                                +item.ModuleInfo.PilotProductID ===
                                +this.pilotProductId
                        )[0];
                        this.LoadDataForTables();
                    }
                });
        }
    }

    private LoadDataForTables() {
        if (
            this.site?.plantName === "Fremont" &&
            this.moduleInfo?.ModuleInfo?.PilotSerialNumber !== null
        ) {
            this.getRTSDetail(this.moduleInfo?.ModuleInfo?.PilotSerialNumber);
        } else if (
            this.site?.plantName !== "Fremont" &&
            this.moduleInfo?.ModuleInfo?.BEN !== null
        ) {
            this.getRTSDetail(this.moduleInfo?.ModuleInfo?.BEN);
        } else {
            this.loadingTableForOpen = false;
            this.loadingTableForComplete = false;
        }
    }

    getRTSDetail(ben: string) {
        this.gridDataForRTSOpen = [];
        this.gridDataForRTSComplete = [];
        this.tempGridDataForRTSOpen = [];
        this.tempGridDataForRTSComplete = [];
        this.service.GetRTSDetails("open", ben).subscribe((res) => {
            if (res && res.length > 0) {
                this.gridDataForRTSOpen = res;
                this.tempGridDataForRTSOpen = JSON.parse(
                    JSON.stringify(this.gridDataForRTSOpen)
                );
            }
            this.loadingTableForOpen = false;
        });
        this.service.GetRTSDetails("completed", ben).subscribe((res) => {
            if (res && res.length > 0) {
                this.gridDataForRTSComplete = res;
                this.tempGridDataForRTSComplete = JSON.parse(
                    JSON.stringify(this.gridDataForRTSComplete)
                );
            }
            this.loadingTableForComplete = false;
        });
    }

    convertJSONString(type: string) {
        return this.sanitizer.bypassSecurityTrustHtml(
            JSON.parse(JSON.stringify(type))
        );
    }

    onClickOfLink(id: number) {
        const url =
            "https://lamresearch.quickbase.com/db/bprt8ii2f?a=er&rid=" + id;
        window.open(url, "_blank");
    }

    filterChangeOpenRTS(filter: CompositeFilterDescriptor): void {
        this.filterRTSOpen = filter;
        this.gridDataForRTSOpen = filterBy(this.tempGridDataForRTSOpen, filter);
    }

    filterChangeCompleteRTS(filter: CompositeFilterDescriptor): void {
        this.filterRTSComplete = filter;
        this.gridDataForRTSComplete = filterBy(
            this.tempGridDataForRTSComplete,
            filter
        );
    }

    public distinctPrimitiveOpenRTS(fieldName: string): any {
        let data: any = distinct(this.tempGridDataForRTSOpen, fieldName).map(
            (item) => item[fieldName]
        );
        data = data.flatMap((f) => (f ? [f] : []));
        data.sort(function (a, b) {
            const textA = a?.toUpperCase();
            const textB = b?.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
        });
        return data;
    }
    public distinctPrimitiveCompletRTS(fieldName: string): any {
        let data: any = distinct(
            this.tempGridDataForRTSComplete,
            fieldName
        ).map((item) => item[fieldName]);
        data = data.flatMap((f) => (f ? [f] : []));
        data.sort(function (a, b) {
            const textA = a?.toUpperCase();
            const textB = b?.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
        });
        return data;
    }

    onSearchFilter(value) {
        this.onSearchOpenRTS(value);
        this.onSearchCompleteRTS(value);
    }
    onSearchOpenRTS(value: string) {
        this.gridDataForRTSOpen = process(this.tempGridDataForRTSOpen, {
            filter: {
                logic: "or",
                filters: [
                    {
                        field: "id",
                        operator: "contains",
                        value: value,
                    },
                    {
                        field: "partNumber",
                        operator: "contains",
                        value: value,
                    },
                    {
                        field: "materialDescription",
                        operator: "contains",
                        value: value,
                    },
                ],
            },
        }).data;
    }
    onSearchCompleteRTS(value: string) {
        this.gridDataForRTSComplete = process(this.tempGridDataForRTSComplete, {
            filter: {
                logic: "or",
                filters: [
                    {
                        field: "id",
                        operator: "contains",
                        value: value,
                    },
                    {
                        field: "partNumber",
                        operator: "contains",
                        value: value,
                    },
                    {
                        field: "materialDescription",
                        operator: "contains",
                        value: value,
                    },
                ],
            },
        }).data;
    }

    onChangeState(idRow: any, event: any) {
        const newVal = event;
        this.service
            .UpdateRTSStatus({ Status: newVal, Id: idRow })
            .toPromise()
            .then(() => {
                this.LoadDataForTables();
                this.notificationService.show({
                    content: "Updated " + idRow,
                    appendTo: this.container,
                    position: { horizontal: "right", vertical: "top" },
                    type: { style: "success", icon: true },
                });
            })
            .catch((err) => {
                this.notificationService.show({
                    content: "Error",
                    appendTo: this.container,
                    position: { horizontal: "right", vertical: "top" },
                    type: { style: "error", icon: true },
                });
            });
    }
}
