import {Component, Input, OnInit} from '@angular/core';
import {DataServiceEandTService} from '../../data-service-eand-t.service';
import {ModuleVFD} from '../../Models/workSummaryGrid';

@Component({
  selector: 'pmpm-safepermit',
  templateUrl: './safepermit.component.html',
  styleUrls: ['./safepermit.component.css']
})
export class SAFEPermitComponent implements OnInit {

  constructor(private service: DataServiceEandTService) { }
  @Input() pilotProductID: number;
  @Input() ben: string;


  public gridData: ModuleVFD[] = [];
  ngOnInit(): void {
    this.service.getModuleVFDSummary(this.pilotProductID).toPromise().then(data => {
      this.gridData = data;
      }
    );

  }

  redirect(bayName: string  ) {
    const url = `https://vfd.fremont.lamrc.net/safe/?edit=true&bayname=${bayName}&ben=${this.ben}`;
    window.open(url, '_blank');
  }

  openGeneralSAFE() {
    const url = 'https://lamresearch.sharepoint.com/:p:/r/sites/PilotMfg/Shared Documents/Pilot Training Center/2000 - Quickbase/2024 - Pilot SAFE Permit Training FD 2022.pptx?d=w42871291c1f945809dde29bed7347c34&csf=1&web=1&e=Wwf3Rh';
    window.open(url, '_blank');
  }
}
