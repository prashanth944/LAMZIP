import {
    Component,
    EventEmitter,
    Input,
    OnInit,
    Output,
    ViewChild,
    ViewContainerRef,
    ViewEncapsulation,
} from "@angular/core";
import { AppStoreService } from "../../../../core/app-store.service";
import { uiScreen } from "../../../../core/model/common.constant";
import { FormBuilder, FormGroup } from "@angular/forms";
import { State } from "@progress/kendo-data-query";
import { Item } from "../../../model/item";
import { DataServiceEandTService } from "../../data-service-eand-t.service";
import { EditService } from "../../../service/edit.service";
import {
    EditModuleAdminVFDAssignmentTable,
    EditModuleAdminViewModelStandard,
    VFDRelease,
} from "../../Models/ModuleSummary";
import { Plant } from "../../../../core/model/user.model";
import { NotificationService } from "@progress/kendo-angular-notification";
import { ModuleVFD } from "../../Models/workSummaryGrid";

@Component({
    selector: "pmpm-edit-module-admin",
    templateUrl: "./edit-module-admin.component.html",
    styleUrls: ["./edit-module-admin.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class EditModuleAdminComponent implements OnInit {
    @ViewChild("appendTo", { read: ViewContainerRef })
    public appendTo: ViewContainerRef;

    @Input() pilotProductID: number;
    @Output() isInWIP: EventEmitter<boolean> = new EventEmitter<boolean>();
    public isHidden = true;
    public buildingItem: Item[] = [
        { text: "A", value: 0 },
        { text: "B", value: 1 },
    ];
    public gridDataForRelease: EditModuleAdminVFDAssignmentTable[] = [];
    public tempGridDataForRelease: EditModuleAdminVFDAssignmentTable[] = [];
    public adminDetails: ModuleVFD[] = [];
    public tempAdminDetails: ModuleVFD[] = [];
    public gridState: State = {
        sort: [],
        skip: 0,
        take: 10,
    };
    public showRemoveFromWIPBtn = false;
    public WIPFlag: boolean = null;
    public bayNameData: string[] = [];
    public statusData: Item[] = [];
    public disableSave = true;
    public site: Plant;
    public isUserAccess = false;
    public removeWIPConfirmation = false;
    public vfdRlease: VFDRelease[] = [];

    constructor(
        private service: DataServiceEandTService,
        private formBuilder: FormBuilder,
        private editService: EditService,
        private appStoreService: AppStoreService,
        private notificationService: NotificationService
    ) {}

    ngOnInit() {
        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.EditModRemoveFromWIP)
                    .subscribe((result) => {
                        this.showRemoveFromWIPBtn = result;
                    });
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.EditModAdmin)
                    .subscribe((r) => {
                        this.isUserAccess = r;
                    });
            }
        });
        this.appStoreService.getCurrentSite().subscribe((res) => {
            this.site = res;
            this.vfdRlease = [];
            this.service
                .GetVFDReleases(this.site.plantId)
                .subscribe((release) => {
                    if (release && release.length > 0) {
                        this.vfdRlease = release;
                        this.getAdminDetails();
                    }
                });
        });
        this.service.GetVFDAssignmentBayDLL().subscribe((res) => {
            if (res && res.length > 0) {
                this.bayNameData = [""];
                res.forEach((item) => {
                    this.bayNameData.push(item.bayName);
                });
            }
        });
        this.service.GetVFDAssignmentStatusDLL().subscribe((res) => {
            if (res && res.length > 0) {
                this.statusData = [];
                this.statusData.push({ text: " ", value: null });
                res.forEach((item) => {
                    this.statusData.push({
                        text: item.masterRecordName,
                        value: item.masterRecordID,
                    });
                });
            }
        });
    }
    getAdminDetails() {
        this.service
            .GetEditModuleAdminSummary(+this.pilotProductID)
            .subscribe((res) => {
                if (res) {
                    this.WIPFlag = res.inWip;
                    this.getModuleReleases();
                    this.getVFDAssignmentTable();
                }
            });
    }

    getModuleReleases() {
        this.adminDetails = [];
        this.service
            .GetModuleReleases(+this.pilotProductID)
            .subscribe((res) => {
                if (res && res.length > 0) {
                    this.adminDetails = [];
                    this.adminDetails = res;
                    this.tempAdminDetails = JSON.parse(
                        JSON.stringify(this.adminDetails)
                    );
                } else {
                    this.vfdRlease.forEach((item) => {
                        const vfd: ModuleVFD = {
                            moduleVFDId: null,
                            pilotProductId: +this.pilotProductID,
                            vfdZoneId: item.vfdZoneId,
                            statusId: null,
                            bayName: null,
                            assignable: false,
                            numberOfDays: null,
                            vfdZoneName: item.vfdZoneName,
                            isRequired: false,
                        };
                        this.adminDetails.push(vfd);
                    });
                    this.tempAdminDetails = JSON.parse(
                        JSON.stringify(this.adminDetails)
                    );
                }
            });
    }
    getVFDAssignmentTable() {
        this.gridDataForRelease = [];
        if (this.WIPFlag) {
            this.service
                .GetVFDAssignmentTable(+this.pilotProductID)
                .subscribe((res) => {
                    if (res && res.length > 0) {
                        this.gridDataForRelease = res;
                        this.tempGridDataForRelease = JSON.parse(
                            JSON.stringify(this.gridDataForRelease)
                        );
                    }
                });
        }
    }
    public onStateChange(state: State) {
        this.gridState = state;
    }
    public cellClickHandler({
        sender,
        rowIndex,
        columnIndex,
        dataItem,
        isEdited,
    }) {
        if (!isEdited) {
            sender.editCell(
                rowIndex,
                columnIndex,
                this.createFormGroup(dataItem)
            );
        }
    }
    public createFormGroup(dataItem: any): FormGroup {
        return this.formBuilder.group({
            PilotProductID: dataItem.PilotProductID,
            ZoneID: dataItem.ZoneID,
            ZoneName: dataItem.ZoneName,
            StatusID: dataItem.StatusID,
            Status: dataItem.Status,
            BayName: dataItem.BayName,
            Assignable: dataItem.Assignable,
            IsAssignable: dataItem.IsAssignable,
        });
    }

    public cancelHandler({ sender, rowIndex }) {
        sender.closeRow(rowIndex);
    }

    public saveHandler({ sender, formGroup, rowIndex }) {
        if (formGroup.valid) {
            this.editService.create(formGroup.value);
            sender.closeRow(rowIndex);
        }
    }
    public saveChanges(grid: any): void {
        grid.closeCell();
        grid.cancelCell();
        const updatedData: any[] = this.editService.saveChanges();
        const request: EditModuleAdminVFDAssignmentTable[] = [];
        if (updatedData && updatedData.length > 0) {
            updatedData.forEach((item) => {
                if (item && item.length > 0) {
                    item.forEach((req) => {
                        request.push(req);
                    });
                }
            });
        }
        this.service
            .UpdateEditModAdminVFDAssignment(request)
            .subscribe((res) => {});
    }

    public cancelChanges(grid: any): void {
        this.editService.cancelChanges();
        this.gridDataForRelease = JSON.parse(
            JSON.stringify(this.tempGridDataForRelease)
        );
    }

    removeFromWIP() {
        const dataToSend = {
            pilotProductID: +this.pilotProductID,
            wipFlat: false,
        };
        this.service
            .SetModuleWIPFlat(dataToSend)
            .toPromise()
            .then(() => {
                this.WIPFlag = false;
                this.getVFDAssignmentTable();
                this.removeWIPConfirmation = false;
                this.showSuccess("Removed from WIP");
                this.isInWIP.emit(true);
            });
    }

    public showSuccess(msg: string): void {
        this.notificationService.show({
            appendTo: this.appendTo,
            content: msg,
            position: { horizontal: "left", vertical: "bottom" },
            animation: { type: "fade", duration: 600 },
            type: { style: "success", icon: true },
        });
    }

    onStatusChange(value: Item, dataItem: EditModuleAdminVFDAssignmentTable) {
        dataItem.status = value.text;
        dataItem.vfdStatusID = value.value;
        this.editService.update(dataItem, "VFD Assignment Table");
    }

    onBayNameChange(
        value: string,
        dataItem: EditModuleAdminVFDAssignmentTable
    ) {
        dataItem.bayName = value;
        this.editService.update(dataItem, "VFD Assignment Table");
    }

    onChangeRelease(admin: ModuleVFD) {
        admin.assignable = !admin.assignable;
        this.disableSave = false;
    }

    onSaveEditModAdmin() {
        const request = new EditModuleAdminViewModelStandard();
        request.pilotProductId = +this.pilotProductID;
        request.moduleVFDs = this.adminDetails;
        this.service.UpdateEditModAdmin(request).subscribe((res) => {
            this.disableSave = true;
            this.getAdminDetails();
        });
    }

    onCancelEditModAdmin() {
        this.disableSave = true;
        this.adminDetails = JSON.parse(JSON.stringify(this.tempAdminDetails));
    }

    openRemoveWIPConfirmation() {
        this.removeWIPConfirmation = true;
    }
    onCloseRemoveWIPConfirmation() {
        this.removeWIPConfirmation = false;
    }
}
