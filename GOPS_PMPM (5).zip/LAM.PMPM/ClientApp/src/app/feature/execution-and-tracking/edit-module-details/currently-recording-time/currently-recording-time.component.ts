import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { Router } from "@angular/router";
import { AppStoreService } from "../../../../core/app-store.service";
import { Plant } from "../../../../core/model/user.model";
import { DataServiceEandTService } from "../../data-service-eand-t.service";

@Component({
    selector: "pmpm-currently-recording-time",
    templateUrl: "./currently-recording-time.component.html",
    styleUrls: ["./currently-recording-time.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class CurrentlyRecordingTimeComponent implements OnInit {
    public gridData = [];
    public userData: any;
    public site: Plant;
    public minutes: number;
    public showDialogbox = false;
    public userId: number;

    constructor(
        private service: DataServiceEandTService,
        private appStoreService: AppStoreService,
        private router: Router
    ) {}

    ngOnInit(): void {
        this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site) {
                this.site = {
                    plantName: site.plantName,
                    plantId: site.plantId,
                };
                this.getHomeSupLaborHours();
            }
        });

        this.appStoreService.getLoggedInUser().subscribe((user) => {
            this.appStoreService.getUserDetails(user.mail).subscribe((res) => {
                if (res && res.username.length > 0) {
                    this.userId = res?.userId;
                }
            });
        });
    }

    getHomeSupLaborHours() {
        this.service
            .getHomeSupLaborHours(this.site.plantId)
            .subscribe((res) => {
                if (res) {
                    this.gridData = res;
                }
            });
    }

    openDialogbox(userData) {
        this.userData = userData;
        this.showDialogbox = true;
    }

    removeUser(userData) {
        const startTime = new Date(this.userData.startTimestamp).getTime();
        const expectedMinutes = this.minutes * 60 * 1000;
        const endTimeStamp = new Date(startTime + expectedMinutes);
        this.userData.endTime = new Date(
            endTimeStamp.getTime() - new Date().getTimezoneOffset() * 60000
        );
        this.userData.userCancelledBy = this.userId;
        this.userData.isUserCancelled = true;
        //End the operation
        this.service
            .updateLogWorkRecord(this.userData, this.userData.workRecordID)
            .subscribe((res) => {
                if (res && res["value"] === "Updated Successfully") {
                    this.getHomeSupLaborHours();
                } else {
                    
                }
            });
        this.showDialogbox = false;
    }

    onCancel() {
        this.showDialogbox = false;
        this.minutes = null;
    }

    routeToEditModule(pilotProductID: number) {
        this.router.navigate(["/edit-module/" + pilotProductID + "/" + 2]);
    }
}
