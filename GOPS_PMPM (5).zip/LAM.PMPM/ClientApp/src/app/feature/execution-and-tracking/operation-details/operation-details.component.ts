import {
    ChangeDetectorRef,
    Component,
    OnInit,
    ViewChild,
    ViewContainerRef,
    ViewEncapsulation,
} from "@angular/core";
import { FormBuilder } from "@angular/forms";
import { ActivatedRoute, Router, RouterStateSnapshot } from "@angular/router";
import { RowClassArgs } from "@progress/kendo-angular-grid";
import { NotificationService } from "@progress/kendo-angular-notification";
import * as moment from "moment";
import { Observable } from "rxjs";
import { AppStoreService } from "../../../core/app-store.service";
import { uiScreen } from "../../../core/model/common.constant";
import { Plant, UserModel } from "../../../core/model/user.model";
import { EditService } from "../../service/edit.service";
import { DataServiceEandTService } from "../data-service-eand-t.service";
import { InterruptionsInfo } from "../Models/interruptionsSummary";
import { OperationLogDetailGeneral, StepDetail } from "../Models/ModuleSummary";

@Component({
    selector: "app-operation-details",
    templateUrl: "./operation-details.component.html",
    styleUrls: ["./operation-details.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class OperationDetailsComponent implements OnInit {
    @ViewChild("mainContainer", { read: ViewContainerRef })
    public mainContainer: ViewContainerRef;
    public workSummaryGridData: any[] = [];
    public workSummaryGridDataBK: any[] = [];
    public interruptionGridData: InterruptionsInfo[] = [];
    public pilotProductId: number;
    public operationId: number;
    public editMode = false;
    public loadTable = false;
    public userId: number;
    public userName: string;
    public site: Plant;
    public canEditWorkRecord = false;
    public logDetails: OperationLogDetailGeneral;
    notesDataItem: any;
    addOpened = false;
    notesValue = "";
    userDetails: UserModel;
    disableSave = true;
    isChanged = false;
    redirectUrl = "";
    disableAddBtn = true;

    constructor(
        private changeDetector: ChangeDetectorRef,
        private appStoreService: AppStoreService,
        private editService: EditService,
        private formBuilder: FormBuilder,
        private router: Router,
        private route: ActivatedRoute,
        private service: DataServiceEandTService,
        private notificationService: NotificationService
    ) {}

    ngOnInit(): void {
        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                // Edit Work Record access
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.EditWorkRecord)
                    .subscribe((result) => {
                        this.canEditWorkRecord = result;
                    });
            }
        });

        this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site) {
                this.site = {
                    plantName: site.plantName,
                    plantId: site.plantId,
                };
            }
        });

        this.route.params.subscribe((param) => {
            this.pilotProductId = param.id;
            this.operationId = param.operationId;
            this.getOperationLogDetails();
            this.getStepDetails();
            this.getInterruptionDetails();
            this.getUserInfo();
        });
    }
    getUserInfo() {
        this.appStoreService.getLoggedInUser().subscribe((user) => {
            this.appStoreService.getUserDetails(user.mail).subscribe((res) => {
                this.userDetails = res;
                this.userId = res?.userId;
                this.userName = res?.firstName + " " + res?.lastName;
            });
        });
    }

    getOperationLogDetails() {
        this.service
            .getOperationLogDetailsGeneral(
                this.pilotProductId,
                this.operationId
            )
            .subscribe((res) => {
                if (res) {
                    this.logDetails = res;
                    this.changeDetector.detectChanges();
                }
            });
    }

    castDateFormat(date: string) {
        return date !== null
            ? moment(date).format("MM-DD-yyyy hh:mm A").toString()
            : "";
    }

    castMinFormat(minutes: number) {
        if (minutes !== null) {
            const numdays = Math.floor(minutes / 1440);
            const numhours = Math.floor((minutes % 1440) / 60);
            const numminutes = Math.floor((minutes % 1440) % 60);
            let output = "";
            output = output + (numdays > 0 ? numdays + " day(s) " : "");
            output = output + (numhours > 0 ? numhours + " hours " : "");
            output = output + numminutes + " minutes ";

            return output;
        } else {
            return "";
        }
    }

    getStepDetails() {
        this.workSummaryGridData = [];
        this.workSummaryGridDataBK = [];
        this.loadTable = true;
        this.service
            .getstepsdetails(this.pilotProductId, this.operationId)
            .subscribe((res) => {
                if (res && res.length > 0) {
                    res.forEach((val) => {
                        const gridSumm = {
                            StepRecordId: val.stepRecordId,
                            Id: val.stepNo,
                            Complete: val.completed,
                            Skipped: val.skipped,
                            ExcludedOption: val.excluded,
                            Reworked: val.reworked,
                            reworkedBy: val.reworkedBy,
                            reworkedById: val.reworkedById,
                            technicianNotes: this.getTechNotesInDifferentLines(
                                val.technicianNotes
                            ),

                            completedBy: val.completedBy,
                            completedById: val.completedById,
                            excludedById: val.excludedById,
                            skippedById: val.skippedById,
                            operationId: val.operationId,
                            pilotProductId: val.pilotProductId,
                            numberofSteps: val.numberofSteps,
                            cycleTimeMinutes: val.cycleTimeMinutes,
                            edited: false,
                        };
                        this.workSummaryGridData.push(gridSumm);
                    });
                }
                this.changeDetector.detectChanges();
                this.loadTable = false;
            });
    }

    getInterruptionDetails() {
        this.service
            .getInterruptsByOperations(this.pilotProductId, this.operationId)
            .subscribe((res2) => {
                if (res2) {
                    this.interruptionGridData = res2;
                    this.changeDetector.detectChanges();
                }
            });
    }
    startEditMode() {
        this.workSummaryGridDataBK = [];
        this.workSummaryGridData.forEach((v) =>
            this.workSummaryGridDataBK.push(Object.assign({}, v))
      );
        this.disableSave = true;
        this.editMode = true;
    }
    saveChanges() {
        if (this.workSummaryGridData.some((x) => x.edited === true)) {
            const updateWorkSummaryObj = [];
            this.workSummaryGridData
                .filter((x) => x.edited === true)
                .forEach((val) => {
                    const updWS: any = {
                        stepRecordId: val.StepRecordId,
                        stepNo: val.Id,
                        completed: val.Complete,
                        skipped: val.Skipped,
                        excluded: val.ExcludedOption,
                        reworked: val.Reworked,

                        completedBy: val.completedBy,
                        completedById: val.completedById,
                        reworkedById: val.reworkedById,
                        skippedById: val.skippedById,
                        excludedById: val.excludedById,

                        technicianNotes: val.technicianNotes,

                        numberofSteps: val.numberofSteps,
                        operationId: val.operationId,
                        cycleTimeMinutes: val.cycleTimeMinutes,
                        pilotProductId: val.pilotProductId,
                    };
                    updateWorkSummaryObj.push(updWS);
                });
            this.service.updateallsteprecord(updateWorkSummaryObj).subscribe(
                (res) => {
                    if (res) {
                        this.notificationService.show({
                            content: "Work record saved",
                            appendTo: this.mainContainer,
                            cssClass: "button-notification",
                            animation: { type: "slide", duration: 400 },
                            position: { horizontal: "right", vertical: "top" },
                            type: { style: "success", icon: true },
                            hideAfter: 1500,
                        });
                        this.editMode = false;
                        this.getStepDetails();
                    }
                },
                (err) => {
                    this.notificationService.show({
                        content: "Error on the Update, Update Failed!",
                        appendTo: this.mainContainer,
                        cssClass: "button-notification",
                        animation: { type: "slide", duration: 400 },
                        position: { horizontal: "right", vertical: "top" },
                        type: { style: "error", icon: true },
                        hideAfter: 2500,
                    });
                }
            );
        } else {
            this.editMode = false;
            this.notificationService.show({
                content: "No Change Detected !",
                appendTo: this.mainContainer,
                cssClass: "button-notification",
                animation: { type: "fade", duration: 800 },
                position: { horizontal: "right", vertical: "top" },
                type: { style: "success", icon: true },
                hideAfter: 1500,
            });
        }
    }
    cancelChanges() {
        this.editMode = false;
        this.workSummaryGridData = [...this.workSummaryGridDataBK];
    }

    rowCallback(context: RowClassArgs) {
        const isEdited = context.dataItem.edited;
        return {
            wasTouch: isEdited,
        };
    }

    changeState(dataItem: any, newState: string) {
        dataItem.edited = true;
        if (newState === "Complete") {
            dataItem.Skipped = false;
            dataItem.ExcludedOption = false;
            dataItem.completedBy = null; //Task 41813: Leave name blank if user edit steps
            dataItem.completedById = null;
        } else if (newState === "Skipped") {
            dataItem.Complete = false;
            dataItem.ExcludedOption = false;
            dataItem.completedBy = null;
            dataItem.skippedById = this.userId;
        } else if (newState === "ExcludedOption") {
            dataItem.Complete = false;
            dataItem.Skipped = false;
            dataItem.completedBy = null;
            dataItem.excludedById = this.userId;
        }
        this.disableSave = this.disableSaveBtn();
        this.openAddNotes(dataItem);
    }

    changeReWorked(dataItem: any) {
        dataItem.reworkedBy = null; //Task 41813: Leave name blank if user edit steps
        dataItem.reworkedById = null;
        dataItem.edited = true;
        this.openAddNotes(dataItem);
    }

    openAddNotes(dataItem: StepDetail) {
        this.notesDataItem = dataItem;
        this.addOpened = true;
    }

    closeAddNotes() {
        this.notesValue = "";
        this.addOpened = false;
        this.disableAddBtn = true;
        this.disableSave = true;
    }

    getTechNotesInDifferentLines(data) {
        let newNotes = "";
        if (data !== null) {
            const notesArr = data.split("|");
            notesArr.forEach((val) => {
                if (val.trim() !== "") {
                    newNotes = newNotes + val.trim() + "\n";
                }
            });
        }
        return newNotes;
    }

    onAddNote() {
        this.addOpened = false;
        const newNote =
            "[" +
            moment(new Date()).format("MM-DD-yyyy hh:mm A").toString() +
            ", " +
            this.userDetails.username +
            "]: " +
            this.notesValue +
            "\n";
        this.notesDataItem.technicianNotes =
            this.notesDataItem.technicianNotes !== null
                ? this.notesDataItem.technicianNotes + newNote
                : newNote;
        this.notesDataItem.edited = true;
        this.notesValue = "";
        this.editService.update(this.notesDataItem, "Step Details");
        this.editService.saveChanges();
        if (this.editMode) {
            this.disableSave = this.disableSaveBtn();
        } else {
            this.workSummaryGridDataBK = [];
            this.workSummaryGridData.forEach((v) =>
                this.workSummaryGridDataBK.push(Object.assign({}, v))
            );
            this.saveChanges();
        }
        this.disableAddBtn = true;
    }

    // to check where we need it
    canDeactivate(
        nextState: RouterStateSnapshot
    ): Observable<boolean> | Promise<boolean> | boolean {
        if (this.editMode) {
            this.isChanged = true;
            this.redirectUrl = nextState.url;
            this.changeDetector.detectChanges();
            return false;
        } else {
            return true;
        }
    }

    onOKClick() {
        this.editMode = false;
        this.isChanged = false;
        if (this.redirectUrl !== "") {
            this.router.navigate([this.redirectUrl]);
            this.redirectUrl = "";
        }
    }

    onReturnToModuleClick() {
        this.router.navigate([
            "/edit-module/" + this.pilotProductId + "/" + "2",
        ]);
    }

    disableSaveBtn() {
        if (
            this.workSummaryGridData.filter(
                (x) => x.edited === true && x.technicianNotes.length === 0
            ).length > 0
        )
            return true;
        else return false;
    }

    onChange(notesValue) {
        this.disableAddBtn = notesValue.length === 0 ? true : false;
    }
}
