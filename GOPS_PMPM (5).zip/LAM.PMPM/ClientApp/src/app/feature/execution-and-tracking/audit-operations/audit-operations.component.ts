import { HttpClient } from "@angular/common/http";
import {
    ChangeDetectionStrategy,
    ChangeDetectorRef,
    Component,
    OnInit,
    ViewChild,
    ViewContainerRef,
    ViewEncapsulation,
} from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { interval, Subject } from "rxjs";
import { environment } from "../../../../environments/environment.dev_server";
import { AppStoreService } from "../../../core/app-store.service";
import { uiScreen } from "../../../core/model/common.constant";
import { Plant, UserModel } from "../../../core/model/user.model";
import { DataServiceEandTService } from "../data-service-eand-t.service";
import { Category, Cause } from "../Models/audit.model";
import {
    InterruptionCategory,
    InterruptionModel,
    InterruptionsSummary,
} from "../Models/interruptionsSummary";
import {
    OperationLogDetail,
    StandardTimeExceptionViewModel,
} from "../Models/ModuleSummary";
import { NotificationService } from "@progress/kendo-angular-notification";

export interface Entry {
    created: Date;
    id: string;
}
export interface TimeSpan {
    hours: number;
    minutes: number;
    seconds: number;
}
declare let require: any;

@Component({
    selector: "pmpm-audit-operations",
    templateUrl: "./audit-operations.component.html",
    styleUrls: ["./audit-operations.component.css"],
    encapsulation: ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AuditOperationsComponent implements OnInit {
    @ViewChild("appendTo", { read: ViewContainerRef })
    public appendTo: ViewContainerRef;

    //page access
    public hasEditAccess = false;

    site: Plant;
    selectedTab = 0;
    entry: Entry;
    interruption: Entry;
    private destroyed$ = new Subject();
    public pilotProductId: number;
    public operationId: number;
    public zoneId: number;
    public user: UserModel;
    public operationLogDetail: OperationLogDetail;
    public workRecordId: number;
    public tempOperationLogDetail: OperationLogDetail;
    public soeLink = "";
    public standardTime = "";

    //Interruptions
    public hours = 0;
    public minutes = 0;
    public seconds = 0;
    public interruptionHours = 0;
    public interruptionMinutes = 0;
    public interruptionSeconds = 0;
    public tempHours = 0;
    public tempMinutes = 0;
    public tempSeconds = 0;
    public gridDataForInterruption: InterruptionsSummary[] = [];
    public interruptionNotes = "";
    public interruptionCategory: InterruptionCategory[] = [];
    public categoryIndex: number;
    public selectedCategoryId: number;
    public selectedCategoryName: string;
    public standardTimeExceptionCategory: StandardTimeExceptionViewModel[] = [];
    public STECategoryId: number;
    public selectedSTECategoryId: number;
    public selectedSTECategoryName: string;
    public interrupted = false;
    public fillInterruptionFormError = true;
    public missingInterruptionNote = false;
    public interruptionStartTime: any = null;
    public interruptionEndTime: any = null;
    public totalInterruptionTime: any = null;
    public counter = 0;
    public totalWorkingTimeInMinutes: number;

    //Add Audit Item
    public showAddPopup = false;
    public causeDDL: Cause[] = [];
    public categoryDDL: Category[] = [];
    public selectedCause: Cause = null;
    public selectedAuditCategory: Category = null;
    public description: string = null;
    public beforeFiles: any;
    public afterFiles: any;
    public after: any;
    public before: any;
    readonly apiUrl = `${environment.apiUrl}`;
    public reload = true;
    public extensions: string[] = ["pptm", "pptx", "pdf"];
    public selectedExtension = "";

    //Grid
    public gridData: any;
    public refreshGrid = false;

    //Timer
    public isTimerStarted: boolean;

    constructor(
        private changeDetector: ChangeDetectorRef,
        private router: Router,
        private route: ActivatedRoute,
        private service: DataServiceEandTService,
        private appStore: AppStoreService,
        private http: HttpClient,
        private notificationService: NotificationService
    ) {}

    ngOnInit(): void {
        this.appStore.getCurrentSite().subscribe((site) => {
            if (site) {
                this.site = {
                    plantName: site.plantName,
                    plantId: site.plantId,
                };
            }
        });

        this.appStore.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                this.appStore
                    .checkUserAccessRight(res, uiScreen.AuditOperation)
                    .subscribe((result) => {
                        this.hasEditAccess = result;
                    });
            }
        });

        this.route.params.subscribe((param) => {
            this.pilotProductId = param.id;
            this.operationId = param.operationId;
            this.zoneId = param.zoneId;
            if (
                this.pilotProductId != undefined &&
                this.operationId != undefined
            ) {
                this.getoperationlogdetails();
            }
            this.getInterruptionCategory();
            this.getStandardTimeExceptionCategory();
            this.selectedTab = param.tabIndexId;
        });

        interval(1000).subscribe(() => {
            this.changeDetector.detectChanges();
        });
    }

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    onTabSelect(e) {
        this.selectedTab = e.index;
        if (e.index === 1) {
            this.getInterruption();
        }
    }

    getoperationlogdetails() {
        this.appStore.getLoggedInUser().subscribe((res) => {
            this.appStore.getUserDetails(res.mail).subscribe((user) => {
                if (user && user.username?.length > 0) {
                    this.user = user;
                    const isRework = false;
                    this.service
                        .getoperationlogdetails(
                            this.pilotProductId,
                            this.operationId,
                            user.userId,
                            isRework
                        )
                        .subscribe((details) => {
                            this.operationLogDetail = details;
                            this.workRecordId =
                                this.operationLogDetail.workRecordId;
                            this.tempOperationLogDetail = details;
                            this.soeLink = details.soeLink;
                            if (details.totalInterruptionSeconds > 0) {
                                const startTime =
                                    (new Date().getTime() -
                                        new Date(details.startTime).getTime()) /
                                    1000;
                                const newStartTime =
                                    startTime -
                                    details.totalInterruptionSeconds;
                                const time = new Date(
                                    Date.now() - newStartTime * 1000
                                );
                                this.entry = {
                                    id: "Total Working Time:",
                                    created: new Date(new Date(time).getTime()),
                                };
                            } else {
                                this.entry = {
                                    id: "Total Working Time:",
                                    created: new Date(
                                        new Date(details.startTime).getTime()
                                    ),
                                };
                            }
                            this.standardTime =
                                Math.floor(details.cycleTimeMinutes / 60) +
                                " Hours" +
                                (details.cycleTimeMinutes % 60 > 0
                                    ? ", " +
                                      (details.cycleTimeMinutes % 60) +
                                      " Minutes"
                                    : "");
                            if (details.isInterrupted) {
                                if (details.totalInterruptionSeconds > 0) {
                                    const startTime =
                                        (new Date(
                                            details.latestInterruptionTime
                                        ).getTime() -
                                            new Date(
                                                details.startTime
                                            ).getTime()) /
                                        1000;
                                    const newStartTime =
                                        startTime -
                                        details.totalInterruptionSeconds;
                                    const time = new Date(
                                        Date.now() - newStartTime * 1000
                                    );
                                    this.entry = {
                                        id: "Total Working Time:",
                                        created: new Date(
                                            new Date(time).getTime()
                                        ),
                                    };
                                } else {
                                    this.entry = {
                                        id: "Total Working Time:",
                                        created: new Date(
                                            new Date(
                                                details.startTime
                                            ).getTime()
                                        ),
                                    };
                                }
                                this.interruption = {
                                    id: "Total Working Time:",
                                    created: new Date(
                                        new Date(
                                            details.latestInterruptionTime
                                        ).getTime()
                                    ),
                                };
                                this.onInterruptionClick(true);
                            }
                        });
                }
            });
        });
    }

    goToEditModOperations() {
        this.router.navigate(["/edit-module/" + this.pilotProductId + "/" + 2]);
    }

    onOpenSOEClick() {
        this.service
            .getSOELink(
                this.site.plantId,
                +this.operationId,
                this.pilotProductId
            )
            .subscribe((res) => {
                if (res && res.url.length > 0) {
                    this.soeLink = res.url;
                    window.open(this.soeLink, "_blank");
                }
            });
    }

    onCancel() {
        const tabIndex = 0;
        this.selectedSTECategoryId = null;
        const workRecordId = this.workRecordId != null ? this.workRecordId : 0;
        this.service.logoperationdelete(workRecordId).subscribe((res) => {
            this.appStore.setOperrationLogDetails$(false);
            this.getoperationlogdetails();
            this.refreshGrid = true;
        });
        this.refreshGrid = false;
    }

    getInterruption() {
        this.gridDataForInterruption = [];
        const workRecordId = this.workRecordId != null ? this.workRecordId : 0;

        this.service.getinterrupts(workRecordId).subscribe((res) => {
            if (res && res.length > 0) {
                res.forEach((item) => {
                    if (item.interruptTime !== null)
                        this.gridDataForInterruption.push(item);
                });
            }
        });
    }

    onInterruptionClick(isExistingInterruption: boolean) {
        this.interrupted = true;
        // Total working time
        this.counter = this.counter + 1;
        this.interruptionStartTime = new Date();
        this.fillInterruptionFormError = true;
        this.selectedTab = 1;
        this.interruptionNotes = "";
        this.categoryIndex = undefined;
        this.selectedCategoryId = undefined;
        if (isExistingInterruption) {
            let totalSeconds = Math.floor(
                (new Date().getTime() - this.entry?.created?.getTime()) / 1000
            );
            this.tempHours = 0;
            this.tempMinutes = 0;
            this.tempSeconds = 0;
            if (totalSeconds >= 3600) {
                this.tempHours = Math.floor(totalSeconds / 3600);
                totalSeconds -= 3600 * this.tempHours;
            }
            if (totalSeconds >= 60) {
                this.tempMinutes = Math.floor(totalSeconds / 60);
                totalSeconds -= 60 * this.tempMinutes;
            }
            this.tempSeconds = totalSeconds;
        }
        if (!isExistingInterruption) {
            this.tempHours = this.hours;
            this.tempMinutes = this.minutes;
            this.tempSeconds = this.seconds;
            this.hours = 0;
            this.minutes = 0;
            this.seconds = 0;
            this.interruption = {
                id: "Total Working Time:",
                created: new Date(new Date().getTime()),
            };
            const request = new InterruptionModel();
            request.operationId = +this.operationId;
            request.pilotProductId = +this.pilotProductId;
            request.userId = this.user?.userId;
            request.interruptionStartTime = new Date(
                new Date().getTime() - new Date().getTimezoneOffset() * 60000
            );
            request.workRecordId = this.workRecordId;
            request.notes = "";
            this.service.startEndInterruption(request).subscribe((res) => {});
        }
        this.getInterruption();
    }

    getInterruptionTime(entry: Entry): TimeSpan {
        let totalSeconds = Math.floor(
            (new Date().getTime() - this.interruption.created.getTime()) / 1000
        );
        this.interruptionHours = 0;
        this.interruptionMinutes = 0;
        this.interruptionSeconds = 0;

        if (totalSeconds >= 3600) {
            this.interruptionHours = Math.floor(totalSeconds / 3600);
            totalSeconds -= 3600 * this.interruptionHours;
        }

        if (totalSeconds >= 60) {
            this.interruptionMinutes = Math.floor(totalSeconds / 60);
            totalSeconds -= 60 * this.interruptionMinutes;
        }

        this.interruptionSeconds = totalSeconds;

        return {
            hours: this.interruptionHours,
            minutes: this.interruptionMinutes,
            seconds: this.interruptionSeconds,
        };
    }

    onEndInterruptionClick() {
        this.interrupted = false;
        this.interruptionEndTime = new Date();
        if (this.counter == 0) {
            this.totalInterruptionTime =
                this.interruptionStartTime.getTime() -
                this.interruptionEndTime.getTime();
        } else if (this.counter > 0) {
            this.totalInterruptionTime =
                this.totalInterruptionTime +
                (this.interruptionEndTime.getTime() -
                    this.interruptionStartTime.getTime());
        }
        this.tempHours = 0;
        this.tempMinutes = 0;
        this.tempSeconds = 0;
        this.selectedTab = 0;
        this.fillInterruptionFormError = false;

        const request = new InterruptionModel();
        request.operationId = +this.operationId;
        request.pilotProductId = +this.pilotProductId;
        request.userId = this.user?.userId;
        request.interruptionEndTime = new Date(
            new Date().getTime() - new Date().getTimezoneOffset() * 60000
        );
        request.workRecordId = this.workRecordId;
        request.notes = this.interruptionNotes;
        request.interruptionCategoryId = this.selectedCategoryId;
        this.service.startEndInterruption(request).subscribe((res) => {
            if (res) this.getInterruption();
        });
    }

    getInterruptionCategory() {
        this.service.getInterruptionCategory().subscribe((res) => {
            if (res && res.length > 0) {
                this.interruptionCategory = res;
            }
        });
    }

    getStandardTimeExceptionCategory() {
        this.service.getStandardTimeExceptionCategory().subscribe((res) => {
            if (res && res.length > 0) {
                this.standardTimeExceptionCategory = res;
            }
        });
    }

    onCategoryIdSelect(category: InterruptionCategory, index: number) {
        this.fillInterruptionFormError = false;
        this.categoryIndex = index;
        this.selectedCategoryId = category.interruptionCategoryId;
        this.selectedCategoryName = category.optionName;
        if (
            category.optionName === "Other" &&
            this.interruptionNotes?.length < 1
        ) {
            this.missingInterruptionNote = true;
        } else this.missingInterruptionNote = false;
    }

    onInterruptionTecniciannotes(note) {
        if (this.selectedCategoryName === "Other") {
            if (this.interruptionNotes.length > 0) {
                this.missingInterruptionNote = false;
            } else {
                this.missingInterruptionNote = true;
            }
        } else this.missingInterruptionNote = false;
    }

    startTimer(event) {
        this.workRecordId = event.workRecordId;
        if (event.startTimer) {
            if (event.startTimestamp != null)
                this.entry = {
                    id: "Total Working Time:",
                    created: new Date(new Date(event.startTimestamp).getTime()),
                };
            else
                this.entry = {
                    id: "Total Working Time:",
                    created: new Date(new Date().getTime()),
                };

            this.isTimerStarted = true;
        } else {
            this.isTimerStarted = false;
        }
    }

    getElapsedTime(entry: Entry): TimeSpan {
        if (
            this.interruptionStartTime != undefined &&
            this.interruptionEndTime != undefined
        ) {
            const totalSeconds = Math.floor(
                (new Date().getTime() -
                    entry.created.getTime() -
                    this.totalInterruptionTime) /
                    1000
            );
            return this.getTime(totalSeconds);
        } else {
            const totalSeconds = Math.floor(
                (new Date().getTime() - entry.created.getTime()) / 1000
            );
            return this.getTime(totalSeconds);
        }
    }

    getTime(totalSeconds) {
        this.hours = 0;
        this.minutes = 0;
        this.seconds = 0;

        if (totalSeconds >= 3600) {
            this.hours = Math.floor(totalSeconds / 3600);
            totalSeconds -= 3600 * this.hours;
        }

        if (totalSeconds >= 60) {
            this.minutes = Math.floor(totalSeconds / 60);
            totalSeconds -= 60 * this.minutes;
        }

        this.seconds = totalSeconds;
        this.totalWorkingTimeInMinutes = this.hours * 60 + this.minutes;
        return {
            hours: this.hours,
            minutes: this.minutes,
            seconds: this.seconds,
        };
    }

    public showSuccess(msg: string): void {
        this.notificationService.show({
            appendTo: this.appendTo,
            content: msg,
            position: { horizontal: "left", vertical: "bottom" },
            animation: { type: "fade", duration: 600 },
            type: { style: "success", icon: true },
        });
    }
}
