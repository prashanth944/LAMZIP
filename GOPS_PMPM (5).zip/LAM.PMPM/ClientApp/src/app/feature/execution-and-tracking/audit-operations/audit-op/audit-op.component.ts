import { HttpClient } from "@angular/common/http";
import {
    Component,
    EventEmitter,
    Input,
    OnChanges,
    OnInit,
    Output,
    SimpleChanges,
    ViewChild,
    ViewContainerRef,
    ViewEncapsulation,
} from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { NotificationService } from "@progress/kendo-angular-notification";
import { environment } from "../../../../../environments/environment.dev_server";
import { AppStoreService } from "../../../../core/app-store.service";
import { uiScreen } from "../../../../core/model/common.constant";
import { UserModel } from "../../../../core/model/user.model";
import { DataServiceEandTService } from "../../data-service-eand-t.service";
import { AuditItem, Category, Cause } from "../../Models/audit.model";
import * as moment from "moment";
declare let require: any;

@Component({
    selector: "pmpm-audit-op",
    templateUrl: "./audit-op.component.html",
    styleUrls: ["./audit-op.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class AuditOpComponent implements OnInit, OnChanges {
    @Input() refreshGrid = false;

    public pilotProductId: number;
    public operationId: number;
    public zoneId: number;

    //access
    public hasDeleteAccess = false;

    //Add Audit Item
    public showAddPopup = false;
    public causeDDL: Cause[] = [];
    public categoryDDL: Category[] = [];
    public selectedCause: Cause = null;
    public selectedAuditCategory: Category = null;
    public description: string = null;
    public reload = true;
    @ViewChild("appendTo", { read: ViewContainerRef })
    public appendTo: ViewContainerRef;
    public addNewBeforeFiles: FileList;

    //Grid
    public gridData: any;

    //Start
    userDetails: UserModel;
    @Output() startTimer: EventEmitter<any> = new EventEmitter<any>();
    public canStartWork: boolean = null;
    public showDialogbox = false;
    public message = "";
    public hasEditAccess = false;

    //End
    readonly apiUrl = `${environment.apiUrl}`;
    public isValid = false;
    public auditItemId: number;
    public currentRowData: any;

    constructor(
        private router: Router,
        private route: ActivatedRoute,
        private service: DataServiceEandTService,
        private appStore: AppStoreService,
        private http: HttpClient,
        private notificationService: NotificationService
    ) {}

    ngOnInit(): void {
        this.route.params.subscribe((param) => {
            this.pilotProductId = param.id;
            this.operationId = param.operationId;
            this.zoneId = param.zoneId;
        });
        this.appStore.getLoggedInUser().subscribe((res) => {
            this.appStore.getUserDetails(res.mail).subscribe((user) => {
                if (user && user.username?.length > 0) {
                    this.userDetails = user;
                    this.getGridData();
                }
            });
        });
        this.appStore.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                this.appStore
                    .checkUserAccessRight(res, uiScreen.AuditItemsStartWork)
                    .subscribe((result) => {
                        this.hasEditAccess = result;
                    });
                this.appStore
                    .checkUserAccessRight(res, uiScreen.AuditItemsDeleteFile)
                    .subscribe((result) => {
                        this.hasDeleteAccess = result;
                    });
            }
        });
        this.getDropdowns();
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (
            changes["refreshGrid"] &&
            changes["refreshGrid"] !== null &&
            changes["refreshGrid"].currentValue
        ) {
            this.refreshGrid = changes["refreshGrid"].currentValue;
            if (this.refreshGrid) {
                this.getGridData();
            }
        }
    }

    castToDate(info: string) {
        if (info) {
            return moment(info).format("MM-DD-YY HH:mm:ss a");
        } else {
            return "";
        }
    }

    getGridData() {
        this.service
            .getAuditOpDetails(+this.pilotProductId, +this.zoneId)
            .subscribe((res) => {
                if (res) {
                    this.gridData = res;
                    if (
                        this.gridData.open.filter(
                            (x) =>
                                x.action == "End Work" &&
                                x.userId == this.userDetails?.userId
                        ).length == 0
                    ) {
                        this.canStartWork = true;
                        this.startTimer.emit({
                            startTimer: false,
                            workRecordId: this.gridData.workRecordID,
                            startTimestamp: null,
                        });
                    } else {
                        this.canStartWork = false;
                        const startTimestamp = this.gridData.open.filter(
                            (x) =>
                                x.action == "End Work" &&
                                x.userId == this.userDetails?.userId
                        )[0].startTimestamp;
                        const workRecordId = this.gridData.open.filter(
                            (x) =>
                                x.action == "End Work" &&
                                x.userId == this.userDetails?.userId
                        )[0].workRecordID;
                        // start the timer
                        this.startTimer.emit({
                            startTimer: true,
                            workRecordId: workRecordId,
                            startTimestamp: startTimestamp,
                        });
                        if (
                            this.gridData.open.filter(
                                (x) =>
                                    x.action == "End Work" &&
                                    x.userId == this.userDetails?.userId
                            )[0].afterPicture.length > 0
                        )
                            this.isValid = true;
                        else this.isValid = false;
                    }
                }
            });
    }

    onActionClick(dataItem) {
        if (dataItem.action.trim() == "Start Work") {
            // start the timer
            this.updateWorkRecord(dataItem);
        } else if (dataItem.action.trim() == "End Work") {
            // stop the timer
            this.updateLogWorkRecord(dataItem);
        }
    }

    updateWorkRecord(dataItem) {
        const workRecord = {
            UserId: this.userDetails.userId,
            PilotProductID: +this.pilotProductId,
            OperationId: +this.operationId,
            StartDateTime: new Date(
                new Date().getTime() - new Date().getTimezoneOffset() * 60000
            ),
            IsAudit: true,
            AuditItemId: dataItem.auditItemId,
        };

        this.service.updateWorkRecordData(workRecord).subscribe((res) => {
            if (res) {
                // No operation is running for the loggedIn user
                // enable Start Work
                this.canStartWork = true;
                this.appStore.setOperrationLogDetails$(true);
                this.getGridData();
            } else {
                // disable Start Work
                this.canStartWork = false;
                this.message =
                    "Different operation is already running, end that first to start another.";
                this.showDialogbox = true;
            }
        });
    }

    updateLogWorkRecord(dataItem) {
        const workRecord = {
            EndTime: new Date(
                new Date().getTime() - new Date().getTimezoneOffset() * 60000
            ),
        };

        this.service
            .updateLogWorkRecord(workRecord, dataItem.workRecordID)
            .subscribe((req) => {
                if (req) {
                    this.appStore.setOperrationLogDetails$(false);
                    this.getGridData();
                }
            });
    }

    setAuditItemId(dataItem, inputType) {
        this.currentRowData = dataItem;
        this.auditItemId = dataItem.auditItemId;
        const input = document.getElementById(inputType);
        input.click();
    }

    //Photos
    handleOpenFiles(beforeOrAfter: string, files: FileList, inputType: string) {
        let currentFiles = [];
        switch (beforeOrAfter) {
            case "a":
                currentFiles = this.currentRowData.afterPicture;
                if (files.length > 0) this.isValid = true;
                else this.isValid = false;
                break;
            case "b":
                currentFiles = this.currentRowData.beforePicture;
                break;
        }
        if (
            files != undefined &&
            files.length > 0 &&
            currentFiles != undefined
        ) {
            for (let i = 0; i < files.length; i++) {
                if (currentFiles.indexOf(files[i].name) >= 0) {
                    (<HTMLInputElement>(
                        document.getElementById(inputType)
                    )).value = "";
                    this.message = "Duplicate file name(s) are not allowed.";
                    this.showDialogbox = true;
                    break;
                }
            }
        }

        if (files != undefined && files.length > 0) {
            this.uploadFiles(this.auditItemId, beforeOrAfter, files);
        }
    }

    handleCompletedFiles(
        beforeOrAfter: string,
        files: FileList,
        inputType: string
    ) {
        if (files != undefined && files.length > 0) {
            for (let i = 0; i < files.length; i++) {
                if (
                    this.currentRowData.afterPicture != undefined &&
                    this.currentRowData.afterPicture.indexOf(files[i].name) >= 0
                ) {
                    (<HTMLInputElement>(
                        document.getElementById(inputType)
                    )).value = "";
                    this.message = "Duplicate file name(s) are not allowed.";
                    this.showDialogbox = true;
                    break;
                }
            }
        }

        if (files != undefined && files.length > 0) {
            this.uploadFiles(this.auditItemId, beforeOrAfter, files);
        }
    }

    uploadFiles(auditItemID, beforeOrAfter, files) {
        const formData: FormData = new FormData();
        for (let i = 0; i < files.length; i++) {
            formData.append("fileKey", files[i], files[i].name);
        }

        this.service
            .uploadAuditFile(auditItemID, beforeOrAfter, formData)
            .subscribe((req) => {
                if (req && req["value"] === "Updated Successfully") {
                    this.getGridData();
                }
            });
    }

    deleteFile(auditItemID, beforeOrAfter, file, inputType) {
        this.service
            .deleteAuditFile(auditItemID, beforeOrAfter, file)
            .subscribe((req) => {
                if (req && req["value"] === "Deleted Successfully") {
                    (<HTMLInputElement>(
                        document.getElementById(inputType)
                    )).value = "";
                    this.getGridData();
                } else {
                    console.log("An Error occured deleting some files.");
                }
            });
    }

    download(auditItemID, beforeOrAfter, file) {
        this.http
            .get(
                this.apiUrl +
                    "/AuditItem/downloadfile/" +
                    auditItemID +
                    "/" +
                    beforeOrAfter +
                    "/" +
                    file,
                { responseType: "blob" }
            )
            .subscribe((result: any) => {
                if (result) {
                    const blob = new Blob([result]);
                    const saveAs = require("file-saver");
                    const fileName = file;
                    saveAs(blob, fileName);
                } else {
                    alert("File not found in Blob!");
                }
            });
    }

    //Add Audit Item
    openAddPopup() {
        this.showAddPopup = true;
    }

    closeAddPopup() {
        this.showAddPopup = false;
        this.resetForm();
    }

    resetForm() {
        this.description = null;
        this.selectedCause = undefined;
        this.selectedAuditCategory = undefined;
    }

    onBeforeFileChange(beforeOrAfter: string, files: FileList) {
        this.addNewBeforeFiles = files;
    }

    onClickOK() {
        // call add api
        this.showAddPopup = false;
        const request = new AuditItem();
        request.description = this.description;
        request.auditCauseID = this.selectedCause.auditCauseId;
        request.auditCategoryID = this.selectedAuditCategory.auditCategoryId;
        request.pilotProductID = +this.pilotProductId;
        request.operationID = +this.operationId;
        request.zoneID = +this.zoneId;
        request.userId = this.userDetails.userId;
        request.createdOn = new Date(
            new Date().getTime() - new Date().getTimezoneOffset() * 60000
        );
        this.service.createAuditItem(request).subscribe((res) => {
            if (res) {
                const auditItemID = res;
                this.getGridData();
                this.resetForm();
                if (this.addNewBeforeFiles.length > 0) {
                    this.uploadFiles(auditItemID, "b", this.addNewBeforeFiles);
                    this.addNewBeforeFiles = null;
                }
            } else {
                this.showError();
                this.resetForm();
            }
        });
    }

    getDropdowns() {
        this.service.getAuditCause().subscribe((res) => {
            this.causeDDL = res;
        });
        this.service.getAuditCategory().subscribe((res) => {
            this.categoryDDL = res;
        });
    }

    public showError(): void {
        this.notificationService.show({
            appendTo: this.appendTo,
            content: "Cannot create duplicate audit item.",
            position: { horizontal: "left", vertical: "bottom" },
            animation: { type: "fade", duration: 600 },
            type: { style: "error", icon: true },
        });
    }
}
