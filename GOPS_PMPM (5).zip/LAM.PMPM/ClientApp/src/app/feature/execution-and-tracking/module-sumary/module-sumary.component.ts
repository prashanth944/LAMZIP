import {
    ChangeDetectorRef,
    Component,
    EventEmitter,
    Input,
    OnInit,
    Output,
    SimpleChanges,
} from "@angular/core";
import { Router } from "@angular/router";
import { AppStoreService } from "../../../core/app-store.service";
import { ModuleSummary, VFDRelease } from "../Models/ModuleSummary";
import { DataServiceEandTService } from "../data-service-eand-t.service";
import { Item } from "../../model/item";
import { ModuleVFD, WIPRelease } from "../Models/workSummaryGrid";
import { Plant, UserModel } from "../../../core/model/user.model";
import { uiScreen } from "../../../core/model/common.constant";
import { Building } from "../../labor-hour-tracking/models/verify-labor-hours.model";
import * as moment from "moment";

@Component({
    selector: "pmpm-module-sumary",
    templateUrl: "./module-sumary.component.html",
    styleUrls: ["./module-sumary.component.css"],
})
export class ModuleSumaryComponent implements OnInit {
    @Input() moduleInfo: ModuleSummary = null;

    @Input() BENFormat = false;

    @Input() WipFormat = false;

    @Input() isShowButtons = true;
    @Input() isFromTechHomePage = false;
    @Input() buildStyleID = 0;
    @Input() vaBuildID = 0;
    @Input() capacityPlanningColorHex: Item[] = [];
    @Input() buildStyleItem: Item[] = [];

    @Output() reloadModuleSummary: EventEmitter<boolean> =
        new EventEmitter<boolean>();

    public openAddToWIPDialoge = false;

    public moduleColorValue: { text: string; value: string };
    public buildSceduleValue: { text: string; value: number };
    public isLaunched = false;
    public actualLaunchDate: Date = null;
    public plannedLaunchDate: Date = null;
    public dateValue = new Date();
    public targetTestDays = 0;
    public chamberReleased = false;
    public subFrameReleased = false;
    public enclosureReleased = false;
    public topPlateReleased = false;
    public maxStaffingPriority: number;
    site: Plant;
    public isUserAccess = false;
    public minDate = new Date();
    public missingLaunchDateError = false;
    public lessThanTodayDateError = false;
    public missingPLDError = false;
    public originalData: WIPRelease;
    public disableAdd = false;
    public isDayShiftOnly = false;
    public buildStyle = "";
    public buildStyleValue: { text: string; value: number };
    public buildTypeValue: { text: string; value: number };
    public buildType: Item[] = [];
    public benReconfiguredFrom = "";
    public addProdOrder = "";
    public deleteProdOrder = "";
    public originalPartNumber = "";
    public targetPartNumber = "";
    public buildStyleError = false;
    public reworkPO = "";
    public otherbuildStyleError = false;
    public buildingValue: Building;
    public userDetail: UserModel;
    public buildings: Building[] = [];
    //Authentication
    canEditLogProgress = false; //Task 24538: Log Progress Button - Edit for Supervisor, Lead, Technician
    public chamberReleasedDays: number;
    public subFrameReleasedDays: number;
    public enclosureReleasedDays: number;
    public topPlateReleasedDays: number;
    public vfdRelease: VFDRelease[] = [];
    public moduleVFDs: ModuleVFD[] = [];
    moduleProcessList: number[] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
    moduleProcess: number;

    constructor(
        private router: Router,
        private appStoreService: AppStoreService,
        private dataService: DataServiceEandTService,
        private changeDetector: ChangeDetectorRef
    ) {}

    ngOnInit(): void {
        this.minDate.setHours(0, 0, 0, 0);
        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.AddToWIPHomePage)
                    .subscribe((result) => {
                        this.isUserAccess = result;
                    });
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.EditLogProgress)
                    .subscribe((result) => {
                        this.canEditLogProgress = result;
                    });
            }
        });

        this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site) {
                this.site = {
                    plantName: site.plantName,
                    plantId: site.plantId,
                };
                this.dataService
                    .GetBuildType(this.site?.plantId)
                    .subscribe((res) => {
                        this.buildType = [];
                        if (res && res.length > 0) {
                            res.forEach((val) => {
                                const newStatus: Item = {
                                    value: val.buildTypeID,
                                    text: val.buildTypeName,
                                };
                                this.buildType.push(newStatus);
                            });
                        }
                    });
                this.appStoreService.getLoggedInUser().subscribe((user) => {
                    this.appStoreService
                        .getUserDetails(user.mail)
                        .subscribe((res) => {
                            if (res) {
                                this.userDetail = res;
                            }
                        });
                });
            }
        });
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (
            changes["moduleInfo"] &&
            changes["moduleInfo"] !== null &&
            changes["moduleInfo"].currentValue
        ) {
            this.moduleInfo = changes["moduleInfo"].currentValue;
            if (this.vaBuildID > 0) {
                this.moduleInfo.ModuleProcess = "RECONFIG";
            }
        }

        if (
            changes["capacityPlanningColorHex"] &&
            changes["capacityPlanningColorHex"] !== null &&
            changes["capacityPlanningColorHex"].currentValue
        ) {
            this.capacityPlanningColorHex =
                changes["capacityPlanningColorHex"].currentValue;
        }

        if (
            changes["buildStyleItem"] &&
            changes["buildStyleItem"] !== null &&
            changes["buildStyleItem"].currentValue
        ) {
            this.buildStyleItem = changes["buildStyleItem"].currentValue;
        }
    }

    setWIPFlatToUp() {
        this.getMaxStaffingPriority();
        this.vfdRelease = [];
        this.moduleVFDs = [];
        this.dataService.GetVFDReleases(this.site.plantId).subscribe((res) => {
            if (res && res.length > 0) {
                this.vfdRelease = res;
                this.dataService
                    .getWIPRelease(this.moduleInfo.ModuleInfo.PilotProductID)
                    .subscribe((res) => {
                        if (res) {
                            this.moduleVFDs = res.moduleVFDs;
                            if (this.moduleVFDs?.length === 0) {
                                this.vfdRelease.forEach((item) => {
                                    const vfd: ModuleVFD = {
                                        moduleVFDId: null,
                                        pilotProductId:
                                            this.moduleInfo.ModuleInfo
                                                .PilotProductID,
                                        vfdZoneId: item.vfdZoneId,
                                        statusId: null,
                                        bayName: null,
                                        assignable: false,
                                        numberOfDays: null,
                                        vfdZoneName: item.vfdZoneName,
                                        isRequired: false,
                                    };
                                    this.moduleVFDs.push(vfd);
                                });
                                this.moduleVFDs.forEach((item) => {
                                    item.assignable =
                                        this.site?.plantName === "Fremont"
                                            ? true
                                            : false;
                                    item.numberOfDays =
                                        this.site?.plantName === "Fremont"
                                            ? 0
                                            : null;
                                });
                            } else {
                                this.moduleVFDs.forEach((item) => {
                                    item.isRequired = false;
                                    item.assignable =
                                        this.site?.plantName === "Fremont"
                                            ? true
                                            : false;
                                    item.numberOfDays =
                                        this.site?.plantName === "Fremont"
                                            ? 0
                                            : null;
                                });
                            }
                            this.dataService
                                .GetBuildingOfUser(this.userDetail?.userId)
                                .subscribe((building) => {
                                    if (building && building.length > 0) {
                                        this.buildings = building;

                                        this.buildStyle = res.buildStyle;
                                        this.originalData = res;
                                        this.buildSceduleValue = {
                                            text: "",
                                            value: 0,
                                        };
                                        this.buildSceduleValue.value =
                                            res.buildSchedule;
                                        if (res.actualLaunchDate !== null) {
                                            this.actualLaunchDate = new Date(
                                                res.actualLaunchDate
                                            );
                                            this.isLaunched = true;
                                        }
                                        if (res.plannedLaunchDate !== null)
                                            this.plannedLaunchDate = new Date(
                                                res.plannedLaunchDate
                                            );
                                        else if (
                                            res.plannedLaunchDate === null &&
                                            !this.isLaunched
                                        ) {
                                            this.disableAdd = true;
                                            this.missingPLDError = true;
                                        }
                                        this.moduleColorValue = {
                                            text: "",
                                            value: "",
                                        };
                                        this.moduleColorValue.value =
                                            res.moduleColor;
                                        this.moduleColorValue.text =
                                            this.capacityPlanningColorHex.filter(
                                                (item) =>
                                                    item?.value?.toLowerCase() ===
                                                    res?.moduleColor?.toLowerCase()
                                            )[0]?.text;
                                        this.targetTestDays =
                                            res.targetTestDays;
                                        this.isDayShiftOnly = res.dayShiftOnly;
                                        this.buildStyleValue = {
                                            text: res.buildStyle,
                                            value: res.buildStyleID,
                                        };
                                        this.buildTypeValue = {
                                            text: res.buildType,
                                            value: res.buildTypeID,
                                        };
                                        this.benReconfiguredFrom =
                                            res.beNorPSNReconfiguredFrom;
                                        this.addProdOrder = res.addPO;
                                        this.deleteProdOrder = res.deletePO;
                                        this.originalPartNumber =
                                            res.currentPartNumber;
                                        this.targetPartNumber =
                                            res.newPartNumber;
                                        this.chamberReleasedDays =
                                            res.chamberReleasedDays;
                                        this.subFrameReleasedDays =
                                            res.subFrameReleasedDays;
                                        this.enclosureReleasedDays =
                                            res.enclosureReleasedDays;
                                        this.topPlateReleasedDays =
                                            res.topPlateReleasedDays;
                                        this.reworkPO = res.reworkPO;
                                        this.moduleProcess = res.processModule;
                                        if (
                                            res.buildingID !== null &&
                                            res.buildingID !== undefined
                                        )
                                            this.buildingValue =
                                                this.buildings.filter(
                                                    (item) =>
                                                        item.buildingID ===
                                                        res.buildingID
                                                )[0];
                                        else
                                            this.buildingValue =
                                                this.buildings.filter(
                                                    (item) => item.isSelected
                                                )[0];
                                    }
                                });
                        }
                    });
                this.openAddToWIPDialoge = true;
            }
        });
    }

    closeAddToWIP() {
        this.openAddToWIPDialoge = false;
        this.resetPopUp();
    }

    setWIPFlatToDown() {
        const dataToSend = {
            pilotProductID: this.moduleInfo.ModuleInfo.PilotProductID,
            wipFlat: false,
        };

        this.dataService
            .SetModuleWIPFlat(dataToSend)
            .toPromise()
            .then(() => {
                this.moduleInfo.ModuleInfo.WIPFlag = false;
            });
    }

    goToEditModule(moduleInfo: any) {
        this.router.navigate([
            "/edit-module/" +
                this.moduleInfo?.ModuleInfo?.PilotProductID +
                "/" +
                0,
        ]);
    }
    goToLogProgress() {
        this.router.navigate([
            "/edit-module/" +
                this.moduleInfo?.ModuleInfo?.PilotProductID +
                "/" +
                2,
        ]);
    }

    onAddWIP() {
        this.buildStyleError = false;
        if (
            this.buildStyleValue === undefined ||
            this.buildStyleValue === null ||
            this.buildStyleValue?.text === null ||
            this.buildStyleValue?.text === undefined
        )
            this.buildStyleError = true;
        if (this.buildStyleValue?.text === "Reconfig") {
            if (
                this.benReconfiguredFrom === null ||
                this.benReconfiguredFrom === undefined ||
                this.benReconfiguredFrom === ""
            )
                this.buildStyleError = true;
            if (
                (this.addProdOrder === null ||
                this.addProdOrder === undefined ||
                this.addProdOrder === "") &&
              this.site.plantName === "Fremont"
            )
                this.buildStyleError = true;
            if (
                (this.deleteProdOrder === null ||
                this.deleteProdOrder === undefined ||
                this.deleteProdOrder === "") &&
              this.site.plantName === "Fremont"
            )
                this.buildStyleError = true;
        }
        if (this.buildStyleValue?.text === "Rework PO") {
            if (
                this.originalPartNumber === null ||
                this.originalPartNumber === undefined ||
                this.originalPartNumber === ""
            )
                this.buildStyleError = true;
            if (
                this.targetPartNumber === null ||
                this.targetPartNumber === undefined ||
                this.targetPartNumber === ""
            )
                this.buildStyleError = true;
            if (
                this.reworkPO === null ||
                this.reworkPO === undefined ||
                this.reworkPO === ""
            )
                this.buildStyleError = true;
        }
        if (
            this.buildStyleValue?.text === "Value Added Build" ||
            this.buildStyleValue?.text === "Pilot Build" ||
            this.buildStyleValue?.text === "Cell Fusion"
        ) {
            if (
                this.buildTypeValue === undefined ||
                this.buildTypeValue === null ||
                this.buildTypeValue?.text === null ||
                this.buildTypeValue?.text === undefined
            )
                this.buildStyleError = true;
        }
        if (
            this.isLaunched == false &&
            (this.plannedLaunchDate === null ||
                this.plannedLaunchDate === undefined)
        ) {
            this.missingPLDError = true;
        } else if (
            this.moduleProcess === null ||
            this.moduleProcess === undefined ||
            this.moduleProcess === 0
        ) {
            this.buildStyleError = true;
        } else if (
            this.isLaunched == true &&
            (this.actualLaunchDate === null ||
                this.actualLaunchDate === undefined)
        ) {
            this.missingLaunchDateError = true;
            this.lessThanTodayDateError = false;
        } else {
            if (!this.buildStyleError) {
                this.missingLaunchDateError = false;
                this.lessThanTodayDateError = false;
                this.missingPLDError = false;

                const request = new WIPRelease();
                request.pilotproductID =
                    this.moduleInfo.ModuleInfo.PilotProductID;
                if (this.plannedLaunchDate != null) {
                    request.plannedLaunchDate = new Date(
                        this.plannedLaunchDate.getTime() -
                            this.plannedLaunchDate.getTimezoneOffset() * 60000
                    );
                } else request.plannedLaunchDate = this.plannedLaunchDate;

                if (this.actualLaunchDate != null) {
                    request.actualLaunchDate = new Date(
                        this.actualLaunchDate.getTime() -
                            this.actualLaunchDate.getTimezoneOffset() * 60000
                    );
                } else request.actualLaunchDate = this.actualLaunchDate;
                request.moduleColor = this.moduleColorValue?.value;
                request.targetTestDays = this.targetTestDays;
                request.dayShiftOnly = this.isDayShiftOnly;
                request.wipPriority = (this.maxStaffingPriority + 1).toString();

                request.buildStyle = this.buildStyleValue?.text;
                request.buildStyleID = this.buildStyleValue?.value;
                if (this.buildStyleValue?.text === "Reconfig") {
                    request.beNorPSNReconfiguredFrom = this.benReconfiguredFrom;
                    request.addPO = this.addProdOrder;
                    request.deletePO = this.deleteProdOrder;
                }
                if (this.buildStyleValue?.text === "Rework PO") {
                    request.currentPartNumber = this.originalPartNumber;
                    request.newPartNumber = this.targetPartNumber;
                    request.reworkPO = this.reworkPO;
                }

                request.buildType = this.buildTypeValue?.text;
                request.buildTypeID = this.buildTypeValue?.value;
                request.buildingID = this.buildingValue?.buildingID;
                request.chamberReleasedDays = this.chamberReleasedDays;
                request.subFrameReleasedDays = this.subFrameReleasedDays;
                request.enclosureReleasedDays = this.enclosureReleasedDays;
                request.topPlateReleasedDays = this.topPlateReleasedDays;
                request.moduleVFDs = this.moduleVFDs;
                request.processModule = this.moduleProcess;
                request.modifiedBy = this.userDetail.userId;
                request.modifiedOn = new Date(
                    new Date().getTime() -
                        new Date().getTimezoneOffset() * 60000
                );
                let date: any = new Date();
                date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
                this.dataService
                    .AddWIPRelease(request, date)
                    .subscribe((res) => {
                        this.openAddToWIPDialoge = false;
                        this.resetPopUp();
                        this.reloadModuleSummary.emit(true);
                    });
            }
        }
    }

    onCheckVFDRelease(vfd: ModuleVFD) {
        vfd.assignable = !vfd.assignable;
        vfd.numberOfDays = vfd.assignable ? 0 : null;
    }
    onCheckVFDReleaseRequired(vfd: ModuleVFD) {
        vfd.isRequired = !vfd.isRequired;
        if (vfd.isRequired) {
            vfd.assignable = !vfd.isRequired;
            vfd.numberOfDays = null;
        }
    }
    resetPopUp() {
        this.buildSceduleValue = { text: "", value: 0 };
        this.moduleColorValue = { text: "", value: "" };
        if (this.originalData?.actualLaunchDate !== null) {
            this.actualLaunchDate = new Date(
                this.originalData.actualLaunchDate
            );
            this.isLaunched = true;
        } else {
            this.actualLaunchDate = null;
            this.isLaunched = false;
        }
        this.plannedLaunchDate =
            this.originalData?.plannedLaunchDate !== null
                ? new Date(this.originalData?.plannedLaunchDate)
                : null;
        this.targetTestDays = 0;
        this.chamberReleased = false;
        this.subFrameReleased = false;
        this.enclosureReleased = false;
        this.topPlateReleased = false;
        this.missingLaunchDateError = false;
        this.lessThanTodayDateError = false;
        this.missingPLDError = false;
        this.isDayShiftOnly = false;
        this.buildStyleValue?.text;
        this.buildStyleValue = { text: "", value: null };
        this.benReconfiguredFrom = "";
        this.addProdOrder = "";
        this.deleteProdOrder = "";
        this.originalPartNumber = "";
        this.targetPartNumber = "";
        this.reworkPO = "";
    }

    getMaxStaffingPriority() {
        this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site) {
                this.dataService
                    .getMaxStaffingPriority(site.plantId)
                    .subscribe((res) => {
                        if (res) {
                            this.maxStaffingPriority = res;
                        }
                    });
            }
        });
    }

    getModuleProcessColor(process: string): string {
        let color = "";
        switch (process) {
            case "POST-TEST":
                color = "#b00b0b";
                break;
            case "TEST":
                color = "#4c046e";
                break;
            case "INTEGRATION":
                color = "#039c12";
                break;
            case "SUB ASSEMBLY":
                color = "#0245a3";
                break;
            case "RECONFIG":
                color = "#b51b49";
                break;
        }
        return color;
    }

    onIssueLogsClick() {
        this.router
            .navigateByUrl("/", { skipLocationChange: true })
            .then(() => {
                this.router.navigate([
                    "/action-items/" +
                        this.moduleInfo?.ModuleInfo?.PilotProductID +
                        "/" +
                        0,
                ]);
            });
    }

    onAuditItemsClick() {
        this.router
            .navigateByUrl("/", { skipLocationChange: true })
            .then(() => {
                this.router.navigate([
                    "/action-items/" +
                        this.moduleInfo?.ModuleInfo?.PilotProductID +
                        "/" +
                        1,
                ]);
            });
    }

    onNICClick() {
        this.router
            .navigateByUrl("/", { skipLocationChange: true })
            .then(() => {
                this.router.navigate([
                    "/action-items/" +
                        this.moduleInfo?.ModuleInfo?.PilotProductID +
                        "/" +
                        2,
                ]);
            });
    }

    onOBCClick() {
        this.router
            .navigateByUrl("/", { skipLocationChange: true })
            .then(() => {
                this.router.navigate([
                    "/action-items/" +
                        this.moduleInfo?.ModuleInfo?.PilotProductID +
                        "/" +
                        3,
                ]);
            });
    }

    onShortageClick() {
        let tabId = 0;
        if (this.BENFormat) tabId = 5;
        else tabId = 4;
        this.router
            .navigateByUrl("/", { skipLocationChange: true })
            .then(() => {
                this.router.navigate([
                    "/action-items/" +
                        this.moduleInfo?.ModuleInfo?.PilotProductID +
                        "/" +
                        tabId,
                ]);
            });
    }

    onTOIClick() {
        let tabId = 0;
        if (this.BENFormat) tabId = 6;
        else tabId = 5;
        this.router
            .navigateByUrl("/", { skipLocationChange: true })
            .then(() => {
                this.router.navigate([
                    "/action-items/" +
                        this.moduleInfo?.ModuleInfo?.PilotProductID +
                        "/" +
                        tabId,
                ]);
            });
    }

    onActualLaunchDateChange(value: Date) {
        if (value === null || value === undefined) {
            this.missingLaunchDateError = true;
            this.disableAdd = true;
        } else {
            this.missingLaunchDateError = false;
            this.disableAdd = false;
        }
    }

    onPlannedLaunchDateChange(value: Date) {
        if (value === null || value === undefined) {
            this.missingPLDError = true;
            this.disableAdd = true;
        } else if (value.getTime() < this.minDate.getTime()) {
            this.lessThanTodayDateError = true;
            this.missingPLDError = false;
            this.disableAdd = true;
        } else {
            this.lessThanTodayDateError = false;
            this.missingPLDError = false;
            this.disableAdd = false;
        }
    }

    onSwitchChange(isLaunched) {
        if (isLaunched) {
            this.plannedLaunchDate =
                this.originalData?.plannedLaunchDate !== null
                    ? new Date(this.originalData?.plannedLaunchDate)
                    : null;
            this.missingPLDError = false;
            this.onActualLaunchDateChange(this.actualLaunchDate);
        } else {
            this.actualLaunchDate =
                this.originalData?.actualLaunchDate !== null
                    ? new Date(this.originalData?.actualLaunchDate)
                    : null;
            this.missingLaunchDateError = false;
            this.lessThanTodayDateError = false;
            this.disableAdd = this.originalData?.plannedLaunchDate === null;
            this.missingPLDError =
                this.originalData?.plannedLaunchDate === null;
        }
    }

    private checkInvalidYear(data) {
        const date = new Date(data);
        return date.getFullYear();
    }

    ALDOnBlur(value: Date) {
        if (
            this.checkInvalidYear(value) < 1900 ||
            this.checkInvalidYear(value) > 2099 ||
            value === null
        ) {
            this.actualLaunchDate = null;
            this.missingLaunchDateError = true;
            this.lessThanTodayDateError = false;
            this.disableAdd = true;
        }
    }

    PLDOnBlur(value: Date) {
        if (
            this.checkInvalidYear(value) < 1900 ||
            this.checkInvalidYear(value) > 2099 ||
            value === null
        ) {
            this.plannedLaunchDate = null;
            this.missingPLDError = true;
            this.disableAdd = true;
        }
    }
}
