import { Component, Input, OnInit } from "@angular/core";

@Component({
    selector: "pmpm-item-warnings",
    templateUrl: "./item-warnings.component.html",
    styleUrls: ["./item-warnings.component.css"],
})
export class ItemWarningsComponent implements OnInit {
    @Input() name = "NO Named";
    @Input() value: any = 0;

    constructor() {}

    ngOnInit(): void {}
}
