import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { environment } from "../../../environments/environment.dev_server";
import { BehaviorSubject, Observable } from "rxjs";
import { AppStoreService } from "../../core/app-store.service";

@Injectable({
    providedIn: "root",
})
export class DataCalendarService {
    isVisibleSource: BehaviorSubject<boolean> = new BehaviorSubject(false);
    pTOEventsList: BehaviorSubject<any[]> = new BehaviorSubject([]);
    holidaysList: BehaviorSubject<any[]> = new BehaviorSubject([]);
    eventToEdit: BehaviorSubject<any> = new BehaviorSubject({});
    showReportTable: BehaviorSubject<boolean> = new BehaviorSubject(false);

    constructor(
        private http: HttpClient,
        private appStoreService: AppStoreService
    ) {}

    readonly apiUrl = `${environment.apiUrl}`;

    getMail() {
        const user =
            this.appStoreService._currentLoggedInUser$.getValue()["mail"];
        if (!user) {
            console.error("Error no mail register on the service");
        }
        return this.appStoreService._currentLoggedInUser$.getValue()["mail"];
    }
    getPlantId() {
        const user = this.appStoreService._currentSite$.getValue()["plantId"];
        if (!user) {
            console.error("Error no plantId register on the service");
        }
        return this.appStoreService._currentSite$.getValue()["plantId"];
    }

    getUserDetails() {
        const info = { userEmail: this.getMail() };
        return this.http.post<any[]>(
            this.apiUrl + "/Calendar/GetUsersDetails",
            info
        );
    }
    AddPTOEvent(information: any) {
        information["userEmail"] = this.getMail();
        information["plantId"] = this.getPlantId();
        return this.http.post<any[]>(
            this.apiUrl + "/Calendar/AddPTOEvent/",
            information
        );
    }
    UpdatePTOEvent(information: any) {
        information["userEmail"] = this.getMail();
        return this.http.post<any[]>(
            this.apiUrl + "/Calendar/UpdatePTOEvent/",
            information
        );
    }
    GetPTOEvent() {
        const info = { userEmail: this.getMail(), plantId: this.getPlantId() };
        return this.http.post<any[]>(
            this.apiUrl + "/Calendar/GetPTOEvents/",
            info
        );
    }
    getHolidays() {
        return this.http.get<any[]>(
            this.apiUrl + "/Admin/GetHolidays/" + this.getPlantId()
        );
    }
    UpdateStatusPTOEvent(info: any) {
        return this.http.post<any[]>(
            this.apiUrl + "/Calendar/UpdateStatusPTOEvent/",
            info
        );
    }
    DropPTOEvent(info: any) {
        return this.http.post<any[]>(
            this.apiUrl + "/Calendar/DropPTOEvent/",
            info
        );
    }

    diplayReportTable() {
        this.showReportTable.next(true);
    }
    hideReportTable() {
        this.showReportTable.next(false);
    }
    getBoolReportTable(): Observable<boolean> {
        return this.showReportTable;
    }

    changeVisibleStatus(state: boolean) {
        this.isVisibleSource.next(state);
    }

    loadEvents() {
        this.GetPTOEvent().subscribe((data) => {
            this.getHolidays().subscribe((data2) => {
                this.holidaysList.next(data2);
                this.pTOEventsList.next(data);
            });
        });
    }

    reLoadEvents() {
        const val = this.pTOEventsList.getValue();
        if (val.length === 0) {
            this.loadEvents();
        } else {
            this.pTOEventsList.next(val);
        }
    }

    itemIndex(item: any, data: any[]) {
        for (let idx = 0; idx < data.length; idx++) {
            if (data[idx].id === item.id) {
                return idx;
            }
        }
        return -1;
    }

    AddEditElements(item: any) {
        const items = this.pTOEventsList.getValue();
        const index = this.itemIndex(item, items);
        if (index !== -1) {
            items.splice(index, 1, item);
        } else {
            items.push(item);
        }
        this.pTOEventsList.next(items);
    }

    removeElements(item: any) {
        const items = this.pTOEventsList.getValue();
        const index = this.itemIndex(item, items);
        items.splice(index, 1);
        this.pTOEventsList.next(items);
    }

    setEventToEdit(item: any) {
        this.eventToEdit.next(item);
    }

    getEventToEdit(): Observable<any> {
        return this.eventToEdit;
    }

    existStartDate(employeeDataID, startDate) {
        let items = this.pTOEventsList.getValue();
        const editVal = this.eventToEdit.getValue();
        if (Object.keys(editVal).length) {
            items = items.filter((row) => row["id"] !== editVal["id"]);
        }

        const str = (date) => {
            if (date && date?.length > 0) {
                return new Date(date)?.toISOString()?.split("T")[0];
            }
        };

        return items.some(
            (row) =>
                str(row["startDate"]) <= str(startDate) &&
                str(row["endDate"]) >= str(startDate) &&
                row["employeeDataID"] === employeeDataID
        );
    }

    existContainsDate(employeeDataID, startDate, endDate) {
        let items = this.pTOEventsList.getValue();
        const editVal = this.eventToEdit.getValue();
        if (Object.keys(editVal).length) {
            items = items.filter((row) => row["id"] !== editVal["id"]);
        }

        const str = (date) => {
            if (date && date?.length > 0) {
                return new Date(date).toISOString().split("T")[0];
            }
        };

        return items.some(
            (row) =>
                str(row["startDate"]) >= str(startDate) &&
                str(row["endDate"]) <= str(endDate) &&
                row["employeeDataID"] === employeeDataID
        );
    }
}
