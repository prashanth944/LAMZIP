import { Component, OnInit } from "@angular/core";
import { SchedulerEvent } from "@progress/kendo-angular-scheduler";
import { DataCalendarService } from "../data-calendar.service";
import { map } from "rxjs/operators";
import { Observable } from "rxjs";

@Component({
    selector: "app-scheduler-report",
    templateUrl: "./scheduler-report.component.html",
    styleUrls: ["./scheduler-report.component.css"],
})
export class SchedulerReportComponent implements OnInit {
    constructor(private dataService: DataCalendarService) {}

    public displayReportTable = false;
    public isSelectable = true;
    public isNew = true;

    public listItems: Observable<SchedulerEvent[]>;

    public levelUser = 3;

    public openNew() {
        this.isNew = true;
        this.dataService.changeVisibleStatus(true);
    }
    public openEdit() {
        this.isNew = false;
        this.dataService.changeVisibleStatus(true);
    }

    ngOnInit(): void {
        this.loadDataFromBK();
    }

    loadDataFromBK() {
        this.listItems = this.dataService.pTOEventsList.pipe(
            map((data) =>
                data
                    .filter(
                        (row) =>
                            row["levelUser"] <= this.levelUser &&
                            row["statusLabel"] !== "D"
                    )
                    .map(this.castEvent)
                    .concat(
                        this.dataService.holidaysList.value.map(
                            this.castHoliday
                        )
                    )
            )
        );
        this.dataService.getBoolReportTable().subscribe((value) => {
            this.displayReportTable = value;
        });
    }

    castEvent(item: any) {
        const startD = new Date(item["startDate"]);
        const endD = new Date(item["endDate"]);
        startD.setHours(8, 0, 0);
        endD.setHours(16, 0, 0);

        return {
            start: startD,
            end: endD,
            title:
                item["FirstName"] +
                " " +
                item["LastName"] +
                " | " +
                item["typeName"],
            description: item["statusLabel"],
        };
    }

    castHoliday(item: any) {
        const startD = new Date(item["HolidayDateDaily"]);
        const endD = new Date(item["HolidayDateDaily"]);
        startD.setHours(8, 0, 0);
        endD.setHours(16, 0, 0);

        return {
            start: startD,
            end: endD,
            title: item["Name"],
            description: "Holiday",
        };
    }

    public changeLevel(inputLevel: number) {
        this.levelUser = inputLevel;
        this.dataService.reLoadEvents();
    }

    public displayReport() {
        this.dataService.diplayReportTable();
    }
}
