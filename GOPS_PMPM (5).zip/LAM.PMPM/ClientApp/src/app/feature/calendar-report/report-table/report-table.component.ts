import { Component, OnInit } from "@angular/core";
import { DataCalendarService } from "../data-calendar.service";
import { Observable } from "rxjs";
import { GridDataResult } from "@progress/kendo-angular-grid";
import { map } from "rxjs/operators";
import { process, State } from "@progress/kendo-data-query";
import { AppStoreService } from "../../../core/app-store.service";
import { role, userRoles } from "../../../core/model/common.constant";

@Component({
    selector: "app-report-table",
    templateUrl: "./report-table.component.html",
    styleUrls: ["./report-table.component.css"],
})
export class ReportTableComponent implements OnInit {
    constructor(
        private dataService: DataCalendarService,
        private appStoreService: AppStoreService
    ) {}

    public gridData: any[] = [];
    public view: Observable<GridDataResult>;
    public displayReportTable = false;

    public isNew = true;
    public confirmDialogBool = false;
    public itemSelected: any = {};
    public newState: any = "A";

    public AllTypes: Observable<any>;
    public SelTypes: any;

    public textSearch = "";

    public levelUser = 3;

    public AllStatus: any[] = [
        { text: "Pending", value: "P" },
        { text: "Approved", value: "A" },
        { text: "Denied", value: "D" },
    ];
    public SelStatus: any;

    public gridState: State = {
        // Initial filter descriptor
        filter: {
            logic: "and",
            filters: [],
        },
    };

    public isManager = false;
    userRoles: string[] = userRoles;

    ngOnInit(): void {
        this.loadDataFromBK();
    }

    loadDataFromBK() {
        this.view = this.dataService.pTOEventsList.pipe(
            map((data) => process(data, this.gridState))
        );

        this.AllTypes = this.dataService.pTOEventsList.pipe(
            map((data) => this.GetUniques(data, "typeName"))
        );

        this.appStoreService.getUserRoles().subscribe((res) => {
            let newUserRoles: string[] = [];
            if (res && res.length > 0) {
                newUserRoles = res;
                this.isManager =
                    newUserRoles.includes(role.Manager) ||
                    newUserRoles.includes(role.SuperUser) ||
                    newUserRoles.includes(role.Supervisor);
            }
        });

        this.dataService.getBoolReportTable().subscribe((value) => {
            this.displayReportTable = value;
        });
    }

    public GetUniques(data: any[], colName: string) {
        return data
            .map((item) => item[colName])
            .filter(
                (value, index, self) =>
                    self.indexOf(value) === index && value !== null
            )
            .map((val) => ({ text: val, value: val }));
    }

    public openNew() {
        this.isNew = true;
        this.dataService.setEventToEdit({});
        this.dataService.changeVisibleStatus(true);
    }
    public openEdit() {
        this.isNew = false;
        this.dataService.changeVisibleStatus(true);
    }
    public editItem(item: any) {
        this.dataService.setEventToEdit(item);
        this.openEdit();
    }

    public openConfirm(info: any, newState: any) {
        this.itemSelected = info;
        this.newState = newState;
        this.confirmDialogBool = true;
    }

    public dateDifference(date2, date1) {
        const d1 = new Date(date1);
        const d2 = new Date(date2);

        const _MS_PER_DAY = 1000 * 60 * 60 * 24;

        // Discard the time and time-zone information.
        const utc1 = Date.UTC(d1.getFullYear(), d1.getMonth(), d1.getDate());
        const utc2 = Date.UTC(d2.getFullYear(), d2.getMonth(), d2.getDate());

        return Math.floor((utc2 - utc1) / _MS_PER_DAY) + 1;
    }

    closeConfirmDialog(label: string) {
        if (label === "yes") {
            if (this.newState !== "Drop") {
                this.itemSelected["statusLabel"] = this.newState;
                this.dataService
                    .UpdateStatusPTOEvent(this.itemSelected)
                    .toPromise()
                    .then((data) => {});
                this.dataService.AddEditElements(this.itemSelected);
            } else {
                this.dataService
                    .DropPTOEvent(this.itemSelected)
                    .toPromise()
                    .then((data) => {});
                this.dataService.removeElements(this.itemSelected);
            }
            this.confirmDialogBool = false;
        } else {
            this.confirmDialogBool = false;
        }
    }

    updateFromFilter() {
        this.gridState["filter"] = {
            logic: "and",
            filters: [],
        };

        if (this.SelTypes && this.SelTypes.value !== "") {
            this.gridState["filter"].filters.push({
                field: "typeName",
                operator: "eq",
                value: this.SelTypes.value,
            });
        }

        if (this.SelStatus && this.SelStatus.value !== "") {
            this.gridState["filter"].filters.push({
                field: "statusLabel",
                operator: "eq",
                value: this.SelStatus.value,
            });
        }
        if (this.textSearch) {
            this.gridState["filter"].filters.push({
                logic: "or",
                filters: [
                    {
                        field: "Username",
                        operator: "contains",
                        value: this.textSearch.trim(),
                    },
                    {
                        field: "groupName",
                        operator: "contains",
                        value: this.textSearch.trim(),
                    },
                    {
                        field: "comment",
                        operator: "contains",
                        value: this.textSearch.trim(),
                    },
                ],
            });
        }

        if (this.levelUser < 3) {
            this.gridState["filter"].filters.push({
                field: "levelUser",
                operator: "lte",
                value: this.levelUser,
            });
        }

        this.dataService.reLoadEvents();
    }

    cleanFilter() {
        this.SelTypes = undefined;
        this.SelStatus = undefined;
        this.textSearch = "";
        this.levelUser = 3;
        this.updateFromFilter();
    }
    public onFilter(inputValue: string): void {
        this.textSearch = inputValue;
        this.updateFromFilter();
    }
    public getValue(event: Event): string {
        return (event.target as HTMLInputElement).value;
    }

    public changeLevel(inputLevel: number) {
        this.levelUser = inputLevel;
        this.updateFromFilter();
    }

    public displayCalendar() {
        this.dataService.hideReportTable();
    }
}
