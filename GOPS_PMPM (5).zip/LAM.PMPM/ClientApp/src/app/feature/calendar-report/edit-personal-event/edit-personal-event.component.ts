import { Component, OnInit } from "@angular/core";
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { DataCalendarService } from "../data-calendar.service";
import { AppStoreService } from "../../../core/app-store.service";
import { Plant } from "../../../core/model/user.model";
import { role } from "../../../core/model/common.constant";

export function checkNeedsOfEndDate() {
    return (formGroup: FormGroup) => {
        const covidControl = formGroup.controls["covidRelated"];
        const endDateControl = formGroup.controls["EndDate"];

        if (
            (covidControl.value === null || covidControl.value === false) &&
            endDateControl.value === null
        ) {
            endDateControl.setErrors({ required: "true" });
        } else {
            const err = endDateControl.errors;
            if (err) {
                delete err["required"];
                if (!Object.keys(err).length) {
                    // if no errors left
                    endDateControl.setErrors(null); // set control errors to null making it VALID
                } else {
                    endDateControl.setErrors(err); // controls got other errors so set them back
                }
            }
        }

        return null;
    };
}
export function checkStartDateAndName(dataService: DataCalendarService) {
    return (formGroup: FormGroup) => {
        const employeeDataID = formGroup.controls["employeeDataID"];
        const startDateControl = formGroup.controls["StartDate"];

        if (startDateControl.errors && !startDateControl.errors.invalidValue) {
            // return if another validator has already found an error on the wwInQuarterControl
            return;
        }
        if (startDateControl.value && employeeDataID.value) {
            // set error on matchingControl if validation fails
            if (
                dataService.existStartDate(
                    employeeDataID.value,
                    startDateControl.value
                )
            ) {
                startDateControl.setErrors({ invalidValue: true });
            } else {
                startDateControl.setErrors(null);
            }
        }
        return null;
    };
}
export function checkEndDateAndName(dataService: DataCalendarService) {
    return (formGroup: FormGroup) => {
        const employeeDataID = formGroup.controls["employeeDataID"];
        const endDateControl = formGroup.controls["EndDate"];
        const startDateControl = formGroup.controls["StartDate"];
        const covidRelated = formGroup.controls["covidRelated"];

        if (endDateControl.errors && !endDateControl.errors.invalidValue) {
            // return if another validator has already found an error on the endDateControl
            return;
        }
        if (endDateControl.value && employeeDataID.value) {
            // set error on matchingControl if validation fails
            if (
                dataService.existStartDate(
                    employeeDataID.value,
                    endDateControl.value
                )
            ) {
                endDateControl.setErrors({ invalidValue: true });
            } else {
                endDateControl.setErrors(null);
            }
        }

        if (endDateControl.errors) {
            // return if another validator has already found an error
            return;
        }
        if (
            endDateControl.value &&
            employeeDataID.value &&
            startDateControl.value &&
            covidRelated.value !== true
        ) {
            // validate the full set
            if (
                dataService.existContainsDate(
                    employeeDataID.value,
                    startDateControl.value,
                    endDateControl.value
                )
            ) {
                endDateControl.setErrors({ invalidValue: true });
            } else {
                endDateControl.setErrors(null);
            }
        }
        return null;
    };
}

@Component({
    selector: "app-edit-personal-event",
    templateUrl: "./edit-personal-event.component.html",
    styleUrls: ["./edit-personal-event.component.css"],
})
export class EditPersonalEventComponent implements OnInit {
    public min: Date = new Date(2021, 1, 1);
    public opened = false;
    public isManager = false;

    public registerForm: FormGroup = new FormGroup(
        {
            employeeDataID: new FormControl({ disabled: !this.isManager }, [
                Validators.required,
            ]),
            groupName: new FormControl({}, [Validators.required]),
            typeName: new FormControl({}, [Validators.required]),
            covidRelated: new FormControl(false),
            StartDate: new FormControl({}, [Validators.required]),
            EndDate: new FormControl({}, []),
            comments: new FormControl({}, [Validators.maxLength(400)]),
        },
        {
            validators: [
                checkNeedsOfEndDate(),
                checkStartDateAndName(this.dataService),
                checkEndDateAndName(this.dataService),
            ],
        }
    );
    public site: Plant;
    public UserData: string[] = [];
    public userListInfo: any[] = [];
    public groupsList: string[] = [];
    public typeList: string[] = [
        "PTO",
        "Personal/Medical",
        "Leaving Early",
        "Coming In Late",
        "Overtime",
        "Working Day Outside of Normal Shift",
    ];

    private originEditObject = {};
    constructor(
        private dataService: DataCalendarService,
        private appStoreService: AppStoreService
    ) {}

    addStatusBool = true;
    private eventEditedId = 0;
    listItems: Array<string> = [
        "Albania",
        "Andorra",
        "Armenia",
        "Austria",
        "Azerbaijan",
    ];
    public today = new Date();

    ngOnInit(): void {
        this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site) {
                this.site = {
                    plantName: site.plantName,
                    plantId: site.plantId,
                };
                this.getGroupsBySite();
            }
        });

        this.dataService.isVisibleSource.subscribe((isVisible) => {
            this.opened = isVisible;
        });

        this.appStoreService.getLoggedInUser().subscribe((user) => {
            if (user) {
                this.getUserDetails();
            }
        });

        this.appStoreService.getCurrentSite().subscribe((plant) => {
            if (plant) {
                this.dataService.loadEvents();
            }
        });

        this.dataService.getEventToEdit().subscribe((item) => {
            if (Object.keys(item).length) {
                this.addStatusBool = false;
                this.updateFormValues(item);
            } else {
                this.addStatusBool = true;
                this.clearForm();
                if (this.userListInfo.length > 0) {
                    this.setEmployeeDataId();
                }
            }
        });

        this.appStoreService.getUserRoles().subscribe((res) => {
            let newUserRoles: string[] = [];
            if (res && res.length > 0) {
                newUserRoles = res;
                this.isManager = newUserRoles.includes(role.Manager);
            }
        });
    }

    updateFormValues(item: any) {
        this.registerForm.setValue({
            employeeDataID: item["employeeDataID"],
            groupName: item["groupName"],
            typeName: item["typeName"],
            covidRelated: item["covidRelated"],
            StartDate: new Date(item["startDate"]),
            EndDate: new Date(item["endDate"]),
            comments: item["comment"],
        });
        this.eventEditedId = item["id"];

        this.originEditObject = {
            employeeDataID: item["employeeDataID"],
            groupName: item["groupName"],
            typeName: item["typeName"],
            covidRelated: item["covidRelated"],
            StartDate: new Date(item["startDate"]),
            EndDate: new Date(item["endDate"]),
            comments: item["comment"],
        };
    }

    getGroupsBySite() {
        if (this.site) {
            if (this.site.plantName === "Tualatin") {
                this.groupsList = [
                    "Contractors",
                    "Engineering Pilot",
                    "HVM PECVD",
                    "HVM Sabre",
                    "PG Engineering",
                    "Pilot Mfg",
                ];
            } else {
                this.groupsList = [
                    "Cleanliness/Chemical Stains",
                    "Dep Fremont",
                    "Eng",
                    "Etch",
                    "F-Platform",
                    "Manager/Supervisor",
                    "Mechatronics",
                    "NPD",
                ];
            }
        }
    }

    getUserDetails() {
        this.dataService
            .getUserDetails()
            .toPromise()
            .then((data) => {
                this.userListInfo = data;
                this.UserData = data.map((x: any) => x["Username"]);
                this.setEmployeeDataId();
            });
    }

    setEmployeeDataId() {
        const mail = this.dataService.getMail();
        const employeeDataIdVal = this.userListInfo.filter(
            (x) => x["Username"] === mail
        )[0]["EmployeeDataID"];
        this.registerForm.controls["employeeDataID"].setValue(
            employeeDataIdVal
        );
    }

    public itIsTheSame() {
        if (this.addStatusBool === false) {
            const original = JSON.stringify(this.originEditObject);
            const diffData = JSON.stringify(this.registerForm.getRawValue());

            return original === diffData;
        } else {
            return false;
        }
    }

    public submitForm(): void {
        const metaData = this.registerForm.getRawValue();
        if (metaData["typeName"] !== "Personal/Medical") {
            metaData["covidRelated"] = false;
        }
        metaData["covidRelated"] = metaData["covidRelated"] ?? false;
        if (metaData["covidRelated"]) {
            metaData["EndDate"] = metaData["StartDate"];
        }
        const getDateWithOutTimeZone = (dateToProcess: Date) => {
            return new Date(
                dateToProcess.getTime() -
                    dateToProcess.getTimezoneOffset() * 60000
            )
                .toISOString()
                .slice(0, 10);
        };

        metaData["EndDate"] = getDateWithOutTimeZone(metaData["EndDate"]);
        metaData["StartDate"] = getDateWithOutTimeZone(metaData["StartDate"]);

        metaData["comments"] = metaData["comments"] ?? "";

        if (this.addStatusBool) {
            // true means is a new object
            this.dataService
                .AddPTOEvent(metaData)
                .toPromise()
                .then(
                    (data) => {
                        this.dataService.AddEditElements(data);
                    },
                    (error: any) => {
                        console.log(error);
                    }
                );
        } else {
            metaData["id"] = this.eventEditedId;

            this.dataService
                .UpdatePTOEvent(metaData)
                .toPromise()
                .then(
                    (data) => {
                        this.dataService.AddEditElements(data);
                    },
                    (error: any) => {
                        console.log(error);
                    }
                );
        }

        this.close();
    }

    public clearForm(): void {
        this.registerForm.reset();
    }

    public close() {
        if (this.addStatusBool) {
            this.clearForm();
            this.setEmployeeDataId();
        }
        this.dataService.changeVisibleStatus(false);
    }

    public dateDifference(date2, date1) {
        if (date1 && date2) {
            const d1 = new Date(date1);
            const d2 = new Date(date2);

            const _MS_PER_DAY = 1000 * 60 * 60 * 24;

            // Discard the time and time-zone information.
            const utc1 = Date.UTC(
                d1.getFullYear(),
                d1.getMonth(),
                d1.getDate()
            );
            const utc2 = Date.UTC(
                d2.getFullYear(),
                d2.getMonth(),
                d2.getDate()
            );

            return Math.floor((utc2 - utc1) / _MS_PER_DAY) + 1;
        } else {
            return 0;
        }
    }
}
