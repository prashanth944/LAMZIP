import { Component, OnInit } from "@angular/core";

@Component({
    selector: "app-calendar-report",
    templateUrl: "./calendar-report.component.html",
    styleUrls: ["./calendar-report.component.css"],
})
export class CalendarReportComponent implements OnInit {
    constructor() {}

    ngOnInit(): void {}
}
