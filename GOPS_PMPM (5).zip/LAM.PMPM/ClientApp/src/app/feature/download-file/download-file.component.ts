import { HttpClient } from "@angular/common/http";
import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
declare let require: any;
import { environment } from "../../../environments/environment.dev_server";

@Component({
    selector: "app-download-file",
    templateUrl: "./download-file.component.html",
    styleUrls: ["./download-file.component.css"],
})
export class DownloadFileComponent implements OnInit {
    readonly apiUrl = `${environment.apiUrl}`;
    public GUID: string;
    public beforeOrAfter: string;
    public file: string;

    constructor(private route: ActivatedRoute, private http: HttpClient) {}

    ngOnInit(): void {
        this.route.params.subscribe((param) => {
            this.GUID = param.GUID;
            this.beforeOrAfter = param.beforeOrAfter;
            this.file = param.file;
        });
        this.downloadFromURL();
    }

    downloadFromURL() {
        this.http
            .get(
                this.apiUrl +
                    "/Log/downloadfilefromurl?guid=" +
                    this.GUID +
                    "&beforeafter=" +
                    this.beforeOrAfter +
                    "&filename=" +
                    this.file,
                { responseType: "blob" }
            )
            .subscribe((result: any) => {
                if (result) {
                    const blob = new Blob([result]);
                    const saveAs = require("file-saver");
                    const fileName = this.file;
                    saveAs(blob, fileName);
                } else {
                    alert("File not found!");
                }
            });
    }
}
