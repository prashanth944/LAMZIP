export class SpecialSubassemblyGrid {
    laborHourItemTypeId: number;
    optionName: string;
    type: string;
    ItemType: string;
    pilotProductID: number[];
    POWO: string[];
    POWOCellValue: number[];
    laborHourValuesId: number[];
}
