export class OtherDDLItem {
    text: string;
    value: any;
    value2: any;
}
