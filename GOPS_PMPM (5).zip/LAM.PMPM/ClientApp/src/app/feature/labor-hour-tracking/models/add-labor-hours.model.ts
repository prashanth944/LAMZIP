export class PSNorBEN {
    public pilotProductID: number;
    public ben: string;
    public pilotSerialNumber: string;
    public buildStyle: string;
}
export class LaborHoursItem {
    public laborHourItemTypeId: number;
    public optionName: string;
    public type: string;
    public time: number;
}

export class LaborHoursItemForMultipleBENorPSN {
    public laborHourItemTypeId: number;
    public optionName: string;
    public type: string;
    public hoursPerDay: number;
}

export class LaborHoursType {
    public laborTypeID: number;
    public laborTypeName: string;
}

export class LaborHoursTypeForLaborHours {
    public laborHourTypeId: number;
    public optionName: string;
    public type: string;
}

export class ItemType {
    public cellValue: number;
    public laborTypeID: number;
    public laborHourValuesId: number;
}

export class DirectLH {
    public ItemType: string;
    public optionName: string;
    public laborHourItemTypeId: number;
    public type: string;
    public pilotProductID: number;
    public ItemTypeCellValue: ItemType[];
}

export class IndirectLH {
    public ItemType: string;
    public optionName: string;
    public laborHourItemTypeId: number;
    public type: string;
    public pilotProductID: number;
    public time: number;
    public laborHourValuesId: number;
    public laborTypeId: number;
}

export class LaborHourLoanTo {
    public laborHourLoanToId: number;
    public optionName: string;
}

export class LaborHourForToday {
    public reworkHours: number;
    public standardHours: number;
}
