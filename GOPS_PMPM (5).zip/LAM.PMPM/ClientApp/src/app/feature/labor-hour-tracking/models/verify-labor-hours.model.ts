import { PSNorBEN } from "./add-labor-hours.model";

export class LaborHourTechWorkLog {
  public ben: string;
  public pilotSerialNumber: string;
  public operationName: string;
  public isRework: boolean;
  public startTime: Date;
  public endTime: Date;
  public interruptionHours: number;
  public totalHours: number;
  public notes: string;
  public interruptionCategory: string;
  public buildStyle: string;
}

export class LaborHourTechDashBoard {
  public laborTechBENDetails: PSNorBEN[];
  public working: number;
  public recorded: number;
  public direct: number;
  public interrupts: number;
  public breaksOrLunch: number;
  public rework: number;
  public total: number;
  public isVerify: boolean;
  public isSwitched: boolean;
}

export class Building {
  public buildingID: number;
  public code: string;
  public isSelected: boolean;
}

export class LaborHourSupDashboardView {
  public laborHourVerificationId: number;
  public userName: string;
  public workingHours: number;
  public financeHours: number;
  public utilization: number;
  public directCT: number;
  public interrupts: number;
  public breakLunchInterrupt: number;
  public totalReworkHours: number;
  public total: number;
  public notes: string;
  public calendarEvent: string;
  public calendarEventStatus: string;
  public userId: number;
  public rowColor: string;
  public shiftDescription: string;
}
export class LaborHourDashboard {
  public userId: number;
  public workingHours: number;
  public recordedHours: number;
  public isVerified: boolean;
}
export class LaborHourNotesViewModel {
  public laborHourVerificationId: number;
  public userId: number;
  public currentDate: Date;
  public notes: string;
}
export class LaborHourManagerDataDetails {
  public name: string;
  public percentage: number;
  public lamId: number;
  public userId: number;
}

export class LaborHourManagerData {
  public startDate: Date;
  public endDate: Date;
  public laborHourManagerDataDetails: LaborHourManagerDataDetails[];
}

export class SubmittedLaborHours {
  public beNorPSN: string;
  public directHours: number;
  public inDirectHours: number;
  public isEditable: boolean;
  public laborHourDate: Date;
  public laborHourId: number;
  public totalLaborHours: number;
}

export class LaborHourEditUserDetail {
  public ben: string;
  public userId: number;
  public userName: string;
  public laborHourDate: Date;
  public laborHourLoanToId: number;
  public laborHourTypeId: number;
  public plantId: number;
  public psn: string;
}

export class LaborHourPilotProductIdEdit {
  public pilotProductId: number;
  public beNorPSN: string;
}

export class LaborHourSpecialSubAssemblyPilotProductIdEdit {
  public specialSubAssemblyPilotProductId: number;
  public wopo: string;
}

export class LaborHourValueEdit {
  public bomChange: boolean;
  public isRework: boolean;
  public phase: string;
  public pilotOrSupplierCaused: string;
  public reworkCategory: string;
  public reworkCategoryId: number;
  public laborHourValuesId: number;
  public laborHourId: number;
  public laborTypeId: number;
  public laborHourItemTypeId: number;
  public laborHourValue: number;
  public specialSubAssemblyPilotProductId: number;
  public wopo: string;
}

export class LaborHourEditDisplayModel {
  public isSingleModule: boolean;
  public isMultiSelectModule: boolean;
  public isSpecialSubAssembly: boolean;
  public laborHourEditUserDetail: LaborHourEditUserDetail;
  public laborHourReworks: LaborHourRework[];
  public pilotProductId: LaborHourPilotProductIdEdit[];
  public specialSubAssemblyPilotProductId: LaborHourSpecialSubAssemblyPilotProductIdEdit[];
  public laborHourOtherDropdownId: number;
  public laborHourValueEdits: LaborHourValueEdit[];
}

export class LaborHourRework {
  public bomChange: boolean;
  public laborHourValue: number;
  public phase: string;
  public pilotOrSupplierCaused: string;
  public reworkCategory: string;
  public reworkCategoryId: number;
}

export class LaborHourSummary {
  public laborHourDate: string;
  public recordedHours: number;
  public laborHourVerificationId: number;
  public userName: string;
  public workingHours: number;
  public financeHours: number;
  public utilization: number;
  public directCT: number;
  public interrupts: number;
  public breakLunchInterrupt: number;
  public totalReworkHours: number;
  public total: number;
  public notes: string;
  public calendarEvent: string;
  public calendarEventStatus: string;
  public userId: number;
  public rowColor: string;
  public shiftShortDescription: string;
  public lamHoliday: string;
}

export class LaborHourManagerDetails {
  public lamId: number;
  public userId: number;
  public name: string;
  public verifiedApprovedCount: number;
  public totalCount: number;
  public percentage: number;
  public laborHourManagerSummary: LaborHourSummary[];
}
