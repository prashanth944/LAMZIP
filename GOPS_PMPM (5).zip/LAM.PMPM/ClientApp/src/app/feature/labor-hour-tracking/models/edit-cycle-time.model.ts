export class CycleTimeUpdateViewModel {
    workRecordID: number;
    workRecordInterruptionId: number;
    endMinutes: number;
}
