export class LaborHourValues {
    laborHourValuesId: number;
    laborHourId: number;
    laborTypeId: number;
    laborHourItemTypeId: number;
    laborHourValue: number;
    specialSubAssemblyPilotProductId: number;
    isRework: boolean;
    bomChange: boolean;
    pilotOrSupplierCaused: string;
    reworkCategoryId: number;
    reworkCategory: string;
}

export class LaborHourModuleMapping {
    laborHourModuleMappingId: number;
    laborHourId: number;
    pilotProductId: number;
    isSpecialSubAssembly: boolean;
}

export class LaborHourAddDetails {
    public laborHourValues: LaborHourValues[];
    public laborHourModuleMappings: LaborHourModuleMapping[];
    public laborHourId: number;
    public userId: number;
    public laborHourDate: Date;
    public createdOn: Date;
    public currentDate: Date;
    public createdBy: number;
    public modifiedOn: Date;
    public modifiedBy: number;
    public laborHourTypeId: number;
    public laborHourLoanToId: number;
    public ben: string;
    public psn: string;
    public plantId: number;
}
