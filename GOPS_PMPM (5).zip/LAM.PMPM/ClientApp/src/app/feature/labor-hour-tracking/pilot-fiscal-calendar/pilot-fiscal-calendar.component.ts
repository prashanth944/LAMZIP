import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { AppStoreService } from "../../../core/app-store.service";
import { uiScreen } from "../../../core/model/common.constant";

@Component({
    selector: "pmpm-pilot-fiscal-calendar",
    templateUrl: "./pilot-fiscal-calendar.component.html",
    styleUrls: ["./pilot-fiscal-calendar.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class PilotFiscalCalendarComponent implements OnInit {
    public isUserAccess = false;
    isLoading = true;

    constructor(private appStoreService: AppStoreService) {}

    ngOnInit() {
        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.PFC)
                    .subscribe((result) => {
                        this.isUserAccess = result;
                        this.isLoading = false;
                    });
            }
        });
    }
}
