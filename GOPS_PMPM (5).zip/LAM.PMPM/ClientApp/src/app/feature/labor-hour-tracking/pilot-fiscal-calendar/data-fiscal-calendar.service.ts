import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable } from "rxjs";
import { HttpClient } from "@angular/common/http";
import { environment } from "../../../../environments/environment.dev_server";

@Injectable({
    providedIn: "root",
})
export class DataFiscalCalendarService {
    fiscalCalendarData: BehaviorSubject<any[]> = new BehaviorSubject([]);
    fiscalCalendarToEdit: BehaviorSubject<any> = new BehaviorSubject({});
    isVisibleSource: BehaviorSubject<boolean> = new BehaviorSubject(false);

    readonly apiUrl = `${environment.apiUrl}`;

    constructor(private http: HttpClient) {}

    GetFiscalCalendar() {
        return this.http.get<any[]>(
            this.apiUrl + "/FiscalCalendar/GetFiscalCalendar/"
        );
    }
    AddFiscalCalendar(information: any) {
        return this.http.post<any[]>(
            this.apiUrl + "/FiscalCalendar/AddFiscalCalendar/",
            information
        );
    }
    EditFiscalCalendar(information: any) {
        return this.http.post<any[]>(
            this.apiUrl + "/FiscalCalendar/UpdateFiscalCalendar/",
            information
        );
    }
    DropFiscalCalendar(information: any) {
        return this.http.post<any[]>(
            this.apiUrl + "/FiscalCalendar/DropFiscalCalendar/",
            information
        );
    }
    loadFiscalCalendar() {
        this.GetFiscalCalendar().subscribe((data) => {
            data.forEach(
                (row) => (row["startDate"] = new Date(row["startDate"]))
            );
            data.forEach((row) => (row["endDate"] = new Date(row["endDate"])));
            this.fiscalCalendarData.next(data);
        });
    }
    reLoadFiscalCalendar() {
        const val = this.fiscalCalendarData.getValue();
        if (val.length === 0) {
            this.loadFiscalCalendar();
        } else {
            this.fiscalCalendarData.next(val);
        }
    }
    itemIndex(item: any, data: any[]) {
        for (let idx = 0; idx < data.length; idx++) {
            if (data[idx].id === item.id) {
                return idx;
            }
        }
        return -1;
    }
    AddEditElements(item: any) {
        const items = this.fiscalCalendarData.getValue();
        const index = this.itemIndex(item, items);
        if (index !== -1) {
            items.splice(index, 1, item);
        } else {
            items.push(item);
        }
        this.fiscalCalendarData.next(items);
    }
    removeElements(item: any) {
        const items = this.fiscalCalendarData.getValue();
        const index = this.itemIndex(item, items);
        items.splice(index, 1);
        this.fiscalCalendarData.next(items);
    }
    AddFiscalCalendarRow(info: any) {
        this.AddFiscalCalendar(info)
            .toPromise()
            .then(
                (data: any) => {
                    const rows: any[] = data;
                    rows.forEach((item) => this.AddEditElements(item));
                },
                (error) => {
                    console.error(error);
                }
            );
    }
    UpdateFiscalCalendarRow(info: any) {
        this.EditFiscalCalendar(info)
            .toPromise()
            .then(
                (data: any) => {
                    const rows: any[] = data;
                    rows.forEach((item) => this.AddEditElements(item));
                },
                (error) => {
                    console.error(error);
                }
            );
    }
    DeleteFiscalCalendarRow(info: any) {
        this.removeElements(info);
        this.DropFiscalCalendar(info)
            .toPromise()
            .then(
                (data: any) => {
                    const rows: any[] = data;
                    rows.forEach((item) => this.AddEditElements(item));
                },
                (error) => {
                    console.error(error);
                }
            );
    }

    changeVisibleStatus(state: boolean) {
        this.isVisibleSource.next(state);
    }
    setRowToEdit(item: any) {
        this.fiscalCalendarToEdit.next(item);
    }

    getEventToEdit(): Observable<any> {
        return this.fiscalCalendarToEdit;
    }

    existWwInQuarterForFiscalYear(fiscalYear, quarter, wwInQuarter) {
        let items = this.fiscalCalendarData.getValue();
        const editVal = this.fiscalCalendarToEdit.getValue();
        if (Object.keys(editVal).length) {
            items = items.filter((row) => row["id"] !== editVal["id"]);
        }
        return items.some(
            (row) =>
                row["FiscalYear"] === fiscalYear &&
                row["Quarter"] === quarter &&
                row["WWinQuarter"] === wwInQuarter
        );
    }

    existStartDate(startDate) {
        let items = this.fiscalCalendarData.getValue();
        const editVal = this.fiscalCalendarToEdit.getValue();
        if (Object.keys(editVal).length) {
            items = items.filter((row) => row["id"] !== editVal["id"]);
        }
        return items.some(
            (row) =>
                new Date(row["startDate"]).getTime() ===
                new Date(startDate).getTime()
        );
    }
}
