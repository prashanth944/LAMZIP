import { Component, OnInit } from "@angular/core";
import { DataFiscalCalendarService } from "../data-fiscal-calendar.service";
import { map } from "rxjs/operators";
import { process, State } from "@progress/kendo-data-query";
import { Observable } from "rxjs";
import {
    DataStateChangeEvent,
    GridDataResult,
} from "@progress/kendo-angular-grid";

@Component({
    selector: "app-fiscal-calendar-report-table",
    templateUrl: "./fiscal-calendar-report-table.component.html",
    styleUrls: ["./fiscal-calendar-report-table.component.css"],
})
export class FiscalCalendarReportTableComponent implements OnInit {
    constructor(private dataService: DataFiscalCalendarService) {}

    public gridData: any[] = [];
    public view: Observable<GridDataResult>;

    public AllFiscalYear: Observable<any>;
    public SelFiscalYear: any;

    public AllQuarters: Observable<any>;
    public SelQuarter: any;

    public confirmDialogBool = false;
    public itemSelected: any = {};
    public newState: any = "A";

    public pageSize = 20;
    public skip = 0;

    public gridState: State = {
        skip: 0,
        take: 20,
        // Initial filter descriptor
        sort: [{ field: "startDate", dir: "asc" }],
        filter: {
            logic: "and",
            filters: [],
        },
    };

    ngOnInit(): void {
        this.loadDataFromBk();
    }

    loadDataFromBk() {
        this.view = this.dataService.fiscalCalendarData.pipe(
            map((data) => process(data, this.gridState))
        );

        this.AllFiscalYear = this.dataService.fiscalCalendarData.pipe(
            map((data) =>
                this.GetUniques(data, "FiscalYear").sort(
                    (n1, n2) => n1.value - n2.value
                )
            )
        );

        this.AllQuarters = this.dataService.fiscalCalendarData.pipe(
            map((data) =>
                this.GetUniques(data, "Quarter").sort(
                    (n1, n2) => n1.value - n2.value
                )
            )
        );

        this.dataService.reLoadFiscalCalendar();
    }

    public GetUniques(data: any[], colName: string) {
        return data
            .map((item) => item[colName])
            .filter(
                (value, index, self) =>
                    self.indexOf(value) === index && value !== null
            )
            .map((val) => ({ text: val, value: val }));
    }

    updateFromFilter() {
        this.gridState["filter"].filters = this.gridState[
            "filter"
        ].filters.filter((f) => f["field"] !== "FiscalYear");
        this.gridState["filter"].filters = this.gridState[
            "filter"
        ].filters.filter((f) => f["field"] !== "Quarter");
        this.gridState["skip"] = 0;

        if (this.SelFiscalYear && this.SelFiscalYear.value !== "") {
            this.gridState["filter"].filters.push({
                field: "FiscalYear",
                operator: "eq",
                value: this.SelFiscalYear.value,
            });
        }

        if (this.SelQuarter && this.SelQuarter.value !== "") {
            this.gridState["filter"].filters.push({
                field: "Quarter",
                operator: "eq",
                value: this.SelQuarter.value,
            });
        }

        this.dataService.reLoadFiscalCalendar();
    }

    cleanFilter() {
        this.SelFiscalYear = undefined;
        this.SelQuarter = undefined;
        this.updateFromFilter();
    }
    public openNew() {
        this.dataService.setRowToEdit({});
        this.dataService.changeVisibleStatus(true);
    }

    public editItem(item: any) {
        this.dataService.setRowToEdit(item);
        this.dataService.changeVisibleStatus(true);
    }
    public openConfirm(info: any, newState: any) {
        this.itemSelected = info;
        this.newState = newState;
        this.confirmDialogBool = true;
    }
    closeConfirmDialog(label: string) {
        if (label === "yes") {
            if (this.newState === "Drop") {
                this.dataService.DeleteFiscalCalendarRow(this.itemSelected);
            }
            this.confirmDialogBool = false;
        } else {
            this.confirmDialogBool = false;
        }
    }
    public dataStateChange(state: DataStateChangeEvent): void {
        this.gridState = state;
        this.gridState["sort"] = [{ field: "startDate", dir: "asc" }];
        this.dataService.reLoadFiscalCalendar();
    }
}
