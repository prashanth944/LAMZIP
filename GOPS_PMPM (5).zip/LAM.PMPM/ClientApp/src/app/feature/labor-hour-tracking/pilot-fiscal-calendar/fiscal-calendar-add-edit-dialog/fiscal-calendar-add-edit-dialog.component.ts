import { Component, OnInit } from "@angular/core";
import { DataFiscalCalendarService } from "../data-fiscal-calendar.service";
import { FormControl, FormGroup, Validators } from "@angular/forms";

export function canInsertValueWwInQuarter(
    dataService: DataFiscalCalendarService
) {
    return (formGroup: FormGroup) => {
        const yearControl = formGroup.controls["FiscalYear"];
        const quarterControl = formGroup.controls["Quarter"];
        const wwInQuarterControl = formGroup.controls["WWinQuarter"];

        if (
            wwInQuarterControl.errors &&
            !wwInQuarterControl.errors.invalidValue
        ) {
            // return if another validator has already found an error on the wwInQuarterControl
            return;
        }

        // set error on matchingControl if validation fails
        if (
            dataService.existWwInQuarterForFiscalYear(
                yearControl.value,
                quarterControl.value,
                wwInQuarterControl.value
            )
        ) {
            wwInQuarterControl.setErrors({ invalidValue: true });
        } else {
            wwInQuarterControl.setErrors(null);
        }
        return null;
    };
}

export function canInsertValueStartDate(
    dataService: DataFiscalCalendarService
) {
    return (formGroup: FormGroup) => {
        const startDateControl = formGroup.controls["StartDate"];

        if (startDateControl.errors && !startDateControl.errors.invalidValue) {
            // return if another validator has already found an error on the wwInQuarterControl
            return;
        }
        if (startDateControl.value) {
            // set error on matchingControl if validation fails
            if (dataService.existStartDate(startDateControl.value)) {
                startDateControl.setErrors({ invalidValue: true });
            } else {
                startDateControl.setErrors(null);
            }
        }
        return null;
    };
}

@Component({
    selector: "app-fiscal-calendar-add-edit-dialog",
    templateUrl: "./fiscal-calendar-add-edit-dialog.component.html",
    styleUrls: ["./fiscal-calendar-add-edit-dialog.component.css"],
})
export class FiscalCalendarAddEditDialogComponent implements OnInit {
    constructor(private dataService: DataFiscalCalendarService) {}
    public opened = false;
    addStatusBool = true; // true means new, false means update
    private fiscalCalendarRowId = 0;

    public registerForm: FormGroup = new FormGroup(
        {
            FiscalYear: new FormControl({}, [
                Validators.required,
                Validators.min(2015),
                Validators.max(2999),
            ]),
            Quarter: new FormControl({ value: undefined, disabled: false }, [
                Validators.min(1),
                Validators.max(4),
                Validators.required,
            ]),
            WWinQuarter: new FormControl({}, [
                Validators.required,
                Validators.min(1),
                Validators.max(14),
            ]),
            StartDate: new FormControl(new Date(2022, 4, 4), [
                Validators.required,
            ]),
            EndDate: new FormControl({ value: null, disabled: true }),
        },
        {
            validators: [
                canInsertValueWwInQuarter(this.dataService),
                canInsertValueStartDate(this.dataService),
            ],
        }
    );

    ngOnInit(): void {
        this.dataService.isVisibleSource.subscribe((isVisible) => {
            this.opened = isVisible;
        });

        this.dataService.getEventToEdit().subscribe((item) => {
            if (Object.keys(item).length) {
                this.addStatusBool = false;
                this.updateFormValues(item);
            } else {
                this.addStatusBool = true;
                this.clearForm();
            }
        });
    }
    public close() {
        this.dataService.changeVisibleStatus(false);
        if (this.addStatusBool) {
            this.clearForm();
        }
    }

    public submitForm(): void {
        const metaData = this.registerForm.getRawValue();

        const getDateWithOutTimeZone = (dateToProcess: Date) => {
            return new Date(
                dateToProcess.getTime() -
                    dateToProcess.getTimezoneOffset() * 60000
            )
                .toISOString()
                .slice(0, 10);
        };

        metaData["EndDate"] = getDateWithOutTimeZone(metaData["EndDate"]);
        metaData["StartDate"] = getDateWithOutTimeZone(metaData["StartDate"]);

        if (this.addStatusBool) {
            // true means is a new object
            this.dataService.AddFiscalCalendarRow(metaData);
        } else {
            metaData["id"] = this.fiscalCalendarRowId;
            this.dataService.UpdateFiscalCalendarRow(metaData);
        }

        this.dataService.changeVisibleStatus(false);
    }

    updateFormValues(item: any) {
        this.registerForm.setValue({
            FiscalYear: item["FiscalYear"],
            Quarter: item["Quarter"],
            WWinQuarter: item["WWinQuarter"],
            StartDate: new Date(item["startDate"]),
            EndDate: new Date(item["endDate"]),
        });
        this.fiscalCalendarRowId = item["id"];
    }

    public clearForm(): void {
        this.registerForm.reset();
    }

    isMonday(date: Date) {
        return date.getDay() === 1;
    }

    public disabledDates = (date: Date): boolean => {
        return !this.isMonday(date);
    };

    updateEndDate() {
        const startDateControl = this.registerForm.controls["StartDate"];
        const endDateControl = this.registerForm.controls["EndDate"];
        const stDate = new Date(startDateControl.value);
        if (stDate) {
            stDate.setDate(stDate.getDate() + 6);
            endDateControl.setValue(stDate);
        } else {
            endDateControl.setValue(null);
        }
    }
}
