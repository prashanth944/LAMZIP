import { Component, OnInit } from "@angular/core";
import { AppStoreService } from "../../core/app-store.service";
import { uiScreen } from "../../core/model/common.constant";

@Component({
    selector: "pmpm-labor-hour-tracking",
    templateUrl: "./labor-hour-tracking.component.html",
    styleUrls: ["./labor-hour-tracking.component.css"],
})
export class LaborHourTrackingComponent implements OnInit {
    public isUserAccess = false;
    isLoading = true;

    constructor(private appStoreService: AppStoreService) {}

    ngOnInit() {
        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.LHNT)
                    .subscribe((result) => {
                        this.isUserAccess = result;
                        this.isLoading = false;
                    });
            }
        });
    }
}
