import {
  Component,
  OnInit,
  ViewChild,
  ViewContainerRef,
  ViewEncapsulation,
} from "@angular/core";
import { AppStoreService } from "../../../core/app-store.service";
import { role, uiScreen } from "../../../core/model/common.constant";
import { Plant, UserModel } from "../../../core/model/user.model";
import {
  LaborHoursItem,
  LaborHoursItemForMultipleBENorPSN,
  PSNorBEN,
  LaborHoursType,
  LaborHoursTypeForLaborHours,
  LaborHourLoanTo,
  LaborHourForToday,
} from "../models/add-labor-hours.model";
import { LaborHourTrackingService } from "../service/labor-hour-tracking.service";
import { EditService } from "../../service/edit.service";
import { FormBuilder, FormGroup } from "@angular/forms";
import { MultiSelectComponent } from "@progress/kendo-angular-dropdowns";
import { SpecialSubassemblyGrid } from "../models/specialSubassemblyGrid";
import { State } from "@progress/kendo-data-query";
import {
  LaborHourAddDetails,
  LaborHourModuleMapping,
  LaborHourValues,
} from "../models/addLaborHour";
import { TooltipDirective } from "@progress/kendo-angular-tooltip";
import { NotificationService } from "@progress/kendo-angular-notification";
import { ActivatedRoute, Router } from "@angular/router";
import { ReworkCategoryViewModel } from "../../execution-and-tracking/Models/ModuleSummary";
import { LaborHourEditDisplayModel } from "../models/verify-labor-hours.model";
import * as moment from "moment";

interface ReworkLaborHour {
  isAssembly: boolean;
  isTest: boolean;
  isBOMChange: boolean;
  isNOtBOMChange: boolean;
  isReworkPilot: boolean;
  isReworkSupplier: boolean;
  reworkCategory: ReworkCategoryViewModel;
  timeSpent: number;
}

@Component({
  selector: "pmpm-add-labor-hours",
  templateUrl: "./add-labor-hours.component.html",
  styleUrls: ["./add-labor-hours.component.css"],
  encapsulation: ViewEncapsulation.None,
})
export class AddLaborHoursComponent implements OnInit {
  @ViewChild("multiselect") public multiselect: MultiSelectComponent;
  @ViewChild(TooltipDirective) public tooltipDir: TooltipDirective;
  @ViewChild("appendTo", { read: ViewContainerRef })
  public appendTo: ViewContainerRef;

  //access
  isUserAccess = false;
  canEdit = false;
  canEditSMSN = false;
  isSaveEnabled = false;
  cellOpen = false;
  isLoading = true;
  public site: Plant;
  userDetail: UserModel;

  public minDate: Date = new Date();
  public maxDate: Date = new Date(new Date().setHours(23, 59, 59, 0));
  public laborHourDate: Date = new Date();
  public todayLaborHourDate: Date = new Date();
  public isMultiplePSN = false;
  public PSNorBEN: PSNorBEN[] = [];
  public psnORbenDefaultItem: PSNorBEN = {
    pilotProductID: 0,
    pilotSerialNumber: "",
    ben: "",
    buildStyle: "",
  };
  public reworkCategoryDefaultItem: ReworkCategoryViewModel = {
    category: "",
    id: null,
  };
  public psnValue: PSNorBEN;
  public benValue: PSNorBEN;
  public PSNorBENDataItem: PSNorBEN[] = [];
  public laborHourTypes: LaborHoursType[] = [];
  public laborHourTypeForLaborHours: LaborHoursTypeForLaborHours[] = [];
  public selectedLaborHours: LaborHoursTypeForLaborHours;
  public reworkGridData: ReworkLaborHour[] = [];
  public openReworkPopup = false;
  public assemblyRegular: number;
  public testRegular: number;
  public assemblyTroubleshooting: number;
  public testTroubleshooting: number;
  public assemblyQualityAssurance: number;
  public testQualityAssurance: number;
  public miscAdmin: number;
  public miscTraining: number;
  public miscBreak: number;
  public laborHourItems: LaborHoursItem[] = [];
  public reworkCategories: ReworkCategoryViewModel[];
  public reworkCategory: ReworkCategoryViewModel;
  public reworkLH: ReworkLaborHour;
  public wopoDDL: any[] = [];
  public tempwopoDDL: any[] = [];
  wopoValue: any[] = [];
  public toolBENHoverMsg = "Put the project name if no BEN is available.";
  public toolPSNHoverMsg =
    "Put the project name if no Pilot Serial Number is available.";
  laborHoursItemForMultipleBENorPSN: LaborHoursItemForMultipleBENorPSN[] = [];
  specialSubassemblyGridData: any[] = [];
  specialSubassemblyGridData2: any[] = [];
  public gridState: State = {
    skip: 0,
    take: 50,
  };
  wopoSelected: string[] = [];
  pilotProductIDSelected: number[] = [];
  loanToData: LaborHourLoanTo[] = [];
  loanTo: LaborHourLoanTo;
  toolBenProject = "";
  public hoverMessage = "";
  public adminHoverMsg =
    "Total hours spent using IQMS, creating issue logs, researching materials including tracking parts, working on collateral duty and writing/reviewing passdowns, and tracking shortages. THIS IS NOT CATCH ALL LH BUCKET,REVIEW ALL OTHER CATAGORIES!!!";
  public trainingHoverMsg =
    "Time spent in class training including web based training courses - Not OJT, OJT is direct labor.";
  public splSubassyHoverMsg =
    "Time spent on to be used by etch sub-assemblies (WC303) and Mechatronics teams";
  public standardHours = 0;
  public reworkdHours = 0;
  public totalHours = 0;
  public laborHourId: number;
  public editlaborHourData: LaborHourEditDisplayModel;
  public isEditMode = false;
  public userName = "";
  public laborHourForToday: LaborHourForToday;
  public totalHoursForSubAssemblies = 0;

  public isChangedStandardHours = false;
  public isChangedReworkedHours = false;
  public oldStandardHours = 0;
  public oldReworkedHours = 0;
  public max = 13;
  public maxShiftHours = 13;

  constructor(
    private appStoreService: AppStoreService,
    private service: LaborHourTrackingService,
    private editService: EditService,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private notificationService: NotificationService,
    private router: Router,
  ) { }

  ngOnInit() {
    this.route.params.subscribe((param) => {
      this.laborHourId = +param.laborHourId;
    });
    this.appStoreService.getUserRoles().subscribe((res) => {
      if (res && res.length > 0) {
        if (res) {
          this.appStoreService
            .checkUserAccessRight(res, uiScreen.AddLH)
            .subscribe((result) => {
              this.isUserAccess = result;
              if (this.isUserAccess) {
                if (
                  res.includes(role.Technician) ||
                  res.includes(role.Leads) ||
                  res.includes(role.PassTeamMember) ||
                  res.includes(role.SuperUser)
                ) {
                  this.canEdit = true;
                }
                if (
                  res.includes(role.Leads) ||
                  res.includes(role.PassTeamMember) ||
                  res.includes(role.SuperUser)
                ) {
                  this.canEditSMSN = true;
                }
              }
              this.isLoading = false;
            });
        }
      }
    });

    this.appStoreService.getCurrentSite().subscribe((site) => {
      if (site) {
        this.site = {
          plantName: site.plantName,
          plantId: site.plantId,
        };
        this.max = this.site.plantName === "Fremont" ? 14 : 13;
        this.maxShiftHours =
          this.site.plantName === "Fremont" ? 16 : 13;
        this.resetWorkInPilotHours();
        this.GetLaborHourTypeForLaborHours(this.site.plantId);
        this.getDropdownValues();
        this.getReworkCategory();
        this.setDatePickerDates();
        this.appStoreService.getLoggedInUser().subscribe((user) => {
          let date: any = new Date();
          date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
          this.appStoreService
            .getUserDetails(user.mail, date)
            .subscribe((res) => {
              if (res) {
                this.userDetail = res;
                this.userName =
                  this.userDetail.firstName +
                  " " +
                  this.userDetail.lastName;
                this.totalHours = this.userDetail.hoursPerDay;
                this.service
                  .GetLaborhoursSubmittedForToday(
                    this.userDetail.userId,
                    this.site.plantId,
                    this.userDetail.shiftID,
                    date
                  )
                  .subscribe((res) => {
                    if (res && res.length > 0) {
                      this.laborHourForToday = res[0];
                    }
                  });
                if (
                  this.laborHourId !== null &&
                  this.laborHourId !== undefined &&
                  !Number.isNaN(this.laborHourId)
                ) {
                  this.isEditMode = true;
                  this.GetLaborHoursData();
                } else {
                  this.getLaborHourItems();
                  this.getLaborHourLoanTo();
                  this.getLabourHourTypes();
                  this.appStoreService
                    .getMultipleBENForLH()
                    .subscribe((res) => {
                      if (res && res.length > 0) {
                        this.isMultiplePSN = true;
                        this.PSNorBENDataItem = res;
                        this.onSelectPSNorBEN();
                        this.getLaborHourItemsForMultipleBENorPSN();
                      }
                    });
                  this.appStoreService
                    .getCurrentBENForLH()
                    .subscribe((ben) => {
                      if (ben) {
                        this.psnValue = ben;
                      }
                    });
                }
              }
            });
        });
      }
    });
  }

  GetLaborHoursData() {
    this.service.GetLaborHoursById(this.laborHourId).subscribe((res) => {
      if (res) {
        this.editlaborHourData = res;
        this.userName =
          this.editlaborHourData.laborHourEditUserDetail.userName;
        this.laborHourDate = new Date(
          this.editlaborHourData.laborHourEditUserDetail.laborHourDate
        );
        if (this.editlaborHourData.isMultiSelectModule) {
          this.isMultiplePSN = true;
          this.editlaborHourData.pilotProductId?.forEach((item) => {
            this.PSNorBENDataItem.push({
              pilotProductID: item.pilotProductId,
              ben:
                this.site.plantName !== "Fremont"
                  ? item.beNorPSN
                  : null,
              pilotSerialNumber:
                this.site.plantName === "Fremont"
                  ? item.beNorPSN
                  : null,
              buildStyle: "",
            });
          });
          this.laborHoursItemForMultipleBENorPSN = [];
          this.getLaborHourItemsForMultipleBENorPSN();
        } else if (this.editlaborHourData.isSingleModule) {
          this.laborHourTypeForLaborHours = [];
          this.service
            .GetLaborHourTypeForLaborHours(this.site.plantId)
            .subscribe((res) => {
              if (res && res.length > 0) {
                this.laborHourTypeForLaborHours = res;
                this.selectedLaborHours =
                  this.laborHourTypeForLaborHours.filter(
                    (item) =>
                      item.laborHourTypeId ===
                      this.editlaborHourData
                        .laborHourEditUserDetail
                        .laborHourTypeId
                  )[0];
              }
            });
          this.psnValue = {
            pilotProductID:
              this.editlaborHourData.pilotProductId[0]
                .pilotProductId,
            ben:
              this.site.plantName !== "Fremont"
                ? this.editlaborHourData.pilotProductId[0]
                  .beNorPSN
                : null,
            pilotSerialNumber:
              this.site.plantName === "Fremont"
                ? this.editlaborHourData.pilotProductId[0]
                  .beNorPSN
                : null,
            buildStyle: "",
          };
          this.getStandardAndReworkData();
        } else if (
          !this.editlaborHourData.isMultiSelectModule &&
          !this.editlaborHourData.isSingleModule &&
          !this.editlaborHourData.isSpecialSubAssembly
        ) {
          this.laborHourTypeForLaborHours = [];
          this.service
            .GetLaborHourTypeForLaborHours(this.site.plantId)
            .subscribe((res) => {
              if (res && res.length > 0) {
                this.laborHourTypeForLaborHours = res;
                this.selectedLaborHours =
                  this.laborHourTypeForLaborHours.filter(
                    (item) =>
                      item.laborHourTypeId ===
                      this.editlaborHourData
                        .laborHourEditUserDetail
                        .laborHourTypeId
                  )[0];
                if (
                  this.selectedLaborHours.optionName ===
                  "Pilot Outsourcing Labor"
                ) {
                  this.service
                    .GetLaborHourLoanTo(this.site?.plantId)
                    .subscribe((res) => {
                      if (res && res.length > 0) {
                        this.loanToData = res;
                        this.loanTo =
                          this.loanToData.filter(
                            (item) =>
                              item.laborHourLoanToId ===
                              this
                                .editlaborHourData
                                .laborHourEditUserDetail
                                .laborHourLoanToId
                          )[0];
                      }
                    });
                  this.toolBenProject =
                    this.site.plantName === "Fremont"
                      ? this.editlaborHourData
                        .laborHourEditUserDetail.psn
                      : this.editlaborHourData
                        .laborHourEditUserDetail.ben;
                  this.laborHoursItemForMultipleBENorPSN = [];
                  this.getLaborHourItemsForMultipleBENorPSN();
                } else if (
                  this.selectedLaborHours.optionName ===
                  "On Quarantine"
                ) {
                  this.laborHoursItemForMultipleBENorPSN = [];
                  this.getLaborHourItemsForMultipleBENorPSN();
                }
              }
            });
        } else if (this.editlaborHourData.isSpecialSubAssembly) {
          this.wopoValue = [];
          this.selectedLaborHours =
            this.laborHourTypeForLaborHours?.filter(
              (item) =>
                item.laborHourTypeId ===
                this.editlaborHourData.laborHourEditUserDetail
                  .laborHourTypeId
            )[0];
          this.editlaborHourData.specialSubAssemblyPilotProductId.forEach(
            (item) => {
              this.wopoValue.push({
                pilotProductID:
                  item.specialSubAssemblyPilotProductId,
                pilotSerialNumber: item.wopo,
              });
            }
          );
          this.wopoDDLChange(this.wopoValue);
        }

        this.isSaveEnabled = false;
      }
    });
  }

  getStandardAndReworkData() {
    this.laborHourTypes = [];
    this.laborHourItems = [];
    this.service.GetLaborHourTypes().subscribe((res) => {
      if (res && res.length > 0) {
        this.laborHourTypes = res;
        this.service.GetLaborHourItems("Standard").subscribe((r) => {
          if (r && r.length > 0) {
            this.laborHourItems = r;
            if (
              this.editlaborHourData.laborHourValueEdits &&
              this.editlaborHourData.laborHourValueEdits.length >
              0
            ) {
              this.editlaborHourData.laborHourValueEdits?.forEach(
                (item) => {
                  if (
                    item.laborTypeId ===
                    this.laborHourTypes.filter(
                      (x) =>
                        x.laborTypeName ===
                        "Assembly"
                    )[0].laborTypeID &&
                    item.laborHourItemTypeId ===
                    this.laborHourItems.filter(
                      (item) =>
                        item.optionName ===
                        "Regular"
                    )[0].laborHourItemTypeId
                  ) {
                    this.assemblyRegular =
                      item.laborHourValue;
                  }
                  if (
                    item.laborTypeId ===
                    this.laborHourTypes.filter(
                      (x) =>
                        x.laborTypeName === "Test"
                    )[0].laborTypeID &&
                    item.laborHourItemTypeId ===
                    this.laborHourItems.filter(
                      (item) =>
                        item.optionName ===
                        "Regular"
                    )[0].laborHourItemTypeId
                  ) {
                    this.testRegular = item.laborHourValue;
                  }
                  if (
                    item.laborTypeId ===
                    this.laborHourTypes.filter(
                      (x) =>
                        x.laborTypeName ===
                        "Assembly"
                    )[0].laborTypeID &&
                    item.laborHourItemTypeId ===
                    this.laborHourItems.filter(
                      (item) =>
                        item.optionName ===
                        "Troubleshooting"
                    )[0].laborHourItemTypeId
                  ) {
                    this.assemblyTroubleshooting =
                      item.laborHourValue;
                  }
                  if (
                    item.laborTypeId ===
                    this.laborHourTypes.filter(
                      (x) =>
                        x.laborTypeName === "Test"
                    )[0].laborTypeID &&
                    item.laborHourItemTypeId ===
                    this.laborHourItems.filter(
                      (item) =>
                        item.optionName ===
                        "Troubleshooting"
                    )[0].laborHourItemTypeId
                  ) {
                    this.testTroubleshooting =
                      item.laborHourValue;
                  }
                  if (
                    item.laborTypeId ===
                    this.laborHourTypes.filter(
                      (x) =>
                        x.laborTypeName ===
                        "Assembly"
                    )[0].laborTypeID &&
                    item.laborHourItemTypeId ===
                    this.laborHourItems.filter(
                      (item) =>
                        item.optionName ===
                        "Quality Assurance"
                    )[0].laborHourItemTypeId
                  ) {
                    this.assemblyQualityAssurance =
                      item.laborHourValue;
                  }
                  if (
                    item.laborTypeId ===
                    this.laborHourTypes.filter(
                      (x) =>
                        x.laborTypeName === "Test"
                    )[0].laborTypeID &&
                    item.laborHourItemTypeId ===
                    this.laborHourItems.filter(
                      (item) =>
                        item.optionName ===
                        "Quality Assurance"
                    )[0].laborHourItemTypeId
                  ) {
                    this.testQualityAssurance =
                      item.laborHourValue;
                  }
                  if (
                    item.laborTypeId ===
                    this.laborHourTypes.filter(
                      (x) =>
                        x.laborTypeName ===
                        "Misc Hours"
                    )[0].laborTypeID &&
                    item.laborHourItemTypeId ===
                    this.laborHourItems.filter(
                      (item) =>
                        item.optionName === "Admin"
                    )[0].laborHourItemTypeId
                  ) {
                    this.miscAdmin = item.laborHourValue;
                  }
                  if (
                    item.laborTypeId ===
                    this.laborHourTypes.filter(
                      (x) =>
                        x.laborTypeName ===
                        "Misc Hours"
                    )[0].laborTypeID &&
                    item.laborHourItemTypeId ===
                    this.laborHourItems.filter(
                      (item) =>
                        item.optionName === "Break"
                    )[0].laborHourItemTypeId
                  ) {
                    this.miscBreak = item.laborHourValue;
                  }
                  if (
                    item.laborTypeId ===
                    this.laborHourTypes.filter(
                      (x) =>
                        x.laborTypeName ===
                        "Misc Hours"
                    )[0].laborTypeID &&
                    item.laborHourItemTypeId ===
                    this.laborHourItems.filter(
                      (item) =>
                        item.optionName ===
                        "Training"
                    )[0].laborHourItemTypeId
                  ) {
                    this.miscTraining = item.laborHourValue;
                  }
                }
              );
              this.standardHours = 0;
              this.standardHours =
                (this.assemblyRegular !== undefined &&
                  this.assemblyRegular !== null
                  ? this.assemblyRegular
                  : 0) +
                (this.testRegular !== undefined &&
                  this.testRegular !== null
                  ? this.testRegular
                  : 0) +
                (this.assemblyTroubleshooting !== undefined &&
                  this.assemblyTroubleshooting !== null
                  ? this.assemblyTroubleshooting
                  : 0) +
                (this.testTroubleshooting !== undefined &&
                  this.testTroubleshooting !== null
                  ? this.testTroubleshooting
                  : 0) +
                (this.assemblyQualityAssurance !== undefined &&
                  this.assemblyQualityAssurance !== null
                  ? this.assemblyQualityAssurance
                  : 0) +
                (this.testQualityAssurance !== undefined &&
                  this.testQualityAssurance !== null
                  ? this.testQualityAssurance
                  : 0) +
                (this.miscAdmin !== undefined &&
                  this.miscAdmin !== null
                  ? this.miscAdmin
                  : 0) +
                (this.miscBreak !== undefined &&
                  this.miscBreak !== null
                  ? this.miscBreak
                  : 0) +
                (this.miscTraining !== undefined &&
                  this.miscTraining !== null
                  ? this.miscTraining
                  : 0);
              this.oldStandardHours = this.standardHours;
            }
            if (
              this.editlaborHourData.laborHourReworks &&
              this.editlaborHourData.laborHourReworks.length > 0
            ) {
              this.reworkCategories = [];
              this.reworkGridData = [];
              this.reworkdHours = 0;
              this.service
                .getReworkCategory()
                .subscribe((res) => {
                  if (res.length > 0) {
                    this.reworkCategories = res;
                    this.editlaborHourData.laborHourReworks?.forEach(
                      (item) => {
                        const reworkLH: ReworkLaborHour =
                        {
                          isAssembly:
                            item.phase ===
                              "Assembly"
                              ? true
                              : false,
                          isTest:
                            item.phase ===
                              "Test"
                              ? true
                              : false,
                          isBOMChange:
                            item.bomChange,
                          isNOtBOMChange:
                            !item.bomChange,
                          isReworkPilot:
                            item.pilotOrSupplierCaused ===
                              "P"
                              ? true
                              : false,
                          isReworkSupplier:
                            item.pilotOrSupplierCaused ===
                              "S"
                              ? true
                              : false,
                          reworkCategory:
                            this.reworkCategories.filter(
                              (x) =>
                                x.id ===
                                item.reworkCategoryId
                            )[0],
                          timeSpent:
                            item.laborHourValue,
                        };

                        this.reworkGridData.push(
                          reworkLH
                        );
                        this.reworkdHours +=
                          reworkLH.timeSpent;
                      }
                    );
                    this.oldReworkedHours =
                      this.reworkdHours;
                  }
                });
            }
          }
        });
      }
    });
  }

  getLaborHourLoanTo() {
    this.loanToData = [];
    this.service.GetLaborHourLoanTo(this.site?.plantId).subscribe((res) => {
      if (res && res.length > 0) {
        this.loanToData = res;
        this.loanTo = this.loanToData[0];
      }
    });
  }

  getReworkCategory() {
    this.reworkCategories = [];
    this.service.getReworkCategory().subscribe((res) => {
      if (res.length > 0) {
        this.reworkCategories = res;
        this.reworkCategory = this.reworkCategories[0];
      }
    });
  }

  getLabourHourTypes() {
    this.laborHourTypes = [];
    this.service.GetLaborHourTypes().subscribe((res) => {
      if (res && res.length > 0) {
        this.laborHourTypes = res;
      }
    });
  }

  GetLaborHourTypeForLaborHours(plantId: number) {
    this.laborHourTypeForLaborHours = [];
    this.service.GetLaborHourTypeForLaborHours(plantId).subscribe((res) => {
      if (res && res.length > 0) {
        this.laborHourTypeForLaborHours = res;
        this.selectedLaborHours = this.laborHourTypeForLaborHours[0];
      }
    });
  }

  getDropdownValues() {
    this.service.GetPSNOrBEN(this.site.plantId, "", "").subscribe((res) => {
      if (res && res.length > 0) {
        let data: any = JSON.parse(JSON.stringify(res));
        if (this.site?.plantName !== "Fremont") {
          data = data.flatMap((f) => (f?.ben ? [f] : []));
          data.sort(function (a, b) {
            const textA = a?.ben?.toUpperCase();
            const textB = b?.ben?.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
          });
        } else {
          data = data.flatMap((f) =>
            f?.pilotSerialNumber ? [f] : []
          );
          data.sort(function (a, b) {
            const textA = a?.pilotSerialNumber?.toUpperCase();
            const textB = b?.pilotSerialNumber?.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
          });
        }
        this.PSNorBEN = JSON.parse(JSON.stringify(data));
      }
    });
  }

  isMultiplePSNSelected() {
    this.isMultiplePSN = !this.isMultiplePSN;
    this.psnValue = this.psnORbenDefaultItem;
    this.PSNorBENDataItem = [];
    this.totalHours = this.userDetail?.hoursPerDay;
    this.isSaveEnabled = true;
    this.selectedLaborHours = this.laborHourTypeForLaborHours[0];
    if (this.isMultiplePSN) {
      this.getLaborHourItemsForMultipleBENorPSN();
    }
  }

  searchPSN(value: string) {
    this.PSNorBEN = [];
    this.service
      .GetPSNOrBEN(this.site.plantId, value, "psn")
      .subscribe((res) => {
        if (res && res.length > 0) {
          let data: any = JSON.parse(JSON.stringify(res));
          data = data.flatMap((f) =>
            f?.pilotSerialNumber ? [f] : []
          );
          data.sort(function (a, b) {
            const textA = a?.pilotSerialNumber?.toUpperCase();
            const textB = b?.pilotSerialNumber?.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
          });
          this.PSNorBEN = JSON.parse(JSON.stringify(data));
        }
      });
  }
  searchBEN(value: string) {
    this.PSNorBEN = [];
    this.service
      .GetPSNOrBEN(this.site.plantId, value, "ben")
      .subscribe((res) => {
        if (res && res.length > 0) {
          let data: any = JSON.parse(JSON.stringify(res));
          data = data.flatMap((f) => (f?.ben ? [f] : []));
          data.sort(function (a, b) {
            const textA = a?.ben?.toUpperCase();
            const textB = b?.ben?.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
          });
          this.PSNorBEN = JSON.parse(JSON.stringify(data));
        }
      });
  }

  getLaborHourItems() {
    this.laborHourItems = [];
    this.service.GetLaborHourItems("Standard").subscribe((res) => {
      if (res && res.length > 0) {
        this.laborHourItems = res;
      }
    });
  }

  onSave() {
    const laborHourModuleMappings: LaborHourModuleMapping[] = [];
    const laborHourValues: LaborHourValues[] = [];
    if (this.isMultiplePSN) {
      const req = new LaborHourAddDetails();
      const date = JSON.parse(JSON.stringify(this.laborHourDate));
      new Date(date).setHours(0, 0, 0, 0);
      if (new Date(date) < new Date(new Date().setHours(0, 0, 0, 0))) {
        this.laborHourDate.setHours(0, 0, 0, 0);
        const totalMinutes =
          this.userDetail?.shiftStartTime?.hours * 60 +
          this.userDetail?.shiftStartTime?.minutes;
        this.laborHourDate = new Date(
          this.laborHourDate.getTime() + totalMinutes * 60000
        );
      }
      if (!this.isEditMode) {
        req.createdBy = this.userDetail?.userId;
        req.createdOn = new Date(
          new Date(this.laborHourDate).getTime() -
          new Date(this.laborHourDate).getTimezoneOffset() * 60000
        );
      }
      req.userId = this.userDetail?.userId;
      req.currentDate = new Date(
        new Date(Date.now()).getTime() -
        new Date(Date.now()).getTimezoneOffset() * 60000
      );
      req.modifiedOn = new Date(
        new Date().getTime() - new Date().getTimezoneOffset() * 60000
      );
      req.modifiedBy = this.userDetail?.userId;
      req.laborHourDate = new Date(
        new Date(this.laborHourDate).getTime() -
        new Date(this.laborHourDate).getTimezoneOffset() * 60000
      );
      req.laborHourId = this.isEditMode ? this.laborHourId : null;
      req.laborHourTypeId = null;
      req.laborHourValues = [];
      req.plantId = this.site?.plantId;
      if (this.isEditMode) {
        req.laborHourValues.push({
          laborHourValuesId:
            this.editlaborHourData.laborHourValueEdits[0]
              .laborHourValuesId,
          laborHourId:
            this.editlaborHourData.laborHourValueEdits[0]
              .laborHourId,
          laborTypeId:
            this.editlaborHourData.laborHourValueEdits[0]
              .laborTypeId,
          laborHourItemTypeId:
            this.laborHoursItemForMultipleBENorPSN[0]
              ?.laborHourItemTypeId,
          laborHourValue:
            this.laborHoursItemForMultipleBENorPSN[0]?.hoursPerDay,
          specialSubAssemblyPilotProductId: null,
          isRework: null,
          bomChange: null,
          pilotOrSupplierCaused: null,
          reworkCategoryId: null,
          reworkCategory: null,
        });
      } else {
        req.laborHourValues.push({
          laborHourValuesId: null,
          laborHourId: null,
          laborTypeId: null,
          laborHourItemTypeId:
            this.laborHoursItemForMultipleBENorPSN[0]
              ?.laborHourItemTypeId,
          laborHourValue:
            this.laborHoursItemForMultipleBENorPSN[0]?.hoursPerDay,
          specialSubAssemblyPilotProductId: null,
          isRework: null,
          bomChange: null,
          pilotOrSupplierCaused: null,
          reworkCategoryId: null,
          reworkCategory: null,
        });
      }

      req.laborHourModuleMappings = [];
      if (this.PSNorBENDataItem?.length > 0) {
        this.PSNorBENDataItem.forEach((item) => {
          req.laborHourModuleMappings.push({
            laborHourModuleMappingId: null,
            laborHourId: this.isEditMode ? this.laborHourId : null,
            pilotProductId: item.pilotProductID,
            isSpecialSubAssembly: false,
          });
        });
      }
      this.service.AddLaborHours(req).subscribe((res) => {
        if (res) {
          this.isSaveEnabled = false;
          this.showSuccess("Saved");
          setTimeout(() => {
            this.reloadCurrentRoute();
          }, 1000);
        }
      });
    } else if (
      this.selectedLaborHours?.optionName === "Working In Pilot" &&
      this.psnValue?.pilotProductID > 0 &&
      !this.isMultiplePSN
    ) {
      if (
        this.assemblyRegular !== null &&
        this.assemblyRegular !== undefined &&
        this.assemblyRegular !== 0
      ) {
        let data = new LaborHourValues();
        data = {
          laborHourValuesId: this.isEditMode
            ? this.editlaborHourData.laborHourValueEdits.filter(
              (item) =>
                item.laborTypeId ===
                this.laborHourTypes.filter(
                  (item) =>
                    item.laborTypeName === "Assembly"
                )[0].laborTypeID &&
                item.laborHourItemTypeId ===
                this.laborHourItems.filter(
                  (item) =>
                    item.optionName === "Regular"
                )[0].laborHourItemTypeId
            )[0]?.laborHourValuesId
            : null,
          laborHourId: this.isEditMode
            ? this.editlaborHourData.laborHourValueEdits[0]
              .laborHourId
            : null,
          laborTypeId: this.laborHourTypes.filter(
            (item) => item.laborTypeName === "Assembly"
          )[0].laborTypeID,
          laborHourItemTypeId: this.laborHourItems.filter(
            (item) => item.optionName === "Regular"
          )[0].laborHourItemTypeId,
          laborHourValue: this.assemblyRegular,
          specialSubAssemblyPilotProductId: null,
          isRework: false,
          bomChange: null,
          pilotOrSupplierCaused: null,
          reworkCategoryId: null,
          reworkCategory: null,
        };
        laborHourValues.push(data);
      }
      if (
        this.testRegular !== null &&
        this.testRegular !== undefined &&
        this.testRegular !== 0
      ) {
        const data: LaborHourValues = {
          laborHourValuesId: this.isEditMode
            ? this.editlaborHourData.laborHourValueEdits.filter(
              (item) =>
                item.laborTypeId ===
                this.laborHourTypes.filter(
                  (item) =>
                    item.laborTypeName === "Test"
                )[0].laborTypeID &&
                item.laborHourItemTypeId ===
                this.laborHourItems.filter(
                  (item) =>
                    item.optionName === "Regular"
                )[0].laborHourItemTypeId
            )[0]?.laborHourValuesId
            : null,
          laborHourId: this.isEditMode
            ? this.editlaborHourData.laborHourValueEdits[0]
              .laborHourId
            : null,
          laborTypeId: this.laborHourTypes.filter(
            (item) => item.laborTypeName === "Test"
          )[0].laborTypeID,
          laborHourItemTypeId: this.laborHourItems.filter(
            (item) => item.optionName === "Regular"
          )[0].laborHourItemTypeId,
          laborHourValue: this.testRegular,
          specialSubAssemblyPilotProductId: null,
          isRework: false,
          bomChange: null,
          pilotOrSupplierCaused: null,
          reworkCategoryId: null,
          reworkCategory: null,
        };
        laborHourValues.push(data);
      }
      if (
        this.assemblyTroubleshooting !== null &&
        this.assemblyTroubleshooting !== undefined &&
        this.assemblyTroubleshooting !== 0
      ) {
        const data: LaborHourValues = {
          laborHourValuesId: this.isEditMode
            ? this.editlaborHourData.laborHourValueEdits.filter(
              (item) =>
                item.laborTypeId ===
                this.laborHourTypes.filter(
                  (item) =>
                    item.laborTypeName === "Assembly"
                )[0].laborTypeID &&
                item.laborHourItemTypeId ===
                this.laborHourItems.filter(
                  (item) =>
                    item.optionName ===
                    "Troubleshooting"
                )[0].laborHourItemTypeId
            )[0]?.laborHourValuesId
            : null,
          laborHourId: this.isEditMode
            ? this.editlaborHourData.laborHourValueEdits[0]
              .laborHourId
            : null,
          laborTypeId: this.laborHourTypes.filter(
            (item) => item.laborTypeName === "Assembly"
          )[0].laborTypeID,
          laborHourItemTypeId: this.laborHourItems.filter(
            (item) => item.optionName === "Troubleshooting"
          )[0].laborHourItemTypeId,
          laborHourValue: this.assemblyTroubleshooting,
          specialSubAssemblyPilotProductId: null,
          isRework: false,
          bomChange: null,
          pilotOrSupplierCaused: null,
          reworkCategoryId: null,
          reworkCategory: null,
        };
        laborHourValues.push(data);
      }
      if (
        this.testTroubleshooting !== null &&
        this.testTroubleshooting !== undefined &&
        this.testTroubleshooting !== 0
      ) {
        const data: LaborHourValues = {
          laborHourValuesId: this.isEditMode
            ? this.editlaborHourData.laborHourValueEdits.filter(
              (item) =>
                item.laborTypeId ===
                this.laborHourTypes.filter(
                  (item) =>
                    item.laborTypeName === "Test"
                )[0].laborTypeID &&
                item.laborHourItemTypeId ===
                this.laborHourItems.filter(
                  (item) =>
                    item.optionName ===
                    "Troubleshooting"
                )[0].laborHourItemTypeId
            )[0]?.laborHourValuesId
            : null,
          laborHourId: this.isEditMode
            ? this.editlaborHourData.laborHourValueEdits[0]
              .laborHourId
            : null,
          laborTypeId: this.laborHourTypes.filter(
            (item) => item.laborTypeName === "Test"
          )[0].laborTypeID,
          laborHourItemTypeId: this.laborHourItems.filter(
            (item) => item.optionName === "Troubleshooting"
          )[0].laborHourItemTypeId,
          laborHourValue: this.testTroubleshooting,
          specialSubAssemblyPilotProductId: null,
          isRework: false,
          bomChange: null,
          pilotOrSupplierCaused: null,
          reworkCategoryId: null,
          reworkCategory: null,
        };
        laborHourValues.push(data);
      }
      if (
        this.assemblyQualityAssurance !== null &&
        this.assemblyQualityAssurance !== undefined &&
        this.assemblyQualityAssurance !== 0
      ) {
        const data: LaborHourValues = {
          laborHourValuesId: this.isEditMode
            ? this.editlaborHourData.laborHourValueEdits.filter(
              (item) =>
                item.laborTypeId ===
                this.laborHourTypes.filter(
                  (item) =>
                    item.laborTypeName === "Assembly"
                )[0].laborTypeID &&
                item.laborHourItemTypeId ===
                this.laborHourItems.filter(
                  (item) =>
                    item.optionName ===
                    "Quality Assurance"
                )[0].laborHourItemTypeId
            )[0]?.laborHourValuesId
            : null,
          laborHourId: this.isEditMode
            ? this.editlaborHourData.laborHourValueEdits[0]
              .laborHourId
            : null,
          laborTypeId: this.laborHourTypes.filter(
            (item) => item.laborTypeName === "Assembly"
          )[0].laborTypeID,
          laborHourItemTypeId: this.laborHourItems.filter(
            (item) => item.optionName === "Quality Assurance"
          )[0].laborHourItemTypeId,
          laborHourValue: this.assemblyQualityAssurance,
          specialSubAssemblyPilotProductId: null,
          isRework: false,
          bomChange: null,
          pilotOrSupplierCaused: null,
          reworkCategoryId: null,
          reworkCategory: null,
        };
        laborHourValues.push(data);
      }
      if (
        this.testQualityAssurance !== null &&
        this.testQualityAssurance !== undefined &&
        this.testQualityAssurance !== 0
      ) {
        const data: LaborHourValues = {
          laborHourValuesId: this.isEditMode
            ? this.editlaborHourData.laborHourValueEdits.filter(
              (item) =>
                item.laborTypeId ===
                this.laborHourTypes.filter(
                  (item) =>
                    item.laborTypeName === "Test"
                )[0].laborTypeID &&
                item.laborHourItemTypeId ===
                this.laborHourItems.filter(
                  (item) =>
                    item.optionName ===
                    "Quality Assurance"
                )[0].laborHourItemTypeId
            )[0]?.laborHourValuesId
            : null,
          laborHourId: this.isEditMode
            ? this.editlaborHourData.laborHourValueEdits[0]
              .laborHourId
            : null,
          laborTypeId: this.laborHourTypes.filter(
            (item) => item.laborTypeName === "Test"
          )[0].laborTypeID,
          laborHourItemTypeId: this.laborHourItems.filter(
            (item) => item.optionName === "Quality Assurance"
          )[0].laborHourItemTypeId,
          laborHourValue: this.testQualityAssurance,
          specialSubAssemblyPilotProductId: null,
          isRework: false,
          bomChange: null,
          pilotOrSupplierCaused: null,
          reworkCategoryId: null,
          reworkCategory: null,
        };
        laborHourValues.push(data);
      }
      if (
        this.miscAdmin !== null &&
        this.miscAdmin !== undefined &&
        this.miscAdmin !== 0
      ) {
        const data: LaborHourValues = {
          laborHourValuesId: this.isEditMode
            ? this.editlaborHourData.laborHourValueEdits.filter(
              (item) =>
                item.laborTypeId ===
                this.laborHourTypes.filter(
                  (item) =>
                    item.laborTypeName ===
                    "Misc Hours"
                )[0].laborTypeID &&
                item.laborHourItemTypeId ===
                this.laborHourItems.filter(
                  (item) => item.optionName === "Admin"
                )[0].laborHourItemTypeId
            )[0]?.laborHourValuesId
            : null,
          laborHourId: this.isEditMode
            ? this.editlaborHourData.laborHourValueEdits[0]
              .laborHourId
            : null,
          laborTypeId: this.laborHourTypes.filter(
            (item) => item.laborTypeName === "Misc Hours"
          )[0].laborTypeID,
          laborHourItemTypeId: this.laborHourItems.filter(
            (item) => item.optionName === "Admin"
          )[0].laborHourItemTypeId,
          laborHourValue: this.miscAdmin,
          specialSubAssemblyPilotProductId: null,
          isRework: false,
          bomChange: null,
          pilotOrSupplierCaused: null,
          reworkCategoryId: null,
          reworkCategory: null,
        };
        laborHourValues.push(data);
      }
      if (
        this.miscTraining !== null &&
        this.miscTraining !== undefined &&
        this.miscTraining !== 0
      ) {
        const data: LaborHourValues = {
          laborHourValuesId: this.isEditMode
            ? this.editlaborHourData.laborHourValueEdits.filter(
              (item) =>
                item.laborTypeId ===
                this.laborHourTypes.filter(
                  (item) =>
                    item.laborTypeName ===
                    "Misc Hours"
                )[0].laborTypeID &&
                item.laborHourItemTypeId ===
                this.laborHourItems.filter(
                  (item) =>
                    item.optionName === "Training"
                )[0].laborHourItemTypeId
            )[0]?.laborHourValuesId
            : null,
          laborHourId: this.isEditMode
            ? this.editlaborHourData.laborHourValueEdits[0]
              .laborHourId
            : null,
          laborTypeId: this.laborHourTypes.filter(
            (item) => item.laborTypeName === "Misc Hours"
          )[0].laborTypeID,
          laborHourItemTypeId: this.laborHourItems.filter(
            (item) => item.optionName === "Training"
          )[0].laborHourItemTypeId,
          laborHourValue: this.miscTraining,
          specialSubAssemblyPilotProductId: null,
          isRework: false,
          bomChange: null,
          pilotOrSupplierCaused: null,
          reworkCategoryId: null,
          reworkCategory: null,
        };
        laborHourValues.push(data);
      }
      if (
        this.miscBreak !== null &&
        this.miscBreak !== undefined &&
        this.miscBreak !== 0
      ) {
        const data: LaborHourValues = {
          laborHourValuesId: this.isEditMode
            ? this.editlaborHourData.laborHourValueEdits.filter(
              (item) =>
                item.laborTypeId ===
                this.laborHourTypes.filter(
                  (item) =>
                    item.laborTypeName ===
                    "Misc Hours"
                )[0].laborTypeID &&
                item.laborHourItemTypeId ===
                this.laborHourItems.filter(
                  (item) => item.optionName === "Break"
                )[0].laborHourItemTypeId
            )[0]?.laborHourValuesId
            : null,
          laborHourId: this.isEditMode
            ? this.editlaborHourData.laborHourValueEdits[0]
              .laborHourId
            : null,
          laborTypeId: this.laborHourTypes.filter(
            (item) => item.laborTypeName === "Misc Hours"
          )[0].laborTypeID,
          laborHourItemTypeId: this.laborHourItems.filter(
            (item) => item.optionName === "Break"
          )[0].laborHourItemTypeId,
          laborHourValue: this.miscBreak,
          specialSubAssemblyPilotProductId: null,
          isRework: false,
          bomChange: null,
          pilotOrSupplierCaused: null,
          reworkCategoryId: null,
          reworkCategory: null,
        };
        laborHourValues.push(data);
      }
      if (this.reworkGridData && this.reworkGridData.length > 0) {
        this.reworkGridData.forEach((item) => {
          const data: LaborHourValues = {
            laborHourValuesId: this.isEditMode
              ? this.editlaborHourData.laborHourValueEdits[0]
                ?.laborHourValuesId
              : null,
            laborHourId: this.isEditMode
              ? this.editlaborHourData.laborHourValueEdits[0]
                .laborHourId
              : null,
            laborTypeId: this.laborHourTypes.filter(
              (x) =>
                x.laborTypeName ===
                (item.isAssembly ? "Assembly" : "Test")
            )[0]?.laborTypeID,
            laborHourItemTypeId: null,
            laborHourValue: item.timeSpent,
            specialSubAssemblyPilotProductId: null,
            isRework: true,
            bomChange: item.isBOMChange,
            pilotOrSupplierCaused: item.isReworkPilot ? "P" : "S",
            reworkCategoryId: item.isReworkPilot
              ? item.reworkCategory?.id
              : null,
            reworkCategory: item.isReworkPilot
              ? item.reworkCategory?.category
              : null,
          };
          laborHourValues.push(data);
        });
      }

      laborHourModuleMappings.push({
        laborHourModuleMappingId: null,
        laborHourId: this.isEditMode ? this.laborHourId : null,
        pilotProductId: this.psnValue.pilotProductID,
        isSpecialSubAssembly: null,
      });

      const date = JSON.parse(JSON.stringify(this.laborHourDate));
      new Date(date).setHours(0, 0, 0, 0);
      if (new Date(date) < new Date(new Date().setHours(0, 0, 0, 0))) {
        this.laborHourDate.setHours(0, 0, 0, 0);
        const totalMinutes =
          this.userDetail?.shiftStartTime?.hours * 60 +
          this.userDetail?.shiftStartTime?.minutes;
        this.laborHourDate = new Date(
          this.laborHourDate.getTime() + totalMinutes * 60000
        );
      }

      const request = new LaborHourAddDetails();
      request.laborHourValues = laborHourValues;
      request.laborHourModuleMappings = laborHourModuleMappings;
      request.laborHourId = this.isEditMode ? this.laborHourId : null;
      request.userId = this.userDetail.userId;
      request.laborHourDate = new Date(
        new Date(this.laborHourDate).getTime() -
        new Date(this.laborHourDate).getTimezoneOffset() * 60000
      );
      if (!this.isEditMode) {
        request.createdBy = this.userDetail.userId;
        request.createdOn = new Date(
          new Date(this.laborHourDate).getTime() -
          new Date(this.laborHourDate).getTimezoneOffset() * 60000
        );
      }
      request.currentDate = new Date(
        new Date(Date.now()).getTime() -
        new Date(Date.now()).getTimezoneOffset() * 60000
      );

      request.modifiedOn = new Date(
        new Date().getTime() - new Date().getTimezoneOffset() * 60000
      );
      request.modifiedBy = this.userDetail?.userId;
      request.laborHourTypeId = this.isEditMode
        ? this.editlaborHourData.laborHourEditUserDetail.laborHourTypeId
        : this.selectedLaborHours.laborHourTypeId;
      request.laborHourLoanToId = null;
      request.ben = null;
      request.psn = null;
      request.plantId = this.site.plantId;

      this.service.AddLaborHours(request).subscribe((res) => {
        this.isSaveEnabled = false;
        this.showSuccess("Saved");
        setTimeout(() => {
          this.reloadCurrentRoute();
        }, 1000);
      });
    } else if (
      this.selectedLaborHours?.optionName === "On Quarantine" &&
      !this.isMultiplePSN
    ) {
      let data = new LaborHourValues();
      if (this.isEditMode) {
        data = {
          laborHourValuesId:
            this.editlaborHourData.laborHourValueEdits[0]
              .laborHourValuesId,
          laborHourId:
            this.editlaborHourData.laborHourValueEdits[0]
              .laborHourId,
          laborTypeId:
            this.editlaborHourData.laborHourValueEdits[0]
              .laborTypeId,
          laborHourItemTypeId:
            this.laborHoursItemForMultipleBENorPSN[0]
              .laborHourItemTypeId,
          laborHourValue:
            this.laborHoursItemForMultipleBENorPSN[0].hoursPerDay,
          specialSubAssemblyPilotProductId: null,
          isRework: null,
          bomChange: null,
          pilotOrSupplierCaused: null,
          reworkCategoryId: null,
          reworkCategory: null,
        };
      } else {
        data = {
          laborHourValuesId: null,
          laborHourId: null,
          laborTypeId: null,
          laborHourItemTypeId:
            this.laborHoursItemForMultipleBENorPSN[0]
              .laborHourItemTypeId,
          laborHourValue:
            this.laborHoursItemForMultipleBENorPSN[0].hoursPerDay,
          specialSubAssemblyPilotProductId: null,
          isRework: null,
          bomChange: null,
          pilotOrSupplierCaused: null,
          reworkCategoryId: null,
          reworkCategory: null,
        };
      }

      laborHourValues.push(data);

      const date = JSON.parse(JSON.stringify(this.laborHourDate));
      new Date(date).setHours(0, 0, 0, 0);
      if (new Date(date) < new Date(new Date().setHours(0, 0, 0, 0))) {
        this.laborHourDate.setHours(0, 0, 0, 0);
        const totalMinutes =
          this.userDetail?.shiftStartTime?.hours * 60 +
          this.userDetail?.shiftStartTime?.minutes;
        this.laborHourDate = new Date(
          this.laborHourDate.getTime() + totalMinutes * 60000
        );
      }

      const request = new LaborHourAddDetails();
      request.laborHourValues = laborHourValues;
      request.laborHourModuleMappings = laborHourModuleMappings;
      request.laborHourId = this.isEditMode ? this.laborHourId : null;
      request.userId = this.userDetail.userId;
      request.laborHourDate = new Date(
        new Date(this.laborHourDate).getTime() -
        new Date(this.laborHourDate).getTimezoneOffset() * 60000
      );
      if (!this.isEditMode) {
        request.createdOn = new Date(
          new Date(this.laborHourDate).getTime() -
          new Date(this.laborHourDate).getTimezoneOffset() * 60000
        );
        request.createdBy = this.userDetail.userId;
      }
      request.currentDate = new Date(
        new Date(Date.now()).getTime() -
        new Date(Date.now()).getTimezoneOffset() * 60000
      );

      request.modifiedOn = new Date(
        new Date().getTime() - new Date().getTimezoneOffset() * 60000
      );
      request.modifiedBy = this.userDetail?.userId;
      request.laborHourTypeId = this.isEditMode
        ? this.editlaborHourData.laborHourEditUserDetail.laborHourTypeId
        : this.selectedLaborHours.laborHourTypeId;
      request.laborHourLoanToId = null;
      request.ben = null;
      request.psn = null;
      request.plantId = this.site.plantId;

      this.service.AddLaborHours(request).subscribe((res) => {
        this.isSaveEnabled = false;
        this.showSuccess("Saved");
        setTimeout(() => {
          this.reloadCurrentRoute();
        }, 1000);
      });
    } else if (
      this.selectedLaborHours?.optionName === "Pilot Outsourcing Labor" &&
      !this.isMultiplePSN
    ) {
      let data = new LaborHourValues();
      if (this.isEditMode) {
        data = {
          laborHourValuesId:
            this.editlaborHourData.laborHourValueEdits[0]
              .laborHourValuesId,
          laborHourId:
            this.editlaborHourData.laborHourValueEdits[0]
              .laborHourId,
          laborTypeId:
            this.editlaborHourData.laborHourValueEdits[0]
              .laborTypeId,
          laborHourItemTypeId:
            this.laborHoursItemForMultipleBENorPSN[0]
              .laborHourItemTypeId,
          laborHourValue:
            this.laborHoursItemForMultipleBENorPSN[0].hoursPerDay,
          specialSubAssemblyPilotProductId: null,
          isRework: null,
          bomChange: null,
          pilotOrSupplierCaused: null,
          reworkCategoryId: null,
          reworkCategory: null,
        };
      } else {
        data = {
          laborHourValuesId: null,
          laborHourId: null,
          laborTypeId: null,
          laborHourItemTypeId:
            this.laborHoursItemForMultipleBENorPSN[0]
              .laborHourItemTypeId,
          laborHourValue:
            this.laborHoursItemForMultipleBENorPSN[0].hoursPerDay,
          specialSubAssemblyPilotProductId: null,
          isRework: null,
          bomChange: null,
          pilotOrSupplierCaused: null,
          reworkCategoryId: null,
          reworkCategory: null,
        };
      }
      laborHourValues.push(data);

      const date = JSON.parse(JSON.stringify(this.laborHourDate));
      new Date(date).setHours(0, 0, 0, 0);
      if (new Date(date) < new Date(new Date().setHours(0, 0, 0, 0))) {
        this.laborHourDate.setHours(0, 0, 0, 0);
        const totalMinutes =
          this.userDetail?.shiftStartTime?.hours * 60 +
          this.userDetail?.shiftStartTime?.minutes;
        this.laborHourDate = new Date(
          this.laborHourDate.getTime() + totalMinutes * 60000
        );
      }

      const request = new LaborHourAddDetails();
      request.laborHourValues = laborHourValues;
      request.laborHourModuleMappings = laborHourModuleMappings;
      request.laborHourId = this.isEditMode ? this.laborHourId : null;
      request.userId = this.userDetail.userId;
      request.laborHourDate = new Date(
        new Date(this.laborHourDate).getTime() -
        new Date(this.laborHourDate).getTimezoneOffset() * 60000
      );
      if (!this.isEditMode) {
        request.createdOn = new Date(
          new Date(this.laborHourDate).getTime() -
          new Date(this.laborHourDate).getTimezoneOffset() * 60000
        );
        request.createdBy = this.userDetail.userId;
      }
      request.currentDate = new Date(
        new Date(Date.now()).getTime() -
        new Date(Date.now()).getTimezoneOffset() * 60000
      );

      request.modifiedOn = new Date(
        new Date().getTime() - new Date().getTimezoneOffset() * 60000
      );
      request.modifiedBy = this.userDetail?.userId;
      request.laborHourTypeId = this.isEditMode
        ? this.editlaborHourData.laborHourEditUserDetail.laborHourTypeId
        : this.selectedLaborHours.laborHourTypeId;
      request.laborHourLoanToId = this.loanTo.laborHourLoanToId;
      request.ben =
        this.site.plantName !== "Fremont" ? this.toolBenProject : null;
      request.psn =
        this.site.plantName === "Fremont" ? this.toolBenProject : null;
      request.plantId = this.site.plantId;

      this.service.AddLaborHours(request).subscribe((res) => {
        this.isSaveEnabled = false;
        this.showSuccess("Saved");
        setTimeout(() => {
          this.reloadCurrentRoute();
        }, 1000);
      });
    } else if (
      (this.selectedLaborHours?.type === "E" ||
        this.selectedLaborHours?.type === "M") &&
      !this.isMultiplePSN
    ) {
      this.specialSubassemblyGridData.forEach((val, index) => {
        for (let i = 0; i < val.pilotProductID.length; i++) {
          if (val.POWOCellValue[i] != null) {
            const data: LaborHourValues = {
              laborHourValuesId: this.isEditMode
                ? val.laborHourValuesId[i]
                : null,
              laborHourId: this.isEditMode
                ? this.editlaborHourData.laborHourValueEdits[0]
                  .laborHourId
                : null,
              laborTypeId: null,
              laborHourItemTypeId: val.laborHourItemTypeId,
              laborHourValue: val.POWOCellValue[i],
              specialSubAssemblyPilotProductId:
                val.pilotProductID[i],
              isRework: null,
              bomChange: null,
              pilotOrSupplierCaused: null,
              reworkCategoryId: null,
              reworkCategory: null,
            };
            laborHourValues.push(data);
          }
        }
      });
      this.specialSubassemblyGridData[0].pilotProductID.forEach((val) => {
        const laborHourModuleMapping: LaborHourModuleMapping = {
          laborHourModuleMappingId: null,
          laborHourId: this.isEditMode ? this.laborHourId : null,
          pilotProductId: val,
          isSpecialSubAssembly: true,
        };
        laborHourModuleMappings.push(laborHourModuleMapping);
      });

      const date = JSON.parse(JSON.stringify(this.laborHourDate));
      new Date(date).setHours(0, 0, 0, 0);
      if (new Date(date) < new Date(new Date().setHours(0, 0, 0, 0))) {
        this.laborHourDate.setHours(0, 0, 0, 0);
        const totalMinutes =
          this.userDetail?.shiftStartTime?.hours * 60 +
          this.userDetail?.shiftStartTime?.minutes;
        this.laborHourDate = new Date(
          this.laborHourDate.getTime() + totalMinutes * 60000
        );
      }

      const request = new LaborHourAddDetails();
      request.laborHourValues = laborHourValues;
      request.laborHourModuleMappings = laborHourModuleMappings;
      request.laborHourId = this.isEditMode ? this.laborHourId : null;
      request.userId = this.userDetail.userId;
      request.laborHourDate = new Date(
        new Date(this.laborHourDate).getTime() -
        new Date(this.laborHourDate).getTimezoneOffset() * 60000
      );
      if (!this.isEditMode) {
        request.createdOn = new Date(
          new Date(this.laborHourDate).getTime() -
          new Date(this.laborHourDate).getTimezoneOffset() * 60000
        );
        request.createdBy = this.userDetail.userId;
      }
      request.currentDate = new Date(
        new Date(Date.now()).getTime() -
        new Date(Date.now()).getTimezoneOffset() * 60000
      );

      request.modifiedOn = new Date(
        new Date().getTime() - new Date().getTimezoneOffset() * 60000
      );
      request.modifiedBy = this.userDetail?.userId;
      request.laborHourTypeId = this.isEditMode
        ? this.editlaborHourData.laborHourEditUserDetail.laborHourTypeId
        : this.selectedLaborHours.laborHourTypeId;
      request.laborHourLoanToId = null;
      request.ben = null;
      request.psn = null;
      request.plantId = this.site.plantId;

      this.service.AddLaborHours(request).subscribe((res) => {
        this.isSaveEnabled = false;
        this.showSuccess("Saved");
        setTimeout(() => {
          this.reloadCurrentRoute();
        }, 1000);
      });
    }

    this.appStoreService.setCurrentBENForLH$(undefined);
    this.appStoreService.setMultipleBENForLH$([]);
  }
  onCancel() {
    this.reloadCurrentRoute();
  }

  public showSuccess(msg: string): void {
    this.notificationService.show({
      appendTo: this.appendTo,
      content: msg,
      position: { horizontal: "left", vertical: "bottom" },
      animation: { type: "fade", duration: 600 },
      type: { style: "success", icon: true },
    });
  }

  reloadCurrentRoute() {
    const currentUrl = this.router.url;
    this.router
      .navigateByUrl("/", { skipLocationChange: true })
      .then(() => {
        this.router.navigate([currentUrl]);
      });
  }

  openAddRework() {
    this.reworkLH = {
      isAssembly: false,
      isTest: false,
      isBOMChange: false,
      isNOtBOMChange: false,
      isReworkPilot: false,
      isReworkSupplier: false,
      reworkCategory: null,
      timeSpent: null,
    };
    this.openReworkPopup = true;
  }

  onSaveReworkDataToGrid() {
    this.reworkGridData.push(this.reworkLH);
    this.reworkdHours += this.reworkLH.timeSpent;
    this.openReworkPopup = false;
    this.isChangedReworkedHours = true;
  }

  onReworkAssemblySelect() {
    this.reworkLH.isTest = this.reworkLH.isAssembly;
    this.reworkLH.isAssembly = !this.reworkLH.isAssembly;
  }
  onReworkTestSelect() {
    this.reworkLH.isAssembly = this.reworkLH.isTest;
    this.reworkLH.isTest = !this.reworkLH.isTest;
  }
  onReworkBOMSelect() {
    this.reworkLH.isBOMChange = !this.reworkLH.isBOMChange;
    this.reworkLH.isNOtBOMChange = !this.reworkLH.isBOMChange;
  }
  onReworkNotBOMSelect() {
    this.reworkLH.isNOtBOMChange = !this.reworkLH.isNOtBOMChange;
    this.reworkLH.isBOMChange = !this.reworkLH.isNOtBOMChange;
  }
  onReworkPilotSelect() {
    this.reworkLH.isReworkSupplier = this.reworkLH.isReworkPilot;
    this.reworkLH.isReworkPilot = !this.reworkLH.isReworkPilot;
    this.reworkLH.reworkCategory = null;
  }
  onReworkSupplierSelect() {
    this.reworkLH.isReworkPilot = this.reworkLH.isReworkSupplier;
    this.reworkLH.isReworkSupplier = !this.reworkLH.isReworkSupplier;
    this.reworkLH.reworkCategory = null;
  }
  onChangeReworkCategory() { }

  isSaveDisabledForRework() {
    if (!this.reworkLH.isAssembly && !this.reworkLH.isTest) {
      return true;
    }
    if (!this.reworkLH.isBOMChange && !this.reworkLH.isNOtBOMChange) {
      return true;
    }
    if (
      this.reworkLH.isNOtBOMChange &&
      !this.reworkLH.isReworkPilot &&
      !this.reworkLH.isReworkSupplier
    ) {
      return true;
    }
    if (
      this.reworkLH.isNOtBOMChange &&
      this.reworkLH.isReworkPilot &&
      (this.reworkLH.reworkCategory === null ||
        this.reworkLH.reworkCategory === undefined ||
        (this.reworkLH.reworkCategory &&
          (this.reworkLH.reworkCategory.id === null ||
            this.reworkLH.reworkCategory.id === undefined)))
    ) {
      return true;
    }
    if (
      this.reworkLH.timeSpent === 0 ||
      this.reworkLH.timeSpent === null ||
      this.reworkLH.timeSpent === undefined
    ) {
      return true;
    }
    return false;
  }

  onSelectPSNorBEN() {
    if (this.PSNorBENDataItem.length > 0) {
      this.isSaveEnabled = true;
    }
  }

  getLaborHourItemsForMultipleBENorPSN() {
    this.laborHoursItemForMultipleBENorPSN = [];
    this.service.GetLaborHourItems("").subscribe((res) => {
      if (res && res.length > 0) {
        const data = res.filter((item) => item.type === null)[0];
        this.laborHoursItemForMultipleBENorPSN.push({
          laborHourItemTypeId: data?.laborHourItemTypeId,
          optionName: data?.optionName,
          type: data?.type,
          hoursPerDay: this.userDetail?.hoursPerDay,
        });
        if (this.isEditMode) {
          this.laborHoursItemForMultipleBENorPSN[0].hoursPerDay =
            this.editlaborHourData.laborHourValueEdits[0].laborHourValue;
          this.totalHours =
            this.editlaborHourData.laborHourValueEdits[0].laborHourValue;
        }
      }
    });
  }

  public cellClickHandlerForLaborHours({
    sender,
    rowIndex,
    columnIndex,
    dataItem,
    isEdited,
  }: any) {
    if (!isEdited) {
      sender.editCell(
        rowIndex,
        columnIndex,
        this.createFormGroupForLaborHours(dataItem)
      );
    }
  }

  public createFormGroupForLaborHours(
    dataItem: LaborHoursItemForMultipleBENorPSN
  ): FormGroup {
    return this.formBuilder.group({
      laborHourItemTypeId: dataItem.laborHourItemTypeId,
      optionName: dataItem.optionName,
      type: dataItem.type,
      hoursPerDay: dataItem.hoursPerDay,
    });
  }

  public cellCloseHandlerForLaborHours(args: any) {
    const { formGroup, dataItem } = args;
    this.cellOpen = false;

    if (!formGroup.valid) {
      args.preventDefault();
    } else if (formGroup.dirty) {
      this.editService.assignValues(dataItem, formGroup.value);
      this.editService.update(dataItem, "Labor Hours");
    } else {
      this.editService.update(dataItem, "Labor Hours");
    }
    const updatedData = this.editService.saveChanges();
    this.isSaveEnabled = updatedData?.length > 0 ? true : false;
  }

  public cancelHandlerForLaborHours({ sender, rowIndex }: any) {
    sender.closeRow(rowIndex);
  }

  public saveHandlerForLaborHours({ sender, formGroup, rowIndex }: any) {
    if (formGroup.valid) {
      this.editService.create(formGroup.value);
      sender.closeRow(rowIndex);
    }
  }

  resetWorkInPilotHours() {
    this.assemblyRegular = null;
    this.testRegular = null;
    this.assemblyTroubleshooting = null;
    this.testTroubleshooting = null;
    this.assemblyQualityAssurance = null;
    this.testQualityAssurance = null;
    this.miscAdmin = null;
    this.miscTraining = null;
    this.miscBreak = null;
    this.standardHours = 0;
    this.reworkdHours = 0;
    this.reworkGridData = [];
  }

  onChangeLaborHourType(e) {
    this.loanTo = this.loanToData[0];
    this.toolBenProject = "";
    this.assemblyRegular = null;
    this.testRegular = null;
    this.assemblyTroubleshooting = null;
    this.testTroubleshooting = null;
    this.assemblyQualityAssurance = null;
    this.testQualityAssurance = null;
    this.miscAdmin = null;
    this.miscTraining = null;
    this.miscBreak = null;
    this.psnValue = this.psnORbenDefaultItem;
    this.benValue = this.psnORbenDefaultItem;
    this.isSaveEnabled = false;
    this.standardHours = 0;
    this.reworkdHours = 0;
    this.specialSubassemblyGridData = [];
    this.wopoSelected = [];
    this.totalHours = this.userDetail?.hoursPerDay;
    if (e.type === "E" || e.type === "M") {
      this.wopoDDL = [];
      this.wopoValue = [];
      this.specialSubassemblyGridData = [];
      this.specialSubassemblyGridData2 = [];
      this.service
        .GetWOPODDL(this.site.plantId, e.type, "")
        .subscribe((res) => {
          if (res && res.length > 0) {
            this.wopoDDL = res;
          }
        });
    }
    if (e.optionName === "On Quarantine") {
      this.getLaborHourItemsForMultipleBENorPSN();
      this.isSaveEnabled = true;
    }
    if (e.optionName === "Pilot Outsourcing Labor") {
      this.getLaborHourItemsForMultipleBENorPSN();
    }
  }

  wopoDDLChange(e) {
    this.isSaveEnabled = true;
    this.specialSubassemblyGridData = [];
    this.wopoSelected = [];
    this.pilotProductIDSelected = [];
    if (e.length === 0) {
      this.wopoSelected = [];
      this.specialSubassemblyGridData2 = [];
      this.specialSubassemblyGridData = JSON.parse(
        JSON.stringify(this.specialSubassemblyGridData2)
      );
      return;
    }
    this.service.GetLaborHourItems("EtchMecha").subscribe((res) => {
      if (res) {
        res.forEach((val) => {
          this.wopoSelected = [];
          this.pilotProductIDSelected = [];
          const wowpoValues = [];
          const laborHourValuesId = [];
          e.forEach((v) => {
            this.wopoSelected.push(v.pilotSerialNumber);
            this.pilotProductIDSelected.push(v.pilotProductID);
            if (
              this.isEditMode &&
              this.editlaborHourData &&
              this.editlaborHourData.laborHourValueEdits?.length >
              0
            ) {
              wowpoValues.push(
                this.editlaborHourData.laborHourValueEdits.filter(
                  (ppId) =>
                    ppId.specialSubAssemblyPilotProductId ===
                    v.pilotProductID &&
                    ppId.laborHourItemTypeId ===
                    val.laborHourItemTypeId
                )[0]?.laborHourValue
              );
              laborHourValuesId.push(
                this.editlaborHourData.laborHourValueEdits.filter(
                  (ppId) =>
                    ppId.specialSubAssemblyPilotProductId ===
                    v.pilotProductID &&
                    ppId.laborHourItemTypeId ===
                    val.laborHourItemTypeId
                )[0]?.laborHourValuesId
              );
            } else {
              wowpoValues.push(null);
              laborHourValuesId.push(null);
            }
          });

          const splsub: SpecialSubassemblyGrid = {
            ItemType: val.optionName,
            optionName: val.optionName,
            laborHourItemTypeId: val.laborHourItemTypeId,
            type: val.type,
            POWO: JSON.parse(JSON.stringify(this.wopoSelected)),
            pilotProductID: JSON.parse(
              JSON.stringify(this.pilotProductIDSelected)
            ),
            POWOCellValue: JSON.parse(JSON.stringify(wowpoValues)),
            laborHourValuesId: JSON.parse(
              JSON.stringify(laborHourValuesId)
            ),
          };
          this.specialSubassemblyGridData.push(splsub);
        });

        if (this.isEditMode) {
          this.specialSubassemblyGridData.forEach((item) => {
            item.POWOCellValue?.forEach((val) => {
              this.totalHoursForSubAssemblies += val;
            });
          });
        }
      }
    });
  }

  handleWOPOFilter(value) {
    if (value.length >= 0) {
      this.wopoDDL = this.tempwopoDDL.filter(
        (s) =>
          s.pilotSerialNumber != null &&
          s.pilotSerialNumber
            ?.toLowerCase()
            .indexOf(value?.toLowerCase()) !== -1
      );
      this.multiselect.toggle(false);
    }
  }
  public onStateChangeSpecialSubassembly(state: State) {
    this.gridState = state;
  }

  public cellClickHandlerSpecialSubassembly({
    sender,
    rowIndex,
    columnIndex,
    dataItem,
    isEdited,
  }: any) {
    if (!isEdited) {
      sender.editCell(
        rowIndex,
        columnIndex,
        this.createFormGroupSpecialSubassembly(dataItem)
      );
      this.cellOpen = true;
    }
  }

  public createFormGroupSpecialSubassembly(dataItem: any): FormGroup {
    return this.formBuilder.group({
      ItemType: dataItem.ItemType,
      optionName: dataItem.optionName,
      laborHourItemTypeId: dataItem.laborHourItemTypeId,
      type: dataItem.type,
    });
  }

  public cellCloseHandlerSpecialSubassembly(args: any) {
    const { formGroup, dataItem } = args;
    this.cellOpen = false;

    if (!formGroup.valid) {
      // prevent closing the edited cell if there are invalid values.
      args.preventDefault();
    } else if (formGroup.dirty) {
      this.editService.assignValues(dataItem, formGroup.value);
      this.editService.update(dataItem, "");
    } else {
      this.editService.update(dataItem, "");
    }
  }

  onRemoveRework(reworkGridData: ReworkLaborHour, index: number) {
    this.reworkdHours -= reworkGridData.timeSpent;
    this.reworkGridData.splice(index, 1);
    this.isChangedReworkedHours = true;
  }

  onInputBENProject() {
    if (this.toolBenProject.length > 0) {
      this.isSaveEnabled = true;
    } else {
      false;
    }
  }

  onChangeLaborHours(dataItem) {
    this.isSaveEnabled = true;
    dataItem.hoursPerDay = this.onChange(dataItem.hoursPerDay);
    this.laborHoursItemForMultipleBENorPSN.forEach((item) => {
      this.calculateTotalLabor(item.hoursPerDay);
    });
  }

  onChange(value) {
    let currentvalue = value;
    if (currentvalue > 0) {
      currentvalue = Math.ceil(currentvalue / 0.25) * 0.25;
    } else if (currentvalue < 0) {
      currentvalue = Math.floor(currentvalue / 0.25) * 0.25;
    } else {
      currentvalue = null;
    }
    return currentvalue;
  }

  onChangeStandardLH(type: string) {
    this.isSaveEnabled = true;
    this.standardHours = 0;
    switch (type) {
      case "assemblyRegular":
        this.assemblyRegular = this.onChange(this.assemblyRegular);
        break;
      case "testRegular":
        this.testRegular = this.onChange(this.testRegular);
        break;
      case "assemblyTroubleshooting":
        this.assemblyTroubleshooting = this.onChange(
          this.assemblyTroubleshooting
        );
        break;
      case "testTroubleshooting":
        this.testTroubleshooting = this.onChange(
          this.testTroubleshooting
        );
        break;
      case "testQualityAssurance":
        this.testQualityAssurance = this.onChange(
          this.testQualityAssurance
        );
        break;
      case "assemblyQualityAssurance":
        this.assemblyQualityAssurance = this.onChange(
          this.assemblyQualityAssurance
        );
        break;
      case "miscAdmin":
        this.miscAdmin = this.onChange(this.miscAdmin);
        break;
      case "miscTraining":
        this.miscTraining = this.onChange(this.miscTraining);
        break;
      case "miscBreak":
        this.miscBreak = this.onChange(this.miscBreak);
        break;
      case "rework":
        this.reworkLH.timeSpent = this.onChange(
          this.reworkLH.timeSpent
        );
        break;
    }

    this.standardHours =
      (this.assemblyRegular !== undefined && this.assemblyRegular !== null
        ? this.assemblyRegular
        : 0) +
      (this.testRegular !== undefined && this.testRegular !== null
        ? this.testRegular
        : 0) +
      (this.assemblyTroubleshooting !== undefined &&
        this.assemblyTroubleshooting !== null
        ? this.assemblyTroubleshooting
        : 0) +
      (this.testTroubleshooting !== undefined &&
        this.testTroubleshooting !== null
        ? this.testTroubleshooting
        : 0) +
      (this.assemblyQualityAssurance !== undefined &&
        this.assemblyQualityAssurance !== null
        ? this.assemblyQualityAssurance
        : 0) +
      (this.testQualityAssurance !== undefined &&
        this.testQualityAssurance !== null
        ? this.testQualityAssurance
        : 0) +
      (this.miscAdmin !== undefined && this.miscAdmin !== null
        ? this.miscAdmin
        : 0) +
      (this.miscBreak !== undefined && this.miscBreak !== null
        ? this.miscBreak
        : 0) +
      (this.miscTraining !== undefined && this.miscTraining !== null
        ? this.miscTraining
        : 0);

    this.isChangedStandardHours = true;
  }

  onChangeSplSubassy(value: number, dataItem, index) {
    this.isSaveEnabled = true;
    this.totalHoursForSubAssemblies = 0;
    this.specialSubassemblyGridData.forEach((v) => {
      if (v.ItemType === dataItem.ItemType) {
        v.POWOCellValue[index] = this.onChange(value);
      }
    });

    this.specialSubassemblyGridData.forEach((item) => {
      item.POWOCellValue?.forEach((val) => {
        this.totalHoursForSubAssemblies += val;
      });
    });

    this.specialSubassemblyGridData2 = JSON.parse(
      JSON.stringify(this.specialSubassemblyGridData)
    );

    this.editService.update(dataItem, "");
  }

  public showTooltip(value: number, e: any) {
    const element = e.target as HTMLElement;
    const time = value ? value.toString() : "";
    if (time.includes(".")) {
      const hours = time.split(".")[0];
      const minutes =
        +time.split(".")[1] === 5
          ? +time.split(".")[1] * 6
          : (+time.split(".")[1] / 100) * 60;
      this.hoverMessage = hours + " hour, " + minutes + " minutes";
      this.tooltipDir.toggle(element);
    } else if (!time.includes(".")) {
      this.hoverMessage = time + " hour, " + "0 minutes";
      this.tooltipDir.toggle(element);
    } else {
      this.tooltipDir.hide();
    }
  }

  public showStandardTooltip(value: number) {
    const time = value ? value.toString() : "0";
    if (time.includes(".")) {
      const hours = time.split(".")[0];
      const minutes =
        +time.split(".")[1] === 5
          ? +time.split(".")[1] * 6
          : (+time.split(".")[1] / 100) * 60;
      this.hoverMessage = hours + " hour, " + minutes + " minutes";
    } else if (!time.includes(".")) {
      this.hoverMessage = time + " hour, " + "0 minutes";
    }
    return this.hoverMessage;
  }

  calculateTotalLabor(shiftHours: number) {
    this.totalHours = 0;
    if (
      this.selectedLaborHours.optionName !== "Working In Pilot" ||
      this.isMultiplePSN
    ) {
      this.standardHours = 0;
      this.reworkdHours = 0;
      this.totalHours = shiftHours;
    }
  }

  isMakeSaveDisable() {
    if (
      this.laborHourDate < this.minDate ||
      this.laborHourDate > this.maxDate
    ) {
      return false;
    } else {
      if (
        (!this.isMultiplePSN &&
          this.selectedLaborHours?.optionName ===
          "Working In Pilot" &&
          this.isShowHoursForToday() &&
          this.userDetail?.hoursPerDay -
          (this.laborHourForToday?.standardHours +
            this.laborHourForToday?.reworkHours +
            this.getStandardHour() +
            this.getReworkHour()) <
          0) ||
        (!this.isShowHoursForToday() &&
          this.userDetail?.hoursPerDay -
          (this.getStandardHour() + this.getReworkHour()) <
          0)
      ) {
        return true;
      } else if (
        !this.isMultiplePSN &&
        (this.selectedLaborHours?.type === "E" ||
          this.selectedLaborHours?.type === "M") &&
        this.userDetail?.hoursPerDay - this.totalHoursForSubAssemblies <
        0
      ) {
        return true;
      } else if (
        this.laborHourDate < this.minDate ||
        this.laborHourDate > this.maxDate
      ) {
        return true;
      } else if (
        !this.isMultiplePSN &&
        this.selectedLaborHours?.optionName ===
        "Pilot Outsourcing Labor" &&
        this.toolBenProject.length === 0
      ) {
        return true;
      } else return false;
    }
  }

  public setDatePickerDates() {
    const currentTime = new Date();
    const shiftTime = new Date();
    shiftTime.setHours(6, 30, 0, 0);
    if (currentTime < shiftTime) {
      const previousDate = currentTime.setDate(currentTime.getDate() - 1);
      this.laborHourDate = new Date(previousDate);
      this.todayLaborHourDate = new Date(previousDate);
    } else {
      this.laborHourDate = new Date();
      this.todayLaborHourDate = new Date();
    }

    const minDateYear = new Date().getFullYear() - 1;
    const minDate = new Date().setFullYear(minDateYear);
    this.minDate = new Date(new Date(minDate).setHours(0, 0, 0, 0));
  }

  onDateChange(value: Date) {
    if (value < this.minDate || value > this.maxDate) {
      this.isSaveEnabled = false;
    } else {
      this.isSaveEnabled = true;
    }
  }

  getStandardHour() {
    if (!this.isChangedStandardHours) return 0;
    else return this.standardHours - this.oldStandardHours;
  }

  getReworkHour() {
    if (!this.isChangedStandardHours) return 0;
    else return this.reworkdHours - this.oldReworkedHours;
  }

  isShowHoursForToday() {
    const date = JSON.parse(JSON.stringify(this.laborHourDate));
    if (new Date(new Date(this.laborHourDate).setHours(0, 0, 0, 0)).getTime() === new Date(new Date(this.todayLaborHourDate).setHours(0, 0, 0, 0)).getTime()) {
      return true;
    }
    else return false;
  }
}

