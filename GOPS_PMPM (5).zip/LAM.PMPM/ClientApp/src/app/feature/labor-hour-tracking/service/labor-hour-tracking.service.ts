import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { environment } from "../../../../environments/environment.dev_server";
import { route } from "../models/route";
import {
    LaborHourForToday,
    LaborHourLoanTo,
    LaborHoursItem,
    LaborHoursType,
    LaborHoursTypeForLaborHours,
    PSNorBEN,
} from "../models/add-labor-hours.model";
import { LaborHourAddDetails } from "../models/addLaborHour";
import { Labor } from "../../other/Models/defaults.model";
import {
    Building,
    LaborHourDashboard,
    LaborHourEditDisplayModel,
    LaborHourManagerData,
    LaborHourManagerDetails,
    LaborHourNotesViewModel,
    LaborHourSupDashboardView,
    LaborHourTechDashBoard,
    LaborHourTechWorkLog,
    SubmittedLaborHours,
} from "../models/verify-labor-hours.model";
import { ReworkCategoryViewModel } from "../../execution-and-tracking/Models/ModuleSummary";

@Injectable({
    providedIn: "root",
})
export class LaborHourTrackingService {
    constructor(private http: HttpClient) {}

    readonly apiUrl = `${environment.apiUrl}`;

    GetPSNOrBEN(
        plantID: number,
        searchtext: string,
        BENOrPSN: string
    ): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .get<any>(
                    `${environment.apiUrl}${route.getPSNOrBEN}` +
                        plantID +
                        (searchtext.length > 0
                            ? "/" + searchtext + "/" + BENOrPSN
                            : "")
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    GetOthersDDL(plantID): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .get<any>(
                    `${environment.apiUrl}${route.getothers}` + "/" + plantID
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    GetWOPODDL(
        plantID: number,
        etchormecha: string,
        searchtext: string
    ): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .get<any>(
                    `${environment.apiUrl}${route.getWOPO}` +
                        plantID +
                        "/" +
                        etchormecha +
                        "/" +
                        searchtext
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    GetLaborHourItems(type: string): Observable<LaborHoursItem[]> {
        return new Observable<LaborHoursItem[]>((observer) => {
            this.http
                .get<LaborHoursItem[]>(
                    `${environment.apiUrl}${route.getlaborhouritems}` + type
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    //single module
    GetLaborHourTypes(): Observable<LaborHoursType[]> {
        return new Observable<LaborHoursType[]>((observer) => {
            this.http
                .get<LaborHoursType[]>(
                    `${environment.apiUrl}${route.getlaborhourtypes}`
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    AddLaborHours(addLHObj: LaborHourAddDetails): Observable<number> {
        return new Observable<number>((observer) => {
            this.http
                .post<number>(
                    `${environment.apiUrl}${route.addlaborhours}`,
                    addLHObj
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    GetLabourDefaultData() {
        return this.http.get<Labor[]>(this.apiUrl + route.getLabourDefaultData);
    }

    GetLHTechWorkLogData(
        userID: number,
        plantID: number,
        shiftID: number,
        currentTime: Date
    ): Observable<LaborHourTechWorkLog[]> {
        return new Observable<LaborHourTechWorkLog[]>((observer) => {
            this.http
                .get<LaborHourTechWorkLog[]>(
                    `${environment.apiUrl}${route.getLHTechWorkLogData}` +
                        userID +
                        "/" +
                        plantID +
                        "/" +
                        shiftID +
                        "/" +
                        currentTime
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }
    GetLHTechInterruptionData(
        userID: number,
        plantID: number,
        shiftID: number,
        currentTime: Date
    ): Observable<LaborHourTechWorkLog[]> {
        return new Observable<LaborHourTechWorkLog[]>((observer) => {
            this.http
                .get<LaborHourTechWorkLog[]>(
                    `${environment.apiUrl}${route.getLHTechInterruptionData}` +
                        userID +
                        "/" +
                        plantID +
                        "/" +
                        shiftID +
                        "/" +
                        currentTime
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    GetLHTechDashBoard(
        userID: number,
        plantID: number,
        shiftID: number,
        currentTime: Date
    ): Observable<LaborHourTechDashBoard> {
        return new Observable<LaborHourTechDashBoard>((observer) => {
            this.http
                .get<LaborHourTechDashBoard>(
                    `${environment.apiUrl}${route.getLHTechDashBoard}` +
                        userID +
                        "/" +
                        plantID +
                        "/" +
                        shiftID +
                        "/" +
                        currentTime
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    UpdateLHTechIsVerify(
        userID: number,
        verify: boolean,
        shiftID: number,
        currentTime: Date,
        plantID: number
    ): Observable<number> {
        return new Observable<number>((observer) => {
            this.http
                .put<number>(
                    `${environment.apiUrl}${route.updateLHTechIsVerify}` +
                        userID +
                        "/" +
                        verify +
                        "/" +
                        shiftID +
                        "/" +
                        currentTime +
                        "/" +
                        plantID,
                    null
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    UpdateLHTechEditWorkingHours(
        userId: number,
        hours: number,
        shiftID: number,
        currentTime: Date,
        plantID: number
    ): Observable<number> {
        return new Observable<number>((observer) => {
            this.http
                .put<number>(
                    `${environment.apiUrl}${route.updateLHTechEditWorkingHours}` +
                        userId +
                        "/" +
                        hours +
                        "/" +
                        shiftID +
                        "/" +
                        currentTime +
                        "/" +
                        plantID,
                    null
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    GetLeadBENorPSN(userid: number): Observable<PSNorBEN[]> {
        return new Observable<PSNorBEN[]>((observer) => {
            this.http
                .get<PSNorBEN[]>(
                    `${environment.apiUrl}${route.getleadnpsnorben}` + userid
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    GetBuildingOfUser(userid: number): Observable<Building[]> {
        return new Observable<Building[]>((observer) => {
            this.http
                .get<Building[]>(
                    `${environment.apiUrl}${route.getbuilding}` + userid
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    GetLaborHours(
        userid: number,
        currenttime: Date
    ): Observable<LaborHourDashboard> {
        return new Observable<LaborHourDashboard>((observer) => {
            this.http
                .get<LaborHourDashboard>(
                    `${environment.apiUrl}${route.getleadlaborhours}` +
                        userid +
                        "/" +
                        currenttime
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    Updatebuilding(userid: number, buildingid: number): Observable<number> {
        return new Observable<number>((observer) => {
            this.http
                .post<number>(
                    `${environment.apiUrl}${route.updatebuilding}` +
                        userid +
                        "/" +
                        buildingid,
                    null
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    GetSupervisorLaborHours(
        userid: number,
        currenttime: Date,
        plantid: number
    ): Observable<LaborHourSupDashboardView[]> {
        return new Observable<LaborHourSupDashboardView[]>((observer) => {
            this.http
                .get<LaborHourSupDashboardView[]>(
                    `${environment.apiUrl}${route.getlaborhourspdb}` +
                        userid +
                        "/" +
                        currenttime +
                        "/" +
                        plantid
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    UpdateInsertNotes(request: LaborHourNotesViewModel): Observable<number> {
        return new Observable<number>((observer) => {
            this.http
                .post<number>(
                    `${environment.apiUrl}${route.updatenotes}`,
                    request
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    GetLHManagerData(
        userID: number,
        plantID: number,
        shiftID: number,
        currentTime: Date
    ): Observable<LaborHourManagerData> {
        return new Observable<LaborHourManagerData>((observer) => {
            this.http
                .get<LaborHourManagerData>(
                    `${environment.apiUrl}${route.getLHManagerData}` +
                        userID +
                        "/" +
                        plantID +
                        "/" +
                        shiftID +
                        "/" +
                        currentTime
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    GetLHManagerDataForCurrentQuarter(
        userID: number,
        plantID: number,
        shiftID: number,
        currentTime: Date
    ): Observable<LaborHourManagerData> {
        return new Observable<LaborHourManagerData>((observer) => {
            this.http
                .get<LaborHourManagerData>(
                    `${environment.apiUrl}${route.getLHManagerDataForCurrentQuarter}` +
                        userID +
                        "/" +
                        plantID +
                        "/" +
                        shiftID +
                        "/" +
                        currentTime
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    GetSubmittedLaborHours(
        userid: number,
        currenttime: Date,
        shiftid: number
    ): Observable<SubmittedLaborHours[]> {
        return new Observable<SubmittedLaborHours[]>((observer) => {
            this.http
                .get<SubmittedLaborHours[]>(
                    `${environment.apiUrl}${route.getall}` +
                        userid +
                        "/" +
                        currenttime +
                        "/" +
                        shiftid
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    DeleteLaborHour(laborhourid: number): Observable<number> {
        return new Observable<number>((observer) => {
            this.http
                .delete<number>(
                    `${environment.apiUrl}${route.deletelaborhour}` +
                        laborhourid
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    GetLaborHoursById(
        laborhourid: number
    ): Observable<LaborHourEditDisplayModel> {
        return new Observable<LaborHourEditDisplayModel>((observer) => {
            this.http
                .get<LaborHourEditDisplayModel>(
                    `${environment.apiUrl}${route.getlaborhours}` + laborhourid
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    UpdateLHTechIsSwitched(
        userID: number,
        isSwitched: boolean,
        shiftID: number,
        currentTime: Date,
        plantID: number
    ): Observable<number> {
        return new Observable<number>((observer) => {
            this.http
                .put<number>(
                    `${environment.apiUrl}${route.updateLHTechIsSwitched}` +
                        userID +
                        "/" +
                        isSwitched +
                        "/" +
                        shiftID +
                        "/" +
                        currentTime +
                        "/" +
                        plantID,
                    null
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    GetCycleTimeOfUser(
        userID: number,
        plantID: number,
        type: string,
        currentTime: Date
    ): Observable<any[]> {
        return new Observable<any>((observer) => {
            this.http
                .get<any[]>(
                    `${environment.apiUrl}${route.getcycletime}` +
                        userID +
                        "/" +
                        plantID +
                        "/" +
                        type +
                        "/" +
                        currentTime
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    UpdateCycleTime(
        cycleTimeModel: any,
        currentTime: Date
    ): Observable<number> {
        return new Observable<number>((observer) => {
            this.http
                .post<number>(
                    `${environment.apiUrl}${route.updatecycletime}` +
                        currentTime,
                    cycleTimeModel
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    GetManagerSummary(
        lamid: number,
        plantid: number,
        type: string,
        currentTime: Date
    ): Observable<LaborHourManagerDetails> {
        return new Observable<LaborHourManagerDetails>((observer) => {
            this.http
                .get<LaborHourManagerDetails>(
                    `${environment.apiUrl}${route.getmanagersummary}` +
                        lamid +
                        "/" +
                        plantid +
                        "/" +
                        type +
                        "/" +
                        currentTime
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    GetLaborHourTypeForLaborHours(
        plantid: number
    ): Observable<LaborHoursTypeForLaborHours[]> {
        return new Observable<LaborHoursTypeForLaborHours[]>((observer) => {
            this.http
                .get<LaborHoursTypeForLaborHours[]>(
                    `${environment.apiUrl}${route.gettype}` + plantid
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    getReworkCategory(): Observable<ReworkCategoryViewModel[]> {
        return new Observable<ReworkCategoryViewModel[]>((observer) => {
            this.http
                .get<ReworkCategoryViewModel[]>(
                    `${environment.apiUrl}${route.getreworkcategory}`
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    GetLaborHourLoanTo(plantId: number): Observable<LaborHourLoanTo[]> {
        return new Observable<LaborHourLoanTo[]>((observer) => {
            this.http
                .get<LaborHourLoanTo[]>(
                    `${environment.apiUrl}${route.getlaborhourloanto}` + plantId
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    GetLaborhoursSubmittedForToday(
        userid: number,
        plantid: number,
        shiftid: number,
        currenttime: Date
    ): Observable<LaborHourForToday[]> {
        return new Observable<LaborHourForToday[]>((observer) => {
            this.http
                .get<LaborHourForToday[]>(
                    `${environment.apiUrl}${route.getlaborhourforday}` +
                        userid +
                        "/" +
                        plantid +
                        "/" +
                        shiftid +
                        "/" +
                        currenttime
                )
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }

    public handleError(error) {
        let errorMessage = "";
        if (error.error instanceof ErrorEvent) {
            // Get client-side error
            errorMessage = error.error.message;
        } else {
            // Get server-side error
            errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }
        return throwError(errorMessage);
    }
}
