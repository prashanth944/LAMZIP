import { Component, OnInit, ViewEncapsulation } from "@angular/core";

@Component({
    selector: "pmpm-shared-calendar",
    templateUrl: "./shared-calendar.component.html",
    styleUrls: ["./shared-calendar.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class SharedCalendarComponent implements OnInit {
    constructor() {}

    ngOnInit(): void {}
}
