import {
    Component,
    Input,
    OnInit,
    ViewChild,
    ViewEncapsulation,
} from "@angular/core";
import { Router } from "@angular/router";
import { RowClassArgs } from "@progress/kendo-angular-grid";
import { TooltipDirective } from "@progress/kendo-angular-tooltip";
import {
    CompositeFilterDescriptor,
    filterBy,
} from "@progress/kendo-data-query";
import * as moment from "moment";
import { AppStoreService } from "../../../../core/app-store.service";
import { uiScreen } from "../../../../core/model/common.constant";
import { Plant, UserModel } from "../../../../core/model/user.model";
import { Labor } from "../../../other/Models/defaults.model";
import { EditService } from "../../../service/edit.service";
import {
    LaborHourNotesViewModel,
    LaborHourSupDashboardView,
} from "../../models/verify-labor-hours.model";
import { LaborHourTrackingService } from "../../service/labor-hour-tracking.service";
import { DataCalendarService } from "../../../calendar-report/data-calendar.service";

@Component({
    selector: "pmpm-supervisor-dashboard",
    templateUrl: "./supervisor-dashboard.component.html",
    styleUrls: ["./supervisor-dashboard.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class SupervisorDashboardComponent implements OnInit {
    @ViewChild(TooltipDirective) public tooltipDir: TooltipDirective;
    @Input() isShowManger = true;
    searchText = "";
    loading = true;
    site: Plant;
    userDetail: UserModel;
    supervisorDashboardDetails: LaborHourSupDashboardView[] = [];
    tempSupervisorDashboardDetails: LaborHourSupDashboardView[] = [];
    notesDataItem: LaborHourSupDashboardView;
    addNoteOpened = false;
    notesValue = "";
    isUserAccess = false;
    laborDefaultData: Labor[] = [];
    laborUtilization = 0;

    constructor(
        private appStoreService: AppStoreService,
        private router: Router,
        private service: LaborHourTrackingService,
        private editService: EditService,
        private calendarService: DataCalendarService
    ) {}

    ngOnInit() {
        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                if (res) {
                    this.appStoreService
                        .checkUserAccessRight(res, uiScreen.SupDashboard)
                        .subscribe((result) => {
                            this.isUserAccess = result;
                        });
                }
            }
        });
        this.appStoreService.getLoggedInUser().subscribe((user) => {
            this.appStoreService.getUserDetails(user.mail).subscribe((res) => {
                if (res) {
                    this.userDetail = res;
                    this.appStoreService.getCurrentSite().subscribe((site) => {
                        if (site) {
                            this.site = site;
                            let date: any = new Date();
                            date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
                            this.service
                                .GetLabourDefaultData()
                                .subscribe((res) => {
                                    this.laborDefaultData = [];
                                    if (res && res.length > 0) {
                                        this.laborDefaultData = res;
                                        this.laborUtilization =
                                            this.laborDefaultData.filter(
                                                (item) =>
                                                    item.plantID ===
                                                    this.site.plantId
                                            )[0].laborUtilization;
                                        this.GetSupervisorLaborHours(
                                            this.userDetail?.userId,
                                            date,
                                            this.site?.plantId
                                        );
                                    }
                                });
                        }
                    });
                }
            });
        });
    }

    GetSupervisorLaborHours(
        userid: number,
        currenttime: Date,
        plantid: number
    ) {
        this.supervisorDashboardDetails = [];
        this.tempSupervisorDashboardDetails = [];
        this.service
            .GetSupervisorLaborHours(userid, currenttime, plantid)
            .subscribe((res) => {
                if (res && res.length > 0) {
                    this.supervisorDashboardDetails = res;
                    this.tempSupervisorDashboardDetails = [
                        ...this.supervisorDashboardDetails,
                    ];
                }
                this.loading = false;
            });
    }

    onSearchFilter() {
        const filter: CompositeFilterDescriptor = { filters: [], logic: "and" };
        if (this.searchText && this.searchText.length > 0) {
            const data1 = [
                {
                    field: "userName",
                    operator: "contains",
                    value: this.searchText,
                },
            ];
            filter.filters.push({ filters: [...data1], logic: "or" });
        }
        this.supervisorDashboardDetails = filterBy(
            this.tempSupervisorDashboardDetails,
            filter
        );
    }
    public showTooltip(e: MouseEvent): void {
        const element = e.target as HTMLElement;
        if (
            (element.nodeName === "TD" || element.nodeName === "TH") &&
            element.offsetWidth < element.scrollWidth
        ) {
            this.tooltipDir.toggle(element);
        } else {
            this.tooltipDir.hide();
        }
    }

    openAddNotes(dataItem: LaborHourSupDashboardView) {
        this.notesDataItem = dataItem;
        this.addNoteOpened = true;
    }

    closeAddNotes() {
        this.addNoteOpened = false;
        this.notesValue = "";
    }

    onAddNote() {
        if (this.notesValue && this.notesValue.length > 0) {
            this.addNoteOpened = false;
            const newNote =
                "[" +
                moment(new Date()).format("MM/DD/yyyy").toString() +
                " " +
                this.userDetail?.firstName +
                " " +
                this.userDetail?.lastName +
                "] " +
                this.notesValue;
            this.notesDataItem.notes =
                this.notesDataItem.notes !== null
                    ? this.notesDataItem.notes + "\n" + newNote
                    : newNote;
            this.editService.update(this.notesDataItem, "Sup Dashboard");
            this.notesValue = "";
            const req = new LaborHourNotesViewModel();
            req.laborHourVerificationId =
                this.notesDataItem.laborHourVerificationId;
            req.userId = this.notesDataItem.userId;
            req.notes = this.notesDataItem.notes;
            req.currentDate = new Date(
                new Date().getTime() - new Date().getTimezoneOffset() * 60000
            );
            this.service.UpdateInsertNotes(req).subscribe((res) => {
                let date: any = new Date();
                date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
                this.GetSupervisorLaborHours(
                    this.userDetail?.userId,
                    date,
                    this.site?.plantId
                );
            });
        }
        this.notesValue = "";
        this.addNoteOpened = false;
    }

    goToSharedCalendar() {
        this.calendarService.diplayReportTable();
        this.router.navigate(["/labor-hour-tracking/shared-calendar"]);
    }

    goToSharedCalendarIfPending(status: string) {
        if (status === "Pending for Approval") {
            this.goToSharedCalendar();
        }
    }

    public rowCallback(context: RowClassArgs) {
        if (context.dataItem.rowColor === "Red") {
            return {
                redbg: true,
            };
        } else if (context.dataItem.rowColor === "Green") {
            return {
                greenbg: true,
            };
        } else if (context.dataItem.rowColor === "Yellow") {
            return {
                yellowbg: true,
            };
        }
    }
}
