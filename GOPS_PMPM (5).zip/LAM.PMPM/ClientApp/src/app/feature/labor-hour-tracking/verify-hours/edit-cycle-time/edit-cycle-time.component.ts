import { Component, OnInit, ViewChild, ViewContainerRef, ViewEncapsulation } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { NotificationService } from "@progress/kendo-angular-notification";
import {
  CompositeFilterDescriptor,
  filterBy,
} from "@progress/kendo-data-query";
import * as moment from "moment";
import { AppStoreService } from "../../../../core/app-store.service";
import { Plant } from "../../../../core/model/user.model";
import { EditService } from "../../../service/edit.service";
import { CycleTimeUpdateViewModel } from "../../models/edit-cycle-time.model";
import { LaborHourTrackingService } from "../../service/labor-hour-tracking.service";

@Component({
  selector: "pmpm-edit-cycle-time",
  templateUrl: "./edit-cycle-time.component.html",
  styleUrls: ["./edit-cycle-time.component.css"],
  encapsulation: ViewEncapsulation.None,
})
export class EditCycleTimeComponent implements OnInit {
  @ViewChild("appendTo", { read: ViewContainerRef })
  public appendTo: ViewContainerRef;
  //loggedIn user details
  public userID = 0;
  public userDetails: any;
  site: Plant;
  //grid
  public gridData: any;
  public tempGridData: any;
  public loadingTable = true;
  public type = "";
  //search and filter
  public filter: CompositeFilterDescriptor;
  public searchText = "";

  public updatedList: any[] = [];
  public disableSave = true;
  public totalCycleTime = 0;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private service: LaborHourTrackingService,
    private appStoreService: AppStoreService,
    private formBuilder: FormBuilder,
    private editService: EditService,
    private notificationService: NotificationService,
  ) { }

  ngOnInit(): void {
    this.route.params.subscribe((param) => {
      this.type = param.type;
      this.appStoreService.getLoggedInUser().subscribe((user) => {
        this.userDetails = user;
        this.appStoreService
          .getUserDetails(user.mail)
          .subscribe((res) => {
            if (res && res.username.length > 0) {
              this.userID = res?.userId;
              this.appStoreService
                .getCurrentSite()
                .subscribe((site) => {
                  if (site) {
                    this.site = {
                      plantName: site.plantName,
                      plantId: site.plantId,
                    };
                    this.getCycleTimeOfUser();
                  }
                });
            }
          });
      });
    });
  }

  public getCycleTimeOfUser() {
    let date: any = new Date();
    date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
    this.service
      .GetCycleTimeOfUser(this.userID, this.site.plantId, this.type, date)
      .subscribe((res) => {
        if (res) {
          this.gridData = res;
          this.tempGridData = JSON.parse(JSON.stringify(res));
          this.loadingTable = false;
          this.calculateTotalCycleTime();
        }
      });
  }

  public calculateTotalCycleTime() {
    this.totalCycleTime = 0;
    this.gridData.forEach((item) => {
      if (
        item.modifiedTime !== "" &&
        item.modifiedTime !== undefined &&
        item.modifiedTime !== 0
      ) {
        this.totalCycleTime = this.totalCycleTime + item.modifiedTime;
      } else {
        this.totalCycleTime = this.totalCycleTime + item.recordedTime;
      }
    });
  }

  onSearchFilter() {
    const filter: CompositeFilterDescriptor = { filters: [], logic: "and" };
    if (this.searchText && this.searchText.length > 0) {
      if (this.site.plantName === "Fremont") {
        const searchFilter = [
          {
            field: "pilotSerialNumber",
            operator: "contains",
            value: this.searchText.trim(),
          },
        ];
        filter.filters.push({
          filters: [...searchFilter],
          logic: "or",
        });
      }
      if (this.site.plantName === "Tualatin") {
        const searchFilter = [
          {
            field: "ben",
            operator: "contains",
            value: this.searchText.trim(),
          },
        ];
        filter.filters.push({
          filters: [...searchFilter],
          logic: "or",
        });
      }
    }
    this.filter = filter;
    this.gridData = filterBy(this.tempGridData, filter);
  }

  public createFormGroup(dataItem: any): FormGroup {
    return this.formBuilder.group({
      modifiedTime: [
        dataItem.modifiedTime,
        Validators.pattern(
          "^(?!0+$)[0-9]{1,2}.?((25)|(50)|(5)|(75)|(0)|(00))?$"
        ),
      ],
      endMinutes: dataItem.endMinutes,
    });
  }

  public cellClickHandler({
    sender,
    rowIndex,
    columnIndex,
    dataItem,
    isEdited,
  }) {
    if (!isEdited) {
      sender.editCell(
        rowIndex,
        columnIndex,
        this.createFormGroup(dataItem)
      );
    }
  }

  public cellCloseHandler(args: any) {
    const { formGroup, dataItem } = args;

    if (!formGroup.valid) {
      // prevent closing the edited cell if there are invalid values.
      args.preventDefault();
    } else if (formGroup.dirty) {
      if (args.column.field === "modifiedTime") {
        if (
          formGroup.value.modifiedTime !== "" &&
          formGroup.value.modifiedTime !== undefined
        ) {
          if (formGroup.value.modifiedTime.toString().includes(".")) {
            const integerPart = formGroup.value.modifiedTime
              .toString()
              .split(".")[0];
            const mantissaPart = formGroup.value.modifiedTime
              .toString()
              .split(".")[1];

            const integerMinutes = +integerPart * 60;

            let mantissaMinutes = 0;
            if (mantissaPart !== "" || mantissaPart !== undefined) {
              switch (mantissaPart) {
                case "0":
                case "00":
                  mantissaMinutes = 0;
                  break;
                case "25":
                  mantissaMinutes = 15;
                  break;
                case "50":
                case "5":
                  mantissaMinutes = 30;
                  break;
                case "75":
                  mantissaMinutes = 45;
                  break;
                default:
                  mantissaMinutes = 0;
                  break;
              }
            }
            formGroup.value.endMinutes = integerMinutes + mantissaMinutes;
          } else {
            const integerPart = formGroup.value.modifiedTime;
            const integerMinutes = integerPart * 60;
            const mantissaMinutes = 0;
            formGroup.value.endMinutes = integerMinutes + mantissaMinutes;
          }
        }

        if (this.type === "Direct" || this.type === "Rework") {
          this.editService.assignValues(dataItem, formGroup.value);
          this.editService.update(dataItem, "ECT-WorkRecordId");
          const updatedData = this.editService.saveChanges();
          if (updatedData?.length > 0) {
            this.disableSave = false;
            const isNew = this.updatedList.filter(
              (x) =>
                x.workRecordID == updatedData[0][0].workRecordID
            );
            if (isNew.length === 0) {
              this.updatedList.push(updatedData[0][0]);
            } else {
              const spliceIndex = this.updatedList.indexOf(
                updatedData[0][0].workRecordID
              );
              this.updatedList.splice(spliceIndex, 1);
              this.updatedList.push(updatedData[0][0]);
            }
          } else {
            this.disableSave = true;
          }
        } else if (
          this.type === "Interrupts" ||
          this.type === "BreakLunch"
        ) {
          this.editService.assignValues(dataItem, formGroup.value);
          this.editService.update(
            dataItem,
            "ECT-WorkRecordInterruptionId"
          );
          const updatedData = this.editService.saveChanges();
          if (updatedData?.length > 0) {
            this.disableSave = false;
            const isNew = this.updatedList.filter(
              (x) =>
                x.workRecordInterruptionId == updatedData[0][0].workRecordInterruptionId
            );
            if (isNew.length === 0) {
              this.updatedList.push(updatedData[0][0]);
            } else {
              const spliceIndex = this.updatedList.indexOf(
                updatedData[0][0].workRecordInterruptionId
              );
              this.updatedList.splice(spliceIndex, 1);
              this.updatedList.push(updatedData[0][0]);
            }
          } else {
            this.disableSave = true;
          }
        }
        this.calculateTotalCycleTime();
      }
    }
  }

  onSave() {
    const request: CycleTimeUpdateViewModel[] = [];
    this.updatedList.forEach((item) => {
      request.push({
        workRecordID: item.workRecordID,
        workRecordInterruptionId: item.workRecordInterruptionId,
        endMinutes: item.endMinutes,
      });
    });
    let date: any = new Date();
    date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
    if (request && request.length > 0) {
      this.service.UpdateCycleTime(request, date).subscribe((res) => {
        this.disableSave = true;
        this.getCycleTimeOfUser();
        this.showSuccess("Saved");
      });
    }
  }

  onCancel() {
    this.editService.cancelChanges();
    this.getCycleTimeOfUser();
  }

  public saveHandler({ sender, formGroup, rowIndex }) {
    if (formGroup.valid) {
      this.editService.create(formGroup.value);
      sender.closeRow(rowIndex);
    }
  }

  public cancelHandler({ sender, rowIndex }) {
    sender.closeRow(rowIndex);
  }

  routeToVerifyHours() {
    this.router.navigate(["/labor-hour-tracking/verify-hours"]);
  }

  onModifiedHours(dataItem) {
    dataItem.modifiedTime = this.onChange(dataItem.modifiedTime);
  }

  onChange(value) {
    let currentvalue = value;
    if (currentvalue > 0) {
      currentvalue = Math.ceil(currentvalue / 0.25) * 0.25;
    } else if (currentvalue < 0) {
      currentvalue = Math.floor(currentvalue / 0.25) * 0.25;
    } else {
      currentvalue = null;
    }
    return currentvalue;
  }

  public showSuccess(msg: string): void {
    this.notificationService.show({
      appendTo: this.appendTo,
      content: msg,
      position: { horizontal: "left", vertical: "bottom" },
      animation: { type: "fade", duration: 600 },
      type: { style: "success", icon: true },
    });
  }
}
