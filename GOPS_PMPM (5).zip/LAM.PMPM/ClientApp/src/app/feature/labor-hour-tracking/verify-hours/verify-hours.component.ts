import { Component, OnInit, ViewChild, ViewEncapsulation } from "@angular/core";
import { Router } from "@angular/router";
import { TooltipDirective } from "@progress/kendo-angular-tooltip";
import { AppStoreService } from "../../../core/app-store.service";
import { role, uiScreen } from "../../../core/model/common.constant";

@Component({
    selector: "pmpm-verify-hours",
    templateUrl: "./verify-hours.component.html",
    styleUrls: ["./verify-hours.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class VerifyHoursComponent implements OnInit {
    @ViewChild(TooltipDirective) public tooltipDir: TooltipDirective;
    public isUserAccess = false;
    isLoading = true;
    isTech = false;
    isLead = false;
    isSuperuser = false;
    isSupervisor = false;
    isPass = false;
    isManager = false;
    isSwitchedToCellFusion = true;
    gridDataForWorkLog: any[] = [];
    gridDataForInterruptions: any[] = [];
    isEditWorkingHour = false;
    editWorkingHours: number;

    constructor(
        private appStoreService: AppStoreService,
        private router: Router
    ) {}

    ngOnInit() {
        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                if (res) {
                    this.appStoreService
                        .checkUserAccessRight(res, uiScreen.VerifyHours)
                        .subscribe((result) => {
                            this.isUserAccess = result;
                            if (res.includes(role.SuperUser))
                                this.isSuperuser = true;
                            else if (res.includes(role.Technician))
                                this.isTech = true;
                            else if (res.includes(role.Leads))
                                this.isLead = true;
                            else if (res.includes(role.Supervisor))
                                this.isSupervisor = true;
                            else if (res.includes(role.PassTeamMember))
                                this.isPass = true;
                            else if (res.includes(role.Manager))
                                this.isManager = true;

                            this.isLoading = false;
                        });
                }
            }
        });
    }
    onSwitch() {
        this.isSwitchedToCellFusion = !this.isSwitchedToCellFusion;
    }
    public showTooltip(e: MouseEvent): void {
        const element = e.target as HTMLElement;
        if (
            (element.nodeName === "TD" || element.nodeName === "TH") &&
            element.offsetWidth < element.scrollWidth
        ) {
            this.tooltipDir.toggle(element);
        } else {
            this.tooltipDir.hide();
        }
    }
    onEditWorkingHours() {
        this.isEditWorkingHour = true;
    }
    closeEditWorkingHour() {
        this.editWorkingHours = null;
        this.isEditWorkingHour = false;
    }
    onAddEditWorkingHour() {
        this.isEditWorkingHour = false;
    }
    goToAddLaborHours() {
        this.router.navigate(["/labor-hour-tracking/add-labor-hours"]);
    }
}
