import {
  Component,
  EventEmitter,
  OnInit,
  Output,
  ViewEncapsulation,
} from "@angular/core";
import { Router } from "@angular/router";
import * as moment from "moment";
import { AppStoreService } from "../../../../core/app-store.service";
import { role, uiScreen } from "../../../../core/model/common.constant";
import { Plant, UserModel } from "../../../../core/model/user.model";
import { PSNorBEN } from "../../models/add-labor-hours.model";
import {
  Building,
  LaborHourDashboard,
} from "../../models/verify-labor-hours.model";
import { LaborHourTrackingService } from "../../service/labor-hour-tracking.service";

@Component({
  selector: "pmpm-pass-dashboard",
  templateUrl: "./pass-dashboard.component.html",
  styleUrls: ["./pass-dashboard.component.css"],
  encapsulation: ViewEncapsulation.None,
})
export class PassDashboardComponent implements OnInit {
  @Output() isVerified: EventEmitter<boolean> = new EventEmitter<boolean>();
  site: Plant;
  isEditWorkingHour = false;
  editWorkingHours: number;
  userDetail: UserModel;
  benOrPsn: PSNorBEN[] = [];
  buildings: Building[] = [];
  notSelectedBuilding: Building;
  laborHour: LaborHourDashboard;
  isUserAccess = false;
  isSuperUser = false;
  isShowVerify = true;
  openVerifyPopup = false;
  max = 13;

  constructor(
    private appStoreService: AppStoreService,
    private router: Router,
    private service: LaborHourTrackingService
  ) { }

  ngOnInit() {
    this.appStoreService.getUserRoles().subscribe((res) => {
      if (res && res.length > 0) {
        if (res) {
          this.appStoreService
            .checkUserAccessRight(res, uiScreen.PassDashboard)
            .subscribe((result) => {
              this.isUserAccess = result;
              if (res.includes(role.SuperUser))
                this.isSuperUser = true;
            });
        }
      }
    });
    this.appStoreService.setMultipleBENForLH$([]);
    this.appStoreService.getLoggedInUser().subscribe((user) => {
      this.appStoreService.getUserDetails(user.mail).subscribe((res) => {
        if (res) {
          this.userDetail = res;
          this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site) {
              this.site = site;
              this.max =
                this.site.plantName === "Fremont" ? 16 : 13;
              let date: any = new Date();
              date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
              this.getBuildingOfUser(this.userDetail?.userId);
              this.GetLaborHours(this.userDetail.userId, date);
            }
          });
        }
      });
    });
  }

  getLeadBENorPSN(userId: number) {
    this.service.GetLeadBENorPSN(userId).subscribe((res) => {
      if (res && res.length > 0) {
        this.benOrPsn = res;
      }
    });
  }

  getBuildingOfUser(userId: number) {
    this.buildings = [];
    this.benOrPsn = [];
    this.service.GetBuildingOfUser(userId).subscribe((res) => {
      if (res && res.length > 0) {
        this.buildings = res;
        if (
          this.buildings.filter((item) => item.isSelected === true)
            ?.length > 0
        ) {
          this.notSelectedBuilding = this.buildings.filter(
            (item) => item.isSelected === false
          )[0];
          this.getLeadBENorPSN(this.userDetail?.userId);
        } else {
          this.buildings[0].isSelected = true;
          this.notSelectedBuilding = this.buildings[1];
          this.service
            .Updatebuilding(
              this.userDetail?.userId,
              this.buildings[0].buildingID
            )
            .subscribe((res) => {
              this.getLeadBENorPSN(this.userDetail?.userId);
            });
        }
      }
    });
  }

  GetLaborHours(userid: number, currentTime: Date) {
    this.service.GetLaborHours(userid, currentTime).subscribe((res) => {
      if (res) {
        this.laborHour = res;
        if (this.laborHour.workingHours !== this.laborHour.recordedHours && res.isVerified) {
          this.isShowVerify = !res.isVerified;
          this.onVerify();
        } else {
          this.isShowVerify = !res.isVerified;
        }
      }
    });
  }

  switch(building: Building) {
    this.service
      .Updatebuilding(this.userDetail?.userId, building?.buildingID)
      .subscribe((res) => {
        this.getBuildingOfUser(this.userDetail.userId);
      });
  }
  onEditWorkingHours() {
    this.isEditWorkingHour = true;
  }
  closeEditWorkingHour() {
    this.editWorkingHours = null;
    this.isEditWorkingHour = false;
  }
  onAddEditWorkingHour() {
    let date: any = new Date();
    date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
    this.service
      .UpdateLHTechEditWorkingHours(
        this.userDetail.userId,
        this.editWorkingHours,
        this.userDetail?.shiftID,
        date,
        this.site?.plantId
      )
      .subscribe((res) => {
        this.GetLaborHours(this.userDetail.userId, date);
        this.editWorkingHours = null;
        if (
          this.laborHour.workingHours !==
          this.laborHour.recordedHours &&
          !this.isShowVerify
        ) {
          this.isShowVerify = true;
        }
        this.isVerified.emit(true);
      });
    this.isEditWorkingHour = false;
  }

  goToAddLaborHoursWithBEN() {
    if (this.benOrPsn && this.benOrPsn.length > 0) {
      this.appStoreService.setMultipleBENForLH$(this.benOrPsn);
      this.appStoreService.setCurrentBENForLH$(undefined);
    }
    this.router.navigate(["/labor-hour-tracking/add-labor-hours"]);
  }

  goToEditLaborHour() {
    this.router.navigate(["/edit-labor-hour"]);
  }

  openVerifConfirmation() {
    this.openVerifyPopup = true;
  }

  onVerify() {
    let date: any = new Date();
    date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
    this.service
      .UpdateLHTechIsVerify(
        this.userDetail?.userId,
        this.isShowVerify,
        this.userDetail?.shiftID,
        date,
        this.site?.plantId
      )
      .subscribe((res) => {
        this.isShowVerify = !this.isShowVerify;
        this.isVerified.emit(true);
      });
    this.openVerifyPopup = false;
  }

  onChangeEditWorkingLH() {
    this.editWorkingHours = this.onChange(this.editWorkingHours);
  }

  onChange(value) {
    let currentvalue = value;
    if (currentvalue > 0) {
      currentvalue = Math.ceil(currentvalue / 0.25) * 0.25;
    } else if (currentvalue < 0) {
      currentvalue = Math.floor(currentvalue / 0.25) * 0.25;
    } else {
      currentvalue = null;
    }
    return currentvalue;
  }
}
