import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { Router } from "@angular/router";
import * as moment from "moment";
import { AppStoreService } from "../../../../core/app-store.service";
import { uiScreen } from "../../../../core/model/common.constant";
import { Plant, UserModel } from "../../../../core/model/user.model";
import { LaborHourManagerDataDetails } from "../../models/verify-labor-hours.model";
import { LaborHourTrackingService } from "../../service/labor-hour-tracking.service";

@Component({
  selector: "pmpm-manager-dashboard",
  templateUrl: "./manager-dashboard.component.html",
  styleUrls: ["./manager-dashboard.component.css"],
  encapsulation: ViewEncapsulation.None,
})
export class ManagerDashboardComponent implements OnInit {
  site: Plant;
  userDetail: UserModel;
  weekLHData: LaborHourManagerDataDetails[] = [];
  quarterLHData: LaborHourManagerDataDetails[] = [];
  today = new Date();
  past7DayStartDate = new Date();
  past7DayEndDate = new Date();
  currentQuarterStartDate = new Date();
  currentQuarterEndDate = new Date();
  isUserAccess = false;


  constructor(
    private appStoreService: AppStoreService,
    private router: Router,
    private service: LaborHourTrackingService
  ) { }

  ngOnInit() {
    this.appStoreService.getUserRoles().subscribe((res) => {
      if (res && res.length > 0) {
        if (res) {
          this.appStoreService
            .checkUserAccessRight(res, uiScreen.ManagerDashboard)
            .subscribe((result) => {
              this.isUserAccess = result;
            });
        }
      }
    });
    this.appStoreService.getLoggedInUser().subscribe((user) => {
      this.appStoreService.getUserDetails(user.mail).subscribe((res) => {
        if (res) {
          this.userDetail = res;
          this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site) {
              this.site = site;
              let date: any = new Date();
              date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
              this.getLHManagerData(
                this.userDetail?.userId,
                this.site?.plantId,
                this.userDetail?.shiftID,
                date
              );
              this.getLHManagerDataForCurrentQuarter(
                this.userDetail?.userId,
                this.site.plantId,
                this.userDetail.shiftID,
                date
              );
            }
          });
        }
      });
    });
  }

  getLHManagerData(
    userID: number,
    plantID: number,
    shiftID: number,
    currentTime: Date
  ) {
    this.weekLHData = [];
    this.service
      .GetLHManagerData(userID, plantID, shiftID, currentTime)
      .subscribe((res) => {
        if (res) {
          this.past7DayStartDate = res.startDate;
          this.past7DayEndDate = res.endDate;
          if (res?.laborHourManagerDataDetails?.length > 0) {
            this.weekLHData = res.laborHourManagerDataDetails;
          }
        }
      });
  }
  getLHManagerDataForCurrentQuarter(
    userID: number,
    plantID: number,
    shiftID: number,
    currentTime: Date
  ) {
    this.quarterLHData = [];
    this.service
      .GetLHManagerDataForCurrentQuarter(
        userID,
        plantID,
        shiftID,
        currentTime
      )
      .subscribe((res) => {
        if (res) {
          this.currentQuarterStartDate = res.startDate;
          this.currentQuarterEndDate = res.endDate;
          if (res?.laborHourManagerDataDetails?.length > 0) {
            this.quarterLHData = res.laborHourManagerDataDetails;
          }
        }
      });
  }
  openLHSubmissionForWeek(data: LaborHourManagerDataDetails) {
    this.router.navigate(["/labor-hour-suumary/Week/" + data.lamId]);
  }
  openLHSubmissionForQuarter(data: LaborHourManagerDataDetails) {
    this.router.navigate(["/labor-hour-suumary/Quarter/" + data.lamId]);
  }
}
