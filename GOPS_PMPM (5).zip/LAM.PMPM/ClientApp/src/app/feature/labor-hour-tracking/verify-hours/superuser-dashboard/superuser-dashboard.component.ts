import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { Router } from "@angular/router";
import { AppStoreService } from "../../../../core/app-store.service";

@Component({
    selector: "pmpm-superuser-dashboard",
    templateUrl: "./superuser-dashboard.component.html",
    styleUrls: ["./superuser-dashboard.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class SuperUserDashboardComponent implements OnInit {
    reloadPassLHD = true;
    reloadTechLHD = true;
    reloadSupervisorLHD = true;

    constructor(
        private appStoreService: AppStoreService,
        private router: Router
    ) {}

    ngOnInit() {}
    isVerifiedPass(value: boolean) {
        this.reloadPassLHD = false;
        this.reloadSupervisorLHD = false;
        setTimeout(() => {
            this.reloadPassLHD = true;
            this.reloadSupervisorLHD = true;
        }, 300);
    }

    isVerifiedTech(value: boolean) {
        this.reloadTechLHD = false;
        this.reloadSupervisorLHD = false;
        setTimeout(() => {
            this.reloadTechLHD = true;
            this.reloadSupervisorLHD = true;
        }, 300);
    }
}
