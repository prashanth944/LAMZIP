import { Component, OnInit, ViewChild, ViewEncapsulation } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { MultiSelectComponent } from "@progress/kendo-angular-dropdowns";
import { RowClassArgs } from "@progress/kendo-angular-grid";
import { TooltipDirective } from "@progress/kendo-angular-tooltip";
import {
    CompositeFilterDescriptor,
    distinct,
    filterBy,
} from "@progress/kendo-data-query";
import * as moment from "moment";
import { AppStoreService } from "../../../../core/app-store.service";
import { Plant, UserModel } from "../../../../core/model/user.model";
import { DataCalendarService } from "../../../calendar-report/data-calendar.service";
import { Labor } from "../../../other/Models/defaults.model";
import {
    LaborHourManagerDetails,
    LaborHourNotesViewModel,
    LaborHourSummary,
} from "../../models/verify-labor-hours.model";
import { LaborHourTrackingService } from "../../service/labor-hour-tracking.service";

@Component({
    selector: "pmpm-labor-hour-summary",
    templateUrl: "./labor-hour-summary.component.html",
    styleUrls: ["./labor-hour-summary.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class LaborHourSummaryComponent implements OnInit {
    @ViewChild("multiselect") public multiselect: MultiSelectComponent;
    @ViewChild(TooltipDirective) public tooltipDir: TooltipDirective;
    searchText = "";
    gridData: LaborHourSummary[] = [];
    tempGridData: LaborHourSummary[] = [];
    notesDataItem: LaborHourSummary;
    summaryDetails: LaborHourManagerDetails;
    excludeVerifiedRecords = false;
    userDetail: UserModel;
    site: Plant;
    type: string;
    lamid: number;
    loadingTable = true;
    laborDefaultData: Labor[] = [];
    laborUtilization = 0;
    dateData: string[] = [];
    tempDateData: string[] = [];
    dateDataItem: string[] = [];
    userData: string[] = [];
    tempUserData: string[] = [];
    userDataItem: string[] = [];
    addNoteOpened = false;
    notesValue = "";

    constructor(
        private appStoreService: AppStoreService,
        private router: Router,
        private service: LaborHourTrackingService,
        private route: ActivatedRoute,
        private calendarService: DataCalendarService
    ) {}

    ngOnInit() {
        this.route.params.subscribe((param) => {
            this.type = param.type;
            this.lamid = +param.lamId;
            this.appStoreService.getLoggedInUser().subscribe((user) => {
                this.appStoreService
                    .getUserDetails(user.mail)
                    .subscribe((res) => {
                        if (res) {
                            this.userDetail = res;
                            this.appStoreService
                                .getCurrentSite()
                                .subscribe((site) => {
                                    if (site) {
                                        this.site = site;
                                        let date: any = new Date();
                                        date = moment(date).format(
                                            "MM-DD-yyyy HH:mm:ss a"
                                        );
                                        this.service
                                            .GetLabourDefaultData()
                                            .subscribe((res) => {
                                                this.laborDefaultData = [];
                                                if (res && res.length > 0) {
                                                    this.laborDefaultData = res;
                                                    this.laborUtilization =
                                                        this.laborDefaultData.filter(
                                                            (item) =>
                                                                item.plantID ===
                                                                this.site
                                                                    .plantId
                                                        )[0].laborUtilization;
                                                    this.GetManagerSummary(
                                                        this.lamid,
                                                        this.site.plantId,
                                                        this.type,
                                                        date
                                                    );
                                                }
                                            });
                                    }
                                });
                        }
                    });
            });
        });
    }
    GetManagerSummary(
        lamid: number,
        plantid: number,
        type: string,
        currentTime: Date
    ) {
        this.loadingTable = true;
        this.gridData = [];
        this.tempGridData = [];
        this.service
            .GetManagerSummary(lamid, plantid, type, currentTime)
            .subscribe((res) => {
                if (res && res.laborHourManagerSummary?.length > 0) {
                    this.summaryDetails = res;
                    res.laborHourManagerSummary.forEach((item) => {
                        item.laborHourDate = moment(item.laborHourDate).format(
                            "MM-DD-yyyy"
                        );
                    });
                    this.gridData = [
                        ...this.summaryDetails.laborHourManagerSummary,
                    ];
                    this.tempGridData = [...this.gridData];

                    let data1: any = distinct(
                        this.gridData,
                        "laborHourDate"
                    ).map((item) => item["laborHourDate"]);
                    data1 = data1.flatMap((f) => (f ? [f] : []));
                    data1.sort(function (a, b) {
                        const textA = a?.toUpperCase();
                        const textB = b?.toUpperCase();
                        return textA < textB ? -1 : textA > textB ? 1 : 0;
                    });

                    this.dateData = [...data1];
                    this.tempDateData = [...this.dateData];

                    let data2: any = distinct(this.gridData, "userName").map(
                        (item) => item["userName"]
                    );
                    data2 = data2.flatMap((f) => (f ? [f] : []));
                    data2.sort(function (a, b) {
                        const textA = a?.toUpperCase();
                        const textB = b?.toUpperCase();
                        return textA < textB ? -1 : textA > textB ? 1 : 0;
                    });
                    this.userData = [...data2];
                    this.tempUserData = [...this.userData];
                }
                this.loadingTable = false;
            });
    }

    public onSearchFilter(): void {
        const filter: CompositeFilterDescriptor = { filters: [], logic: "and" };
        if (this.searchText && this.searchText.length > 0) {
            const data1 = [
                {
                    field: "userName",
                    operator: "contains",
                    value: this.searchText,
                },
            ];
            filter.filters.push({ filters: [...data1], logic: "or" });
        }
        if (this.dateDataItem && this.dateDataItem.length > 0) {
            const data2: any[] = [];
            this.dateDataItem.forEach((item) => {
                data2.push({
                    field: "laborHourDate",
                    operator: "eq",
                    value: item,
                });
            });
            filter.filters.push({ filters: [...data2], logic: "or" });
        }
        if (this.userDataItem && this.userDataItem.length > 0) {
            const data3: any[] = [];
            this.userDataItem.forEach((item) => {
                data3.push({
                    field: "userName",
                    operator: "eq",
                    value: item,
                });
            });
            filter.filters.push({ filters: [...data3], logic: "or" });
        }

        if (this.excludeVerifiedRecords) {
            const data4: any[] = [];
            data4.push({
                field: "rowColor",
                operator: "eq",
                value: "Red",
            });
            data4.push({
                field: "rowColor",
                operator: "eq",
                value: "Yellow",
            });
            filter.filters.push({ filters: [...data4], logic: "or" });
        } else {
            const data4: any[] = [];
            data4.push({
                field: "rowColor",
                operator: "eq",
                value: "Green",
            });
            data4.push({
                field: "rowColor",
                operator: "eq",
                value: "Red",
            });
            data4.push({
                field: "rowColor",
                operator: "eq",
                value: "Yellow",
            });
        }
        this.gridData = filterBy(this.tempGridData, filter);
    }

    public showTooltip(e: MouseEvent): void {
        const element = e.target as HTMLElement;
        if (
            (element.nodeName === "TD" || element.nodeName === "TH") &&
            element.offsetWidth < element.scrollWidth
        ) {
            this.tooltipDir.toggle(element);
        } else {
            this.tooltipDir.hide();
        }
    }

    openAddNotes(dataItem: LaborHourSummary) {
        this.notesDataItem = dataItem;
        this.addNoteOpened = true;
    }

    public rowCallback(context: RowClassArgs) {
        if (context?.dataItem?.rowColor === "Red") {
            return {
                redbg: true,
            };
        } else if (context?.dataItem?.rowColor === "Green") {
            return {
                greenbg: true,
            };
        } else if (context?.dataItem?.rowColor === "Yellow") {
            return {
                yellowbg: true,
            };
        } else {
            return {
                greenbg: true,
            };
        }
    }
    changeRecords() {
        this.excludeVerifiedRecords = !this.excludeVerifiedRecords;
        this.onSearchFilter();
    }

    returnToDashboard() {
        this.router.navigate(["/labor-hour-tracking/verify-hours"]);
    }

    handleDateFilter(value) {
        if (value.length >= 0) {
            this.dateData = this.tempDateData.filter(
                (s) => s?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
            );
        } else {
            this.multiselect.toggle(false);
        }
    }
    handleUserFilter(value) {
        if (value.length >= 0) {
            this.userData = this.tempUserData.filter(
                (s) => s?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
            );
        } else {
            this.multiselect.toggle(false);
        }
    }

    closeAddNotes() {
        this.addNoteOpened = false;
        this.notesValue = "";
    }

    onAddNote() {
        if (this.notesValue && this.notesValue.length > 0) {
            this.addNoteOpened = false;
            const newNote =
                "[" +
                moment(new Date()).format("MM/DD/yyyy").toString() +
                " " +
                this.userDetail?.firstName +
                " " +
                this.userDetail?.lastName +
                "] " +
                this.notesValue;
            this.notesDataItem.notes =
                this.notesDataItem.notes !== null
                    ? this.notesDataItem.notes + "\n" + newNote
                    : newNote;
            this.notesValue = "";

            const req = new LaborHourNotesViewModel();
            req.laborHourVerificationId =
                this.notesDataItem.laborHourVerificationId;
            req.userId = this.notesDataItem.userId;
            req.notes = this.notesDataItem.notes;

            let date = JSON.parse(
                JSON.stringify(this.notesDataItem.laborHourDate)
            );
            new Date(date).setHours(0, 0, 0, 0);
            const totalMinutes =
                this.userDetail?.shiftStartTime?.hours * 60 +
                this.userDetail?.shiftStartTime?.minutes;
            date = new Date(new Date(date).getTime() + totalMinutes * 60000);
            req.currentDate = new Date(
                date.getTime() - date.getTimezoneOffset() * 60000
            );

            this.service.UpdateInsertNotes(req).subscribe((res) => {
                let date: any = new Date();
                date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
                this.GetManagerSummary(
                    this.lamid,
                    this.site.plantId,
                    this.type,
                    date
                );
            });
        }
        this.notesValue = "";
        this.addNoteOpened = false;
    }

    goToSharedCalendar() {
        this.calendarService.diplayReportTable();
        this.router.navigate(["/labor-hour-tracking/shared-calendar"]);
    }

    goToSharedCalendarIfPending(status: any) {
        if (status === "Pending for Approval") {
            this.goToSharedCalendar();
        }
    }
}
