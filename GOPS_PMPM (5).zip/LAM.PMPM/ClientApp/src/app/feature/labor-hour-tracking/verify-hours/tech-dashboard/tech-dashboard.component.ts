import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
  ViewEncapsulation,
} from "@angular/core";
import { Router } from "@angular/router";
import { TooltipDirective } from "@progress/kendo-angular-tooltip";
import * as moment from "moment";
import { AppStoreService } from "../../../../core/app-store.service";
import { uiScreen } from "../../../../core/model/common.constant";
import { Plant, UserModel } from "../../../../core/model/user.model";
import { Labor } from "../../../other/Models/defaults.model";
import { PSNorBEN } from "../../models/add-labor-hours.model";
import {
  LaborHourTechDashBoard,
  LaborHourTechWorkLog,
} from "../../models/verify-labor-hours.model";
import { LaborHourTrackingService } from "../../service/labor-hour-tracking.service";

@Component({
  selector: "pmpm-tech-dashboard",
  templateUrl: "./tech-dashboard.component.html",
  styleUrls: ["./tech-dashboard.component.css"],
  encapsulation: ViewEncapsulation.None,
})
export class TechDashboardComponent implements OnInit {
  @ViewChild(TooltipDirective) public tooltipDir: TooltipDirective;
  @Input() showWorkLogs = true;
  @Input() showHeader = true;
  @Output() isVerified: EventEmitter<boolean> = new EventEmitter<boolean>();

  isSwitchedToCellFusion = false;
  gridDataForWorkLog: LaborHourTechWorkLog[] = [];
  gridDataForInterruptions: LaborHourTechWorkLog[] = [];
  isEditWorkingHour = false;
  editWorkingHours: number;
  isShowVerify = false;
  userDetail: UserModel;
  dashboardDetails: LaborHourTechDashBoard;
  site: Plant;
  isUserAccess = false;
  isLoading = true;

  laborDefaultData: Labor[] = [];
  openVerifyPopup = false;
  max = 13;

  constructor(
    private appStoreService: AppStoreService,
    private router: Router,
    private service: LaborHourTrackingService
  ) { }

  ngOnInit() {
    this.appStoreService.getUserRoles().subscribe((res) => {
      if (res && res.length > 0) {
        if (res) {
          this.appStoreService
            .checkUserAccessRight(res, uiScreen.TechDashboard)
            .subscribe((result) => {
              this.isUserAccess = result;
            });
        }
      }
      this.service.GetLabourDefaultData().subscribe((res) => {
        this.laborDefaultData = [];
        if (res && res.length > 0) {
          this.laborDefaultData = res;
        }
      });
    });
    this.appStoreService.setCurrentBENForLH$(undefined);
    this.appStoreService.getLoggedInUser().subscribe((user) => {
      this.appStoreService.getUserDetails(user.mail).subscribe((res) => {
        if (res) {
          this.userDetail = res;
          this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site) {
              this.site = site;
              this.max =
                this.site.plantName === "Fremont" ? 16 : 13;
              let date: any = new Date();
              date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
              this.getTechWorkLog(
                this.userDetail?.userId,
                this.site.plantId,
                this.userDetail.shiftID,
                date
              );
              this.getTechInterruption(
                this.userDetail?.userId,
                this.site.plantId,
                this.userDetail.shiftID,
                date
              );
              this.getLaborDashboard(
                this.userDetail?.userId,
                this.site.plantId,
                this.userDetail.shiftID,
                date
              );
            }
          });
        }
      });
    });
  }
  getTechWorkLog(
    userId: number,
    plantId: number,
    shiftID: number,
    currenTime: Date
  ) {
    this.gridDataForWorkLog = [];
    this.service
      .GetLHTechWorkLogData(userId, plantId, shiftID, currenTime)
      .subscribe((res) => {
        if (res && res.length > 0) {
          this.gridDataForWorkLog = res;
          this.isSwitchedToCellFusion =
            this.gridDataForWorkLog.filter(
              (item) => item.buildStyle === "Cell Fusion"
            ).length > 0
              ? true
              : this.dashboardDetails?.isSwitched;
        } else {
          this.isSwitchedToCellFusion =
            this.dashboardDetails?.isSwitched;
        }
      });
  }
  getTechInterruption(
    userId: number,
    plantId: number,
    shiftID: number,
    currenTime: Date
  ) {
    this.gridDataForInterruptions = [];
    this.service
      .GetLHTechInterruptionData(userId, plantId, shiftID, currenTime)
      .subscribe((res) => {
        if (res && res.length > 0) this.gridDataForInterruptions = res;
      });
  }
  getLaborDashboard(
    userId: number,
    plantId: number,
    shiftID: number,
    currenTime: Date
  ) {
    this.service
      .GetLHTechDashBoard(userId, plantId, shiftID, currenTime)
      .subscribe((res) => {
        if (res) {          
          this.dashboardDetails = res;
          if (this.dashboardDetails.working !== this.dashboardDetails.recorded && res.isVerify) {
            this.isShowVerify = !res.isVerify;
            this.onVerify();
          } else {
            this.isShowVerify = !res.isVerify;
          }
        }
      });
  }

  openVerifConfirmation() {
    this.openVerifyPopup = true;
  }

  onVerify() {
    let date: any = new Date();
    date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
    this.service
      .UpdateLHTechIsVerify(
        this.userDetail?.userId,
        this.isShowVerify,
        this.userDetail?.shiftID,
        date,
        this.site?.plantId
      )
      .subscribe((res) => {
        this.isShowVerify = !this.isShowVerify;
        this.isVerified.emit(true);
      });
    this.openVerifyPopup = false;
  }
  public showTooltip(e: MouseEvent): void {
    const element = e.target as HTMLElement;
    if (
      (element.nodeName === "TD" || element.nodeName === "TH") &&
      element.offsetWidth < element.scrollWidth
    ) {
      this.tooltipDir.toggle(element);
    } else {
      this.tooltipDir.hide();
    }
  }
  onEditWorkingHours() {
    this.isEditWorkingHour = true;
  }
  closeEditWorkingHour() {
    this.editWorkingHours = null;
    this.isEditWorkingHour = false;
  }
  onAddEditWorkingHour() {
    let date: any = new Date();
    date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
    this.service
      .UpdateLHTechEditWorkingHours(
        this.userDetail.userId,
        this.editWorkingHours,
        this.userDetail?.shiftID,
        date,
        this.site?.plantId
      )
      .subscribe((res) => {
        this.getLaborDashboard(
          this.userDetail.userId,
          this.site.plantId,
          this.userDetail?.shiftID,
          date
        );
        this.editWorkingHours = null;
        if (
          this.dashboardDetails.working !==
          this.dashboardDetails.recorded &&
          !this.isShowVerify
        ) {
          this.isShowVerify = true;
        }
        this.isVerified.emit(true);
      });
    this.isEditWorkingHour = false;
  }
  goToAddLaborHours() {
    this.router.navigate(["/labor-hour-tracking/add-labor-hours"]);
  }

  goToAddLaborHoursWithBEN(data: PSNorBEN) {
    this.appStoreService.setCurrentBENForLH$(data);
    this.appStoreService.setMultipleBENForLH$([]);
    this.router.navigate(["/labor-hour-tracking/add-labor-hours"]);
  }

  goToEditLaborHour() {
    this.router.navigate(["/edit-labor-hour"]);
  }

  isSwitched() {
    let date: any = new Date();
    date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
    this.isSwitchedToCellFusion = !this.isSwitchedToCellFusion;
    this.service
      .UpdateLHTechIsSwitched(
        this.userDetail?.userId,
        this.isSwitchedToCellFusion,
        this.userDetail?.shiftID,
        date,
        this.site?.plantId
      )
      .subscribe((res) => { });
  }

  validateCycleTimeHours(): boolean {
    if (
      this.gridDataForWorkLog?.filter(
        (item) => item.buildStyle === "Cell Fusion"
      )?.length > 0 &&
      this.isSwitchedToCellFusion
    ) {
      return true;
    } else if (this.laborDefaultData && this.laborDefaultData.length > 0) {
      const defaultCycleTime = this.laborDefaultData.filter(
        (item) => item.plantID === this.site?.plantId
      )[0]?.cycleTimeUtilization;
      return (
        this.dashboardDetails?.total >=
        this.dashboardDetails?.recorded *
        (1 - defaultCycleTime / 100) &&
        this.dashboardDetails?.total <=
        this.dashboardDetails?.recorded *
        (1 + defaultCycleTime / 100)
      );
    } else {
      return false;
    }
  }

  routeToEditCycleTime(type: string) {
    this.router.navigate(["/edit-cycle-time/" + type]);
  }

  onChangeEditWorkingLH() {
    this.editWorkingHours = this.onChange(this.editWorkingHours);
  }

  onChange(value) {
    let currentvalue = value;
    if (currentvalue > 0) {
      currentvalue = Math.ceil(currentvalue / 0.25) * 0.25;
    } else if (currentvalue < 0) {
      currentvalue = Math.floor(currentvalue / 0.25) * 0.25;
    } else {
      currentvalue = null;
    }
    return currentvalue;
  }

  isShowUnVerify() {
    if ((!this.isUserAccess || this.dashboardDetails?.working !== this.dashboardDetails?.recorded || this.dashboardDetails?.laborTechBENDetails?.length > 0 || !this.validateCycleTimeHours()) && !this.isShowVerify) {
      return true;
    } else {
      this.isShowVerify = true;
      return false;
    }
  }
}
