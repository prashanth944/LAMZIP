import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { Router } from "@angular/router";
import { AppStoreService } from "../../../../core/app-store.service";

@Component({
    selector: "pmpm-lead-dashboard",
    templateUrl: "./lead-dashboard.component.html",
    styleUrls: ["./lead-dashboard.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class LeadDashboardComponent implements OnInit {
    reloadSupervisorLHD = true;

    constructor(
        private appStoreService: AppStoreService,
        private router: Router
    ) {}

    ngOnInit() {}
    isVerifiedPass(value: boolean) {
        this.reloadSupervisorLHD = false;
        setTimeout(() => {
            this.reloadSupervisorLHD = true;
        }, 300);
    }
}
