import { Component, OnInit, ViewChild, ViewEncapsulation } from "@angular/core";
import { Router } from "@angular/router";
import { DataBindingDirective } from "@progress/kendo-angular-grid";
import { TooltipDirective } from "@progress/kendo-angular-tooltip";
import {
    CompositeFilterDescriptor,
    filterBy,
} from "@progress/kendo-data-query";
import * as moment from "moment";
import { AppStoreService } from "../../../core/app-store.service";
import { Plant, UserModel } from "../../../core/model/user.model";
import { SubmittedLaborHours } from "../models/verify-labor-hours.model";
import { LaborHourTrackingService } from "../service/labor-hour-tracking.service";

@Component({
    selector: "pmpm-edit-labor-hour",
    templateUrl: "./edit-labor-hours.component.html",
    styleUrls: ["./edit-labor-hours.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class EditLaborHourComponent implements OnInit {
    @ViewChild(DataBindingDirective) dataBinding: DataBindingDirective;
    @ViewChild(TooltipDirective) public tooltipDir: TooltipDirective;
    gridData: SubmittedLaborHours[] = [];
    tempGridData: SubmittedLaborHours[] = [];
    site: Plant;
    userDetail: UserModel;
    searchText = "";
    loading = true;

    constructor(
        private appStoreService: AppStoreService,
        private service: LaborHourTrackingService,
        private router: Router
    ) {}

    ngOnInit() {
        this.appStoreService.getLoggedInUser().subscribe((user) => {
            this.appStoreService.getUserDetails(user.mail).subscribe((res) => {
                if (res) {
                    this.userDetail = res;
                    this.appStoreService.getCurrentSite().subscribe((site) => {
                        if (site) {
                            this.site = site;
                            let date: any = new Date();
                            date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
                            this.GetSubmittedLaborHours(
                                this.userDetail?.userId,
                                date,
                                this.userDetail?.shiftID
                            );
                        }
                    });
                }
            });
        });
    }

    GetSubmittedLaborHours(userId: number, date: Date, shiftId: number) {
        this.tempGridData = [];
        this.gridData = [];
        this.service
            .GetSubmittedLaborHours(userId, date, shiftId)
            .subscribe((res) => {
                if (res && res.length > 0) {
                    this.gridData = res;
                    this.gridData.forEach((item) => {
                        item.beNorPSN = item.beNorPSN?.replace(/\\n/g, "\n");
                    });
                    this.tempGridData = [...this.gridData];
                }
                this.loading = false;
            });
    }

    public showTooltip(e: MouseEvent): void {
        const element = e.target as HTMLElement;
        if (
            (element.nodeName === "TD" || element.nodeName === "TH") &&
            element.offsetWidth < element.scrollWidth
        ) {
            this.tooltipDir.toggle(element);
        } else {
            this.tooltipDir.hide();
        }
    }

    onSearchFilter() {
        const filter: CompositeFilterDescriptor = { filters: [], logic: "and" };
        if (this.searchText && this.searchText.length > 0) {
            const data1 = [
                {
                    field: "beNorPSN",
                    operator: "contains",
                    value: this.searchText,
                },
            ];
            filter.filters.push({ filters: [...data1], logic: "or" });
        }
        this.gridData = filterBy(this.tempGridData, filter);
        this.dataBinding.skip = 0;
    }
    onEditLaborHours(data: SubmittedLaborHours) {
        this.router.navigate(["/add-labor-hours/" + data.laborHourId]);
    }

    onAddLaborHours() {
        this.router.navigate(["/labor-hour-tracking/add-labor-hours"]);
    }

    returnToDashboard() {
        this.router.navigate(["/labor-hour-tracking/verify-hours"]);
    }

    onDeleteLaborHours(data: SubmittedLaborHours) {
        this.service.DeleteLaborHour(data?.laborHourId).subscribe((res) => {
            if (res) {
                let date: any = new Date();
                date = moment(date).format("MM-DD-yyyy HH:mm:ss a");
                this.GetSubmittedLaborHours(
                    this.userDetail?.userId,
                    date,
                    this.userDetail?.shiftID
                );
            }
        });
    }
}
