import { Component, OnDestroy, OnInit } from "@angular/core";
import { DataServiceEandTService } from "../../execution-and-tracking/data-service-eand-t.service";
import { AppStoreService } from "../../../core/app-store.service";
import { Subscription } from "rxjs";
import { GridDataResult } from "@progress/kendo-angular-grid";
import { process, State } from "@progress/kendo-data-query";
import { Plant } from "../../../core/model/user.model";
import { Item } from "../../model/item";

@Component({
    selector: "pmpm-modules-upcoming",
    templateUrl: "./modules-upcoming.component.html",
    styleUrls: ["./modules-upcoming.component.css"],
})
export class ModulesUpcomingComponent implements OnInit, OnDestroy {
    public data: any[] = [];
    public viewData: GridDataResult;
    site: Plant;
    private subscription: Subscription[] = [];

    public AllFCID: string[];
    public SelFCID: string;

    public AllProductType: string[];
    public SelProductType: string;

    public AllPilotSerialNumber: string[];
    public SelPilotSerialNumber: string;

    public AllBEN: string[];
    public SelBEN: string;

    public AllFlag: any[];
    public SelFlag: any;

    private textSearch = "";
    public loadTable = true;
    public capacityPlanningColorHex: Item[] = [];
    public buildStyleItem: Item[] = [];

    public gridState: State = {
        sort: [{ dir: "asc", field: "ModuleInfo.CommitLaunch" }],
    };

    constructor(
        private dataService: DataServiceEandTService,
        private appStoreService: AppStoreService
    ) {}

    ngOnDestroy(): void {
        this.subscription.forEach((sub) => sub.unsubscribe());
    }
    ngOnInit(): void {
        this.subscription.push(
            this.appStoreService.getCurrentSite().subscribe((site) => {
                if (site) {
                    this.site = {
                        plantName: site.plantName,
                        plantId: site.plantId,
                    };
                    this.updateLocalData(this.site.plantId);
                }
            })
        );

        this.dataService.getModuleColorDDL().subscribe((mc) => {
            mc.forEach((val) => {
                const newMC: Item = {
                    value: val.value.trim(),
                    text: val.masterRecordName,
                };
                this.capacityPlanningColorHex.push(newMC);
                this.capacityPlanningColorHex =
                    this.capacityPlanningColorHex.sort(function (a, b) {
                        const textA = a?.text?.toUpperCase();
                        const textB = b?.text?.toUpperCase();
                        return textA < textB ? -1 : textA > textB ? 1 : 0;
                    });
            });
        });

        this.dataService.getBuildStyleDDL().subscribe((res) => {
            if (res && res.length) {
                res.forEach((val) => {
                    const newStatus: Item = {
                        value: val.masterRecordID,
                        text: val.masterRecordName,
                    };
                    this.buildStyleItem.push(newStatus);
                });
                this.buildStyleItem = this.buildStyleItem.filter(
                    (item) => item.text !== "Special Subassembly"
                );
            }
        });
    }

    updateLocalData(plantId) {
        this.dataService
            .getModuleSummaryInfoOnly(plantId)
            .toPromise()
            .then((data) => {
                this.data = data;

                this.AllFCID = this.GetUniques(this.data, "FCID");
                this.AllProductType = this.GetUniques(this.data, "ProductType");
                this.AllPilotSerialNumber = this.GetUniques(
                    this.data,
                    "PilotSerialNumber"
                );
                this.AllBEN = this.GetUniques(this.data, "BEN");
                this.AllFlag = ["In WIP Report", "Not Currently in WIP Report"];

                this.viewData = process(this.data, this.gridState);
                this.loadTable = false;
            });
    }

    public GetUniques(data: any[], colName: string) {
        return data
            .map((item) => item.ModuleInfo[colName])
            .filter(
                (value, index, self) =>
                    self.indexOf(value) === index &&
                    value !== null &&
                    value !== ""
            );
    }

    public onFilter(inputValue: string): void {
        this.textSearch = inputValue;
        this.updateFromFilter();
    }
    public getValue(event: Event): string {
        return (event.target as HTMLInputElement).value;
    }

    public updateFromFilter() {
        this.gridState["filter"] = {
            logic: "and",
            filters: [],
        };

        if (this.SelFCID && this.SelFCID !== "All FCID") {
            this.gridState["filter"].filters.push({
                field: "ModuleInfo.FCID",
                operator: "eq",
                value: this.SelFCID,
            });
        }
        if (this.SelProductType && this.SelProductType !== "All Product Type") {
            this.gridState["filter"].filters.push({
                field: "ModuleInfo.ProductType",
                operator: "eq",
                value: this.SelProductType,
            });
        }
        if (
            this.SelPilotSerialNumber &&
            this.SelPilotSerialNumber !== "All Pilot Serial Number"
        ) {
            this.gridState["filter"].filters.push({
                field: "ModuleInfo.PilotSerialNumber",
                operator: "eq",
                value: this.SelPilotSerialNumber,
            });
        }
        if (this.SelBEN && this.SelBEN !== "All BEN") {
            this.gridState["filter"].filters.push({
                field: "ModuleInfo.BEN",
                operator: "eq",
                value: this.SelBEN,
            });
        }
        if (
            this.SelFlag !== undefined &&
            this.SelFlag !== null &&
            this.SelFlag !== ""
        ) {
            if (this.SelFlag === "In WIP Report") {
                this.gridState["filter"].filters.push({
                    field: "ModuleInfo.WIPFlag",
                    operator: "eq",
                    value: true,
                });
            } else if (this.SelFlag === "Not Currently in WIP Report") {
                this.gridState["filter"].filters.push({
                    field: "ModuleInfo.WIPFlag",
                    operator: "neq",
                    value: true,
                });
            }
        }

        if (this.textSearch) {
            if (this.site.plantName === "Tualatin") {
                this.gridState["filter"].filters.push({
                    logic: "or",
                    filters: [
                        {
                            field: "ModuleInfo.BEN",
                            operator: "contains",
                            value: this.textSearch.trim(),
                        },
                        {
                            field: "ModuleInfo.FCID",
                            operator: "contains",
                            value: this.textSearch.trim(),
                        },
                    ],
                });
            }
            if (this.site.plantName === "Fremont") {
                this.gridState["filter"].filters.push({
                    logic: "or",
                    filters: [
                        {
                            field: "ModuleInfo.FCID",
                            operator: "contains",
                            value: this.textSearch.trim(),
                        },
                        {
                            field: "ModuleInfo.FremontID",
                            operator: "contains",
                            value: this.textSearch.trim(),
                        },
                        {
                            field: "ModuleInfo.PilotSerialNumber",
                            operator: "contains",
                            value: this.textSearch.trim(),
                        },
                    ],
                });
            }
        }

        if (this.gridState["filter"].filters.length === 0) {
            delete this.gridState["filter"];
        }

        this.viewData = process(this.data, this.gridState);
    }

    reloadModuleSummary(event) {
        this.updateLocalData(this.site?.plantId);
    }
}
