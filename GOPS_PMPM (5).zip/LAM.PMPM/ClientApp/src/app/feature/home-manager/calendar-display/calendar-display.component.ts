import { Component, Input, OnInit } from "@angular/core";

@Component({
    selector: "pmpm-calendar-display",
    templateUrl: "./calendar-display.component.html",
    styleUrls: ["./calendar-display.component.css"],
})
export class CalendarDisplayComponent implements OnInit {
    @Input() numberDay = 25;
    @Input() month = "JUN";
    @Input() label = "Personal PTO";
    @Input() colorDate = "green";
    @Input() isEntireFactoryShutDown = false;

    constructor() {}

    ngOnInit(): void {}
}
