import { Component, Input, OnInit } from "@angular/core";
import { AppStoreService } from "../../../core/app-store.service";
import { Plant } from "../../../core/model/user.model";
import { Holiday, HolidayCalendar } from "../model/home-page.model";
import { HomePageService } from "../service/home-page.service";

@Component({
    selector: "pmpm-home-technician",
    templateUrl: "./home-technician.component.html",
    styleUrls: ["./home-technician.component.css"],
})
export class HomeTechnicianComponent implements OnInit {
    @Input() username = "User";
    @Input() plantName = "";

    public holiday: Holiday[] = [];
    public holidayData: HolidayCalendar[];
    public monthNames = [
        "JAN",
        "FEB",
        "MAR",
        "APR",
        "MAY",
        "JUN",
        "JUL",
        "AUG",
        "SEP",
        "OCT",
        "NOV",
        "DEC",
    ];
    public standardID: number;
    public reconfigID: number;
    public cellFusionID: number;
    public valueAddedBuild: number;
    public site: Plant;

    constructor(
        private appStoreService: AppStoreService,
        private service: HomePageService
    ) {}

    ngOnInit(): void {
        this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site) {
                this.site = site;
                this.holidayData = [];
                this.service.getHolidays(site.plantId).subscribe((res) => {
                    this.holiday = res;
                    this.holiday.sort(
                        (a, b) =>
                            new Date(a.HolidayDateDaily).getTime() -
                            new Date(b.HolidayDateDaily).getTime()
                    );
                    this.holiday.forEach((item) => {
                        const hol: HolidayCalendar = {
                            date: new Date(item.HolidayDateDaily).getDate(),
                            month: this.monthNames[
                                new Date(item.HolidayDateDaily).getMonth()
                            ],
                            label: item.Name,
                            isEntireFactoryShutDown: item.FactoryShutDown,
                            color: this.getColorCode(
                                this.monthNames[
                                    new Date(item.HolidayDateDaily).getMonth()
                                ]
                            ),
                        };
                        this.holidayData.push(hol);
                    });
                });
            }
        });
        this.getBuildStyleIDs();
    }

    getColorCode(month: string): string {
        let color = "";
        switch (month) {
            case "JAN":
                color = "#30854c";
                break;
            case "FEB":
                color = "#2d477e";
                break;
            case "MAR":
                color = "#797a32";
                break;
            case "APR":
                color = "#916740";
                break;
            case "MAY":
                color = "#7a2a2a";
                break;
            case "JUN":
                color = "#0e0e8c";
                break;
            case "JUL":
                color = "#692e86";
                break;
            case "AUG":
                color = "#2e8873";
                break;
            case "SEP":
                color = "#863939";
                break;
            case "OCT":
                color = "#de7104";
                break;
            case "NOV":
                color = "#6b048a";
                break;
            case "DEC":
                color = "#bf060c";
                break;
        }
        return color;
    }

    getBuildStyleIDs() {
        this.service.getBuildStyleDDL().subscribe((res) => {
            if (res && res.length) {
                this.standardID = res.find(
                    (build) => build.masterRecordName === "Pilot Build"
                ).masterRecordID;
                this.reconfigID = res.find(
                    (build) => build.masterRecordName === "Reconfig"
                ).masterRecordID;
                this.valueAddedBuild = res.find(
                    (build) => build.masterRecordName === "Value Added Build"
                ).masterRecordID;
                this.cellFusionID = res.find(
                    (build) => build.masterRecordName === "Cell Fusion"
                ).masterRecordID;
            }
        });
    }
}
