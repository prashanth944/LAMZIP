import { Component, Input, OnInit, ViewEncapsulation } from "@angular/core";
import { ClipboardService } from "ngx-clipboard";
import { Plant } from "../../../core/model/user.model";

@Component({
    selector: "pmpm-quick-links",
    templateUrl: "./quick-links.component.html",
    styleUrls: ["./quick-links.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class QuickLinksComponent {
    @Input() site: Plant;
    @Input() role = "";

    constructor(private clipboardService: ClipboardService) {}

    copyText(text) {
        this.clipboardService.copyFromContent(text);
    }

    gotoPage(page: string, site: string) {
        let url = "";
        switch (page) {
            case "sap":
                url =
                    site === "Fremont"
                        ? "https://epp.fremont.lamrc.net/irj/portal?NavigationTarget=navurl://e9dc0731c19963b952ca3fbeceed6db3"
                        : "https://epp.fremont.lamrc.net/irj/portal?NavigationTarget=navurl://e9dc0731c19963b952ca3fbeceed6db3";
                window.open(url, "_blank");
                break;
            case "fpo":
                url =
                    site === "Fremont"
                        ? "https://lamresearch.quickbase.com/db/bgmh64wey"
                        : "";
                window.open(url, "_blank");
                break;
            case "thePoint":
                url =
                    site === "Fremont"
                        ? "http://thepoint.lamrc.net/Pages/default.aspx"
                        : "http://thepoint.lamrc.net/Pages/default.aspx";
                window.open(url, "_blank");
                break;
            case "NCi":
            case "NCe":
                url =
                    site === "Fremont"
                        ? "https://trackwise.lamresearch.com/trackwise/"
                        : "https://trackwise.lamresearch.com/trackwise/servlet/TeamAccess/Login";
                window.open(url, "_blank");
                break;
            case "5S":
                url =
                    site === "Fremont"
                        ? "https://lamresearch.quickbase.com/db/bm2pq894b?a=td"
                        : "";
                window.open(url, "_blank");
                break;
            case "toolInfoTag":
                url =
                    site === "Fremont"
                        ? "https://lamresearch-my.sharepoint.com/:w:/p/philip_lu/EfvNXaPFyaJJvXofdEDQRO4BeKr7tiiPI070n-tTqQcpjw?email=Ed.Nono%40lamresearch.com&e=4%3amxhI0z&at=9"
                        : "";
                window.open(url, "_blank");
                break;
            case "weeklyRisk":
                url =
                    site === "Fremont"
                        ? "https://lamresearch.quickbase.com/db/bntdxcvkt?a=q&qid=9"
                        : "";
                window.open(url, "_blank");
                break;
            case "soe":
                url =
                    site === "Fremont"
                        ? "https://lamresearch.sharepoint.com/sites/PMPM/SOE%20%20Fremont/Forms/AllItems.aspx"
                        : "https://lamresearch.sharepoint.com/sites/PilotOpsTuaEng/SOE/";
                window.open(url, "_blank");
                break;
            case "urbp":
                url =
                    site === "Fremont"
                        ? "https://lamresearch.quickbase.com/db/bgmsi55gw?a=td"
                        : "";
                window.open(url, "_blank");
                break;
            case "decon":
                url =
                    site === "Fremont"
                        ? "https://lamresearch.quickbase.com/db/br58ffcgu?a=td"
                        : "";
                window.open(url, "_blank");
                break;
            case "issuesLog":
                url =
                    site === "Fremont"
                        ? "https://lamresearch.quickbase.com/db/bgmh64wg7?a=td"
                        : "";
                window.open(url, "_blank");
                break;
            case "utilization":
                url =
                    site === "Fremont"
                        ? "https://app.powerbi.com/groups/41f4aec7-b863-401d-a37d-5b5561585dc6/reports/807d1240-1c14-42e2-8fb9-05a3d0522403/ReportSectionf4aa0acdc5fb2f927968"
                        : "https://lamresearch.quickbase.com/db/brqaqhw2i?a=td";
                window.open(url, "_blank");
                break;
            case "lamFiscalCal":
                url =
                    site === "Fremont"
                        ? "https://thepoint.lamrc.net/dept/Finance/FinanceForms/Documents/fiscal calendar (new).xlsx"
                        : "https://thepoint.lamrc.net/dept/Finance/FinanceForms/Documents/fiscal calendar (new).xlsx";
                window.open(url, "_blank");
                break;
            case "rmbwa":
                url =
                    site === "Fremont"
                        ? "http://ehsets.fremont.lamrc.net/EHSETS/RMBWA.aspx"
                        : "http://ehsets.fremont.lamrc.net/EHSETS/RMBWA.aspx";
                window.open(url, "_blank");
                break;
            case "usbRequest":
                url =
                    site === "Fremont"
                        ? "https://lamresearch.quickbase.com/db/bn4waf4y3?a=td"
                        : "";
                window.open(url, "_blank");
                break;
            case "ehs":
                url =
                    site === "Fremont"
                        ? "http://ehsets.fremont.lamrc.net/"
                        : "http://ehsets.fremont.lamrc.net/";
                window.open(url, "_blank");
                break;
            case "lockerRequest":
                url =
                    site === "Fremont"
                        ? "https://lamresearch.quickbase.com/db/bqunhtsn9"
                        : "";
                window.open(url, "_blank");
                break;
            case "dos":
                url =
                    site === "Fremont"
                        ? ""
                        : "https://lamresearch.quickbase.com/db/bn5dsbi44?a=nwr";
                window.open(url, "_blank");
                break;
            case "amp":
                url =
                    site === "Fremont"
                        ? ""
                        : "https://lamresearch.quickbase.com/db/bpbs6gzf9";
                window.open(url, "_blank");
                break;
            case "pbo":
                url =
                    site === "Fremont"
                        ? ""
                        : "https://lamresearch.quickbase.com/db/bpdcbu58m";
                window.open(url, "_blank");
                break;
            case "peo":
                url =
                    site === "Fremont"
                        ? ""
                        : "https://lamresearch.quickbase.com/db/bpdg9vhgn";
                window.open(url, "_blank");
                break;
            case "tpo":
                url =
                    site === "Fremont"
                        ? ""
                        : "https://lamresearch.quickbase.com/db/bhmqdixf4";
                window.open(url, "_blank");
                break;
            case "vfd":
                url =
                    site === "Fremont"
                        ? ""
                        : "https://lamresearch.quickbase.com/db/bp6722up5?a=q&qid=8";
                window.open(url, "_blank");
                break;
            case "vfdAss":
                url =
                    site === "Fremont"
                        ? ""
                        : "https://lamresearch.quickbase.com/db/bp6722up5?a=q&qid=12&dlta=mog~";
                window.open(url, "_blank");
                break;
            case "wvd":
                url =
                    site === "Fremont"
                        ? ""
                        : "https://go.microsoft.com/fwlink/?linkid=2068602";
                window.open(url, "_blank");
                break;
            case "ehsDB":
                url =
                    site === "Fremont"
                        ? ""
                        : "https://app.powerbi.com/groups/me/reports/d51cb11c-d401-4148-8595-8ff3d7762971/ReportSection7c773e26e06d5a0a4969?ctid=918079db-c902-4e29-b22c-9764410d0375&openReportSource=ReportInvitation";
                window.open(url, "_blank");
                break;
            case "mtt":
                url =
                    site === "Fremont"
                        ? "https://lamresearch.sharepoint.com/sites/PilotPCFSProgram/Lists/Issue%20tracker/Current%20Issues.aspx?"
                        : "";
                window.open(url, "_blank");
                break;
            case "safe":
                url =
                    site === "Fremont"
                        ? "https://lamresearch.sharepoint.com/sites/EHS_Fremont/Lists/SAFE%20Permit%20Fremont/AllItems.aspx"
                        : "https://vfd.fremont.lamrc.net/safe";
                window.open(url, "_blank");
                break;
            case "workNexus":
                url =
                    site === "Fremont"
                        ? "https://extranet3.superior-sdc.com/worknexus/lamresearch.nsf"
                        : "https://lamresearch.worknexusvms.net/";
                window.open(url, "_blank");
                break;
            case "lamTraining":
                url =
                    site === "Fremont"
                        ? "https://lamcorp.plateau.com/learning/user/personal/landOnPortalHome.do"
                        : "https://nam02.safelinks.protection.outlook.com/?url=https%3A%2F%2Flamcorp.plateau.com%2Flearning%2Fuser%2Fpersonal%2FlandOnPortalHome.do%3FOWASP_CSRFTOKEN%3DL22R-JOL9-E9ZD-0ILT-F793-A5I7-1ZHZ-D6VL%26fromSF%3DY%26fromDeepLink%3Dtrue%26pageID%3D&data=04%7C01%7CXinhui.Mo%40lamresearch.com%7C3ef991313a9040c4dfbf08da038c56f1%7C918079dbc9024e29b22c9764410d0375%7C0%7C0%7C637826198559343138%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000&sdata=jz22M%2BFgQmKRK80O2uybMYhYfm7VQXikKD%2B2UH8oBuE%3D&reserved=0";
                window.open(url, "_blank");
                break;
            case "pilotTC":
                url =
                    site === "Fremont"
                        ? ""
                        : "https://lamresearch.quickbase.com/db/biagn2y8e?a=td";
                window.open(url, "_blank");
                break;
            case "testTSDB":
                url =
                    site === "Fremont"
                        ? ""
                        : "https://lamresearch.quickbase.com/db/bq977hrpw?a=td";
                window.open(url, "_blank");
                break;
            case "toolReplenishment":
                url =
                    site === "Fremont"
                        ? "https://lamresearch.quickbase.com/db/bm2pq894b?a=q&qid=1"
                        : "https://lamresearch.quickbase.com/db/bpdcbu58m?a=showpage&edit=1&pageid=115";
                window.open(url, "_blank");
                break;
            case "sharePoint":
                url =
                    site === "Fremont"
                        ? "https://sharepoint.lamrc.net/dept/PilotOpsMfg/default.aspx"
                        : "https://sharepoint.lamrc.net/dept/PilotOpsMfg/default.aspx";
                window.open(url, "_blank");
                break;
            case "ADPeTime":
                url =
                    site === "Fremont"
                        ? "https://eetd2.adp.com/111xntpstatic/applications/navigator/html5/dist/container/index.html?version=8.1.10.1111#/"
                        : "https://myapps.microsoft.com/signin/1a8747e0-4120-4391-8e5b-57bf75325cc2?tenantId=918079db-c902-4e29-b22c-9764410d0375&relaystate=https://fed.adp.com/saml/fedlanding.html?EETDC2";
                window.open(url, "_blank");
                break;
            case "matrix":
                url =
                    site === "Fremont"
                        ? "http://kmmatrix.fremont.lamrc.net/"
                        : "http://kmmatrix.fremont.lamrc.net/";
                window.open(url, "_blank");
                break;
            case "freestock":
                url =
                    site === "Fremont"
                        ? ""
                        : "https://sharepoint.lamrc.net/dept/GSCM/projects/TFS/_layouts/15/WopiFrame.aspx?sourcedoc=%7bEFE49349-FB9B-40D0-AB8E-ACFADD4B4B15%7d&file=Gexpro%20FLoorstock%20Fill%20list.xls&action=default";
                window.open(url, "_blank");
                break;
            case "DDS2000":
                url =
                    site === "Fremont"
                        ? "https://thepoint.lamrc.net/dept/EngPortal/DDS2000/Pages/default.aspx"
                        : "https://thepoint.lamrc.net/dept/EngPortal/DDS2000/Documents/Current/DDS2000.xlsm";
                window.open(url, "_blank");
                break;
            case "userGuide":
                url =
                    "http://lamresearch.sharepoint.com/sites/PMPM/PMPM%20Documentation/Forms/AllItems.aspx?id=%2fsites%2fPMPM%2fPMPM%20Documentation%2fPMPM%20Super%20User%20Documentation&viewid=51bf6b44-de9b-4ff7-8a07-3c293a15a426";
                window.open(url, "_blank");
                break;
            case "greyMaterial":
                url =
                    site === "Fremont"
                        ? "https://lamresearch-my.sharepoint.com/:x:/p/omar_ornelasgonzalez/EeHi6_zNkgNDrFoB1klUPFIBHpHsrAPZj2yrIv_srXK5bA?"
                        : "https://lamresearch.sharepoint.com/:w:/r/sites/PilotMfg/Shared%20Documents/Pilot%20Training%20Center/6000%20-%20Pilot%20Reference%20Documents/6030%20-%20Pilot%20Grey%20Material%20Process.docx?d=wb4f8ed6a5a234df781f4bd3680450d98&csf=1&web=1&e=jxpiLm";
                window.open(url, "_blank");
                break;
        }
    }
}
