export class Holiday {
    public FactoryShutDown: boolean;
    public HolidayDateDaily: Date;
    public HolidayID: number;
    public Name: string;
    public PlantID: number;
}

export class HolidayCalendar {
    date: number;
    month: string;
    label: string;
    isEntireFactoryShutDown: boolean;
    color: string;
}
