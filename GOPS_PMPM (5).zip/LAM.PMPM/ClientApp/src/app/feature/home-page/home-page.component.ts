import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { AppStoreService } from "../../core/app-store.service";
import { role, userRoles } from "../../core/model/common.constant";
import { HomePageService } from "./service/home-page.service";

@Component({
    selector: "pmpm-home-page",
    templateUrl: "./home-page.component.html",
    styleUrls: ["./home-page.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class HomeComponent implements OnInit {
    profile: any;
    userRoles: string[] = userRoles;
    public userName = "";
    public found = false;
    public isLoading = true;
    public plantName = "";

    //roles
    public superUser = false;
    public manager = false;
    public projectManager = false;
    public lead = false;
    public technician = false;
    public supervisor = false;
    public other = false;

    constructor(
        private appStoreService: AppStoreService,
        private service: HomePageService
    ) {}
    ngOnInit() {
        this.isLoading = true;
        this.appStoreService.getUserRoles().subscribe((res) => {
            let newUserRoles: string[] = [];
            if (res && res.length > 0) {
                newUserRoles = res;
                this.found = newUserRoles.some((r) =>
                    this.userRoles.includes(r)
                );
                this.setHomePage(newUserRoles);
                this.isLoading = false;
            }
        });

        this.appStoreService.getCurrentSite().subscribe((plant) => {
            if (plant) {
                this.plantName = plant.plantName;
            }
        });

        this.appStoreService.getLoggedInUser().subscribe((info) => {
            if (info) {
                this.userName = info.givenName;
            }
        });
    }

    private setHomePage(roles: string[]): void {
        if (roles.includes(role.SuperUser)) this.superUser = true;
        else if (roles.includes(role.Manager)) this.manager = true;
        else if (roles.includes(role.ProjectManager))
            this.projectManager = true;
        else if (roles.includes(role.Leads)) this.lead = true;
        else if (roles.includes(role.Technician)) this.technician = true;
        else if (roles.includes(role.Supervisor)) this.supervisor = true;
        else this.other = true;
    }
}
