import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { environment } from "../../../../environments/environment.dev_server";
import { MasterRecords } from "../../capacity-planning/adjust-capacity/bay/models/MasterRecords";
import { Observable } from "rxjs";

@Injectable({
    providedIn: "root",
})
export class HomePageService {
    constructor(private http: HttpClient) {}

    readonly apiUrl = `${environment.apiUrl}`;

    getHolidays(plantID: number) {
        return this.http.get<any[]>(
            this.apiUrl + "/Admin/GetHolidays/" + plantID
        );
    }

    getHomeWIPbuild(plantID: number, buildStyleID: number) {
        return this.http.get<any[]>(
            this.apiUrl +
                "/HomeRole/GetHomeWIPbuild/" +
                plantID +
                "/" +
                buildStyleID
        );
    }

    getBuildStyleDDL(): Observable<MasterRecords[]> {
        return new Observable<MasterRecords[]>((observer) => {
            this.http
                .get<MasterRecords[]>(this.apiUrl + "/Modules/GetBuildStyleDDL")
                .subscribe((res) => {
                    observer.next(res);
                });
        });
    }
}
