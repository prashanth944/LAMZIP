import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Inject,
  Input,
  NgZone,
  OnDestroy,
  Output,
  PLATFORM_ID,
  ViewChild,
  ViewEncapsulation,
} from "@angular/core";
import { isPlatformBrowser } from "@angular/common";
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import { GanttChartService } from "./service/gantt-chart.service";
import {
  dayWeek,
  GanttChartViewModel,
  GanttData,
  ProductNameBay,
  ProductNameLabor,
  ProductNameSum,
  ScheduledBay,
  ScheduledLabor,
  ScheduleSum,
  WeeklyDatesBay,
  WeeklyDatesLabor,
  WeeklyDatesSum,
} from "./model/gantt-chart.model";
import { AppStoreService } from "../../core/app-store.service";
import { Plant, UserModel } from "../../core/model/user.model";
import {
  AggregateDescriptor,
  AggregateResult,
  CompositeFilterDescriptor,
  distinct,
  filterBy,
} from "@progress/kendo-data-query";
import { MultiSelectComponent } from "@progress/kendo-angular-dropdowns";
import * as moment from "moment";
import { Item } from "../model/item";
import { MpsService } from "../master-production-schedule/mps-service/mps.service";
import { AdjustScheduleViewModule } from "../master-production-schedule/model/mps-summary";
import { DomSanitizer, SafeStyle } from "@angular/platform-browser";
import { ContentScrollEvent } from "@progress/kendo-angular-grid";
import { Labor, Module } from "../other/Models/defaults.model";

@Component({
  selector: "pmpm-gantt-chart",
  templateUrl: "./gantt-chart.component.html",
  styleUrls: ["./gantt-chart.component.css"],
  encapsulation: ViewEncapsulation.None,
})
export class GanttChartComponent implements AfterViewInit, OnDestroy {
  @ViewChild("multiselect") public multiselect: MultiSelectComponent;
  @Input() canUserEdit = false;
  @Input() inWIP = false;
  @Input() productionPlanID: number;
  @Input() planName = "";
  @Output() closeChart: EventEmitter<boolean> = new EventEmitter<boolean>();

  private chart: am4charts.XYChart;
  public chartData: GanttChartViewModel[] = [];
  public tempChartData: GanttChartViewModel[] = [];
  public toolTypeChartData: GanttChartViewModel[] = [];
  public productTypeChartData: GanttChartViewModel[] = [];
  public plantSpeceficChartData: GanttData[] = [];
  public site: Plant;
  public toolTypeItems: string[] = [];
  public tempToolTypeItems: string[] = [];
  public productTypeItems: string[] = [];
  public tempProductTypeItems: string[] = [];
  public toolTypeValue: string[] = [];
  public productTypeValue: string[] = [];
  public minFromDate: Date = new Date();
  public maxFromDate: Date = new Date();
  public minToDate: Date = new Date();
  public maxToDate: Date = new Date();
  public chartMinDate: Date;
  public chartMaxDate: Date;
  public filter: CompositeFilterDescriptor;
  public isLoading = true;
  public buildTypeItems: string[] = []; //User Story 37057: Add Build Type to Gantt Charts
  public tempBuildTypeItems: string[] = [];
  public buildTypeValue: string[] = [];

  public openShiftLaunchPopup = false;
  public openTimePopup = false;
  public moduleProcessData: Item[] = [];
  public benOrPsn: Item[] = [];
  public tempBenOrPsn: Item[] = [];
  public benOrPsnData: Item;
  public moduleProcess: Item;
  public noOfDays = 0;
  public enableSaveModuleProcess = false;
  public userDetail: UserModel;

  public revenueTypeItems: string[] = []; //User Story 37057: Add Build Type to Gantt Charts
  public tempRevenueTypeItems: string[] = [];
  public revenueTypeValue: string[] = [];

  public recordTypeItems: string[] = []; //User Story 37057: Add Build Type to Gantt Charts
  public tempRecordTypeItems: string[] = [];
  public recordTypeValue: string[] = [];
  public noOfDaysError = false;
  public scheduleStatusMessage = "";
  public openScheduleGeneratedPopUp = false;
  public moduleToBeUpdate: GanttChartViewModel;
  public gridDataForBaysRemaining: ScheduledBay[] = [];
  public BaysProductName: ProductNameBay[] = [];
  public BaysWeeklyDates: WeeklyDatesBay[] = [];

  public gridDataForLaborRemaining: ScheduledLabor[] = [];
  public LaborProductName: ProductNameLabor[] = [];
  public LaborWeeklyDates: WeeklyDatesLabor[] = [];

  public baysWeekColumns: dayWeek[] = [];
  public baysWeekAvailableColumns: dayWeek[] = [];
  public laborWeekColumns: dayWeek[] = [];
  public scheduleSumColumn: dayWeek[] = [];
  public aggregates: AggregateDescriptor[] = [];
  public total: AggregateResult;

  public previousCellValue = -1;
  public startFullQuarter: Date;
  public endFullQuarter: Date;
  public grid1;
  public grid2;
  public grid3;
  public scrolledLeft = false;
  public scrollPosition = 0;
  public scheduleSum: ScheduleSum[] = [];
  public weeklyDatesSum: WeeklyDatesSum[] = [];
  public productNameSum: ProductNameSum[] = [];

  public originalLaborData: Labor[] = [];
  public originalModuleData: Module[] = [];
  public laborUsageWarningRed = 0;
  public laborUsageWarningYellow = 0;
  public bayUsageWarningYellow = 0;
  public bayUsageWarningRed = 0;

  public loadSum = true;
  public loadBays = true;
  public loadLabor = true;

  constructor(
    @Inject(PLATFORM_ID) private platformId,
    private zone: NgZone,
    private service: GanttChartService,
    private changeDetector: ChangeDetectorRef,
    private appStoreService: AppStoreService,
    private mpsService: MpsService,
    private sanitizer: DomSanitizer
  ) { }
  // Run the function only in the browser
  browserOnly(f: () => void) {
    if (isPlatformBrowser(this.platformId)) {
      this.zone.runOutsideAngular(() => {
        f();
      });
    }
  }

  ngAfterViewInit() {
    this.grid1 = document.querySelector("#grid1 .k-grid-content");

    this.grid2 = document.querySelector("#grid2 .k-grid-content");

    this.grid3 = document.querySelector("#grid3 .k-grid-content");
    this.isLoading = true;
    const toDate = new Date();
    toDate.setMonth(new Date().getMonth() + 24).toString();
    const fromDate = new Date();
    fromDate.setMonth(new Date().getMonth() - 6).toString();

    const defaultToDate = new Date();
    defaultToDate.setMonth(new Date().getMonth() + 12).toString();

    this.maxFromDate = toDate;
    this.minFromDate = fromDate;
    this.maxToDate = toDate;
    this.minToDate = new Date();
    this.chartMaxDate = defaultToDate;
    this.chartMinDate = this.minToDate;

    const today = new Date();
    const quarter = Math.floor(today.getMonth() / 3);

    this.startFullQuarter = this.chartMinDate;
    this.endFullQuarter = new Date(
      this.startFullQuarter.getFullYear(),
      this.startFullQuarter.getMonth() + 7,
      0
    );

    this.changeDetector.detectChanges();
    this.appStoreService.getCurrentSite().subscribe((site) => {
      this.site = site;
      this.appStoreService.getLoggedInUser().subscribe((user) => {
        this.appStoreService
          .getUserDetails(user.mail)
          .subscribe((res) => {
            this.userDetail = res;
          });
      });
      this.getGanttChartData();
      this.getLaborDefaultData();
      this.getModuleDefaultData();
      this.GetGanttChartSumOfSchedulebay();
    });
  }

  getLaborDefaultData() {
    this.service.GetLabourDefaultData().subscribe((res) => {
      if (res) {
        this.originalLaborData = JSON.parse(JSON.stringify(res));
        this.laborUsageWarningRed = this.originalLaborData.filter(
          (x) => x.plantID == this.site?.plantId
        )[0].laborUsageWarningRed;
        this.laborUsageWarningYellow = this.originalLaborData.filter(
          (x) => x.plantID == this.site?.plantId
        )[0].laborUsageWarningYellow;
        this.GetGanttChartScheduleLabor();
      }
    });
  }

  getModuleDefaultData() {
    this.service.GetModuleDefaultData().subscribe((module) => {
      if (module) {
        this.originalModuleData = JSON.parse(JSON.stringify(module));
        this.bayUsageWarningRed = this.originalModuleData.filter(
          (x) => x.plantID == this.site?.plantId
        )[0].bayUsageWarningRed;
        this.bayUsageWarningYellow = this.originalModuleData.filter(
          (x) => x.plantID == this.site?.plantId
        )[0].bayUsageWarningYellow;
        this.GetGanttChartScheduleBay();
      }
    });
  }

  getAssemblyTotal(index: number) {
    let total = 0;
    this.gridDataForLaborRemaining.forEach((item) => {
      if (item.ProductName.Laborgroup === "Assembly")
        total += item?.WeeklyDates[index]?.TotalRemainingHour;
    });
    return total;
  }
  getTestTotal(index: number) {
    let total = 0;
    this.gridDataForLaborRemaining.forEach((item) => {
      if (item.ProductName.Laborgroup === "Test")
        total += item?.WeeklyDates[index]?.TotalRemainingHour;
    });
    return total;
  }
  GetGanttChartScheduleBay() {
    this.gridDataForBaysRemaining = [];
    this.BaysProductName = [];
    this.service
      .GetGanttChartScheduleBayLimitedFilter(
        this.site.plantId,
        moment(this.chartMinDate).format("MM/DD/yyyy"),
        moment(this.chartMaxDate).format("MM/DD/yyyy"),
        this.productionPlanID
      )
      .subscribe((res) => {
        if (res && res.length > 0) {
          this.gridDataForBaysRemaining = res;
          this.gridDataForBaysRemaining.forEach((item) => {
            this.baysWeekColumns = [];
            this.baysWeekAvailableColumns = [];
            item.ProductName.TotalRemaining =
              this.mapBaysDateColumn(item.WeeklyDates);
            item.ProductName.TotalAvailablity =
              this.mapBaysDateTotalAvailablity(item.WeeklyDates);
            this.BaysProductName.push(item.ProductName);
          });
        }
        this.loadBays = false;
      });
  }

  mapBaysDateColumn(daysData: any): number[] {
    const daysDataArray: number[] = [];
    for (let i = 0; i < daysData.length; i++) {
      if (
        this.baysWeekColumns.filter(
          (item) =>
            item.field === moment(daysData[i].BayDate).format("M-D")
        ).length === 0
      ) {
        const c = daysData[i].TotalRemaining;
        daysDataArray.push(c);
        const dayWk: dayWeek = new dayWeek();
        dayWk.field = moment(daysData[i].BayDate).format("M-D");
        this.baysWeekColumns.push(dayWk);
      }
    }
    return daysDataArray;
  }
  mapBaysDateTotalAvailablity(daysData: any): number[] {
    const daysDataArray: number[] = [];
    for (let i = 0; i < daysData.length; i++) {
      if (
        this.baysWeekAvailableColumns.filter(
          (item) =>
            item.field === moment(daysData[i].BayDate).format("M-D")
        ).length === 0
      ) {
        const c = daysData[i].TotalAvailablity;
        daysDataArray.push(c);
        const dayWk: dayWeek = new dayWeek();
        dayWk.field = moment(daysData[i].BayDate).format("M-D");
        this.baysWeekAvailableColumns.push(dayWk);
      }
    }
    return daysDataArray;
  }
  GetGanttChartScheduleLabor() {
    this.gridDataForLaborRemaining = [];
    this.LaborProductName = [];
    this.laborWeekColumns = [];
    this.service
      .GetGanttChartScheduleLaborLimitedFilter(
        this.site.plantId,
        moment(this.chartMinDate).format("MM/DD/yyyy"),
        moment(this.chartMaxDate).format("MM/DD/yyyy"),
        this.productionPlanID
      )
      .subscribe((res) => {
        if (res && res.length > 0) {
          this.gridDataForLaborRemaining = res;
          this.gridDataForLaborRemaining.forEach((item, index) => {
            item.ProductName.TotalRemainingHour =
              this.mapLaborDateColumn(item.WeeklyDates, index);
            item.ProductName.TotalAvailablity =
              this.mapLaborDateTotalAvailbaleity(
                item.WeeklyDates
              );
            this.LaborProductName.push(item.ProductName);
          });
        }
        this.loadLabor = false;
      });
  }

  mapLaborDateColumn(daysData: any, rownum: number): number[] {
    const daysDataArray: number[] = [];
    for (let i = 0; i < daysData.length; i++) {
      const c = daysData[i].TotalRemainingHour;
      daysDataArray.push(c);
      const dayWk: dayWeek = new dayWeek();
      dayWk.field = moment(daysData[i].LaborDate).format("M-D");
      if (rownum == 0) {
        this.laborWeekColumns.push(dayWk);
      }
    }
    return daysDataArray;
  }

  mapLaborDateTotalAvailbaleity(daysData: any): number[] {
    const daysDataArray: number[] = [];
    for (let i = 0; i < daysData.length; i++) {
      const c = daysData[i].TotalAvailablity;
      daysDataArray.push(c);
    }
    return daysDataArray;
  }

  GetGanttChartSumOfSchedulebay() {
    this.scheduleSum = [];
    this.scheduleSumColumn = [];
    this.productNameSum = [];
    this.service
      .GetGanttChartSumSchedulebayLimitedFilter(
        this.site.plantId,
        moment(this.chartMinDate).format("MM/DD/yyyy"),
        moment(this.chartMaxDate).format("MM/DD/yyyy"),
        this.productionPlanID
      )
      .subscribe((res) => {
        if (res && res.length > 0) {
          const productName = new ProductNameSum();
          productName.summaryItems = "Total Remaining Bays";
          productName.TotalRemaining = [];
          this.weeklyDatesSum = [];
          res.forEach((item) => {
            this.weeklyDatesSum.push(item.WeeklyDates);
          });
          this.scheduleSum.push({
            ProductName: productName,
            WeeklyDates: JSON.parse(
              JSON.stringify(this.weeklyDatesSum)
            ),
          });

          this.service
            .GetGanttChartSumScheduleLaborLimitedFilter(
              this.site.plantId,
              moment(this.chartMinDate).format("MM/DD/yyyy"),
              moment(this.chartMaxDate).format("MM/DD/yyyy"),
              this.productionPlanID
            )
            .subscribe((result) => {
              if (result && result.length > 0) {
                const productName1 = new ProductNameSum();
                productName1.summaryItems =
                  "Total Remaining Hours";
                productName1.TotalRemaining = [];
                this.weeklyDatesSum = [];
                result.forEach((item) => {
                  this.weeklyDatesSum.push(item.WeeklyDates);
                });
                this.scheduleSum.push({
                  ProductName: productName1,
                  WeeklyDates: JSON.parse(
                    JSON.stringify(this.weeklyDatesSum)
                  ),
                });

                this.service
                  .GetGanttChartLaunchDates(
                    moment(this.chartMinDate).format(
                      "MM/DD/yyyy"
                    ),
                    moment(this.chartMaxDate).format(
                      "MM/DD/yyyy"
                    ),
                    this.productionPlanID
                  )
                  .subscribe((response) => {
                    if (response && response.length > 0) {
                      const productName2 =
                        new ProductNameSum();
                      productName2.summaryItems =
                        "Number of Launches";
                      productName2.TotalRemaining = [];
                      this.weeklyDatesSum.forEach(
                        (item) => {
                          if (
                            response.filter(
                              (d) =>
                                d.Date ===
                                item.Date
                            ).length > 0
                          ) {
                            item.TotalRemaining =
                              response.filter(
                                (d) =>
                                  d.Date ===
                                  item.Date
                              )[0].TotalRemaining;
                          } else {
                            item.TotalRemaining = 0;
                          }
                        }
                      );

                      this.scheduleSum.push({
                        ProductName: productName2,
                        WeeklyDates: JSON.parse(
                          JSON.stringify(
                            this.weeklyDatesSum
                          )
                        ),
                      });
                      this.scheduleSum.forEach(
                        (item, index) => {
                          item.ProductName.TotalRemaining =
                            this.mapScheduleSumColumn(
                              item.WeeklyDates,
                              index
                            );
                          this.productNameSum.push(
                            item.ProductName
                          );
                        }
                      );
                    } else {
                      const productName2 =
                        new ProductNameSum();
                      productName2.summaryItems =
                        "Number of Launches";
                      productName2.TotalRemaining = [];
                      this.weeklyDatesSum.forEach(
                        (item) => {
                          item.TotalRemaining = 0;
                        }
                      );
                      this.scheduleSum.push({
                        ProductName: productName2,
                        WeeklyDates: JSON.parse(
                          JSON.stringify(
                            this.weeklyDatesSum
                          )
                        ),
                      });
                      this.scheduleSum.forEach(
                        (item, index) => {
                          item.ProductName.TotalRemaining =
                            this.mapScheduleSumColumn(
                              item.WeeklyDates,
                              index
                            );
                          this.productNameSum.push(
                            item.ProductName
                          );
                        }
                      );
                    }
                  });
              }
            });
        }
        this.loadSum = false;
      });
  }

  mapScheduleSumColumn(daysData: any, rownum: number): number[] {
    const daysDataArray: number[] = [];
    for (let i = 0; i < daysData.length; i++) {
      const c = daysData[i].TotalRemaining;
      daysDataArray.push(c);
      const dayWk: dayWeek = new dayWeek();
      dayWk.field = moment(daysData[i].Date).format("M-D");
      if (rownum == 0) {
        this.scheduleSumColumn.push(dayWk);
      }
    }
    return daysDataArray;
  }

  getGanttChartData() {
    this.service
      .GetGanttChartData(
        this.site.plantId,
        this.inWIP,
        this.productionPlanID
      )
      .subscribe((res) => {
        if (res && res.length > 0) {
          this.chartData = [];
          this.toolTypeItems = [];
          this.productTypeItems = [];
          this.tempToolTypeItems = [];
          this.tempProductTypeItems = [];
          this.buildTypeItems = [];
          this.tempBuildTypeItems = [];
          this.revenueTypeItems = [];
          this.tempRevenueTypeItems = [];
          this.chartData = res;
          this.tempChartData = JSON.parse(
            JSON.stringify(this.chartData)
          );

          let data1: any = this.distinctPrimitive("toolTypeName");
          data1 = data1.flatMap((f) => (f ? [f] : []));
          data1.sort(function (a, b) {
            const textA = a?.toUpperCase();
            const textB = b?.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
          });
          this.toolTypeItems = data1;
          this.tempToolTypeItems = JSON.parse(
            JSON.stringify(this.toolTypeItems)
          );

          let data2: any = this.distinctPrimitive("productGroupName");
          data2 = data2.flatMap((f) => (f ? [f] : []));
          data2.sort(function (a, b) {
            const textA = a?.toUpperCase();
            const textB = b?.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
          });
          this.productTypeItems = data2;
          this.tempProductTypeItems = JSON.parse(
            JSON.stringify(this.productTypeItems)
          );

          let data3: any = this.distinctPrimitive("buildTypeName");
          data3 = data3.flatMap((f) => (f ? [f] : []));
          data3.sort(function (a, b) {
            const textA = a?.toUpperCase();
            const textB = b?.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
          });
          this.buildTypeItems = data3;
          this.tempBuildTypeItems = JSON.parse(
            JSON.stringify(this.buildTypeItems)
          );

          let data4: any = this.distinctPrimitive("revenueCode");
          data4 = data4.flatMap((f) => (f ? [f] : []));
          data4.sort(function (a, b) {
            const textA = a?.toUpperCase();
            const textB = b?.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
          });
          this.revenueTypeItems = data4;
          this.tempRevenueTypeItems = JSON.parse(
            JSON.stringify(this.revenueTypeItems)
          );

          let data5: any = this.distinctPrimitive("recordType");
          data5 = data5.flatMap((f) => (f ? [f] : []));
          data5.sort(function (a, b) {
            const textA = a?.toUpperCase();
            const textB = b?.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
          });
          this.recordTypeItems = data5;
          this.tempRecordTypeItems = JSON.parse(
            JSON.stringify(this.recordTypeItems)
          );

          this.isLoading = false;
          setTimeout(() => {
            this.buildChart(this.chartData);
          }, 10);
          this.changeDetector.detectChanges();
        }
        this.isLoading = false;
      });
  }

  public distinctPrimitive(fieldName: string): any {
    const distinctData: any[] = distinct(this.chartData, fieldName).map(
      (item) => item[fieldName]
    );
    distinctData.sort(function (a, b) {
      const textA = a?.toUpperCase();
      const textB = b?.toUpperCase();
      return textA < textB ? -1 : textA > textB ? 1 : 0;
    });
    return distinctData;
  }

  buildChart(chartData: GanttChartViewModel[]) {
    const colorSet = new am4core.ColorSet();

    colorSet.saturation = 0.4;
    this.plantSpeceficChartData = [];
    if (this.inWIP) {
      chartData.forEach((item) => {
        const dt = new GanttData();
        dt.module =
          this.site.plantName === "Fremont"
            ? item.pilotSerialNumber
            : item.ben;
        dt.moduleAndToolType =
          (this.site.plantName === "Fremont"
            ? item.pilotSerialNumber
            : item.ben) +
          " - " +
          item.toolTypeName;

        dt.subAssemblyStartDate = item.lprPlannedLaunchP09;

        let subAssyEndDate = null;
        if (
          item.lprPlannedLaunchP09 !== null &&
          item.lprPlannedLaunchP09 !== item.plannedIntegrationStart &&
          item.lprPlannedLaunchP09 !== item.plannedTestStart &&
          item.lprPlannedLaunchP09 !== item.plannedTestComplete
        ) {
          if (item.plannedIntegrationStart !== null) {
            subAssyEndDate = new Date(item.plannedIntegrationStart);
            subAssyEndDate.setDate(subAssyEndDate.getDate() - 1);
          } else if (item.plannedTestStart !== null) {
            subAssyEndDate = new Date(item.plannedTestStart);
            subAssyEndDate.setDate(subAssyEndDate.getDate() - 1);
          } else if (item.plannedTestComplete !== null) {
            subAssyEndDate = new Date(item.plannedTestComplete);
            subAssyEndDate.setDate(subAssyEndDate.getDate() - 1);
          } else {
            subAssyEndDate = new Date(
              moment(
                new Date(item.lprPlannedLaunchP09).setHours(24)
              ).format("yyyy-MM-DDTHH:mm:ss")
            );
          }

          dt.subAssemblyEndDate =
            new Date(dt.subAssemblyStartDate).getTime() ===
              new Date(subAssyEndDate)?.getTime()
              ? new Date(
                moment(
                  new Date(subAssyEndDate).setHours(24)
                ).format("yyyy-MM-DDTHH:mm:ss")
              )
              : subAssyEndDate;
        } else {
          dt.subAssemblyEndDate = null;
        }

        dt.integrationStartDate = item.plannedIntegrationStart;

        let intEndDate = null;
        if (item.plannedIntegrationStart !== null) {
          if (item.plannedTestStart !== null) {
            intEndDate = new Date(item.plannedTestStart);
            intEndDate.setDate(intEndDate.getDate() - 1);
          } else if (item.plannedTestComplete !== null) {
            intEndDate = new Date(item.plannedTestComplete);
            intEndDate.setDate(intEndDate.getDate() - 1);
          } else {
            intEndDate = new Date(
              moment(
                new Date(item.plannedIntegrationStart).setHours(
                  24
                )
              ).format("yyyy-MM-DDTHH:mm:ss")
            );
          }

          dt.integrationEndDate =
            new Date(dt.integrationStartDate).getTime() ===
              new Date(intEndDate)?.getTime()
              ? new Date(
                moment(
                  new Date(intEndDate).setHours(24)
                ).format("yyyy-MM-DDTHH:mm:ss")
              )
              : intEndDate;
        } else {
          dt.integrationEndDate = null;
        }

        dt.testStartDate = item.plannedTestStart;
        dt.testEndDate =
          item.plannedTestStart !== null
            ? item.plannedTestComplete === item.plannedTestStart
              ? new Date(
                moment(
                  new Date(item.plannedTestStart).setHours(
                    24
                  )
                ).format("yyyy-MM-DDTHH:mm:ss")
              )
              : item.plannedTestComplete
            : null;

        dt.postTestStartDate = new Date(
          moment(
            new Date(item.plannedTestComplete).setHours(24)
          ).format("yyyy-MM-DDTHH:mm:ss")
        );
        dt.postTestEndDate =
          item.plannedManufacturingComplete !== null
            ? new Date(dt.postTestStartDate).getTime() ===
              new Date(item.plannedManufacturingComplete).getTime()
              ? new Date(
                moment(
                  new Date(
                    item.plannedManufacturingComplete
                  ).setHours(24)
                ).format("yyyy-MM-DDTHH:mm:ss")
              )
              : item.plannedManufacturingComplete
            : null;

        dt.actualSubAssemblyStartDate = item.actualLaunch;
        const actualSubAssyEndDate = new Date(
          item.actualIntegrationStart
        );
        actualSubAssyEndDate?.setDate(
          actualSubAssyEndDate?.getDate() - 1
        );
        dt.actualSubAssemblyEndDate =
          actualSubAssyEndDate !== null &&
            actualSubAssyEndDate !== undefined
            ? actualSubAssyEndDate
            : new Date(
              moment(
                new Date(item.actualLaunch)?.setHours(24)
              ).format("yyyy-MM-DDTHH:mm:ss")
            );

        dt.actualIntegrationStartDate =
          item.actualIntegrationStart !== null
            ? item.actualIntegrationStart
            : new Date(
              moment(
                new Date(item.actualLaunch)?.setHours(24)
              ).format("yyyy-MM-DDTHH:mm:ss")
            );
        const actualIntEndDate = new Date(item.actualTestStart);
        actualIntEndDate?.setDate(actualIntEndDate?.getDate() - 1);
        dt.actualIntegrationEndDate =
          actualIntEndDate !== null && actualIntEndDate !== undefined
            ? actualIntEndDate
            : new Date(
              moment(
                new Date(
                  item.actualIntegrationStart
                )?.setHours(24)
              ).format("yyyy-MM-DDTHH:mm:ss")
            );

        dt.actualTestStartDate =
          item.actualTestStart !== null
            ? item.actualTestStart
            : new Date(
              moment(
                new Date(
                  item.actualIntegrationStart
                )?.setHours(24)
              ).format("yyyy-MM-DDTHH:mm:ss")
            );
        dt.actualTestEndDate =
          item.actualTestComplete !== null
            ? item.actualTestComplete
            : new Date(
              moment(
                new Date(item.actualTestStart)?.setHours(24)
              ).format("yyyy-MM-DDTHH:mm:ss")
            );

        dt.actualPostTestStartDate =
          item.actualTestComplete !== null
            ? new Date(
              moment(
                new Date(item.actualTestComplete)?.setHours(
                  24
                )
              ).format("yyyy-MM-DDTHH:mm:ss")
            )
            : new Date(
              moment(
                new Date(item.actualTestStart)?.setHours(24)
              ).format("yyyy-MM-DDTHH:mm:ss")
            );
        dt.actualPostTestEndDate =
          item.actualManufacturingComplete !== null
            ? item.actualManufacturingComplete
            : new Date(
              moment(
                new Date(item.actualTestComplete)?.setHours(
                  24
                )
              ).format("yyyy-MM-DDTHH:mm:ss")
            );

        dt.EarliestStartDateFromDate = item.earliestStartDate;
        dt.EarliestStartDateToDate = moment(
          new Date(item.earliestStartDate)?.setHours(24)
        ).format("yyyy-MM-DDTHH:mm:ss");
        dt.RecordType = item.recordType;
        dt.RevenueCode = item.revenueCode;
        dt.FCID = item.fcid;
        dt.ToolTypeName = item.toolTypeName;
        dt.ProductGroupName = item.productGroupName;
        dt.MCSDFromDate = item.manufacturingCommitedShipDate;
        dt.MCSDToDate = moment(
          new Date(item.manufacturingCommitedShipDate).setHours(24)
        ).format("yyyy-MM-DDTHH:mm:ss");
        dt.TSDFromDate = item.targetShipDate;
        dt.TSDToDate = moment(
          new Date(item.targetShipDate)?.setHours(24)
        ).format("yyyy-MM-DDTHH:mm:ss");
        dt.CRDFromDate = item.customerRequestDate;
        dt.CRDToDate = moment(
          new Date(item.customerRequestDate)?.setHours(24)
        ).format("yyyy-MM-DDTHH:mm:ss");
        dt.SRDFromDate = item.salesOpsRequestDate;
        dt.SRDToDate = moment(
          new Date(item.salesOpsRequestDate)?.setHours(24)
        ).format("yyyy-MM-DDTHH:mm:ss");
        dt.planofRecordFromDate = item.planofRecord;
        dt.planofRecordToDate = moment(
          new Date(item.planofRecord)?.setHours(24)
        ).format("yyyy-MM-DDTHH:mm:ss");
        dt.BuildType = item.buildTypeName; //User Story 37057: Add Build Type to Gantt Charts
        dt.colorBar1 = am4core.color("#03fccf");
        dt.colorBar2 = am4core.color("#03fcf4");
        dt.colorBar3 = am4core.color("#03d7fc");
        dt.colorBar4 = am4core.color("#088bd1");
        dt.colorBar5 = am4core.color("#f06656");
        dt.colorBar6 = am4core.color("#fcf342");
        dt.colorBar7 = am4core.color("#6277fc");
        dt.colorBar8 = am4core.color("#217502");
        dt.colorBar9 = am4core.color("#b169c7");
        dt.colorBar10 = am4core.color("#f048ed");
        dt.colorBar11 = am4core.color("#999ff2");
        dt.colorBar12 = am4core.color("#7ae67a");
        dt.colorBar13 = am4core.color("#f28966");
        dt.colorBar14 = am4core.color("#000000");
        dt.colorBar15 = am4core.color("#ffffff");
        dt.colorBar16 = am4core.color("#a19d33");
        dt.strokeColor = this.getStrokeColor(item.buildTypeName);
        this.plantSpeceficChartData.push(dt);
      });
    } else {
      chartData.forEach((item) => {
        const dt = new GanttData();
        dt.module =
          this.site.plantName === "Fremont"
            ? item.pilotSerialNumber
            : item.ben;
        dt.moduleAndToolType =
          (this.site.plantName === "Fremont"
            ? item.pilotSerialNumber
            : item.ben) +
          " - " +
          item.toolTypeName;
        dt.subAssemblyStartDate = item.projectedLaunch;

        let subAssyEndDate = null;
        if (
          item.projectedLaunch !== null &&
          item.projectedLaunch !== item.projectedIntegrationStart &&
          item.projectedLaunch !== item.projectedTestStart &&
          item.projectedLaunch !== item.projectedTestComplete
        ) {
          if (item.projectedIntegrationStart !== null) {
            subAssyEndDate = new Date(
              item.projectedIntegrationStart
            );
            subAssyEndDate.setDate(subAssyEndDate.getDate() - 1);
          } else if (item.projectedTestStart !== null) {
            subAssyEndDate = new Date(item.projectedTestStart);
            subAssyEndDate.setDate(subAssyEndDate.getDate() - 1);
          } else if (item.projectedTestComplete !== null) {
            subAssyEndDate = new Date(item.projectedTestComplete);
            subAssyEndDate.setDate(subAssyEndDate.getDate() - 1);
          } else {
            dt.subAssemblyEndDate = null;
          }

          dt.subAssemblyEndDate =
            new Date(dt.subAssemblyStartDate).getTime() ===
              new Date(subAssyEndDate)?.getTime()
              ? new Date(
                moment(
                  new Date(subAssyEndDate).setHours(24)
                ).format("yyyy-MM-DDTHH:mm:ss")
              )
              : subAssyEndDate;
        } else {
          dt.subAssemblyEndDate = null;
        }

        dt.integrationStartDate = item.projectedIntegrationStart;

        let intEndDate = null;
        if (item.projectedIntegrationStart !== null) {
          if (item.projectedTestStart !== null) {
            intEndDate = new Date(item.projectedTestStart);
            intEndDate.setDate(intEndDate.getDate() - 1);
          } else if (item.projectedTestComplete !== null) {
            intEndDate = new Date(item.projectedTestComplete);
            intEndDate.setDate(intEndDate.getDate() - 1);
          } else {
            intEndDate = new Date(
              moment(
                new Date(
                  item.projectedIntegrationStart
                ).setHours(24)
              ).format("yyyy-MM-DDTHH:mm:ss")
            );
          }

          dt.integrationEndDate =
            new Date(dt.integrationStartDate).getTime() ===
              new Date(intEndDate)?.getTime()
              ? new Date(
                moment(
                  new Date(intEndDate).setHours(24)
                ).format("yyyy-MM-DDTHH:mm:ss")
              )
              : intEndDate;
        } else {
          dt.integrationEndDate = null;
        }

        dt.testStartDate = item.projectedTestStart;
        dt.testEndDate =
          item.projectedTestStart !== null
            ? item.projectedTestComplete === item.projectedTestStart
              ? new Date(
                moment(
                  new Date(
                    item.projectedTestStart
                  ).setHours(24)
                ).format("yyyy-MM-DDTHH:mm:ss")
              )
              : item.projectedTestComplete
            : null;

        dt.postTestStartDate =
          item.projectedTestComplete !== null
            ? new Date(
              moment(
                new Date(item.projectedTestComplete).setHours(
                  24
                )
              ).format("yyyy-MM-DDTHH:mm:ss")
            )
            : item.projectedManufacturingComplete;
        dt.postTestEndDate =
          new Date(dt.postTestStartDate).getTime() ===
            new Date(item.projectedManufacturingComplete).getTime()
            ? new Date(
              moment(
                new Date(
                  item.projectedManufacturingComplete
                ).setHours(24)
              ).format("yyyy-MM-DDTHH:mm:ss")
            )
            : item.projectedManufacturingComplete;

        dt.actualSubAssemblyStartDate = item.actualLaunch;
        const actualSubAssyEndDate = new Date(
          item.actualIntegrationStart
        );
        actualSubAssyEndDate?.setDate(
          actualSubAssyEndDate?.getDate() - 1
        );
        dt.actualSubAssemblyEndDate =
          actualSubAssyEndDate !== null &&
            actualSubAssyEndDate !== undefined
            ? actualSubAssyEndDate
            : new Date(
              moment(
                new Date(item.actualLaunch)?.setHours(24)
              ).format("yyyy-MM-DDTHH:mm:ss")
            );

        dt.actualIntegrationStartDate =
          item.actualIntegrationStart !== null
            ? item.actualIntegrationStart
            : new Date(
              moment(
                new Date(item.actualLaunch)?.setHours(24)
              ).format("yyyy-MM-DDTHH:mm:ss")
            );
        const actualIntEndDate = new Date(item.actualTestStart);
        actualIntEndDate?.setDate(actualIntEndDate?.getDate() - 1);
        dt.actualIntegrationEndDate =
          actualIntEndDate !== null && actualIntEndDate !== undefined
            ? actualIntEndDate
            : new Date(
              moment(
                new Date(
                  item.actualIntegrationStart
                )?.setHours(24)
              ).format("yyyy-MM-DDTHH:mm:ss")
            );

        dt.actualTestStartDate =
          item.actualTestStart !== null
            ? item.actualTestStart
            : new Date(
              moment(
                new Date(
                  item.actualIntegrationStart
                )?.setHours(24)
              ).format("yyyy-MM-DDTHH:mm:ss")
            );
        dt.actualTestEndDate =
          item.actualTestComplete !== null
            ? item.actualTestComplete
            : new Date(
              moment(
                new Date(item.actualTestStart)?.setHours(24)
              ).format("yyyy-MM-DDTHH:mm:ss")
            );

        dt.actualPostTestStartDate =
          item.actualTestComplete !== null
            ? new Date(
              moment(
                new Date(item.actualTestComplete)?.setHours(
                  24
                )
              ).format("yyyy-MM-DDTHH:mm:ss")
            )
            : new Date(
              moment(
                new Date(item.actualTestStart)?.setHours(24)
              ).format("yyyy-MM-DDTHH:mm:ss")
            );
        dt.actualPostTestEndDate =
          item.actualManufacturingComplete !== null
            ? item.actualManufacturingComplete
            : new Date(
              moment(
                new Date(item.actualTestComplete)?.setHours(
                  24
                )
              ).format("yyyy-MM-DDTHH:mm:ss")
            );

        dt.EarliestStartDateFromDate = item.earliestStartDate;
        dt.EarliestStartDateToDate = moment(
          new Date(item.earliestStartDate)?.setHours(24)
        ).format("yyyy-MM-DDTHH:mm:ss");
        dt.RecordType = item.recordType;
        dt.RevenueCode = item.revenueCode;
        dt.FCID = item.fcid;
        dt.ToolTypeName = item.toolTypeName;
        dt.ProductGroupName = item.productGroupName;
        dt.MCSDFromDate = item.manufacturingCommitedShipDate;
        dt.MCSDToDate = moment(
          new Date(item.manufacturingCommitedShipDate).setHours(24)
        ).format("yyyy-MM-DDTHH:mm:ss");
        dt.TSDFromDate = item.targetShipDate;
        dt.TSDToDate = moment(
          new Date(item.targetShipDate)?.setHours(24)
        ).format("yyyy-MM-DDTHH:mm:ss");
        dt.CRDFromDate = item.customerRequestDate;
        dt.CRDToDate = moment(
          new Date(item.customerRequestDate)?.setHours(24)
        ).format("yyyy-MM-DDTHH:mm:ss");
        dt.SRDFromDate = item.salesOpsRequestDate;
        dt.SRDToDate = moment(
          new Date(item.salesOpsRequestDate)?.setHours(24)
        ).format("yyyy-MM-DDTHH:mm:ss");
        dt.planofRecordFromDate = item.planofRecord;
        dt.planofRecordToDate = moment(
          new Date(item.planofRecord)?.setHours(24)
        ).format("yyyy-MM-DDTHH:mm:ss");
        dt.BuildType = item.buildTypeName; //User Story 37057: Add Build Type to Gantt Charts
        dt.colorBar1 = am4core.color("#03fccf");
        dt.colorBar2 = am4core.color("#03fcf4");
        dt.colorBar3 = am4core.color("#03d7fc");
        dt.colorBar4 = am4core.color("#088bd1");
        dt.colorBar5 = am4core.color("#f06656");
        dt.colorBar6 = am4core.color("#fcf342");
        dt.colorBar7 = am4core.color("#6277fc");
        dt.colorBar8 = am4core.color("#217502");
        dt.colorBar9 = am4core.color("#b169c7");
        dt.colorBar10 = am4core.color("#f048ed");
        dt.colorBar11 = am4core.color("#999ff2");
        dt.colorBar12 = am4core.color("#7ae67a");
        dt.colorBar13 = am4core.color("#f28966");
        dt.colorBar14 = am4core.color("#000000");
        dt.colorBar15 = am4core.color("#ffffff");
        dt.colorBar16 = am4core.color("#a19d33");
        dt.strokeColor = this.getStrokeColor(item.buildTypeName);
        this.plantSpeceficChartData.push(dt);
      });
    }
    this.browserOnly(() => {
      am4core.useTheme(am4themes_animated);

      const chart = am4core.create("chartdiv", am4charts.XYChart);
      chart.hiddenState.properties.opacity = 0; // this creates initial fade-in

      chart.paddingRight = 30;
      chart.dateFormatter.inputDateFormat = "yyyy-MM-dd";

      chart.data = this.plantSpeceficChartData;

      const categoryAxis = chart.yAxes.push(new am4charts.CategoryAxis());
      categoryAxis.dataFields.category = "moduleAndToolType";
      categoryAxis.renderer.grid.template.location = 0;
      categoryAxis.renderer.inversed = true;
      categoryAxis.fontSize = 8;
      categoryAxis.fontWeight = "bold";
      categoryAxis.contentHeight = 10;
      categoryAxis.renderer.minGridDistance = 10;

      const cellSize = 15;
      chart.events.on("datavalidated", function (ev) {
        // Get objects of interest
        const chart = ev.target;
        const categoryAxis = chart.yAxes.getIndex(0);
        // Calculate how we need to adjust chart height
        const adjustHeight =
          chart.data.length * cellSize - categoryAxis.pixelHeight;
        // get current chart height
        const targetHeight = chart.pixelHeight + adjustHeight;
        // Set it on chart's container
        chart.svgContainer.htmlElement.style.height =
          targetHeight + "px";
      });

      const dateAxis = chart.xAxes.push(new am4charts.DateAxis());
      dateAxis.dateFormatter.dateFormat = "MM-dd-yyyy";
      dateAxis.renderer.minGridDistance = 70;
      dateAxis.baseInterval = { count: 30, timeUnit: "minute" };
      dateAxis.max = this.chartMaxDate.getTime();
      dateAxis.min = this.chartMinDate.getTime();
      dateAxis.strictMinMax = false;
      dateAxis.renderer.tooltipLocation = 1;

      const series1 = chart.series.push(new am4charts.ColumnSeries());
      series1.columns.template.width = am4core.percent(80);
      series1.columns.template.tooltipText =
        (this.inWIP ? "Planned Subassembly" : "Projected Subassembly") +
        "\n {openDateX} - {dateX} \n Record Type: {RecordType} \n Revenue Code: {RevenueCode} \n FCID: {FCID} \n Product Type: {ProductGroupName} \n Tool Type: {ToolTypeName} \n Build Type: {BuildType}";
      series1.dataFields.openDateX = "subAssemblyStartDate";
      series1.dataFields.dateX = "subAssemblyEndDate";
      series1.dataFields.categoryY = "moduleAndToolType";
      series1.columns.template.propertyFields.fill = "colorBar1"; // get color from data
      series1.columns.template.propertyFields.stroke = "strokeColor";
      series1.columns.template.strokeOpacity = 1;
      series1.columns.template.fillOpacity = 1;
      series1.clustered = false;

      const series2 = chart.series.push(new am4charts.ColumnSeries());
      series2.columns.template.width = am4core.percent(80);
      series2.columns.template.tooltipText =
        (this.inWIP ? "Planned Integration" : "Projected Integration") +
        "\n {openDateX} - {dateX} \n Record Type: {RecordType} \n Revenue Code: {RevenueCode} \n FCID: {FCID} \n Product Type: {ProductGroupName} \n Tool Type: {ToolTypeName} \n Build Type: {BuildType}";
      series2.dataFields.openDateX = "integrationStartDate";
      series2.dataFields.dateX = "integrationEndDate";
      series2.dataFields.categoryY = "moduleAndToolType";
      series2.columns.template.propertyFields.fill = "colorBar2"; // get color from data
      series2.columns.template.propertyFields.stroke = "strokeColor";
      series2.columns.template.strokeOpacity = 1;
      series2.columns.template.fillOpacity = 1;
      series2.clustered = false;

      const series3 = chart.series.push(new am4charts.ColumnSeries());
      series3.columns.template.width = am4core.percent(80);
      series3.columns.template.tooltipText =
        (this.inWIP ? "Planned In Test" : "Projected In Test") +
        "\n {openDateX} - {dateX} \n Record Type: {RecordType} \n Revenue Code: {RevenueCode} \n FCID: {FCID} \n Product Type: {ProductGroupName} \n Tool Type: {ToolTypeName} \n Build Type: {BuildType}";
      series3.dataFields.openDateX = "testStartDate";
      series3.dataFields.dateX = "testEndDate";
      series3.dataFields.categoryY = "moduleAndToolType";
      series3.columns.template.propertyFields.fill = "colorBar3"; // get color from data
      series3.columns.template.propertyFields.stroke = "strokeColor";
      series3.columns.template.strokeOpacity = 1;
      series3.columns.template.fillOpacity = 1;
      series3.clustered = false;

      const series4 = chart.series.push(new am4charts.ColumnSeries());
      series4.columns.template.width = am4core.percent(80);
      series4.columns.template.tooltipText =
        (this.inWIP ? "Planned Post Test" : "Projected Post Test") +
        "\n {openDateX} - {dateX} \n Record Type: {RecordType} \n Revenue Code: {RevenueCode} \n FCID: {FCID} \n Product Type: {ProductGroupName} \n Tool Type: {ToolTypeName} \n Build Type: {BuildType}";
      series4.dataFields.openDateX = "postTestStartDate";
      series4.dataFields.dateX = "postTestEndDate";
      series4.dataFields.categoryY = "moduleAndToolType";
      series4.columns.template.propertyFields.fill = "colorBar4"; // get color from data
      series4.columns.template.propertyFields.stroke = "strokeColor";
      series4.columns.template.strokeOpacity = 1;
      series4.columns.template.fillOpacity = 1;
      series4.clustered = false;

      const series5 = chart.series.push(new am4charts.ColumnSeries());
      series5.columns.template.width = am4core.percent(80);
      series5.columns.template.tooltipText =
        "Actual Post Test \n {openDateX} - {dateX} \n Record Type: {RecordType} \n Revenue Code: {RevenueCode} \n FCID: {FCID} \n Product Type: {ProductGroupName} \n Tool Type: {ToolTypeName} \n Build Type: {BuildType}";
      series5.dataFields.openDateX = "actualPostTestStartDate";
      series5.dataFields.dateX = "actualPostTestEndDate";
      series5.dataFields.categoryY = "moduleAndToolType";
      series5.columns.template.propertyFields.fill = "colorBar13"; // get color from data
      series5.columns.template.propertyFields.stroke = "strokeColor";
      series5.columns.template.strokeOpacity = 0;
      series5.columns.template.fillOpacity = 0.5;
      series5.tooltip.getFillFromObject = false;
      series5.tooltip.label.propertyFields.fill = "colorBar14";
      series5.tooltip.background.propertyFields.stroke = "colorBar15";
      series5.tooltip.background.fill = am4core.color("#f28966");
      series5.columns.template.adapter.add(
        "fill",
        function (fill, target) {
          const pattern = new am4core.LinePattern();
          pattern.width = 10;
          pattern.height = 10;
          pattern.strokeWidth = 1;
          pattern.stroke = am4core.color("#f28966");
          pattern.rotation = 45;
          return pattern;
        }
      );
      series5.columns.template.background.adapter.add(
        "fill",
        function (fill, target) {
          return target.dataItem ? am4core.color("#f28966") : fill;
        }
      );
      series5.clustered = true;

      const series6 = chart.series.push(new am4charts.ColumnSeries());
      series6.columns.template.width = am4core.percent(80);
      series6.columns.template.tooltipText =
        "Actual In Test \n {openDateX} - {dateX} \n Record Type: {RecordType} \n Revenue Code: {RevenueCode} \n FCID: {FCID} \n Product Type: {ProductGroupName} \n Tool Type: {ToolTypeName} \n Build Type: {BuildType}";
      series6.dataFields.openDateX = "actualTestStartDate";
      series6.dataFields.dateX = "actualTestEndDate";
      series6.dataFields.categoryY = "moduleAndToolType";
      series6.columns.template.propertyFields.fill = "colorBar12"; // get color from data
      series6.columns.template.propertyFields.stroke = "strokeColor";
      series6.columns.template.strokeOpacity = 0;
      series6.columns.template.fillOpacity = 0.5;
      series6.tooltip.getFillFromObject = false;
      series6.tooltip.label.propertyFields.fill = "colorBar14";
      series6.tooltip.background.propertyFields.stroke = "colorBar15";
      series6.tooltip.background.fill = am4core.color("#7ae67a");
      series6.columns.template.adapter.add(
        "fill",
        function (fill, target) {
          const pattern = new am4core.LinePattern();
          pattern.width = 10;
          pattern.height = 10;
          pattern.strokeWidth = 1;
          pattern.stroke = am4core.color("#7ae67a");
          pattern.rotation = 45;
          return pattern;
        }
      );
      series6.columns.template.background.adapter.add(
        "fill",
        function (fill, target) {
          return target.dataItem ? am4core.color("#7ae67a") : fill;
        }
      );
      series6.clustered = true;

      const series7 = chart.series.push(new am4charts.ColumnSeries());
      series7.columns.template.width = am4core.percent(80);
      series7.columns.template.tooltipText =
        "Actual Integration \n {openDateX} - {dateX} \n Record Type: {RecordType} \n Revenue Code: {RevenueCode} \n FCID: {FCID} \n Product Type: {ProductGroupName} \n Tool Type: {ToolTypeName} \n Build Type: {BuildType}";
      series7.dataFields.openDateX = "actualIntegrationStartDate";
      series7.dataFields.dateX = "actualIntegrationEndDate";
      series7.dataFields.categoryY = "moduleAndToolType";
      series7.columns.template.propertyFields.fill = "colorBar11"; // get color from data
      series7.columns.template.propertyFields.stroke = "strokeColor";
      series7.columns.template.strokeOpacity = 0;
      series7.columns.template.fillOpacity = 0.5;
      series7.tooltip.getFillFromObject = false;
      series7.tooltip.label.propertyFields.fill = "colorBar14";
      series7.tooltip.background.propertyFields.stroke = "colorBar15";
      series7.tooltip.background.fill = am4core.color("#999ff2");
      series7.columns.template.adapter.add(
        "fill",
        function (fill, target) {
          const pattern = new am4core.LinePattern();
          pattern.width = 10;
          pattern.height = 10;
          pattern.strokeWidth = 1;
          pattern.stroke = am4core.color("#999ff2");
          pattern.rotation = 45;
          return pattern;
        }
      );
      series7.columns.template.background.adapter.add(
        "fill",
        function (fill, target) {
          return target.dataItem ? am4core.color("#999ff2") : fill;
        }
      );
      series7.clustered = true;

      const series8 = chart.series.push(new am4charts.ColumnSeries());
      series8.columns.template.width = am4core.percent(80);
      series8.columns.template.tooltipText =
        "Actual Subassembly \n {openDateX} - {dateX} \n Record Type: {RecordType} \n Revenue Code: {RevenueCode} \n FCID: {FCID} \n Product Type: {ProductGroupName} \n Tool Type: {ToolTypeName} \n Build Type: {BuildType}";
      series8.dataFields.openDateX = "actualSubAssemblyStartDate";
      series8.dataFields.dateX = "actualSubAssemblyStartDate";
      series8.dataFields.categoryY = "moduleAndToolType";
      series8.columns.template.propertyFields.fill = "colorBar10"; // get color from data
      series8.columns.template.propertyFields.stroke = "strokeColor";
      series8.columns.template.strokeOpacity = 0;
      series8.columns.template.fillOpacity = 0.5;
      series8.tooltip.getFillFromObject = false;
      series8.tooltip.label.propertyFields.fill = "colorBar14";
      series8.tooltip.background.propertyFields.stroke = "colorBar15";
      series8.tooltip.background.fill = am4core.color("#f048ed");
      series8.columns.template.adapter.add(
        "fill",
        function (fill, target) {
          const pattern = new am4core.LinePattern();
          pattern.width = 10;
          pattern.height = 10;
          pattern.strokeWidth = 1;
          pattern.stroke = am4core.color("#f048ed");
          pattern.rotation = 45;
          return pattern;
        }
      );
      series8.columns.template.background.adapter.add(
        "fill",
        function (fill, target) {
          return target.dataItem ? am4core.color("#f048ed") : fill;
        }
      );
      series8.clustered = true;

      const series9 = chart.series.push(new am4charts.ColumnSeries());
      series9.columns.template.width = am4core.percent(80);
      series9.columns.template.tooltipText =
        "Earliest Start Date: {openDateX} \n Record Type: {RecordType} \n Revenue Code: {RevenueCode} \n FCID: {FCID} \n Product Type: {ProductGroupName} \n Tool Type: {ToolTypeName} \n Build Type: {BuildType}";
      series9.dataFields.openDateX = "EarliestStartDateFromDate";
      series9.dataFields.dateX = "EarliestStartDateToDate";
      series9.dataFields.categoryY = "moduleAndToolType";
      series9.columns.template.propertyFields.fill = "colorBar5"; // get color from data
      series9.columns.template.propertyFields.stroke = "strokeColor";
      series9.columns.template.strokeOpacity = 1;
      series9.columns.template.fillOpacity = 1;
      series9.clustered = true;

      const series10 = chart.series.push(new am4charts.ColumnSeries());
      series10.columns.template.width = am4core.percent(80);
      series10.columns.template.tooltipText =
        "MCSD: {openDateX} \n Record Type: {RecordType} \n Revenue Code: {RevenueCode} \n FCID: {FCID} \n Product Type: {ProductGroupName} \n Tool Type: {ToolTypeName} \n Build Type: {BuildType}";
      series10.dataFields.openDateX = "MCSDFromDate";
      series10.dataFields.dateX = "MCSDToDate";
      series10.dataFields.categoryY = "moduleAndToolType";
      series10.columns.template.propertyFields.fill = "colorBar6"; // get color from data
      series10.columns.template.propertyFields.stroke = "strokeColor";
      series10.columns.template.strokeOpacity = 1;
      series10.columns.template.fillOpacity = 1;
      series10.clustered = true;

      const series11 = chart.series.push(new am4charts.ColumnSeries());
      series11.columns.template.width = am4core.percent(80);
      series11.columns.template.tooltipText =
        "TSD: {openDateX} \n Record Type: {RecordType} \n Revenue Code: {RevenueCode} \n FCID: {FCID} \n Product Type: {ProductGroupName} \n Tool Type: {ToolTypeName} \n Build Type: {BuildType}";
      series11.dataFields.openDateX = "TSDFromDate";
      series11.dataFields.dateX = "TSDToDate";
      series11.dataFields.categoryY = "moduleAndToolType";
      series11.columns.template.propertyFields.fill = "colorBar7"; // get color from data
      series11.columns.template.propertyFields.stroke = "strokeColor";
      series11.columns.template.strokeOpacity = 1;
      series11.columns.template.fillOpacity = 1;
      series11.clustered = true;

      const series12 = chart.series.push(new am4charts.ColumnSeries());
      series12.columns.template.width = am4core.percent(80);
      series12.columns.template.tooltipText =
        "CRD: {openDateX} \n Record Type: {RecordType} \n Revenue Code: {RevenueCode} \n FCID: {FCID} \n Product Type: {ProductGroupName} \n Tool Type: {ToolTypeName} \n Build Type: {BuildType}";
      series12.dataFields.openDateX = "CRDFromDate";
      series12.dataFields.dateX = "CRDToDate";
      series12.dataFields.categoryY = "moduleAndToolType";
      series12.columns.template.propertyFields.fill = "colorBar8"; // get color from data
      series12.columns.template.propertyFields.stroke = "strokeColor";
      series12.columns.template.strokeOpacity = 1;
      series12.columns.template.fillOpacity = 1;
      series12.clustered = true;

      const series13 = chart.series.push(new am4charts.ColumnSeries());
      series13.columns.template.width = am4core.percent(80);
      series13.columns.template.tooltipText =
        "SRD: {openDateX} \n Record Type: {RecordType} \n Revenue Code: {RevenueCode} \n FCID: {FCID} \n Product Type: {ProductGroupName} \n Tool Type: {ToolTypeName} \n Build Type: {BuildType}";
      series13.dataFields.openDateX = "SRDFromDate";
      series13.dataFields.dateX = "SRDToDate";
      series13.dataFields.categoryY = "moduleAndToolType";
      series13.columns.template.propertyFields.fill = "colorBar9"; // get color from data
      series13.columns.template.propertyFields.stroke = "strokeColor";
      series13.columns.template.strokeOpacity = 1;
      series13.columns.template.fillOpacity = 1;
      series13.clustered = true;

      const series14 = chart.series.push(new am4charts.ColumnSeries());
      series14.columns.template.width = am4core.percent(80);
      series14.columns.template.tooltipText =
        "POR: {openDateX} \n Record Type: {RecordType} \n Revenue Code: {RevenueCode} \n FCID: {FCID} \n Product Type: {ProductGroupName} \n Tool Type: {ToolTypeName} \n Build Type: {BuildType}";
      series14.dataFields.openDateX = "planofRecordFromDate";
      series14.dataFields.dateX = "planofRecordToDate";
      series14.dataFields.categoryY = "moduleAndToolType";
      series14.columns.template.propertyFields.fill = "colorBar16"; // get color from data
      series14.columns.template.propertyFields.stroke = "strokeColor";
      series14.columns.template.strokeOpacity = 1;
      series14.columns.template.fillOpacity = 1;
      series14.clustered = true;

      chart.scrollbarX = new am4core.Scrollbar();
      if (!this.inWIP) {
        const startFullQuarter = this.startFullQuarter;
        const endFullQuarter = this.endFullQuarter;
        chart.events.on("ready", function () {
          dateAxis.zoomToDates(startFullQuarter, endFullQuarter);
        });
      }

      document
        .querySelector(".k-grid .k-grid-content")
        .addEventListener("scroll", (e) => {
          if (!this.inWIP) {
            if (this.scrolledLeft) {
              if (this.startFullQuarter >= this.chartMinDate)
                this.startFullQuarter.setHours(-240);
              if (this.endFullQuarter <= this.chartMaxDate)
                this.endFullQuarter.setHours(-240);
            } else {
              if (this.startFullQuarter >= this.chartMinDate)
                this.startFullQuarter.setHours(120);
              if (this.endFullQuarter <= this.chartMaxDate)
                this.endFullQuarter.setHours(120);
            }
            if (
              this.startFullQuarter >= this.chartMinDate &&
              this.endFullQuarter <= this.chartMaxDate
            ) {
              dateAxis.zoomToDates(
                this.startFullQuarter,
                this.endFullQuarter
              );
            }
          }
        });

      this.chart = chart;
    });
  }

  public getStrokeColor(buildType: string) {
    let color: any;
    switch (buildType) {
      case "BQ (Build Qualify)":
        color = am4core.color("#000000");
        break;
      case "BV (Build Verify)":
      case "CB (Control Build)":
        color = am4core.color("#FFFF00");
        break;
      case "1H (First HVM)":
      case "H (HVM)":
        color = am4core.color("#FF5412");
        break;
      case "Alpha (A)":
        color = am4core.color("#9165a7");
        break;
      case "FLT (Float)":
        color = am4core.color("#65a765");
        break;
      default:
        color = am4core.color("#FFFFFF00");
        break;
    }
    return color;
  }

  onFilterChange() {
    const filter: CompositeFilterDescriptor = { filters: [], logic: "and" };
    if (this.toolTypeValue && this.toolTypeValue.length > 0) {
      const data1: any[] = [];
      this.toolTypeValue.forEach((item) => {
        data1.push({
          field: "toolTypeName",
          operator: "contains",
          value: item,
        });
      });
      filter.filters.push({ filters: [...data1], logic: "or" });
    }
    if (this.productTypeValue && this.productTypeValue.length > 0) {
      const data2: any[] = [];
      this.productTypeValue.forEach((item) => {
        data2.push({
          field: "productGroupName",
          operator: "contains",
          value: item,
        });
      });
      filter.filters.push({ filters: [...data2], logic: "or" });
    }
    if (this.buildTypeValue && this.buildTypeValue.length > 0) {
      const data3: any[] = [];
      this.buildTypeValue.forEach((item) => {
        data3.push({
          field: "buildTypeName",
          operator: "contains",
          value: item,
        });
      });
      filter.filters.push({ filters: [...data3], logic: "or" });
    }
    if (this.revenueTypeValue && this.revenueTypeValue.length > 0) {
      const data4: any[] = [];
      this.revenueTypeValue.forEach((item) => {
        data4.push({
          field: "revenueCode",
          operator: "contains",
          value: item,
        });
      });
      filter.filters.push({ filters: [...data4], logic: "or" });
    }
    if (this.recordTypeValue && this.recordTypeValue.length > 0) {
      const data3: any[] = [];
      this.recordTypeValue.forEach((item) => {
        data3.push({
          field: "recordType",
          operator: "contains",
          value: item,
        });
      });
      filter.filters.push({ filters: [...data3], logic: "or" });
    }
    this.filter = filter;
    this.chartData = filterBy(this.tempChartData, filter);

    this.buildChart(this.chartData);
  }
  handleToolTypeFilter(value) {
    if (value.length >= 0) {
      this.toolTypeItems = JSON.parse(
        JSON.stringify(
          this.tempToolTypeItems.filter(
            (s) =>
              s?.toLowerCase().indexOf(value?.toLowerCase()) !==
              -1
          )
        )
      );
    } else {
      this.multiselect.toggle(false);
    }
  }

  handleProductTypeFilter(value) {
    if (value.length >= 0) {
      this.productTypeItems = this.tempProductTypeItems.filter(
        (s) => s?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
      );
    } else {
      this.multiselect.toggle(false);
    }
  }

  handleBuildTypeFilter(value) {
    if (value.length >= 0) {
      this.buildTypeItems = JSON.parse(
        JSON.stringify(
          this.tempBuildTypeItems.filter(
            (s) =>
              s?.toLowerCase().indexOf(value?.toLowerCase()) !==
              -1
          )
        )
      );
    } else {
      this.multiselect.toggle(false);
    }
  }

  onChangeFromDateDaily(value: Date) {
    if (value === null || value === undefined)
      this.chartMinDate = this.minFromDate;
    else if (
      value.getTime() < this.minFromDate.getTime() ||
      value.getTime() > this.maxFromDate.getTime() ||
      value.getTime() > this.chartMaxDate.getTime()
    )
      this.chartMinDate = this.minFromDate;
    else this.chartMinDate = value;

    this.minToDate = this.chartMinDate;
    this.getLaborDefaultData();
    this.getModuleDefaultData();
    this.GetGanttChartSumOfSchedulebay();
    this.buildChart(this.chartData);
  }
  onChangeToDateDaily(value: Date) {
    if (value === null || value === undefined)
      this.chartMaxDate = this.maxToDate;
    else if (
      value.getTime() < this.minToDate.getTime() ||
      value.getTime() > this.maxToDate.getTime() ||
      value.getTime() < this.chartMinDate.getTime()
    )
      this.chartMaxDate = this.maxToDate;
    else this.chartMaxDate = value;

    this.maxFromDate = this.chartMaxDate;
    this.getLaborDefaultData();
    this.getModuleDefaultData();
    this.GetGanttChartSumOfSchedulebay();
    this.buildChart(this.chartData);
  }

  //User Story 37063: Scheduled Module - Add or remove days from a module process which is already scheduled, without rescheduling it
  openShiftLaunch() {
    if (this.site?.plantName === "Fremont") {
      this.benOrPsn = [];
      this.tempBenOrPsn = [];
      this.chartData.forEach((item) => {
        this.benOrPsn.push({
          text: item.pilotSerialNumber,
          value: item.pilotProductID,
        });
      });
      this.tempBenOrPsn = [...this.benOrPsn];
    } else {
      this.benOrPsn = [];
      this.tempBenOrPsn = [];
      this.chartData.forEach((item) => {
        this.benOrPsn.push({
          text: item.ben,
          value: item.pilotProductID,
        });
      });
      this.tempBenOrPsn = [...this.benOrPsn];
    }
    this.moduleToBeUpdate = this.chartData[0];
    this.benOrPsnData = this.benOrPsn[0];
    this.openShiftLaunchPopup = true;
    this.changeDetector.detectChanges();
  }
  UpdateShiftSechecdule() {
    this.openShiftLaunchPopup = false;
    const request = new AdjustScheduleViewModule();
    request.userID = this.userDetail?.userId;
    request.plantID = this.site?.plantId;
    request.plantName = this.site?.plantName;
    request.pilotProductID = this.benOrPsnData?.value;
    request.productionPlanID = +this.productionPlanID;
    request.planType = this.planName;
    request.moduleProcess = "";
    request.earliestStartDate =
      this.chartData.filter(
        (item) => item.pilotProductID === this.benOrPsnData?.value
      )[0]?.earliestStartDate !== null
        ? moment(
          new Date(
            this.chartData.filter(
              (item) =>
                item.pilotProductID ===
                this.benOrPsnData?.value
            )[0]?.earliestStartDate
          )
        ).format("yyyy-MM-DD")
        : moment(new Date()).add(1, "days").format("yyyy-MM-DD");
    request.dayShiftOnly = this.chartData.filter(
      (item) => item.pilotProductID === this.benOrPsnData?.value
    )[0]?.dayShiftOnly;
    request.noOfDays = this.noOfDays;
    this.isLoading = true;
    this.loadSum = true;
    this.loadBays = true;
    this.loadLabor = true;
    this.gridDataForLaborRemaining = [];
    this.LaborProductName = [];
    this.laborWeekColumns = [];
    this.gridDataForBaysRemaining = [];
    this.BaysProductName = [];
    this.scheduleSum = [];
    this.scheduleSumColumn = [];
    this.productNameSum = [];
    this.mpsService.UpdateGeneratedSchedule(request).subscribe((res) => {
      if (res) {
        this.closeShiftPopup();
        this.scheduleStatusMessage = res.value;
        this.openScheduleGeneratedPopUp = true;
        this.getGanttChartData();
        this.getLaborDefaultData();
        this.getModuleDefaultData();
        this.GetGanttChartSumOfSchedulebay();
      }
    });
  }
  openTimeLaunch() {
    if (this.site?.plantName === "Fremont") {
      this.benOrPsn = [];
      this.tempBenOrPsn = [];
      this.chartData.forEach((item) => {
        this.benOrPsn.push({
          text: item.pilotSerialNumber,
          value: item.pilotProductID,
        });
      });
      this.tempBenOrPsn = [...this.benOrPsn];
    } else {
      this.benOrPsn = [];
      this.tempBenOrPsn = [];
      this.chartData.forEach((item) => {
        this.benOrPsn.push({
          text: item.ben,
          value: item.pilotProductID,
        });
      });
      this.tempBenOrPsn = [...this.benOrPsn];
    }
    this.moduleToBeUpdate = this.chartData[0];
    this.benOrPsnData = this.benOrPsn[0];
    this.openTimePopup = true;
    this.moduleProcessData = [];
    this.mpsService
      .GetModuleProcess(this.benOrPsnData?.value, +this.productionPlanID)
      .subscribe((res) => {
        if (res && res.length > 0) {
          res.forEach((item) => {
            this.moduleProcessData.push({
              text: item.moduleProcess,
              value: item.moduleProcessID,
            });
          });

          if (this.moduleToBeUpdate.subAssemblyHours === 0 || this.moduleToBeUpdate.subAssemblyHours === null || this.moduleToBeUpdate.subAssemblyHours === undefined) {
            this.moduleProcessData = [...this.moduleProcessData.filter(item => item.text !== 'Subassembly')];
          }
          if (this.moduleToBeUpdate.integrationHours === 0 || this.moduleToBeUpdate.integrationHours === null || this.moduleToBeUpdate.integrationHours === undefined) {
            this.moduleProcessData = [...this.moduleProcessData.filter(item => item.text !== 'Integration')];
          }
          if (this.moduleToBeUpdate.testHours === 0 || this.moduleToBeUpdate.testHours === null || this.moduleToBeUpdate.testHours === undefined) {
            this.moduleProcessData = [...this.moduleProcessData.filter(item => item.text !== 'Test')];
          }
          if (this.moduleToBeUpdate.posttestHours === 0 || this.moduleToBeUpdate.posttestHours === null || this.moduleToBeUpdate.posttestHours === undefined) {
            this.moduleProcessData = [...this.moduleProcessData.filter(item => item.text !== 'Post-test')];
          }

          this.moduleProcess = this.moduleProcessData[0];
          this.changeDetector.detectChanges();
        }
      });
  }
  UpdateTimeSechecdule() {
    this.noOfDaysError = false;
    this.mpsService
      .GetCheckLeadTimeDays(
        this.moduleProcess?.text,
        this.noOfDays,
        this.benOrPsnData?.value,
        this.productionPlanID
      )
      .subscribe((res) => {
        if (res && res?.value === 1) {
          this.openTimePopup = false;
          this.noOfDaysError = false;
          const request = new AdjustScheduleViewModule();
          request.userID = this.userDetail?.userId;
          request.plantID = this.site?.plantId;
          request.plantName = this.site?.plantName;
          request.pilotProductID = this.benOrPsnData?.value;
          request.productionPlanID = +this.productionPlanID;
          request.planType = "What If";
          request.earliestStartDate =
            this.chartData.filter(
              (item) =>
                item.pilotProductID === this.benOrPsnData?.value
            )[0]?.earliestStartDate !== null
              ? moment(
                new Date(
                  this.chartData.filter(
                    (item) =>
                      item.pilotProductID ===
                      this.benOrPsnData?.value
                  )[0]?.earliestStartDate
                )
              ).format("yyyy-MM-DD")
              : moment(new Date())
                .add(1, "days")
                .format("yyyy-MM-DD");
          request.dayShiftOnly = this.chartData.filter(
            (item) =>
              item.pilotProductID === this.benOrPsnData?.value
          )[0]?.dayShiftOnly;
          request.moduleProcess = this.moduleProcess?.text;
          request.noOfDays = this.noOfDays;
          this.isLoading = true;
          this.loadSum = true;
          this.loadBays = true;
          this.loadLabor = true;
          this.gridDataForLaborRemaining = [];
          this.LaborProductName = [];
          this.laborWeekColumns = [];
          this.gridDataForBaysRemaining = [];
          this.BaysProductName = [];
          this.scheduleSum = [];
          this.scheduleSumColumn = [];
          this.productNameSum = [];
          this.mpsService
            .UpdateGeneratedSchedule(request)
            .subscribe((res) => {
              if (res) {
                this.closeTimePopup();
                this.scheduleStatusMessage = res.value;
                this.openScheduleGeneratedPopUp = true;
                this.getGanttChartData();
                this.getLaborDefaultData();
                this.getModuleDefaultData();
                this.GetGanttChartSumOfSchedulebay();
              }
            });
        } else {
          this.noOfDaysError = true;
        }
      });
  }
  onChangeNoOfDays() {
    this.noOfDaysError = false;
    this.enableSaveModuleProcess = true;
    if (
      this.noOfDays === undefined ||
      this.noOfDays === null ||
      this.noOfDays === 0
    ) {
      this.enableSaveModuleProcess = false;
    }
  }

  closeShiftPopup() {
    this.noOfDays = 0;
    this.openShiftLaunchPopup = false;
    this.enableSaveModuleProcess = false;
    this.noOfDaysError = false;
  }
  closeTimePopup() {
    this.noOfDays = 0;
    this.openTimePopup = false;
    this.enableSaveModuleProcess = false;
    this.noOfDaysError = false;
  }

  handleFilter(value) {
    this.benOrPsn = this.tempBenOrPsn.filter(
      (s) => s.text.toLowerCase().indexOf(value.toLowerCase()) !== -1
    );
  }

  onValueChangeTime(value) {
    this.noOfDays = 0;
    this.enableSaveModuleProcess = false;
    this.noOfDaysError = false;
    this.moduleToBeUpdate =
      this.site.plantName === "Fremont"
        ? this.chartData.filter(
          (item) =>
            item.pilotSerialNumber === this.benOrPsnData?.text
        )[0]
        : this.chartData.filter(
          (item) => item.ben === this.benOrPsnData?.value
        )[0];
    this.mpsService
      .GetModuleProcess(this.benOrPsnData?.value, +this.productionPlanID)
      .subscribe((res) => {
        this.moduleProcessData = [];
        if (res && res.length > 0) {
          res.forEach((item) => {
            this.moduleProcessData.push({
              text: item.moduleProcess,
              value: item.moduleProcessID,
            });
          });

          if (this.moduleToBeUpdate.subAssemblyHours === 0 || this.moduleToBeUpdate.subAssemblyHours === null || this.moduleToBeUpdate.subAssemblyHours === undefined) {
            this.moduleProcessData = [...this.moduleProcessData.filter(item => item.text !== 'Subassembly')];
          }
          if (this.moduleToBeUpdate.integrationHours === 0 || this.moduleToBeUpdate.integrationHours === null || this.moduleToBeUpdate.integrationHours === undefined) {
            this.moduleProcessData = [...this.moduleProcessData.filter(item => item.text !== 'Integration')];
          }
          if (this.moduleToBeUpdate.testHours === 0 || this.moduleToBeUpdate.testHours === null || this.moduleToBeUpdate.testHours === undefined) {
            this.moduleProcessData = [...this.moduleProcessData.filter(item => item.text !== 'Test')];
          }
          if (this.moduleToBeUpdate.posttestHours === 0 || this.moduleToBeUpdate.posttestHours === null || this.moduleToBeUpdate.posttestHours === undefined) {
            this.moduleProcessData = [...this.moduleProcessData.filter(item => item.text !== 'Post-test')];
          }

          this.moduleProcess = this.moduleProcessData[0];
          this.changeDetector.detectChanges();
        }
      });
  }

  onValueChangeShift(value) {
    this.noOfDays = 0;
    this.enableSaveModuleProcess = false;
    this.noOfDaysError = false;
    this.moduleToBeUpdate =
      this.site.plantName === "Fremont"
        ? this.chartData.filter(
          (item) =>
            item.pilotSerialNumber === this.benOrPsnData?.text
        )[0]
        : this.chartData.filter(
          (item) => item.ben === this.benOrPsnData?.value
        )[0];
  }

  onCloseChartChart() {
    this.closeChart.emit(true);
  }

  handleRevenueTypeFilter(value) {
    if (value.length >= 0) {
      this.revenueTypeItems = JSON.parse(
        JSON.stringify(
          this.tempRevenueTypeItems.filter(
            (s) =>
              s?.toLowerCase().indexOf(value?.toLowerCase()) !==
              -1
          )
        )
      );
    } else {
      this.multiselect.toggle(false);
    }
  }

  handleRecordTypeFilter(value) {
    if (value.length >= 0) {
      this.recordTypeItems = JSON.parse(
        JSON.stringify(
          this.tempRecordTypeItems.filter(
            (s) =>
              s?.toLowerCase().indexOf(value?.toLowerCase()) !==
              -1
          )
        )
      );
    } else {
      this.multiselect.toggle(false);
    }
  }

  public colorCode(
    TotalRemaining: number[],
    TotalAvailablity: number[],
    index: number,
    gridName: string
  ): SafeStyle {
    let result = "transparent";
    if (gridName === "labor") {
      if (
        TotalRemaining[index] <=
        (1 - this.laborUsageWarningRed / 100) * TotalAvailablity[index]
      ) {
        result = "#FFBA80";
      } else if (
        TotalRemaining[index] <=
        (1 - this.laborUsageWarningYellow / 100) *
        TotalAvailablity[index]
      ) {
        result = "#FFFACD";
      }
    } else if (gridName === "bay") {
      if (
        TotalRemaining[index] <=
        (1 - this.bayUsageWarningRed / 100) * TotalAvailablity[index]
      ) {
        result = "#FFBA80";
      } else if (
        TotalRemaining[index] <=
        (1 - this.bayUsageWarningYellow / 100) * TotalAvailablity[index]
      ) {
        result = "#FFFACD";
      }
    }
    return this.sanitizer.bypassSecurityTrustStyle(result);
  }

  public scrollEvent(e: ContentScrollEvent) {
    this.zone.runOutsideAngular(() => {
      this.grid1 = document.querySelector("#grid1 .k-grid-content");
      this.grid1.scrollLeft = e.scrollLeft;

      this.grid2 = document.querySelector("#grid2 .k-grid-content");
      if (this.grid2 !== null) {
        this.grid2.scrollLeft = e.scrollLeft;
      }

      this.grid3 = document.querySelector("#grid3 .k-grid-content");
      if (this.grid3 !== null) {
        this.grid3.scrollLeft = e.scrollLeft;
      }

      if (this.scrollPosition > e.scrollLeft) this.scrolledLeft = true;
      if (this.scrollPosition < e.scrollLeft) this.scrolledLeft = false;

      this.scrollPosition = e.scrollLeft;
    });
  }

  ngOnDestroy() {
    // Clean up chart when the component is removed
    this.browserOnly(() => {
      if (this.chart) {
        this.chart.dispose();
      }
    });
  }
}
