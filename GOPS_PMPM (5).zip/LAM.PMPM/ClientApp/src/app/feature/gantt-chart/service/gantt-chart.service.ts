import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment.dev_server';
import { GanttChartViewModel, SceduleSUmWeeklyData, ScheduledBay, ScheduledLabor, ScheduleSum, WeeklyDatesSum } from '../model/gantt-chart.model';
import { Labor, Module } from '../../other/Models/defaults.model';

@Injectable({
  providedIn: 'root'
})

export class GanttChartService {
  constructor(private http: HttpClient) { }
  readonly getGanttChartData = '/MPS/GetGanttChartData/';
  readonly getGanttChartScheduleBayLimitedFilter = '/EditSchedule/GetGanttChartScheduleBayLimitedFilter?PlantID=';
  readonly getGanttChartScheduleLaborLimitedFilter = '/EditSchedule/GetGanttChartScheduleLaborLimitedFilter?PlantID=';
  readonly getGanttChartSumSchedulebayLimitedFilter = '/EditSchedule/GetGanttChartSumSchedulebayLimitedFilter?PlantID=';
  readonly getGanttChartSumScheduleLaborLimitedFilter = '/EditSchedule/GetGanttChartSumScheduleLaborLimitedFilter?PlantID=';
  readonly getGanttChartLaunchDates = '/EditSchedule/GetGanttChartLaunchDates?StartDate=';
  readonly getLabourDefaultData = '/AdminSetDefaults/GetLabourDefaultData';
  readonly getModuleDefaultData = '/AdminSetDefaults/GetModuleDefaultData';

  GetGanttChartData(plantID: number, inWIP: boolean, productionPlanID: number): Observable<GanttChartViewModel[]> {
    return new Observable<GanttChartViewModel[]>(observer => {
      this.http
        .get<GanttChartViewModel[]>(`${environment.apiUrl}${this.getGanttChartData}` + plantID + '/' + inWIP + '/' + productionPlanID)
        .subscribe(res => {
          observer.next(res);
        });
    });
  }

  GetGanttChartScheduleBayLimitedFilter(plantID: number, startDate: string, endDate: string, productionPlanID: number): Observable<ScheduledBay[]> {
    return new Observable<ScheduledBay[]>(observer => {
      this.http
        .get<ScheduledBay[]>(`${environment.apiUrl}${this.getGanttChartScheduleBayLimitedFilter}` + plantID + '&StartDate=' + startDate + '&EndDate=' + endDate + '&productionPlanID=' + productionPlanID)
        .subscribe(res => {
          observer.next(res);
        });
    });
  }

  GetGanttChartScheduleLaborLimitedFilter(plantID: number, startDate: string, endDate: string, productionPlanID: number): Observable<ScheduledLabor[]> {
    return new Observable<ScheduledLabor[]>(observer => {
      this.http
        .get<ScheduledLabor[]>(`${environment.apiUrl}${this.getGanttChartScheduleLaborLimitedFilter}` + plantID + '&StartDate=' + startDate + '&EndDate=' + endDate + '&productionPlanID=' + productionPlanID)
        .subscribe(res => {
          observer.next(res);
        });
    });
  }
  GetGanttChartSumSchedulebayLimitedFilter(plantID: number, startDate: string, endDate: string, productionPlanID: number): Observable<SceduleSUmWeeklyData[]> {
    return new Observable<SceduleSUmWeeklyData[]>(observer => {
      this.http
        .get<SceduleSUmWeeklyData[]>(`${environment.apiUrl}${this.getGanttChartSumSchedulebayLimitedFilter}` + plantID + '&StartDate=' + startDate + '&EndDate=' + endDate + '&productionPlanID=' + productionPlanID)
        .subscribe(res => {
          observer.next(res);
        });
    });
  }
  GetGanttChartSumScheduleLaborLimitedFilter(plantID: number, startDate: string, endDate: string, productionPlanID: number): Observable<SceduleSUmWeeklyData[]> {
    return new Observable<SceduleSUmWeeklyData[]>(observer => {
      this.http
        .get<SceduleSUmWeeklyData[]>(`${environment.apiUrl}${this.getGanttChartSumScheduleLaborLimitedFilter}` + plantID + '&StartDate=' + startDate + '&EndDate=' + endDate + '&productionPlanID=' + productionPlanID)
        .subscribe(res => {
          observer.next(res);
        });
    });
  }

  GetGanttChartLaunchDates(startDate: string, endDate: string, productionPlanID: number): Observable<WeeklyDatesSum[]> {
    return new Observable<WeeklyDatesSum[]>(observer => {
      this.http
        .get<WeeklyDatesSum[]>(`${environment.apiUrl}${this.getGanttChartLaunchDates}`+ startDate + '&EndDate=' + endDate + '&productionPlanID=' + productionPlanID)
        .subscribe(res => {
          observer.next(res);
        });
    });
  }

  GetLabourDefaultData() {
    return this.http.get<Labor[]>(`${environment.apiUrl}${this.getLabourDefaultData}`);
  }

  GetModuleDefaultData() {
    return this.http.get<Module[]>(`${environment.apiUrl}${this.getModuleDefaultData}`);
  }
}
