export class GanttChartViewModel {
  public pilotProductID: number;
  public fcid: string;
  public pilotSerialNumber: string;
  public ben: string;
  public fremontID: number;
  public lprid: number;
  public productionStatus: string;
  public pilotToolType: string;
  public customer: string;
  public priorityDate: Date;
  public noCapacity: boolean;
  public recordType: string;
  public revenueCode: string;
  public buildTypeID: number;
  public buildTypeName: string;
  public toolTypeName: string;
  public productGroupName: string;
  public toolTypeID: number;
  public productGroupID: number;
  public building: number;
  public salesOrderNumber: string;
  public salesOrder: string;
  public bomNumber: number;
  public dayShiftOnly: boolean;
  public buildStyleId: number;
  public buildScheduleId: number;
  public pom: string;
  public crdEsc: boolean;
  public mcsdRiskLevel: string;
  public salesPriority: string; 
  public purchaseOrderNumber: string; 
  public pilotRisk: string; 
  public lPRPercComplete: string; 
  public inWIP: boolean;
  public plannedRiskLevel: string;
  public status: string; 
  public plantID: number;
  public projectedMRPP08: Date;
  public mrpP08: Date;
  public lprPlannedLaunchP09: Date;
  public projectedLaunch: Date;
  public commitLaunch: Date;
  public actualLaunch: Date;
  public projectedIntegrationStart: Date;
  public actualIntegrationStart: Date;
  public projectedTestStart: Date;
  public actualTestStart: Date;
  public projectedTestComplete: Date;
  public actualTestComplete: Date;
  public projectedManufacturingComplete: Date;
  public commitedManufacturingComplete: Date;
  public actualManufacturingComplete: Date;
  public manufacturingCommitedShipDate: Date;
  public projectedCrateComplete: Date;
  public actualCrateComplete: Date;
  public targetShipDate: Date;
  public salesOpsRequestDate: Date;
  public customerRequestDate: Date;
  public earliestStartDate: Date;
  public plannedDMRF: Date;
  public actualDMRF: Date;
  public idleTestDay: Date;
  public pilotManufacturingCommitedShipDate: Date;
  public planofRecord: Date;
  public plannedShipDate: Date;
  public actualShipDate: Date;
  public plannedManufacturingComplete: Date;
  public plannedTestStart: Date;
  public plannedCrateComplete: Date;
  public lPRPlannedPilotLaunchP47: Date;
  public committedTestComplete: Date;
  public committedTestStart: Date;
  public committedIntegrationStart: Date;
  public alreadyScheduled: boolean;
  public productionPlanID: number;
  public plannedTestComplete: Date;
  public plannedIntegrationStart: Date;
  public materialReadiness: Date;
  public subAssemblyHours: number;
  public integrationHours: number;
  public testHours: number;
  public posttestHours: number;
}

export class GanttData {
  public module: string;
  public moduleAndToolType: string;
  public colorBar1: any;
  public colorBar2: any;
  public colorBar3: any;
  public colorBar4: any;
  public colorBar5: any;
  public colorBar6: any;
  public colorBar7: any;
  public colorBar8: any;
  public colorBar9: any;
  public colorBar10: any;
  public colorBar11: any;
  public colorBar12: any;
  public colorBar13: any;
  public colorBar14: any;
  public colorBar15: any;
  public colorBar16: any;
  public strokeColor: any;
  public subAssemblyStartDate: Date;
  public subAssemblyEndDate: Date;
  public integrationStartDate: Date;
  public integrationEndDate: Date;
  public testStartDate: Date;
  public testEndDate: Date;
  public postTestStartDate: Date;
  public postTestEndDate: Date;

  public actualSubAssemblyStartDate: any;
  public actualSubAssemblyEndDate: any;
  public actualIntegrationStartDate: any;
  public actualIntegrationEndDate: any;
  public actualTestStartDate: any;
  public actualTestEndDate: any;
  public actualPostTestStartDate: any;
  public actualPostTestEndDate: any;

  public EarliestStartDateFromDate: Date;  
  public EarliestStartDateToDate: string;
  public RecordType?: string;
  public FCID: string;
  public ToolTypeName: string;
  public ProductGroupName: string;
  public MCSDFromDate: Date;
  public MCSDToDate: string;  
  public TSDFromDate: Date;
  public TSDToDate: string;
  public CRDFromDate: Date;
  public CRDToDate: string;
  public SRDFromDate: Date;
  public SRDToDate: string;
  public planofRecordFromDate: Date;
  public planofRecordToDate: string;
  public BuildType: string;
  public RevenueCode: string;
}

export class ProductNameBay {
  public BayTypeName: string;
  public BuildingName: string;
  public Product_Type: string;
  public TotalRemaining: number[];
  public TotalAvailablity: number[];
}

export class WeeklyDatesBay {
  public BayDate: Date;
  public TotalRemaining: number;
  public TotalAvailablity: number;
}

export class ProductNameLabor {
  public Laborgroup: string;
  public ManagementName: string;
  public TotalRemainingHour: number[];
  public TotalAvailablity: number[];
}

export class WeeklyDatesLabor {
  public LaborDate: Date;
  public SumRemainingHour: number;
  public TotalAvailablity: number;
  public TotalConsumedHour: number;
  public TotalRemainingHour: number;
}

export class ScheduledBay {
  public ProductName: ProductNameBay;
  public WeeklyDates: WeeklyDatesBay[];
}

export class ScheduledLabor {
  public ProductName: ProductNameLabor;
  public WeeklyDates: WeeklyDatesLabor[];
}

export class dayWeek {
  public field: string;
}


export class WeeklyDatesSum {
  public Date: Date;
  public TotalRemaining: number;
}

export class ProductNameSum {
  public summaryItems: string;
  public TotalRemaining: number[];
}

export class ScheduleSum {  
  public ProductName: ProductNameSum;
  public WeeklyDates: WeeklyDatesSum[];
}

export class SceduleSUmWeeklyData {
  public WeeklyDates: WeeklyDatesSum;
}
