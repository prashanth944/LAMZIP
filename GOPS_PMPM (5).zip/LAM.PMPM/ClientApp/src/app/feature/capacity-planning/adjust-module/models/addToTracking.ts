export class AddToTracking {
  PlantID: number;
  ProductGroupID: number;
  ProductGroupName: string;
  ToolTypeID: number;
  FCID: string;
  BEN: string;
  RecordType: string;
  RevenueType: string;
  CRD: string;
  TSD: string;
  SRD: string;
  MCSD: string;
  LPRID: string;
}
