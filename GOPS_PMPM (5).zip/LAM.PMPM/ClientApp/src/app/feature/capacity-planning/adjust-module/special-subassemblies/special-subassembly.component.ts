import {
    Component,
    OnInit,
    ViewEncapsulation,
    ViewChild,
    ChangeDetectionStrategy,
    ChangeDetectorRef,
    ViewContainerRef,
} from "@angular/core";
import { FormBuilder } from "@angular/forms";
import {
    distinct,
    process,
    CompositeFilterDescriptor,
    filterBy,
} from "@progress/kendo-data-query";
import { EditService } from "../../../service/edit.service";
import { AppStoreService } from "../../../../core/app-store.service";
import { AdjustModuleService } from "../adjust-module-service/adjustModule.service";
import { role, uiScreen } from "../../../../core/model/common.constant";
import { Plant } from "../../../../core/model/user.model";
import { Item } from "../../../model/item";
import { SpecialSubassembly } from "../models/specialSubassembly";
import * as moment from "moment";
import { NotificationService } from "@progress/kendo-angular-notification";
import { MultiSelectComponent } from "@progress/kendo-angular-dropdowns";
import { TooltipDirective } from "@progress/kendo-angular-tooltip";

@Component({
    selector: "pmpm-special-subassembly",
    templateUrl: "./special-subassembly.component.html",
    styleUrls: ["./special-subassembly.component.css"],
    encapsulation: ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SpecialSubassemblyComponent implements OnInit {
    @ViewChild("appendTo", { read: ViewContainerRef })
    public appendTo: ViewContainerRef;
    @ViewChild("multiselect") public multiselect: MultiSelectComponent;
    @ViewChild(TooltipDirective) public tooltipDir: TooltipDirective;

    site: Plant;
    specialSubassemblyTypeList: Item[] = [
        { text: "Etch", value: 1 },
        { text: "Mecha", value: 2 },
    ];
    specialSubassemblyTypeValue: Item = { text: "Etch", value: 1 };
    specialSubassemblyTypeEditValue: Item = { text: "", value: 0 };
    specialSubassemblyTypeAddValue: Item = { text: "Etch", value: 1 };

    specialSubassemblyGridData: SpecialSubassembly[] = [];
    tempSpecialSubassemblyGridData: SpecialSubassembly[] = [];

    msg: string;
    showPSNorBENerr = false;
    showBTerror = false;

    subassemblyTypeValue = "Etch";
    subassemblyHoursValue = 0;
    engineeringPOCTypeValue = "";
    testHoursValue = 0;
    SOELinkValue = "";
    pilotMEApprovedValue = true;
    pilotCommitedDateValue: Date;
    mfgApprovedValue = true;
    subassyTechsValue = 1;
    subassyBaysValue = 1;
    testTechsValue = 1; //if no test hrs, default test techs and bays to 0.
    testBaysValue = 1;
    pcfsShortageFreeAuditValue = true;
    auditorValue = "";
    dateDeliveredValue: Date;
    kitReceivedDateValue: Date;
    serialNoValue = "";
    techBuildItems: Item[] = [];
    techBuildValue: string;
    pilotBuildCompleteDateValue: Date;
    techTestItems: Item[] = [];
    techTestValue: string;
    pilotTestCompleteDateValue: Date;
    inShippingValue = true;
    ca10ShortageFreeValue = true;

    pcWoReleasedValue: boolean; // = true;//made this already checked. to make PO/WO number mandatory always.
    pcWoValue = "";
    tempPCWOValue = "";
    plannerNameValue = "";
    demandTypeItems: Item[] = [];
    demandTypeValue: Item = { text: "", value: 0 };
    partNumber: string;
    partNumberValue: Item = { text: "", value: 0 };
    descriptionValue = "";
    qty = 0;
    CRD: Date;
    hotValue: boolean;
    reworkValue: boolean;
    SPCLProcessValue: boolean;
    estimatedBuildTime: number;
    estimatedTestTime: number;
    notes = "";

    materialReadinessValue: Date;
    commitLaunchValue: Date;
    committedTestStartValue: Date;
    commitedManufacturingCompleteValue: Date;
    assemblyTechnicianName: string;
    testTechnicianName: string;
    createdDate: Date;
    modifiedDate: Date;
    kitReceivedDate: Date;
    pilotProductID: number;
    engineeringPOC: string;

    public capacityPlanningColorHex: Array<Item> = [];
    capacityPlanningColorItems: Item[] = [];
    capacityPlanningColorValue: Item = { text: "", value: 0 };
    cpColor = "";
    cpColorValue: Item = { text: "", value: 0 };
    assemblySerialNumber: string;

    addOpened = false;
    showEditSection = false;
    showAddNewSubassy = false;
    assemblySerialNumberValue = "";
    descAddNewValue = "";
    soeLinkAddNewValue = "";
    estimatedBuildTimeValue: number;

    showValidationMsg = false;

    //authentication variables
    canViewSpecialSubassembly = false;
    rule1Edit = false; /*Authentication - "Add" new button, Edit Subassembly-->
                              PC tab except PC/WO Released Checkbox, Edit Subassembly-->PCFS, Edit Subassembly-->
                              CA10 tab - Edit for PASS / PCFS, Manager / Director, Supervisor, Lead*/
    rule5Edit = false; //  Authentication - Edit Subassembly-->Mfg Mgr tab-  Mfg Mgr tab - Edit for Manager/Director, Supervisor, Lead
    rule7Edit = false; // Authentication - Edit Subassembly-->Pilot Technician - Edit for Manager/Director, Supervisor, Lead, Technician
    rule8View = false; // Authentication - Edit Subassembly-->Pilot Technician - View for All
    rule9Edit = true; //Authentication - View Summary table under Special Subassemblies, "Edit" button - Edit for All except technicians
    rule10Edit = false; //Authentication - PC/WO Released Checkbox - Edit for Pass Team Member/PCFS
    rule11Edit = false; // Authentication - Edit Subassembly-->Eng - Edit for Engineer, Manager/Director, Supervisor, Lead

    loadTable = true;
    gridFilteredData: any[] = [];
    gridFilteredData2: any[] = [];

    public cA10ShortageFreeItems: any[] = [];
    public requestDateItems: any[] = [];
    public hotItems: any[] = [];
    public isMfgApprovedItems: any[] = [];
    public partNumberItems: any[] = [];

    isCA10Checked = false;
    isRequestDateChecked = false;
    isHotChecked = false;
    isMfgApprovedChecked = false;
    isPartNumberChecked = false;

    disableSave = true;
    errMsg: string;

    public ca10ShortageFreeFilterValue: boolean[] = [];
    public ca10ShortageFreeFilterDataItems: boolean[] = [];
    public tempCa10ShortageFreeFilterDataItems: boolean[] = [];

    public requestDateFilterDataItems: string[] = [];
    public requestDateFilterDataValue: string[] = [];
    public tempRequestDateFilterDataValue: string[] = [];

    public hotFilterItems: string[] = [];
    public tempHotFilterItems: string[] = [];
    public hotFilterValue: string[] = [];

    public mfgApprovedFilterItems: string[] = [];
    public tempMfgApprovedFilterItems: string[] = [];
    public mfgApprovedFilterValue: string[] = [];

    public partNumberFilterItems: string[] = [];
    public tempPartNumberFilterItems: string[] = [];
    public partNumberFilterValue: string[] = [];

    public searchText = "";
    public filter: CompositeFilterDescriptor;

    constructor(
        private formBuilder: FormBuilder,
        public editService: EditService,
        private appStoreService: AppStoreService,
        private adjustModuleService: AdjustModuleService,
        private notificationService: NotificationService,
        private changeDetector: ChangeDetectorRef
    ) {}

    public ngOnInit(): void {
        this.loadTable = true;
        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.SpecialSubassembly)
                    .subscribe((result) => {
                        this.canViewSpecialSubassembly = result;

                        if (
                            res.includes(role.Manager) ||
                            res.includes(role.SuperUser) ||
                            res.includes(role.Supervisor) ||
                            res.includes(role.PassTeamMember) ||
                            res.includes(role.Leads)
                        ) {
                            this.rule1Edit = true;
                        }

                        if (
                            res.includes(role.Manager) ||
                            res.includes(role.SuperUser) ||
                            res.includes(role.Supervisor) ||
                            res.includes(role.Leads)
                        ) {
                            this.rule5Edit = true;
                        }

                        if (
                            res.includes(role.Manager) ||
                            res.includes(role.SuperUser) ||
                            res.includes(role.Supervisor) ||
                            res.includes(role.Technician) ||
                            res.includes(role.Leads)
                        ) {
                            this.rule7Edit = true;
                        }
                        if (res.includes(role.Technician)) {
                            this.rule9Edit = false;
                        }
                        if (
                            res.includes(role.PassTeamMember) ||
                            res.includes(role.SuperUser)
                        ) {
                            this.rule10Edit = true;
                        }
                        if (
                            res.includes(role.Engineer) ||
                            res.includes(role.Manager) ||
                            res.includes(role.Supervisor) ||
                            res.includes(role.Leads) ||
                            res.includes(role.SuperUser)
                        ) {
                            this.rule11Edit = true;
                        }
                    });
            }
        });
        this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site) {
                this.site = {
                    plantName: site.plantName,
                    plantId: site.plantId,
                };
                this.fillSpecialSubassemblyGrid(
                    this.specialSubassemblyTypeValue.text
                );
            }
        });
        this.adjustModuleService.getMRPDemand().subscribe((res) => {
            if (res) {
                res.forEach((val) => {
                    const dt: Item = {
                        text: val.masterRecordName,
                        value: val.masterRecordID,
                    };
                    this.demandTypeItems.push(dt);
                });
            }
        });
        this.adjustModuleService.getModuleColorDDL().subscribe((mc) => {
            mc.forEach((val) => {
                const newMC: Item = {
                    value: val.value.trim(),
                    text: val.masterRecordName,
                };
                this.capacityPlanningColorHex.push(newMC);
            });
        });
    }
    specialSubassemblyTypeChange(e) {
        this.showEditSection = false;
        this.fillSpecialSubassemblyGrid(e.text);
        this.resetAddEditSpecialSubassembly();
        this.specialSubassemblyTypeAddValue = e;
    }
    fillSpecialSubassemblyGrid(subassyType) {
        this.loadTable = true;
        this.adjustModuleService
            .getSpecialSubAssySummary(this.site?.plantId, subassyType, 0)
            .subscribe((res) => {
                if (res) {
                    this.specialSubassemblyGridData = res;
                    this.specialSubassemblyGridData.forEach((val) => {
                        val.cA10ShortageFree =
                            val.cA10ShortageFree !== null
                                ? val.cA10ShortageFree
                                : false;
                        val.hot = val.hot !== null ? val.hot : false;
                        val.mfgApproved =
                            val.mfgApproved !== null ? val.mfgApproved : false;

                        val.dateDelivered =
                            val.dateDelivered !== null
                                ? moment(val.dateDelivered).format("M-D-YY")
                                : null;
                        val.materialReadiness =
                            val.materialReadiness !== null
                                ? moment(val.materialReadiness).format("M-D-YY")
                                : null;
                        val.crd =
                            val.crd !== null
                                ? moment(val.crd).format("M-D-YY")
                                : null;
                        val.commitLaunch =
                            val.commitLaunch !== null
                                ? moment(val.commitLaunch).format("M-D-YY")
                                : null;
                        val.committedTestStart =
                            val.committedTestStart !== null
                                ? moment(val.committedTestStart).format(
                                      "M-D-YY"
                                  )
                                : null;
                        val.commitedManufacturingComplete =
                            val.commitedManufacturingComplete !== null
                                ? moment(
                                      val.commitedManufacturingComplete
                                  ).format("M-D-YY")
                                : null;
                        val.pilotCommit =
                            val.pilotCommit !== null
                                ? moment(val.pilotCommit).format("M-D-YY")
                                : null;
                        val.createdDate =
                            val.createdDate !== null
                                ? moment(val.createdDate).format("M-D-YY")
                                : null;
                        val.modifiedDate =
                            val.modifiedDate !== null
                                ? moment(val.modifiedDate).format("M-D-YY")
                                : null;
                    });
                    this.tempSpecialSubassemblyGridData =
                        this.specialSubassemblyGridData;
                    this.gridFilteredData = this.specialSubassemblyGridData;
                    this.gridFilteredData2 = this.specialSubassemblyGridData;

                    const data1: any = distinct(
                        this.tempSpecialSubassemblyGridData,
                        "cA10ShortageFree"
                    ).map((item) => item["cA10ShortageFree"]);
                    this.ca10ShortageFreeFilterDataItems = data1;
                    this.tempCa10ShortageFreeFilterDataItems = JSON.parse(
                        JSON.stringify(data1)
                    );

                    let data2: any = distinct(
                        this.tempSpecialSubassemblyGridData,
                        "crd"
                    ).map((item) => item["crd"]);
                    data2 = data2.flatMap((f) => (f ? [f] : []));
                    data2.sort(function (a, b) {
                        const textA = a?.toUpperCase();
                        const textB = b?.toUpperCase();
                        return textA < textB ? -1 : textA > textB ? 1 : 0;
                    });
                    this.requestDateFilterDataItems = data2;
                    this.tempRequestDateFilterDataValue = JSON.parse(
                        JSON.stringify(data2)
                    );

                    const data3: any = distinct(
                        this.tempSpecialSubassemblyGridData,
                        "hot"
                    ).map((item) => item["hot"]);
                    this.hotFilterItems = data3;
                    this.tempHotFilterItems = JSON.parse(JSON.stringify(data3));

                    const data4: any = distinct(
                        this.tempSpecialSubassemblyGridData,
                        "mfgApproved"
                    ).map((item) => item["mfgApproved"]);
                    this.mfgApprovedFilterItems = data4;
                    this.tempMfgApprovedFilterItems = JSON.parse(
                        JSON.stringify(data4)
                    );

                    let data5: any = distinct(
                        this.tempSpecialSubassemblyGridData,
                        "partNumber"
                    ).map((item) => item["partNumber"]);
                    data5 = data5.flatMap((f) => (f ? [f] : []));
                    data5.sort(function (a, b) {
                        const textA = a?.toUpperCase();
                        const textB = b?.toUpperCase();
                        return textA < textB ? -1 : textA > textB ? 1 : 0;
                    });
                    this.partNumberFilterItems = data5;
                    this.tempPartNumberFilterItems = JSON.parse(
                        JSON.stringify(data5)
                    );

                    this.cA10ShortageFreeItems =
                        this.distinctPrimitive("cA10ShortageFree");
                    this.requestDateItems = this.distinctPrimitive("crd");
                    this.hotItems = this.distinctPrimitive("hot");
                    this.isMfgApprovedItems =
                        this.distinctPrimitive("mfgApproved");
                    this.partNumberItems = this.distinctPrimitive("partNumber");

                    this.loadTable = false;
                    this.changeDetector.detectChanges();
                }
            });
    }
    openEdit(dataItem) {
        const val = this.specialSubassemblyGridData.filter(
            (x) => x.pilotProductID == dataItem.pilotProductID
        );
        const res = val[0];
        //PC Tab
        this.specialSubassemblyTypeEditValue = this.specialSubassemblyTypeValue;
        this.pcWoReleasedValue = res.pcwoReleased;
        this.pcWoValue = res.productionOrderNum;
        this.tempPCWOValue = res.productionOrderNum;
        this.plannerNameValue = res.plannerName;
        this.demandTypeValue.text = res.mrpDemand;
        this.demandTypeValue.value = res.mrpDemandID;
        this.partNumber = res.partNumber;
        this.descriptionValue = res.description;
        this.qty = res.qty;
        this.CRD = res.crd !== null ? new Date(res.crd) : null;
        this.hotValue = res.hot;
        this.reworkValue = res.rework;
        this.SPCLProcessValue = res.spclProcess;
        this.estimatedBuildTime = res.estimatedBuildTime;
        this.estimatedTestTime = res.testBuildHours;
        this.notes = res.note;

        this.cpColorValue = {
            text: this.getTextFromValue(res.capacityPlanningColor),
            value: res.capacityPlanningColor,
        };

        this.assemblySerialNumber = res.assemblySerialNumber;

        //Eng tab
        this.subassemblyTypeValue = res.specialSubAssyType;
        this.subassemblyHoursValue =
            res.subassemblyBuildHours >= 0 ? res.subassemblyBuildHours : 0;
        this.engineeringPOC = res.engineeringPOC;
        this.testHoursValue = res.testBuildHours;
        this.pilotMEApprovedValue = res.pilotMEApproved;
        this.SOELinkValue = res.soeLink;

        //Mfg Mgr
        this.pilotCommitedDateValue =
            res.pilotCommit !== null ? new Date(res.pilotCommit) : null;
        this.mfgApprovedValue = res.mfgApproved;
        this.subassyTechsValue = res.subassemblyTechnician;
        this.subassyBaysValue = res.subassemblyBays;
        this.testTechsValue = res.testTechnician;
        this.testBaysValue = res.testBays;

        //PCFS
        this.pcfsShortageFreeAuditValue = res.pcfsShortageFreeAudit;
        this.auditorValue = res.auditor;
        this.dateDeliveredValue =
            res.dateDelivered !== null ? new Date(res.dateDelivered) : null;
        this.kitReceivedDateValue =
            res.kitReceivedDate !== null ? new Date(res.kitReceivedDate) : null;

        //Pilot Technician
        this.serialNoValue = res.serialNum;
        this.techBuildValue = res.techBuild;
        this.pilotBuildCompleteDateValue =
            res.actualTestStart !== null ? new Date(res.actualTestStart) : null;
        this.techTestValue = res.techTest;
        this.pilotTestCompleteDateValue =
            res.actualTestComplete !== null
                ? new Date(res.actualTestComplete)
                : null;
        this.inShippingValue = res.inShipping;

        //CA10
        this.ca10ShortageFreeValue = res.cA10ShortageFree;

        this.materialReadinessValue =
            res.materialReadiness !== null
                ? new Date(res.materialReadiness)
                : null;
        this.commitLaunchValue =
            res.commitLaunch !== null ? new Date(res.commitLaunch) : null;
        this.committedTestStartValue =
            res.committedTestStart !== null
                ? new Date(res.committedTestStart)
                : null;
        this.commitedManufacturingCompleteValue =
            res.commitedManufacturingComplete !== null
                ? new Date(res.commitedManufacturingComplete)
                : null;
        this.assemblyTechnicianName = res.assemblyTechnicianName;
        this.testTechnicianName = res.testTechnicianName;
        this.createdDate =
            res.createdDate !== null ? new Date(res.createdDate) : null;
        this.modifiedDate =
            res.modifiedDate !== null ? new Date(res.modifiedDate) : null;
        this.kitReceivedDate =
            res.kitReceivedDate !== null ? new Date(res.kitReceivedDate) : null;
        this.pilotProductID = res.pilotProductID;
        this.engineeringPOC = res.engineeringPOC;

        this.showEditSection = !this.showEditSection;
    }
    getTextFromValue(st) {
        let retval = "";
        this.capacityPlanningColorHex.forEach((val) => {
            if (val.value == st) {
                retval = val.text;
            }
        });
        return retval;
    }
    onTabSelect(e) {}
    closeEdit() {
        this.fillSpecialSubassemblyGrid(this.specialSubassemblyTypeValue.text);
        this.resetAddEditSpecialSubassembly();
        this.showEditSection = false;
        this.disableSave = true;
    }
    openAdd() {
        this.addOpened = true;
    }
    closeAdd() {
        this.resetAddEditSpecialSubassembly();
        this.addOpened = false;
    }
    showAddNewSubassembly() {
        this.showAddNewSubassy = !this.showAddNewSubassy;
    }
    cpColorSelectionChange(event) {
        this.cpColor = event.value;
        this.cpColorValue = event.text;
        this.onChange();
    }
    onSubmitAdd() {
        const splSubAddObj: SpecialSubassembly = {
            plantId: this.site?.plantId,
            hot: this.hotValue,
            productionOrderNum:
                this.pcWoValue !== undefined ? this.pcWoValue : null,
            pcwoReleased:
                this.pcWoReleasedValue !== undefined
                    ? this.pcWoReleasedValue
                    : null,
            cA10ShortageFree: null,
            dateDelivered: null,
            mfgApproved: null,
            pcfsAuditedBy: null,
            qty: this.qty,
            plannerName:
                this.plannerNameValue !== undefined
                    ? this.plannerNameValue
                    : null,
            partNumber: this.partNumber !== undefined ? this.partNumber : null,
            description: this.descriptionValue,
            subassemblyBuildHours: null,
            subassemblyTechnician: null,
            subassemblyBays: null,
            testBuildHours: null,
            testTechnician: null,
            testBays: null,
            totalLaborHour: null,
            materialReadiness: null,
            crd:
                this.CRD !== undefined
                    ? moment(this.CRD).format("yyyy-MM-DD")
                    : null,
            commitLaunch: null,
            committedTestStart: null,
            commitedManufacturingComplete: null,
            pilotCommit: null,
            assemblyTechnicianName: null,
            testTechnicianName: null,
            mrpDemand:
                this.demandTypeValue.text !== ""
                    ? this.demandTypeValue.text
                    : null,
            capacityPlanningColor:
                this.cpColorValue.value !== 0 ? this.cpColorValue.value : null,
            note: this.notes,
            createdDate: null,
            modifiedDate: null,
            pilotProductID: null,

            auditor: null,
            engineeringPOC: null,
            estimatedBuildTime:
                this.estimatedBuildTime !== undefined
                    ? this.estimatedBuildTime
                    : null,
            estimatedTestTime:
                this.estimatedTestTime !== undefined
                    ? this.estimatedTestTime
                    : null,
            kitReceivedDate: null,
            mrpDemandID:
                this.demandTypeValue.value !== 0
                    ? this.demandTypeValue.value
                    : null,
            pcfsShortageFreeAudit: null,
            pilotMEApproved: null,
            rework: this.reworkValue,
            serialNum: null,
            soeLink: this.soeLinkAddNewValue,
            spclProcess: this.SPCLProcessValue,
            specialSubAssyType: this.specialSubassemblyTypeAddValue.text,

            techBuild: null,
            techTest: null,

            assemblySerialNumber: this.assemblySerialNumber,
            actualTestStart: null,
            actualTestComplete: null,
            inShipping: null,
        };
        if (this.checkValidation(splSubAddObj) === false) {
            this.errMsg = "(*)Please fill all the mandatory fields.";
            this.showValidationMsg = true;
            return;
        } else if (this.checkValidData(splSubAddObj) === false) {
            this.errMsg = "(*)Invalid Input";
            this.showValidationMsg = true;
            return;
        } else {
            this.adjustModuleService
                .getpsnbenexists(this.site?.plantId, this.pcWoValue)
                .subscribe((res) => {
                    if (res.exist == 0) {
                        this.showPSNorBENerr = false;
                        this.checkIfEqual();
                        this.loadTable = true;
                        this.adjustModuleService
                            .addEditSpecialSubAssy(splSubAddObj)
                            .subscribe((res) => {
                                if (res) {
                                    this.fillSpecialSubassemblyGrid(
                                        this.specialSubassemblyTypeValue.text
                                    );
                                }
                            });
                        this.addOpened = false;
                        this.resetAddEditSpecialSubassembly();
                    }
                    this.changeDetector.detectChanges();
                });
        }
    }
    checkValidation(splSubAddObj) {
        if (
            splSubAddObj.specialSubAssyType === null ||
            splSubAddObj.productionOrderNum === null ||
            splSubAddObj.productionOrderNum === "" ||
            splSubAddObj.plannerName === null ||
            splSubAddObj.plannerName === "" ||
            splSubAddObj.mrpDemand === null ||
            splSubAddObj.mrpDemandID === null ||
            splSubAddObj.partNumber === null ||
            splSubAddObj.partNumber === "" ||
            splSubAddObj.crd === null ||
            splSubAddObj.estimatedBuildTime === null ||
            splSubAddObj.estimatedBuildTime === ""
        ) {
            return false;
        }
        return true;
    }
    checkValidData(splSubAddObj: SpecialSubassembly) {
        if (
            (splSubAddObj.qty !== null &&
                (splSubAddObj.qty < 0 ||
                    splSubAddObj.qty > 100 ||
                    splSubAddObj.qty % 1 !== 0)) ||
            (splSubAddObj.estimatedBuildTime !== null &&
                (splSubAddObj.estimatedBuildTime < 0 ||
                    splSubAddObj.estimatedBuildTime > 9999 ||
                    splSubAddObj.estimatedBuildTime % 1 !== 0)) ||
            (splSubAddObj.estimatedTestTime !== null &&
                (splSubAddObj.estimatedTestTime < 0 ||
                    splSubAddObj.estimatedTestTime > 9999 ||
                    splSubAddObj.estimatedTestTime % 1 !== 0)) ||
            (splSubAddObj.testBuildHours !== null &&
                (splSubAddObj.testBuildHours < 0 ||
                    splSubAddObj.testBuildHours > 9999 ||
                    splSubAddObj.testBuildHours % 1 !== 0)) ||
            (splSubAddObj.subassemblyBays !== null &&
                (splSubAddObj.subassemblyBays < 0 ||
                    splSubAddObj.subassemblyBays > 10 ||
                    splSubAddObj.subassemblyBays % 1 !== 0)) ||
            (splSubAddObj.subassemblyTechnician !== null &&
                (splSubAddObj.subassemblyTechnician < 0 ||
                    splSubAddObj.subassemblyTechnician > 10 ||
                    splSubAddObj.subassemblyBays % 1 !== 0)) ||
            (splSubAddObj.testBays !== null &&
                (splSubAddObj.testBays < 0 ||
                    splSubAddObj.testBays > 10 ||
                    splSubAddObj.testBays % 1 !== 0)) ||
            (splSubAddObj.testTechnician !== null &&
                (splSubAddObj.testTechnician < 0 ||
                    splSubAddObj.testTechnician > 10 ||
                    splSubAddObj.testTechnician % 1 !== 0)) ||
            this.checkValidityOfString(splSubAddObj.partNumber) === false ||
            (splSubAddObj.serialNum !== null &&
                this.checkValidityOfString(splSubAddObj.serialNum) === false)
        ) {
            return false;
        }
        return true;
    }
    checkValidityOfString(str) {
        const x = str.match("[a-zA-Z0-9-]+");
        if (x == str) {
            return true;
        } else {
            return false;
        }
    }
    checkForNum(e) {
        if (e.key == "E" || e.key == "e" || e.key == ".") {
            e.preventDefault();
        }
    }
    public showError(msg: string): void {
        this.notificationService.show({
            appendTo: this.appendTo,
            content: msg,
            position: { horizontal: "left", vertical: "bottom" },
            animation: { type: "fade", duration: 600 },
            type: { style: "warning", icon: true },
        });
    }
    resetAddEditSpecialSubassembly() {
        this.showValidationMsg = false;
        this.showPSNorBENerr = false;
        this.showBTerror = false;

        //PC Tab
        this.specialSubassemblyTypeAddValue = this.specialSubassemblyTypeValue;
        this.pcWoReleasedValue = undefined; //true;//made this already checked. to make PO/WO number mandatory always.
        this.pcWoValue = undefined;
        this.tempPCWOValue = undefined;
        this.plannerNameValue = undefined;
        this.demandTypeValue = { text: "", value: 0 };
        this.partNumber = undefined;
        this.assemblySerialNumberValue = undefined;
        this.soeLinkAddNewValue = undefined;
        this.descriptionValue = undefined;
        this.qty = undefined;
        this.CRD = undefined;
        this.hotValue = undefined;
        this.reworkValue = undefined;
        this.SPCLProcessValue = undefined;
        this.estimatedBuildTime = undefined;
        this.estimatedTestTime = undefined;
        this.notes = "";
        this.cpColorValue = { text: "", value: 0 };
        this.cpColor = undefined;
        this.showAddNewSubassy = false;

        //Eng tab
        this.subassemblyTypeValue = undefined;
        this.subassemblyHoursValue = undefined;
        this.engineeringPOC = undefined;
        this.testHoursValue = undefined;
        this.pilotMEApprovedValue = undefined;
        this.SOELinkValue = undefined;

        //Mfg Mgr
        this.pilotCommitedDateValue = undefined;
        this.mfgApprovedValue = undefined;
        this.subassyTechsValue = undefined;
        this.subassyBaysValue = undefined;
        this.testTechsValue = undefined;
        this.testBaysValue = undefined;

        //PCFS
        this.pcfsShortageFreeAuditValue = undefined;
        this.auditorValue = undefined;
        this.dateDeliveredValue = undefined;
        this.kitReceivedDateValue = undefined;

        //Pilot Technician
        this.serialNoValue = undefined;
        this.techBuildValue = undefined;
        this.pilotBuildCompleteDateValue = undefined;
        this.techTestValue = undefined;
        this.pilotTestCompleteDateValue = undefined;
        this.inShippingValue = undefined;

        //CA10
        this.ca10ShortageFreeValue = undefined;
    }

    onSaveEdit() {
        const splSubEditObj: SpecialSubassembly = {
            plantId: this.site?.plantId,
            hot: this.hotValue,
            productionOrderNum: this.pcWoValue,
            pcwoReleased: this.pcWoReleasedValue,
            cA10ShortageFree: this.ca10ShortageFreeValue,
            dateDelivered:
                this.dateDeliveredValue !== null
                    ? moment(this.dateDeliveredValue).format("yyyy-MM-DD")
                    : null,
            mfgApproved: this.mfgApprovedValue,
            pcfsAuditedBy: this.auditorValue,
            qty: this.qty,
            plannerName: this.plannerNameValue,
            partNumber: this.partNumber,
            description: this.descriptionValue,
            subassemblyBuildHours:
                this.subassemblyHoursValue >= 0
                    ? this.subassemblyHoursValue
                    : 0,
            subassemblyTechnician: this.subassyTechsValue,
            subassemblyBays: this.subassyBaysValue,
            testBuildHours: this.testHoursValue,
            testTechnician: this.testTechsValue,
            testBays: this.testBaysValue,
            totalLaborHour: this.subassemblyHoursValue + this.testHoursValue,
            materialReadiness:
                this.materialReadinessValue !== null
                    ? moment(this.materialReadinessValue).format("yyyy-MM-DD")
                    : null,
            crd:
                this.CRD !== null ? moment(this.CRD).format("yyyy-MM-DD") : null,
            commitLaunch:
                this.commitLaunchValue !== null
                    ? moment(this.commitLaunchValue).format("yyyy-MM-DD")
                    : null,
            committedTestStart:
                this.committedTestStartValue !== null
                    ? moment(this.committedTestStartValue).format("yyyy-MM-DD")
                    : null,
            commitedManufacturingComplete:
                this.commitedManufacturingCompleteValue !== null
                    ? moment(this.commitedManufacturingCompleteValue).format(
                          "yyyy-MM-DD"
                      )
                    : null,
            pilotCommit:
                this.pilotCommitedDateValue !== null
                    ? moment(this.pilotCommitedDateValue).format("yyyy-MM-DD")
                    : null,
            assemblyTechnicianName: this.assemblyTechnicianName,
            testTechnicianName: this.testTechnicianName,
            mrpDemand: this.demandTypeValue.text,
            capacityPlanningColor: this.cpColorValue.value,
            note: this.notes,
            createdDate:
                this.createdDate !== null
                    ? moment(this.createdDate).format("yyyy-MM-DD")
                    : null,
            modifiedDate:
                this.modifiedDate !== null
                    ? moment(this.modifiedDate).format("yyyy-MM-DD")
                    : null,
            pilotProductID: this.pilotProductID,

            auditor: this.auditorValue,
            engineeringPOC: this.engineeringPOC,
            estimatedBuildTime: this.estimatedBuildTime,
            estimatedTestTime: this.estimatedTestTime,
            kitReceivedDate:
                this.kitReceivedDateValue !== null
                    ? moment(this.kitReceivedDateValue).format("yyyy-MM-DD")
                    : null,
            mrpDemandID: this.demandTypeValue.value,
            pcfsShortageFreeAudit: this.pcfsShortageFreeAuditValue,
            pilotMEApproved: this.pilotMEApprovedValue,
            rework: this.reworkValue,
            serialNum: this.serialNoValue,
            soeLink: this.SOELinkValue,
            spclProcess: this.SPCLProcessValue,
            specialSubAssyType: this.specialSubassemblyTypeAddValue.text,

            techBuild: this.techBuildValue,
            techTest: this.techTestValue,

            assemblySerialNumber: this.assemblySerialNumber,
            actualTestStart:
                this.pilotBuildCompleteDateValue !== null
                    ? moment(this.pilotBuildCompleteDateValue).format(
                          "yyyy-MM-DD"
                      )
                    : null,
            actualTestComplete:
                this.pilotTestCompleteDateValue !== null
                    ? moment(this.pilotTestCompleteDateValue).format(
                          "yyyy-MM-DD"
                      )
                    : null,
            inShipping: this.inShippingValue,
        };
        if (this.checkValidation(splSubEditObj) === false) {
            this.showError("Please fill all the mandatory fields");
            return;
        }
        if (this.checkValidData(splSubEditObj) === false) {
            this.showError("Invalid Data Entered!");
            return;
        }
        this.adjustModuleService
            .addEditSpecialSubAssy(splSubEditObj)
            .subscribe((res) => {
                if (res) {
                    this.showSuccess();
                    this.disableSave = true;
                    this.showPSNorBENerr = false;
                    this.changeDetector.detectChanges();
                    this.adjustModuleService
                        .getSpecialSubAssySummary(
                            this.site?.plantId,
                            this.specialSubassemblyTypeValue.text,
                            this.pilotProductID
                        )
                        .subscribe((res) => {
                            this.tempSpecialSubassemblyGridData = res;
                        });
                }
            });
    }
    onCancelEdit() {
        this.showPSNorBENerr = false;
        const res = this.tempSpecialSubassemblyGridData.filter(
            (x) => x.pilotProductID == this.pilotProductID
        )[0];
        //PC Tab
        this.specialSubassemblyTypeEditValue = this.specialSubassemblyTypeValue;
        this.pcWoReleasedValue = res.pcwoReleased;
        this.pcWoValue = res.productionOrderNum;
        this.plannerNameValue = res.plannerName;
        this.demandTypeValue.text = res.mrpDemand;
        this.demandTypeValue.value = res.mrpDemandID;
        this.partNumber = res.partNumber;
        this.descriptionValue = res.description;
        this.qty = res.qty;
        this.CRD = res.crd !== null ? new Date(res.crd) : null;
        this.hotValue = res.hot;
        this.reworkValue = res.rework;
        this.SPCLProcessValue = res.spclProcess;
        this.estimatedBuildTime = res.estimatedBuildTime;
        this.estimatedTestTime = res.testBuildHours;
        this.notes = res.note;
        this.cpColorValue = {
            text: this.getTextFromValue(res.capacityPlanningColor),
            value: res.capacityPlanningColor,
        };

        this.assemblySerialNumber = res.assemblySerialNumber;

        //Eng tab
        this.subassemblyTypeValue = res.specialSubAssyType;
        this.subassemblyHoursValue =
            res.subassemblyBuildHours >= 0 ? res.subassemblyBuildHours : 0;
        this.engineeringPOC = res.engineeringPOC;
        this.testHoursValue = res.testBuildHours;
        this.pilotMEApprovedValue = res.pilotMEApproved;
        this.SOELinkValue = res.soeLink;

        //Mfg Mgr
        this.pilotCommitedDateValue =
            res.pilotCommit !== null ? new Date(res.pilotCommit) : null;
        this.mfgApprovedValue = res.mfgApproved;
        this.subassyTechsValue = res.subassemblyTechnician;
        this.subassyBaysValue = res.subassemblyBays;
        this.testTechsValue = res.testTechnician;
        this.testBaysValue = res.testBays;

        //PCFS
        this.pcfsShortageFreeAuditValue = res.pcfsShortageFreeAudit;
        this.auditorValue = res.auditor;
        this.dateDeliveredValue =
            res.dateDelivered !== null ? new Date(res.dateDelivered) : null;
        this.kitReceivedDateValue =
            res.kitReceivedDate !== null ? new Date(res.kitReceivedDate) : null;

        //Pilot Technician
        this.serialNoValue = res.serialNum;
        this.techBuildValue = res.techBuild;
        this.pilotBuildCompleteDateValue =
            res.actualTestStart !== null ? new Date(res.actualTestStart) : null;
        this.techTestValue = res.techTest;
        this.pilotTestCompleteDateValue =
            res.actualTestComplete !== null
                ? new Date(res.actualTestComplete)
                : null;
        this.inShippingValue = res.inShipping;

        //CA10
        this.ca10ShortageFreeValue = res.cA10ShortageFree;

        this.materialReadinessValue =
            res.materialReadiness !== null
                ? new Date(res.materialReadiness)
                : null;
        this.commitLaunchValue =
            res.commitLaunch !== null ? new Date(res.commitLaunch) : null;
        this.committedTestStartValue =
            res.committedTestStart !== null
                ? new Date(res.committedTestStart)
                : null;
        this.commitedManufacturingCompleteValue =
            res.commitedManufacturingComplete !== null
                ? new Date(res.commitedManufacturingComplete)
                : null;
        this.assemblyTechnicianName = res.assemblyTechnicianName;
        this.testTechnicianName = res.testTechnicianName;
        this.createdDate =
            res.createdDate !== null ? new Date(res.createdDate) : null;
        this.modifiedDate =
            res.modifiedDate !== null ? new Date(res.modifiedDate) : null;
        this.kitReceivedDate =
            res.kitReceivedDate !== null ? new Date(res.kitReceivedDate) : null;
        this.pilotProductID = res.pilotProductID;
        this.engineeringPOC = res.engineeringPOC;

        this.disableSave = true;
    }
    public showSuccess(): void {
        this.notificationService.show({
            appendTo: this.appendTo,
            content: "Saved",
            position: { horizontal: "left", vertical: "bottom" },
            animation: { type: "fade", duration: 600 },
            type: { style: "success", icon: true },
        });
    }

    onItemClick(value, field) {
        this.onClearCheckbox(value, field);
        value.checked = true;
        this.onFilterData(value.text, field);
        this.setButtonColor(value, field);
    }

    setButtonColor(value, field) {
        switch (field) {
            case "cA10ShortageFree":
                if (value.text === "None") {
                    this.isCA10Checked = false;
                } else {
                    this.isCA10Checked = true;
                }
                break;
            case "crd":
                if (value.text === "None") {
                    this.isRequestDateChecked = false;
                } else {
                    this.isRequestDateChecked = true;
                }
                break;
            case "hot":
                if (value.text === "None") {
                    this.isHotChecked = false;
                } else {
                    this.isHotChecked = true;
                }
                break;
            case "mfgApproved":
                if (value.text === "None") {
                    this.isMfgApprovedChecked = false;
                } else {
                    this.isMfgApprovedChecked = true;
                }
                break;
            case "partNumber":
                if (value.text === "None") {
                    this.isPartNumberChecked = false;
                } else {
                    this.isPartNumberChecked = true;
                }
                break;
        }
    }

    onClearCheckbox(value, field) {
        switch (field) {
            case "cA10ShortageFree":
                this.cA10ShortageFreeItems.forEach(
                    (item) => (item.checked = false)
                );
                break;
            case "crd":
                this.requestDateItems.forEach((item) => (item.checked = false));
                break;
            case "hot":
                this.hotItems.forEach((item) => (item.checked = false));
                break;
            case "mfgApproved":
                this.isMfgApprovedItems.forEach(
                    (item) => (item.checked = false)
                );
                break;
            case "partNumber":
                this.partNumberItems.forEach((item) => (item.checked = false));
                break;
        }
    }
    onResetFilters() {
        this.onClearCheckbox("", "cA10ShortageFree");
        this.onClearCheckbox("", "crd");
        this.onClearCheckbox("", "hot");
        this.onClearCheckbox("", "mfgApproved");
        this.onClearCheckbox("", "partNumber");
        this.isCA10Checked = false;
        this.isRequestDateChecked = false;
        this.isHotChecked = false;
        this.isMfgApprovedChecked = false;
        this.isPartNumberChecked = false;

        this.specialSubassemblyGridData = this.gridFilteredData2;
    }
    public distinctPrimitive(fieldName: string): any {
        const distinctData: any[] = distinct(
            this.specialSubassemblyGridData,
            fieldName
        ).map((item) => item[fieldName]);
        const data: any[] = [{ text: "None", checked: true }];
        distinctData.forEach((item) => {
            data.push({ text: item, checked: false });
        });
        return data;
    }

    public onFilterData(inputValue: string, field: string): void {
        if (inputValue === "None") {
            this.specialSubassemblyGridData = this.gridFilteredData;
        } else {
            this.specialSubassemblyGridData = process(this.gridFilteredData, {
                filter: {
                    logic: "and",
                    filters: [
                        {
                            field: field,
                            operator: "eq",
                            value: inputValue,
                        },
                    ],
                },
            }).data;
        }
    }

    public getValue(event: Event): string {
        return (event.target as HTMLInputElement).value;
    }
    checkValidationQty(e) {
        if (e < 0) {
            this.qty = 0;
        } else if (e > 100) {
            this.qty = 100;
        }
    }
    checkPSNorBEN() {
        this.adjustModuleService
            .getpsnbenexists(this.site?.plantId, this.pcWoValue)
            .subscribe((res) => {
                if (res.exist == 0) {
                    this.showPSNorBENerr = false;
                    this.disableSave = false;
                } else {
                    if (this.tempPCWOValue !== this.pcWoValue) {
                        this.showPSNorBENerr = true;
                        this.disableSave = true;
                    }
                }
                this.changeDetector.detectChanges();
            });
    }
    checkIfEqual() {
        if (
            this.estimatedBuildTime !== undefined ||
            this.estimatedBuildTime !== null ||
            this.estimatedTestTime !== undefined ||
            this.estimatedTestTime !== null
        ) {
            if (this.estimatedBuildTime > this.estimatedTestTime) {
                this.showBTerror = false;
                this.disableSave = false;
            } else if (this.estimatedTestTime !== null) {
                this.showBTerror = true;
            }
        }
    }
    checkValidation2() {
        const splSubAddObj: SpecialSubassembly = {
            plantId: this.site?.plantId,
            hot: this.hotValue,
            productionOrderNum:
                this.pcWoValue !== undefined ? this.pcWoValue : null,
            pcwoReleased:
                this.pcWoReleasedValue !== undefined
                    ? this.pcWoReleasedValue
                    : null,
            cA10ShortageFree: null,
            dateDelivered: null,
            mfgApproved: null,
            pcfsAuditedBy: null,
            qty: this.qty,
            plannerName:
                this.plannerNameValue !== undefined
                    ? this.plannerNameValue
                    : null,
            partNumber: this.partNumber !== undefined ? this.partNumber : null,
            description: this.descriptionValue,
            subassemblyBuildHours: null,
            subassemblyTechnician: null,
            subassemblyBays: null,
            testBuildHours: null,
            testTechnician: null,
            testBays: null,
            totalLaborHour: null,
            materialReadiness: null,
            crd:
                this.CRD !== undefined
                    ? moment(this.CRD).format("yyyy-MM-DD")
                    : null,
            commitLaunch: null,
            committedTestStart: null,
            commitedManufacturingComplete: null,
            pilotCommit: null,
            assemblyTechnicianName: null,
            testTechnicianName: null,
            mrpDemand:
                this.demandTypeValue.text !== ""
                    ? this.demandTypeValue.text
                    : null,
            capacityPlanningColor:
                this.cpColorValue.value !== 0 ? this.cpColorValue.value : null,
            note: this.notes,
            createdDate: null,
            modifiedDate: null,
            pilotProductID: null,

            auditor: null,
            engineeringPOC: null,
            estimatedBuildTime:
                this.estimatedBuildTime !== undefined
                    ? this.estimatedBuildTime
                    : null,
            estimatedTestTime:
                this.estimatedTestTime !== undefined
                    ? this.estimatedTestTime
                    : null,
            kitReceivedDate: null,
            mrpDemandID:
                this.demandTypeValue.value !== 0
                    ? this.demandTypeValue.value
                    : null,
            pcfsShortageFreeAudit: null,
            pilotMEApproved: null,
            rework: this.reworkValue,
            serialNum: null,
            soeLink: this.soeLinkAddNewValue,
            spclProcess: this.SPCLProcessValue,
            specialSubAssyType: this.specialSubassemblyTypeAddValue.text,

            techBuild: null,
            techTest: null,

            assemblySerialNumber: this.assemblySerialNumber,
            actualTestStart: null,
            actualTestComplete: null,
            inShipping: null,
        };
        if (this.checkValidation(splSubAddObj) === false) {
            this.errMsg = "(*)Please fill all the mandatory fields.";
            this.showValidationMsg = true;
            this.checkPSNorBEN();
        } else {
            this.showValidationMsg = false;
        }
    }
    onChange() {
        this.disableSave = false;
    }
    onChangeEBT() {
        if (this.estimatedTestTime !== null) {
            if (this.estimatedBuildTime - this.estimatedTestTime >= 0) {
                this.subassemblyHoursValue =
                    this.estimatedBuildTime - this.estimatedTestTime;
            } else {
                this.subassemblyHoursValue = 0;
            }
        } else {
            this.subassemblyHoursValue = this.estimatedBuildTime - 0;
        }
    }
    onChangeETT() {
        if (this.estimatedBuildTime !== null) {
            if (this.estimatedBuildTime - this.estimatedTestTime >= 0) {
                this.subassemblyHoursValue =
                    this.estimatedBuildTime - this.estimatedTestTime;
            } else {
                this.subassemblyHoursValue = 0;
            }
        }
        this.testHoursValue = this.estimatedTestTime;
    }
    onChangeSubassyHrs() {
        if (this.testHoursValue !== null) {
            this.estimatedBuildTime =
                this.subassemblyHoursValue + this.testHoursValue;
        } else {
            this.estimatedBuildTime = this.subassemblyHoursValue + 0;
        }
    }
    onChangeTestHrs() {
        if (this.subassemblyHoursValue !== null) {
            this.estimatedBuildTime =
                this.subassemblyHoursValue + this.testHoursValue;
        } else {
            this.estimatedBuildTime = 0 + this.testHoursValue;
        }
        this.estimatedTestTime = this.testHoursValue;
    }

    handleCa10ShortageFilter(value) {
        if (value.length >= 0) {
            this.ca10ShortageFreeFilterDataItems =
                this.tempCa10ShortageFreeFilterDataItems.filter(
                    (s) => s == value
                );
        } else {
            this.multiselect.toggle(false);
        }
    }
    handleRequestDateFilter(value) {
        if (value.length >= 0) {
            this.requestDateFilterDataItems =
                this.tempRequestDateFilterDataValue.filter(
                    (s) => s?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
                );
        } else {
            this.multiselect.toggle(false);
        }
    }
    handleHotFilter(value) {
        if (value.length >= 0) {
            this.hotFilterItems = this.tempHotFilterItems.filter(
                (s) => s == value
            );
        } else {
            this.multiselect.toggle(false);
        }
    }
    handleMfgApprovedFilter(value) {
        if (value.length >= 0) {
            this.mfgApprovedFilterItems =
                this.tempMfgApprovedFilterItems.filter((s) => s == value);
        } else {
            this.multiselect.toggle(false);
        }
    }
    handlePartNumberFilter(value) {
        if (value.length >= 0) {
            this.partNumberItems = this.tempPartNumberFilterItems.filter(
                (s) => s?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
            );
        } else {
            this.multiselect.toggle(false);
        }
    }
    onSearchFilter() {
        const filter: CompositeFilterDescriptor = { filters: [], logic: "and" };
        if (this.searchText && this.searchText.length > 0) {
            const data1 = [
                {
                    field: "productionOrderNum",
                    operator: "contains",
                    value: this.searchText,
                },
                {
                    field: "partNumber",
                    operator: "contains",
                    value: this.searchText,
                },
            ];
            filter.filters.push({ filters: [...data1], logic: "or" });
        }
        if (
            this.ca10ShortageFreeFilterValue &&
            this.ca10ShortageFreeFilterValue.length > 0
        ) {
            const data2: any[] = [];
            this.ca10ShortageFreeFilterValue.forEach((item) => {
                data2.push({
                    field: "cA10ShortageFree",
                    operator: "equals",
                    value: item,
                });
            });
            filter.filters.push({ filters: [...data2], logic: "or" });
        }
        if (
            this.requestDateFilterDataValue &&
            this.requestDateFilterDataValue.length > 0
        ) {
            const data3: any[] = [];
            this.requestDateFilterDataValue.forEach((item) => {
                data3.push({
                    field: "crd",
                    operator: "contains",
                    value: item,
                });
            });
            filter.filters.push({ filters: [...data3], logic: "or" });
        }
        if (this.hotFilterValue && this.hotFilterValue.length > 0) {
            const data4: any[] = [];
            this.hotFilterValue.forEach((item) => {
                data4.push({
                    field: "hot",
                    operator: "equals",
                    value: item,
                });
            });
            filter.filters.push({ filters: [...data4], logic: "or" });
        }
        if (
            this.mfgApprovedFilterValue &&
            this.mfgApprovedFilterValue.length > 0
        ) {
            const data5: any[] = [];
            this.mfgApprovedFilterValue.forEach((item) => {
                data5.push({
                    field: "mfgApproved",
                    operator: "equals",
                    value: item,
                });
            });
            filter.filters.push({ filters: [...data5], logic: "or" });
        }
        if (
            this.partNumberFilterValue &&
            this.partNumberFilterValue.length > 0
        ) {
            const data6: any[] = [];
            this.partNumberFilterValue.forEach((item) => {
                data6.push({
                    field: "partNumber",
                    operator: "contains",
                    value: item,
                });
            });
            filter.filters.push({ filters: [...data6], logic: "or" });
        }
        this.filter = filter;
        this.specialSubassemblyGridData = filterBy(
            this.tempSpecialSubassemblyGridData,
            filter
        );
    }
    public showTooltip(e: MouseEvent): void {
        this.changeDetector.detectChanges();
        const element = e.target as HTMLElement;
        if (element.innerText === "Total Labor Hrs") {
            this.msg =
                "Total labor hours = subassembly hours + integration hours (default 0) + test hours + post-test hours (defaults to 1)";
            this.tooltipDir.toggle(element);
        } else {
            this.tooltipDir.hide();
        }
    }

    navigateToSOELink(soeLink: string) {
        window.open(soeLink, "_blank");
    }
}
