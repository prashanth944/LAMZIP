export class SpecialSubassembly {
    plantId: number;
    hot: boolean;
    pcwoReleased: boolean;
    cA10ShortageFree: boolean;
    dateDelivered: string;
    mfgApproved: boolean;
    pcfsAuditedBy: string;
    qty: number;
    plannerName: string;
    partNumber: string;
    description: string;
    subassemblyBuildHours: number;
    subassemblyTechnician: number;
    subassemblyBays: number;
    testBuildHours: number;
    testTechnician: number;
    testBays: number;
    totalLaborHour: number;
    materialReadiness: string;
    crd: string;
    commitLaunch: string;
    committedTestStart: string;
    commitedManufacturingComplete: string;
    pilotCommit: string;
    assemblyTechnicianName: string;
    testTechnicianName: string;
    mrpDemand: string;
    capacityPlanningColor: string;
    note: string;
    createdDate: string;
    modifiedDate: string;
    pilotProductID: number;

    auditor: string;
    engineeringPOC: string;
    estimatedBuildTime: number;
    estimatedTestTime: number;
    kitReceivedDate: string;
    mrpDemandID: number;
    pcfsShortageFreeAudit: boolean;
    pilotMEApproved: boolean;
    rework: boolean;
    serialNum: string;
    soeLink: string;
    spclProcess: boolean;
    specialSubAssyType: string;

    techBuild: string;
    techTest: string;

    assemblySerialNumber: string;
    actualTestStart: string;
    actualTestComplete: string;
    inShipping: boolean;
    productionOrderNum: string;
}
