import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { environment } from "../../../../../environments/environment.dev_server";
import { routes } from "../models/route";
import { ModuleGrid } from "../models/moduleGrid";

@Injectable({
    providedIn: "root",
})
export class AdjustModuleService {
    constructor(private http: HttpClient) {}

    // HttpClient API get() method => get bay summary
    getModule(plantID): Observable<ModuleGrid[]> {
        return new Observable<ModuleGrid[]>((observer) => {
            this.http
                .get<ModuleGrid[]>(
                    `${environment.apiUrl}${routes.getModule}` +
                        "?plantID=" +
                        plantID
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    getBuildTypeDDL(plantId): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(
                    `${environment.apiUrl}${routes.getBuildTypeDDL}` +
                        "?plantID=" +
                        plantId
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    getBuildStyleDDL(): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(`${environment.apiUrl}${routes.getBuildStyleDDL}`)
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    getBuildStyleDDLForAddPOPUp(): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(
                    `${environment.apiUrl}${routes.getBuildStyleDDLForAddPOPUp}`
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    getBuildScheduleDDL(): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(
                    `${environment.apiUrl}${routes.getBuildScheduleDDL}`
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    getAssosiatedBENDDL(plantId): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(
                    `${environment.apiUrl}${routes.getAssosiatedBENDDL}` +
                        "?PlantID=" +
                        plantId
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    getModuleToolType(plantID): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(
                    `${environment.apiUrl}${routes.getModuleToolType}` +
                        "?plantID=" +
                        plantID
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    getToolTypeDDL(plantID): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(
                    `${environment.apiUrl}${routes.getToolTypeDDL}` +
                        "?plantID=" +
                        plantID
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    getModuleColorDDL(): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(`${environment.apiUrl}${routes.getModuleColorDDL}`)
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    addModules(addModuleObj): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .post<any>(
                    `${environment.apiUrl}${routes.addModules}`,
                    addModuleObj
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    // HttpClient API put() method => Update Modules
    updateModules(updateModuleObj): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .put<any>(
                    `${environment.apiUrl}${routes.updateModules}`,
                    updateModuleObj
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    // HttpClient API put() method => Update Tool Type
    updateToolType(updateToolTypeObj): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .put<any>(
                    `${environment.apiUrl}${routes.updateToolType}`,
                    updateToolTypeObj
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    //special subassembly
    getSpecialSubAssySummary(
        plantID,
        SubassemblyType,
        PilotProductId
    ): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .get<any>(
                    `${environment.apiUrl}${routes.getSpecialSubAssySummary}` +
                        "?plantID=" +
                        plantID +
                        "&SubassemblyType=" +
                        SubassemblyType +
                        "&PilotProductId=" +
                        PilotProductId
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    getMRPDemand(): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(`${environment.apiUrl}${routes.getMRPDemand}`)
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    addEditSpecialSubAssy(addSpecialSubAssyObj): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .post<any>(
                    `${environment.apiUrl}${routes.addEditSpecialSubAssy}`,
                    addSpecialSubAssyObj
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    getpsnbenexists(plantID, psnben): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .get<any>(
                    `${environment.apiUrl}${routes.getpsnbenexists}` +
                        plantID +
                        "/" +
                        psnben
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    getOtherSAPModule(plantID): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .get<any>(
                    `${environment.apiUrl}${routes.getOtherSAPModule}` + plantID
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    GetOtherSAPModuleSearch(plantID, searchText): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .get<any>(
                    `${environment.apiUrl}${routes.getOtherSAPModuleSearch}` +
                        plantID +
                        "/" +
                        searchText
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    addOtherSAPModule(addOtherSapModuleObj): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .post<any>(
                    `${environment.apiUrl}${routes.addOtherSAPModule}`,
                    addOtherSapModuleObj
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    getDemandRequirements(pilotProductID: number): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .get<any>(
                    `${environment.apiUrl}${routes.getDemandRequirements}` +
                        pilotProductID
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    updateDemandRequirements(
        pilotProductID: number,
        data: any
    ): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .put<any>(
                    `${environment.apiUrl}${routes.updateDemandRequirements}` +
                        pilotProductID,
                    data
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

  getAddPO(POValue: string): Observable<any> {
      return new Observable<any>((observer) => {
            this.http
              .get(
                `${environment.apiUrl}${routes.getAddPO}` + POValue , { responseType: 'text' }
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    getDeletePO(POValue: string): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
              .get(
                `${environment.apiUrl}${routes.getDeletePO}` + POValue , { responseType: 'text' }
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    public handleError(error) {
        let errorMessage = "";
        if (error.error instanceof ErrorEvent) {
            // Get client-side error
            errorMessage = error.error.message;
        } else {
            // Get server-side error
            errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }
        return throwError(errorMessage);
    }
}
