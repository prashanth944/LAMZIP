import {
  Component,
  OnInit,
  ViewEncapsulation,
  ViewChild,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  ViewContainerRef,
  ViewChildren,
} from "@angular/core";
import { FormBuilder } from "@angular/forms";
import {
  distinct,
  CompositeFilterDescriptor,
  filterBy,
  State,
} from "@progress/kendo-data-query";
import { EditService } from "../../../service/edit.service";
import { AppStoreService } from "../../../../core/app-store.service";
import { AdjustModuleService } from "../adjust-module-service/adjustModule.service";
import { Plant } from "../../../../core/model/user.model";
import { SpecialSubassembly } from "../models/specialSubassembly";
import { NotificationService } from "@progress/kendo-angular-notification";
import { MultiSelectComponent } from "@progress/kendo-angular-dropdowns";
import { TooltipDirective } from "@progress/kendo-angular-tooltip";
import { OtherSAPModules } from "../models/OtherSAPModules";
import { AddToTracking } from "../models/addToTracking";
import { DataBindingDirective } from "@progress/kendo-angular-grid";

@Component({
  selector: "pmpm-other-sap-modules",
  templateUrl: "./other-sap-modules.component.html",
  styleUrls: ["./other-sap-modules.component.css"],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OtherSapModulesComponent implements OnInit {
  @ViewChildren(DataBindingDirective)
  public dataBinding: DataBindingDirective[];
  @ViewChild("appendTo", { read: ViewContainerRef })
  public appendTo: ViewContainerRef;
  @ViewChild("multiselect") public multiselect: MultiSelectComponent;
  @ViewChild(TooltipDirective) public tooltipDir: TooltipDirective;

  site: Plant;

  specialSubassemblyGridData: SpecialSubassembly[] = [];
  tempSpecialSubassemblyGridData: SpecialSubassembly[] = [];

  otherSAPModulesGridData: OtherSAPModules[] = [];
  tempOtherSAPModulesGridData: OtherSAPModules[] = [];
  currDataItem: OtherSAPModules;

  msg: string;
  addOpened = false;
  loadTable = true;

  public gridState: State = {
    skip: 0,
    take: 50,
    // Initial filter descriptor
    filter: {
      logic: "and",
      filters: [],
    },
  };
  public searchText = "";
  public filter: CompositeFilterDescriptor;

  constructor(
    private formBuilder: FormBuilder,
    public editService: EditService,
    private appStoreService: AppStoreService,
    private adjustModuleService: AdjustModuleService,
    private notificationService: NotificationService,
    private changeDetector: ChangeDetectorRef
  ) { }

  public ngOnInit(): void {
    this.loadTable = true;
    this.appStoreService.getCurrentSite().subscribe((site) => {
      if (site) {
        this.site = {
          plantName: site.plantName,
          plantId: site.plantId,
        };
        this.fillOtherSAPModulesGrid();
      }
    });
  }

  fillOtherSAPModulesGrid() {
    this.loadTable = true;
    this.adjustModuleService
      .getOtherSAPModule(this.site?.plantId)
      .subscribe((res) => {
        if (res) {
          this.otherSAPModulesGridData = res;
        }
        this.tempOtherSAPModulesGridData = [
          ...this.otherSAPModulesGridData,
        ];
        this.loadTable = false;
        this.changeDetector.detectChanges();
      });
  }
  addToTracking(dataItem: OtherSAPModules) {
    this.addOpened = true;
    this.currDataItem = dataItem;
  }

  onYesClick() {
    const dataItem = this.currDataItem;
    const addToTrackingObj: AddToTracking = {
      PlantID: this.site?.plantId,
      ProductGroupID: dataItem.productGroupID,
      ProductGroupName: dataItem.productGroupName,
      ToolTypeID: dataItem.toolTypeID,
      FCID: dataItem.fcid,
      BEN: dataItem.ben,
      RecordType: dataItem.recordType,
      RevenueType: dataItem.revenueCode,
      CRD: dataItem.crd,
      TSD: dataItem.tsd,
      SRD: dataItem.srd,
      MCSD: dataItem.mcsd,
      LPRID: dataItem.lprid,
    };
    this.loadTable = true;
    this.closeAdd();
    this.adjustModuleService
      .addOtherSAPModule(addToTrackingObj)
      .subscribe((res) => {
        if (res) {
          this.fillOtherSAPModulesGrid();
          this.showSuccess();
        }
      });
  }
  closeAdd() {
    this.addOpened = false;
  }
  public showSuccess(): void {
    this.notificationService.show({
      appendTo: this.appendTo,
      content: "Added Successfully",
      position: { horizontal: "left", vertical: "bottom" },
      animation: { type: "fade", duration: 600 },
      type: { style: "success", icon: true },
    });
  }
  onSearchFilter() {
    this.loadTable = true;
    if (
      this.searchText == null ||
      this.searchText == "" ||
      this.searchText == undefined
    ) {
      this.fillOtherSAPModulesGrid();
    } else {
      this.adjustModuleService
        .GetOtherSAPModuleSearch(this.site?.plantId, this.searchText)
        .subscribe((res) => {
          if (res) {
            this.otherSAPModulesGridData = [...res];
          }
          this.loadTable = false;
          this.tempOtherSAPModulesGridData = [
            ...this.otherSAPModulesGridData,
          ];
          Array.from(this.dataBinding)[0].skip = 0;
        });
    }
  }

  public distinctPrimitiveFilter(fieldName: string): any {
    const data: any = distinct(this.otherSAPModulesGridData, fieldName)
      .map((item) => item[fieldName])
      .map((val) => ({ text: val, value: val }));
    data.forEach((item) => {
      if (item.value === "") item.text = "BLANK";
      else if (item.value === null) {
        item.text = "NULL";
      }
    });
    data.sort(function (a, b) {
      const textA = a?.text.toUpperCase();
      const textB = b?.text.toUpperCase();
      return textA < textB ? -1 : textA > textB ? 1 : 0;
    });
    return data;
  }
  public filterChange(filter: CompositeFilterDescriptor): void {
    this.filter = filter;
    this.otherSAPModulesGridData = filterBy(
      this.tempOtherSAPModulesGridData,
      filter
    );
  }
}
