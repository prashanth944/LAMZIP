export interface toolTypeGrid {
    Id: number;
    ToolType: string;
    SubassemblyId: number;
    SubassemblyBays: number;
    SubassemblyHours: number;
    SubassemblyTechs: number;
    IntegrationId: number;
    IntegrationBays: number;
    IntegrationHours: number;
    IntegrationTechs: number;
    TestId: number;
    TestBays: number;
    TestHours: number;
    TestTechs: number;
    PostTestId: number;
    PostTestBays: number;
    PostTestHours: number;
    PostTestTechs: number;
    TotalLH: number;
    TransitionDate: string;
    POABOMReleaseDate: string;
    LastUpdated: string;
    UpdatedBy: string;
}
