"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addModule = void 0;
var addModule = /** @class */ (function () {
    function addModule() {
        this.baysRequiredForSubAssembly = 0;
        this.baysRequiredForIntegration = 0;
        this.baysRequiredForTest = 0;
        this.baysRequiredForPostTest = 0;
    }
    return addModule;
}());
exports.addModule = addModule;
//# sourceMappingURL=add-module.js.map