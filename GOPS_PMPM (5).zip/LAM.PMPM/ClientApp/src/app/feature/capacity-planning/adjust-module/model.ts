export class Product {
    public ProductID: number | undefined;
    public ProductName = "";
    public Discontinued = false;
    public UnitsInStock: number | undefined;
    public UnitPrice = 0;
}

export interface Item {
    text: string;
    value: string;
}

export class AdjustModule {
    public Status: string;
    public FCID: string;
    public PilotSerialNumber: string;
    public BuildStyle: string;
    public BuildSchedule: string;
    public NoCapacity: boolean;
    public RecordType: string;
    public RevenueType: string;
    public ToolType: string;
    public ProductType: string;
    public BuildType: string;
    public AssyBaysNeeded: string;
    public AssyHrs: string;
    public IntBaysNeeded: string;
    public IntHrs: string;
    public TestBaysNeeded: string;
    public TestHrs: string;
    public PostTestBaysNeeded: string;
    public PostTestHrs: string;
    public TotalLaborHrs: string;
    public MaterialReadiness: Date;
    public BOM: Date;
    public TranisitionDate: Date;
    public Launch: Date;
    public Integration: Date;
    public TestStart: Date;
    public MfgComplete: Date;
    public TSD: Date;
    public MCSD: Date;
    public CRD: Date;
    public CRDGap: Date;
    public CRDEsc: Date;
    public SRD: Date;

    public Color: string;
    public Notes: string;
}
