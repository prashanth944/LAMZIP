export const routes = {
    getModule: "/Modules/GetModule",
    getBuildTypeDDL: "/Modules/GetBuildTypeDDL",
    getBuildStyleDDL: "/Modules/GetBuildStyleDDL",
    getBuildStyleDDLForAddPOPUp: "/Modules/GetBuildStyleDDLForAddPOPUp",
    getBuildScheduleDDL: "/Modules/GetBuildScheduleDDL",
    getAssosiatedBENDDL: "/Modules/GetAssosiatedBENDDL",
    getModuleToolType: "/Modules/GetModuleToolType",
    getToolTypeDDL: "/Bays/GetToolType",
    getModuleColorDDL: "/Modules/GetModuleColorDDL",
    addModules: "/Modules/AddModules",
    updateModules: "/Modules/UpdateModule",
    updateToolType: "/Modules/UpdateToolType",

    getSpecialSubAssySummary: "/Modules/GetSpecialSubAssySummary",
    getMRPDemand: "/Modules/GetMRPDemand",
    addEditSpecialSubAssy: "/Modules/AddEditSpecialSubAssy",
    getpsnbenexists: "/Modules/getpsnbenexists/",
    getOtherSAPModule: "/Modules/GetOtherSAPModule/",
    addOtherSAPModule: "/Modules/AddOtherSAPModule/",
    getOtherSAPModuleSearch: "/Modules/GetOtherSAPModuleSearch/",

    getDemandRequirements: "/Modules/getmoduledemand/",
    updateDemandRequirements: "/Modules/updatemoduledemand/",

    getAddPO: "/Modules/GetAddPO/",
    getDeletePO: "/Modules/GetDeletePO/",
};
