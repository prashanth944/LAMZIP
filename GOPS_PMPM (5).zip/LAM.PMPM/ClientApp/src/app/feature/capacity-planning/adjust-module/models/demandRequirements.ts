export interface DemandRequirements {
    Process: string;
    CalenderDays: number;
    LaborHours: number;
    Bays: number;
    Techs: number;
}
