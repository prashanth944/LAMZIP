export interface UpdateToolType {
    toolTypeID: number;
    moduleProcessID: number;
    toolTypeName: string;
    moduleProcess: string;
    bayRequired: number;
    hourRequired: number;
    technicianRequired: number;
    transitionDate: string;
    poabomReleaseDate: string;
}
