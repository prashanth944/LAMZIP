export class FilterItem {
    filterValues: string;
    filterType: string;
}
