export class addModule {
    BuildStyleId: number | undefined;
    BuildScheduleId: number | undefined;
    BuildTypeID: number | undefined;
    ToolTypeID: number | undefined;
    FCID: string;
    PilotSerialNumber: string;
    BEN: string;
    CurrentPartNumber: string;
    NewPartNumber: string;
    ReworkPO: string;
    AssociatedBEN: string;
    AssociatedPSN: string;
    ProductGroupID: number | undefined; //Product type
    CommitLaunch: string;
    POM: string;
    CRD: string;
    POR: string;

    BuildingID: number;
    CapacityPlanningColor: string;

    BaysRequiredSubassembly: number | undefined;
    TotalAssemblyHours: number | undefined;
    TechnicianRequiredSubassembly: number | undefined;

    BaysRequiredIntegration: number | undefined;
    TotalIntegrationHours: number | undefined;
    TechnicianRequiredIntegration: number | undefined;

    BaysRequiredForTest: number | undefined;
    TotalTestHours: number | undefined;
    TechnicianRequiredTest: number | undefined;

    BaysRequiredPostTest: number | undefined;
    TotalPostTestHours: number | undefined;
    TechnicianRequiredPostTest: number | undefined;

    ModuleProcessSubassembly: string;
    ModuleProcessIntegration: string;
    ModuleProcessTest: string;
    ModuleProcessPostTest: string;

    RecordType: string;
    RevenueType: string;
    PlantID: number;

    ProductionOrderNum: string;
    AddPO: string;
    DeletePO: string;
    BENorPSNReconfiguredFrom: string;
    modifiedBy: number;
    modifiedOn: Date;
}
