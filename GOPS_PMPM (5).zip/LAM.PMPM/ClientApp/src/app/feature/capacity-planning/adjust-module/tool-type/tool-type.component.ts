import {
    Component,
    EventEmitter,
    Input,
    OnChanges,
    OnInit,
    Output,
    SimpleChanges,
    ViewChild,
    ViewContainerRef,
    ViewEncapsulation,
} from "@angular/core";
import { AppStoreService } from "../../../../core/app-store.service";
import { role, uiScreen } from "../../../../core/model/common.constant";
import { toolTypeGrid } from "../models/toolTypeGrid";
import {
    State,
    CompositeFilterDescriptor,
    filterBy,
} from "@progress/kendo-data-query";
import { AdjustModuleService } from "../adjust-module-service/adjustModule.service";
import { Plant } from "../../../../core/model/user.model";
import * as moment from "moment";
import { FormBuilder, FormGroup } from "@angular/forms";
import { EditService } from "../../../service/edit.service";
import { UpdateToolType } from "../models/updateToolType";
import { NotificationService } from "@progress/kendo-angular-notification";
import { DataBindingDirective } from "@progress/kendo-angular-grid";
@Component({
    selector: "pmpm-tool-type",
    templateUrl: "./tool-type.component.html",
    styleUrls: ["./tool-type.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class ToolTypeComponent implements OnInit, OnChanges {
    @ViewChild(DataBindingDirective) dataBinding: DataBindingDirective;
    @ViewChild("appendTo", { read: ViewContainerRef })
    public appendTo: ViewContainerRef;
    @Input() site: Plant;
    @Input() toolTypeGridData: toolTypeGrid[] = [];
    @Input() searchToolTypeValue = "";
    @Output() searchText: EventEmitter<string> = new EventEmitter<string>();
    toolTypeGridData2: toolTypeGrid[] = [];
    isUserAccess = false;
    canEditModuleReworkAndToolType = false;
    canViewAdjustModule = false;
    gridFilteredToolData: any[] = [];
    loadTableTT = true;
    public gridState: State = {
        skip: 0,
        take: 50,
    };
    public take = 50;
    public skip = 0;

    showttErrMsg = false;
    ttValidationErrMsg = "";
    updateToolTypeObj: UpdateToolType[] = [];
    constructor(
        private appStoreService: AppStoreService,
        private adjustModuleService: AdjustModuleService,
        private formBuilder: FormBuilder,
        private editService: EditService,
        private notificationService: NotificationService
    ) {}
    public ngOnInit(): void {
        this.canEditModuleReworkAndToolType = false;
        this.canViewAdjustModule = false;
        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.ModifyModule)
                    .subscribe((result) => {
                        this.canViewAdjustModule = result;
                        if (
                            !res.includes(role.Technician) &&
                            !res.includes(role.PassTeamMember)
                        )
                            this.isUserAccess = true;
                        if (
                            res.includes(role.Manager) ||
                            res.includes(role.SuperUser)
                        )
                            this.canEditModuleReworkAndToolType = true;
                    });
            }
        });
    }
    ngOnChanges(changes: SimpleChanges) {
        if (
            changes["searchToolTypeValue"] &&
            changes["searchToolTypeValue"] !== null &&
            changes["searchToolTypeValue"].currentValue
        ) {
            this.searchToolTypeValue =
                changes["searchToolTypeValue"].currentValue;
        }
        if (
            changes["toolTypeGridData"] &&
            changes["toolTypeGridData"] !== null &&
            changes["toolTypeGridData"].currentValue
        ) {
            this.toolTypeGridData = changes["toolTypeGridData"].currentValue;
            this.gridFilteredToolData = JSON.parse(
                JSON.stringify(this.toolTypeGridData)
            );
            this.toolTypeGridData2 = JSON.parse(
                JSON.stringify(this.toolTypeGridData)
            );
            if (
                this.searchToolTypeValue !== null &&
                this.searchToolTypeValue !== "" &&
                this.searchToolTypeValue !== undefined
            ) {
                this.onSearchFilterToolType();
            }
            this.loadTableTT = false;
        }
    }
    public getValue(event: Event): string {
        this.searchToolTypeValue = (
            event.target as HTMLInputElement
        ).value.toString();
        return (event.target as HTMLInputElement).value;
    }
    public onSearchFilterToolType() {
        const filter: CompositeFilterDescriptor = { filters: [], logic: "and" };
        if (this.searchToolTypeValue && this.searchToolTypeValue.length > 0) {
            const data1 = [
                {
                    field: "ToolType",
                    operator: "contains",
                    value: this.searchToolTypeValue,
                },
            ];
            filter.filters.push({ filters: [...data1], logic: "or" });
        }
        this.toolTypeGridData = filterBy(this.gridFilteredToolData, filter);
        if (this.dataBinding) this.dataBinding.skip = 0;
        this.searchText.emit(this.searchToolTypeValue);
    }
    public onStateChangeToolType(state: State) {}
    public cellClickHandlerToolType({
        sender,
        rowIndex,
        columnIndex,
        dataItem,
        isEdited,
    }: any) {
        if (!isEdited) {
            sender.editCell(
                rowIndex,
                columnIndex,
                this.createFormGroupToolType(dataItem)
            );
        }
    }
    public createFormGroupToolType(dataItem: any): FormGroup {
        return this.formBuilder.group({
            ToolType: dataItem.ToolType,
            SubassemblyBays: dataItem.SubassemblyBays,
            SubassemblyHours: dataItem.SubassemblyHours,
            SubassemblyTechs: dataItem.SubassemblyTechs,
            IntegrationBays: dataItem.IntegrationBays,
            IntegrationHours: dataItem.IntegrationHours,
            IntegrationTechs: dataItem.IntegrationTechs,
            TestBays: dataItem.TestBays,
            TestHours: dataItem.TestHours,
            TestTechs: dataItem.TestTechs,
            PostTestBays: dataItem.PostTestBays,
            PostTestHours: dataItem.PostTestHours,
            PostTestTechs: dataItem.PostTestTechs,
            TotalLH: dataItem.TotalLH,
            TransitionDate: dataItem.TransitionDate,
            POABOMReleaseDate: dataItem.POABOMReleaseDate,
            LastUpdated: dataItem.LastUpdated,
            UpdatedBy: dataItem.UpdatedBy,
        });
    }
    public cellCloseHandlerToolType(args: any) {
        const { formGroup, dataItem } = args;
        if (!formGroup.valid) {
            // prevent closing the edited cell if there are invalid values.
            args.preventDefault();
        } else if (formGroup.dirty) {
            formGroup.value.TotalLH =
                formGroup.value.SubassemblyHours +
                formGroup.value.IntegrationHours +
                formGroup.value.TestHours +
                formGroup.value.PostTestHours;
            this.checkToolTypeValidation(args.column.field, formGroup.value);
            if (!this.showttErrMsg) {
                this.editService.assignValues(dataItem, formGroup.value);
                this.editService.update(dataItem, "Tool Type");
            }
        } else {
            this.editService.update(dataItem, "Tool Type");
        }
    }
    checkToolTypeValidation(column, formGrp) {
        if (column === "SubassemblyBays") {
            if (
                formGrp.SubassemblyBays < 0 ||
                formGrp.SubassemblyBays > 9 ||
                formGrp.SubassemblyBays % 1 !== 0
            ) {
                this.showttErrMsg = true;
                this.ttValidationErrMsg =
                    "(*)Please enter Integer values for Subassembly between 0 and 9";
            } else {
                this.showttErrMsg = false;
                this.ttValidationErrMsg = "";
            }
        } else if (column === "SubassemblyTechs") {
            if (
                formGrp.SubassemblyTechs < 0 ||
                formGrp.SubassemblyTechs > 9 ||
                formGrp.SubassemblyTechs % 1 !== 0
            ) {
                this.showttErrMsg = true;
                this.ttValidationErrMsg =
                    "(*)Please enter Integer values for Subassembly Techs between 0 and 9";
            } else {
                this.showttErrMsg = false;
                this.ttValidationErrMsg = "";
            }
        } else if (column === "IntegrationBays") {
            if (
                formGrp.IntegrationBays < 0 ||
                formGrp.IntegrationBays > 9 ||
                formGrp.IntegrationBays % 1 !== 0
            ) {
                this.showttErrMsg = true;
                this.ttValidationErrMsg =
                    "(*)Please enter Integer values for Integration Bays between 0 and 9";
            } else {
                this.showttErrMsg = false;
                this.ttValidationErrMsg = "";
            }
        } else if (column === "IntegrationTechs") {
            if (
                formGrp.IntegrationTechs < 0 ||
                formGrp.IntegrationTechs > 9 ||
                formGrp.IntegrationTechs % 1 !== 0
            ) {
                this.showttErrMsg = true;
                this.ttValidationErrMsg =
                    "(*)Please enter Integer values for Integration Techs between 0 and 9";
            } else {
                this.showttErrMsg = false;
                this.ttValidationErrMsg = "";
            }
        } else if (column === "TestBays") {
            if (
                formGrp.TestBays < 0 ||
                formGrp.TestBays > 9 ||
                formGrp.TestBays % 1 !== 0
            ) {
                this.showttErrMsg = true;
                this.ttValidationErrMsg =
                    "(*)Please enter Integer values for Test Bays between 0 and 9";
            } else {
                this.showttErrMsg = false;
                this.ttValidationErrMsg = "";
            }
        } else if (column === "TestTechs") {
            if (
                formGrp.TestTechs < 0 ||
                formGrp.TestTechs > 9 ||
                formGrp.TestTechs % 1 !== 0
            ) {
                this.showttErrMsg = true;
                this.ttValidationErrMsg =
                    "(*)Please enter Integer values for Test Techs between 0 and 9";
            } else {
                this.showttErrMsg = false;
                this.ttValidationErrMsg = "";
            }
        } else if (column === "PostTestBays") {
            if (
                formGrp.PostTestBays < 0 ||
                formGrp.PostTestBays > 9 ||
                formGrp.PostTestBays % 1 !== 0
            ) {
                this.showttErrMsg = true;
                this.ttValidationErrMsg =
                    "(*)Please enter Integer values for PostTest Bays between 0 and 9";
            } else {
                this.showttErrMsg = false;
                this.ttValidationErrMsg = "";
            }
        } else if (column === "PostTestTechs") {
            if (
                formGrp.PostTestTechs < 0 ||
                formGrp.PostTestTechs > 9 ||
                formGrp.PostTestTechs % 1 !== 0
            ) {
                this.showttErrMsg = true;
                this.ttValidationErrMsg =
                    "(*)Please enter Integer values for PostTest Techs between 0 and 9";
            } else {
                this.showttErrMsg = false;
                this.ttValidationErrMsg = "";
            }
        } else if (column === "SubassemblyHours") {
            if (
                formGrp.SubassemblyHours < 0 ||
                formGrp.SubassemblyHours > 9999 ||
                formGrp.SubassemblyHours % 1 !== 0
            ) {
                this.showttErrMsg = true;
                this.ttValidationErrMsg =
                    "(*)Please enter Integer values for Subassembly Hours between 0 and 9999";
            } else {
                this.showttErrMsg = false;
                this.ttValidationErrMsg = "";
            }
        } else if (column === "IntegrationHours") {
            if (
                formGrp.IntegrationHours < 0 ||
                formGrp.IntegrationHours > 9999 ||
                formGrp.IntegrationHours % 1 !== 0
            ) {
                this.showttErrMsg = true;
                this.ttValidationErrMsg =
                    "(*)Please enter Integer values for Integration Hours between 0 and 9999";
            } else {
                this.showttErrMsg = false;
                this.ttValidationErrMsg = "";
            }
        } else if (column === "TestHours") {
            if (
                formGrp.TestHours < 0 ||
                formGrp.TestHours > 9999 ||
                formGrp.TestHours % 1 !== 0
            ) {
                this.showttErrMsg = true;
                this.ttValidationErrMsg =
                    "(*)Please enter Integer values for Test Hours between 0 and 9999";
            } else {
                this.showttErrMsg = false;
                this.ttValidationErrMsg = "";
            }
        } else if (column === "PostTestHours") {
            if (
                formGrp.PostTestHours < 0 ||
                formGrp.PostTestHours > 9999 ||
                formGrp.PostTestHours % 1 !== 0
            ) {
                this.showttErrMsg = true;
                this.ttValidationErrMsg =
                    "(*)Please enter Integer values for PostTest Hours between 0 and 9999";
            } else {
                this.showttErrMsg = false;
                this.ttValidationErrMsg = "";
            }
        }
    }
    public cancelHandlerToolType({ sender, rowIndex }: any) {
        sender.closeRow(rowIndex);
    }
    public saveHandlerToolType({ sender, formGroup, rowIndex }: any) {
        if (formGroup.valid) {
            this.editService.create(formGroup.value);
            sender.closeRow(rowIndex);
        }
    }
    public removeHandlerToolType({ sender, dataItem }: any) {
        this.editService.remove(dataItem);
        sender.cancelCell();
    }
    public saveChangesToolType(grid: any): void {
        grid.closeCell();
        grid.cancelCell();
        const abc = this.editService.saveChanges();
        this.updateToolTypeObj = [];
        abc[0].forEach((val) => {
            const updateToolTypeSubassembly: UpdateToolType = {
                toolTypeID: val.Id,
                moduleProcessID:
                    val.SubassemblyId !== null ? val.SubassemblyId : 6,
                toolTypeName: val.ToolType,
                moduleProcess: "Subassembly",
                bayRequired: val.SubassemblyBays,
                hourRequired: val.SubassemblyHours,
                technicianRequired: val.SubassemblyTechs,
                transitionDate:
                    val.TransitionDate !== null
                        ? moment(val.TransitionDate).format("yyyy-MM-DD")
                        : null,
                poabomReleaseDate:
                    val.POABOMReleaseDate !== null
                        ? moment(val.POABOMReleaseDate).format("yyyy-MM-DD")
                        : null,
            };
            this.updateToolTypeObj.push(updateToolTypeSubassembly);
            const updateToolTypeIntegration: UpdateToolType = {
                toolTypeID: val.Id,
                moduleProcessID:
                    val.IntegrationId !== null ? val.IntegrationId : 7,
                toolTypeName: val.ToolType,
                moduleProcess: "Integration",
                bayRequired: val.IntegrationBays,
                hourRequired: val.IntegrationHours,
                technicianRequired: val.IntegrationTechs,
                transitionDate:
                    val.TransitionDate !== null
                        ? moment(val.TransitionDate).format("yyyy-MM-DD")
                        : null,
                poabomReleaseDate:
                    val.POABOMReleaseDate !== null
                        ? moment(val.POABOMReleaseDate).format("yyyy-MM-DD")
                        : null,
            };
            this.updateToolTypeObj.push(updateToolTypeIntegration);
            const updateToolTypeTest: UpdateToolType = {
                toolTypeID: val.Id,
                moduleProcessID: val.TestId !== null ? val.TestId : 8,
                toolTypeName: val.ToolType,
                moduleProcess: "Test",
                bayRequired: val.TestBays,
                hourRequired: val.TestHours,
                technicianRequired: val.TestTechs,
                transitionDate:
                    val.TransitionDate !== null
                        ? moment(val.TransitionDate).format("yyyy-MM-DD")
                        : null,
                poabomReleaseDate:
                    val.POABOMReleaseDate !== null
                        ? moment(val.POABOMReleaseDate).format("yyyy-MM-DD")
                        : null,
            };
            this.updateToolTypeObj.push(updateToolTypeTest);
            const updateToolTypePostTest: UpdateToolType = {
                toolTypeID: val.Id,
                moduleProcessID: val.PostTestId !== null ? val.PostTestId : 9,
                toolTypeName: val.ToolType,
                moduleProcess: "Post-test",
                bayRequired: val.PostTestBays,
                hourRequired: val.PostTestHours,
                technicianRequired: val.PostTestTechs,
                transitionDate:
                    val.TransitionDate !== null
                        ? moment(val.TransitionDate).format("yyyy-MM-DD")
                        : null,
                poabomReleaseDate:
                    val.POABOMReleaseDate !== null
                        ? moment(val.POABOMReleaseDate).format("yyyy-MM-DD")
                        : null,
            };
            this.updateToolTypeObj.push(updateToolTypePostTest);
        });
        this.adjustModuleService
            .updateToolType(this.updateToolTypeObj)
            .subscribe((res) => {
                this.showSuccess("Saved");
            });
    }
    public showSuccess(msg: string): void {
        this.notificationService.show({
            appendTo: this.appendTo,
            content: msg,
            position: { horizontal: "left", vertical: "bottom" },
            animation: { type: "fade", duration: 600 },
            type: { style: "success", icon: true },
        });
    }
    public cancelChangesToolType(grid: any): void {
        this.toolTypeGridData = JSON.parse(
            JSON.stringify(this.toolTypeGridData2)
        );
    }
    //tool type dates
    onChangeTransitionDateTT(value: Date, dataItem: any) {
        dataItem.TransitionDate = moment(value).format("M-D-YY");
        if (
            parseInt(dataItem.TransitionDate.split("-")[2]) > 99 ||
            parseInt(dataItem.TransitionDate.split("-")[2]) < 0
        ) {
            dataItem.TransitionDate = null;
        }
        this.createFormGroupToolType(dataItem);
    }
    onChangePOABOMReleaseDateTT(value: Date, dataItem: any) {
        dataItem.POABOMReleaseDate = moment(value).format("M-D-YY");
        if (
            parseInt(dataItem.POABOMReleaseDate.split("-")[2]) > 99 ||
            parseInt(dataItem.POABOMReleaseDate.split("-")[2]) < 0
        ) {
            dataItem.POABOMReleaseDate = null;
        }
        this.createFormGroupToolType(dataItem);
    }
}
