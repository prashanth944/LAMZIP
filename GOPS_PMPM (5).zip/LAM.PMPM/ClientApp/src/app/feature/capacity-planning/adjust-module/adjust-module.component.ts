import {
  Component,
  OnInit,
  ViewChild,
  ViewChildren,
  ViewContainerRef,
  ViewEncapsulation,
} from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ExcelExportData } from "@progress/kendo-angular-excel-export";
import {
  DataBindingDirective,
  GridComponent,
  GridDataResult,
  RowClassArgs,
} from "@progress/kendo-angular-grid";
import { NotificationService } from "@progress/kendo-angular-notification";
import {
  CompositeFilterDescriptor,
  distinct,
  filterBy,
  process,
  State,
} from "@progress/kendo-data-query";
import * as moment from "moment";
import { Observable } from "rxjs";
import { AppStoreService } from "../../../core/app-store.service";
import { role, uiScreen } from "../../../core/model/common.constant";
import { Plant, UserModel } from "../../../core/model/user.model";
import { Item } from "../../model/item";
import { ScheduleStatus } from "../../model/schedule-status.model";
import { EditService } from "../../service/edit.service";
import { RequestService } from "../../service/request.service";
import { BayService } from "../adjust-capacity/bay/bay-service/bay.service";
import { CreateCPService } from "../check-capacity-requirement/create-capacity-plan/create-cp-service/createCP.service";
import { AdjustModuleService } from "./adjust-module-service/adjustModule.service";
import { addModule } from "./models/add-module";
import { DemandRequirements } from "./models/demandRequirements";
import { FilterItem } from "./models/filterItem";
import { ModuleGrid } from "./models/moduleGrid";
import { toolTypeGrid } from "./models/toolTypeGrid";
import { UpdateModule } from "./models/updateModule";

@Component({
  selector: "pmpm-adjust-module",
  templateUrl: "./adjust-module.component.html",
  styleUrls: ["./adjust-module.component.css", "./pdf-styles.css"],
  encapsulation: ViewEncapsulation.None,
})
export class AdjustModuleComponent implements OnInit {
  @ViewChildren(DataBindingDirective) public binding: DataBindingDirective[];
  @ViewChild("appendTo", { read: ViewContainerRef })
  public appendTo: ViewContainerRef;

  public view: Observable<GridDataResult> = new Observable<GridDataResult>();
  gridData: ModuleGrid[] = [];
  public gridView: GridDataResult;

  demandRequirementsGridData: any[] = [];
  public addOpened = false;
  public addToolTypeOpened = false;
  public editToolTypeOpened = false;

  public isProductTypeChecked = false;
  public isDivisionChecked = false;
  public isBuildTypeChecked = false;
  public isToolTypeChecked = false;
  public isCustomerChecked = false;

  transistionDate: Date = new Date();
  POABOMReleaseDate: Date = new Date();
  site: Plant;

  cpColor = "";
  reworkPO = false;
  valueAddedBuild = false;
  standardBuild = false;
  reconfig = false;

  disableCapacityFields = false;

  public gridFilteredData: any[] = [];
  public gridFilteredData2: any[] = [];

  public productTypeData: any[] = [];
  public productTypeItemsSource: any[] = [];
  public tempProductTypeData: any[] = [];
  public divisionData: any[] = [];
  public buildTypeData: any[] = [];
  public tempBuildTypeData: any[] = [];
  public toolTypeData: any[] = [];
  public tempToolTypeData: any[] = [];
  public toolTypeDataSource: any[] = [];
  public customerData: any[] = [];
  public tempCustomerData: any[] = [];
  public buildingItems: Array<Item> = [];
  public productTypeItems: Array<Item> = [];

  public buildTypeItems: Array<Item> = [];
  public associatedBENItems: Array<Item> = [];
  public toolTypeItems: Array<Item> = [];
  public toolTypeItemsSource: Array<Item> = [];
  public buildStyleItems: Array<Item> = [];
  tempBS: Array<Item> = [];
  public buildStyleItemsAddPopup: Array<Item> = [];

  public buildScheduleItems: Array<Item> = [];
  public buildScheduleItemsWithLH: Array<Item> = [];
  public POMItems: Array<Item> = [];
  public capacityPlanningColorHex: Array<Item> = [];
  public PilotRiskLevelItems: any = ["", "LOW", "MEDIUM", "HIGH", "MISS"];
  public SalesPriorityItems: any = ["", "LOW", "MEDIUM", "HIGH"];
  PilotRiskLevelGridValue = { text: "", value: 0 };
  SalesPriorityGridValue = { text: "", value: 0 };

  buildStyleGridValue = { text: "", value: 0 };
  buildScheduleGridValue = { text: "", value: 0 };
  buildTypeGridValue = { text: "", value: 0 };
  capacityPlanningColorGridValue = { text: "", value: 0 };
  buildingValue: { text: ""; value: 0 };

  buildStyleValue: { text: string; value: number };
  FCIDValue: string;
  currentPartNumberValue = "";
  newPartNumberValue = "";
  reworkPOValue = "";
  associatedBENValue: { text: ""; value: number };
  associatedPSNValue: { text: ""; value: number };

  buildTypeValue: { text: string; value: number };

  buildScheduleValue: { text: string; value: number };
  editedBuildScheduleValue: { text: string; value: number };
  pilotSerialNumberValue: string;
  baysRequiredForSubAssembly = 0;
  totalAssemblyHoursValue: number;
  baysRequiredForIntegration = 0;
  totalIntegrationHoursValue: number;
  baysRequiredForTest = 0;
  totalTestHoursValue: number;
  baysRequiredForPostTest = 0;
  totalPostTestHoursValue: number;
  cpColorValue: { text: ""; value: 0 };
  committedLaunchDateValue: Date;
  CRDDateValue: Date;
  PORDateValue: Date;

  BENValue: string;
  POMValue: string;
  productTypeValue: { text: ""; value: 0 };
  toolTypeValue: { text: ""; value: 0 };

  addPOValue: string;
  deletePOValue: string;
  benReconfiguredFromValue: string;

  demandRequirementsGridValue: DemandRequirements[] = [];

  addModule: addModule;
  updateModuleObj: UpdateModule[] = [];

  materialReadinessValue: Date = new Date();
  buildScheduleLH: number;
  setGrayColorCD = false;
  setGrayColorLH = false;
  disableAddButton = false;
  disableAddButton2 = false;
  showValidationErrorMsg = false;
  searchValue = "";
  searchToolTypeValue = "";
  toolTypeGridData: toolTypeGrid[] = [];

  public loadTable = true;
  public loadTableTT = true;

  public disabledDates: Date[] = [new Date(2021, 12, 12)];

  public BTValueAddedBuildmodel = {
    BTValueAddedBuild: null,
  };

  showErrMsg = false;
  errMsg = "";
  showDemandReqErrMsg = false;
  demandErrMsg = "";
  showPSNorBENerr = false;

  public recordTypeItems: Array<Item> = [];
  public revenueTypeItems: Array<Item> = [];
  recordTypeValue: { text: ""; value: 0 };
  revenueTypeValue: { text: ""; value: 0 };

  cellOpen = false;
  showErrorMsgDe = false;

  public gridState: State = {
    skip: 0,
    take: 50,
    // Initial filter descriptor
    filter: {
      logic: "and",
      filters: [],
    },
  };
  public state: State = {
    skip: 0,
  };
  public searchState: State = {
    skip: 0,
    take: 50,
  };
  editCapacity = true;
  public filter: CompositeFilterDescriptor;

  public changes: any = {};
  filterValues: FilterItem[] = [];
  grdData: any[] = [];
  prevVal = "";
  isUserAccess = false;
  canEditModuleReworkAndToolType = false;
  canViewAdjustModule = false;
  isLoading = true;

  public pageSize = 6;
  public skip = 0;
  public minEffectiveDate = new Date();
  public showProductType = false;
  public showBuildType = false;
  public showToolType = false;
  public showcustomer = false;
  public group: any[] = [
    {
      field: "notes",
    },
  ];
  public userDetail: UserModel;

  disableAddBSDDL = true;
  public colIndex;
  public colIndex2;
  public colIndex3;
  public colIndex4;
  public colIndex5;
  public colIndex6;
  public colIndex7;
  public colIndex8;
  public colIndex9;
  public colIndex10;
  public colIndex11;
  public colIndex12;
  public colIndex13;
  public colIndex14;
  public colIndex15;
  public colIndex16;
  public colIndex17;
  public scheduleStatusData: ScheduleStatus[] = [];
  public scheduleStatus: ScheduleStatus;

  public editOpened = false;
  public editedDataItem: ModuleGrid = new ModuleGrid();
  public minDate = new Date();
  public crdDateError = false;
  public porDateError = false;
  public committedDateError = false;

  POValue: string;

  constructor(
    private formBuilder: FormBuilder,
    public editService: EditService,
    private appStoreService: AppStoreService,
    private adjustModuleService: AdjustModuleService,
    private bayService: BayService,
    private createCPService: CreateCPService,
    private notificationService: NotificationService,
    private requestService: RequestService
  ) {
    this.allData = this.allData.bind(this);
  }

  public ngOnInit(): void {
    this.minDate.setDate(this.minDate.getDate() + 1);
    this.canEditModuleReworkAndToolType = false;
    this.canViewAdjustModule = false;
    this.isLoading = true;
    this.appStoreService.getUserRoles().subscribe((res) => {
      if (res && res.length > 0) {
        this.appStoreService
          .checkUserAccessRight(res, uiScreen.ModifyModule)
          .subscribe((result) => {
            this.canViewAdjustModule = result;
            if (
              !res.includes(role.Technician) &&
              !res.includes(role.PassTeamMember)
            )
              this.isUserAccess = true;
            if (
              res.includes(role.Manager) ||
              res.includes(role.SuperUser)
            )
              this.canEditModuleReworkAndToolType = true;
            this.isLoading = false;
          });
      }
    });
    this.appStoreService.getCurrentSite().subscribe((site) => {
      if (site) {
        this.isLoading = true;
        this.disableAddBSDDL = true;
        this.site = {
          plantName: site.plantName,
          plantId: site.plantId,
        };
        this.populateDropdowns();

        this.fillToolTypeGrid();
        this.toolTypeItems = [];
        this.buildingItems = [];
        this.productTypeItems = [];
        this.gridState["filter"].filters = [];

        this.adjustModuleService
          .getToolTypeDDL(this.site?.plantId)
          .subscribe((tt) => {
            tt.forEach((val) => {
              const newTT: Item = {
                value: val.toolTypeID,
                text: val.toolTypeName,
              };
              this.toolTypeItems.push(newTT);
              this.toolTypeItemsSource.push(newTT);
            });
          });
        this.bayService
          .getBuilding(this.site?.plantId)
          .subscribe((buildings) => {
            buildings.forEach((val) => {
              const newBuilding: Item = {
                value: val.buildingID,
                text: val.buildingName,
              };
              this.buildingItems.push(newBuilding);
            });
          });
        this.bayService
          .getProductType(this.site?.plantId)
          .subscribe((pt) => {
            pt.forEach((val) => {
              const newPt: Item = {
                value: val.productGroupID,
                text: val.productName,
              };
              this.productTypeItems.push(newPt);
            });
            this.productTypeItemsSource = [
              ...this.productTypeItems,
            ];
          });
      }
    });
    this.appStoreService.getLoggedInUser().subscribe((user) => {
      this.appStoreService.getUserDetails(user.mail).subscribe((res) => {
        this.userDetail = res;
      });
    });
    this.scheduleStatusData = [];
    this.requestService.GetScheduleStatus().subscribe((res) => {
      if (res && res.length > 0) {
        const data = JSON.parse(
          JSON.stringify(
            res.filter(
              (item) =>
                item.optionName !== "Dropped" &&
                item.optionName !== "Shipped/Crated"
            )
          )
        );
        this.scheduleStatusData.push({
          optionName: "",
          scheduleStatusId: null,
        });
        this.scheduleStatusData = [...this.scheduleStatusData, ...data];
      }
    });
  }
  onTabSelect(e) {
    if (e.index == 0) {
      this.fillAdjustModulesGrid();
    }
  }

  populateDropdowns() {
    this.buildTypeItems = [];
    this.buildStyleItems = [];
    this.buildStyleItemsAddPopup = [];

    this.tempBS = [];
    this.buildScheduleItems = [];
    this.buildScheduleItemsWithLH = [];
    this.associatedBENItems = [];
    this.capacityPlanningColorHex = [];
    this.recordTypeItems = [];
    this.revenueTypeItems = [];

    this.adjustModuleService
      .getBuildTypeDDL(this.site?.plantId)
      .subscribe((bt) => {
        bt.forEach((val) => {
          const newBt: Item = {
            value: val.value,
            text: val.masterRecordName,
          };
          this.buildTypeItems.push(newBt);
        });
      });
    this.adjustModuleService.getBuildStyleDDL().subscribe((bs) => {
      bs.forEach((val) => {
        const newBs: Item = {
          value: val.masterRecordID,
          text: val.masterRecordName,
        };
        this.buildStyleItems.push(newBs);
      });
    });
    this.adjustModuleService
      .getBuildStyleDDLForAddPOPUp()
      .subscribe((bs) => {
        bs.forEach((val) => {
          const newBs: Item = {
            value: val.masterRecordID,
            text: val.masterRecordName,
          };
          this.buildStyleItemsAddPopup.push(newBs);
        });
        this.tempBS = JSON.parse(
          JSON.stringify(this.buildStyleItemsAddPopup)
        );
        this.disableAddBSDDL = false;
        this.isLoading = false;
      });
    this.adjustModuleService.getBuildScheduleDDL().subscribe((bsc) => {
      bsc.forEach((val) => {
        const newBsc: Item = {
          value: val.masterRecordID,
          text: val.masterRecordName.split(",")[0],
        };
        this.buildScheduleItems.push(newBsc);
        const newBscLH: Item = {
          text: val.masterRecordName.split(",")[0],
          value: val.masterRecordName.split(",")[1],
        };
        this.buildScheduleItemsWithLH.push(newBscLH);
      });
    });
    this.adjustModuleService
      .getAssosiatedBENDDL(this.site?.plantId)
      .subscribe((ben) => {
        ben.forEach((val) => {
          const newBen: Item = {
            value: 0,
            text: val.ben,
          };
          this.associatedBENItems.push(newBen);
        });
      });
    this.adjustModuleService.getModuleColorDDL().subscribe((mc) => {
      mc.forEach((val) => {
        const newMC: Item = {
          value: val.value.trim(),
          text: val.masterRecordName,
        };
        this.capacityPlanningColorHex.push(newMC);
      });
      this.fillAdjustModulesGrid();
    });
    this.createCPService
      .getRecordType(this.site?.plantId)
      .subscribe((rt) => {
        rt.forEach((val) => {
          const newRT: Item = {
            value: val.schedulePriorityID,
            text: val.priorities,
          };
          this.recordTypeItems.push(newRT);
        });
      });
    this.createCPService
      .getRevenueType(this.site?.plantId)
      .subscribe((rt) => {
        rt.forEach((val) => {
          const newRT: Item = {
            value: val.schedulePriorityID,
            text: val.priorities,
          };
          this.revenueTypeItems.push(newRT);
        });
      });
  }

  public itemDisabled(itemArgs: { dataItem: any; index: number }) {
    return itemArgs.index === 4;
  }
  public itemDisabled2(itemArgs: { dataItem: any; index: number }) {
    return itemArgs.index === 5;
  }
  fillAdjustModulesGrid() {
    this.gridData = [];
    this.loadTable = true;
    this.adjustModuleService
      .getModule(this.site?.plantId)
      .subscribe((modules) => {
        if (modules && modules.length > 0) {
          this.gridData = modules;
          this.gridData.forEach((item) => {
            if (
              item.capacityPlanningColor == null ||
              item.capacityPlanningColor == ""
            ) {
              item.capacityPlanningColor = "transparent";
            }
            if (
              item.capacityPlanningColor.includes("#") ||
              item.capacityPlanningColor.includes("transparent")
            ) {
              item.capacityPlanningColorString =
                this.getColorFromHexValue(
                  item.capacityPlanningColor
                );
            } else {
              item.capacityPlanningColorString =
                item.capacityPlanningColor;
              item.capacityPlanningColor = this.getHexColorValue(
                item.capacityPlanningColor
              );
            }

            if (
              item.schedulingColor == null ||
              item.schedulingColor == ""
            ) {
              item.schedulingColor = "transparent";
            }
            if (
              item.schedulingColor.includes("#") ||
              item.schedulingColor.includes("transparent")
            ) {
              item.schedulingColorString =
                this.getColorFromHexValue(item.schedulingColor);
            } else {
              item.schedulingColorString = item.schedulingColor;
              item.schedulingColor = this.getHexColorValue(
                item.schedulingColor
              );
            }
            item.notes = item.notes?.replace(/(<([^>]+)>)/gi, "");
          });
          this.toolTypeDataSource =
            this.distinctPrimitive("toolTypeName");
          this.gridFilteredData = JSON.parse(
            JSON.stringify(this.gridData)
          );
          this.gridFilteredData2 = JSON.parse(
            JSON.stringify(this.gridData)
          );
          this.loadTable = false;
          if (this.searchValue != "") {
            this.onSearchFilter();
          }
        }
        this.loadTable = false;
        const filter: CompositeFilterDescriptor = {
          filters: [],
          logic: "and",
        };
        const data = [
          {
            field: "scheduleStatus",
            operator: "eq",
            value: "New",
          },
          {
            field: "scheduleStatus",
            operator: "eq",
            value: "Changed",
          },
          {
            field: "scheduleStatus",
            operator: "eq",
            value: "Dropped",
          },
          {
            field: "scheduleStatus",
            operator: "eq",
            value: null,
          },
        ];
        filter.filters.push({ filters: [...data], logic: "or" });
        this.filterChange(filter);
      });
  }
  fillToolTypeGrid() {
    this.toolTypeGridData = [];
    this.loadTableTT = true;
    //get module tool type grid
    this.adjustModuleService
      .getModuleToolType(this.site?.plantId)
      .subscribe((tt) => {
        tt.forEach((val) => {
          const ttg: toolTypeGrid = {
            Id: val.ToolTypeName.ToolTypeID,
            ToolType: val.ToolTypeName.ToolTypeName,
            SubassemblyId: this.getModuleProcessDetails(
              val.ModuleProcess,
              "Subassembly",
              "Id"
            ),
            SubassemblyBays: this.getModuleProcessDetails(
              val.ModuleProcess,
              "Subassembly",
              "Bays"
            ),
            SubassemblyHours: this.getModuleProcessDetails(
              val.ModuleProcess,
              "Subassembly",
              "Hours"
            ),
            SubassemblyTechs: this.getModuleProcessDetails(
              val.ModuleProcess,
              "Subassembly",
              "Techs"
            ),
            IntegrationId: this.getModuleProcessDetails(
              val.ModuleProcess,
              "Integration",
              "Id"
            ),
            IntegrationBays: this.getModuleProcessDetails(
              val.ModuleProcess,
              "Integration",
              "Bays"
            ),
            IntegrationHours: this.getModuleProcessDetails(
              val.ModuleProcess,
              "Integration",
              "Hours"
            ),
            IntegrationTechs: this.getModuleProcessDetails(
              val.ModuleProcess,
              "Integration",
              "Techs"
            ),
            TestId: this.getModuleProcessDetails(
              val.ModuleProcess,
              "Test",
              "Id"
            ),
            TestBays: this.getModuleProcessDetails(
              val.ModuleProcess,
              "Test",
              "Bays"
            ),
            TestHours: this.getModuleProcessDetails(
              val.ModuleProcess,
              "Test",
              "Hours"
            ),
            TestTechs: this.getModuleProcessDetails(
              val.ModuleProcess,
              "Test",
              "Techs"
            ),
            PostTestId: this.getModuleProcessDetails(
              val.ModuleProcess,
              "Post-test",
              "Id"
            ),
            PostTestBays: this.getModuleProcessDetails(
              val.ModuleProcess,
              "Post-test",
              "Bays"
            ),
            PostTestHours: this.getModuleProcessDetails(
              val.ModuleProcess,
              "Post-test",
              "Hours"
            ),
            PostTestTechs: this.getModuleProcessDetails(
              val.ModuleProcess,
              "Post-test",
              "Techs"
            ),
            TotalLH: val.TotalLaborHour,
            POABOMReleaseDate:
              val.ModuleProcess[0].POABOMReleaseDate != null
                ? moment(
                  val.ModuleProcess[0].POABOMReleaseDate
                ).format("M-D-YY")
                : null,
            TransitionDate:
              val.ModuleProcess[0].TransitionDate != null
                ? moment(
                  val.ModuleProcess[0].TransitionDate
                ).format("M-D-YY")
                : null,
            LastUpdated:
              val.ModuleProcess[0].LastUpdated != null
                ? moment(
                  val.ModuleProcess[0].LastUpdated
                ).format("M-D-YY")
                : null,
            UpdatedBy: val.ModuleProcess[0].UpdatedBy,
          };
          this.toolTypeGridData.push(ttg);
        });
      });
  }
  getModuleProcessDetails(
    moduleProcess: any[],
    MP: string,
    value: string
  ): number {
    for (let i = 0; i < moduleProcess.length; i++) {
      if (moduleProcess[i].ModuleProcessName == MP) {
        if (value == "Bays") {
          return moduleProcess[i].BayRequired;
        } else if (value == "Hours") {
          return moduleProcess[i].HourRequired;
        } else if (value == "Techs") {
          return moduleProcess[i].TechnicianRequired;
        } else if (value == "Id") {
          return moduleProcess[i].ModuleProcessID;
        }
      }
    }
    return null;
  }
  fillDemandRequirementsGridData(event) {
    let flag = -1;
    this.toolTypeGridData.forEach((val) => {
      if (val.ToolType == event.text) {
        this.demandRequirementsGridData = [];
        const drSubAssembly: DemandRequirements = {
          Process: "Subassembly",
          CalenderDays: null,
          Bays: val.SubassemblyBays,
          LaborHours: val.SubassemblyHours,
          Techs: val.SubassemblyTechs,
        };
        const drIntegration: DemandRequirements = {
          Process: "Integration",
          CalenderDays: null,
          Bays: val.IntegrationBays,
          LaborHours: val.IntegrationHours,
          Techs: val.IntegrationTechs,
        };
        const drTest: DemandRequirements = {
          Process: "Test",
          CalenderDays: null,
          Bays: val.TestBays,
          LaborHours: val.TestHours,
          Techs: val.PostTestTechs,
        };
        const drPostTest: DemandRequirements = {
          Process: "Post-Test",
          CalenderDays: null,
          Bays: val.PostTestBays,
          LaborHours: val.PostTestHours,
          Techs: val.PostTestTechs,
        };
        this.demandRequirementsGridData.push(drSubAssembly);
        this.demandRequirementsGridData.push(drIntegration);
        this.demandRequirementsGridData.push(drTest);
        this.demandRequirementsGridData.push(drPostTest);
        flag = 1;
      }
    });
    if (flag == -1) {
      this.demandRequirementsGridData = [];
      if (event == "REWORKPO") {
        const drSubAssembly: DemandRequirements = {
          Process: "Subassembly",
          CalenderDays: null,
          Bays: 1,
          LaborHours: null,
          Techs: 1,
        };
        this.demandRequirementsGridData.push(drSubAssembly);
      } else {
        this.demandRequirementsGridData = [];
        const drSubAssembly: DemandRequirements = {
          Process: "Subassembly",
          CalenderDays: null,
          Bays: 0,
          LaborHours: 0,
          Techs: 0,
        };
        const drIntegration: DemandRequirements = {
          Process: "Integration",
          CalenderDays: null,
          Bays: 0,
          LaborHours: 0,
          Techs: 0,
        };
        const drTest: DemandRequirements = {
          Process: "Test",
          CalenderDays: null,
          Bays: 0,
          LaborHours: 0,
          Techs: 0,
        };
        const drPostTest: DemandRequirements = {
          Process: "Post-Test",
          CalenderDays: null,
          Bays: 0,
          LaborHours: 0,
          Techs: 0,
        };
        this.demandRequirementsGridData.push(drSubAssembly);
        this.demandRequirementsGridData.push(drIntegration);
        this.demandRequirementsGridData.push(drTest);
        this.demandRequirementsGridData.push(drPostTest);
      }
    }
  }
  public onStateChange(state: State) {
    this.gridState = state;
    if (this.searchValue === "") this.loadData();
  }
  private loadData(): void {
    this.gridView = process(this.gridData, this.gridState);
  }

  public cellClickHandler({
    sender,
    rowIndex,
    columnIndex,
    dataItem,
    isEdited,
  }: any) {
    if (!isEdited) {
      sender.editCell(
        rowIndex,
        columnIndex,
        this.createFormGroup(dataItem)
      );
    }
  }

  public cellCloseHandler(args: any) {
    const { formGroup, dataItem } = args;
    if (formGroup.dirty) {
      if (!this.checkValidationAdj(args)) {
        this.editService.assignValues(dataItem, formGroup.value);
        this.editService.update(dataItem, "Adjust Module");
      }
    } else if (!formGroup.valid) {
      // prevent closing the edited cell if there are invalid values.
      if (!this.checkValidationAdj(args)) {
        this.editService.update(dataItem, "Adjust Module");
      }
    } else {
      this.editService.update(dataItem, "Adjust Module");
    }
    this.noCapacityCheckedChanged(dataItem);
  }
  public cancelHandler({ sender, rowIndex }: any) {
    sender.closeRow(rowIndex);
  }

  checkValidationAdj(args) {
    if (args.column.field == "SubAssyBaysNeeded") {
      if (
        args.formGroup.value["SubAssyBaysNeeded"] < 0 ||
        args.formGroup.value["SubAssyBaysNeeded"] > 9
      ) {
        this.showErrorMsgDe = true;
        this.errMsg =
          "(*)Please enter SubAssembly bays between 0 and 9.";
      } else {
        this.showErrorMsgDe = false;
        this.errMsg = "";
      }
    } else if (args.column.field == "SubAssyHrs") {
      if (
        args.formGroup.value["SubAssyHrs"] < 0 ||
        args.formGroup.value["SubAssyHrs"] > 999
      ) {
        this.showErrorMsgDe = true;
        this.errMsg =
          "(*)Please enter SubAssembly Hours between 0 and 999.";
      } else {
        this.showErrorMsgDe = false;
        this.errMsg = "";
      }
    } else if (args.column.field == "SubAssyTechs") {
      if (
        args.formGroup.value["SubAssyTechs"] < 0 ||
        args.formGroup.value["SubAssyTechs"] > 9
      ) {
        this.showErrorMsgDe = true;
        this.errMsg =
          "(*)Please enter SubAssembly Techs between 0 and 9.";
      } else {
        this.showErrorMsgDe = false;
        this.errMsg = "";
      }
    } else if (args.column.field == "IntBaysNeeded") {
      if (
        args.formGroup.value["IntBaysNeeded"] < 0 ||
        args.formGroup.value["IntBaysNeeded"] > 9
      ) {
        this.showErrorMsgDe = true;
        this.errMsg =
          "(*)Please enter Integration bays between 0 and 9.";
      } else {
        this.showErrorMsgDe = false;
        this.errMsg = "";
      }
    } else if (args.column.field == "IntHrs") {
      if (
        args.formGroup.value["IntHrs"] < 0 ||
        args.formGroup.value["IntHrs"] > 999
      ) {
        this.showErrorMsgDe = true;
        this.errMsg =
          "(*)Please enter Integration Hours between 0 and 999.";
      } else {
        this.showErrorMsgDe = false;
        this.errMsg = "";
      }
    } else if (args.column.field == "IntTechs") {
      if (
        args.formGroup.value["IntTechs"] < 0 ||
        args.formGroup.value["IntTechs"] > 9
      ) {
        this.showErrorMsgDe = true;
        this.errMsg =
          "(*)Please enter Integration Techs between 0 and 9.";
      } else {
        this.showErrorMsgDe = false;
        this.errMsg = "";
      }
    } else if (args.column.field == "TestBaysNeeded") {
      if (
        args.formGroup.value["TestBaysNeeded"] < 0 ||
        args.formGroup.value["TestBaysNeeded"] > 9
      ) {
        this.showErrorMsgDe = true;
        this.errMsg = "(*)Please enter Test bays between 0 and 9.";
      } else {
        this.showErrorMsgDe = false;
        this.errMsg = "";
      }
    } else if (args.column.field == "TestHrs") {
      if (
        args.formGroup.value["TestHrs"] < 0 ||
        args.formGroup.value["TestHrs"] > 999
      ) {
        this.showErrorMsgDe = true;
        this.errMsg = "(*)Please enter Test Hours between 0 and 999.";
      } else {
        this.showErrorMsgDe = false;
        this.errMsg = "";
      }
    } else if (args.column.field == "TestTechs") {
      if (
        args.formGroup.value["TestTechs"] < 0 ||
        args.formGroup.value["TestTechs"] > 9
      ) {
        this.showErrorMsgDe = true;
        this.errMsg = "(*)Please enter Test Techs between 0 and 9.";
      } else {
        this.showErrorMsgDe = false;
        this.errMsg = "";
      }
    } else if (args.column.field == "PostTestBaysNeeded") {
      if (
        args.formGroup.value["PostTestBaysNeeded"] < 0 ||
        args.formGroup.value["PostTestBaysNeeded"] > 9
      ) {
        this.showErrorMsgDe = true;
        this.errMsg = "(*)Please enter PostTest bays between 0 and 9.";
      } else {
        this.showErrorMsgDe = false;
        this.errMsg = "";
      }
    } else if (args.column.field == "PostTestHrs") {
      if (
        args.formGroup.value["PostTestHrs"] < 0 ||
        args.formGroup.value["PostTestHrs"] > 999
      ) {
        this.showErrorMsgDe = true;
        this.errMsg =
          "(*)Please enter Post Test Hours between 0 and 999.";
      } else {
        this.showErrorMsgDe = false;
        this.errMsg = "";
      }
    } else if (args.column.field == "PostTestTechs") {
      if (
        args.formGroup.value["PostTestTechs"] < 0 ||
        args.formGroup.value["PostTestTechs"] > 9
      ) {
        this.showErrorMsgDe = true;
        this.errMsg =
          "(*)Please enter Post Test Techs between 0 and 9.";
      } else {
        this.showErrorMsgDe = false;
        this.errMsg = "";
      }
    }
    return this.showErrorMsgDe;
  }
  public saveHandler({ sender, formGroup, rowIndex }: any) {
    if (formGroup.valid) {
      this.editService.create(formGroup.value);
      sender.closeRow(rowIndex);
    }
  }

  public removeHandler({ sender, dataItem }: any) {
    this.editService.remove(dataItem);

    sender.cancelCell();
  }

  public saveChanges(grid: any): void {
    this.errMsg = "";
    this.showErrMsg = false;
    grid.closeCell();
    grid.cancelCell();
    const abc = this.editService.saveChanges();
    //Update Modules API ---replace updateToolType obj
    this.updateModuleObj = [];
    abc[0].forEach((val: ModuleGrid) => {
      const updateModule: UpdateModule = {
        PlantName: this.site.plantName,
        PilotProductID: val.pilotProductID,
        FCID: val.fcid,
        PilotRisk: val.pilotRisk,
        PilotSerialNumber: val.pilotSerialNumber,
        BuildStyleId: val.buildStyleId,
        BuildScheduleId: val.buildScheduleId,
        NoCapacity: val.noCapacity,
        RecordType: val.recordType,
        RevenueCode: val.revenueCode,
        ProductGroupName: val.productGroupName,
        ToolTypeName: val.toolTypeName,
        PilotToolType: val.pilotToolType,
        BuildTypeId: val.buildTypeID,
        BaysRequired: 0,

        BaysRequiredSubassembly: val.baysRequiredSubassembly,
        TotalAssemblyHours: val.totalAssemblyHours,
        TechnicianRequiredSubassembly:
          val.technicianRequiredSubassembly,

        BaysRequiredIntegration: val.baysRequiredIntegration,
        TotalIntegrationHours: val.totalIntegrationHours,
        TechnicianRequiredIntegration:
          val.technicianRequiredIntegration,

        BaysRequiredForTest: val.baysRequiredForTest,
        TotalTestHours: val.totalTestHours,
        TechnicianRequiredTest: val.technicianRequiredTest,

        BaysRequiredPostTest: val.baysRequiredPostTest,
        TotalPostTestHours: val.totalPostTestHours,
        TechnicianRequiredPostTest: val.technicianRequiredPostTest,

        TotalLaborHour: val.totalLaborHour,

        //Dates
        PriorityDate: null,
        EarliestStartDate:
          val.earliestStartDate != null
            ? moment(val.earliestStartDate).format("yyyy-MM-DD")
            : null,
        MaterialReadiness:
          val.materialReadiness != null
            ? moment(val.materialReadiness).format("yyyy-MM-DD")
            : null,
        ActualDMRF: null,
        ActualShipDate:
          val.transitionDate != null
            ? moment(val.transitionDate).format("yyyy-MM-DD")
            : null, //Actual Ship date-->transistion date
        CommitLaunch:
          val.commitLaunch != null
            ? moment(val.commitLaunch).format("yyyy-MM-DD")
            : null,
        CommittedIntegrationStart:
          val.committedIntegrationStart != null
            ? moment(val.committedIntegrationStart).format(
              "yyyy-MM-DD"
            )
            : null,
        CommitTestStart:
          val.commitTestStart != null
            ? moment(val.commitTestStart).format("yyyy-MM-DD")
            : null,
        CommitManufacturingComplete:
          val.commitManufacturingComplete != null
            ? moment(val.commitManufacturingComplete).format(
              "yyyy-MM-DD"
            )
            : null,

        CRD:
          val.crd != null
            ? moment(val.crd).format("yyyy-MM-DD")
            : null,
        SRD:
          val.srd != null
            ? moment(val.srd).format("yyyy-MM-DD")
            : null,
        PilotMCSD:
          val.pilotMCSD != null
            ? moment(val.pilotMCSD).format("yyyy-MM-DD")
            : null,
        SapMCSD:
          val.sapMCSD != null
            ? moment(val.sapMCSD).format("yyyy-MM-DD")
            : null,
        TSD:
          val.tsd != null
            ? moment(val.tsd).format("yyyy-MM-DD")
            : null,
        PlanofRecord:
          val.planofRecord != null
            ? moment(val.planofRecord).format("yyyy-MM-DD")
            : null,

        POABOMReleaseDate:
          val.poabomReleaseDate != null
            ? moment(val.poabomReleaseDate).format("yyyy-MM-DD")
            : null,

        SalesPriority:
          val.salesPriority != null
            ? val.salesPriority.toString()
            : null,
        CRDEsc: val.crdEsc,

        SchedulingColor: val.schedulingColor,
        CapacityPlanningColor: val.capacityPlanningColor,
        Notes: val.notes,
        ScheduleStatus: val.scheduleStatus,
        ScheduleStatusId: val.scheduleStatusId,
        ModuleProcessSubassembly: "Subassembly",
        ModuleProcessIntegration: "Integration",
        ModuleProcessTest: "Test",
        ModuleProcessPostTest: "Post-test",
        ModifiedBy: this.userDetail?.userId,
        ModifiedOn: new Date(
          new Date().getTime() -
          new Date().getTimezoneOffset() * 60000
        ),
      };
      this.updateModuleObj.push(updateModule);
    });
    this.adjustModuleService
      .updateModules(this.updateModuleObj)
      .subscribe((res) => {
        if (res) {
          this.showSuccess("Saved");
        }
      });
  }

  public showSuccess(msg: string): void {
    this.notificationService.show({
      appendTo: this.appendTo,
      content: msg,
      position: { horizontal: "left", vertical: "bottom" },
      animation: { type: "fade", duration: 600 },
      type: { style: "success", icon: true },
    });
  }
  public showError(msg: string): void {
    this.notificationService.show({
      appendTo: this.appendTo,
      content: msg,
      position: { horizontal: "left", vertical: "bottom" },
      animation: { type: "fade", duration: 600 },
      type: { style: "warning", icon: true },
    });
  }

  public cancelChanges(grid: any): void {
    this.errMsg = "";
    this.showErrMsg = false;
    this.fillAdjustModulesGrid();

    grid.cancelCell();

    this.editService.cancelChanges();
  }

  public createFormGroup(dataItem: ModuleGrid): FormGroup {
    return this.formBuilder.group({
      fcid: dataItem.fcid,
      PilotSerialNumber: dataItem.pilotSerialNumber,
      pilotRisk: dataItem.pilotRisk,
      salesPriority: dataItem.salesPriority,
      buildStyleId: dataItem.buildStyleId,
      buildScheduleId: dataItem.buildScheduleId,
      noCapacity: dataItem.noCapacity,
      recordType: dataItem.recordType,
      revenueCode: dataItem.revenueCode,
      toolTypeName: dataItem.toolTypeName,
      productGroupName: dataItem.productGroupName,
      buildTypeID: dataItem.buildTypeID,
      buildTypeName: dataItem.buildTypeName,
      pilotToolType: dataItem.pilotToolType,

      baysRequiredSubassembly: [
        dataItem.baysRequiredSubassembly,
        Validators.pattern("^[0-9]{1,1}"),
      ],
      totalAssemblyHours: [
        dataItem.totalAssemblyHours,
        Validators.pattern("^[0-9]{1,3}"),
      ],
      technicianRequiredSubassembly: [
        dataItem.technicianRequiredSubassembly,
        Validators.pattern("^[0-9]{1,1}"),
      ],

      baysRequiredIntegration: [
        dataItem.baysRequiredIntegration,
        Validators.pattern("^[0-9]{1,1}"),
      ],
      totalIntegrationHours: [
        dataItem.totalIntegrationHours,
        Validators.pattern("^[0-9]{1,3}"),
      ],
      technicianRequiredIntegration: [
        dataItem.technicianRequiredIntegration,
        Validators.pattern("^[0-9]{1,1}"),
      ],

      baysRequiredForTest: [
        dataItem.baysRequiredForTest,
        Validators.pattern("^[0-9]{1,1}"),
      ],
      totalTestHours: [
        dataItem.totalTestHours,
        Validators.pattern("^[0-9]{1,3}"),
      ],
      technicianRequiredTest: [
        dataItem.technicianRequiredTest,
        Validators.pattern("^[0-9]{1,1}"),
      ],

      baysRequiredPostTest: [
        dataItem.baysRequiredPostTest,
        Validators.pattern("^[0-9]{1,1}"),
      ],
      totalPostTestHours: [
        dataItem.totalPostTestHours,
        Validators.pattern("^[0-9]{1,3}"),
      ],
      technicianRequiredPostTest: [
        dataItem.technicianRequiredPostTest,
        Validators.pattern("^[0-9]{1,1}"),
      ],

      totalLaborHour: dataItem.totalLaborHour,
      earliestStartDate: dataItem.earliestStartDate,
      materialReadiness: dataItem.materialReadiness,
      poabomReleaseDate: dataItem.poabomReleaseDate,
      transitionDate: dataItem.transitionDate,
      commitLaunch: dataItem.commitLaunch,
      committedIntegrationStart: dataItem.committedIntegrationStart,
      commitTestStart: dataItem.commitTestStart,
      commitManufacturingComplete: dataItem.commitManufacturingComplete,

      tsd: dataItem.tsd,
      pilotMCSD: dataItem.pilotMCSD,
      crd: dataItem.crd,
      crdGapDays: dataItem.crdGapDays,
      crdEsc: dataItem.crdEsc,
      srd: dataItem.srd,
      planofRecord: dataItem.planofRecord,
      schedulingColor: dataItem.schedulingColor,
      capacityPlanningColor: dataItem.capacityPlanningColor,
      notes: dataItem.notes,
    });
  }

  public onStateChangeDemand(state: State) {
    this.gridState = state;
  }

  public cellClickHandlerDemand({
    sender,
    rowIndex,
    columnIndex,
    dataItem,
    isEdited,
  }: any) {
    if (!isEdited) {
      sender.editCell(
        rowIndex,
        columnIndex,
        this.createFormGroupDemand(dataItem)
      );
      this.cellOpen = true;
    }
  }

  public cellCloseHandlerDemand(args: any) {
    const { formGroup, dataItem } = args;
    this.cellOpen = false;

    if (!formGroup.valid) {
      // prevent closing the edited cell if there are invalid values.
      args.preventDefault();
      this.disableAddButton = true;
    } else if (formGroup.dirty) {
      this.disableAddButton = false;
      this.editService.assignValues(dataItem, formGroup.value);
      this.editService.update(dataItem, "Demand Requirements");
    } else {
      this.disableAddButton = false;
      this.editService.update(dataItem, "Demand Requirements");
    }
    this.calculateLaborHoursCalendarDays(dataItem, args.column.field);
  }
  public createFormGroupDemand(dataItem: any): FormGroup {
    return this.formBuilder.group({
      Process: dataItem.Process,
      CalenderDays: dataItem.CalenderDays,
      LaborHours: dataItem.LaborHours,
      Bays: dataItem.Bays,
      Techs: dataItem.Techs,
    });
  }

  calculateLaborHoursCalendarDays(data: any, col: string) {
    if (col == "CalenderDays") {
      this.showDemandReqErrMsg = false;
      this.demandErrMsg = "";
      if (
        data.CalenderDays <= 0 ||
        data.CalenderDays > 99 ||
        data.CalenderDays % 1 != 0
      ) {
        this.showDemandReqErrMsg = true;
        this.demandErrMsg =
          "(*)Please enter Integer values for Calender Days between 1 and 100";
        data.CalenderDays = 0;
        return;
      }
      const prevLH = data.LaborHours != null ? data.LaborHours : 0;
      const LH =
        this.buildScheduleLH != undefined
          ? Math.ceil(
            data.CalenderDays * this.buildScheduleLH * data.Techs
          )
          : 0;
      if (LH != NaN && LH != Infinity) {
        data.LaborHours = LH != 0 && LH != NaN ? LH : prevLH;
      } else {
        data.LaborHours = prevLH;
      }
      this.setGrayColorCD = false;
      this.setGrayColorLH = true;
    } else if (col == "LaborHours") {
      this.showDemandReqErrMsg = false;
      this.demandErrMsg = "";
      if (
        data.LaborHours <= 0 ||
        data.LaborHours > 999 ||
        data.LaborHours % 1 != 0
      ) {
        this.showDemandReqErrMsg = true;
        this.demandErrMsg =
          "(*)Please enter Integer values for Labor Hours between 1 and 1000";
        data.LaborHours = 0;
        return;
      }
      const prevCD = data.CalenderDays != null ? data.CalenderDays : 0;
      const CD =
        this.buildScheduleLH != undefined
          ? Math.ceil(
            data.LaborHours / (this.buildScheduleLH * data.Techs)
          )
          : 0;
      if (CD != NaN && CD != Infinity) {
        data.CalenderDays = CD != 0 && CD != NaN ? CD : prevCD;
      } else {
        data.CalenderDays = prevCD;
      }
      this.setGrayColorCD = true;
      this.setGrayColorLH = false;
    } else if (col == "Techs") {
      this.showDemandReqErrMsg = false;
      this.demandErrMsg = "";
      if (
        (data.LaborHours != 0 || data.CalenderDays != 0) &&
        data.Techs == 0
      ) {
        this.showDemandReqErrMsg = true;
        this.demandErrMsg =
          "(*)Please enter an Integer value for number of Techs between 1 and 9 as Labor Hours/Calendar Days > 0.";
        return;
      }
      if (data.Techs < 0 || data.Techs > 9 || data.Techs % 1 != 0) {
        this.showDemandReqErrMsg = true;
        this.demandErrMsg =
          "(*)Please enter an Integer value for number of Techs between 0 and 9.";
        data.Techs = 0;
        return;
      }
      const prevLH1 = data.LaborHours != null ? data.LaborHours : 0;
      const prevCD1 = data.CalenderDays != null ? data.CalenderDays : 0;
      if (data.LaborHours == 0) {
        var LH1 =
          this.buildScheduleLH != undefined
            ? Math.ceil(
              data.CalenderDays *
              this.buildScheduleLH *
              data.Techs
            )
            : 0;
        var CD1 =
          this.buildScheduleLH != undefined
            ? Math.ceil(
              data.LH1 / (this.buildScheduleLH * data.Techs)
            )
            : 0;
      } else {
        var CD1 =
          this.buildScheduleLH != undefined
            ? Math.ceil(
              data.LaborHours /
              (this.buildScheduleLH * data.Techs)
            )
            : 0;
        var LH1 =
          this.buildScheduleLH != undefined
            ? Math.ceil(CD1 * this.buildScheduleLH * data.Techs)
            : 0;
      }
      if (
        CD1 != NaN &&
        CD1 != Infinity &&
        LH1 != NaN &&
        LH1 != Infinity
      ) {
        data.CalenderDays = CD1 != 0 && CD1 != NaN ? CD1 : prevCD1;
        data.LaborHours = LH1 != 0 && LH1 != NaN ? LH1 : prevLH1;
        if (isNaN(data.CalenderDays)) {
          data.CalenderDays = prevCD1;
        }
        if (isNaN(data.LaborHours)) {
          data.LaborHours = prevLH1;
        }
      } else {
        data.CalenderDays = prevCD1;
        data.LaborHours = prevLH1;
      }
      this.setGrayColorCD = true;
      this.setGrayColorLH = false;
    } else if (col == "Bays") {
      this.showDemandReqErrMsg = false;
      this.demandErrMsg = "";
      if (
        (data.LaborHours != 0 || data.CalenderDays != 0) &&
        data.Bays == 0
      ) {
        this.showDemandReqErrMsg = true;
        this.demandErrMsg =
          "(*)Please enter an Integer value for number of Bays between 1 and 9 as Labor Hours/Calendar Days > 0.";
        return;
      }
      if (data.Bays < 0 || data.Bays > 9 || data.Bays % 1 != 0) {
        this.showDemandReqErrMsg = true;
        this.demandErrMsg =
          "(*)Please enter an Integer value for number of Bays between 0 and 9.";
        data.Bays = 0;
        return;
      }
    } else if (col == "bs") {
      if (data.Techs != null) {
        const prevLH = data.LaborHours != null ? data.LaborHours : 0;
        const LH =
          this.buildScheduleLH != undefined
            ? Math.ceil(
              data.CalenderDays *
              this.buildScheduleLH *
              data.Techs
            )
            : 0;
        if (LH != NaN && LH != Infinity) {
          data.LaborHours = LH != 0 && LH != NaN ? LH : prevLH;
        } else {
          data.LaborHours = prevLH;
        }
      } else {
        data.LaborHours = 0;
      }
    }
  }
  getCalendarDaysColor() {
    if (this.setGrayColorCD == true && this.setGrayColorLH == false) {
      return "set-gray-CD";
    }
    else {
      return "set-yellow-LH";
    }
  }
  getLaborHoursColor() {
    if (this.setGrayColorCD == false && this.setGrayColorLH == true) {
      return "set-gray-LH";
    } else {
      return "set-yellow-LH";
    }
  }
  buildScheduleSelectionChange(event) {
    this.buildScheduleItemsWithLH.forEach((val) => {
      if (val.text == event.text) {
        this.buildScheduleLH = val.value;
      }
    });
    if (this.demandRequirementsGridData.length > 0) {
      this.demandRequirementsGridData.forEach((val) => {
        this.calculateLaborHoursCalendarDays(val, "bs");
      });
    }
  }

  checkValuesBaysTechs(value) {
    if (value < 0 || value > 10) return false;
    return true;
  }

  //Add Module/Production Code Dialog
  closeAdd(status: string) {
    this.demandErrMsg = "";
    this.showDemandReqErrMsg = false;
    this.addOpened = false;
    this.crdDateError = false;
    this.porDateError = false;
    this.committedDateError = false;
    this.resetAddModule();
  }

  openAdd() {
    this.addOpened = true;
    if (this.site?.plantName === "Fremont") {
      this.buildStyleItemsAddPopup = this.buildStyleItemsAddPopup.filter(
        (x) => x.text != "Cell Fusion"
      );
      const bsch = this.buildScheduleItems.filter((x) =>
        x.text.includes("10")
      );
      this.buildScheduleValue = {
        text: bsch[0].text,
        value: bsch[0].value,
      };
      this.buildScheduleItemsWithLH.forEach((val) => {
        if (val.text == this.buildScheduleValue.text) {
          this.buildScheduleLH = val.value;
        }
      });
    } else {
      this.buildStyleItemsAddPopup = JSON.parse(
        JSON.stringify(this.tempBS)
      );
    }
  }

  cpColorSelectionChange(event) {
    this.cpColor = event.value;
    this.cpColorValue = event.text;
  }
  buildStyleSelectionChange(event) {
    if (event.text == "Rework PO") {
      this.standardBuild = true;
      this.reworkPO = true;
      this.valueAddedBuild = false;
      this.reconfig = false;
      this.fillDemandRequirementsGridData("REWORKPO");
    } else if (event.text == "Value Added Build") {
      this.standardBuild = true;
      this.reworkPO = false;
      this.valueAddedBuild = true;
      this.reconfig = false;
      this.fillDemandRequirementsGridData("VALUEADDEDBUILD");
    } else if (event.text == "Pilot Build" || event.text == "Cell Fusion") {
      this.standardBuild = true;
      this.reworkPO = false;
      this.valueAddedBuild = false;
      this.reconfig = false;
      const bti = this.buildTypeItems.filter((x) =>
        x.text.toLowerCase().includes("beta")
      );
      this.buildTypeValue = {
        text: bti[0].text,
        value: bti[0].value,
      };
    } else if (event.text == "Reconfig") {
      this.reconfig = true;
      this.standardBuild = true;
      this.reworkPO = false;
      this.valueAddedBuild = false;
    } else {
      if (event.text == "Special Projects") {
        this.buildTypeItems = this.buildTypeItems.filter(
          (x) =>
            x.text.toLowerCase().includes("alpha") ||
            x.text.includes("BQ") ||
            x.text.includes("BV") ||
            x.text.includes("CB")
        );
      }
      this.standardBuild = false;
      this.reworkPO = false;
      this.valueAddedBuild = false;
      this.reconfig = false;
    }
  }

  toolTypeSelectionChange(event) {
    if (this.buildStyleValue.text == "Rework PO") return;
    this.fillDemandRequirementsGridData(event);
  }

  dataItemColorSelectionChange(data, id, dataItem: ModuleGrid) {
    dataItem.capacityPlanningColor = data.value.trim();
    dataItem.capacityPlanningColorString = data.text.trim();
    this.editService.update(dataItem, "Adjust Module");
  }

  dataItemSchedulingColorSelectionChange(data, id, dataItem: ModuleGrid) {
    dataItem.schedulingColor = data.value.trim();
    dataItem.schedulingColorString = data.text.trim();
    this.editService.update(dataItem, "Adjust Module");
  }

  setBuildTypeValue() {
    if (this.BTValueAddedBuildmodel.BTValueAddedBuild != null) {
      if (
        this.buildStyleValue["text"].toString() == "Value Added Build"
      ) {
        this.buildTypeValue = {
          text: this.BTValueAddedBuildmodel.BTValueAddedBuild,
          value: this.getValueFromText(
            this.buildTypeItems,
            this.BTValueAddedBuildmodel.BTValueAddedBuild
          ),
        };
      }
    }
  }

  onSubmitAdd() {
    this.setBuildTypeValue();
    this.disableAddButtonValidation();
    if (this.disableAddButton2 === true) {
      this.showValidationErrorMsg = true;
      return;
    } else {
      this.showValidationErrorMsg = false;
    }

    this.addModule = {
      BuildStyleId:
        this.buildStyleValue != undefined
          ? this.buildStyleValue["value"]
          : null,
      FCID: this.FCIDValue != undefined ? this.FCIDValue : null,
      CurrentPartNumber:
        this.currentPartNumberValue != undefined
          ? this.currentPartNumberValue
          : null,
      NewPartNumber:
        this.newPartNumberValue != undefined
          ? this.newPartNumberValue
          : null,
      ReworkPO:
        this.reworkPOValue != undefined ? this.reworkPOValue : null,
      AssociatedBEN:
        this.associatedBENValue != undefined
          ? this.associatedBENValue.text
          : null,
      AssociatedPSN:
        this.associatedPSNValue != undefined
          ? this.associatedPSNValue.text
          : null,
      BuildTypeID:
        this.buildTypeValue != undefined
          ? parseInt(this.buildTypeValue["value"].toString())
          : null,

      BuildScheduleId:
        this.buildScheduleValue != undefined
          ? this.buildScheduleValue["value"]
          : null,
      PilotSerialNumber:
        this.pilotSerialNumberValue != undefined &&
          this.site.plantName === "Fremont"
          ? this.pilotSerialNumberValue
          : null,
      BEN:
        this.pilotSerialNumberValue != undefined &&
          this.site.plantName !== "Fremont"
          ? this.pilotSerialNumberValue
          : null, // we are getting both PSN and BEN in a single variable pilotSerialNumberValue
      CommitLaunch:
        this.committedLaunchDateValue != undefined
          ? moment(this.committedLaunchDateValue).format("yyyy-MM-DD")
          : null,
      POM: this.POMValue != undefined ? this.POMValue : null,

      CRD:
        this.CRDDateValue != undefined
          ? moment(this.CRDDateValue).format("yyyy-MM-DD")
          : null,
      POR:
        this.PORDateValue != undefined
          ? moment(this.PORDateValue).format("yyyy-MM-DD")
          : null,

      ProductGroupID:
        this.productTypeValue != undefined
          ? this.productTypeValue["value"]
          : null,
      ToolTypeID:
        this.toolTypeValue != undefined
          ? this.toolTypeValue["value"]
          : null,

      BuildingID:
        this.buildingValue != undefined
          ? this.buildingValue["value"]
          : null,

      CapacityPlanningColor:
        this.cpColorValue != undefined
          ? this.getHexColorValue(this.cpColorValue["text"])
          : "transparent",

      BaysRequiredSubassembly:
        this.demandRequirementsGridData[0] != undefined
          ? this.demandRequirementsGridData[0].Bays
          : null,
      TotalAssemblyHours:
        this.demandRequirementsGridData[0] != undefined
          ? this.demandRequirementsGridData[0].LaborHours
          : null,
      TechnicianRequiredSubassembly:
        this.demandRequirementsGridData[0] != undefined
          ? this.demandRequirementsGridData[0].Techs
          : null,

      BaysRequiredIntegration:
        this.demandRequirementsGridData[1] != undefined
          ? this.demandRequirementsGridData[1].Bays
          : null,
      TotalIntegrationHours:
        this.demandRequirementsGridData[1] != undefined
          ? this.demandRequirementsGridData[1].LaborHours
          : null,
      TechnicianRequiredIntegration:
        this.demandRequirementsGridData[1] != undefined
          ? this.demandRequirementsGridData[1].Techs
          : null,

      BaysRequiredForTest:
        this.demandRequirementsGridData[2] != undefined
          ? this.demandRequirementsGridData[2].Bays
          : null,
      TotalTestHours:
        this.demandRequirementsGridData[2] != undefined
          ? this.demandRequirementsGridData[2].LaborHours
          : null,
      TechnicianRequiredTest:
        this.demandRequirementsGridData[2] != undefined
          ? this.demandRequirementsGridData[2].Techs
          : null,

      BaysRequiredPostTest:
        this.demandRequirementsGridData[3] != undefined
          ? this.demandRequirementsGridData[3].Bays
          : null,
      TotalPostTestHours:
        this.demandRequirementsGridData[3] != undefined
          ? this.demandRequirementsGridData[3].LaborHours
          : null,
      TechnicianRequiredPostTest:
        this.demandRequirementsGridData[3] != undefined
          ? this.demandRequirementsGridData[3].Techs
          : null,

      ModuleProcessSubassembly: "Subassembly",
      ModuleProcessIntegration: "Integration",
      ModuleProcessTest: "Test",
      ModuleProcessPostTest: "Post-test",
      RecordType:
        this.recordTypeValue != undefined
          ? this.recordTypeValue.text
          : null,
      RevenueType:
        this.revenueTypeValue != undefined
          ? this.revenueTypeValue.text
          : null,
      PlantID: this.site?.plantId,
      ProductionOrderNum:
        this.POValue !== undefined ? this.POValue : null,
      AddPO: this.addPOValue !== undefined ? this.addPOValue : null,
      DeletePO:
        this.deletePOValue !== undefined ? this.deletePOValue : null,
      BENorPSNReconfiguredFrom:
        this.benReconfiguredFromValue != undefined
          ? this.benReconfiguredFromValue
          : null,

      modifiedBy: this.userDetail?.userId,
      modifiedOn: new Date(
        new Date().getTime() - new Date().getTimezoneOffset() * 60000
      ),
    };
    //call save API
    if (!this.checkAddModuleValidation()) {
      return;
    }

    if (
      this.buildStyleValue["text"].toString() == "Pilot Build" ||
      this.buildStyleValue["text"].toString() == "Cell Fusion" ||
      this.buildStyleValue["text"].toString() == "Value Added Build" ||
      this.buildStyleValue["text"].toString() == "Reconfig"
    ) {
      this.adjustModuleService
        .getpsnbenexists(
          this.site?.plantId,
          this.pilotSerialNumberValue
        )
        .subscribe((res) => {
          if (res.exist == 0) {
            this.gridData = [];
            this.loadTable = true;

            this.adjustModuleService
              .addModules(this.addModule)
              .subscribe((res) => {
                if (res) this.fillAdjustModulesGrid();
              });
            //Reset the form
            this.resetAddModule();

            //closing Add dialog
            this.addOpened = false;
          }
        });
    } else if (this.buildStyleValue["text"].toString() == "Rework PO") {
      this.adjustModuleService
        .getpsnbenexists(this.site?.plantId, this.reworkPOValue)
        .subscribe((res) => {
          if (res.exist == 0) {
            this.gridData = [];
            this.loadTable = true;

            this.adjustModuleService
              .addModules(this.addModule)
              .subscribe((res) => {
                if (res) this.fillAdjustModulesGrid();
              });
            //Reset the form
            this.resetAddModule();

            //closing Add dialog
            this.addOpened = false;
          }
        });
    }
  }

  resetAddModule() {
    this.reworkPO = false;
    this.valueAddedBuild = false;
    this.standardBuild = false;
    this.reconfig = false;
    this.showPSNorBENerr = false;

    this.buildStyleValue = undefined;
    this.FCIDValue = undefined;
    this.currentPartNumberValue = "";
    this.newPartNumberValue = "";
    this.reworkPOValue = "";
    this.associatedBENValue = undefined;
    this.associatedPSNValue = undefined;
    this.buildTypeValue = undefined;

    this.BTValueAddedBuildmodel.BTValueAddedBuild = null;
    this.buildScheduleValue = undefined;
    this.pilotSerialNumberValue = undefined;
    this.BENValue = undefined;
    this.committedLaunchDateValue = undefined;
    this.POMValue = undefined;
    this.productTypeValue = undefined;
    this.toolTypeValue = undefined;
    this.cpColorValue = undefined;
    this.buildingValue = undefined;
    this.cpColor = undefined;
    this.demandRequirementsGridData = [];
    this.recordTypeValue = undefined;
    this.revenueTypeValue = undefined;
    this.CRDDateValue = undefined;
    this.PORDateValue = undefined;

    this.addPOValue = undefined;
    this.deletePOValue = undefined;
    this.benReconfiguredFromValue = undefined;
  }

  checkAddModuleValidation() {
    if (
      this.buildStyleValue["text"].toString() == "Pilot Build" ||
      this.buildStyleValue["text"].toString() == "Cell Fusion"
    ) {
      if (
        this.addModule.BuildScheduleId == null ||
        this.addModule.ToolTypeID == null ||
        this.pilotSerialNumberValue == undefined ||
        this.pilotSerialNumberValue == null
      ) {
        this.showValidationErrorMsg = true;
        return false;
      } else if (this.addModule.TotalAssemblyHours != 0) {
        if (
          this.addModule.BaysRequiredSubassembly == 0 ||
          this.addModule.BaysRequiredSubassembly == null ||
          this.addModule.TechnicianRequiredSubassembly == 0 ||
          this.addModule.TechnicianRequiredSubassembly == null
        ) {
          this.showDemandReqErrMsg = true;
          this.demandErrMsg =
            "Total LH not 0. Technicians and Bays cannot be 0.";
          return false;
        }
      } else if (this.addModule.TotalIntegrationHours != 0) {
        if (
          this.addModule.BaysRequiredIntegration == 0 ||
          this.addModule.BaysRequiredIntegration == null ||
          this.addModule.TechnicianRequiredIntegration == 0 ||
          this.addModule.TechnicianRequiredIntegration == null
        ) {
          this.showDemandReqErrMsg = true;
          this.demandErrMsg =
            "Total LH not 0. Technicians and Bays cannot be 0.";
          return false;
        }
      } else if (this.addModule.TotalTestHours != 0) {
        if (
          this.addModule.BaysRequiredForTest == 0 ||
          this.addModule.BaysRequiredForTest == null ||
          this.addModule.TechnicianRequiredTest == 0 ||
          this.addModule.TechnicianRequiredTest == null
        ) {
          this.showDemandReqErrMsg = true;
          this.demandErrMsg =
            "Total LH not 0. Technicians and Bays cannot be 0.";
          return false;
        }
      } else if (this.addModule.TotalPostTestHours != 0) {
        if (
          this.addModule.BaysRequiredPostTest == 0 ||
          this.addModule.BaysRequiredPostTest == null ||
          this.addModule.TechnicianRequiredPostTest == 0 ||
          this.addModule.TechnicianRequiredPostTest == null
        ) {
          this.showDemandReqErrMsg = true;
          this.demandErrMsg =
            "Total LH not 0. Technicians and Bays cannot be 0.";
          return false;
        }
      } else {
        this.showValidationErrorMsg = false;
        return true;
      }
    }
    if (this.buildStyleValue["text"].toString() == "Rework PO") {
      if (
        this.addModule.BuildScheduleId == null ||
        this.addModule.CurrentPartNumber == null ||
        this.addModule.ReworkPO == null
      ) {
        this.showValidationErrorMsg = true;
        return false;
      } else if (this.addModule.TotalAssemblyHours != 0) {
        if (
          this.addModule.BaysRequiredSubassembly == 0 ||
          this.addModule.BaysRequiredSubassembly == null ||
          this.addModule.TechnicianRequiredSubassembly == 0 ||
          this.addModule.TechnicianRequiredSubassembly == null
        ) {
          this.showDemandReqErrMsg = true;
          this.demandErrMsg =
            "Total LH not 0. Technicians and Bays cannot be 0.";
          return false;
        }
      } else {
        this.showValidationErrorMsg = false;
        return true;
      }
    }
    if (this.buildStyleValue["text"].toString() == "Value Added Build") {
      if (
        this.addModule.BuildScheduleId == null ||
        this.pilotSerialNumberValue == undefined ||
        this.pilotSerialNumberValue == null ||
        this.addModule.BuildTypeID == null ||
        (this.site?.plantName !== "Fremont" &&
          this.addModule.BuildingID == null)
      ) {
        this.showValidationErrorMsg = true;
        return false;
      } else if (this.addModule.TotalAssemblyHours != 0) {
        if (
          this.addModule.BaysRequiredSubassembly == 0 ||
          this.addModule.BaysRequiredSubassembly == null ||
          this.addModule.TechnicianRequiredSubassembly == 0 ||
          this.addModule.TechnicianRequiredSubassembly == null
        ) {
          this.showDemandReqErrMsg = true;
          this.demandErrMsg =
            "Total LH not 0. Technicians and Bays cannot be 0.";
          return false;
        }
      } else if (this.addModule.TotalIntegrationHours != 0) {
        if (
          this.addModule.BaysRequiredIntegration == 0 ||
          this.addModule.BaysRequiredIntegration == null ||
          this.addModule.TechnicianRequiredIntegration == 0 ||
          this.addModule.TechnicianRequiredIntegration == null
        ) {
          this.showDemandReqErrMsg = true;
          this.demandErrMsg =
            "Total LH not 0. Technicians and Bays cannot be 0.";
          return false;
        }
      } else if (this.addModule.TotalTestHours != 0) {
        if (
          this.addModule.BaysRequiredForTest == 0 ||
          this.addModule.BaysRequiredForTest == null ||
          this.addModule.TechnicianRequiredTest == 0 ||
          this.addModule.TechnicianRequiredTest == null
        ) {
          this.showDemandReqErrMsg = true;
          this.demandErrMsg =
            "Total LH not 0. Technicians and Bays cannot be 0.";
          return false;
        }
      } else if (this.addModule.TotalPostTestHours != 0) {
        if (
          this.addModule.BaysRequiredPostTest == 0 ||
          this.addModule.BaysRequiredPostTest == null ||
          this.addModule.TechnicianRequiredPostTest == 0 ||
          this.addModule.TechnicianRequiredPostTest == null
        ) {
          this.showDemandReqErrMsg = true;
          this.demandErrMsg =
            "Total LH not 0. Technicians and Bays cannot be 0.";
          return false;
        }
      } else {
        this.showValidationErrorMsg = false;
        return true;
      }
    }
    return true;
  }

  closeToolTypeAdd(status: string) {
    this.addToolTypeOpened = false;
  }

  openToolTypeAdd() {
    this.addToolTypeOpened = true;
  }

  closeToolTypeEdit(status: string) {
    this.editToolTypeOpened = false;
  }

  openToolTypeEdit() {
    this.editToolTypeOpened = true;
  }
  onChangeEarliestAllowedLaunchDate(value: Date, dataItem: ModuleGrid) {
    this.errMsg = "";
    this.showErrMsg = false;
    dataItem.earliestStartDate = moment(value).format("M-D-YY");
    if (value < new Date()) {
      dataItem.earliestStartDate = null;
      this.errMsg =
        "Please enter a Earliest Allowed Launch Date greater than current date!";
      this.showErrMsg = true;
    } else if (dataItem.earliestStartDate != null) {
      if (
        parseInt(dataItem.earliestStartDate.split("-")[2]) > 99 ||
        parseInt(dataItem.earliestStartDate.split("-")[2]) < 0
      ) {
        dataItem.earliestStartDate = null;
        this.errMsg =
          "Please enter a valid Earliest Allowed Launch Date!";
        this.showErrMsg = true;
      }
    } else {
      dataItem.earliestStartDate = moment(value).format("M-D-YY");
    }
    this.createFormGroup(dataItem);
  }
  onChangeMaterialReadiness(value: Date, dataItem: ModuleGrid) {
    this.errMsg = "";
    this.showErrMsg = false;
    dataItem.materialReadiness = moment(value).format("M-D-YY");
    if (
      parseInt(dataItem.materialReadiness.split("-")[2]) > 99 ||
      parseInt(dataItem.materialReadiness.split("-")[0]) < 0
    ) {
      dataItem.materialReadiness = null;
    }
    this.createFormGroup(dataItem);
  }
  onChangeBOM(value: Date, dataItem: ModuleGrid) {
    this.errMsg = "";
    this.showErrMsg = false;
    dataItem.poabomReleaseDate = moment(value).format("M-D-YY");
    if (
      parseInt(dataItem.poabomReleaseDate.split("-")[2]) > 99 ||
      parseInt(dataItem.poabomReleaseDate.split("-")[2]) < 0
    ) {
      dataItem.poabomReleaseDate = null;
    } else {
      dataItem.poabomReleaseDate = moment(value).format("M-D-YY");
    }
    this.createFormGroup(dataItem);
  }
  onChangeTranisitionDate(value: Date, dataItem: ModuleGrid) {
    this.errMsg = "";
    this.showErrMsg = false;
    dataItem.transitionDate = moment(value).format("M-D-YY");
    if (
      parseInt(dataItem.transitionDate.split("-")[2]) > 99 ||
      parseInt(dataItem.transitionDate.split("-")[2]) < 0
    ) {
      dataItem.transitionDate = null;
    } else {
      dataItem.transitionDate = moment(value).format("M-D-YY");
    }
    this.createFormGroup(dataItem);
  }
  onChangeLaunch(value: Date, dataItem: ModuleGrid) {
    this.errMsg = "";
    this.showErrMsg = false;

    if (value < new Date()) {
      this.errMsg =
        "Please enter a Committed Launch date greater than current date!";
      this.showErrMsg = true;
    } else if (dataItem.commitLaunch != null) {
      if (
        parseInt(dataItem.commitLaunch.split("-")[2]) > 99 ||
        parseInt(dataItem.commitLaunch.split("-")[2]) < 0
      ) {
        this.errMsg = "Please enter a valid Committed Launch date!";
        this.showErrMsg = true;
      } else {
        dataItem.commitLaunch = moment(value).format("M-D-YY");
        this.createFormGroup(dataItem);
      }
    } else {
      dataItem.commitLaunch = moment(value).format("M-D-YY");
      this.createFormGroup(dataItem);
    }
  }
  onChangeIntegration(value: Date, dataItem: ModuleGrid) {
    this.errMsg = "";
    this.showErrMsg = false;
    dataItem.committedIntegrationStart = moment(value).format("M-D-YY");
    if (
      parseInt(dataItem.committedIntegrationStart.split("-")[2]) > 99 ||
      parseInt(dataItem.committedIntegrationStart.split("-")[2]) < 0
    ) {
      dataItem.committedIntegrationStart = null;
    }
    this.createFormGroup(dataItem);
  }
  onChangeTestStart(value: Date, dataItem: ModuleGrid) {
    this.errMsg = "";
    this.showErrMsg = false;
    dataItem.commitTestStart = moment(value).format("M-D-YY");
    if (
      parseInt(dataItem.commitTestStart.split("-")[2]) > 99 ||
      parseInt(dataItem.commitTestStart.split("-")[2]) < 0
    ) {
      dataItem.commitTestStart = null;
    }
    this.createFormGroup(dataItem);
  }
  onChangeMfgComplete(value: Date, dataItem: ModuleGrid) {
    this.errMsg = "";
    this.showErrMsg = false;
    dataItem.commitManufacturingComplete = moment(value).format("M-D-YY");
    if (
      parseInt(dataItem.commitManufacturingComplete.split("-")[2]) > 99 ||
      parseInt(dataItem.commitManufacturingComplete.split("-")[2]) < 0
    ) {
      dataItem.commitManufacturingComplete = null;
    }
    this.createFormGroup(dataItem);
  }
  onChangePilotMCSD(value: Date, dataItem: ModuleGrid) {
    this.errMsg = "";
    this.showErrMsg = false;
    if (value < new Date()) {
      this.errMsg =
        "Please enter a Pilot MCSD date greater than current date!";
      this.showErrMsg = true;
    } else if (dataItem.pilotMCSD != null) {
      if (
        parseInt(dataItem.pilotMCSD.split("-")[2]) > 99 ||
        parseInt(dataItem.pilotMCSD.split("-")[2]) < 0
      ) {
        this.errMsg = "Please enter a valid Pilot MCSD date!";
        this.showErrMsg = true;
      } else {
        dataItem.pilotMCSD = moment(value).format("M-D-YY");
        this.createFormGroup(dataItem);
      }
    } else {
      dataItem.pilotMCSD = moment(value).format("M-D-YY");
      this.createFormGroup(dataItem);
    }
  }
  onChangeCRD(value: Date, dataItem: ModuleGrid) {
    this.errMsg = "";
    this.showErrMsg = false;
    if (value < new Date()) {
      this.errMsg = "Please enter a CRD date greater than current date!";
      this.showErrMsg = true;
    } else if (dataItem.crd != null) {
      if (
        parseInt(dataItem.crd.split("-")[2]) > 99 ||
        parseInt(dataItem.crd.split("-")[2]) < 0
      ) {
        this.errMsg = "Please enter a valid CRD date!";
        this.showErrMsg = true;
      } else {
        dataItem.crd = moment(value).format("M-D-YY");
        this.createFormGroup(dataItem);
      }
    } else {
      dataItem.crd = moment(value).format("M-D-YY");
      this.createFormGroup(dataItem);
    }
  }
  onChangePOR(value: Date, dataItem: ModuleGrid) {
    this.errMsg = "";
    this.showErrMsg = false;
    if (value < new Date()) {
      this.errMsg = "Please enter a POR date greater than current date!";
      this.showErrMsg = true;
    } else if (dataItem.planofRecord != null) {
      if (
        parseInt(dataItem.planofRecord.split("-")[2]) > 99 ||
        parseInt(dataItem.planofRecord.split("-")[2]) < 0
      ) {
        this.errMsg = "Please enter a valid POR date!";
        this.showErrMsg = true;
      } else {
        dataItem.planofRecord = moment(value).format("M-D-YY");
        this.createFormGroup(dataItem);
      }
    } else {
      dataItem.planofRecord = moment(value).format("M-D-YY");
      this.createFormGroup(dataItem);
    }
  }

  onChangeTSD(value: Date, dataItem: ModuleGrid) {
    this.errMsg = "";
    this.showErrMsg = false;
    dataItem.tsd = moment(value).format("M-D-YY");
    if (value < new Date()) {
      dataItem.tsd = null;
      this.errMsg = "Please enter a TSD greater than current date!";
      this.showErrMsg = true;
    } else if (dataItem.tsd != null) {
      if (
        parseInt(dataItem.tsd.split("-")[2]) > 99 ||
        parseInt(dataItem.tsd.split("-")[2]) < 0
      ) {
        dataItem.tsd = null;
        this.errMsg = "Please enter a valid TSD!";
        this.showErrMsg = true;
      }
    } else {
      dataItem.tsd = moment(value).format("M-D-YY");
    }
    this.createFormGroup(dataItem);
  }

  onChangeSRD(value: Date, dataItem: ModuleGrid) {
    this.errMsg = "";
    this.showErrMsg = false;
    dataItem.srd = moment(value).format("M-D-YY");
    if (value < new Date()) {
      dataItem.srd = null;
      this.errMsg = "Please enter a SRD greater than current date!";
      this.showErrMsg = true;
    } else if (dataItem.srd != null) {
      if (
        parseInt(dataItem.srd.split("-")[2]) > 99 ||
        parseInt(dataItem.srd.split("-")[2]) < 0
      ) {
        dataItem.srd = null;
        this.errMsg = "Please enter a valid SRD!";
        this.showErrMsg = true;
      }
    } else {
      dataItem.srd = moment(value).format("M-D-YY");
    }
    this.createFormGroup(dataItem);
  }

  public distinctPrimitive(fieldName: string): any {
    const distinctData: any[] = distinct(this.gridData, fieldName).map(
      (item) => item[fieldName]
    );
    const data: any[] = [];
    distinctData.forEach((item) => {
      if (item !== null) data.push({ text: item, checked: false });
    });
    data.sort(function (a, b) {
      const textA = a?.text?.toUpperCase();
      const textB = b?.text?.toUpperCase();
      return textA < textB ? -1 : textA > textB ? 1 : 0;
    });
    return data;
  }

  handleFilter(value, dataItem) {
    if (dataItem === "toolTypeItems") {
      this.toolTypeItems = this.toolTypeItemsSource.filter(
        (s) => s.text.toLowerCase().indexOf(value.toLowerCase()) !== -1
      );
    } else if (dataItem === "toolTypeData") {
      this.toolTypeData = this.toolTypeDataSource.filter(
        (s) => s.text.toLowerCase().indexOf(value.toLowerCase()) !== -1
      );
    } else if (dataItem === "productTypeItems") {
      this.productTypeItems = this.productTypeItemsSource.filter(
        (s) => s.text.toLowerCase().indexOf(value.toLowerCase()) !== -1
      );
    }
  }

  public onSearchFilter(): void {
    const filter: CompositeFilterDescriptor = { filters: [], logic: "and" };
    if (this.site.plantName != "Fremont") {
      const data1 = [
        {
          field: "fcid",
          operator: "contains",
          value: this.searchValue?.trim(),
        },
        {
          field: "ben",
          operator: "contains",
          value: this.searchValue?.trim(),
        },
        {
          field: "toolTypeName",
          operator: "contains",
          value: this.searchValue?.trim(),
        },
        {
          field: "productGroupName",
          operator: "contains",
          value: this.searchValue?.trim(),
        },
        {
          field: "notes",
          operator: "contains",
          value: this.searchValue?.trim(),
        },
      ];
      filter.filters.push({ filters: [...data1], logic: "or" });
    }
    if (this.site.plantName == "Fremont") {
      const data1 = [
        {
          field: "fcid",
          operator: "contains",
          value: this.searchValue?.trim(),
        },
        {
          field: "fremontID",
          operator: "contains",
          value: this.searchValue?.trim(),
        },
        {
          field: "pilotSerialNumber",
          operator: "contains",
          value: this.searchValue?.trim(),
        },
        {
          field: "toolTypeName",
          operator: "contains",
          value: this.searchValue?.trim(),
        },
        {
          field: "productGroupName",
          operator: "contains",
          value: this.searchValue?.trim(),
        },
        {
          field: "notes",
          operator: "contains",
          value: this.searchValue?.trim(),
        },
      ];
      filter.filters.push({ filters: [...data1], logic: "or" });
    }
    this.gridData = filterBy(this.gridFilteredData, filter);
    Array.from(this.binding)[0].skip = 0;
  }

  getValueFromText(arr: Array<Item>, key: any) {
    let val = -1;
    if (typeof key === "string") {
      for (let i = 0; i < arr.length; i++) {
        if (arr[i].text == key) {
          val = arr[i].value;
        }
      }
    } else {
      for (let i = 0; i < arr.length; i++) {
        if (arr[i].text == key.text) {
          val = arr[i].value;
        }
      }
    }
    return val;
  }
  getTextFromValue(arr: Array<Item>, key: any) {
    let val = "";
    if (typeof key === "number") {
      for (let i = 0; i < arr.length; i++) {
        if (arr[i].value == key) {
          val = arr[i].text;
        }
      }
    } else {
      for (let i = 0; i < arr.length; i++) {
        if (arr[i].value == key) {
          val = arr[i].text;
        }
      }
    }
    return val;
  }
  getBuildScheduleGridValue(data) {
    if (data != null) {
      this.buildScheduleGridValue = {
        text: this.getTextFromValue(this.buildScheduleItems, data),
        value: data,
      };
    } else {
      this.buildScheduleGridValue = { text: "", value: 0 };
    }
    return this.buildScheduleGridValue.text;
  }
  getPilotRiskLevelValue(data) {
    if (data != null) {
      this.PilotRiskLevelGridValue = {
        text: data,
        value: this.getValueFromText(this.PilotRiskLevelItems, data),
      };
    } else {
      this.PilotRiskLevelGridValue = { text: "", value: 0 };
    }
    return this.PilotRiskLevelGridValue.text;
  }
  getSalesPriorityValue(data) {
    if (data != null) {
      this.SalesPriorityGridValue = {
        text: data,
        value: this.getValueFromText(this.SalesPriorityItems, data),
      };
    } else {
      this.SalesPriorityGridValue = { text: "", value: 0 };
    }
    return this.SalesPriorityGridValue.text;
  }
  getBuildStyleValue(data) {
    if (data != null) {
      this.buildStyleGridValue = {
        text: this.getTextFromValue(this.buildStyleItems, data),
        value: data,
      };
    } else {
      this.buildStyleGridValue = { text: "", value: 0 };
    }
    return this.buildStyleGridValue.text;
  }
  getBuildTypeValue(data) {
    if (data != null) {
      this.buildTypeGridValue = {
        text: this.getTextFromValue(this.buildTypeItems, data),
        value: data,
      };
    } else {
      this.buildTypeGridValue = { text: "", value: 0 };
    }
    return this.buildTypeGridValue.text;
  }
  dataItemPilotRiskLevelSelectionChange(data, id, dataItem) {
    this.PilotRiskLevelGridValue = { text: data.text, value: data.value };
    dataItem.PilotRisk = data.text;
    this.editService.update(dataItem, "");
  }
  dataItemSalesPrioritySelectionChange(data, id, dataItem) {
    this.SalesPriorityGridValue = { text: data.text, value: data.value };
    dataItem.SalesPriority = data.text;
    this.editService.update(dataItem, "");
  }

  dataItembuildStyleSelectionChange(data, id, dataItem) {
    this.buildStyleGridValue = { text: data.text, value: data.value };
    dataItem.buildStyleId = data.value;
    this.editService.update(dataItem, "Adjust Module");
  }

  dataItembuildScheduleSelectionChange(data, id, dataItem: ModuleGrid) {
    this.buildScheduleGridValue = { text: data.text, value: data.value };
    dataItem.buildScheduleId = data.value;
    this.editService.update(dataItem, "Adjust Module");
  }
  dataItembuildTypeSelectionChange(data, id, dataItem: ModuleGrid) {
    this.buildTypeGridValue = { text: data.text, value: data.value };
    dataItem.buildTypeName = data.text;
    dataItem.buildTypeID = parseInt(data.value);
    this.editService.update(dataItem, "Adjust Module");
  }
  noCapacityCheckedChanged(data) {
    if (data.NoCapacity == true) {
      data.DisabledNoCapacity = true;
    }
  }
  getNoCapacityBackgroundColor(data: ModuleGrid) {
    if (data.noCapacity == true) {
      return "noCapacityClass";
    } else {
      return "capacityClass";
    }
  }
  checkPSNorBEN(psn) {
    this.adjustModuleService
      .getpsnbenexists(this.site?.plantId, psn)
      .subscribe((res) => {
        if (res.exist == 1) {
          this.showValidationErrorMsg = true;
          this.showPSNorBENerr = true;
        } else {
          this.showValidationErrorMsg = false;
          this.showPSNorBENerr = false;
        }
      });
  }
  disableAddButtonValidation() {
    if (
      this.buildStyleValue["text"].toString() === "Pilot Build" ||
      this.buildStyleValue["text"].toString() === "Cell Fusion"
    ) {
      if (
        this.buildScheduleValue === undefined ||
        this.buildScheduleValue["text"].toString() === "" ||
        this.toolTypeValue === undefined ||
        this.toolTypeValue["text"].toString() === "" ||
        this.pilotSerialNumberValue === undefined ||
        this.pilotSerialNumberValue === "" ||
        this.productTypeValue === undefined ||
        this.productTypeValue["text"].toString() === ""
      ) {
        this.disableAddButton2 = true;
        this.showValidationErrorMsg = true;
      } else {
        this.disableAddButton2 = false;
        this.showValidationErrorMsg = false;
        this.checkPSNorBEN(this.pilotSerialNumberValue);
      }
    } else if (this.buildStyleValue["text"].toString() === "Rework PO") {
      if (
        this.buildScheduleValue === undefined ||
        this.buildScheduleValue["text"].toString() === "" ||
        this.currentPartNumberValue === "" ||
        this.newPartNumberValue === "" ||
        this.reworkPOValue === "" ||
        (this.site?.plantName !== "Fremont" &&
          (this.buildingValue === undefined ||
            this.buildingValue["text"].toString() === ""))
      ) {
        this.disableAddButton2 = true;
        this.showValidationErrorMsg = true;
      } else {
        this.disableAddButton2 = false;
        this.showValidationErrorMsg = false;
        this.checkPSNorBEN(this.reworkPOValue);
      }
    } else if (
      this.buildStyleValue["text"].toString() === "Value Added Build"
    ) {
      this.setBuildTypeValue();
      if (
        this.buildScheduleValue === undefined ||
        this.buildScheduleValue["text"].toString() === "" ||
        this.pilotSerialNumberValue === undefined ||
        this.pilotSerialNumberValue === "" ||
        this.buildTypeValue === undefined ||
        this.buildTypeValue["text"].toString() === "" ||
        (this.site?.plantName !== "Fremont" &&
          (this.buildingValue === undefined ||
            this.buildingValue["text"].toString() === ""))
      ) {
        this.disableAddButton2 = true;
        this.showValidationErrorMsg = true;
      } else {
        this.disableAddButton2 = false;
        this.showValidationErrorMsg = false;
        this.checkPSNorBEN(this.pilotSerialNumberValue);
      }
    }
    if (this.buildStyleValue["text"].toString() === "Reconfig") {
      if (
        this.buildScheduleValue === undefined ||
        this.buildScheduleValue["text"].toString() === "" ||
        this.toolTypeValue === undefined ||
        this.toolTypeValue["text"].toString() === "" ||
        this.pilotSerialNumberValue === undefined ||
        this.pilotSerialNumberValue === "" ||
        this.productTypeValue === undefined ||
        this.productTypeValue["text"].toString() === "" ||
        (this.POValue === undefined &&
          this.site.plantName === "Tualatin") ||
        (this.POValue === "" && this.site.plantName === "Tualatin") ||
        (this.addPOValue === undefined &&
          this.site.plantName === "Fremont") ||
        (this.addPOValue === "" && this.site.plantName === "Fremont") ||
        (this.deletePOValue === undefined &&
          this.site.plantName === "Fremont") ||
        (this.deletePOValue === "" &&
          this.site.plantName === "Fremont") ||
        this.benReconfiguredFromValue === undefined ||
        this.benReconfiguredFromValue === ""
      ) {
        this.disableAddButton2 = true;
        this.showValidationErrorMsg = true;
      } else {
        this.disableAddButton2 = false;
        this.showValidationErrorMsg = false;
        this.checkPSNorBEN(this.pilotSerialNumberValue);
      }
    }
  }

  onBlurCheckValidation() {
    this.disableAddButtonValidation();
  }
  getHexColorValue(color) {
    let hexVal = "";
    this.capacityPlanningColorHex.forEach((val) => {
      if (val.text.trim() == color.trim()) hexVal = val.value;
    });
    return hexVal;
  }
  getColorFromHexValue(color) {
    let colorVal = "";
    this.capacityPlanningColorHex.forEach((val) => {
      if (val.value.trim() == color.trim()) colorVal = val.text;
    });
    return colorVal;
  }
  getDiasbledDates() {
    for (let i = 1; i <= 1000; i++) {
      const dateN = moment(new Date()).subtract(i, "days").toDate();
      this.disabledDates.push(dateN);
    }
    return this.disabledDates;
  }
  toggleNoCapacity(dataItem: ModuleGrid) {
    dataItem.noCapacity = !dataItem.noCapacity;
    if (dataItem.noCapacity) {
      dataItem.baysRequiredSubassembly = 0;
      dataItem.totalAssemblyHours = 0;
      dataItem.technicianRequiredSubassembly = 0;

      dataItem.baysRequiredIntegration = 0;
      dataItem.totalIntegrationHours = 0;
      dataItem.technicianRequiredIntegration = 0;

      dataItem.baysRequiredForTest = 0;
      dataItem.totalTestHours = 0;
      dataItem.technicianRequiredTest = 0;

      dataItem.baysRequiredPostTest = 0;
      dataItem.totalPostTestHours = 0;
      dataItem.technicianRequiredPostTest = 0;

      dataItem.totalLaborHour = 0;
      this.editCapacity = false;
    }
    this.editService.update(dataItem, "Adjust Module");
  }
  public rowCallback(context: RowClassArgs) {
    const dataset = context.dataItem;
    const NoCapVal = dataset["noCapacity"] || false;
    return {
      NoCapClass: NoCapVal,
    };
  }
  public onToggleProductType(): void {
    this.showProductType = !this.showProductType;
    this.showBuildType = false;
    this.showToolType = false;
    this.showcustomer = false;
    this.buildTypeData = this.tempBuildTypeData;
    this.toolTypeData = this.tempToolTypeData;
    this.customerData = this.tempCustomerData;
  }
  public onToggleBuildType(): void {
    this.showBuildType = !this.showBuildType;
    this.showProductType = false;
    this.showToolType = false;
    this.showcustomer = false;
    this.productTypeData = this.tempProductTypeData;
    this.toolTypeData = this.tempToolTypeData;
    this.customerData = this.tempCustomerData;
  }
  public onToggleToolType(): void {
    this.showToolType = !this.showToolType;
    this.showProductType = false;
    this.showBuildType = false;
    this.showcustomer = false;
    this.productTypeData = this.tempProductTypeData;
    this.buildTypeData = this.tempBuildTypeData;
    this.customerData = this.tempCustomerData;
  }
  public onToggleCustomer(): void {
    this.showcustomer = !this.showcustomer;
    this.showProductType = false;
    this.showBuildType = false;
    this.showToolType = false;
    this.productTypeData = this.tempProductTypeData;
    this.buildTypeData = this.tempBuildTypeData;
    this.toolTypeData = this.tempToolTypeData;
  }

  handleProductTypeFilter(value) {
    this.productTypeData = this.tempProductTypeData.filter(
      (s) => s?.text?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
    );
  }
  handleBuildTypeFilter(value) {
    this.buildTypeData = this.tempBuildTypeData.filter(
      (s) => s?.text?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
    );
  }
  handleToolTypeFilter(value) {
    this.toolTypeData = this.tempToolTypeData.filter(
      (s) => s?.text?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
    );
  }
  handleCustomerFilter(value) {
    this.customerData = this.tempCustomerData.filter(
      (s) => s?.text?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
    );
  }

  public exportToExcel(grid: GridComponent): void {
    grid.saveAsExcel();
  }
  public exportToPDF(grid: GridComponent): void {
    grid.saveAsPDF();
  }
  public distinctPrimitiveFilter(fieldName: string): any {
    let data: any;
    if (fieldName === "scheduleStatus") {
      data = [
        { text: "New", value: "New" },
        { text: "Changed", value: "Changed" },
        { text: "Dropped", value: "Dropped" },
        { text: "Shipped/Crated", value: "Shipped/Crated" },
        { text: null, value: null },
      ];
    } else {
      data = distinct(this.gridData, fieldName)
        .map((item) => item[fieldName])
        .map((val) => ({ text: val, value: val }));
    }
    data.forEach((item) => {
      if (item.value === "") item.text = "BLANK";
      else if (item.value === null) {
        item.text = "NULL";
      }
    });
    data.sort(function (a, b) {
      const textA = a?.text.toUpperCase();
      const textB = b?.text.toUpperCase();
      return textA < textB ? -1 : textA > textB ? 1 : 0;
    });
    return data;
  }
  public filterChange(filter: CompositeFilterDescriptor): void {
    this.filter = filter;
    this.gridData = filterBy(this.gridFilteredData, filter);

    Array.from(this.binding)[0].skip = 0;
  }
  onSearchToolType(value: string) {
    this.searchToolTypeValue = value;
  }

  public allData(): ExcelExportData {
    const result: ExcelExportData = {
      data: process(this.gridData, this.state).data,
    };
    return result;
  }
  onChangeSubassyBays(e, dataItem: ModuleGrid) {
    if (+e < 0 || +e > 9 || +e % 1 != 0) {
      this.showError("Please enter integer value between 0 and 9");
      return;
    }
    dataItem.baysRequiredSubassembly = +e;
    this.createFormGroup(dataItem);
  }
  onChangeSubassyHrs(e, dataItem: ModuleGrid) {
    if (+e < 0 || +e > 9999 || +e % 1 != 0) {
      this.showError("Please enter integer value between 0 and 9999");
      return;
    }
    dataItem.totalAssemblyHours = +e;
    this.createFormGroup(dataItem);
  }
  onChangeSubassyTechs(e, dataItem: ModuleGrid) {
    if (+e < 0 || +e > 9 || +e % 1 != 0) {
      this.showError("Please enter integer value between 0 and 9");
      return;
    }
    dataItem.technicianRequiredSubassembly = +e;
    this.createFormGroup(dataItem);
  }

  onChangeIntegrationBays(e, dataItem: ModuleGrid) {
    if (+e < 0 || +e > 9 || +e % 1 != 0) {
      this.showError("Please enter integer value between 0 and 9");
      return;
    }
    dataItem.baysRequiredIntegration = +e;
    this.createFormGroup(dataItem);
  }
  onChangeIntegrationHrs(e, dataItem: ModuleGrid) {
    if (+e < 0 || +e > 9999 || +e % 1 != 0) {
      this.showError("Please enter integer value between 0 and 9999");
      return;
    }
    dataItem.totalIntegrationHours = +e;
    this.createFormGroup(dataItem);
  }
  onChangeIntegrationTechs(e, dataItem: ModuleGrid) {
    if (+e < 0 || +e > 9 || +e % 1 != 0) {
      this.showError("Please enter integer value between 0 and 9");
      return;
    }
    dataItem.technicianRequiredIntegration = +e;
    this.createFormGroup(dataItem);
  }

  onChangeTestBays(e, dataItem: ModuleGrid) {
    if (+e < 0 || +e > 9 || +e % 1 != 0) {
      this.showError("Please enter integer value between 0 and 9");
      return;
    }
    dataItem.baysRequiredForTest = +e;
    this.createFormGroup(dataItem);
  }
  onChangeTestHrs(e, dataItem: ModuleGrid) {
    if (+e < 0 || +e > 9999 || +e % 1 != 0) {
      this.showError("Please enter integer value between 0 and 9999");
      return;
    }
    dataItem.totalTestHours = +e;
    this.createFormGroup(dataItem);
  }
  onChangeTestTechs(e, dataItem: ModuleGrid) {
    if (+e < 0 || +e > 9 || +e % 1 != 0) {
      this.showError("Please enter integer value between 0 and 9");
      return;
    }
    dataItem.technicianRequiredTest = +e;
    this.createFormGroup(dataItem);
  }

  onChangePostTestBays(e, dataItem: ModuleGrid) {
    if (+e < 0 || +e > 9 || +e % 1 != 0) {
      this.showError("Please enter integer value between 0 and 9");
      return;
    }
    dataItem.baysRequiredPostTest = +e;
    this.createFormGroup(dataItem);
  }
  onChangePostTestHrs(e, dataItem: ModuleGrid) {
    if (+e < 0 || +e > 9999 || +e % 1 != 0) {
      this.showError("Please enter integer value between 0 and 9999");
      return;
    }
    dataItem.totalPostTestHours = +e;
    this.createFormGroup(dataItem);
  }
  onChangePostTestTechs(e, dataItem: ModuleGrid) {
    if (+e < 0 || +e > 9 || +e % 1 != 0) {
      this.showError("Please enter integer value between 0 and 9");
      return;
    }
    dataItem.technicianRequiredPostTest = +e;
    this.createFormGroup(dataItem);
  }

  public onExcelExport(e: any): void {
    const rows = e.workbook.sheets[0].rows;

    rows.forEach((row, rowIndex) => {
      const currentItem = this.gridData[rowIndex - 1];

      if (row.type === "header") {
        row.cells.forEach((cell, index) => {
          if (cell.value === "Daily Hours/Tech") {
            this.colIndex = index;
          }
          if (cell.value === "Build Style") {
            this.colIndex2 = index;
          }
          if (cell.value === "Color") {
            this.colIndex3 = index;
          }
          if (cell.value === "Earliest Allowed Launch Date") {
            this.colIndex4 = index;
          }
          if (cell.value === "Material Readiness") {
            this.colIndex5 = index;
          }
          if (cell.value === "POA BOM Release Date") {
            this.colIndex6 = index;
          }
          if (cell.value === "Tranisition Date") {
            this.colIndex7 = index;
          }
          if (cell.value === "Committed Launch") {
            this.colIndex8 = index;
          }
          if (cell.value === "Committed Integration") {
            this.colIndex9 = index;
          }
          if (cell.value === "Committed Test Start") {
            this.colIndex10 = index;
          }
          if (cell.value === "Committed Mfg Complete") {
            this.colIndex11 = index;
          }
          if (cell.value === "Pilot MCSD") {
            this.colIndex12 = index;
          }
          if (cell.value === "SAP MCSD") {
            this.colIndex13 = index;
          }
          if (cell.value === "TSD") {
            this.colIndex14 = index;
          }
          if (cell.value === "POR") {
            this.colIndex15 = index;
          }
          if (cell.value === "CRD") {
            this.colIndex16 = index;
          }
          if (cell.value === "SRD") {
            this.colIndex17 = index;
          }
        });
      }

      // Use the column index to determine the content of the Total Price cell value
      if (row.type === "data") {
        row.cells.forEach((cell, index) => {
          if (index == this.colIndex) {
            cell.value =
              this.getTextFromValue(
                this.buildScheduleItems,
                currentItem.buildScheduleId
              ) != ""
                ? +this.getTextFromValue(
                  this.buildScheduleItems,
                  currentItem.buildScheduleId
                )
                : null;
          }
          if (index == this.colIndex2) {
            cell.value = this.getTextFromValue(
              this.buildStyleItems,
              currentItem.buildStyleId
            );
          }
          if (index == this.colIndex3) {
            cell.value = this.getTextFromValue(
              this.capacityPlanningColorHex,
              currentItem.capacityPlanningColor
            );
          }
          if (index == this.colIndex4) {
            cell.value =
              currentItem.earliestStartDate != null
                ? moment(currentItem.earliestStartDate).format(
                  "M-D-YY"
                )
                : null;
          }
          if (index == this.colIndex5) {
            cell.value =
              currentItem.materialReadiness != null
                ? moment(currentItem.materialReadiness).format(
                  "M-D-YY"
                )
                : null;
          }
          if (index == this.colIndex6) {
            cell.value =
              currentItem.poabomReleaseDate != null
                ? moment(currentItem.poabomReleaseDate).format(
                  "M-D-YY"
                )
                : null;
          }
          if (index == this.colIndex7) {
            cell.value =
              currentItem.transitionDate != null
                ? moment(currentItem.transitionDate).format(
                  "M-D-YY"
                )
                : null;
          }
          if (index == this.colIndex8) {
            cell.value =
              currentItem.commitLaunch != null
                ? moment(currentItem.commitLaunch).format(
                  "M-D-YY"
                )
                : null;
          }
          if (index == this.colIndex9) {
            cell.value =
              currentItem.committedIntegrationStart != null
                ? moment(
                  currentItem.committedIntegrationStart
                ).format("M-D-YY")
                : null;
          }
          if (index == this.colIndex10) {
            cell.value =
              currentItem.commitTestStart != null
                ? moment(currentItem.commitTestStart).format(
                  "M-D-YY"
                )
                : null;
          }
          if (index == this.colIndex11) {
            cell.value =
              currentItem.commitManufacturingComplete != null
                ? moment(
                  currentItem.commitManufacturingComplete
                ).format("M-D-YY")
                : null;
          }
          if (index == this.colIndex12) {
            cell.value =
              currentItem.pilotMCSD != null
                ? moment(currentItem.pilotMCSD).format("M-D-YY")
                : null;
          }
          if (index == this.colIndex13) {
            cell.value =
              currentItem.sapMCSD != null
                ? moment(currentItem.sapMCSD).format("M-D-YY")
                : null;
          }
          if (index == this.colIndex14) {
            cell.value =
              currentItem.tsd != null
                ? moment(currentItem.tsd).format("M-D-YY")
                : null;
          }
          if (index == this.colIndex15) {
            cell.value =
              currentItem.planofRecord != null
                ? moment(currentItem.planofRecord).format(
                  "M-D-YY"
                )
                : null;
          }
          if (index == this.colIndex16) {
            cell.value =
              currentItem.crd != null
                ? moment(currentItem.crd).format("M-D-YY")
                : null;
          }
          if (index == this.colIndex17) {
            cell.value =
              currentItem.srd != null
                ? moment(currentItem.srd).format("M-D-YY")
                : null;
          }
        });
      }
    });
  }
  dataItemScheduleStatusChange(data, dataItem: ModuleGrid) {
    dataItem.scheduleStatus = data.optionName;
    dataItem.scheduleStatusId = data.scheduleStatusId;
    this.editService.update(dataItem, "Adjust Module");
  }

  openEditDemand(dataItem: ModuleGrid) {
    this.standardBuild =
      this.getBuildStyleValue(dataItem.buildStyleId).toUpperCase() ===
        "SPECIAL SUBASSEMBLY"
        ? false
        : true;
    this.editedDataItem = dataItem;
    this.adjustModuleService
      .getDemandRequirements(dataItem.pilotProductID)
      .subscribe((res) => {
        if (res) {
          this.editOpened = true;
          this.editedDataItem.pilotSerialNumber =
            res.pilotSerialNumber;
          this.editedDataItem.ben = res.ben;
          this.editedDataItem.productGroupName = res.productGroupName;
          this.editedDataItem.toolTypeName = res.toolTypeName;
          this.editedBuildScheduleValue = {
            text: this.getTextFromValue(
              this.buildScheduleItems,
              res.buildScheduleId
            ),
            value: res.buildScheduleId,
          };
          if (
            this.getBuildStyleValue(
              dataItem.buildStyleId
            ).toUpperCase() == "REWORK PO"
          ) {
            this.demandRequirementsGridData = [];
            const drSubAssembly: DemandRequirements = {
              Process: "Subassembly",
              CalenderDays: res.calendarDaysSubAssembly,
              Bays: res.baysRequiredSubassembly,
              LaborHours: res.totalAssemblyHours,
              Techs: res.technicianRequiredSubassembly,
            };
            this.demandRequirementsGridData.push(drSubAssembly);
          } else {
            this.demandRequirementsGridData = [];
            const drSubAssembly: DemandRequirements = {
              Process: "Subassembly",
              CalenderDays: res.calendarDaysSubAssembly,
              Bays: res.baysRequiredSubassembly,
              LaborHours: res.totalAssemblyHours,
              Techs: res.technicianRequiredSubassembly,
            };
            const drIntegration: DemandRequirements = {
              Process: "Integration",
              CalenderDays: res.calendarDaysIntegration,
              Bays: res.baysRequiredIntegration,
              LaborHours: res.totalIntegrationHours,
              Techs: res.technicianRequiredIntegration,
            };
            const drTest: DemandRequirements = {
              Process: "Test",
              CalenderDays: res.calendarDaysTest,
              Bays: res.baysRequiredForTest,
              LaborHours: res.totalTestHours,
              Techs: res.technicianRequiredTest,
            };
            const drPostTest: DemandRequirements = {
              Process: "Post-Test",
              CalenderDays: res.calendarDaysPostTest,
              Bays: res.baysRequiredPostTest,
              LaborHours: res.totalPostTestHours,
              Techs: res.technicianRequiredPostTest,
            };
            this.demandRequirementsGridData.push(drSubAssembly);
            this.demandRequirementsGridData.push(drIntegration);
            this.demandRequirementsGridData.push(drTest);
            this.demandRequirementsGridData.push(drPostTest);
          }
        }
      });
  }

  closeEdit() {
    this.editOpened = false;
    this.showDemandReqErrMsg = false;
    this.demandErrMsg = "";
    this.demandRequirementsGridData = [];
    this.editService.cancelDemandRequirementChanges();
    this.editedDataItem = new ModuleGrid();
  }

  updateDemandRequirements() {
    const editModule: UpdateModule = {
      PilotProductID: this.editedDataItem.pilotProductID,
      BuildScheduleId: this.editedBuildScheduleValue.value,
      BaysRequiredSubassembly:
        this.demandRequirementsGridData[0] != undefined
          ? this.demandRequirementsGridData[0].Bays
          : null,
      TotalAssemblyHours:
        this.demandRequirementsGridData[0] != undefined
          ? this.demandRequirementsGridData[0].LaborHours
          : null,
      TechnicianRequiredSubassembly:
        this.demandRequirementsGridData[0] != undefined
          ? this.demandRequirementsGridData[0].Techs
          : null,
      BaysRequiredIntegration:
        this.demandRequirementsGridData[1] != undefined
          ? this.demandRequirementsGridData[1].Bays
          : null,
      TotalIntegrationHours:
        this.demandRequirementsGridData[1] != undefined
          ? this.demandRequirementsGridData[1].LaborHours
          : null,
      TechnicianRequiredIntegration:
        this.demandRequirementsGridData[1] != undefined
          ? this.demandRequirementsGridData[1].Techs
          : null,
      BaysRequiredForTest:
        this.demandRequirementsGridData[2] != undefined
          ? this.demandRequirementsGridData[2].Bays
          : null,
      TotalTestHours:
        this.demandRequirementsGridData[2] != undefined
          ? this.demandRequirementsGridData[2].LaborHours
          : null,
      TechnicianRequiredTest:
        this.demandRequirementsGridData[2] != undefined
          ? this.demandRequirementsGridData[2].Techs
          : null,
      BaysRequiredPostTest:
        this.demandRequirementsGridData[3] != undefined
          ? this.demandRequirementsGridData[3].Bays
          : null,
      TotalPostTestHours:
        this.demandRequirementsGridData[3] != undefined
          ? this.demandRequirementsGridData[3].LaborHours
          : null,
      TechnicianRequiredPostTest:
        this.demandRequirementsGridData[3] != undefined
          ? this.demandRequirementsGridData[3].Techs
          : null,
      ModuleProcessSubassembly: "Subassembly",
      ModuleProcessIntegration: "Integration",
      ModuleProcessTest: "Test",
      ModuleProcessPostTest: "Post-test",

      PlantName: this.site.plantName,
      FCID: this.editedDataItem.fcid,
      PilotRisk: this.editedDataItem.pilotRisk,
      PilotSerialNumber: this.editedDataItem.pilotSerialNumber,
      BuildStyleId: this.editedDataItem.buildStyleId,
      NoCapacity: this.editedDataItem.noCapacity,
      RecordType: this.editedDataItem.recordType,
      RevenueCode: this.editedDataItem.revenueCode,
      ProductGroupName: this.editedDataItem.productGroupName,
      ToolTypeName: this.editedDataItem.toolTypeName,
      PilotToolType: this.editedDataItem.pilotToolType,
      BuildTypeId: this.editedDataItem.buildTypeID,
      BaysRequired: 0,
      TotalLaborHour: this.editedDataItem.totalLaborHour,

      //Dates
      PriorityDate: null,
      EarliestStartDate:
        this.editedDataItem.earliestStartDate != null
          ? moment(this.editedDataItem.earliestStartDate).format(
            "yyyy-MM-DD"
          )
          : null,
      MaterialReadiness:
        this.editedDataItem.materialReadiness != null
          ? moment(this.editedDataItem.materialReadiness).format(
            "yyyy-MM-DD"
          )
          : null,
      ActualDMRF: null,
      ActualShipDate:
        this.editedDataItem.transitionDate != null
          ? moment(this.editedDataItem.transitionDate).format(
            "yyyy-MM-DD"
          )
          : null, //Actual Ship date-->transistion date
      CommitLaunch:
        this.editedDataItem.commitLaunch != null
          ? moment(this.editedDataItem.commitLaunch).format(
            "yyyy-MM-DD"
          )
          : null,
      CommittedIntegrationStart:
        this.editedDataItem.committedIntegrationStart != null
          ? moment(
            this.editedDataItem.committedIntegrationStart
          ).format("yyyy-MM-DD")
          : null,
      CommitTestStart:
        this.editedDataItem.commitTestStart != null
          ? moment(this.editedDataItem.commitTestStart).format(
            "yyyy-MM-DD"
          )
          : null,
      CommitManufacturingComplete:
        this.editedDataItem.commitManufacturingComplete != null
          ? moment(
            this.editedDataItem.commitManufacturingComplete
          ).format("yyyy-MM-DD")
          : null,
      CRD:
        this.editedDataItem.crd != null
          ? moment(this.editedDataItem.crd).format("yyyy-MM-DD")
          : null,
      SRD:
        this.editedDataItem.srd != null
          ? moment(this.editedDataItem.srd).format("yyyy-MM-DD")
          : null,
      PilotMCSD:
        this.editedDataItem.pilotMCSD != null
          ? moment(this.editedDataItem.pilotMCSD).format("yyyy-MM-DD")
          : null,
      SapMCSD:
        this.editedDataItem.sapMCSD != null
          ? moment(this.editedDataItem.sapMCSD).format("yyyy-MM-DD")
          : null,
      TSD:
        this.editedDataItem.tsd != null
          ? moment(this.editedDataItem.tsd).format("yyyy-MM-DD")
          : null,
      PlanofRecord:
        this.editedDataItem.planofRecord != null
          ? moment(this.editedDataItem.planofRecord).format(
            "yyyy-MM-DD"
          )
          : null,
      POABOMReleaseDate:
        this.editedDataItem.poabomReleaseDate != null
          ? moment(this.editedDataItem.poabomReleaseDate).format(
            "yyyy-MM-DD"
          )
          : null,
      SalesPriority:
        this.editedDataItem.salesPriority != null
          ? this.editedDataItem.salesPriority.toString()
          : null,
      CRDEsc: this.editedDataItem.crdEsc,

      SchedulingColor: this.editedDataItem.schedulingColor,
      CapacityPlanningColor: this.editedDataItem.capacityPlanningColor,
      Notes: this.editedDataItem.notes,
      ScheduleStatus: this.editedDataItem.scheduleStatus,
      ScheduleStatusId: this.editedDataItem.scheduleStatusId,
      ModifiedBy: this.userDetail?.userId,
      ModifiedOn: new Date(
        new Date().getTime() - new Date().getTimezoneOffset() * 60000
      ),
    };

    this.adjustModuleService
      .updateDemandRequirements(
        this.editedDataItem.pilotProductID,
        editModule
      )
      .subscribe((res) => {
        if (res)
          //Reset the form
          this.closeEdit();
        this.fillAdjustModulesGrid();
      });
  }
  changeCRDDate(value: Date) {
    this.minDate.setHours(0, 0, 0, 0);
    if (value?.getTime() < this.minDate?.getTime()) {
      this.crdDateError = true;
    } else {
      this.crdDateError = false;
    }
  }
  changePORDate(value: Date) {
    this.minDate.setHours(0, 0, 0, 0);
    if (value?.getTime() < this.minDate?.getTime()) {
      this.porDateError = true;
    } else {
      this.porDateError = false;
    }
  }
  changeLaunchDate(value: Date) {
    this.minDate.setHours(0, 0, 0, 0);
    if (value?.getTime() < this.minDate?.getTime()) {
      this.committedDateError = true;
    } else {
      this.committedDateError = false;
    }
  }

  onPOBlur() {
    if (this.POValue) {
      this.adjustModuleService.getAddPO(this.POValue).subscribe((res) => {
        this.addPOValue = res;
      });
      this.adjustModuleService
        .getDeletePO(this.POValue)
        .subscribe((res) => {
          this.deletePOValue = res;
        });
    }
  }
}
