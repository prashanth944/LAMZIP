export interface UpdateModule {
    PlantName: string;
    PilotProductID: number | undefined;
    FCID: string;
    PilotRisk: string;
    PilotSerialNumber: string;
    BuildStyleId: number | undefined;
    BuildScheduleId: number | undefined;
    NoCapacity: boolean | undefined;
    RecordType: string;
    RevenueCode: string;
    ProductGroupName: string;
    ToolTypeName: string;
    PilotToolType: string;
    BuildTypeId: number;
    BaysRequired: number | undefined;

    BaysRequiredSubassembly: number | undefined;
    TotalAssemblyHours: number | undefined;
    TechnicianRequiredSubassembly: number | undefined;

    BaysRequiredIntegration: number | undefined;
    TotalIntegrationHours: number | undefined;
    TechnicianRequiredIntegration: number | undefined;

    BaysRequiredForTest: number | undefined;
    TotalTestHours: number | undefined;
    TechnicianRequiredTest: number | undefined;

    BaysRequiredPostTest: number | undefined;
    TotalPostTestHours: number | undefined;
    TechnicianRequiredPostTest: number | undefined;

    TotalLaborHour: number | undefined;

    //Dates
    PriorityDate: string;
    EarliestStartDate: string;
    MaterialReadiness: string;
    ActualDMRF: string;
    ActualShipDate: string; //Transistion date
    CommitLaunch: string;
    CommittedIntegrationStart: string;
    CommitTestStart: string;
    CommitManufacturingComplete: string;
    CRD: string;
    SRD: string;
    PilotMCSD: string; //PilotManufacturingCommitedShipDate
    SapMCSD: string; //ManufacturingCommitedShipDate
    TSD: string;
    POABOMReleaseDate: string;
    PlanofRecord: string;

    SalesPriority: string;
    CRDEsc: boolean | undefined;

    SchedulingColor: string;
    CapacityPlanningColor: string;
    Notes: string;

    ModuleProcessSubassembly: string;
    ModuleProcessIntegration: string;
    ModuleProcessTest: string;
    ModuleProcessPostTest: string;
    ModifiedBy: number;
    ModifiedOn: Date;
    ScheduleStatus: string;
    ScheduleStatusId: number;
}
