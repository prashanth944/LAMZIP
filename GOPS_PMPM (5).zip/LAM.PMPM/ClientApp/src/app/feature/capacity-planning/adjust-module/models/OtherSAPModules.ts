export class OtherSAPModules {
    pilotProductID: number;
    fcid: string;
    ben: string;
    recordType: string;
    revenueCode: string;
    productGroupID: number;
    productGroupName: string;
    toolTypeID: number;
    toolTypeName: string;
    tsd: string;
    crd: string;
    srd: string;
    mcsd: string;
    lprid: string;
}
