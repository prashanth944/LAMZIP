import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { AppStoreService } from '../../core/app-store.service';
import { uiScreen } from '../../core/model/common.constant';

@Component({
    selector: 'pmpm-capacity-planning',
    templateUrl: './capacity-planning.component.html',
  styleUrls: ['./capacity-planning.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class CapcityPlanningComponent implements OnInit{
  userRoles: string[] = [];
  isUserAccess = false;
  isLoading = true;

  constructor(private appStoreService: AppStoreService) { }

  ngOnInit() {
    this.userRoles = [];
      this.appStoreService.getUserRoles().subscribe(res => {
        if (res && res.length > 0) {
          this.userRoles = res;
          this.appStoreService.checkUserAccessRight(this.userRoles, uiScreen.CP).subscribe(result => {
            this.isUserAccess = result;
            this.isLoading = false;
          });
        }
      });
    }   
}
