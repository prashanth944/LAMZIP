import {
    Component,
    OnDestroy,
    OnInit,
    ViewChild,
    ViewEncapsulation,
} from "@angular/core";
import { DomSanitizer, SafeStyle } from "@angular/platform-browser";
import {
    filterBy,
    CompositeFilterDescriptor,
    distinct,
} from "@progress/kendo-data-query";
import { DatePipe } from "@angular/common";
import { dayWeek } from "./bay-day-week-model";
import { DataBindingDirective } from "@progress/kendo-angular-grid";
import { AppStoreService } from "../../../../core/app-store.service";
import { BayService } from "./bay-service/bay.service";
import {
    BaySummary,
    BaySummaryByBaytype,
    BaySummaryStats,
} from "./models/baySummary";
import { BaySummaryDailyWeekly } from "./models/baySummaryDaily";
import { AddUpdateBayModel } from "./models/AddUpdateBayModel";
import * as moment from "moment";
import { Item } from "../../../model/item";
import { Subscription } from "rxjs";
import { Plant } from "../../../../core/model/user.model";
import { uiScreen } from "../../../../core/model/common.constant";

@Component({
    selector: "pmpm-bay",
    templateUrl: "./bay.component.html",
    styleUrls: ["./bay.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class BayComponent implements OnInit, OnDestroy {
    @ViewChild(DataBindingDirective, { static: true })
    dataBinding: DataBindingDirective;
    @ViewChild("list") list;

    public gridDataDailySummary: BaySummaryDailyWeekly[] = [];
    public gridDataDailySummaryTualatin: BaySummaryDailyWeekly[] = [];
    public gridDataWeeklySummary: BaySummaryDailyWeekly[] = [];
    public gridDataWeeklySummaryTualatin: BaySummaryDailyWeekly[] = [];
    public gridDataMonthlySummary: BaySummaryDailyWeekly[] = [];
    public gridDataMonthlySummaryTualatin: BaySummaryDailyWeekly[] = [];
    public filter: CompositeFilterDescriptor = undefined;
    public gridDataDailyDetails: BaySummaryDailyWeekly[] = [];
    public gridDataWeeklyDetails: BaySummaryDailyWeekly[] = [];
    public gridDataMonthlyDetails: BaySummaryDailyWeekly[] = [];

    public gridDataDaily: any[] = filterBy(
        this.gridDataDailyDetails,
        this.filter
    );
    public gridDataWeekly: any[] = filterBy(
        this.gridDataWeeklyDetails,
        this.filter
    );
    public gridDataMonthly: any[] = filterBy(
        this.gridDataWeeklyDetails,
        this.filter
    );

    public dailyView = false;
    dailyViewButtonText = "Switch to Daily";
    public editOpened = false;
    public addOpened = false;
    public deleteOpened = false;
    public deleteRowData: any;
    endDateError = false;

    public statusItems: Array<Item> = [];
    public bayTypeItems: Array<Item> = [];
    public productItems: Array<Item> = [];
    public buildingItems: Array<Item> = [];

    public dailyColumns2: dayWeek[] = [];
    public monthlyColumns2: dayWeek[] = [];

    public dailyColumnsSet: Set<Date> = new Set();
    public monthlyColumnsSet: Set<Date> = new Set();

    public columns: dayWeek[] = [];
    public columnsSet: Set<Date> = new Set();

    public value: Date = new Date();
    public value2: Date = new Date();
    public cellValue = -1;
    public previousCellValue = -1;

    loadSummary = true;
    loadDetails = true;

    private subscription: Subscription[] = [];
    // add bay model values
    bayIdValue: number;
    bayNameValue: string;
    bayNameValueForEdit: { text: ""; value: 0 };
    statusValue = { text: "", value: 0 };
    effectiveDateValue: Date = new Date();
    endDateValue: Date = undefined;
    bayAvailable = false;
    bayUnAvailable = false;
    bayTypeValue: { text: ""; value: 0 };
    productTypeValue: { text: ""; value: 0 };
    productTypeValues: any[];
    buildingValue: { text: ""; value: 0 };
    biggerEffectiveDateError = false;
    today = new Date();

    bayAvNotChecked = false;
    noEndDateChecked = false;
    public data: Array<Item> = [];

    public availabilityModel = {
        available: null,
    };

    addBay: AddUpdateBayModel;
    editBay: AddUpdateBayModel;
    site: Plant;

    // for API call
    baySummary: BaySummary;
    interval: string;
    public minEndDate = new Date();
    public minEffectiveDate = new Date();
    public isUserAccess = false;
    public timeViewList: Item[] = [
        { text: "Monthly", value: 2 },
        { text: "Weekly", value: 0 },
        { text: "Daily", value: 1 },
    ];
    public timeViewValue = { text: "Weekly", value: 0 };
    timeView = "Weekly";

    productTypeNotSelected = false;
    showValidationError = false;
    disableAdd = true;
    nameRequired = false;
    bayNameList: any[] = [];
    bayNameExists = false;

    minAvalibleDate = new Date(
        this.today.getFullYear() - 1,
        this.today.getMonth(),
        this.today.getDate()
    );

    maxAvalibleDate = new Date(
        this.today.getFullYear() + 2,
        this.today.getMonth(),
        this.today.getDate()
    );

    minDate = new Date(this.today.getTime());
    maxDate = new Date(this.today.getFullYear(), this.today.getMonth() + 4, 1);
    greaterEffectiveDateerror = false;
    columnHeaderBaySummaryStat: dayWeek[] = [];

    bayAssemblyIntegration: BaySummaryStats[] = [];
    bayIntegration: BaySummaryStats[] = [];
    bayTest: BaySummaryStats[] = [];
    baySummaryStats: BaySummaryStats[] = [];

    baySummaryByBaytype: BaySummaryByBaytype;

    loadStatGrid = true;

    constructor(
        private sanitizer: DomSanitizer,
        private appStoreService: AppStoreService,
        private bayService: BayService,
        private datePipe: DatePipe
    ) {
        this.data = this.productItems.slice();
    }

    ngOnInit() {
        this.today.setHours(0, 0, 0, 0);
        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.Bays)
                    .subscribe((result) => {
                        this.isUserAccess = result;
                    });
            }
        });
        this.subscription.push(
            this.appStoreService.getCurrentSite().subscribe((site) => {
                if (site) {
                    this.site = {
                        plantName: site.plantName,
                        plantId: site.plantId,
                  };

                    this.timeViewChange({ text: "Weekly" });
                    this.getBuilding();
                    this.bayService
                        .getProductType(this.site?.plantId)
                        .subscribe((pt) => {
                            pt.forEach((val) => {
                                const newPt: Item = {
                                    value: val.productGroupID,
                                    text: val.productName,
                                };
                                this.productItems.push(newPt);
                            });
                            this.data = this.productItems.slice();
                        });
                }
            })
        );
        this.subscription.push(
            this.bayService.getBayStatusDDL().subscribe((status) => {
                status.forEach((val) => {
                    const newStatus: Item = {
                        value: val.masterRecordID,
                        text: val.masterRecordName,
                    };
                    this.statusItems.push(newStatus);
                });
            })
        );

        this.subscription.push(
            this.bayService.getBayType().subscribe((bt) => {
                bt.forEach((val) => {
                    const newBt: Item = {
                        value: val.bayTypeID,
                        text: val.bayTypeName,
                    };
                    this.bayTypeItems.push(newBt);
                });
            })
        );
    }

    ngAfterViewInit() {
        window.addEventListener("scroll", this.scrollFixed);
    }

    private scrollFixed() {
        const grid = <HTMLElement>(
            document.querySelector(".bay-fixed-header-grid")
        );
        const header = <HTMLElement>(
            grid.querySelector(".bay-fixed-header-grid .k-grid-header")
        );

        const offset = window.scrollY - (10 / 100) * window.scrollY;
        const tableOffsetTop = grid.offsetTop;
        const tableOffsetBottom =
            tableOffsetTop + grid.clientHeight - header.clientHeight;

        if (offset < tableOffsetTop || offset > tableOffsetBottom) {
            header.classList.remove("fixed-header");
        } else if (offset >= tableOffsetTop && offset <= tableOffsetBottom) {
            header.classList.add("fixed-header");
            header.style.width = grid.clientWidth + "px";
        }
    }

    getBuilding() {
        this.buildingItems = [];
        this.subscription.push(
            this.bayService
                .getBuilding(this.site?.plantId)
                .subscribe((buildings) => {
                    buildings.forEach((val) => {
                        const newBuilding: Item = {
                            value: val.buildingID,
                            text: val.buildingName,
                        };
                        this.buildingItems.push(newBuilding);
                    });
                })
        );
    }

    getBaySummaryDetails() {
        this.gridDataDailySummary = [];
        this.gridDataDailySummaryTualatin = [];
        this.gridDataWeeklySummary = [];
        this.gridDataWeeklySummaryTualatin = [];
        this.gridDataMonthlySummary = [];
        this.gridDataMonthlySummaryTualatin = [];

        this.gridDataDailyDetails = [];
        this.gridDataWeeklyDetails = [];
        this.gridDataMonthlyDetails = [];

        this.filter = undefined;

        this.gridDataDaily = filterBy(this.gridDataDailyDetails, this.filter);
        this.gridDataWeekly = filterBy(this.gridDataWeeklyDetails, this.filter);
        this.gridDataMonthly = filterBy(
            this.gridDataMonthlyDetails,
            this.filter
        );

        this.loadDetails = true;
        this.loadSummary = true;
        // get bay summary
        if (this.timeView === "Weekly") {
            const minDateVla = moment(this.minDate).format("YYYY-MM-DD");
            const maxDateVla = moment(this.maxDate).format("YYYY-MM-DD");
            this.columnsSet = new Set();
            if (this.site.plantName === "Fremont") {
                this.subscription.push(
                    this.bayService
                        .getBaySummary(
                            "week",
                            this.site?.plantId,
                            minDateVla,
                            maxDateVla
                        )
                        .subscribe((baySum) => {
                            this.mapBaySummary(baySum, "week");
                            this.loadSummary = false;
                        })
                );
            } else {
                this.subscription.push(
                    this.bayService
                        .getBaySummaryTualatin(
                            "week",
                            this.site?.plantId,
                            minDateVla,
                            maxDateVla
                        )
                        .subscribe((baySum) => {
                            this.mapBaySummary(baySum, "week", "Tualatin");
                            this.loadSummary = false;
                        })
                );
            }
            this.subscription.push(
                this.bayService
                    .getBayDetails(
                        "week",
                        this.site?.plantId,
                        minDateVla,
                        maxDateVla
                    )
                    .subscribe((baySum) => {
                        this.mapBayDetails(baySum, "week");
                        this.loadDetails = false;
                        this.bayNameList =
                            this.distinctPrimitiveWeekly("BayName");
                    })
            );
        } else if (this.timeView === "Daily") {
            const minDateVla = moment(this.minDate).format("YYYY-MM-DD");
            const maxDateVla = moment(this.maxDate).format("YYYY-MM-DD");
            this.dailyColumnsSet = new Set();

            if (this.site.plantName === "Fremont") {
                this.subscription.push(
                    this.bayService
                        .getBaySummary(
                            "daily",
                            this.site?.plantId,
                            minDateVla,
                            maxDateVla
                        )
                        .subscribe((baySum) => {
                            this.mapBaySummary(baySum, "daily");
                            this.loadSummary = false;
                        })
                );
            } else {
                this.subscription.push(
                    this.bayService
                        .getBaySummaryTualatin(
                            "daily",
                            this.site?.plantId,
                            minDateVla,
                            maxDateVla
                        )
                        .subscribe((baySum) => {
                            this.mapBaySummary(baySum, "daily", "Tualatin");
                            this.loadSummary = false;
                        })
                );
            }
            this.subscription.push(
                this.bayService
                    .getBayDetails(
                        "daily",
                        this.site?.plantId,
                        minDateVla,
                        maxDateVla
                    )
                    .subscribe((baySum) => {
                        this.mapBayDetails(baySum, "daily");
                        this.loadDetails = false;
                        this.bayNameList =
                            this.distinctPrimitiveDaily("BayName");
                    })
            );
        } else if (this.timeView === "Monthly") {
            const minDateVla = moment(this.minDate).format("YYYY-MM-DD");
            const maxDateVla = moment(this.maxDate).format("YYYY-MM-DD");
            this.monthlyColumnsSet = new Set();

            if (this.site.plantName === "Fremont") {
                this.subscription.push(
                    this.bayService
                        .getBaySummary(
                            "month",
                            this.site?.plantId,
                            minDateVla,
                            maxDateVla
                        )
                        .subscribe((baySum) => {
                            this.mapBaySummary(baySum, "month");
                            this.loadSummary = false;
                        })
                );
            } else {
                this.subscription.push(
                    this.bayService
                        .getBaySummaryTualatin(
                            "month",
                            this.site?.plantId,
                            minDateVla,
                            maxDateVla
                        )
                        .subscribe((baySum) => {
                            this.mapBaySummary(baySum, "month", "Tualatin");
                            this.loadSummary = false;
                        })
                );
            }
            this.subscription.push(
                this.bayService
                    .getBayDetails(
                        "month",
                        this.site?.plantId,
                        minDateVla,
                        maxDateVla
                    )
                    .subscribe((baySum) => {
                        this.mapBayDetails(baySum, "month");
                        this.loadDetails = false;
                        this.bayNameList =
                            this.distinctPrimitiveMonthly("BayName");
                    })
            );
        }
    }

    mapBaySummary(baySummaryObj, interval: string, plant = "Fremont") {
        for (let i = 0; i < baySummaryObj.length; i++) {
            const baySummaryDailyWeekly: BaySummaryDailyWeekly = {
                Id: 0,
                BayName: "",
                BayType: baySummaryObj[i].BayDetails.Bay_Type,
                Building: baySummaryObj[i].BayDetails.Building_Name,
                ProductType: baySummaryObj[i].BayDetails.Product_Type,
                Status: baySummaryObj[i].BayDetails.Status,
                DayWeek: this.mapBayAvailabilityDaily(
                    baySummaryObj[i].DailyWeeklyDates,
                    interval,
                    i,
                    "summary"
                ),
            };
            if (interval === "daily" && plant === "Fremont") {
                this.gridDataDailySummary.push(baySummaryDailyWeekly);
            } else if (interval === "week" && plant === "Fremont") {
                this.gridDataWeeklySummary.push(baySummaryDailyWeekly);
            } else if (interval === "month" && plant === "Fremont") {
                this.gridDataMonthlySummary.push(baySummaryDailyWeekly);
            } else if (interval === "daily") {
                this.gridDataDailySummaryTualatin.push(baySummaryDailyWeekly);
            } else if (interval === "week") {
                this.gridDataWeeklySummaryTualatin.push(baySummaryDailyWeekly);
            } else {
                this.gridDataMonthlySummaryTualatin.push(baySummaryDailyWeekly);
            }
        }

        // set the columns
        let columns = Array.from(this.dailyColumnsSet);
        columns = columns.sort();
        this.dailyColumns2 = columns.map(
            (x) =>
                <dayWeek>{
                    title: this.datePipe.transform(x, "M-d-yy").toString(),
                }
        );

        let columns2 = Array.from(this.columnsSet);
        columns2 = columns2.sort();
        this.columns = columns2.map(
            (x) =>
                <dayWeek>{
                    title: this.datePipe.transform(x, "M-d-yy").toString(),
                }
        );

        let columns3 = Array.from(this.monthlyColumnsSet);
        columns3 = columns3.sort();
        this.monthlyColumns2 = columns3.map(
            (x) =>
                <dayWeek>{
                    title: this.datePipe.transform(x, "M-d-yy").toString(),
                }
        );
    }
    mapBayDetails(baySummaryObj, interval: string) {
        for (let i = 0; i < baySummaryObj.length; i++) {
            const baySummaryDailyWeekly: BaySummaryDailyWeekly = {
                Id: 0,
                BayName: baySummaryObj[i].BayDetails.Bay_Name,
                BayType: baySummaryObj[i].BayDetails.Bay_Type,
                Building: baySummaryObj[i].BayDetails.Building_Name,
                ProductType: baySummaryObj[i].BayDetails.Product_Type,
                Status: baySummaryObj[i].BayDetails.Status,
                DayWeek: this.mapBayAvailabilityDaily(
                    baySummaryObj[i].DailyWeeklyDates,
                    interval,
                    i,
                    "details"
                ),
            };
            if (interval == "daily") {
                this.gridDataDailyDetails.push(baySummaryDailyWeekly);
            } else if (interval == "week") {
                this.gridDataWeeklyDetails.push(baySummaryDailyWeekly);
            } else if (interval == "month") {
                this.gridDataMonthlyDetails.push(baySummaryDailyWeekly);
            }
        }

        // set the columns
        let columns = Array.from(this.dailyColumnsSet);
        columns = columns.sort();
        this.dailyColumns2 = columns.map(
            (x) =>
                <dayWeek>{
                    title: this.datePipe.transform(x, "M-d-yy").toString(),
                }
        );

        let columns2 = Array.from(this.columnsSet);
        columns2 = columns2.sort();
        this.columns = columns2.map(
            (x) =>
                <dayWeek>{
                    title: this.datePipe.transform(x, "M-d-yy").toString(),
                }
        );

        let columns3 = Array.from(this.monthlyColumnsSet);
        columns3 = columns3.sort();
        this.monthlyColumns2 = columns3.map(
            (x) =>
                <dayWeek>{
                    title: this.datePipe.transform(x, "M-d-yy").toString(),
                }
        );
    }

    evalValue(dictVal: any, col: any) {
        if (col.title in dictVal) {
            return dictVal[col.title];
        }
        return 0;
    }

    mapBayAvailabilityDaily(
        daysData: any,
        interval: string,
        rownum: number,
        summ: string
    ): {} {
        const daysDataArray = {};
        if (interval === "daily") {
            for (let i = 0; i < daysData.length; i++) {
                const c = daysData[i].Bays_Availablity;
                const title = this.datePipe
                    .transform(daysData[i].WeekStart, "M-d-yy")
                    .toString();
                daysDataArray[title] = c;
                this.dailyColumnsSet.add(daysData[i].WeekStart);
            }
        } else if (interval === "week") {
            for (let i = 0; i < daysData.length; i++) {
                const c = daysData[i].Bays_Availablity;
                const title = this.datePipe
                    .transform(daysData[i].WeekStart, "M-d-yy")
                    .toString();
                daysDataArray[title] = c;
                this.columnsSet.add(daysData[i].WeekStart);
            }
        } else if (interval === "month") {
            for (let i = 0; i < daysData.length; i++) {
                const c = daysData[i].Bays_Availablity;
                const title = this.datePipe
                    .transform(daysData[i].WeekStart, "M-d-yy")
                    .toString();
                daysDataArray[title] = c;
                this.monthlyColumnsSet.add(daysData[i].WeekStart);
            }
        }
        return daysDataArray;
    }

    onTabSelect(event: Event) {}

    closeEdit(status: string) {
        this.bayAvNotChecked = false;
        this.editOpened = false;
        this.endDateError = false;
        this.greaterEffectiveDateerror = false;
        this.resetAddBay();
    }

    openEdit(data) {
        this.minEndDate = new Date();
        this.editOpened = true;
        this.populateEditBay(data);
    }
    closeAdd(status: string) {
        this.bayAvNotChecked = false;
        this.addOpened = false;
        this.endDateError = false;
        this.bayNameExists = false;
        this.greaterEffectiveDateerror = false;
        this.resetAddBay();
    }

    openAdd() {
        this.minEndDate = new Date();
        this.addOpened = true;
    }

    public colorCode(val: any, i: number): SafeStyle {
        // i is the index of the Week array
        let result = "transparent";
        const cv = parseInt(val);
        if (this.previousCellValue != -1 && i != 0) {
            // cv = -1 for every ist cell value
            if (cv < this.previousCellValue) {
                result = "#FFBA80";
            } else if (cv > this.previousCellValue) {
                result = "#B2F699";
            }
        } else {
            this.previousCellValue = -1; // resetting the previous cell value to -1 for every new row
        }
        this.previousCellValue = cv;
        return this.sanitizer.bypassSecurityTrustStyle(result);
    }

    timeViewChange(view) {
        this.timeView = view.text;
        if (this.timeView === "Daily") {
            this.minDate = new Date(this.today.getTime());
            this.maxDate = new Date(
                this.today.getTime() + 1000 * 60 * 60 * 24 * 60
            );
            this.timeViewValue = { text: "Daily", value: 1 };
        } else if (this.timeView === "Weekly") {
            this.minDate = new Date(this.today.getTime());
            this.maxDate = new Date(this.today.getTime());
            this.maxDate.setMonth(this.maxDate.getMonth() + 6);
            this.timeViewValue = { text: "Weekly", value: 0 };
        } else if (this.timeView === "Monthly") {
            this.minDate = new Date(this.today.getTime());
            this.maxDate = new Date(this.today.getTime());
            this.maxDate.setFullYear(this.maxDate.getFullYear() + 1);
            this.timeViewValue = { text: "Monthly", value: 2 };
        }

        this.getBaySummaryDetails();
        this.GetBaysSummaryByBayType();
    }

    GetBaysSummaryByBayType() {
        this.loadStatGrid = true;
        const minDateVla = moment(this.minDate).format("YYYY-MM-DD");
        const maxDateVla = moment(this.maxDate).format("YYYY-MM-DD");
        this.bayAssemblyIntegration = [];
        this.bayIntegration = [];
        this.bayTest = [];
        this.baySummaryStats = [];
        this.columnHeaderBaySummaryStat = [];
        if (this.timeView === "Weekly") {
            this.bayService
                .GetBaysSummaryByBayType(
                    "week",
                    this.site?.plantId,
                    minDateVla,
                    maxDateVla
                )
                .subscribe((res) => {
                    if (res) {
                        this.baySummaryByBaytype = res;
                        this.bayAssemblyIntegration =
                            this.baySummaryByBaytype?.bayAssemblyIntegration;
                        this.mapBaysDateColumn(
                            this.bayAssemblyIntegration,
                            "Assy + Int"
                        );

                        this.bayIntegration =
                            this.baySummaryByBaytype?.bayIntegration;
                        this.mapBaysDateColumn(this.bayIntegration, "Int Only");

                        this.bayTest = this.baySummaryByBaytype?.bayTest;
                        this.mapBaysDateColumn(this.bayTest, "Test");

                        this.baySummaryStats.push(
                            this.bayAssemblyIntegration[0]
                        );
                        this.baySummaryStats.push(this.bayIntegration[0]);
                        this.baySummaryStats.push(this.bayTest[0]);
                    }
                    this.loadStatGrid = false;
                });
        }

        if (this.timeView === "Monthly") {
            this.bayService
                .GetBaysSummaryByBayType(
                    "month",
                    this.site?.plantId,
                    minDateVla,
                    maxDateVla
                )
                .subscribe((res) => {
                    if (res) {
                        this.baySummaryByBaytype = res;
                        this.bayAssemblyIntegration =
                            this.baySummaryByBaytype?.bayAssemblyIntegration;
                        this.mapBaysDateColumn(
                            this.bayAssemblyIntegration,
                            "Assy + Int"
                        );

                        this.bayIntegration =
                            this.baySummaryByBaytype?.bayIntegration;
                        this.mapBaysDateColumn(this.bayIntegration, "Int Only");

                        this.bayTest = this.baySummaryByBaytype?.bayTest;
                        this.mapBaysDateColumn(this.bayTest, "Test");

                        this.baySummaryStats.push(
                            this.bayAssemblyIntegration[0]
                        );
                        this.baySummaryStats.push(this.bayIntegration[0]);
                        this.baySummaryStats.push(this.bayTest[0]);
                    }
                    this.loadStatGrid = false;
                });
        }

        if (this.timeView === "Daily") {
            this.bayService
                .GetBaysSummaryByBayType(
                    "daily",
                    this.site?.plantId,
                    minDateVla,
                    maxDateVla
                )
                .subscribe((res) => {
                    if (res) {
                        this.baySummaryByBaytype = res;
                        this.bayAssemblyIntegration =
                            this.baySummaryByBaytype?.bayAssemblyIntegration;
                        this.mapBaysDateColumn(
                            this.bayAssemblyIntegration,
                            "Assy + Int"
                        );

                        this.bayIntegration =
                            this.baySummaryByBaytype?.bayIntegration;
                        this.mapBaysDateColumn(this.bayIntegration, "Int Only");

                        this.bayTest = this.baySummaryByBaytype?.bayTest;
                        this.mapBaysDateColumn(this.bayTest, "Test");

                        this.baySummaryStats.push(
                            this.bayAssemblyIntegration[0]
                        );
                        this.baySummaryStats.push(this.bayIntegration[0]);
                        this.baySummaryStats.push(this.bayTest[0]);
                    }
                    this.loadStatGrid = false;
                });
        }
    }

    mapBaysDateColumn(daysData, type: string) {
        daysData[0].baysAvailablityArray = [];
        this.columnHeaderBaySummaryStat = [];
        for (let i = 0; i < daysData.length; i++) {
            daysData[i].bayType = type;
            const c = daysData[i]?.baysAvailablity;
            daysData[0].baysAvailablityArray.push(c);
            const dayWk: dayWeek = new dayWeek();
            dayWk.title = moment(daysData[i]?.bayDate).format("MM-DD-YY");
            this.columnHeaderBaySummaryStat.push(dayWk);
        }
    }

    public changeStartDate() {
        if (this.minDate > this.maxDate) {
            this.maxDate = new Date(this.minDate.getTime());
        }
        this.getBaySummaryDetails();
    }
    // filtering methods
    public filterChangeWeekly(filter: CompositeFilterDescriptor): void {
        this.filter = filter;
        this.gridDataWeekly = filterBy(this.gridDataWeeklyDetails, filter);
    }

    public distinctPrimitiveWeekly(fieldName: string): any {
        return distinct(this.gridDataWeekly, fieldName).map(
            (item) => item[fieldName]
        );
    }
    public filterChangeDaily(filter: CompositeFilterDescriptor): void {
        this.filter = filter;
        this.gridDataDaily = filterBy(this.gridDataDailyDetails, filter);
    }

    public distinctPrimitiveDaily(fieldName: string): any {
        return distinct(this.gridDataDaily, fieldName).map(
            (item) => item[fieldName]
        );
    }

    public filterChangeMonthly(filter: CompositeFilterDescriptor): void {
        this.filter = filter;
        this.gridDataMonthly = filterBy(this.gridDataMonthlyDetails, filter);
    }

    public distinctPrimitiveMonthly(fieldName: string): any {
        return distinct(this.gridDataMonthly, fieldName).map(
            (item) => item[fieldName]
        );
    }

    // submitting add bay
    onSubmitAddBay() {
        if (this.bayAvailable == false && this.bayUnAvailable == false) {
            this.bayAvNotChecked = true;
            return;
        } else {
            this.bayAvNotChecked = false;
        }
        const effectiveDate = this.effectiveDateValue;
        effectiveDate?.setHours(0, 0, 0, 0);
        const endDate = this.endDateValue;
        endDate?.setHours(0, 0, 0, 0);
        if (effectiveDate?.getTime() > endDate?.getTime()) {
            this.greaterEffectiveDateerror = true;
            return;
        } else {
            this.greaterEffectiveDateerror = false;
        }
        this.addBay = {
            BayName: this.bayNameValue,
            StatusID: this.statusValue["value"],
            EffectiveDate: moment(this.effectiveDateValue).format("yyyy-MM-DD"),
            EndDate: moment(this.endDateValue).format("yyyy-MM-DD"),
            ProductTypeGroupListID:
                this.site.plantName !== "Fremont" ||
                this.productTypeValues == undefined
                    ? String(this.productItems.map((x) => x["value"])[0])
                    : this.productTypeValues.map((x) => x["value"]).join(","),
            BuildingID:
                this.site.plantName === "Fremont"
                    ? this.getValueFromText(this.buildingItems, "1")
                    : this.buildingValue["value"],
            BayTypeID: this.bayTypeValue["value"],
            BaysAvailablity:
                this.bayAvailable === true && this.bayUnAvailable === false
                    ? true
                    : false,
            NoEndDate: this.noEndDateChecked,
        };
        // Call Add Bay API
        this.checkValidation();
        if (!this.showValidationError) {
            this.addOpened = false;
            this.loadDetails = true;
            this.loadSummary = true;
            this.bayService.addBays(this.addBay).subscribe((res) => {
                if (res) {
                    this.getBaySummaryDetails();
                }
            });
            this.resetAddBay();
        }
    }
    resetAddBay() {
        this.addBay = {
            BayName: undefined,
            StatusID: undefined,
            EffectiveDate: undefined,
            EndDate: undefined,
            ProductTypeGroupListID: undefined,
            BuildingID: undefined,
            BayTypeID: undefined,
            BaysAvailablity: undefined,
            NoEndDate: false,
        };
        this.bayNameValue = undefined;
        this.statusValue = { text: "", value: 0 };
        this.effectiveDateValue = new Date();
        this.effectiveDateValue.setHours(0, 0, 0, 0);
        this.endDateValue = undefined;
        this.bayAvailable = false;
        this.bayUnAvailable = false;
        this.bayTypeValue = { text: "", value: 0 };
        this.productTypeValue = { text: "", value: 0 };
        this.buildingValue = { text: "", value: 0 };
        this.productTypeValues = [];
        this.noEndDateChecked = false;
        this.productTypeNotSelected = false;
        this.showValidationError = false;
        this.bayNameExists = false;
        this.greaterEffectiveDateerror = false;

        this.disableAdd = true;
    }

    // edit Bay
    populateEditBay(data) {
        this.bayIdValue = data["Id"];
        this.bayNameValueForEdit = { text: data["BayName"], value: 0 };
        this.statusValue = { text: data["Status"], value: 0 };
        this.effectiveDateValue = new Date();
        this.effectiveDateValue.setHours(0, 0, 0, 0);
        this.endDateValue = undefined;
        this.bayAvailable = data["Bay Available?"];
        this.bayTypeValue = { text: data["BayType"], value: 0 };
        this.productTypeValue = { text: data["ProductType"], value: 0 };
        this.productTypeValues =
            this.site.plantName !== "Fremont"
                ? undefined
                : data["ProductType"].split(",").map((x) => ({
                      text: x,
                      value: this.productItems.filter((y) => y.text === x)[0]
                          .value,
                  }));
        this.buildingValue = { text: data["Building"], value: 0 };
        this.statusValueChange(this.statusValue);
    }

    getValueFromText(arr: Array<Item>, key: any) {
        let val = -1;
        if (typeof key === "string") {
            for (let i = 0; i < arr.length; i++) {
                if (arr[i].text == key) {
                    val = arr[i].value;
                }
            }
        } else {
            for (let i = 0; i < arr.length; i++) {
                if (arr[i].text == key.text) {
                    val = arr[i].value;
                }
            }
        }
        return val;
    }

    updateEditBay() {
        if (this.bayAvailable == false && this.bayUnAvailable == false) {
            this.bayAvNotChecked = true;
            return;
        } else {
            this.bayAvNotChecked = false;
        }
        const effectiveDate = this.effectiveDateValue;
        effectiveDate?.setHours(0, 0, 0, 0);
        const endDate = this.endDateValue;
        endDate?.setHours(0, 0, 0, 0);
        if (effectiveDate?.getTime() > endDate?.getTime()) {
            this.greaterEffectiveDateerror = true;
            return;
        } else {
            this.greaterEffectiveDateerror = false;
        }
        this.editBay = {
            BayName: this.bayNameValueForEdit.text,
            StatusID: this.getValueFromText(this.statusItems, this.statusValue),
            EffectiveDate: moment(this.effectiveDateValue).format("yyyy-MM-DD"),
            EndDate:
                this.endDateValue == undefined
                    ? null
                    : moment(this.endDateValue).format("yyyy-MM-DD"),
            ProductTypeGroupListID:
                this.site.plantName !== "Fremont"
                    ? undefined
                    : this.productTypeValues.map((x) => x["value"]).join(","),
            BuildingID: this.getValueFromText(
                this.buildingItems,
                this.buildingValue
            ),
            BayTypeID: this.getValueFromText(
                this.bayTypeItems,
                this.bayTypeValue
            ),
            BaysAvailablity:
                this.bayAvailable == true && this.bayUnAvailable == false
                    ? true
                    : false,
            NoEndDate: this.noEndDateChecked,
        };
        // Call Edit Bay API
        this.checkValidationEdit();
        if (!this.showValidationError) {
            this.loadDetails = true;
            this.loadSummary = true;
            this.subscription.push(
                this.bayService.updateBays(this.editBay).subscribe((res) => {
                    if (res) {
                        this.getBaySummaryDetails();
                    }
                })
            );
            this.resetAddBay();
            this.editOpened = false;
        }
    }

    openDelete(data) {
        this.deleteOpened = true;
        this.deleteRowData = data;
    }
    closeDelete(status: string) {
        this.deleteOpened = false;
    }
    onSubmitDeleteBay() {
        // call delete api with this.deleteRowData.id
        this.subscription.push(
            this.bayService
                .deleteBay(this.deleteRowData["BayName"])
                .subscribe((res) => {
                    if (res) {
                        this.getBaySummaryDetails();
                    }
                })
        );
        this.deleteOpened = false;
    }
    statusValueChange(value: any) {
        if (value["text"] == "Loaned Out to HVM") {
            this.bayAvailable = false;
            this.bayUnAvailable = true;
        } else if (value["text"] == "On Loan From HVM") {
            this.bayAvailable = true;
            this.bayUnAvailable = false;
        } else {
            this.bayAvailable = false;
            this.bayUnAvailable = false;
        }
    }

    radioButtonEvent(val) {
        if (val == "available") {
            this.bayAvailable = true;
            this.bayUnAvailable = false;
        } else {
            this.bayAvailable = false;
            this.bayUnAvailable = true;
        }
    }

    onChangeEndDate(event) {
        if (this.endDateValue < this.effectiveDateValue) {
            this.endDateError = true;
        } else {
            this.endDateError = false;
        }
        this.greaterEffectiveDateerror = false;
    }

    ngOnDestroy(): void {
        this.subscription.forEach((sub) => sub.unsubscribe());
        window.removeEventListener("scroll", this.scrollFixed);
    }

    onChangeEffectiveDate(value: Date) {
        if (value === null || value === undefined || value < this.today) {
            this.biggerEffectiveDateError = true;
        } else {
            this.biggerEffectiveDateError = false;
            this.minEndDate = value;
        }
        this.greaterEffectiveDateerror = false;
    }
    onNoEndDateCheckboxClick() {
        this.noEndDateChecked = !this.noEndDateChecked;
        this.endDateValue = undefined;
    }
    checkValidation() {
        if (this.site?.plantName == "Fremont") {
            if (
                this.nameRequired ||
                this.statusValue.value == 0 ||
                (this.bayAvailable == false && this.bayUnAvailable == false) ||
                this.bayTypeValue.value == 0 ||
                this.productTypeValues == undefined ||
                this.productTypeValues.length == 0
            ) {
                this.showValidationError = true;
                this.disableAdd = true;
            } else {
                this.showValidationError = false;
                this.disableAdd = false;
            }
        } else {
            if (
                this.nameRequired ||
                this.statusValue.value == 0 ||
                (this.bayAvailable == false && this.bayUnAvailable == false) ||
                this.bayTypeValue.value == 0 ||
                this.buildingValue.value == 0
            ) {
                this.showValidationError = true;
                this.disableAdd = true;
            } else {
                this.showValidationError = false;
                this.disableAdd = false;
            }
        }
    }
    checkValidationEdit() {
        if (this.site?.plantName == "Fremont") {
            if (
                this.bayNameValueForEdit.text == null ||
                this.bayNameValueForEdit.text == undefined ||
                this.bayNameValueForEdit.text == "" ||
                this.statusValue.text == "" ||
                this.buildingValue.text == "" ||
                (this.bayAvailable == false && this.bayUnAvailable == false) ||
                this.bayTypeValue.text == "" ||
                this.productTypeValues == undefined ||
                this.productTypeValues.length == 0
            ) {
                this.showValidationError = true;
                this.disableAdd = true;
            } else {
                this.showValidationError = false;
                this.disableAdd = false;
            }
        } else {
            if (
                this.bayNameValueForEdit.text == null ||
                this.bayNameValueForEdit.text == undefined ||
                this.bayNameValueForEdit.text == "" ||
                this.statusValue.text == "" ||
                (this.bayAvailable == false && this.bayUnAvailable == false) ||
                this.bayTypeValue.text == "" ||
                this.buildingValue.text == ""
            ) {
                this.showValidationError = true;
                this.disableAdd = true;
            } else {
                this.showValidationError = false;
                this.disableAdd = false;
            }
        }
    }
    public getNameErr(reqErr) {
        this.nameRequired = reqErr;
        this.checkValidation();
    }
    getBayExists(e) {
        if (this.bayNameList.indexOf(this.bayNameValue) != -1) {
            this.bayNameExists = true;
        } else {
            this.bayNameExists = false;
        }
    }

    getBaySummaryTotal(index: number) {
        let total = 0;
        this.baySummaryStats.forEach((item) => {
            total += item?.baysAvailablityArray[index];
        });
        return total;
    }
}
