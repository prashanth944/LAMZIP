export class dayWeek {
    public title: string;
}
