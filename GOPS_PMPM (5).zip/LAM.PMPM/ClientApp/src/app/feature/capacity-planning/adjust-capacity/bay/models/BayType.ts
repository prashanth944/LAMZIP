export interface BayType {
    bayTypeID: number;
    bayTypeName: string;
}
