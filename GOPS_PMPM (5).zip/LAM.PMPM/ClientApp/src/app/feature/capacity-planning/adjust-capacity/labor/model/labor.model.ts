import { Item } from "../../../../model/item";

export class LaborManagementProductGroupViewModel {
    public productGroupID: number;
    public laborProductName: string;
    public laborManagmentGroupID: number;
    public productName: string;
}
export class LabourManagementGroupMapping {
    public laborManagmentGroupID: number;
    public managementName: string;
    public laborManagmentProductGroupID: number;
    public laborProductGroupID: number;
    public laborMgmtGrpDetails: LaborManagementProductGroupViewModel[];
    public productTypeData: Item[];
}
export class LabourManagementGroupMappingRequest {
    public laborManagmentGroupID: number;
    public managementName: string;
    public laborManagmentProductGroupID: number;
    public laborProductGroupID: number;
    public laborMgmtGrpDetails: LaborManagementProductGroupViewModel[];
}
export class ManagementGroupFactor {
    EfficencyFactor: number;
    OvertimeAllowance: number;
    UtilizationTarget: number;
    PTOPercentage: number;
}
export class LaborManagementGroup {
    public laborManagmentGroupID: number;
    public managementName: string;
    public efficencyFactor: number;
    public overtimeAllowance: number;
    public utilizationTarget: number;
    public pTOPercentage: number;
    public plantID: number;
    public createdOn: Date;
}
export class LaborHeadCountViewModel {
    public Name: string;
    public HeadcountType: string;
    public Headcount: string;
    public Date: string;
    public WeekStart: string;
}
export class LaborHoursViewModel {
    public Name: string;
    public Status: boolean;
    public TotalAvailableHours: number;
    public Assembly: string;
    public Date: string;
    public WeekStart: string;
}

export class LaborHeadCountSnapShotViewModel {
    public DayShiftOnly: string;
    public TotalAvailableHours: number;
    public Date: string;
    public DayName: string;
}
export class BuildType {
    public buildTypeID: number;
    public buildTypeName: string;
    public laborMultiplier: string;
    public multiplierValue: number;
    public plantID: number;
}
export class LaborMasterRecords {
    public masterRecordID: number;
    public masterRecordName: string;
    public type: string;
    public created_Date: string;
    public created_By: string;
}
export class LaborAssemblyTechnicianViewModel {
    public shiftID: number;
    public laborCapacityID: number;
    public assembleyTest: string;
    public status: string;
    public managementGroup: string;
    public shiftType: string;
    public effectiveDate: string;
    public endDate: string;
    public loanDeptFromTo: string;
    public headCount: number;
    public effectiveDateString: string;
    public endDateString: string;
    public PlantID: number;
}
export class LaborPoolViewModel {
    public AssemblyName: string;
    public DayShiftOnly: string;
    public Department: string;
    public LaborManagmentGroupID: number;
    public ManagementName: string;
    public ShiftName: string;
    public Status: string;
}
export class Shifts {
    public shiftID: number;
    public shiftName: string;
    public hoursPerDay: number;
    public description: string;
    public shortDescription: string;
    public compression: string;
    public shiftStartTime: string;
    public shiftEndTime: string;
    public dayShiftType: string;
    public monday1: number;
    public tuesday1: number;
    public wednesday1: number;
    public thursday1: number;
    public friday1: number;
    public saturday1: number;
    public sunday1: number;
    public monday2: number;
    public tuesday2: number;
    public wednesday2: number;
    public thursday2: number;
    public friday2: number;
    public saturday2: number;
    public sunday2: number;
    public weeknum?: number;
    public PlantID: number;
}
export class LaborSummaryDailyWeekly {
    ManagementName: string;
    Assembly: string;
    DayWeek: number[];
}
export class LaborSummary {
    ManagementName: string;
    Assembly: string;
    ShiftDetails: string;
    DayWeek: number[];
}
export class LaborSummaryLonedOutLabor {
    Department: string;
    ShiftDetails: string;
    DayWeek: number[];
}
export class LaborSummaryLaborPool {
    AssemblyName: string;
    DayShiftOnly: string;
    Department: string;
    LaborManagmentGroupID: number;
    ManagementName: string;
    ShiftName: string;
    Status: string;
    DayWeek: number[];
}
export class LaborSummaryHeadCountSnapshot {
    DayShiftOnly: string;
    DayWeek: number[];
}
