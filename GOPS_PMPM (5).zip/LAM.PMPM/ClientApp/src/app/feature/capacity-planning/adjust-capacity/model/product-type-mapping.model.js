"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductTypeMapping = void 0;
var ProductTypeMapping = /** @class */ (function () {
    function ProductTypeMapping() {
    }
    return ProductTypeMapping;
}());
exports.ProductTypeMapping = ProductTypeMapping;
//# sourceMappingURL=product-type-mapping.model.js.map