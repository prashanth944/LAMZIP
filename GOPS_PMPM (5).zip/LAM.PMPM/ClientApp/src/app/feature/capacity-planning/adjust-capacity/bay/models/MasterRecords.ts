export interface MasterRecords {
    masterRecordID: number;
    masterRecordName: string;
    type: string;
    created_Date: Date;
    created_By: Date;
    value: string;
}
