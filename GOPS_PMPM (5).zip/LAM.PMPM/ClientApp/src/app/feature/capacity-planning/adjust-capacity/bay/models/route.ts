export const routes = {
    getBaySummary: "/Bays/GetBaysSummary",
    getBaySummaryTualatin: "/Bays/GetBaysSummaryTualatin",
    getBayDetails: "/Bays/GetBaysDetails",
    getBuilding: "/Bays/GetBuilding",
    getProductType: "/Bays/GetProductType/",
    getBayType: "/Bays/GetBayType",
    getByaStatus: "/Bays/GetBayStatusDDL",
    getToolType: "/Bays/GetToolType",
    deleteBays: "/Bays/DeleteBays/",
    addBays: "/Bays/AddBays",
    updateBays: "/Bays/UpdateBays",
    getBaysSummaryByBayType: "/Bays/GetBaysSummaryByBayType",
};
