export class ProductTypeMapping {
    public ProductType: string;
    public ManagementGroup: string;
}
