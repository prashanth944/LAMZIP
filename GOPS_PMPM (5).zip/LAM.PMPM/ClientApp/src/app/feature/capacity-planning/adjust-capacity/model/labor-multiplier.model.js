"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LaborMultiplier = void 0;
var LaborMultiplier = /** @class */ (function () {
    function LaborMultiplier() {
    }
    return LaborMultiplier;
}());
exports.LaborMultiplier = LaborMultiplier;
//# sourceMappingURL=labor-multiplier.model.js.map