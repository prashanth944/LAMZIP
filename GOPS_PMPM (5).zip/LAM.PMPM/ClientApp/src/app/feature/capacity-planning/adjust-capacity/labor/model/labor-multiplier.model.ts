export class LaborMultiplier {
    public BuildType: string;
    public MultiplierValue: number;
}
