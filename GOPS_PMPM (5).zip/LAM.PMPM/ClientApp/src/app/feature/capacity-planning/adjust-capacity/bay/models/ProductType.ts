export interface ProductType {
    productGroupID: number;
    productName: string;
}
