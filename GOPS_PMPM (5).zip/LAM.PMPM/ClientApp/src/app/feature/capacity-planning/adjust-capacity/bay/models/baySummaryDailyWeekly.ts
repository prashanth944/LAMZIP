export class BaySummaryDailyWeekly {
    Id: number;
    BayName: string;
    ProductType: number;
    Building: number;
    BayType: number;
    Status: number;
    DayWeek: number[];
}
