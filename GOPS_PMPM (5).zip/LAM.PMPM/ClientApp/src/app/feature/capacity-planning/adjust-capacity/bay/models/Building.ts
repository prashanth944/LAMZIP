export interface Building {
    buildingID: number;
    buildingName: string;
}
