export interface BaySummary {
    BayID: number;
    BayName: string;
    BuildingName: string;
    BayTypeName: string;
    StatusID: number;
    EffectiveDate: Date;
    EndDate: Date;
    ProductGroupID: number;
    BuildingID: number;
    BayTypeID: number;
    BaysAvailablity: boolean;
    ProductType: string;
    Standard: string;
    WeekStart: string;
}

export class BayDetails {
    public Bay_Type: string;
    public BaysAvailablity: number[];
}

export class DailyWeeklyDates {
    public Bays_Availablity: number;
    public WeekStart: Date;
}

export class BaySummaryStats {
    public bayDate: Date;
    public baysAvailablity: number;
    public bayType: string;
    public baysAvailablityArray: number[];
}

export class BaySummaryDetails {
    public baysAvailablity: number[];
    public bayType: string;
}

export class BayAssemblyIntegration {
    public bayDate: Date;
    public baysAvailablity: number;
    public assemblyIntegration: string;
}

export class BayIntegration {
    public bayDate: Date;
    public baysAvailablity: number;
    public integration: string;
}

export class BayTest {
    public bayDate: Date;
    public baysAvailablity: number;
    public bayName: string;
    public test: string;
}

export class BaySummaryByBaytype {
    public bayAssemblyIntegration: BaySummaryStats[];
    public bayIntegration: BaySummaryStats[];
    public bayTest: BaySummaryStats[];
}
