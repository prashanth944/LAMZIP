"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShiftType = void 0;
var ShiftType = /** @class */ (function () {
    function ShiftType() {
    }
    return ShiftType;
}());
exports.ShiftType = ShiftType;
//# sourceMappingURL=shift-type.model.js.map