export class AddUpdateBayModel {
    BayName: string;
    StatusID: number | undefined;
    EffectiveDate: string | undefined;
    EndDate: string | undefined;
    ProductTypeGroupListID: string | undefined;
    BuildingID: number | undefined;
    BayTypeID: number | undefined;
    BaysAvailablity: boolean;
    NoEndDate: boolean;
}
