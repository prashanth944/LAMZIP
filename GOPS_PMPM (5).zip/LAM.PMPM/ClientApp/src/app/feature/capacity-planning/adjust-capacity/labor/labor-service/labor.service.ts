import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { environment } from "../../../../../../environments/environment.dev_server";
import { routes } from "../model/routes";
import {
    BuildType,
    LaborAssemblyTechnicianViewModel,
    LaborHeadCountSnapShotViewModel,
    LaborHeadCountViewModel,
    LaborHoursViewModel,
    LaborManagementGroup,
    LaborManagementProductGroupViewModel,
    LaborMasterRecords,
    LaborPoolViewModel,
    LabourManagementGroupMapping,
    LabourManagementGroupMappingRequest,
    Shifts,
} from "../model/labor.model";

@Injectable({
    providedIn: "root",
})
export class LaborService {
    constructor(private http: HttpClient) {}

    // HttpClient API get() method => get bay summary
    GetBuildType(plantID: number): Observable<BuildType[]> {
        return new Observable<BuildType[]>((observer) => {
            this.http
                .get<BuildType[]>(
                    `${environment.apiUrl}${routes.getBuildType}` + plantID
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    GetLaborManagementProductGroup(
        plantID: number
    ): Observable<LabourManagementGroupMapping[]> {
        return new Observable<LabourManagementGroupMapping[]>((observer) => {
            this.http
                .get<LabourManagementGroupMapping[]>(
                    `${environment.apiUrl}${routes.getLaborManagementProductGroup}` +
                        plantID
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    AddManagementGroup(request: LaborManagementGroup): Observable<number> {
        return new Observable<number>((observer) => {
            this.http
                .post<number>(
                    `${environment.apiUrl}${routes.addManagementGroup}`,
                    request
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    GetManagementGroup(plantID: number): Observable<LaborManagementGroup[]> {
        return new Observable<LaborManagementGroup[]>((observer) => {
            this.http
                .get<LaborManagementGroup[]>(
                    `${environment.apiUrl}${routes.getManagementGroup}` +
                        plantID
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    GetHeadCount(interval: string): Observable<LaborHeadCountViewModel[]> {
        return new Observable<LaborHeadCountViewModel[]>((observer) => {
            this.http
                .get<LaborHeadCountViewModel[]>(
                    `${environment.apiUrl}${routes.getHeadCount}` + interval
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    GetLaborhours(interval: string): Observable<LaborHoursViewModel[]> {
        return new Observable<LaborHoursViewModel[]>((observer) => {
            this.http
                .get<LaborHoursViewModel[]>(
                    `${environment.apiUrl}${routes.getLaborhours}` + interval
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    GetLaborPool(
        interval: string,
        plantID: number,
        minDateVla: string,
        maxDateVla: string
    ): Observable<LaborPoolViewModel[]> {
        return new Observable<LaborPoolViewModel[]>((observer) => {
            this.http
                .get<LaborPoolViewModel[]>(
                    `${environment.apiUrl}${routes.getLaborPool}` +
                        "?interval=" +
                        interval +
                        "&plantID=" +
                        plantID +
                        "&minDate=" +
                        minDateVla +
                        "&maxDate=" +
                        maxDateVla
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    GetLaborOverTime(interval: string): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(
                    `${environment.apiUrl}${routes.getLaborOverTime}` + interval
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    GetLaborLoanedOut(interval: string): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(
                    `${environment.apiUrl}${routes.getLaborLoanedOut}` +
                        interval
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    GetShiftType(plantID): Observable<Shifts[]> {
        return new Observable<Shifts[]>((observer) => {
            this.http
                .get<Shifts[]>(
                    `${environment.apiUrl}${routes.getShiftType}` + plantID
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    GetHeadCountSnapShot(
        plantID,
        minDate
    ): Observable<LaborHeadCountSnapShotViewModel[]> {
        return new Observable<LaborHeadCountSnapShotViewModel[]>((observer) => {
            this.http
                .get<LaborHeadCountSnapShotViewModel[]>(
                    `${environment.apiUrl}${routes.getHeadCountSnapShot}` +
                        plantID +
                        "?minDate=" +
                        minDate
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    GetAssemblyTest(): Observable<LaborMasterRecords[]> {
        return new Observable<LaborMasterRecords[]>((observer) => {
            this.http
                .get<LaborMasterRecords[]>(
                    `${environment.apiUrl}${routes.getAssemblyTestDDL}`
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    GetCompressionDDL(): Observable<LaborMasterRecords[]> {
        return new Observable<LaborMasterRecords[]>((observer) => {
            this.http
                .get<LaborMasterRecords[]>(
                    `${environment.apiUrl}${routes.getCompressionDDL}`
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    GetDepartmentFromToDDL(): Observable<LaborMasterRecords[]> {
        return new Observable<LaborMasterRecords[]>((observer) => {
            this.http
                .get<LaborMasterRecords[]>(
                    `${environment.apiUrl}${routes.getDepartmentFromToDDL}`
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    GetManagementGroupDDL(plantID: number): Observable<LaborMasterRecords[]> {
        return new Observable<LaborMasterRecords[]>((observer) => {
            this.http
                .get<LaborMasterRecords[]>(
                    `${environment.apiUrl}${routes.getManagementGroupDDL}` +
                        plantID
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    GetShiftTypeDDL(plantid: number): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(
                    `${environment.apiUrl}${routes.getShiftTypeDDL}` + plantid
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    GetStatusDDL(): Observable<LaborMasterRecords[]> {
        return new Observable<LaborMasterRecords[]>((observer) => {
            this.http
                .get<LaborMasterRecords[]>(
                    `${environment.apiUrl}${routes.getStatusDDL}`
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    AddAssemblyTechnician(
        request: LaborAssemblyTechnicianViewModel
    ): Observable<number> {
        return new Observable<number>((observer) => {
            this.http
                .post<number>(
                    `${environment.apiUrl}${routes.addAssemblyTechnician}`,
                    request
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    UpdateAssemblyTechnician(
        request: LaborAssemblyTechnicianViewModel
    ): Observable<number> {
        return new Observable<number>((observer) => {
            this.http
                .post<number>(
                    `${environment.apiUrl}${routes.updateAssemblyTechnician}`,
                    request
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    UpdateShift(request: Shifts[]): Observable<number> {
        return new Observable<number>((observer) => {
            this.http
                .put<number>(
                    `${environment.apiUrl}${routes.updateShift}`,
                    request
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    AddShift(request: Shifts[]): Observable<number> {
        return new Observable<number>((observer) => {
            this.http
                .post<number>(
                    `${environment.apiUrl}${routes.addShift}`,
                    request
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    UpdateManagementGroup(request: LaborManagementGroup): Observable<number> {
        return new Observable<number>((observer) => {
            this.http
                .put<number>(
                    `${environment.apiUrl}${routes.updateManagementGroup}`,
                    request
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    UpdateBuildType(request: BuildType[]): Observable<number> {
        return new Observable<number>((observer) => {
            this.http
                .put<number>(
                    `${environment.apiUrl}${routes.updateBuildType}`,
                    request
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    UpdateProductManagmentMap(
        request: LabourManagementGroupMappingRequest[]
    ): Observable<number> {
        return new Observable<number>((observer) => {
            this.http
                .put<number>(
                    `${environment.apiUrl}${routes.updateProductManagmentMap}`,
                    request
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    GetProductTypeDDL(
        plantId: number
    ): Observable<LaborManagementProductGroupViewModel[]> {
        return new Observable<LaborManagementProductGroupViewModel[]>(
            (observer) => {
                this.http
                    .get<LaborManagementProductGroupViewModel[]>(
                        `${environment.apiUrl}${routes.getProductTypeDDL}` +
                            plantId
                    )
                    .subscribe(
                        (res) => {
                            observer.next(res);
                        },
                        (error) => {
                            this.handleError(error);
                        }
                    );
            }
        );
    }

    DeleteLaborPool(
        request: LaborAssemblyTechnicianViewModel
    ): Observable<number> {
        return new Observable<number>((observer) => {
            this.http
                .post<number>(
                    `${environment.apiUrl}${routes.deleteLaborPool}`,
                    request
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    // Error handling
    public handleError(error) {
        let errorMessage = "";
        if (error.error instanceof ErrorEvent) {
            // Get client-side error
            errorMessage = error.error.message;
        } else {
            // Get server-side error
            errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }
        return throwError(errorMessage);
    }
}
