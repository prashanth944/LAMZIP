import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import {
    BaySummary,
    BaySummaryByBaytype,
} from "../models/baySummary";
import { ToolType } from "../models/toolType";
import { Building } from "../models/Building";
import { ProductType } from "../models/ProductType";
import { BayType } from "../models/BayType";
import { MasterRecords } from "../models/MasterRecords";
import { environment } from "../../../../../../environments/environment.dev_server";
import { routes } from "../models/route";

@Injectable({
    providedIn: "root",
})
export class BayService {
    constructor(private http: HttpClient) {}

    // HttpClient API get() method => get bay summary
    getBaySummary(
        interval: string,
        plantID,
        minDate,
        maxDate
    ): Observable<BaySummary> {
        return new Observable<BaySummary>((observer) => {
            this.http
                .get<BaySummary>(
                    `${environment.apiUrl}${routes.getBaySummary}` +
                        "?interval=" +
                        interval +
                        "&plantID=" +
                        plantID +
                        "&startDate=" +
                        minDate +
                        "&maxDate=" +
                        maxDate
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    getBaySummaryTualatin(
        interval: string,
        plantID,
        minDate,
        maxDate
    ): Observable<BaySummary> {
        return new Observable<BaySummary>((observer) => {
            this.http
                .get<BaySummary>(
                    `${environment.apiUrl}${routes.getBaySummaryTualatin}` +
                        "?interval=" +
                        interval +
                        "&plantID=" +
                        plantID +
                        "&startDate=" +
                        minDate +
                        "&maxDate=" +
                        maxDate
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    getBayDetails(
        interval: string,
        plantID,
        minDate,
        maxDate
    ): Observable<BaySummary> {
        return new Observable<BaySummary>((observer) => {
            this.http
                .get<BaySummary>(
                    `${environment.apiUrl}${routes.getBayDetails}` +
                        "?interval=" +
                        interval +
                        "&plantID=" +
                        plantID +
                        "&startDate=" +
                        minDate +
                        "&maxDate=" +
                        maxDate
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    getBuilding(plantID): Observable<Building[]> {
        const param = "?plantID=" + plantID;
        return new Observable<Building[]>((observer) => {
            this.http
                .get<Building[]>(
                    `${environment.apiUrl}${routes.getBuilding}${param}`
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    getProductType(plantId: number): Observable<ProductType[]> {
        return new Observable<ProductType[]>((observer) => {
            this.http
                .get<ProductType[]>(
                    `${environment.apiUrl}${routes.getProductType}` + plantId
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    getBayType(): Observable<BayType[]> {
        return new Observable<BayType[]>((observer) => {
            this.http
                .get<BayType[]>(`${environment.apiUrl}${routes.getBayType}`)
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    getBayStatusDDL(): Observable<MasterRecords[]> {
        return new Observable<MasterRecords[]>((observer) => {
            this.http
                .get<MasterRecords[]>(
                    `${environment.apiUrl}${routes.getByaStatus}`
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    getToolType(interval: string): Observable<ToolType> {
        return new Observable<ToolType>((observer) => {
            this.http
                .get<ToolType>(`${environment.apiUrl}${routes.getToolType}`)
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    // delete bays
    deleteBay(bayName) {
        return new Observable<any>((observer) => {
            this.http
                .delete<any>(
                    `${environment.apiUrl}${routes.deleteBays}` + bayName
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    addBays(addBayObj): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .post<any>(`${environment.apiUrl}${routes.addBays}`, addBayObj)
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    // HttpClient API put() method => Update bays
    updateBays(updateBayObj): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .put<any>(
                    `${environment.apiUrl}${routes.updateBays}`,
                    updateBayObj
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    GetBaysSummaryByBayType(
        interval: string,
        plantID: number,
        startDate: string,
        maxDate: string
    ): Observable<BaySummaryByBaytype> {
        return new Observable<BaySummaryByBaytype>((observer) => {
            this.http
                .get<BaySummaryByBaytype>(
                    `${environment.apiUrl}${routes.getBaysSummaryByBayType}` +
                        "?interval=" +
                        interval +
                        "&plantID=" +
                        plantID +
                        "&startDate=" +
                        startDate +
                        "&maxDate=" +
                        maxDate
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    // Error handling
    public handleError(error) {
        let errorMessage = "";
        if (error.error instanceof ErrorEvent) {
            // Get client-side error
            errorMessage = error.error.message;
        } else {
            // Get server-side error
            errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }
        return throwError(errorMessage);
    }
}
