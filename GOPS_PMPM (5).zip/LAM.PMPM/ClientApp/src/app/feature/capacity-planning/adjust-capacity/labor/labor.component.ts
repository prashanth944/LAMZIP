import {
  ChangeDetectorRef,
  Component,
  Inject,
  LOCALE_ID,
  OnInit,
  ViewChild,
  ViewContainerRef,
  ViewEncapsulation,
} from "@angular/core";
import { AppStoreService } from "../../../../core/app-store.service";
import {
  DataBindingDirective,
  GridDataResult,
} from "@progress/kendo-angular-grid";
import {
  State,
  process,
  CompositeFilterDescriptor,
  filterBy,
  distinct,
} from "@progress/kendo-data-query";
import { Observable } from "rxjs";
import { map } from "rxjs/operators";
import { FormBuilder, FormGroup } from "@angular/forms";
import { EditService } from "src/app/feature/service/edit.service";
import { LaborService } from "./labor-service/labor.service";
import {
  BuildType,
  LaborAssemblyTechnicianViewModel,
  LaborManagementGroup,
  LaborSummary,
  LaborSummaryHeadCountSnapshot,
  LaborSummaryLaborPool,
  LaborSummaryLonedOutLabor,
  LabourManagementGroupMapping,
  LabourManagementGroupMappingRequest,
  Shifts,
} from "./model/labor.model";
import { dayWeek, Item } from "../../../model/item";
import * as moment from "moment";
import { DomSanitizer, SafeStyle } from "@angular/platform-browser";
import { Plant } from "../../../../core/model/user.model";
import { formatDate } from "@angular/common";
import { role, uiScreen } from "../../../../core/model/common.constant";
import { MultiSelectComponent } from "@progress/kendo-angular-dropdowns";
import { DataService } from "../../../other/admin/Services/DataService";
import { Labor } from "../../../other/Models/defaults.model";
import { NotificationService } from "@progress/kendo-angular-notification";

@Component({
  selector: "pmpm-labor",
  templateUrl: "./labor.component.html",
  styleUrls: ["./labor.component.css"],
  encapsulation: ViewEncapsulation.None,
})
export class LaborComponent implements OnInit {
  @ViewChild("appendTo", { read: ViewContainerRef })
  public appendTo: ViewContainerRef;
  @ViewChild(DataBindingDirective, { static: true })
  dataBinding: DataBindingDirective;
  @ViewChild("multiselect") public multiselect: MultiSelectComponent;

  editLaborSummary = false;
  addTechnicians = false;
  addShiftType = false;
  addManagementGroup = false;
  site: Plant;
  activeAdjustLaborTab = 0;
  addEditHeader: string;
  isWeek1Mon = false;
  isWeek1Tue = false;
  isWeek1Wed = false;
  isWeek1Thu = false;
  isWeek1Fri = false;
  isWeek1Sat = false;
  isWeek1Sun = false;
  isWeek2Mon = false;
  isWeek2Tue = false;
  isWeek2Wed = false;
  isWeek2Thu = false;
  isWeek2Fri = false;
  isWeek2Sat = false;
  isWeek2Sun = false;
  isSaveShiftType = false;
  missingShiftDescription = false;
  missingShiftShortDescription = false;
  missingCompressionValueForEdit = false;
  invalidShiftStartTime = false;
  inavlidShiftEndTime = false;
  sameShiftEndTime = false;
  isSameWeek = false;
  compressionValueForEdit: { text: string; value: 0 };
  managementGroupValue: { text: ""; value: 0 };
  laborTypeValue: { text: ""; value: 0 };
  statusValue: { text: string; value: 0 };
  loaningFormValue: { text: string; value: 0 };
  mgGroupValue: { text: string; value: 0 };
  productTypeMgGroupValue: Item[];
  shiftTypeValue: { text: string; value: 0 };
  technicianEffectiveDate: Date;
  technicianEndDate: Date;
  headCount: number;
  shiftDescription = "";
  shiftShortDescription = "";
  shiftHoursPerShift: number;
  isDayShift = false;
  overTimeAllowance: number;
  efficiencyFactor: number;
  utilizationTarget: number;
  laborManagmentGroupID: number;
  shiftTypeId: number;
  pto: number;
  public view: Observable<GridDataResult>;
  public gridState: State = {
    sort: [],
    skip: 0,
    take: 10,
  };
  gridDataForFremontWeekly: LaborSummary[] = [];
  gridDataForFremontDaily: LaborSummary[] = [];
  gridDataForFremontMonthly: LaborSummary[] = [];

  laborHoursGridDataWeekly: LaborSummary[] = [];
  laborHoursGridDataDaily: LaborSummary[] = [];
  laborHoursGridDataMonthly: LaborSummary[] = [];

  gridDataForOverTimeWeekly: LaborSummary[] = [];
  gridDataForOverTimeDaily: LaborSummary[] = [];
  gridDataForOverTimeMonthly: LaborSummary[] = [];

  gridDataForLoanedOutWeekly: LaborSummaryLonedOutLabor[] = [];
  gridDataForLoanedOutDaily: LaborSummaryLonedOutLabor[] = [];
  gridDataForLoanedOutMonthly: LaborSummaryLonedOutLabor[] = [];

  gridDataForLaborMultiplier: BuildType[] = [];
  tempGridDataForLaborMultiplier: BuildType[] = [];
  gridDataForShiftType: Shifts[] = [];

  gridDataForManagementGroup: LaborManagementGroup[] = [];
  gridDataForLaborPoolWeekly: LaborSummaryLaborPool[] = [];
  gridDataForLaborPoolDaily: LaborSummaryLaborPool[] = [];
  gridDataForLaborPoolMonthly: LaborSummaryLaborPool[] = [];
  masterGridDataForLaborPoolWeekly: LaborSummaryLaborPool[] = [];
  masterGridDataForLaborPoolDaily: LaborSummaryLaborPool[] = [];
  masterGridDataForLaborPoolMonthly: LaborSummaryLaborPool[] = [];
  gridDataForProductType: LabourManagementGroupMapping[] = [];
  tempGridDataForProductType: LabourManagementGroupMapping[] = [];
  gridDataForHeadCountSnapshot: LaborSummaryHeadCountSnapshot[] = [];

  public lonedOuntWeekColumns: dayWeek[] = [];
  public lonedOuntDailyColumns: dayWeek[] = [];
  public lonedOuntMonthlyColumns: dayWeek[] = [];
  public overTimeWeekColumns: dayWeek[] = [];
  public overTimeDailyColumns: dayWeek[] = [];
  public overTimeMonthlyColumns: dayWeek[] = [];
  public laborHoursWeekColumns: dayWeek[] = [];
  public laborHoursDailyColumns: dayWeek[] = [];
  public laborHoursMonthlyColumns: dayWeek[] = [];
  public headcountWeekColumns: dayWeek[] = [];
  public headcountDailyColumns: dayWeek[] = [];
  public headcountMonthlyColumns: dayWeek[] = [];
  public adjustLaborWeekColumns: dayWeek[] = [];
  public adjustLaborDailyColumns: dayWeek[] = [];
  public adjustLaborMonthlyColumns: dayWeek[] = [];
  public HeadCountSnapshotColumns: dayWeek[] = [];
  public headCountValue = 0;
  public statusItems: Item[] = [];
  public managementGroup: Item[] = [];
  public compressionItem: Item[] = [];
  public departmentItem: Item[] = [];
  public laborTypeItem: Item[] = [];
  public shiftTypeItems: Item[] = [];
  public dateValue: Date = new Date();
  public shiftStartTimeValue: Date = new Date();
  public shiftEndTimeValue: Date = new Date();
  public gridView: any[];
  public filter: CompositeFilterDescriptor;
  public gridDataWeekly: any[];
  public gridDataDaily: any[];
  public gridDataMonthly: any[];
  public gridDataHeadCountWeekly: any[];
  public gridDataHeadCountDaily: any[];
  public editView: string;
  public tempEditView: string;
  public isShiftType = false;
  public isDayNight = false;
  public isNone = true;
  public isShowShiftType = false;
  public isShowDayNight = false;
  public isShowNone = true;
  public shiftHoursPerShiftError = false;
  public addLaborPoolError = false;
  public biggerEndDateError = false;
  public headcountError = false;
  public existingRecordError = false;
  public departmentHeader = "Department Loaning From";
  public hideDepartmentDropDown = false;
  public managementGroupName = "";
  public productTypeGroup: Item[] = [];
  public tempProductTypeGroup: Item[] = [];
  public masterProductTypeGroup: Item[] = [];
  public showUnits = "Unit = People";
  public isDeleteLaborPool = false;
  public minEndDate: Date;
  public minEffectiveDate = new Date();
  public biggerEffectiveDateError = false;
  public today = new Date();
  public tempDeleteLaborPool: LaborSummaryLaborPool;
  public isUserAccess = false;
  public isLoading = true;
  public timeViewList: Item[] = [
    { text: "Monthly", value: 2 },
    { text: "Weekly", value: 0 },
    { text: "Daily", value: 1 },
  ];
  public timeViewValue = { text: "Weekly", value: 0 };
  public defaultManagementGroupData: Labor[] = [];
  public loadHeadCount = false;
  public loadLaborPool = false;
  public isShowEditView = true;
  public canEditOT = false; // User Story 36263: Labor Capacity Mgmt group tab - allow edit of mgmt group OT % with warning, superusers only

  minAvalibleDate = new Date(
    this.today.getFullYear() - 1,
    this.today.getMonth(),
    this.today.getDate()
  );

  maxAvalibleDate = new Date(
    this.today.getFullYear() + 2,
    this.today.getMonth(),
    this.today.getDate()
  );

  minDate = new Date(this.today.getTime());
  maxDate = new Date(this.today.getFullYear(), this.today.getMonth() + 4, 1);

  constructor(
    private appStoreService: AppStoreService,
    public editService: EditService,
    private formBuilder: FormBuilder,
    private laborService: LaborService,
    private sanitizer: DomSanitizer,
    @Inject(LOCALE_ID) private locale: string,
    private setDefualtsService: DataService,
    private changeDetector: ChangeDetectorRef,
    private notificationService: NotificationService
  ) { }

  ngOnInit() {
    this.isLoading = true;
    this.today.setHours(0, 0, 0, 0);
    this.appStoreService.getUserRoles().subscribe((res) => {
      if (res && res.length > 0) {
        this.appStoreService
          .checkUserAccessRight(res, uiScreen.Labor)
          .subscribe((result) => {
            this.isUserAccess = result;
            if (res.includes(role.SuperUser)) {
              this.canEditOT = true;
            }
            this.isLoading = false;
          });
      }
    });
    this.shiftEndTimeValue.setHours(this.shiftEndTimeValue.getHours() + 1);
    this.appStoreService.getCurrentSite().subscribe((site) => {
      if (site) {
        this.site = {
          plantName: site.plantName,
          plantId: site.plantId,
        };
        this.getHeadCountSnapShot();       

        this.laborService
          .GetProductTypeDDL(this.site?.plantId)
          .subscribe((res) => {
            if (res && res.length > 0) {
              res.forEach((val) => {
                const newStatus: Item = {
                  value: val.productGroupID,
                  text: val.productName,
                };
                this.productTypeGroup.push(newStatus);
                this.tempProductTypeGroup = [
                  ...this.productTypeGroup,
                ];
                this.masterProductTypeGroup = [
                  ...this.productTypeGroup,
                ];
              });

              if (this.timeViewValue.text === "Weekly") {
                this.setDatesDeffWeekly();
                this.getOverTimeWeekly();
                this.getLonedOutLaborWeekly();
                this.getLaborPoolWeekly();
                this.getHeadCountWeekly();
                this.getLaborHoursWeekly();
                this.getShiftType();
                this.getBuildType();
                this.getProductTypeMapping();
                this.getManagementGroup();
                this.getManagementGroupDefaultData();
                this.laborService
                  .GetManagementGroupDDL(this.site?.plantId)
                  .subscribe((res) => {
                    if (res && res.length > 0) {
                      res.forEach((val) => {
                        const newStatus: Item = {
                          value: val.masterRecordID,
                          text: val.masterRecordName,
                        };
                        this.managementGroup.push(newStatus);
                      });
                    }
                  });

                if (this.site.plantName !== "Fremont") {
                  this.mgGroupValue = { text: "None", value: 0 };
                } else {
                  this.mgGroupValue = { text: "", value: 0 };
                }
              }
              if (this.timeViewValue.text === "Daily") {
                this.setDatesDeffDaily();
                this.getOverTimeDaily();
                this.getLonedOutLaborDaily();
                this.getLaborPoolDaily();
                this.getHeadCountDaily();
                this.getLaborHoursDaily();
                this.getShiftType();
                this.getBuildType();
                this.getProductTypeMapping();
                this.getManagementGroup();
                this.getManagementGroupDefaultData();
                this.laborService
                  .GetManagementGroupDDL(this.site?.plantId)
                  .subscribe((res) => {
                    if (res && res.length > 0) {
                      res.forEach((val) => {
                        const newStatus: Item = {
                          value: val.masterRecordID,
                          text: val.masterRecordName,
                        };
                        this.managementGroup.push(newStatus);
                      });
                    }
                  });

                if (this.site.plantName !== "Fremont") {
                  this.mgGroupValue = { text: "None", value: 0 };
                } else {
                  this.mgGroupValue = { text: "", value: 0 };
                }
              }
              if (this.timeViewValue.text === "Monthly") {
                this.setDatesDeffMonth();
                this.getOverTimeMonthly();
                this.getLonedOutLaborMonthly();
                this.getLaborPoolMonthly();
                this.getHeadCountMonthly();
                this.getLaborHoursMonthly();
                this.getShiftType();
                this.getBuildType();
                this.getProductTypeMapping();
                this.getManagementGroup();
                this.getManagementGroupDefaultData();
                this.laborService
                  .GetManagementGroupDDL(this.site?.plantId)
                  .subscribe((res) => {
                    if (res && res.length > 0) {
                      res.forEach((val) => {
                        const newStatus: Item = {
                          value: val.masterRecordID,
                          text: val.masterRecordName,
                        };
                        this.managementGroup.push(newStatus);
                      });
                    }
                  });

                if (this.site.plantName !== "Fremont") {
                  this.mgGroupValue = { text: "None", value: 0 };
                } else {
                  this.mgGroupValue = { text: "", value: 0 };
                }
              }
            }
          });
        this.getShiftTypeDDL();
      }
    });
    this.view = this.editService.pipe(
      map((data) => process(data, this.gridState))
    );
    this.laborTypeItem = [
      { text: "Assembly", value: 1 },
      { text: "Test", value: 2 },
    ];

    this.laborService.GetStatusDDL().subscribe((res) => {
      if (res && res.length > 0) {
        res.forEach((val) => {
          const newStatus: Item = {
            value: val.type,
            text: val.masterRecordName,
          };
          this.statusItems.push(newStatus);
        });
      }
    });
    this.laborService.GetCompressionDDL().subscribe((res) => {
      if (res && res.length > 0) {
        res.forEach((val) => {
          const newStatus: Item = {
            value: val.masterRecordID,
            text: val.masterRecordName,
          };
          this.compressionItem.push(newStatus);
        });
      }
    });
    this.laborService.GetDepartmentFromToDDL().subscribe((res) => {
      if (res && res.length > 0) {
        res.forEach((val) => {
          let first = val.masterRecordName.substr(0, 1).toUpperCase();
          first =
            first + val.masterRecordName.substr(1).toLowerCase();
          const newStatus: Item = {
            value: val.masterRecordID,
            text: first,
          };
          this.departmentItem.push(newStatus);
        });
      }
    });
  }

  getHeadCountSnapShot() {
    this.HeadCountSnapshotColumns = [];
    const minDateVla = moment(this.minDate).format("YYYY-MM-DD");
    this.laborService
      .GetHeadCountSnapShot(this.site?.plantId.toString(), minDateVla)
      .subscribe((res) => {
        if (res) {
          this.mapHeadCountSnapShot(res);
        }
      });
  }

  getManagementGroupDefaultData() {
    this.setDefualtsService.GetLabourDefaultData().subscribe((res) => {
      if (res) {
        this.defaultManagementGroupData = JSON.parse(
          JSON.stringify(res)
        );
        this.overTimeAllowance = this.defaultManagementGroupData.filter(
          (x) => x.plantID == this.site.plantId
        )[0].overtimePerc;
        this.efficiencyFactor = this.defaultManagementGroupData.filter(
          (x) => x.plantID == this.site.plantId
        )[0].efficencyFactory;
        this.utilizationTarget = this.defaultManagementGroupData.filter(
          (x) => x.plantID == this.site.plantId
        )[0].laborUtilization;
        this.pto = this.defaultManagementGroupData.filter(
          (x) => x.plantID == this.site.plantId
        )[0].ptoPerc;
      }
    });
  }

  getShiftTypeDDL() {
    this.shiftTypeItems = [];
    this.laborService
      .GetShiftTypeDDL(this.site?.plantId)
      .subscribe((res) => {
        if (res && res.length > 0) {
          res.forEach((val) => {
            const newStatus: Item = {
              value: val.shiftID,
              text: val.shortDescription,
            };
            this.shiftTypeItems.push(newStatus);
          });
        }
      });
  }
  getBuildType() {
    this.laborService.GetBuildType(this.site?.plantId).subscribe((res) => {
      if (res && res.length > 0) {
        this.gridDataForLaborMultiplier = res;
        this.gridDataForLaborMultiplier.forEach((item) => {
          item.multiplierValue =
            item.multiplierValue !== null &&
              item.multiplierValue !== undefined
              ? item.multiplierValue
              : 0;
        });
        this.tempGridDataForLaborMultiplier = JSON.parse(
          JSON.stringify(this.gridDataForLaborMultiplier)
        );
      }
    });
  }
  getLaborPoolWeekly() {
    this.loadLaborPool = true;
    this.gridDataForLaborPoolWeekly = [];
    this.masterGridDataForLaborPoolWeekly = [];
    this.adjustLaborWeekColumns = [];

    const minDateVla = moment(this.minDate).format("YYYY-MM-DD");
    const maxDateVla = moment(this.maxDate).format("YYYY-MM-DD");

    this.laborService
      .GetLaborPool("week", this.site?.plantId, minDateVla, maxDateVla)
      .subscribe((res) => {
        if (res && res.length > 0) {
          this.mapLaborPool(res, "week");
        }
        this.loadLaborPool = false;
      });
  }
  getLaborPoolDaily() {
    this.loadLaborPool = true;
    this.masterGridDataForLaborPoolDaily = [];
    this.gridDataForLaborPoolDaily = [];
    this.adjustLaborDailyColumns = [];

    const minDateVla = moment(this.minDate).format("YYYY-MM-DD");
    const maxDateVla = moment(this.maxDate).format("YYYY-MM-DD");

    this.laborService
      .GetLaborPool("daily", this.site?.plantId, minDateVla, maxDateVla)
      .subscribe((res) => {
        if (res && res.length > 0) {
          this.mapLaborPool(res, "daily");
        }
        this.loadLaborPool = false;
      });
  }
  getLaborPoolMonthly() {
    this.loadLaborPool = true;
    this.masterGridDataForLaborPoolMonthly = [];
    this.gridDataForLaborPoolMonthly = [];
    this.adjustLaborMonthlyColumns = [];

    const minDateVla = moment(this.minDate).format("YYYY-MM-DD");
    const maxDateVla = moment(this.maxDate).format("YYYY-MM-DD");

    this.laborService
      .GetLaborPool("month", this.site?.plantId, minDateVla, maxDateVla)
      .subscribe((res) => {
        if (res && res.length > 0) {
          this.mapLaborPool(res, "month");
        }
        this.loadLaborPool = false;
      });
  }
  getManagementGroup() {
    this.laborService
      .GetManagementGroupDDL(this.site?.plantId)
      .subscribe((res) => {
        if (res && res.length > 0) {
          res.forEach((val) => {
            const newStatus: Item = {
              value: val.masterRecordID,
              text: val.masterRecordName,
            };
            this.managementGroup.push(newStatus);
          });
        }
      });
    this.laborService
      .GetManagementGroup(this.site?.plantId)
      .subscribe((res) => {
        if (res && res.length > 0) {
          this.gridDataForManagementGroup = res;
        }
      });
  }
  getProductTypeMapping() {
    this.laborService
      .GetLaborManagementProductGroup(this.site?.plantId)
      .subscribe((res) => {
        if (res && res.length > 0) {
          this.gridDataForProductType = res;
          this.gridDataForProductType.forEach((item) => {
            item.productTypeData = [];
            if (item.laborMgmtGrpDetails.length > 0) {
              item.laborMgmtGrpDetails.forEach((product) => {
                item.productTypeData.push({
                  text: product.laborProductName,
                  value: product.productGroupID,
                });
                this.productTypeGroup =
                  this.productTypeGroup.filter(
                    (p) =>
                      p.text !==
                      product.laborProductName &&
                      p.value !== product.productGroupID
                  );
                this.tempProductTypeGroup = [
                  ...this.productTypeGroup,
                ];
                this.masterProductTypeGroup = [
                  ...this.productTypeGroup,
                ];
              });
            }
          });
          this.tempGridDataForProductType = JSON.parse(
            JSON.stringify(this.gridDataForProductType)
          );
        }
      });
  }
  getHeadCountWeekly() {
    this.loadHeadCount = true;
    this.gridDataForFremontWeekly = [];
    this.headcountWeekColumns = [];

    let args = "week/" + this.site?.plantId.toString();
    if (this.isShiftType || this.isDayNight) {
      args = args + "/" + this.editView;
    }

    const minDateVla = moment(this.minDate).format("YYYY-MM-DD");
    const maxDateVla = moment(this.maxDate).format("YYYY-MM-DD");

    args = args + "?minDate=" + minDateVla + "&maxDate=" + maxDateVla;

    this.laborService.GetHeadCount(args).subscribe((res) => {
      if (res && res.length > 0) {
        this.mapHeadCount(res, "week");
      }
      this.loadHeadCount = false;
    });
  }
  getHeadCountDaily() {
    this.loadHeadCount = true;
    this.gridDataForFremontDaily = [];
    this.headcountDailyColumns = [];

    let args = "daily/" + this.site?.plantId.toString();
    if (this.isShiftType || this.isDayNight) {
      args = args + "/" + this.editView;
    }

    const minDateVla = moment(this.minDate).format("YYYY-MM-DD");
    const maxDateVla = moment(this.maxDate).format("YYYY-MM-DD");

    args = args + "?minDate=" + minDateVla + "&maxDate=" + maxDateVla;

    this.laborService.GetHeadCount(args).subscribe((res) => {
      if (res && res.length > 0) {
        this.mapHeadCount(res, "daily");
      }
      this.loadHeadCount = false;
    });
  }
  getHeadCountMonthly() {
    this.loadHeadCount = true;
    this.gridDataForFremontMonthly = [];
    this.headcountMonthlyColumns = [];

    let args = "month/" + this.site?.plantId.toString();
    if (this.isShiftType || this.isDayNight) {
      args = args + "/" + this.editView;
    }

    const minDateVla = moment(this.minDate).format("YYYY-MM-DD");
    const maxDateVla = moment(this.maxDate).format("YYYY-MM-DD");

    args = args + "?minDate=" + minDateVla + "&maxDate=" + maxDateVla;

    this.laborService.GetHeadCount(args).subscribe((res) => {
      if (res && res.length > 0) {
        this.mapHeadCount(res, "month");
      }
      this.loadHeadCount = false;
    });
  }
  getOverTimeWeekly() {
    this.gridDataForOverTimeWeekly = [];
    this.overTimeWeekColumns = [];

    let args = "week/" + this.site?.plantId.toString();
    if (this.isShiftType || this.isDayNight) {
      args = args + "/" + this.editView;
    }

    const minDateVla = moment(this.minDate).format("YYYY-MM-DD");
    const maxDateVla = moment(this.maxDate).format("YYYY-MM-DD");

    args = args + "?minDate=" + minDateVla + "&maxDate=" + maxDateVla;

    this.laborService.GetLaborOverTime(args).subscribe((res) => {
      if (res && res.length > 0) {
        this.mapOverTime(res, "week");
      }
    });
  }
  getOverTimeDaily() {
    this.gridDataForOverTimeDaily = [];
    this.overTimeDailyColumns = [];

    let args = "daily/" + this.site?.plantId.toString();
    if (this.isShiftType || this.isDayNight) {
      args = args + "/" + this.editView;
    }

    const minDateVla = moment(this.minDate).format("YYYY-MM-DD");
    const maxDateVla = moment(this.maxDate).format("YYYY-MM-DD");

    args = args + "?minDate=" + minDateVla + "&maxDate=" + maxDateVla;

    this.laborService.GetLaborOverTime(args).subscribe((res) => {
      if (res && res.length > 0) {
        this.mapOverTime(res, "daily");
      }
    });
  }
  getOverTimeMonthly() {
    this.gridDataForOverTimeMonthly = [];
    this.overTimeMonthlyColumns = [];

    let args = "month/" + this.site?.plantId.toString();
    if (this.isShiftType || this.isDayNight) {
      args = args + "/" + this.editView;
    }

    const minDateVla = moment(this.minDate).format("YYYY-MM-DD");
    const maxDateVla = moment(this.maxDate).format("YYYY-MM-DD");

    args = args + "?minDate=" + minDateVla + "&maxDate=" + maxDateVla;

    this.laborService.GetLaborOverTime(args).subscribe((res) => {
      if (res && res.length > 0) {
        this.mapOverTime(res, "month");
      }
    });
  }

  getLaborHoursWeekly() {
    this.laborHoursGridDataWeekly = [];
    this.laborHoursWeekColumns = [];

    let args = "week/" + this.site?.plantId.toString();
    if (this.isShiftType || this.isDayNight) {
      args = args + "/" + this.editView;
    }

    const minDateVla = moment(this.minDate).format("YYYY-MM-DD");
    const maxDateVla = moment(this.maxDate).format("YYYY-MM-DD");

    args = args + "?minDate=" + minDateVla + "&maxDate=" + maxDateVla;

    this.laborService.GetLaborhours(args).subscribe((res) => {
      if (res && res.length > 0) {
        this.mapLaborHours(res, "week");
      }
    });
  }
  getLaborHoursDaily() {
    this.laborHoursGridDataDaily = [];
    this.laborHoursDailyColumns = [];

    let args = "daily/" + this.site?.plantId.toString();
    if (this.isShiftType || this.isDayNight) {
      args = args + "/" + this.editView;
    }

    const minDateVla = moment(this.minDate).format("YYYY-MM-DD");
    const maxDateVla = moment(this.maxDate).format("YYYY-MM-DD");

    args = args + "?minDate=" + minDateVla + "&maxDate=" + maxDateVla;

    this.laborService.GetLaborhours(args).subscribe((res) => {
      if (res && res.length > 0) {
        this.mapLaborHours(res, "daily");
      }
    });
  }
  getLaborHoursMonthly() {
    this.laborHoursGridDataMonthly = [];
    this.laborHoursMonthlyColumns = [];

    let args = "month/" + this.site?.plantId.toString();
    if (this.isShiftType || this.isDayNight) {
      args = args + "/" + this.editView;
    }

    const minDateVla = moment(this.minDate).format("YYYY-MM-DD");
    const maxDateVla = moment(this.maxDate).format("YYYY-MM-DD");

    args = args + "?minDate=" + minDateVla + "&maxDate=" + maxDateVla;

    this.laborService.GetLaborhours(args).subscribe((res) => {
      if (res && res.length > 0) {
        this.mapLaborHours(res, "month");
      }
    });
  }
  getLonedOutLaborWeekly() {
    this.gridDataForLoanedOutWeekly = [];
    this.lonedOuntWeekColumns = [];

    let args = "week/" + this.site?.plantId.toString();
    if (this.isShiftType || this.isDayNight) {
      args = args + "/" + this.editView;
    }

    const minDateVla = moment(this.minDate).format("YYYY-MM-DD");
    const maxDateVla = moment(this.maxDate).format("YYYY-MM-DD");

    args = args + "?minDate=" + minDateVla + "&maxDate=" + maxDateVla;

    this.laborService.GetLaborLoanedOut(args).subscribe((res) => {
      if (res && res.length > 0) {
        this.mapLoanedOut(res, "week");
      }
    });
  }
  getLonedOutLaborDaily() {
    this.gridDataForLoanedOutDaily = [];
    this.lonedOuntDailyColumns = [];

    let args = "daily/" + this.site?.plantId.toString();
    if (this.isShiftType || this.isDayNight) {
      args = args + "/" + this.editView;
    }

    const minDateVla = moment(this.minDate).format("YYYY-MM-DD");
    const maxDateVla = moment(this.maxDate).format("YYYY-MM-DD");

    args = args + "?minDate=" + minDateVla + "&maxDate=" + maxDateVla;

    this.laborService.GetLaborLoanedOut(args).subscribe((res) => {
      if (res && res.length > 0) {
        this.mapLoanedOut(res, "daily");
      }
    });
  }
  getLonedOutLaborMonthly() {
    this.gridDataForLoanedOutMonthly = [];
    this.lonedOuntMonthlyColumns = [];

    let args = "month/" + this.site?.plantId.toString();
    if (this.isShiftType || this.isDayNight) {
      args = args + "/" + this.editView;
    }

    const minDateVla = moment(this.minDate).format("YYYY-MM-DD");
    const maxDateVla = moment(this.maxDate).format("YYYY-MM-DD");

    args = args + "?minDate=" + minDateVla + "&maxDate=" + maxDateVla;

    this.laborService.GetLaborLoanedOut(args).subscribe((res) => {
      if (res && res.length > 0) {
        this.mapLoanedOut(res, "month");
      }
    });
  }
  getShiftType() {
    this.laborService.GetShiftType(this.site?.plantId).subscribe((res) => {
      if (res && res.length > 0) {
        this.gridDataForShiftType = [...res];
      }
    });
  }
  mapHeadCountSnapShot(SummaryObj) {
    let laborSummaryDailyWeekly = new LaborSummaryHeadCountSnapshot();
    for (
      let i = 0;
      i < SummaryObj?.laborHeadCountSnapshotList?.length;
      i++
    ) {
      laborSummaryDailyWeekly = {
        DayShiftOnly:
          SummaryObj.laborHeadCountSnapshotList[i].DayShiftOnly
            .DayShiftOnly,
        DayWeek: this.mapLaborHeadCountSnapShot(
          SummaryObj.laborHeadCountSnapshotList[i].WeeklyValues,
          i,
          "summary"
        ),
      };
      this.gridDataForHeadCountSnapshot.push(laborSummaryDailyWeekly);
    }
    const daysDataArray: number[] = [];
    for (let j = 0; j < SummaryObj?.laborHour?.length; j++) {
      daysDataArray.push(SummaryObj.laborHour[j].TotalLaborHour[0]);
    }
    const totalLaborSummaryDailyWeekly = {
      DayShiftOnly: "Total",
      DayWeek: daysDataArray,
    };
    this.gridDataForHeadCountSnapshot = [
      ...this.gridDataForHeadCountSnapshot,
      ...[totalLaborSummaryDailyWeekly],
    ];
  }

  mapLaborHeadCountSnapShot(
    daysData: any,
    rownum: number,
    summ: string
  ): number[] {
    const daysDataArray: number[] = [];
    for (let i = 0; i < daysData.length; i++) {
      const c = daysData[i].TotalAvailableHour;
      daysDataArray.push(c);
      const dayWk: dayWeek = new dayWeek();
      dayWk.field = daysData[i].DayName;
      if (rownum == 0 && summ == "summary") {
        this.HeadCountSnapshotColumns.push(dayWk);
      }
    }
    return daysDataArray;
  }

  mapHeadCount(SummaryObj, interval: string) {
    let laborSummaryDailyWeekly = new LaborSummary();
    for (let i = 0; i < SummaryObj.length; i++) {
      laborSummaryDailyWeekly = {
        ManagementName: SummaryObj[i].ManagementName.ManagementName,
        Assembly: SummaryObj[i].ManagementName.Assembly,
        ShiftDetails: SummaryObj[i].ManagementName.ShiftDetails,
        DayWeek: this.mapLaborHeadCount(
          SummaryObj[i].WeeklyDates,
          interval,
          i,
          "summary"
        ),
      };
      if (interval == "daily") {
        this.gridDataForFremontDaily.push(laborSummaryDailyWeekly);
      } else if (interval == "month") {
        this.gridDataForFremontMonthly.push(laborSummaryDailyWeekly);
      } else {
        this.gridDataForFremontWeekly.push(laborSummaryDailyWeekly);
      }
    }
  }

  mapLaborHeadCount(
    daysData: any,
    interval: string,
    rownum: number,
    summ: string
  ): number[] {
    const daysDataArray: number[] = [];
    if (interval == "daily") {
      for (let i = 0; i < daysData.length; i++) {
        const c = daysData[i].Headcount;
        daysDataArray.push(c);
        const dayWk: dayWeek = new dayWeek();
        dayWk.field = moment(daysData[i].LaborDate).format("M-D-YY");
        if (rownum == 0 && summ == "summary") {
          this.headcountDailyColumns.push(dayWk);
        }
      }
    } else if (interval == "month") {
      for (let i = 0; i < daysData.length; i++) {
        const c = daysData[i].Headcount;
        daysDataArray.push(c);
        const dayWk: dayWeek = new dayWeek();
        dayWk.field = moment(daysData[i].LaborDate).format("M-D-YY");
        if (rownum == 0 && summ == "summary") {
          this.headcountMonthlyColumns.push(dayWk);
        }
      }
    } else {
      for (let i = 0; i < daysData.length; i++) {
        const c = daysData[i].Headcount;
        daysDataArray.push(c);
        const dayWk: dayWeek = new dayWeek();
        dayWk.field = moment(daysData[i].LaborDate).format("M-D-YY");
        if (rownum == 0 && summ == "summary") {
          this.headcountWeekColumns.push(dayWk);
        }
      }
    }
    return daysDataArray;
  }

  mapLaborHours(SummaryObj, interval: string) {
    let laborSummaryDailyWeekly = new LaborSummary();
    for (let i = 0; i < SummaryObj.length; i++) {
      laborSummaryDailyWeekly = {
        ManagementName: SummaryObj[i].ManagementName.ManagementName,
        Assembly: SummaryObj[i].ManagementName.Assembly,
        ShiftDetails: SummaryObj[i].ManagementName.ShiftDetails,
        DayWeek: this.mapLaborHoursData(
          SummaryObj[i].WeeklyDates,
          interval,
          i,
          "summary"
        ),
      };
      if (interval == "daily") {
        this.laborHoursGridDataDaily.push(laborSummaryDailyWeekly);
      } else if (interval == "month") {
        this.laborHoursGridDataMonthly.push(laborSummaryDailyWeekly);
      } else {
        this.laborHoursGridDataWeekly.push(laborSummaryDailyWeekly);
      }
    }
  }

  mapLaborHoursData(
    daysData: any,
    interval: string,
    rownum: number,
    summ: string
  ): number[] {
    const daysDataArray: number[] = [];
    if (interval == "daily") {
      for (let i = 0; i < daysData.length; i++) {
        const c = daysData[i].TotalAvailableHour;
        daysDataArray.push(c);
        const dayWk: dayWeek = new dayWeek();
        dayWk.field = moment(daysData[i].LaborDate).format("M-D-YY");
        if (rownum == 0 && summ == "summary") {
          this.laborHoursDailyColumns.push(dayWk);
        }
      }
    } else if (interval == "month") {
      for (let i = 0; i < daysData.length; i++) {
        const c = daysData[i].TotalAvailableHour;
        daysDataArray.push(c);
        const dayWk: dayWeek = new dayWeek();
        dayWk.field = moment(daysData[i].WeekStart).format("M-D-YY");
        if (rownum == 0 && summ == "summary") {
          this.laborHoursMonthlyColumns.push(dayWk);
        }
      }
    } else {
      for (let i = 0; i < daysData.length; i++) {
        const c = daysData[i].TotalAvailableHour;
        daysDataArray.push(c);
        const dayWk: dayWeek = new dayWeek();
        dayWk.field = moment(daysData[i].WeekStart).format("M-D-YY");
        if (rownum == 0 && summ == "summary") {
          this.laborHoursWeekColumns.push(dayWk);
        }
      }
    }
    return daysDataArray;
  }

  mapOverTime(SummaryObj, interval: string) {
    let laborSummaryDailyWeekly = new LaborSummary();
    const dataForOverTimeDaily = [];
    const dataForOverTimeMonthly = [];
    const dataForOverTimeWeekly = [];
    for (let i = 0; i < SummaryObj.length; i++) {
      laborSummaryDailyWeekly = {
        ManagementName: SummaryObj[i].ManagementName.ManagementName,
        Assembly: SummaryObj[i].ManagementName.Assembly,
        ShiftDetails: SummaryObj[i].ManagementName.ShiftDetails,
        DayWeek: this.mapLaborOverTime(
          SummaryObj[i].WeeklyDates,
          interval,
          i,
          "summary"
        ),
      };
      if (interval == "daily") {
        dataForOverTimeDaily.push(laborSummaryDailyWeekly);
      } else if (interval == "month") {
        dataForOverTimeMonthly.push(laborSummaryDailyWeekly);
      } else {
        dataForOverTimeWeekly.push(laborSummaryDailyWeekly);
      }
    }
    this.gridDataForOverTimeDaily = [...dataForOverTimeDaily];
    this.gridDataForOverTimeMonthly = [...dataForOverTimeMonthly];
    this.gridDataForOverTimeWeekly = [...dataForOverTimeWeekly];
  }

  mapLaborOverTime(
    daysData: any,
    interval: string,
    rownum: number,
    summ: string
  ): number[] {
    const daysDataArray: number[] = [];
    if (interval == "daily") {
      for (let i = 0; i < daysData.length; i++) {
        const c = daysData[i].TotalAvailableOvertimeHour;
        daysDataArray.push(c);
        const dayWk: dayWeek = new dayWeek();
        dayWk.field = moment(daysData[i].LaborDate).format("M-D-YY");
        if (rownum == 0 && summ == "summary") {
          this.overTimeDailyColumns.push(dayWk);
        }
      }
    } else if (interval == "month") {
      for (let i = 0; i < daysData.length; i++) {
        const c = daysData[i].TotalAvailableOvertimeHour;
        daysDataArray.push(c);
        const dayWk: dayWeek = new dayWeek();
        dayWk.field = moment(daysData[i].WeekStart).format("M-D-YY");
        if (rownum == 0 && summ == "summary") {
          this.overTimeMonthlyColumns.push(dayWk);
        }
      }
    } else {
      for (let i = 0; i < daysData.length; i++) {
        const c = daysData[i].TotalAvailableOvertimeHour;
        daysDataArray.push(c);
        const dayWk: dayWeek = new dayWeek();
        dayWk.field = moment(daysData[i].WeekStart).format("M-D-YY");
        if (rownum == 0 && summ == "summary") {
          this.overTimeWeekColumns.push(dayWk);
        }
      }
    }
    return daysDataArray;
  }

  mapLoanedOut(SummaryObj, interval: string) {
    let laborSummaryLonedOutLabor = new LaborSummaryLonedOutLabor();
    for (let i = 0; i < SummaryObj.length; i++) {
      laborSummaryLonedOutLabor = {
        Department: SummaryObj[i].Department.Department,
        ShiftDetails: SummaryObj[i].Department.ShiftDetails,
        DayWeek: this.mapLaborLoanedOut(
          SummaryObj[i].WeeklyDates,
          interval,
          i,
          "summary"
        ),
      };
      if (interval == "daily") {
        this.gridDataForLoanedOutDaily.push(laborSummaryLonedOutLabor);
      } else if (interval == "month") {
        this.gridDataForLoanedOutMonthly.push(
          laborSummaryLonedOutLabor
        );
      } else {
        this.gridDataForLoanedOutWeekly.push(laborSummaryLonedOutLabor);
      }
    }
  }

  mapLaborLoanedOut(
    daysData: any,
    interval: string,
    rownum: number,
    summ: string
  ): number[] {
    const daysDataArray: number[] = [];
    if (interval == "daily") {
      for (let i = 0; i < daysData.length; i++) {
        const c = daysData[i].TotalAvailableHour;
        daysDataArray.push(c);
        const dayWk: dayWeek = new dayWeek();
        dayWk.field = moment(daysData[i].LaborDate).format("M-D-YY");
        if (rownum == 0 && summ == "summary") {
          this.lonedOuntDailyColumns.push(dayWk);
        }
      }
    } else if (interval == "month") {
      for (let i = 0; i < daysData.length; i++) {
        const c = daysData[i].TotalAvailableHour;
        daysDataArray.push(c);
        const dayWk: dayWeek = new dayWeek();
        dayWk.field = moment(daysData[i].WeekStart).format("M-D-YY");
        if (rownum == 0 && summ == "summary") {
          this.lonedOuntMonthlyColumns.push(dayWk);
        }
      }
    } else {
      for (let i = 0; i < daysData.length; i++) {
        const c = daysData[i].TotalAvailableHour;
        daysDataArray.push(c);
        const dayWk: dayWeek = new dayWeek();
        dayWk.field = moment(daysData[i].WeekStart).format("M-D-YY");
        if (rownum == 0 && summ == "summary") {
          this.lonedOuntWeekColumns.push(dayWk);
        }
      }
    }
    return daysDataArray;
  }

  mapLaborPool(SummaryObj, interval: string) {
    let laborSummaryLaborPool = new LaborSummaryLaborPool();
    const gridData = [];
    for (let i = 0; i < SummaryObj.length; i++) {
      laborSummaryLaborPool = {
        AssemblyName: SummaryObj[i].ManagementName.AssemblyName,
        DayShiftOnly: SummaryObj[i].ManagementName.DayShiftOnly,
        Department:
          SummaryObj[i].ManagementName.Department.toUpperCase(),
        LaborManagmentGroupID:
          SummaryObj[i].ManagementName.LaborManagmentGroupID,
        ManagementName: SummaryObj[i].ManagementName.ManagementName,
        ShiftName: SummaryObj[i].ManagementName.ShortDescription,
        Status: SummaryObj[i].ManagementName.Status,
        DayWeek: this.mapLaborPoolData(
          SummaryObj[i].WeeklyDates,
          interval,
          i,
          "summary"
        ),
      };
      if (interval == "daily") {
        gridData.push(laborSummaryLaborPool);
      } else if (interval == "month") {
        gridData.push(laborSummaryLaborPool);
      } else {
        gridData.push(laborSummaryLaborPool);
      }
    }

    if (interval == "daily") {
      this.gridDataForLaborPoolDaily = [...gridData];
      this.masterGridDataForLaborPoolDaily = [...gridData];
      const filter: CompositeFilterDescriptor = {
        filters: [],
        logic: "and",
      };
      this.filterChangeDaily(filter);
    } else if (interval == "month") {
      this.gridDataForLaborPoolMonthly = [...gridData];
      this.masterGridDataForLaborPoolMonthly = [...gridData];
      const filter: CompositeFilterDescriptor = {
        filters: [],
        logic: "and",
      };
      this.filterChangeDaily(filter);
    } else {
      this.gridDataForLaborPoolWeekly = [...gridData];
      this.masterGridDataForLaborPoolWeekly = [...gridData];
      const filter: CompositeFilterDescriptor = {
        filters: [],
        logic: "and",
      };
      this.filterChangeWeekly(filter);
    }
  }

  mapLaborPoolData(
    daysData: any,
    interval: string,
    rownum: number,
    summ: string
  ): number[] {
    const daysDataArray: number[] = [];
    if (interval == "daily") {
      for (let i = 0; i < daysData.length; i++) {
        const c = daysData[i].AssemblyTestCount;
        daysDataArray.push(c);
        const dayWk: dayWeek = new dayWeek();
        dayWk.field = moment(daysData[i].LaborDate).format("M-D-YY");
        if (rownum == 0 && summ == "summary") {
          this.adjustLaborDailyColumns.push(dayWk);
        }
      }
    } else if (interval == "month") {
      for (let i = 0; i < daysData.length; i++) {
        const c = daysData[i].AssemblyTestCount;
        daysDataArray.push(c);
        const dayWk: dayWeek = new dayWeek();
        dayWk.field = moment(daysData[i].WeekStart).format("M-D-YY");
        if (rownum == 0 && summ == "summary") {
          this.adjustLaborMonthlyColumns.push(dayWk);
        }
      }
    } else {
      for (let i = 0; i < daysData.length; i++) {
        const c = daysData[i].AssemblyTestCount;
        daysDataArray.push(c);
        const dayWk: dayWeek = new dayWeek();
        dayWk.field = moment(daysData[i].WeekStart).format("M-D-YY");
        if (rownum == 0 && summ == "summary") {
          this.adjustLaborWeekColumns.push(dayWk);
        }
      }
    }
    return daysDataArray;
  }

  onOpenAddEditDialog(isAdd: string, data) {
    if (this.activeAdjustLaborTab === 2) {
      this.addTechnicians = true;
      if (isAdd) {
        this.addEditHeader = "Add Technicians";
      } else {
        this.addEditHeader = "Edit Technicians";
        this.onEditLaborPool(data);
      }
    }
    if (this.activeAdjustLaborTab === 1) {
      this.addShiftType = true;
      if (isAdd) {
        this.addEditHeader = "Add Shift";
      } else {
        this.addEditHeader = "Edit Shift";
        this.onEditShiftType(data);
      }
    }
    if (this.activeAdjustLaborTab === 4) {
      if (isAdd) {
        this.addEditHeader = "Add Management Group";
        this.addManagementGroup = true;
      } else {
        this.addEditHeader = "Edit Management Group";
        this.onEditManagementGroup(data);
      }
    }
  }

  onEditShiftType(data: Shifts) {
    this.shiftDescription = data.description;
    this.shiftShortDescription = data.shortDescription;
    const com = this.compressionItem.filter(
      (item) => item.text === data.compression
    )[0]?.value;
    this.compressionValueForEdit = { text: data.compression, value: com };
    this.isDayShift = data.dayShiftType === "Yes" ? true : false;
    this.shiftStartTimeValue = moment(
      data.shiftStartTime,
      "hh:mm a"
    ).toDate();
    if (data.shiftStartTime.includes('PM') && data.shiftEndTime.includes('AM')) {
      this.shiftEndTimeValue = moment(data.shiftEndTime, "hh:mm a").toDate();
      this.shiftEndTimeValue.setDate(
        this.shiftEndTimeValue.getDate() + 1
      );
    } else {
      this.shiftEndTimeValue = moment(data.shiftEndTime, "hh:mm a").toDate();
    }
    
    this.shiftHoursPerShift = this.getHoursPerDay(data);
    this.isWeek1Sun = data.sunday1 > 0 ? true : false;
    this.isWeek1Mon = data.monday1 > 0 ? true : false;
    this.isWeek1Tue = data.tuesday1 > 0 ? true : false;
    this.isWeek1Wed = data.wednesday1 > 0 ? true : false;
    this.isWeek1Thu = data.thursday1 > 0 ? true : false;
    this.isWeek1Fri = data.friday1 > 0 ? true : false;
    this.isWeek1Sat = data.saturday1 > 0 ? true : false;
    this.isWeek2Sun = data.sunday2 > 0 ? true : false;
    this.isWeek2Mon = data.monday2 > 0 ? true : false;
    this.isWeek2Tue = data.tuesday2 > 0 ? true : false;
    this.isWeek2Wed = data.wednesday2 > 0 ? true : false;
    this.isWeek2Thu = data.thursday2 > 0 ? true : false;
    this.isWeek2Fri = data.friday2 > 0 ? true : false;
    this.isWeek2Sat = data.saturday2 > 0 ? true : false;
    this.shiftTypeId = data.shiftID;
  }

  getHoursPerDay(data: Shifts): number {
    if (data.sunday1 > 0) {
      data.hoursPerDay = data.sunday1;
    } else if (data.monday1 > 0) {
      data.hoursPerDay = data.monday1;
    } else if (data.tuesday1 > 0) {
      data.hoursPerDay = data.tuesday1;
    } else if (data.wednesday1 > 0) {
      data.hoursPerDay = data.wednesday1;
    } else if (data.thursday1 > 0) {
      data.hoursPerDay = data.thursday1;
    } else if (data.friday1 > 0) {
      data.hoursPerDay = data.friday1;
    } else if (data.saturday1 > 0) {
      data.hoursPerDay = data.saturday1;
    } else if (data.sunday2 > 0) {
      data.hoursPerDay = data.sunday2;
    } else if (data.monday2 > 0) {
      data.hoursPerDay = data.monday2;
    } else if (data.tuesday2 > 0) {
      data.hoursPerDay = data.tuesday2;
    } else if (data.wednesday2 > 0) {
      data.hoursPerDay = data.wednesday2;
    } else if (data.thursday2 > 0) {
      data.hoursPerDay = data.thursday2;
    } else if (data.friday2 > 0) {
      data.hoursPerDay = data.friday2;
    } else if (data.saturday2 > 0) {
      data.hoursPerDay = data.saturday2;
    }

    return data.hoursPerDay;
  }
  onEditManagementGroup(data) {
    this.efficiencyFactor = data.efficencyFactor;
    const value = this.managementGroup.filter(
      (item) => item.text === data.managementName
    )[0].value;
    this.managementGroupValue = { text: data.managementName, value: value };
    this.managementGroupName = this.managementGroupValue.text;
    this.overTimeAllowance = data.overtimeAllowance;
    this.pto = data.ptoPercentage;
    this.utilizationTarget = data.utilizationTarget;
    this.laborManagmentGroupID = data.laborManagmentGroupID;
    this.addManagementGroup = true;
  }
  onEditLaborPool(data) {
    const shiftType = this.shiftTypeItems.filter(
      (item) => item.text?.toLowerCase() === data.ShiftName?.toLowerCase()
    )[0]?.value;
    this.shiftTypeValue = { text: data.ShiftName, value: shiftType };

    this.mgGroupValue = {
      text: data.ManagementName,
      value: data.LaborManagmentGroupID,
    };

    const loaningForm = this.departmentItem.filter(
      (item) =>
        item.text?.toLowerCase() === data.Department?.toLowerCase()
    )[0]?.value;
    this.loaningFormValue = { text: data.Department, value: loaningForm };

    const StatusValue = this.statusItems.filter(
      (item) => item.text?.toLowerCase() === data.Status?.toLowerCase()
    )[0]?.value;
    this.statusValue = { text: data.Status, value: StatusValue };

    if (this.statusValue.text === "Standard") {
      this.hideDepartmentDropDown = true;
    } else {
      this.hideDepartmentDropDown = false;
    }

    if (this.statusValue.text === "On Loan") {
      this.hideDepartmentDropDown = false;
      this.departmentHeader = "Department Loaning From";
    }
    if (this.statusValue.text === "Loaned Out") {
      this.hideDepartmentDropDown = false;
      this.departmentHeader = "Department Loaning To";
    }

    const laborTypeValue = this.laborTypeItem.filter(
      (item) =>
        item.text?.toLowerCase() === data.AssemblyName?.toLowerCase()
    )[0]?.value;
    this.laborTypeValue = {
      text: data.AssemblyName,
      value: laborTypeValue,
    };

    this.laborManagmentGroupID = data.LaborManagmentGroupID;
  }
  onAddManagementGroup(isAdd: boolean) {
    const request = new LaborManagementGroup();
    request.efficencyFactor = this.efficiencyFactor;
    request.overtimeAllowance = this.overTimeAllowance;
    request.pTOPercentage = this.pto;
    request.utilizationTarget = this.utilizationTarget;
    request.managementName = this.managementGroupName;
    request.plantID = this.site?.plantId;
    request.createdOn = new Date(
      new Date().getTime() - new Date().getTimezoneOffset() * 60000
    );
    if (
      request.managementName !== undefined &&
      request.managementName !== "" &&
      request.managementName !== null
    ) {
      if (isAdd) {
        this.laborService
          .AddManagementGroup(request)
          .subscribe((res) => {
            if (res) {
              this.getManagementGroup();
            }
          });
      } else {
        request.laborManagmentGroupID = this.laborManagmentGroupID;
        this.laborService
          .UpdateManagementGroup(request)
          .subscribe((res) => {
            if (res) {
              this.getManagementGroup();
            }
          });
      }
      this.onCloseAdjustLabor();
    }
  }

  resetManagementGroup() {
    this.overTimeAllowance = this.defaultManagementGroupData.filter(
      (x) => x.plantID == this.site.plantId
    )[0].overtimePerc;
    this.efficiencyFactor = this.defaultManagementGroupData.filter(
      (x) => x.plantID == this.site.plantId
    )[0].efficencyFactory;
    this.utilizationTarget = this.defaultManagementGroupData.filter(
      (x) => x.plantID == this.site.plantId
    )[0].laborUtilization;
    this.pto = this.defaultManagementGroupData.filter(
      (x) => x.plantID == this.site.plantId
    )[0].ptoPerc;
    this.managementGroupValue = { text: "", value: 0 };
    this.managementGroupName = "";
  }

  onCloseAdjustLabor() {
    if (this.activeAdjustLaborTab === 2) {
      this.addTechnicians = false;
    }
    if (this.activeAdjustLaborTab === 1) {
      this.addShiftType = false;
    }
    if (this.activeAdjustLaborTab === 4) {
      this.addManagementGroup = false;
    }

    this.resetManagementGroup();
    this.resetShiftType();
    this.resetAddAssembly();
  }

  getSelectedTab(event) {
    this.activeAdjustLaborTab = event.index;
  }

  setDatesDeffWeekly() {
    // Dates by Def
    this.minDate = new Date(this.today.getTime());
    this.maxDate = new Date(this.today.getTime());
    this.maxDate.setMonth(this.maxDate.getMonth() + 6);
  }

  setDatesDeffDaily() {
    // Dates by Def
    this.minDate = new Date(this.today.getTime());
    this.maxDate = new Date(
      this.today.getTime() + 1000 * 60 * 60 * 24 * 60
    );
  }

  setDatesDeffMonth() {
    // Dates by Def
    this.minDate = new Date(this.today.getTime());
    this.maxDate = new Date(this.today.getTime());
    this.maxDate.setFullYear(this.maxDate.getFullYear() + 1);
  }

  timeViewChange(view) {
    if (view.text === "Weekly") {
      this.setDatesDeffWeekly();
      this.showUnits = "Unit = People";
      this.isShiftType = false;
      this.isDayNight = false;
      this.isNone = true;
      this.isShowShiftType = this.isShiftType;
      this.isShowDayNight = this.isDayNight;
      this.isShowNone = this.isNone;
      this.isShowEditView = true;
      this.getHeadCountWeekly();
      this.getOverTimeWeekly();
      this.getLaborHoursWeekly();
      this.getLonedOutLaborWeekly();
      this.getLaborPoolWeekly();
    }
    if (view.text === "Daily") {
      this.setDatesDeffDaily();
      this.showUnits = "Unit = People";
      this.isShiftType = false;
      this.isDayNight = false;
      this.isNone = true;
      this.isShowShiftType = this.isShiftType;
      this.isShowDayNight = this.isDayNight;
      this.isShowNone = this.isNone;
      this.isShowEditView = true;
      this.getHeadCountDaily();
      this.getOverTimeDaily();
      this.getLaborHoursDaily();
      this.getLonedOutLaborDaily();
      this.getLaborPoolDaily();
    }
    if (view.text === "Monthly") {
      this.setDatesDeffMonth();
      this.showUnits = "Unit = People";
      this.isShiftType = false;
      this.isDayNight = false;
      this.isNone = true;
      this.isShowShiftType = this.isShiftType;
      this.isShowDayNight = this.isDayNight;
      this.isShowNone = this.isNone;
      this.isShowEditView = true;
      this.getHeadCountMonthly();
      this.getOverTimeMonthly();
      this.getLaborHoursMonthly();
      this.getLonedOutLaborMonthly();
      this.getLaborPoolMonthly();
    }
  }

  public changeStartDate() {
    if (this.minDate > this.maxDate) {
      this.maxDate = new Date(this.minDate.getTime());
    }
    this.timeRangeChanged();
  }

  public timeRangeChanged() {
    if (this.timeViewValue.text === "Weekly") {
      this.isShowShiftType = this.isShiftType;
      this.isShowDayNight = this.isDayNight;
      this.isShowNone = this.isNone;
      this.isShowEditView = true;
      this.getHeadCountWeekly();
      this.getOverTimeWeekly();
      this.getLaborHoursWeekly();
      this.getLonedOutLaborWeekly();
      this.getLaborPoolWeekly();
    }
    if (this.timeViewValue.text === "Daily") {
      this.isShowShiftType = this.isShiftType;
      this.isShowDayNight = this.isDayNight;
      this.isShowNone = this.isNone;
      this.isShowEditView = true;
      this.getHeadCountDaily();
      this.getOverTimeDaily();
      this.getLaborHoursDaily();
      this.getLonedOutLaborDaily();
      this.getLaborPoolDaily();
    }
    if (this.timeViewValue.text === "Monthly") {
      this.isShowShiftType = this.isShiftType;
      this.isShowDayNight = this.isDayNight;
      this.isShowNone = this.isNone;
      this.isShowEditView = true;
      this.getHeadCountMonthly();
      this.getOverTimeMonthly();
      this.getLaborHoursMonthly();
      this.getLonedOutLaborMonthly();
      this.getLaborPoolMonthly();
    }
  }

  week1MondayShift() {
    this.isWeek1Mon = !this.isWeek1Mon;
    if (this.isWeek1Mon) {
      this.isSaveShiftType = false;
    }
  }
  week1TuesdayShift() {
    this.isWeek1Tue = !this.isWeek1Tue;
    if (this.isWeek1Tue) {
      this.isSaveShiftType = false;
    }
  }
  week1WednesdayShift() {
    this.isWeek1Wed = !this.isWeek1Wed;
    if (this.isWeek1Wed) {
      this.isSaveShiftType = false;
    }
  }
  week1ThursdayShift() {
    this.isWeek1Thu = !this.isWeek1Thu;
    if (this.isWeek1Thu) {
      this.isSaveShiftType = false;
    }
  }
  week1FridayShift() {
    this.isWeek1Fri = !this.isWeek1Fri;
    if (this.isWeek1Fri) {
      this.isSaveShiftType = false;
    }
  }
  week1SaturdayShift() {
    this.isWeek1Sat = !this.isWeek1Sat;
    if (this.isWeek1Sat) {
      this.isSaveShiftType = false;
    }
  }
  week1SundayShift() {
    this.isWeek1Sun = !this.isWeek1Sun;
    if (this.isWeek1Sun) {
      this.isSaveShiftType = false;
    }
  }
  week2MondayShift() {
    this.isWeek2Mon = !this.isWeek2Mon;
    if (this.isWeek2Mon) {
      this.isSaveShiftType = false;
    }
  }
  week2TuesdayShift() {
    this.isWeek2Tue = !this.isWeek2Tue;
    if (this.isWeek2Tue) {
      this.isSaveShiftType = false;
    }
  }
  week2WednesdayShift() {
    this.isWeek2Wed = !this.isWeek2Wed;
    if (this.isWeek2Wed) {
      this.isSaveShiftType = false;
    }
  }
  week2ThursdayShift() {
    this.isWeek2Thu = !this.isWeek2Thu;
    if (this.isWeek2Thu) {
      this.isSaveShiftType = false;
    }
  }
  week2FridayShift() {
    this.isWeek2Fri = !this.isWeek2Fri;
    if (this.isWeek2Fri) {
      this.isSaveShiftType = false;
    }
  }
  week2SaturdayShift() {
    this.isWeek2Sat = !this.isWeek2Sat;
    if (this.isWeek2Sat) {
      this.isSaveShiftType = false;
    }
  }
  week2SundayShift() {
    this.isWeek2Sun = !this.isWeek2Sun;
    if (this.isWeek2Sun) {
      this.isSaveShiftType = false;
    }
  }

  public onStateChangeForBuild(state: State) {
    this.gridState = state;
  }
  public cellClickHandlerForBuild({
    sender,
    rowIndex,
    columnIndex,
    dataItem,
    isEdited,
  }) {
    if (!isEdited) {
      sender.editCell(
        rowIndex,
        columnIndex,
        this.createFormGroupForBuild(dataItem)
      );
    }
  }

  public cellCloseHandlerForBuild(args: any) {
    const { formGroup, dataItem } = args;

    if (!formGroup.valid) {
      args.preventDefault();
    } else if (formGroup.dirty) {
      this.editService.assignValues(dataItem, formGroup.value);
      this.editService.update(dataItem, "Build Multiplier");
    }
  }

  public cancelHandlerForBuild({ sender, rowIndex }) {
    sender.closeRow(rowIndex);
  }

  public saveHandlerForBuild({ sender, formGroup, rowIndex }) {
    if (formGroup.valid) {
      this.editService.create(formGroup.value);
      sender.closeRow(rowIndex);
    }
  }

  public createFormGroupForBuild(dataItem: any): FormGroup {
    return this.formBuilder.group({
      buildTypeName: dataItem.buildTypeName,
      multiplierValue: dataItem.multiplierValue,
    });
  }

  public onStateChangeForProductType(state: State) {
    this.gridState = state;
  }
  public cellClickHandlerForProductType({
    sender,
    rowIndex,
    columnIndex,
    dataItem,
    isEdited,
  }) {
    if (!isEdited) {
      sender.editCell(
        rowIndex,
        columnIndex,
        this.createFormGroupForProductType(dataItem)
      );
    }
  }

  public cellCloseHandlerForProductType(args: any) {
    const { formGroup, dataItem } = args;

    if (!formGroup.valid) {
      args.preventDefault();
    } else if (formGroup.dirty) {
      this.editService.assignValues(dataItem, formGroup.value);
      this.editService.update(dataItem, "Product Type Mapping");
    }
  }

  public cancelHandlerForProductType({ sender, rowIndex }) {
    sender.closeRow(rowIndex);
  }

  public saveHandlerForProductType({ sender, formGroup, rowIndex }) {
    if (formGroup.valid) {
      this.editService.create(formGroup.value);
      sender.closeRow(rowIndex);
    }
  }

  public saveChangesForProductType(grid: any): void {
    grid.closeCell();
    grid.cancelCell();
    const updatedData = this.editService.saveChanges();
    const request: LabourManagementGroupMappingRequest[] = [];
    updatedData.forEach((item) => {
      item.forEach((m) => {
        const req = new LabourManagementGroupMappingRequest();
        req.laborMgmtGrpDetails = m.laborMgmtGrpDetails;
        req.laborManagmentGroupID = m.laborManagmentGroupID;
        req.managementName = m.managementName;
        req.laborManagmentProductGroupID =
          m.laborManagmentProductGroupID;
        req.laborProductGroupID = m.laborProductGroupID;
        request.push(req);
      });
    });
    this.laborService
      .UpdateProductManagmentMap(request)
      .subscribe((res) => {
        if (res) {
          this.getProductTypeMapping();
          this.showSuccess("Saved");
        }
      });
  }
  public saveChangesForBuildMultiplier(grid: any): void {
    grid.closeCell();
    grid.cancelCell();
    const updatedData: any[] = this.editService.saveChanges();
    const request: BuildType[] = [];

    updatedData.forEach((item) => {
      item.forEach((m) => {
        const req = new BuildType();
        req.buildTypeID = m.buildTypeID;
        req.buildTypeName = m.buildTypeName;
        req.laborMultiplier = m.laborMultiplier;
        req.multiplierValue = m.multiplierValue;
        req.plantID = this.site?.plantId;
        request.push(req);
      });
    });

    this.laborService.UpdateBuildType(request).subscribe((res) => {
      if (res) {
        this.getBuildType();
        this.showSuccess("Saved");
      }
    });
  }

  public cancelChangesForBuildMultiplier(grid: any): void {
    this.gridDataForLaborMultiplier = JSON.parse(
      JSON.stringify(this.tempGridDataForLaborMultiplier)
    );
    this.editService.cancelChanges();
  }
  public cancelChangesForProductTypeMapping(grid: any): void {
    this.gridDataForProductType = JSON.parse(
      JSON.stringify(this.tempGridDataForProductType)
    );
    this.productTypeGroup = [...this.masterProductTypeGroup];
    this.editService.cancelChanges();
  }
  public createFormGroupForProductType(dataItem: any): FormGroup {
    return this.formBuilder.group({
      laborProductName: dataItem.laborProductName,
      name: dataItem.name,
    });
  }

  public filterChangeWeekly(filter: CompositeFilterDescriptor): void {
    this.filter = filter;
    this.gridDataWeekly = filterBy(
      this.masterGridDataForLaborPoolWeekly,
      filter
    );
  }

  public filterChangeDaily(filter: CompositeFilterDescriptor): void {
    this.filter = filter;
    this.gridDataDaily = filterBy(
      this.masterGridDataForLaborPoolDaily,
      filter
    );
  }
  public filterChangeMonthly(filter: CompositeFilterDescriptor): void {
    this.filter = filter;
    this.gridDataMonthly = filterBy(
      this.masterGridDataForLaborPoolMonthly,
      filter
    );
  }
  public distinctPrimitiveWeekly(fieldName: string): any {
    return distinct(this.masterGridDataForLaborPoolWeekly, fieldName).map(
      (item) => item[fieldName]
    );
  }
  public distinctPrimitiveDaily(fieldName: string): any {
    return distinct(this.masterGridDataForLaborPoolDaily, fieldName).map(
      (item) => item[fieldName]
    );
  }
  public distinctPrimitiveMonthly(fieldName: string): any {
    return distinct(this.masterGridDataForLaborPoolMonthly, fieldName).map(
      (item) => item[fieldName]
    );
  }

  public onFilterWeekly(inputValue: string): void {
    this.gridView = process(this.gridDataWeekly, {
      filter: {
        logic: "or",
        filters: [
          {
            field: "ManagementGroup",
            operator: "contains",
            value: inputValue,
          },
          {
            field: "A/T",
            operator: "contains",
            value: inputValue,
          },
          {
            field: "Status",
            operator: "contains",
            value: inputValue,
          },
          {
            field: "Department",
            operator: "contains",
            value: inputValue,
          },
          {
            field: "ShiftType",
            operator: "contains",
            value: inputValue,
          },
          {
            field: "DayShift",
            operator: "contains",
            value: inputValue,
          },
        ],
      },
    }).data;
    this.dataBinding.skip = 0;
  }
  public onFilterDaily(inputValue: string): void {
    this.gridView = process(this.gridDataDaily, {
      filter: {
        logic: "or",
        filters: [
          {
            field: "ManagementName",
            operator: "contains",
            value: inputValue,
          },
          {
            field: "AssemblyName",
            operator: "contains",
            value: inputValue,
          },
          {
            field: "Status",
            operator: "contains",
            value: inputValue,
          },
          {
            field: "Department",
            operator: "contains",
            value: inputValue,
          },
          {
            field: "ShiftName",
            operator: "contains",
            value: inputValue,
          },
          {
            field: "DayShiftOnly",
            operator: "contains",
            value: inputValue,
          },
        ],
      },
    }).data;
    this.dataBinding.skip = 0;
  }
  public onFilterMonthly(inputValue: string): void {
    this.gridView = process(this.gridDataMonthly, {
      filter: {
        logic: "or",
        filters: [
          {
            field: "ManagementName",
            operator: "contains",
            value: inputValue,
          },
          {
            field: "AssemblyName",
            operator: "contains",
            value: inputValue,
          },
          {
            field: "Status",
            operator: "contains",
            value: inputValue,
          },
          {
            field: "Department",
            operator: "contains",
            value: inputValue,
          },
          {
            field: "ShiftName",
            operator: "contains",
            value: inputValue,
          },
          {
            field: "DayShiftOnly",
            operator: "contains",
            value: inputValue,
          },
        ],
      },
    }).data;
    this.dataBinding.skip = 0;
  }

  public onChangeShiftStartTime(value: Date) {
    if (value === null || value === undefined) {
      this.invalidShiftStartTime = true;
    } else {
      this.invalidShiftStartTime = false;
      this.shiftStartTimeValue = value;
      if (
        (this.shiftEndTimeValue.getTime() -
          this.shiftStartTimeValue.getTime()) /
        3600000 <
        0
      ) {
        this.shiftEndTimeValue.setDate(
          this.shiftEndTimeValue.getDate() + 1
        );
      }
      if (
        this.shiftStartTimeValue.getTime() ===
        this.shiftEndTimeValue.getTime()
      ) {
        this.sameShiftEndTime = true;
      } else {
        this.sameShiftEndTime = false;
      }
    }
  }
  public onChangeShiftEndTime(value: Date) {
    if (value === null || value === undefined) {
      this.inavlidShiftEndTime = true;
    } else {
      this.inavlidShiftEndTime = false;
      this.sameShiftEndTime = false;
      this.shiftEndTimeValue = value;
      if (
        moment(this.shiftStartTimeValue).format("MM/DD/yyyy HH:mm") ===
        moment(this.shiftEndTimeValue).format("MM/DD/yyyy HH:mm")
      ) {
        this.sameShiftEndTime = true;
      } else if (
        (this.shiftEndTimeValue.getTime() -
          this.shiftStartTimeValue.getTime()) /
        3600000 <
        0
      ) {
        this.sameShiftEndTime = false;
        this.shiftEndTimeValue.setDate(
          this.shiftEndTimeValue.getDate() + 1
        );
      } else {
        this.sameShiftEndTime = false;
      }
    }
  }
  public onChangeHoursPerShift(value: number) {
    if (
      value <=
      Math.round(
        ((this.shiftEndTimeValue.getTime() -
          this.shiftStartTimeValue.getTime()) /
          3600000) *
        100
      ) /
      100 &&
      this.shiftHoursPerShift !== 0
    ) {
      this.shiftHoursPerShiftError = false;
    } else {
      this.shiftHoursPerShiftError = true;
    }
  }
  public onChangeDayShift(isDayShift) {
    this.isDayShift = !isDayShift;
  }
  onChangeShiftDecscription() {
    if (
      this.shiftDescription === null ||
      this.shiftDescription === undefined ||
      this.shiftDescription === ""
    ) {
      this.missingShiftDescription = true;
    } else {
      this.missingShiftDescription = false;
    }
  }
  onChangeShiftShortDecscription() {
    if (
      this.shiftShortDescription === null ||
      this.shiftShortDescription === undefined ||
      this.shiftShortDescription === ""
    ) {
      this.missingShiftShortDescription = true;
    } else {
      this.missingShiftShortDescription = false;
    }
  }
  public onSaveShiftType(isAdd: boolean) {
    if (
      this.shiftDescription === null ||
      this.shiftDescription === undefined ||
      this.shiftDescription === ""
    ) {
      this.missingShiftDescription = true;
    } else if (
      this.shiftShortDescription === null ||
      this.shiftShortDescription === undefined ||
      this.shiftShortDescription === ""
    ) {
      this.missingShiftShortDescription = true;
    } else if (
      !this.compressionValueForEdit ||
      (this.compressionValueForEdit &&
        (this.compressionValueForEdit.text === undefined ||
          this.compressionValueForEdit.text === null ||
          this.compressionValueForEdit.text === ""))
    ) {
      this.missingCompressionValueForEdit = true;
    } else if (
      this.shiftStartTimeValue === null ||
      this.shiftStartTimeValue === undefined
    ) {
      this.invalidShiftStartTime = true;
    } else if (
      this.shiftEndTimeValue === null ||
      this.shiftEndTimeValue === undefined
    ) {
      this.inavlidShiftEndTime = true;
    } else if (
      this.shiftEndTimeValue.getTime() ===
      this.shiftStartTimeValue.getTime()
    ) {
      this.sameShiftEndTime = true;
    } else if (
      this.shiftHoursPerShift >
      (this.shiftEndTimeValue.getTime() -
        this.shiftStartTimeValue.getTime()) /
      3600000 ||
      this.shiftHoursPerShift === 0
    ) {
      this.shiftHoursPerShiftError = true;
    } else if (
      this.shiftHoursPerShift === null ||
      this.shiftHoursPerShift === undefined ||
      this.shiftHoursPerShift === 0
    ) {
      this.shiftHoursPerShiftError = true;
    } else if (
      !this.isWeek1Mon &&
      !this.isWeek1Tue &&
      !this.isWeek1Wed &&
      !this.isWeek1Thu &&
      !this.isWeek1Fri &&
      !this.isWeek1Sat &&
      !this.isWeek1Sun &&
      !this.isWeek2Mon &&
      !this.isWeek2Tue &&
      !this.isWeek2Wed &&
      !this.isWeek2Thu &&
      !this.isWeek2Fri &&
      !this.isWeek2Sat &&
      !this.isWeek2Sun
    ) {
      this.isSaveShiftType = true;
    } else {
      const req: Shifts[] = [];
      const request1 = new Shifts();
      request1.shiftName = "";
      request1.description = this.shiftDescription;
      request1.shortDescription = this.shiftShortDescription;
      request1.compression = this.compressionValueForEdit.text;
      request1.dayShiftType = this.isDayShift ? "T" : "F";
      request1.shiftStartTime = moment(this.shiftStartTimeValue).format(
        "MM/DD/yyyy hh:mm a"
      );
      request1.shiftEndTime = moment(this.shiftEndTimeValue).format(
        "MM/DD/yyyy hh:mm a"
      );
      request1.hoursPerDay = this.shiftHoursPerShift;
      request1.monday1 = this.isWeek1Mon ? 1 : 0;
      request1.tuesday1 = this.isWeek1Tue ? 1 : 0;
      request1.wednesday1 = this.isWeek1Wed ? 1 : 0;
      request1.thursday1 = this.isWeek1Thu ? 1 : 0;
      request1.friday1 = this.isWeek1Fri ? 1 : 0;
      request1.saturday1 = this.isWeek1Sat ? 1 : 0;
      request1.sunday1 = this.isWeek1Sun ? 1 : 0;
      request1.PlantID = this.site?.plantId;

      const request2 = new Shifts();
      request2.shiftName = "";
      request2.description = this.shiftDescription;
      request2.shortDescription = this.shiftShortDescription;
      request2.compression = this.compressionValueForEdit.text;
      request2.dayShiftType = this.isDayShift ? "T" : "F";
      request2.shiftStartTime = moment(this.shiftStartTimeValue).format(
        "MM/DD/yyyy hh:mm a"
      );
      request2.shiftEndTime = moment(this.shiftEndTimeValue).format(
        "MM/DD/yyyy hh:mm a"
      );
      request2.hoursPerDay = this.shiftHoursPerShift;
      request2.monday1 = this.isWeek2Mon ? 1 : 0;
      request2.tuesday1 = this.isWeek2Tue ? 1 : 0;
      request2.wednesday1 = this.isWeek2Wed ? 1 : 0;
      request2.thursday1 = this.isWeek2Thu ? 1 : 0;
      request2.friday1 = this.isWeek2Fri ? 1 : 0;
      request2.saturday1 = this.isWeek2Sat ? 1 : 0;
      request2.sunday1 = this.isWeek2Sun ? 1 : 0;
      request2.PlantID = this.site?.plantId;

      if (isAdd) {
        req.push(request1);
        req.push(request2);
        this.laborService.AddShift(req).subscribe((res) => {
          if (res) {
            this.onCloseAdjustLabor();
            this.getShiftType();
            this.getShiftTypeDDL();
          }
        });
      } else {
        request1.shiftID = this.shiftTypeId;
        request2.shiftID = this.shiftTypeId;
        request1.weeknum = 1;
        request2.weeknum = 2;
        req.push(request1);
        req.push(request2);
        this.laborService.UpdateShift(req).subscribe((res) => {
          if (res) {
            this.onCloseAdjustLabor();
            this.getShiftType();
            this.getShiftTypeDDL();
          }
        });
      }
      this.onCloseAdjustLabor();
    }
  }

  resetShiftType() {
    this.shiftDescription = "";
    this.shiftShortDescription = "";
    this.compressionValueForEdit = { text: "", value: 0 };
    this.isDayShift = false;
    this.isSameWeek = false;
    this.shiftHoursPerShiftError = false;
    this.shiftStartTimeValue = new Date();
    this.shiftEndTimeValue = new Date();
    this.shiftEndTimeValue.setHours(this.shiftEndTimeValue.getHours() + 1);
    this.shiftHoursPerShift = undefined;
    this.isWeek1Mon = false;
    this.isWeek1Tue = false;
    this.isWeek1Wed = false;
    this.isWeek1Thu = false;
    this.isWeek1Fri = false;
    this.isWeek1Sat = false;
    this.isWeek1Sun = false;
    this.isWeek2Mon = false;
    this.isWeek2Tue = false;
    this.isWeek2Wed = false;
    this.isWeek2Thu = false;
    this.isWeek2Fri = false;
    this.isWeek2Sat = false;
    this.isWeek2Sun = false;
    this.missingShiftDescription = false;
    this.missingShiftShortDescription = false;
    this.missingCompressionValueForEdit = false;
    this.isSaveShiftType = false;
    this.invalidShiftStartTime = false;
    this.inavlidShiftEndTime = false;
    this.sameShiftEndTime = false;
  }
  onHeadCountChange(value) {
    this.addLaborPoolError = false;
    this.headcountError = false;
    this.biggerEndDateError = false;
    this.existingRecordError = false;
  }

  public onSaveLaborPool(isAdd: boolean) {
    if (
      this.technicianEffectiveDate === undefined ||
      this.technicianEffectiveDate === null
    ) {
      this.addLaborPoolError = true;
      this.biggerEndDateError = false;
      this.headcountError = false;
      this.existingRecordError = false;
    } else if (
      (this.technicianEndDate?.getTime() -
        this.technicianEffectiveDate?.getTime()) /
      (1000 * 3600 * 24) <
      0
    ) {
      this.biggerEndDateError = true;
      this.addLaborPoolError = false;
      this.headcountError = false;
      this.existingRecordError = false;
    } else if (this.headCount === undefined || this.headCount === null) {
      this.headcountError = true;
      this.addLaborPoolError = false;
      this.biggerEndDateError = false;
      this.existingRecordError = false;
    } else {
      this.addLaborPoolError = false;
      this.biggerEndDateError = false;
      this.headcountError = false;
      this.existingRecordError = false;
      if (
        this.technicianEndDate === undefined ||
        this.technicianEndDate === null
      ) {
        const date = new Date();
        date.setMonth(
          new Date(this.technicianEffectiveDate).getMonth() + 6
        ).toString();
        this.technicianEndDate = date;
      }
      const request = new LaborAssemblyTechnicianViewModel();
      request.shiftID = this.shiftTypeItems.filter(
        (item) =>
          item.text.toLowerCase() ===
          this.shiftTypeValue?.text?.toLowerCase()
      )[0]?.value;
      request.assembleyTest = this.laborTypeValue?.text;
      request.status = this.statusValue?.text;
      request.managementGroup = this.mgGroupValue?.value.toString();

      const effectiveDateString = moment(
        this.technicianEffectiveDate
      ).format("yyyy-MM-DD");
      request.effectiveDateString = effectiveDateString;

      const endDateString = moment(this.technicianEndDate).format(
        "yyyy-MM-DD"
      );
      request.endDateString = endDateString;

      request.loanDeptFromTo = this.loaningFormValue?.text.toLowerCase();
      request.headCount = this.headCount;
      request.PlantID = this.site?.plantId;
      if (isAdd) {
        if (this.timeViewValue.text === "Weekly") {
          this.existingRecordError = false;
          this.gridDataForLaborPoolWeekly?.forEach((item) => {
            if (
              item.Department.toLowerCase() ===
              request.loanDeptFromTo.toLowerCase() &&
              item.AssemblyName.toLowerCase() ===
              request.assembleyTest.toLowerCase() &&
              item.ManagementName.toLowerCase() ===
              this.mgGroupValue.text.toLowerCase() &&
              item.ShiftName.toLowerCase() ===
              this.shiftTypeValue?.text.toLowerCase() &&
              item.Status.toLowerCase() ===
              this.statusValue?.text.toLowerCase()
            ) {
              this.existingRecordError = true;
            }
          });
          if (!this.existingRecordError) {
            this.loadLaborPool = true;
            this.laborService
              .AddAssemblyTechnician(request)
              .subscribe((res) => {
                if (res) {
                  this.getLaborPoolWeekly();
                  this.getHeadCountWeekly();
                  this.getLaborHoursWeekly();
                  this.getOverTimeWeekly();
                  this.getLonedOutLaborWeekly();
                }
              });
            this.onCloseAdjustLabor();
          }
        } else if (this.timeViewValue.text === "Daily") {
          this.existingRecordError = false;
          this.gridDataForLaborPoolDaily?.forEach((item) => {
            if (
              item.Department.toLowerCase() ===
              request.loanDeptFromTo.toLowerCase() &&
              item.AssemblyName.toLowerCase() ===
              request.assembleyTest.toLowerCase() &&
              item.ManagementName.toLowerCase() ===
              this.mgGroupValue.text.toLowerCase() &&
              item.ShiftName.toLowerCase() ===
              this.shiftTypeValue?.text.toLowerCase() &&
              item.Status.toLowerCase() ===
              this.statusValue?.text.toLowerCase()
            ) {
              this.existingRecordError = true;
            }
          });
          if (!this.existingRecordError) {
            this.loadLaborPool = true;
            this.laborService
              .AddAssemblyTechnician(request)
              .subscribe((res) => {
                if (res) {
                  this.getLaborPoolDaily();
                  this.getHeadCountDaily();
                  this.getLaborHoursDaily();
                  this.getOverTimeDaily();
                  this.getLonedOutLaborDaily();
                }
              });
            this.onCloseAdjustLabor();
          }
        } else {
          this.existingRecordError = false;
          this.gridDataForLaborPoolMonthly?.forEach((item) => {
            if (
              item.Department.toLowerCase() ===
              request.loanDeptFromTo.toLowerCase() &&
              item.AssemblyName.toLowerCase() ===
              request.assembleyTest.toLowerCase() &&
              item.ManagementName.toLowerCase() ===
              this.mgGroupValue.text.toLowerCase() &&
              item.ShiftName.toLowerCase() ===
              this.shiftTypeValue?.text.toLowerCase() &&
              item.Status.toLowerCase() ===
              this.statusValue?.text.toLowerCase()
            ) {
              this.existingRecordError = true;
            }
          });
          if (!this.existingRecordError) {
            this.loadLaborPool = true;
            this.laborService
              .AddAssemblyTechnician(request)
              .subscribe((res) => {
                if (res) {
                  this.getLaborPoolMonthly();
                  this.getHeadCountMonthly();
                  this.getLaborHoursMonthly();
                  this.getOverTimeMonthly();
                  this.getLonedOutLaborMonthly();
                }
              });
            this.onCloseAdjustLabor();
          }
        }
      } else {
        this.laborService
          .UpdateAssemblyTechnician(request)
          .subscribe((res) => {
            if (res) {
              if (this.timeViewValue.text === "Weekly") {
                this.getLaborPoolWeekly();
                this.getHeadCountWeekly();
                this.getLaborHoursWeekly();
                this.getOverTimeWeekly();
                this.getLonedOutLaborWeekly();
              } else if (this.timeViewValue.text === "Daily") {
                this.getLaborPoolDaily();
                this.getHeadCountDaily();
                this.getLaborHoursDaily();
                this.getOverTimeDaily();
                this.getLonedOutLaborDaily();
              } else {
                this.getLaborPoolMonthly();
                this.getHeadCountMonthly();
                this.getLaborHoursMonthly();
                this.getOverTimeMonthly();
                this.getLonedOutLaborMonthly();
              }
            }
          });
        this.onCloseAdjustLabor();
      }
    }
  }

  resetAddAssembly() {
    this.technicianEffectiveDate = null;
    this.technicianEndDate = null;
    this.headCount = undefined;
    this.addLaborPoolError = false;
    this.biggerEndDateError = false;
    this.headcountError = false;
    this.hideDepartmentDropDown = false;
    this.existingRecordError = false;
    this.shiftTypeValue = { text: "", value: 0 };
    if (this.site.plantName !== "Fremont") {
      this.mgGroupValue = { text: "None", value: 0 };
    } else {
      this.mgGroupValue = { text: "", value: 0 };
    }

    this.loaningFormValue = { text: "", value: 0 };
    this.laborTypeValue = { text: "", value: 0 };
    this.statusValue = { text: "", value: 0 };
  }

  onLaborTypeChange(event: any) {
    this.existingRecordError = false;
    this.laborTypeValue = {
      text: event.text,
      value: event.value,
    };
  }

  onSatusChange(event: any) {
    this.existingRecordError = false;
    this.statusValue = {
      text: event.text,
      value: event.value,
    };
    if (this.statusValue.text === "Standard") {
      this.hideDepartmentDropDown = true;
      this.loaningFormValue = this.departmentItem.filter(
        (item) => item.text.toLowerCase() === "pilot"
      )[0];
    }
    if (this.statusValue.text === "On Loan") {
      this.loaningFormValue = { text: "", value: 0 };
      this.hideDepartmentDropDown = false;
      this.departmentHeader = "Department Loaning From";
    }
    if (this.statusValue.text === "Loaned Out") {
      this.loaningFormValue = { text: "", value: 0 };
      this.hideDepartmentDropDown = false;
      this.departmentHeader = "Department Loaning To";
    }
  }
  onLoaningFormChange(event: any) {
    this.existingRecordError = false;
    this.loaningFormValue = {
      text: event.text,
      value: event.value,
    };
  }
  onMgGroupChange(event: any) {
    this.existingRecordError = false;
    this.mgGroupValue = {
      text: event.text,
      value: event.value,
    };
  }
  onShiftTypeChange(event: any) {
    this.existingRecordError = false;
    this.shiftTypeValue = {
      text: event.text,
      value: event.value,
    };
  }
  closeSaveConfiramtion() {
    this.isSaveShiftType = false;
    this.missingShiftDescription = false;
    this.missingShiftShortDescription = false;
    this.missingCompressionValueForEdit = false;
    this.addShiftType = true;
    this.isWeek1Mon = false;
    this.isWeek1Tue = false;
    this.isWeek1Wed = false;
    this.isWeek1Thu = false;
    this.isWeek1Fri = false;
    this.isWeek1Sat = false;
    this.isWeek1Sun = false;
    this.isWeek2Mon = false;
    this.isWeek2Tue = false;
    this.isWeek2Wed = false;
    this.isWeek2Thu = false;
    this.isWeek2Fri = false;
    this.isWeek2Sat = false;
    this.isWeek2Sun = false;
  }
  public onSelectmeWeek(isSameWeek) {
    this.isSameWeek = isSameWeek;
    if (isSameWeek) {
      this.isWeek2Mon = this.isWeek1Mon;
      this.isWeek2Tue = this.isWeek1Tue;
      this.isWeek2Wed = this.isWeek1Wed;
      this.isWeek2Thu = this.isWeek1Thu;
      this.isWeek2Fri = this.isWeek1Fri;
      this.isWeek2Sat = this.isWeek1Sat;
      this.isWeek2Sun = this.isWeek1Sun;
    } else {
      this.isWeek2Mon = false;
      this.isWeek2Tue = false;
      this.isWeek2Wed = false;
      this.isWeek2Thu = false;
      this.isWeek2Fri = false;
      this.isWeek2Sat = false;
      this.isWeek2Sun = false;
    }
  }

  public onCompressionChange(event: any) {
    if (event && event.text?.length > 0) {
      this.missingCompressionValueForEdit = false;
      this.compressionValueForEdit = {
        text: event.text,
        value: event.value,
      };
    } else {
      this.missingCompressionValueForEdit = true;
    }
  }

  public colorCode(val: any): SafeStyle {
    let result = "transparent";
    if (val > 0) {
      result = "#dde8ee";
    }
    return this.sanitizer.bypassSecurityTrustStyle(result);
  }

  onProductTypeMgGroupChange(
    event: Item[],
    data: LabourManagementGroupMapping
  ) {
    this.productTypeGroup = [...this.masterProductTypeGroup];
    this.tempProductTypeGroup = [...this.productTypeGroup];
   
    data.laborMgmtGrpDetails = [];
    if (event?.length > 0) {
      event.forEach((item) => {
        if (item.value !== null && item.value !== undefined) {
          data.laborMgmtGrpDetails.push({
            laborProductName: item.text,
            productGroupID: item.value,
            productName: item.text,
            laborManagmentGroupID: data.laborManagmentGroupID,
          });
          this.gridDataForProductType.forEach((gridData) => {
            if (gridData.laborMgmtGrpDetails.length > 0) {
              gridData.laborMgmtGrpDetails.forEach((product) => {
                this.productTypeGroup =
                  this.productTypeGroup.filter(
                    (p) =>
                      p.text !==
                      product.laborProductName &&
                      p.value !== product.productGroupID
                  );
                this.tempProductTypeGroup = [
                  ...this.productTypeGroup,
                ];
              });
            }
          });
        }
      });
    }
    this.editService.update(data, "Product Type Mapping");
  }

  onOpenEditSummary() {
    this.editLaborSummary = true;
  }

  onCloseEditSummary() {
    this.editLaborSummary = false;
    if (this.editView === "daynight") {
      this.isShiftType = false;
      this.isNone = false;
      this.isDayNight = true;
    } else if (this.editView === "shifttype") {
      this.isDayNight = false;
      this.isNone = false;
      this.isShiftType = true;
    } else {
      this.isDayNight = false;
      this.isShiftType = false;
      this.isNone = true;
    }
    this.isShowShiftType = this.isShiftType;
    this.isShowDayNight = this.isDayNight;
    this.isShowNone = this.isNone;
  }

  onApplyEditSummary() {
    this.editLaborSummary = false;
    this.editView = this.tempEditView;
    this.isShowShiftType = this.isShiftType;
    this.isShowDayNight = this.isDayNight;
    this.isShowNone = this.isNone;
    if (this.timeViewValue.text === "Weekly") {
      this.getHeadCountWeekly();
      this.getOverTimeWeekly();
      this.getLaborHoursWeekly();
      this.getLonedOutLaborWeekly();
    } else if (this.timeViewValue.text === "Daily") {
      this.getHeadCountDaily();
      this.getOverTimeDaily();
      this.getLaborHoursDaily();
      this.getLonedOutLaborDaily();
    } else {
      this.getHeadCountMonthly();
      this.getOverTimeMonthly();
      this.getLaborHoursMonthly();
      this.getLonedOutLaborMonthly();
    }
  }

  radioButtonEventDayNight(isChecked) {
    this.isDayNight = isChecked;
    this.isNone = false;
    this.isShiftType = false;
    this.tempEditView = "daynight";
  }
  radioButtonEventShiftType(isChecked) {
    this.isShiftType = isChecked;
    this.isNone = false;
    this.isDayNight = false;
    this.tempEditView = "shifttype";
  }
  radioButtonEventNone() {
    this.isShiftType = false;
    this.isDayNight = false;
    this.isNone = true;
    this.tempEditView = "";
  }

  onChangeMultiplierVallue(value: number, dataItem: any) {
    dataItem.multiplierValue = value;
    this.editService.update(dataItem, "Build Multiplier");
  }
  onBlurMultiplierVallue(value: number, dataItem: any) {
    if (
      dataItem.multiplierValue === 0 ||
      dataItem.multiplierValue === null ||
      dataItem.multiplierValue === undefined
    ) {
      dataItem.multiplierValue = 0;
    }
    this.changeDetector.detectChanges();
  }

  onTabSelect(e) {
    if (e.index === 0) {
      this.isShowEditView = true;
      this.showUnits = "Unit = People";
    }
    if (e.index === 1) {
      this.isShowEditView = true;
      this.showUnits = "Unit = Hours";
    }
    if (e.index === 2) {
      this.isShowEditView = true;
      this.showUnits = "Unit = Hours";
    }
    if (e.index === 3) {
      this.isShowEditView = true;
      this.showUnits = "Unit = Hours";
    }
    if (e.index === 4) {
      this.isShowEditView = false;
      this.showUnits = "";
    }
  }
  onDeleteLaborPool(data: LaborSummaryLaborPool) {
    this.tempDeleteLaborPool = data;
    this.isDeleteLaborPool = true;
  }
  DeleteLaborPool() {
    const request = new LaborAssemblyTechnicianViewModel();
    const shiftTypeId = this.shiftTypeItems.filter(
      (item) =>
        item.text?.toLowerCase() ===
        this.tempDeleteLaborPool?.ShiftName?.toLowerCase()
    )[0]?.value;
    request.shiftID = shiftTypeId;
    request.PlantID = this.site.plantId;
    request.assembleyTest = this.tempDeleteLaborPool.AssemblyName;
    request.status = this.tempDeleteLaborPool.Status;
    request.managementGroup =
      this.tempDeleteLaborPool.LaborManagmentGroupID.toString();
    request.loanDeptFromTo =
      this.tempDeleteLaborPool.Department.toLowerCase();

    this.laborService.DeleteLaborPool(request).subscribe((res) => {
      if (res) {
        if (this.timeViewValue.text === "Weekly") {
          this.getLaborPoolWeekly();
          this.getHeadCountWeekly();
          this.getLaborHoursWeekly();
          this.getOverTimeWeekly();
          this.getLonedOutLaborWeekly();
        } else if (this.timeViewValue.text === "Daily") {
          this.getLaborPoolDaily();
          this.getHeadCountDaily();
          this.getLaborHoursDaily();
          this.getOverTimeDaily();
          this.getLonedOutLaborDaily();
        } else {
          this.getLaborPoolMonthly();
          this.getHeadCountMonthly();
          this.getOverTimeMonthly();
          this.getLaborHoursMonthly();
          this.getLonedOutLaborMonthly();
        }
      }
    });
    this.isDeleteLaborPool = false;
  }
  onBlurEffectiveDate(value: Date) {
    const isValiDate = moment(value).isValid();
    if (isValiDate) {
      if (
        this.checkInvalidYear(value) < 1753 ||
        this.checkInvalidYear(value) > 2099
      ) {
        const mdy = this.getDayMonthYear(
          moment(value).format("M/D/yy")
        );
        this.autoCompleteDateField(mdy, "Effective Date");
      } else {
        if (value < this.today) {
          this.biggerEffectiveDateError = true;
        } else {
          this.biggerEffectiveDateError = false;
          this.minEndDate = value;
        }
      }
    }
    this.addLaborPoolError = false;
    this.biggerEndDateError = false;
    this.headcountError = false;
    this.existingRecordError = false;
  }

  onBlurEndDate(value: Date) {
    const isValiDate = moment(value).isValid();
    if (isValiDate) {
      if (this.checkInvalidYear(value) < 1753) {
        const mdy = this.getDayMonthYear(
          moment(value).format("MM/DD/yyyy")
        );
        this.autoCompleteDateField(mdy, "End Date");
      }
    }
    this.addLaborPoolError = false;
    this.headcountError = false;
    this.biggerEndDateError = false;
    this.existingRecordError = false;
  }

  private checkInvalidYear(data) {
    const date = new Date(data);
    return date.getFullYear();
  }

  private getDayMonthYear(date: string) {
    let month = null,
      day = null,
      year = null;
    let resYear = null;
    if (date.indexOf("/") > -1) {
      const res = date.split("/");
      if (res.length === 2) {
        // if the split count is 2 means date is '10/02'
        month = Number(res[0]);
        day = Number(res[1]);
        resYear = "";
      } else if (res.length > 1) {
        month = Number(res[0]);
        day = Number(res[1]);
        year = res[2] === "" ? null : Number(res[2]); // if user has not entered year then don't assign it with 0
        resYear = res[2]; // To convert empty year to current year
      }
    } else {
      if (date.length >= 6 && date.length <= 8) {
        month = Number(date.substring(0, 2));
        day = Number(date.substring(2, 4));
        year = Number(date.substring(4));
      }
    }
    if (date.length === 4) {
      // to handle month and date without separetor
      month = Number(date.substring(0, 2));
      day = Number(date.substring(2, 4));
      resYear = "";
    }
    return this.validateMonthDayYear(month, day, year, resYear);
  }

  private validateMonthDayYear(month, day, year, resYear) {
    if (
      isNaN(month) ||
      isNaN(day) ||
      isNaN(year) ||
      (year && year >= 100 && year <= 999) ||
      (year === null && resYear !== "")
    ) {
      return;
    }
    if (year >= 1 && year <= 29) {
      year = 2000 + year;
    }
    if (year >= 30 && year <= 99) {
      year = 1900 + year;
    }
    if (year > 2099) {
      year = +year.toString().substr(year.toString().length - 2) + 2000;
    }
    if (resYear === "") {
      year = new Date().getFullYear();
    }
    return { month, day, year };
  }

  private autoCompleteDateField(mdy: any, field: string) {
    if (!mdy) {
      return;
    }
    const month = mdy.month,
      day = mdy.day,
      year = mdy.year;
    if (!this.checkMDYRange(month, day, year)) {
      return;
    }
    let inputDate =
      month.toString() + "/" + day.toString() + "/" + year.toString();
    inputDate = formatDate(inputDate, "MM/dd/yyyy", this.locale);
    if (field === "Effective Date") {
      this.technicianEffectiveDate = new Date(inputDate);
      if (this.technicianEffectiveDate < this.today) {
        this.biggerEffectiveDateError = true;
      } else {
        this.biggerEffectiveDateError = false;
        this.minEndDate = this.technicianEffectiveDate;
      }
    } else {
      this.technicianEndDate = new Date(inputDate);
    }
  }
  private checkMDYRange(month: number, day: number, year: number) {
    if (month < 1 || month > 12) {
      return false;
    }
    if (day < 1 || day > 31) {
      return false;
    }
    if (
      (month === 4 || month === 6 || month === 9 || month === 11) &&
      day === 31
    ) {
      return false;
    }
    if (month === 2) {
      const isleap =
        year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
      if (day > 29 || (day === 29 && !isleap)) {
        return false;
      }
    }
    return true;
  }

  handleProductTypeFilter(value) {
    if (value.length >= 0) {
      this.productTypeGroup = this.tempProductTypeGroup.filter(
        (s) =>
          s?.text.toLowerCase().indexOf(value?.toLowerCase()) !== -1
      );
    } else {
      this.multiselect.toggle(false);
    }
  }

  public showSuccess(msg: string): void {
    this.notificationService.show({
      appendTo: this.appendTo,
      content: msg,
      position: { horizontal: "left", vertical: "bottom" },
      animation: { type: "fade", duration: 600 },
      type: { style: "success", icon: true },
    });
  }
}
