export class ShiftType {
    public Description: string;
    public ShortDesc: string;
    public Compression: string;
    public Time: string;
    public Week1Sun: string;
    public Week1Mon: string;
    public Week1Tue: string;
    public Week1Wed: string;
    public Week1Thu: string;
    public Week1Fri: string;
    public Week1Sat: string;
    public Week2Sun: string;
    public Week2Mon: string;
    public Week2Tue: string;
    public Week2Wed: string;
    public Week2Thu: string;
    public Week2Fri: string;
    public Week2Sat: string;
    public isEdit: boolean;
}
