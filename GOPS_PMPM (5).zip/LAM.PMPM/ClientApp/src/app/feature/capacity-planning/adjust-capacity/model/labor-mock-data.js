"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HeadcountSnapshotMock = exports.ProductTypeMock = exports.LaborPoolDaily = exports.LaborPoolWeekly = exports.ManagementGroup = exports.ShiftTypeMock = exports.LaborMultiplierMock = exports.TualatinDaily = exports.FremontDaily = exports.TualatinWeekly = exports.FremontWeekly = void 0;
exports.FremontWeekly = [{
        "Management Group": "CA-EPL",
        "A/T": "Assembly",
        "6-7-21": 800,
        "6-14-21": 800,
        "6-21-21": 900,
        "6-28-21": 900,
        "7-5-21": 800,
        "7-14-21": 800,
    },
    {
        "Management Group": "Any",
        "A/T": "Test",
        "6-7-21": 80,
        "6-14-21": 80,
        "6-21-21": 80,
        "6-28-21": 90,
        "7-5-21": 80,
        "7-14-21": 80,
    },
    {
        "Management Group": "CA-DPL",
        "A/T": "Test",
        "6-7-21": 800,
        "6-14-21": 800,
        "6-21-21": 900,
        "6-28-21": 900,
        "7-5-21": 800,
        "7-14-21": 800,
    },
    {
        "Management Group": "Any",
        "A/T": "Assembly",
        "6-7-21": 800,
        "6-14-21": 800,
        "6-21-21": 900,
        "6-28-21": 900,
        "7-5-21": 800,
        "7-14-21": 800,
    }];
exports.TualatinWeekly = [{
        "A/T": "Assembly",
        "6-7-21": 800,
        "6-14-21": 800,
        "6-21-21": 900,
        "6-28-21": 900,
        "7-5-21": 800,
        "7-14-21": 800,
    },
    {
        "A/T": "Test",
        "6-7-21": 80,
        "6-14-21": 80,
        "6-21-21": 80,
        "6-28-21": 90,
        "7-5-21": 80,
        "7-14-21": 80,
    },
    {
        "A/T": "Test",
        "6-7-21": 800,
        "6-14-21": 800,
        "6-21-21": 900,
        "6-28-21": 900,
        "7-5-21": 800,
        "7-14-21": 800,
    },
    {
        "A/T": "Assembly",
        "6-7-21": 800,
        "6-14-21": 800,
        "6-21-21": 900,
        "6-28-21": 900,
        "7-5-21": 800,
        "7-14-21": 800,
    }];
exports.FremontDaily = [{
        "Management Group": "CA-EPL",
        "A/T": "Assembly",
        "7-Jun-21": 800,
        "8-Jun-21": 800,
        "9-Jun-21": 900,
        "10-Jun-21": 900,
        "11-Jun-21": 800,
        "12-Jun-21": 800,
    },
    {
        "Management Group": "Any",
        "A/T": "Test",
        "6-7-21": 80,
        "6-8-21": 80,
        "6-9-21": 80,
        "6-10-21": 90,
        "6-11-21": 80,
        "6-12-21": 80,
    },
    {
        "Management Group": "CA-DPL",
        "A/T": "Test",
        "6-7-21": 800,
        "6-8-21": 800,
        "6-9-21": 900,
        "6-10-21": 900,
        "6-11-21": 800,
        "6-12-21": 800,
    },
    {
        "Management Group": "Any",
        "A/T": "Assembly",
        "6-7-21": 800,
        "6-8-21": 800,
        "6-9-21": 900,
        "6-10-21": 900,
        "6-11-21": 800,
        "6-12-21": 800,
    }];
exports.TualatinDaily = [{
        "A/T": "Assembly",
        "7-Jun-21": 800,
        "8-Jun-21": 800,
        "9-Jun-21": 900,
        "10-Jun-21": 900,
        "11-Jun-21": 800,
        "12-Jun-21": 800,
    },
    {
        "A/T": "Test",
        "6-7-21": 80,
        "6-8-21": 80,
        "6-9-21": 80,
        "6-10-21": 90,
        "6-11-21": 80,
        "6-12-21": 80,
    },
    {
        "A/T": "Test",
        "6-7-21": 800,
        "6-8-21": 800,
        "6-9-21": 900,
        "6-10-21": 900,
        "6-11-21": 800,
        "6-12-21": 800,
    },
    {
        "A/T": "Assembly",
        "6-7-21": 800,
        "6-8-21": 800,
        "6-9-21": 900,
        "6-10-21": 900,
        "6-11-21": 800,
        "6-12-21": 800,
    }
];
exports.LaborMultiplierMock = [{
        "BuildType": "All",
        "MultiplierValue": 0.88
    },
    {
        "BuildType": "All",
        "MultiplierValue": 0.7
    },
    {
        "BuildType": "Alpha",
        "MultiplierValue": 3
    },
    {
        "BuildType": "Build Verify",
        "MultiplierValue": 1.7
    },
    {
        "BuildType": "Build Qualify",
        "MultiplierValue": 1.7
    },
    {
        "BuildType": "Beta",
        "MultiplierValue": 0
    }];
exports.ShiftTypeMock = [
    {
        "Description": "Monday-Friday",
        "ShortDesc": "M-F",
        "Compression": "Regular",
        "Time": "8:00 AM - 4:30 PM",
        "Week1Sun": "",
        "Week1Mon": "8",
        "Week1Tue": "8",
        "Week1Wed": "8",
        "Week1Thu": "8",
        "Week1Fri": "8",
        "Week1Sat": "",
        "Week2Sun": "",
        "Week2Mon": "8",
        "Week2Tue": "8",
        "Week2Wed": "8",
        "Week2Thu": "8",
        "Week2Fri": "8",
        "Week2Sat": "",
        "isEdit": true
    },
    {
        "Description": "Front End Days",
        "ShortDesc": "FED",
        "Compression": "Fully Compressed",
        "Time": "5:00 AM - 5:30 PM",
        "Week1Sun": "12",
        "Week1Mon": "12",
        "Week1Tue": "12",
        "Week1Wed": "",
        "Week1Thu": "",
        "Week1Fri": "",
        "Week1Sat": "",
        "Week2Sun": "",
        "Week2Mon": "8",
        "Week2Tue": "8",
        "Week2Wed": "8",
        "Week2Thu": "8",
        "Week2Fri": "8",
        "Week2Sat": "",
        "isEdit": true
    },
    {
        "Description": "Front End Days",
        "ShortDesc": "FED",
        "Compression": "Semi Compressed",
        "Time": "5:00 PM - 3:30 PM",
        "Week1Sun": "10",
        "Week1Mon": "10",
        "Week1Tue": "10",
        "Week1Wed": "10",
        "Week1Thu": "",
        "Week1Fri": "",
        "Week1Sat": "",
        "Week2Sun": "",
        "Week2Mon": "8",
        "Week2Tue": "8",
        "Week2Wed": "8",
        "Week2Thu": "8",
        "Week2Fri": "8",
        "Week2Sat": "",
        "isEdit": true
    },
    {
        "Description": "Front End Nights",
        "ShortDesc": "FEN",
        "Compression": "Fully Compressed",
        "Time": "5:00 PM - 5:30 PM",
        "Week1Sun": "12",
        "Week1Mon": "12",
        "Week1Tue": "12",
        "Week1Wed": "12",
        "Week1Thu": "",
        "Week1Fri": "",
        "Week1Sat": "",
        "Week2Sun": "",
        "Week2Mon": "8",
        "Week2Tue": "8",
        "Week2Wed": "8",
        "Week2Thu": "8",
        "Week2Fri": "8",
        "Week2Sat": "",
        "isEdit": true
    }
];
exports.ManagementGroup = [
    {
        "Management Group": "CA-EPL",
        "Over Time Allowance": "10%",
        "Efficiency Factor": "70%",
        "Utilization Target": "70%",
        "PTO": "10%"
    },
    {
        "Management Group": "CA-DPL",
        "Over Time Allowance": "10%",
        "Efficiency Factor": "75%",
        "Utilization Target": "70%",
        "PTO": "10%"
    },
    {
        "Management Group": "CA-DPMD",
        "Over Time Allowance": "10%",
        "Efficiency Factor": "75%",
        "Utilization Target": "70%",
        "PTO": "10%"
    },
    {
        "Management Group": "CA-EPM",
        "Over Time Allowance": "10%",
        "Efficiency Factor": "80%",
        "Utilization Target": "70%",
        "PTO": "10%"
    },
    {
        "Management Group": "CA-MEC",
        "Over Time Allowance": "10%",
        "Efficiency Factor": "80%",
        "Utilization Target": "70%",
        "PTO": "10%"
    }
];
exports.LaborPoolWeekly = [
    {
        "ManagementGroup": "CA-EPL",
        "A/T": "Assembly",
        "Status": "Standard",
        "Department": "Pilot",
        "ShiftType": "Front End Days (FED)",
        "DayShift": "Yes",
        "6-7-21": "10",
        "6-14-21": "10",
        "6-21-21": "10",
        "6-28-21": "10",
        "7-5-21": "10",
        "7-14-21": "10",
        "isEdit": true
    },
    {
        "ManagementGroup": "CA-EPL",
        "A/T": "Test",
        "Status": "On Loan",
        "Department": "HVM",
        "ShiftType": "Front End Days (FED)",
        "DayShift": "Yes",
        "6-7-21": "10",
        "6-14-21": "10",
        "6-21-21": "10",
        "6-28-21": "10",
        "7-5-21": "10",
        "7-14-21": "10",
        "isEdit": true
    },
    {
        "ManagementGroup": "CA-DPL",
        "A/T": "Assembly",
        "Status": "Standard",
        "Department": "Pilot",
        "ShiftType": "Front End Nights (FEN)",
        "DayShift": "No",
        "6-7-21": "10",
        "6-14-21": "10",
        "6-21-21": "10",
        "6-28-21": "10",
        "7-5-21": "10",
        "7-14-21": "10",
        "isEdit": true
    },
    {
        "ManagementGroup": "N/A",
        "A/T": "Test",
        "Status": "Loaned Out",
        "Department": "Floor",
        "ShiftType": "Back End Nights (BEN)",
        "DayShift": "No",
        "6-7-21": "10",
        "6-14-21": "10",
        "6-21-21": "10",
        "6-28-21": "10",
        "7-5-21": "10",
        "7-14-21": "10",
        "isEdit": true
    }
];
exports.LaborPoolDaily = [
    {
        "ManagementGroup": "CA-EPL",
        "A/T": "Assembly",
        "Status": "Standard",
        "Department": "Pilot",
        "ShiftType": "Front End Days (FED)",
        "DayShift": "Yes",
        "6-7-21": "10",
        "6-8-21": "10",
        "6-9-21": "10",
        "6-10-21": "10",
        "6-11-21": "10",
        "6-12-21": "10",
        "isEdit": true
    },
    {
        "ManagementGroup": "CA-EPL",
        "A/T": "Test",
        "Status": "On Loan",
        "Department": "HVM",
        "ShiftType": "Front End Days (FED)",
        "DayShift": "Yes",
        "6-7-21": "10",
        "6-8-21": "10",
        "6-9-21": "10",
        "6-10-21": "10",
        "6-11-21": "10",
        "6-12-21": "10",
        "isEdit": true
    },
    {
        "ManagementGroup": "CA-DPL",
        "A/T": "Assembly",
        "Status": "Standard",
        "Department": "Pilot",
        "ShiftType": "Front End Nights (FEN)",
        "DayShift": "No",
        "6-7-21": "10",
        "6-8-21": "10",
        "6-9-21": "10",
        "6-10-21": "10",
        "6-11-21": "10",
        "6-12-21": "10",
        "isEdit": true
    },
    {
        "ManagementGroup": "N/A",
        "A/T": "Test",
        "Status": "Loaned Out",
        "Department": "Floor",
        "ShiftType": "Back End Nights (BEN)",
        "DayShift": "No",
        "6-7-21": "10",
        "6-8-21": "10",
        "6-9-21": "10",
        "6-10-21": "10",
        "6-11-21": "10",
        "6-12-21": "10",
    }
];
exports.ProductTypeMock = [
    {
        "ProductType": "Aether",
        "ManagementGroup": "CA-EPL"
    },
    {
        "ProductType": "MEMS Etch 200mm",
        "ManagementGroup": "CA-DPL"
    },
    {
        "ProductType": "MEMS Etch 300mm",
        "ManagementGroup": "CA-DPL"
    },
    {
        "ProductType": "MEMS Etch 200mm",
        "ManagementGroup": "CA-DPL"
    },
    {
        "ProductType": "XXXXXX",
        "ManagementGroup": "Missing"
    }
];
exports.HeadcountSnapshotMock = [
    {
        "ShiftType": "Day",
        "Week1Sun": "28",
        "Week1Mon": "30",
        "Week1Tue": "30",
        "Week1Wed": "30",
        "Week1Thu": "28",
        "Week1Fri": "28",
        "Week1Sat": "28",
        "Week2Sun": "28",
        "Week2Mon": "28",
        "Week2Tue": "28",
        "Week2Wed": "28",
        "Week2Thu": "28",
        "Week2Fri": "29",
        "Week2Sat": "29",
    },
    {
        "ShiftType": "Night",
        "Week1Sun": "24",
        "Week1Mon": "24",
        "Week1Tue": "24",
        "Week1Wed": "26",
        "Week1Thu": "26",
        "Week1Fri": "26",
        "Week1Sat": "26",
        "Week2Sun": "26",
        "Week2Mon": "26",
        "Week2Tue": "26",
        "Week2Wed": "26",
        "Week2Thu": "25",
        "Week2Fri": "25",
        "Week2Sat": "25",
    },
    {
        "ShiftType": "Total",
        "Week1Sun": "52",
        "Week1Mon": "52",
        "Week1Tue": "52",
        "Week1Wed": "56",
        "Week1Thu": "54",
        "Week1Fri": "54",
        "Week1Sat": "54",
        "Week2Sun": "54",
        "Week2Mon": "54",
        "Week2Tue": "54",
        "Week2Wed": "54",
        "Week2Thu": "53",
        "Week2Fri": "54",
        "Week2Sat": "54",
    }
];
//# sourceMappingURL=labor-mock-data.js.map