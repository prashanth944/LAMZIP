export class ToolType {
    Tool_Type_ID: number;
    Name: string;
}
