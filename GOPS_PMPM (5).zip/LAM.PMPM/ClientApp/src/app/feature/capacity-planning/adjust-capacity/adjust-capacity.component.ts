import { Component, DoCheck, OnInit, ViewEncapsulation } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { AppStoreService } from "../../../core/app-store.service";
import { uiScreen } from "../../../core/model/common.constant";

@Component({
    selector: "pmpm-adjust-capacity",
    templateUrl: "./adjust-capacity.component.html",
    styleUrls: ["./adjust-capacity.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class AdjustCapacityComponent implements OnInit, DoCheck {
    tabType: string | undefined;
    isUserAccess = false;
    isLoading = true;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private appStoreService: AppStoreService
    ) {}
    ngOnInit() {
        this.tabType = "labor";
        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.AdjustCapacity)
                    .subscribe((result) => {
                        this.isUserAccess = result;
                        this.isLoading = false;
                    });
            }
        });
    }
    ngDoCheck() {
        this.tabType = this.router.url.split("/").pop();
    }

    onTabSelect(tab) {
        if (tab.index === 0) {
            this.router.navigate(["/capacity/adjust-capacity/labor"]);
        }
        if (tab.index === 1) {
            this.router.navigate(["/capacity/adjust-capacity/bay"]);
        }
    }
}
