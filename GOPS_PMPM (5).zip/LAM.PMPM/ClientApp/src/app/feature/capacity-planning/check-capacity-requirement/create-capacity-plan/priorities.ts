export const priorities = [{
    "PriorityId": 1,
    "PriorityName": "Priority Date"
},
{
    "PriorityId": 2,
    "PriorityName": "MCSD"
},
{
    "PriorityId": 3,
    "PriorityName": "Record Type"
}, {
    "PriorityId": 4,
    "PriorityName": "Revenue Type"
}, {
    "PriorityId": 5,
    "PriorityName": "MRP"
}];


export const recordType=[
    {
        "RecordTypeId": 1,
        "RecordTypeName": "Slotted"
    },
    {
        "RecordTypeId": 2,
        "RecordTypeName": "Forecasted"
    },
];

export const revenueType=[
    {
        "RevenueTypeId": 1,
        "RevenueTypeName": "Revenue"
    },
    {
        "RevenueTypeId": 2,
        "RevenueTypeName": "Eval"
    },
];