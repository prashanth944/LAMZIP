export class CompareSummary {
  status: string;
  scenarioA: string;
  scenarioB: string;
  comparison: string;
}
