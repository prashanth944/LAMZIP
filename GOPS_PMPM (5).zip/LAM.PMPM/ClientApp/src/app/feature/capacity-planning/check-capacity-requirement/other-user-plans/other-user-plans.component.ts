import {
    ChangeDetectionStrategy,
    ChangeDetectorRef,
    Component,
    OnInit,
    ViewEncapsulation,
} from "@angular/core";
import { distinct, process } from "@progress/kendo-data-query";
import * as moment from "moment";
import { Router } from "@angular/router";
import { CreateCPService } from "../create-capacity-plan/create-cp-service/createCP.service";
import { AppStoreService } from "../../../../core/app-store.service";
import { EditService } from "../../../service/edit.service";
import { Plant } from "../../../../core/model/user.model";
import { PanelBarExpandMode } from "@progress/kendo-angular-layout";
import { FilterItem } from "../../adjust-module/models/filterItem";
import { OtherUserPlanGrid } from "../model/otherUserPlanGrid";

@Component({
    selector: "pmpm-other-user-plans",
    templateUrl: "./other-user-plans.component.html",
    styleUrls: ["./other-user-plans.component.css"],
    encapsulation: ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OtherUserPlansComponent implements OnInit {
    site: Plant;
    public expandMode: number = PanelBarExpandMode.Multiple;
    public kendoPanelBarExpandMode: any = PanelBarExpandMode;
    public height = 150;

    planGridData: any[] = [];
    public gridFilteredData: any[] = [];
    public gridFilteredData2: any[] = [];
    prevVal = "";
    grdData: any[] = [];
    planID = 0;

    public userId: number;
    public userName: string;

    dataRefreshDateData: any[] = [];
    planOwnerData: any[] = [];
    lastModifiedData: any[] = [];
    planTypeData: any[] = [];
    sitesData: any[] = []; 
    filterValues: FilterItem[] = [];

    constructor(
        private createCPService: CreateCPService,
        private appStoreService: AppStoreService,
        private router: Router,
        private editService: EditService,
        private changeDetector: ChangeDetectorRef
    ) {}
    ngOnInit() {
        this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site) {
                this.site = {
                    plantName: site.plantName,
                    plantId: site.plantId,
                };
                this.fillOtherUserPlanGrid();
            }
        });
        this.appStoreService.getLoggedInUser().subscribe((user) => {
            this.appStoreService.getUserDetails(user.mail).subscribe((res) => {
                this.userId = res?.userId;
                this.userName = res?.firstName + " " + res?.lastName;
            });
        });
    }
    public onChange(event: any): void {
        this.expandMode = parseInt(event.target.value, 10);
    }

    public onHeightChange(value: any): void {
        this.height = value;
    }

    public onPanelChange(event: any): void {}
    fillOtherUserPlanGrid() {
        this.planGridData = [];
        this.gridFilteredData = [];
        this.gridFilteredData2 = [];
        this.createCPService.getOtherUserPlans().subscribe((pp) => {
            pp.forEach((val) => {
                const newPt: OtherUserPlanGrid = {
                    PlanId: val.productionPlanID,
                    PlanName: val.planName,
                    PlanType: val.planType,
                    DataRefreshDate: moment(val.dataRefreshDate)
                        .format("MM-DD-yyyy hh:mm A")
                        .toString(),
                    LastModified: moment(val.modifiedDate)
                        .format("MM-DD-yyyy hh:mm A")
                        .toString(),
                    Owner: val.userID,
                    Description: val.description,
                    PlantId: val.plantID,
                    PlantName: val.plantName,
                };
                this.planGridData.push(newPt);
                this.changeDetector.detectChanges();
            });
            this.dataRefreshDateData =
                this.distinctPrimitive("DataRefreshDate");
            this.planOwnerData = this.distinctPrimitive("Owner");
            this.lastModifiedData = this.distinctPrimitive("LastModified");
            this.planTypeData = this.distinctPrimitive("PlanType");
            this.sitesData = this.distinctPrimitive("PlantName");
            this.planGridData = this.planGridData.filter(
                (x) => x.PlantName === this.site?.plantName
            );
            this.sitesData.forEach((item) => {
                if (item.text === this.site?.plantName) {
                    item.checked = true;
                }
            });
            this.changeDetector.detectChanges();
        });
        this.gridFilteredData = this.planGridData;
        this.gridFilteredData2 = this.planGridData;
    }

    onCreateNewPlan() {
        this.appStoreService.setPlanCreatedBy$(this.planGridData[0].userName);
        this.router.navigate(["/create-capacity-plan/" + "0" + "/0"]);
    }
    closeCreateCP() {
        this.router.navigate(["/capacity/check-capacity"]);
    }
    cellClickHandler(event) {
        if (event.column.field === "PlanName") {
            this.planGridData = this.planGridData.filter(
                (x) => x.PlanId == event.dataItem.PlanId
            );
            this.planID = this.planGridData[0].PlanId;
            this.appStoreService.setPlanCreatedBy$(this.planGridData[0].Owner);
            this.router.navigate([
                "/create-capacity-plan/" + this.planID.toString() + "/0",
            ]);
        }
    }
    public onSearchFilter(inputValue: string): void {
        this.planGridData = process(this.gridFilteredData, {
            filter: {
                logic: "or",
                filters: [
                    {
                        field: "PlanName",
                        operator: "contains",
                        value: inputValue,
                    },
                    {
                        field: "Owner",
                        operator: "contains",
                        value: inputValue,
                    },
                ],
            },
        }).data;
    }
    public getValue(event: Event): string {
        return (event.target as HTMLInputElement).value;
    }
    public distinctPrimitive(fieldName: string): any {
        const distinctData: any[] = distinct(this.planGridData, fieldName).map(
            (item) => item[fieldName]
        );
        const data: any[] = [];
        distinctData.forEach((item) => {
            if (item !== null) data.push({ text: item, checked: false });
        });
        data.sort(function (a, b) {
            const textA = a?.text?.toUpperCase();
            const textB = b?.text?.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
        });
        return data;
    }

    onItemClick(value, field) {
        value.checked = !value.checked;
        if (value.text != "None") {
            if (value.checked) {
                const fi: FilterItem = {
                    filterValues: value.text,
                    filterType: field,
                };
                this.filterValues.push(fi);
            } else {
                const filter2 = [];
                this.filterValues.forEach((val) => {
                    if (val.filterValues != value.text) {
                        filter2.push(val);
                    }
                });
                this.filterValues = filter2;
            }
        } else {
            const filter2 = [];
            this.filterValues.forEach((val) => {
                if (val.filterType != field) {
                    filter2.push(val);
                }
            });
            this.filterValues = filter2;
            this.onClearCheckbox(value, field);
        }
        this.onFilterData(this.filterValues, field);
    }

    public onFilterData(inputValue, field: string): void {
        if (inputValue.length == 0) {
            this.sitesData.forEach((item) => {
                if (item.text === this.site?.plantName) {
                    if (item.checked == true) {
                        this.planGridData = this.gridFilteredData2.filter(
                            (x) => x.PlantName === this.site?.plantName
                        );
                        this.changeDetector.detectChanges();
                    } else {
                        this.planGridData = this.gridFilteredData2;
                        this.changeDetector.detectChanges();
                    }
                } else {
                    this.planGridData = this.gridFilteredData2;
                    this.changeDetector.detectChanges();
                }
            });
            this.gridFilteredData = this.gridFilteredData2;
        } else {
            if (field == this.prevVal) {
                this.gridFilteredData = this.gridFilteredData2;
            } else {
                this.gridFilteredData = this.planGridData;
            }
            this.planGridData = [];
            inputValue.forEach((val) => {
                this.grdData = process(this.gridFilteredData, {
                    filter: {
                        logic: "or",
                        filters: [
                            {
                                field: val.filterType,
                                operator: "eq",
                                value: val.filterValues,
                            },
                        ],
                    },
                }).data;
                if (field == this.prevVal) {
                    this.grdData.forEach((val) => {
                        this.planGridData.push(val);
                    });
                } else {
                    this.planGridData = this.grdData;
                }
                this.prevVal = val.filterType;
            });
        }
    }
    clearFilter() {
        if (this.planGridData.length != this.gridFilteredData2.length) {
            this.planGridData = this.gridFilteredData2;

            this.dataRefreshDateData.forEach((item) => {
                if (item.text != "None") {
                    item.checked = false;
                }
            });
            this.planOwnerData.forEach((item) => {
                if (item.text != "None") {
                    item.checked = false;
                }
            });
            this.lastModifiedData.forEach((item) => {
                if (item.text != "None") {
                    item.checked = false;
                }
            });
            this.planTypeData.forEach((item) => {
                if (item.text != "None") {
                    item.checked = false;
                }
            });
            this.sitesData.forEach((item) => {
                if (item.text != "None") {
                    item.checked = false;
                }
            });
        }
    }

    onClearCheckbox(value, field) {
        switch (field) {
            case "DataRefreshDate":
                this.dataRefreshDateData.forEach(
                    (item) => (item.checked = false)
                );
                break;
            case "Owner":
                this.planOwnerData.forEach((item) => (item.checked = false));
                break;
            case "LastModified":
                this.lastModifiedData.forEach((item) => (item.checked = false));
                break;
            case "PlanType":
                this.planTypeData.forEach((item) => (item.checked = false));
                break;
            case "PlantName":
                this.sitesData.forEach((item) => (item.checked = false));
                break;
        }
    }
    onShowSchedule(planId) {
        const pd = this.planGridData.filter((x) => x.PlanId == planId);
        const pt = pd[0].PlanType;
        if (pt === "POR") {
            this.router.navigate(["/mps"]);
        } else {
            this.router.navigate(["/schedule-generated/" + planId.toString()]);
        }
    }
    onShowPlan(planId) {
        this.planGridData = this.planGridData.filter((x) => x.PlanId == planId);
        this.appStoreService.setPlanCreatedBy$(this.planGridData[0].Owner);
        this.router.navigate([
            "/create-capacity-plan/" + planId.toString() + "/0",
        ]);
    }
}
