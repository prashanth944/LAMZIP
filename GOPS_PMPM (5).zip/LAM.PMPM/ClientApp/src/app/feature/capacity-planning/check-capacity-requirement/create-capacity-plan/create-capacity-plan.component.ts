import {
    ChangeDetectorRef,
    Component,
    OnInit,
    TemplateRef,
    ViewChild,
    ViewContainerRef,
    ViewEncapsulation,
} from "@angular/core";
import { SelectableSettings } from "@progress/kendo-angular-grid";
import { State, process } from "@progress/kendo-data-query";
import { SetSchedulePriorityMock } from "../model/set-schedule-priority.model";
import { ActivatedRoute, Router, RouterStateSnapshot } from "@angular/router";
import { CreateCP } from "./models/createCP";
import { PriorityOrder } from "./models/PriorityOrder";
import { ModuleGrid } from "../../../capacity-planning/adjust-module/models/moduleGrid";
import { CreateCPService } from "../create-capacity-plan/create-cp-service/createCP.service";
import { Item } from "../../../model/item";
import * as moment from "moment";
import { ModuleGridCP } from "./models/moduleGridCP";
import { AppStoreService } from "../../../../core/app-store.service";
import { ModLevelCPGrid } from "./models/modLevelCPGrid";
import { SchedulePriorities } from "./models/schedulePriorities";
import { Plant } from "../../../../core/model/user.model";
import { NotificationService } from "@progress/kendo-angular-notification";
import { role, uiScreen } from "../../../../core/model/common.constant";
import { PlanGrid } from "../model/planGrid";
import { Observable } from "rxjs";
import { EditService } from "../../../service/edit.service";
import { ScheduleGeneratedService } from "../../../schedule-generated/schedule-generated-service/schedule-generated.service";
import { LabelSettings } from "@progress/kendo-angular-progressbar";
import { ProductionPlan } from "../../../master-production-schedule/model/mps-summary";
import { MpsService } from "../../../master-production-schedule/mps-service/mps.service";

@Component({
    selector: "pmpm-create-capacity-plan",
    templateUrl: "./create-capacity-plan.component.html",
    styleUrls: ["./create-capacity-plan.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class CreateCapacityPlanComponent implements OnInit {
    @ViewChild("template", { read: TemplateRef })
    public notificationTemplate: TemplateRef<any>;
    @ViewChild("appendTo", { read: ViewContainerRef })
    public appendTo: ViewContainerRef;

    canEdit = false;
    createCPdata: any[];
    planGridData: any[];

    planTypeItems: Array<Item> = [];
    plantItems: Array<Item> = [];
    site: Plant;
    showGeneralTab = true;

    showModLevelTab = false;
    showModTab = true;

    laborResourcesSwitch = true;
    bayResourcesSwitch = true;

    dataRefreshDate: string = moment(new Date())
        .format("MM-DD-yyyy hh:mm A")
        .toString();
    public gridData2: Array<PriorityOrder> = [];
    public recordTypeGridData: Array<PriorityOrder> = [];
    public revenueTypeGridData: Array<PriorityOrder> = [];

    public checkboxOnly = false;
    public mode = "multiple";
    public drag = false;
    public selectableSettings: SelectableSettings;

    public extractDataItems;
    public extractDataItems2;
    public extractDataItems3;
    public extractRecordItems;
    public extractRevenueItems;

    enableArrowButtons = false;
    enableRecordArrowButtons = false;
    enableRevenueArrowButtons = false;
    showRecordTypeGrid = false;
    showRevenueTypeGrid = false;
    setOrderRecordType = "Set Order";
    setOrderRevenueType = "Set Order";
    setOrderRecordTypeColor = "Red";
    setOrderRevenueTypeColor = "Red";

    public mySelection: number[] = [];
    public mySelection2: number[] = [];

    public recordTypeSelection: number[] = [];
    public revenueTypeSelection: number[] = [];

    planNameValue = "";
    planTypeValue: { text: ""; value: 0 };
    planDescriptionValue = "";
    PriorityListOrderValue: SchedulePriorities[] = [];
    RecordTypeOrderValue: SchedulePriorities[] = [];
    RevenueTypeOrderValue: SchedulePriorities[] = [];
    LaborResourcesHardConstraintValue: boolean;
    BayResourcesHardConstraintValue: boolean;
    ModuleLevelCPListValue: ModuleGrid[] = [];

    SitePlantName = "";
    showValidationErr = false;
    generateScheduleOpened = false;
    noModulesAvailableForScheduleOpened = false;
    showNoModulesAvailableMsg = "";

    modLevelCPdata: any[] = [];
    modLevelCPdata2: any[] = [];

    modLevelCPdataAlreadySc: any[] = [];

    modLevelCPGrid: ModLevelCPGrid[] = [];
    updateModuleObj: ModLevelCPGrid[] = [];
    showPlanNameInvalid = false;
    showPlanTypeInvalid = false;
    createNewPlan = true;
    CreateorModify = "Create";
    showErrorMsg = false;
    isCancelChangesClicked = false;
    notificationMsg = "";
    missingPriorityDateOpened = false;
    successCount = 0;

    public isLoading = false;
    public userId: number;
    public userName: string;
    public planID: string;
    countWarning = 0;
    showPriorityErrorMsg = false;
    public isChanged = false;
    redirectUrl = "";
    selectedTab = 0;

    public state: State = {
        skip: 0,
        take: 10,
    };
    public gridData: any = process(SetSchedulePriorityMock, this.state);
    isUserAccess = false;
    planCreatedByUser: string;
    editableByUser = false;

    tabId: number;
    tempTabId = 0;

    //progress bar
    public value = 0;
    public running: any;
    public labelText = "0%";

    disableModLevelTab = true;
    showTabChangeError = false;
    public showErrorDialogbox = false;
    public showSuccessDialogbox = false;
    public newlyAddedPilotProductIds: any[] = [];

    editModeOn = false;
    navigationOff = false;
    savePORChanges = false;
    cancelPORChanges = false;
    canRemoveLock = false;
    canUserEdit = false;
    modifiedDate: string = moment(new Date())
        .format("MM-DD-yyyy hh:mm A")
        .toString();
    porIsBeingEdited = true;
    porIsBeingEditedBy = "";
    userRoles: string[] = [];
    savePORClickable = false;
    modifiedBy = "";
    isURLChanged = false;
    canEditPOR = false;

    constructor(
        private router: Router,
        private createCPService: CreateCPService,
        private route: ActivatedRoute,
        private editService: EditService,
        private changeDetector: ChangeDetectorRef,
        private scheduleService: ScheduleGeneratedService,
        private appStoreService: AppStoreService,
        private notificationService: NotificationService,
        private mpsService: MpsService
    ) {}
    ngOnInit() {
        this.route.params.subscribe((param) => {
            this.planID = param.id;
            if (param.tabId === "0") {
                this.tabId = param.tabId;
            } else {
                this.tempTabId = param.tabId;
            }
        });

        this.appStoreService.getLaborHardConstraint().subscribe((res) => {
            this.laborResourcesSwitch = res;
        });
        this.appStoreService.getBayHardConstraint().subscribe((res) => {
            this.bayResourcesSwitch = res;
        });

        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                this.userRoles = res;
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.CreateCP)
                    .subscribe((result) => {
                        this.isUserAccess = result;
                        if (
                            res.includes(role.SuperUser) ||
                            res.includes(role.Manager)
                        ) {
                            this.canUserEdit = true;
                        }
                        this.canEditPOR = !res.includes(role.Supervisor);
                    });

                this.appStoreService.getCurrentSite().subscribe((site) => {
                    if (site) {
                        this.site = {
                            plantName: site.plantName,
                            plantId: site.plantId,
                        };

                        if (
                            this.router.url.includes("/create-capacity-plan/")
                        ) {
                            this.fillPriorityGrid();
                        }
                        this.SitePlantName = this.site.plantName;
                        if (parseInt(this.planID) == 0) {
                            this.createNewPlan = true;
                            this.CreateorModify = "Create";
                            this.disableModLevelTab = true;
                        } else {
                            this.createNewPlan = false;
                            this.CreateorModify = "Modify";
                            this.disableModLevelTab = false;
                        }
                        this.setSelectableSettings();
                        this.extract2();
                        this.changeDetector.detectChanges();
                    }
                });

                this.appStoreService.getLoggedInUser().subscribe((user) => {
                    this.appStoreService
                        .getUserDetails(user.mail)
                        .subscribe((res) => {
                            this.userId = res?.userId;
                            this.userName =
                                res?.firstName + " " + res?.lastName;
                            this.appStoreService
                                .getPlanCreatedBy()
                                .subscribe((res2) => {
                                    this.planCreatedByUser = res2;
                                    if (parseInt(this.planID) == 0) {
                                        this.editableByUser = true;
                                    }
                                    this.changeDetector.detectChanges();
                                });
                        });
                });
            }
        });
    }

    getPlanDetails() {
        this.planGridData = [];
        this.createCPService
            .getProductionPlanData(this.site.plantId)
            .subscribe((pp) => {
                pp.forEach((val) => {
                    const newPt: PlanGrid = {
                        PlanId: val.productionPlanID,
                        PlanName: val.planName,
                        PlanType: val.planType,
                        DataRefreshDate: moment(val.dataRefreshDate)
                            .format("MM-DD-yyyy hh:mm A")
                            .toString(),
                        LastModified: moment(val.modifiedDate)
                            .format("MM-DD-yyyy hh:mm A")
                            .toString(),
                        Owner: val.userID,
                        Description: val.description,
                        PlantId: val.plantID,
                        CanEdit: null,
                    };
                    this.planGridData.push(newPt);
                });
            });
        this.scheduleService
            .getProductionPlanByProdPlanID(parseInt(this.planID))
            .subscribe((val) => {
                if (val.length > 0) {
                    this.planNameValue = val[0]?.planName;
                    this.planTypeValue = { text: val[0]?.planType, value: 0 };
                    if (
                        this.planTypeValue.text.toUpperCase().trim() === "POR"
                    ) {
                        if (
                            this.userName === this.planCreatedByUser ||
                            this.userRoles.includes(role.SuperUser) ||
                            this.userRoles.includes(role.Manager)
                        ) {
                            this.editableByUser = true;
                        }
                    } else {
                        if (this.userName === this.planCreatedByUser) {
                            this.editableByUser = true;
                        }
                    }

                    this.planDescriptionValue =
                        val[0]?.description != undefined
                            ? val[0]?.description
                            : null;
                    this.dataRefreshDate = moment(val[0]?.dataRefreshDate)
                        .format("MM-DD-yyyy hh:mm A")
                        .toString();
                    this.planCreatedByUser = val[0]?.userID;
                    this.modifiedDate = moment(val[0]?.modifiedDate)
                        .format("MM-DD-yyyy hh:mm A")
                        .toString();
                    this.modifiedBy = val[0].modifiedBy;
                    this.porIsBeingEdited = val[0].isBeingEdited;
                    this.porIsBeingEditedBy = val[0].isBeingEditedBy;

                    if (this.porIsBeingEdited) {
                        if (this.userRoles.includes(role.SuperUser)) {
                            this.canRemoveLock = true;
                        }
                        this.editModeOn =
                            this.porIsBeingEditedBy.trim() ==
                            this.userName.trim()
                                ? true
                                : false;
                        this.navigationOff =
                            this.porIsBeingEditedBy.trim() ==
                            this.userName.trim()
                                ? true
                                : false;
                    } else {
                        this.canRemoveLock = false;
                        if (
                            !this.userRoles.includes(role.SuperUser) &&
                            !this.userRoles.includes(role.Manager)
                        ) {
                            this.porIsBeingEdited = true;
                        }
                        this.editModeOn = false;
                        this.navigationOff = false;
                    }
                }
                this.appStoreService.setPlanCreatedBy$(this.planCreatedByUser);
                this.fillModuleGridOnTabChange();
                this.changeDetector.detectChanges();
            });
    }

    fillPriorityGrid() {
        this.createCPService.getPlanType().subscribe((pt) => {
            pt.forEach((val) => {
                const newPt: Item = {
                    value: val.plantID,
                    text: val.planName,
                };
                this.planTypeItems.push(newPt);
            });
        });

        this.createCPService
            .getSchedulePriority(this.site?.plantId)
            .subscribe((sp) => {
                sp.forEach((val) => {
                    const newSP: PriorityOrder = {
                        PriorityId: val.schedulePriorityID,
                        PriorityName: val.priorities,
                    };
                    this.gridData2.push(newSP);
                });
                this.createCPService
                    .getRecordType(this.site?.plantId)
                    .subscribe((rt) => {
                        rt.forEach((val) => {
                            const newRT: PriorityOrder = {
                                PriorityId: val.schedulePriorityID,
                                PriorityName: val.priorities,
                            };
                            this.recordTypeGridData.push(newRT);
                        });
                        this.createCPService
                            .getRevenueType(this.site?.plantId)
                            .subscribe((rt) => {
                                rt.forEach((val) => {
                                    const newRT: PriorityOrder = {
                                        PriorityId: val.schedulePriorityID,
                                        PriorityName: val.priorities,
                                    };
                                    this.revenueTypeGridData.push(newRT);
                                });
                                this.getPlanDetails();
                            });
                    });
                this.changeDetector.detectChanges();
            });
        this.createCPService.getPlant().subscribe((pt) => {
            pt.forEach((val) => {
                const newPT: Item = {
                    value: val.PlantId,
                    text: val.PlantName,
                };
                this.plantItems.push(newPT);
            });
        });
        this.changeDetector.detectChanges();
    }

    fillModuleGridOnTabChange() {
        this.modLevelCPdata = [];
        this.modLevelCPdataAlreadySc = [];
        this.modLevelCPdata2 = [];

        this.PriorityListOrderValue = [];
        this.RecordTypeOrderValue = [];
        this.RevenueTypeOrderValue = [];
        this.modLevelCPGrid = [];
        this.gridData2.forEach((val) => {
            const sp: SchedulePriorities = {
                SchedulePriorityID: val.PriorityId,
                Priorities: val.PriorityName,
            };
            this.PriorityListOrderValue.push(sp);
        });
        this.recordTypeGridData.forEach((val) => {
            const sp: SchedulePriorities = {
                SchedulePriorityID: val.PriorityId,
                Priorities: val.PriorityName,
            };
            this.RecordTypeOrderValue.push(sp);
        });
        this.revenueTypeGridData.forEach((val) => {
            const sp: SchedulePriorities = {
                SchedulePriorityID: val.PriorityId,
                Priorities: val.PriorityName,
            };
            this.RevenueTypeOrderValue.push(sp);
        });
        const createCPObj: CreateCP = {
            PlantID: this.site?.plantId,
            PlantName: this.site?.plantName,
            PlanName: this.planNameValue,
            PlanType:
                this.planTypeValue != undefined
                    ? this.planTypeValue["text"]
                    : "",
            Description: this.planDescriptionValue,
            PriorityOrder: this.PriorityListOrderValue,
            RecordTypePriorityOrder: this.RecordTypeOrderValue,
            RevenueTypePriorityOrder: this.RevenueTypeOrderValue,

            LaborResourcesHardConstraint: this.laborResourcesSwitch,
            BayResourcesHardConstraint: this.bayResourcesSwitch,

            UserID: this.userName,
            DataRefreshDate: new Date(
                new Date().getTime() - new Date().getTimezoneOffset() * 60000
            ),

            ModulesLevelCp: this.modLevelCPGrid,
            IsModLevel: false,
            ProductionPlanID: parseInt(this.planID),
            PilotProductIds: [],
            ModifiedById: this.userId,
        };
        this.createCPService
            .getModuleLevelCP2(this.site.plantName, this.planID, createCPObj)
            .subscribe((modules) => {
                if (modules) {
                    const modLevelCPdata1 = [];
                    this.modLevelCPdataAlreadySc = [];
                    this.modLevelCPdata = [];
                    this.modLevelCPdata2 = [];
                    let i = 1;
                    modules.forEach((val) => {
                        const mg: ModuleGridCP = {
                            Id: val.pilotProductID,
                            Priority: val.alreadyScheduled == false ? i : null,
                            Status: "",
                            FCID: val.fcid,
                            PriorityDate: val.priorityDateDDl,
                            PilotSerialNumber: val.pilotSerialNumber,
                            PilotRisk: val.pilotRisk,
                            SalesPriority: val.salesPriority,
                            BuildStyle: val.buildStyleId,
                            BuildSchedule: val.buildScheduleId,
                            DayShiftOnly:
                                val.dayShiftOnly != null
                                    ? val.dayShiftOnly
                                    : false,
                            NoCapacity: val.noCapacity,
                            RecordType: val.recordType,
                            RevenueType: val.revenueCode,
                            ToolType: val.toolTypeName,
                            ToolTypeID: val.toolTypeID,

                            CustomerID: val.customerID,
                            CompleteATP: val.completeATP,

                            MPSName: val.mpsName,
                            ProductType: val.productGroupName,
                            BuildTypeId: val.buildTypeID,
                            BuildType: val.buildTypeName,

                            SubAssyBaysNeeded: val.baysRequiredSubassembly,
                            SubAssyHrs: val.totalAssemblyHours,
                            SubAssyTechs: val.technicianRequiredSubassembly,
                            IntBaysNeeded: val.baysRequiredIntegration,
                            IntHrs: val.totalIntegrationHours,
                            IntTechs: val.technicianRequiredIntegration,
                            TestBaysNeeded: val.baysRequiredForTest,
                            TestHrs: val.totalTestHours,
                            TestTechs: val.technicianRequiredTest,
                            PostTestBaysNeeded: val.baysRequiredPostTest,
                            PostTestHrs: val.totalPostTestHours,
                            PostTestTechs: val.technicianRequiredPostTest,
                            TotalLaborHrs:
                                val.noCapacity != true ? val.totalLaborHour : 0,
                            ScheduleStatus: val.scheduleStatus,
                            ScheduleStatusId: val.scheduleStatusId,

                            EarliestAllowedLaunchDate:
                                val.earliestStartDate != null
                                    ? moment(val.earliestStartDate).format(
                                          "M-D-YY"
                                      )
                                    : null,
                            MaterialReadiness:
                                val.materialReadiness != null
                                    ? moment(val.materialReadiness).format(
                                          "M-D-YY"
                                      )
                                    : null,
                            BOM:
                                val.poabomReleaseDate != null
                                    ? moment(val.poabomReleaseDate).format(
                                          "M-D-YY"
                                      )
                                    : null,
                            TranisitionDate:
                                val.transitionDate != null
                                    ? moment(val.transitionDate).format(
                                          "M-D-YY"
                                      )
                                    : null,
                            Launch:
                                val.commitLaunch != null
                                    ? moment(val.commitLaunch).format("M-D-YY")
                                    : null,
                            Integration:
                                val.committedIntegrationStart != null
                                    ? moment(
                                          val.committedIntegrationStart
                                      ).format("M-D-YY")
                                    : null,
                            TestStart:
                                val.commitTestStart != null
                                    ? moment(val.commitTestStart).format(
                                          "M-D-YY"
                                      )
                                    : null,
                            MfgComplete:
                                val.commitManufacturingComplete != null
                                    ? moment(
                                          val.commitManufacturingComplete
                                      ).format("M-D-YY")
                                    : null,
                            PilotMCSD:
                                val.pilotMCSD != null
                                    ? moment(val.pilotMCSD).format("M-D-YY")
                                    : null,
                            SapMCSD:
                                val.sapMCSD != null
                                    ? moment(val.sapMCSD).format("M-D-YY")
                                    : null,

                            TSD:
                                val.tsd != null
                                    ? moment(val.tsd).format("M-D-YY")
                                    : null,

                            CRD:
                                val.crd != null
                                    ? moment(val.crd).format("M-D-YY")
                                    : null,
                            CRDGap: val.crdGapDays,
                            CRDEsc: val.crdEsc,
                            SRD:
                                val.srd != null
                                    ? moment(val.srd).format("M-D-YY")
                                    : null,
                            Color: val.capacityPlanningColor,
                            Notes: val.notes,
                            DisabledNoCapacity: false,

                            ModuleIdSubassembly: val.moduleIdSubassembly,
                            ModuleIdIntegration: val.moduleIdIntegration,
                            ModuleIdTest: val.moduleIdTest,
                            ModuleIdPostTest: val.moduleIdPostTest,
                            ActualDMRF:
                                val.actualDMRF != null
                                    ? moment(val.actualDMRF).format("M-D-YY")
                                    : null,
                            PlannedDMRF:
                                val.PlannedDMRF != null
                                    ? moment(val.PlannedDMRF).format("M-D-YY")
                                    : null,
                            POM: val.pom,
                            BEN: val.ben,
                            Warning: this.setWarning(val),
                            AlreadyScheduled: val.alreadyScheduled,

                            PlanOfRecord:
                                val.planofRecord != null
                                    ? moment(val.planofRecord).format("M-D-YY")
                                    : null,
                            T09Comment: val.t09Comment,
                            onPOR: val.onPOR,
                        };
                        if (
                            mg.PriorityDate === null ||
                            mg.PriorityDate === undefined
                        ) {
                            mg.PriorityDate =
                                this.site.plantName == "Fremont"
                                    ? "POR"
                                    : "CRD";
                        }
                        if (this.newlyAddedPilotProductIds.includes(mg.Id)) {
                            mg.PriorityDate =
                                this.site.plantName == "Fremont"
                                    ? "POR"
                                    : "CRD";
                        }
                        modLevelCPdata1.push(mg);
                        if (mg.AlreadyScheduled === false) i = i + 1;
                        if (this.isCancelChangesClicked) {
                            this.showGeneralTab = false;
                            this.showModLevelTab = true;
                            this.showModTab = true;
                            this.isCancelChangesClicked = false;
                        }
                    });
                    this.modLevelCPdata = [
                        ...modLevelCPdata1,
                        ...this.modLevelCPdataAlreadySc,
                    ];
                    this.modLevelCPdata2 = [...this.modLevelCPdata];
                }
            });
        this.tabId = this.tempTabId;
        this.changeDetector.detectChanges();
        if (this.planID != "0") {
            this.router.navigate([
                "/create-capacity-plan/" + this.planID + "/1",
            ]);
        }
    }

    setWarning(val) {
        let subAssyWarn = false;
        let inteWarn = false;
        let testWarn = false;
        let postTestWarn = false;

        if (
            val.baysRequiredSubassembly == 0 ||
            val.totalAssemblyHours == 0 ||
            val.technicianRequiredSubassembly == 0
        ) {
            subAssyWarn = true;
        }
        if (
            val.baysRequiredIntegration == 0 ||
            val.totalIntegrationHours == 0 ||
            val.technicianRequiredIntegration == 0
        ) {
            inteWarn = true;
        }
        if (
            val.baysRequiredForTest == 0 ||
            val.totalTestHours == 0 ||
            val.technicianRequiredTest == 0
        ) {
            testWarn = true;
        }
        if (
            val.baysRequiredPostTest == 0 ||
            val.totalPostTestHours == 0 ||
            val.technicianRequiredPostTest == 0
        ) {
            postTestWarn = true;
        }

        if (
            subAssyWarn &&
            inteWarn &&
            testWarn &&
            postTestWarn &&
            val.noCapacity == false
        ) {
            val.Warning = true;
            return true;
        }

        if (val.priorityDateDDl === "CRD") {
            if (
                (val.crd == null || new Date(val.crd) < new Date()) &&
                !val.alreadyScheduled
            ) {
                return true;
            } else {
                return false;
            }
        } else if (val.priorityDateDDl === "MCSD") {
            if (
                (val.pilotMCSD == null ||
                    new Date(val.pilotMCSD) < new Date()) &&
                !val.alreadyScheduled
            ) {
                return true;
            } else {
                return false;
            }
        } else if (val.priorityDateDDl === "TSD") {
            if (
                (val.tsd == null || new Date(val.tsd) < new Date()) &&
                !val.alreadyScheduled
            ) {
                return true;
            } else {
                return false;
            }
        } else if (val.priorityDateDDl === "SRD") {
            if (
                (val.srd == null || new Date(val.srd) < new Date()) &&
                !val.alreadyScheduled
            ) {
                return true;
            } else {
                return false;
            }
        } else if (
            (val.priorityDateDDl === "POR" ||
                new Date(val.priorityDateDDl) < new Date()) &&
            !val.alreadyScheduled
        ) {
            if (val.planofRecord == null) {
                return true;
            } else {
                return false;
            }
        } else if (val.priorityDateDDl === "Launch") {
            if (
                (val.commitLaunch == null ||
                    new Date(val.commitLaunch) < new Date()) &&
                !val.alreadyScheduled
            ) {
                return true;
            } else {
                return false;
            }
        } else if (val.priorityDateDDl == null) {
            if (
                val.crd == null &&
                val.pilotMCSD == null &&
                val.tsd == null &&
                val.srd == null &&
                val.planofRecord == null &&
                val.commitLaunch
            ) {
                return true;
            }
        }
        return false;
    }
    useDefaults() {}
    generateSchedule() {
        if (
            this.modLevelCPdata.length == 0 ||
            this.checkUndscheduledModules() == 0
        ) {
            this.noModulesAvailableForScheduleOpened = true;
            if (parseInt(this.planID) > 0) {
                this.showNoModulesAvailableMsg =
                    "There are no modules added to be scheduled. Do you want to go to already existing schedule?";
            } else {
                this.showNoModulesAvailableMsg =
                    "There are no modules added to be scheduled. Please add a module first to continue.";
            }
        } else {
            this.countWarning = 0;
            this.modLevelCPdata.forEach((val) => {
                if (val.Warning == true) {
                    this.countWarning = this.countWarning + 1;
                }
            });
            if (this.countWarning > 0) {
                this.missingPriorityDateOpened = true;
            } else {
                this.generateScheduleOpened = true;
            }
        }
    }
    checkUndscheduledModules() {
        let count = 0;
        this.modLevelCPdata.forEach((val) => {
            if (val.AlreadyScheduled == false || val.AlreadyScheduled == null) {
                count += 1;
            }
        });
        return count;
    }
    onProceedClick() {
        this.missingPriorityDateOpened = false;
        this.generateScheduleOpened = true;
    }
    onCancelProceedClick() {
        this.missingPriorityDateOpened = false;
    }

    onGenerateSchedule(isModLevel) {
        if (
            this.planDescriptionValue != "" &&
            this.planNameValue != undefined
        ) {
            this.showValidationErr = false;
        } else {
            this.showValidationErr = true;
            this.generateScheduleOpened = false;
            return;
        }

        this.submitCreateCP(isModLevel);
        this.generateScheduleOpened = false;
    }
    onCancelGenerateSchedule() {
        this.generateScheduleOpened = false;
    }

    onOkNoModulesAvailable() {
        this.noModulesAvailableForScheduleOpened = false;
        if (parseInt(this.planID) > 0) {
            if (this.planTypeValue["text"].toString() === "POR") {
                this.router.navigate(["/mps"]);
            } else {
                this.router.navigate([
                    "/schedule-generated/" + this.planID.toString(),
                ]);
            }
        }
    }
    onCancelNoModulesAvailable() {
        this.noModulesAvailableForScheduleOpened = false;
    }
    submitCreateCP(isModLevel: boolean) {
        this.isLoading = true;
        this.startProgress();
        this.PriorityListOrderValue = [];
        this.RecordTypeOrderValue = [];
        this.RevenueTypeOrderValue = [];
        this.modLevelCPGrid = [];
        this.notificationMsg = "";
        this.gridData2.forEach((val) => {
            const sp: SchedulePriorities = {
                SchedulePriorityID: val.PriorityId,
                Priorities: val.PriorityName,
            };
            this.PriorityListOrderValue.push(sp);
        });
        this.recordTypeGridData.forEach((val) => {
            const sp: SchedulePriorities = {
                SchedulePriorityID: val.PriorityId,
                Priorities: val.PriorityName,
            };
            this.RecordTypeOrderValue.push(sp);
        });
        this.revenueTypeGridData.forEach((val) => {
            const sp: SchedulePriorities = {
                SchedulePriorityID: val.PriorityId,
                Priorities: val.PriorityName,
            };
            this.RevenueTypeOrderValue.push(sp);
        });
        //only allowing modules without warning and with a earliest allowed start date
        this.modLevelCPdata.forEach((val) => {
            if (val.Warning == false && val.AlreadyScheduled != 1) {
                const ml: ModLevelCPGrid = {
                    PilotProductID: val.Id,
                    FCID: val.FCID,
                    PilotRisk: val.PilotRisk,
                    PilotSerialNumber: val.PilotSerialNumber,
                    PriorityDateDDl: val.PriorityDate,
                    PriorityDate: new Date(),

                    CompleteATP: val.CompleteATP,
                    CustomerID: val.CustomerID,

                    BuildStyleId: val.BuildStyle,
                    BuildScheduleId: val.BuildSchedule,
                    DayShiftOnly:
                        val.DayShiftOnly != null ? val.dayShiftOnly : false,
                    NoCapacity: val.NoCapacity,
                    RecordType: val.RecordType,
                    RevenueCode: val.RevenueType,
                    ProductGroupName: val.ProductType,
                    ToolTypeName: val.ToolType,
                    ToolTypeId: val.ToolTypeID,
                    BuildTypeId: parseInt(val.BuildTypeId),
                    BaysRequired: 0,

                    BaysRequiredSubassembly: val.SubAssyBaysNeeded,
                    TotalAssemblyHours: val.SubAssyHrs,
                    TechnicianRequiredSubassembly: val.SubAssyTechs,

                    BaysRequiredIntegration: val.IntBaysNeeded,
                    TotalIntegrationHours: val.IntHrs,
                    TechnicianRequiredIntegration: val.IntTechs,

                    BaysRequiredForTest: val.TestBaysNeeded,
                    TotalTestHours: val.TestHrs,
                    TechnicianRequiredTest: val.TestTechs,

                    BaysRequiredPostTest: val.PostTestBaysNeeded,
                    TotalPostTestHours: val.PostTestHrs,
                    TechnicianRequiredPostTest: val.PostTestTechs,

                    TotalLaborHour:
                        val.NoCapacity != true ? val.TotalLaborHrs : 0,
                    ScheduleStatus: val.ScheduleStatus,
                    ScheduleStatusId: val.ScheduleStatusId,

                    //Dates
                    EarliestStartDate:
                        val.EarliestAllowedLaunchDate != null
                            ? moment(val.EarliestAllowedLaunchDate).format(
                                  "yyyy-MM-DD"
                              )
                            : moment(new Date())
                                  .add(1, "days")
                                  .format("yyyy-MM-DD"),
                    MaterialReadiness:
                        val.MaterialReadiness != null
                            ? moment(val.MaterialReadiness).format("yyyy-MM-DD")
                            : null,
                    ActualDMRF: null,
                    ActualShipDate:
                        val.TranisitionDate != null
                            ? moment(val.TranisitionDate).format("yyyy-MM-DD")
                            : null, //Actual Ship date-->transistion date
                    CommitLaunch:
                        val.Launch != null
                            ? moment(val.Launch).format("yyyy-MM-DD")
                            : null,
                    CommittedIntegrationStart:
                        val.Integration != null
                            ? moment(val.Integration).format("yyyy-MM-DD")
                            : null,
                    CommitTestStart:
                        val.TestStart != null
                            ? moment(val.TestStart).format("yyyy-MM-DD")
                            : null,
                    CommitManufacturingComplete:
                        val.MfgComplete != null
                            ? moment(val.MfgComplete).format("yyyy-MM-DD")
                            : null,
                    CRD:
                        val.CRD != null
                            ? moment(val.CRD).format("yyyy-MM-DD")
                            : null,
                    SRD:
                        val.SRD != null
                            ? moment(val.SRD).format("yyyy-MM-DD")
                            : null,
                    TSD:
                        val.TSD != null
                            ? moment(val.TSD).format("yyyy-MM-DD")
                            : null,
                    PilotManufacturingCommitedShipDate:
                        val.MfgComplete != null
                            ? moment(val.MfgComplete).format("yyyy-MM-DD")
                            : null,
                    POABOMReleaseDate:
                        val.BOM != null
                            ? moment(val.BOM).format("yyyy-MM-DD")
                            : null,
                    PilotMCSD:
                        val.PilotMCSD != null
                            ? moment(val.PilotMCSD).format("yyyy-MM-DD")
                            : null,

                    SalesPriority:
                        val.SalesPriority != null
                            ? val.SalesPriority.toString()
                            : null,
                    CRDGapDays: val.CRDGap, //should be int
                    CRDEsc: val.CRDEsc,

                    CapacityPlanningColor: val.Color,
                    Notes: val.Notes,

                    ModuleIdSubassembly: val.ModuleIdSubassembly,
                    ModuleIdIntegration: val.ModuleIdIntegration,
                    ModuleIdTest: val.ModuleIdTest,
                    ModuleIdPostTest: val.ModuleIdPostTest,
                    PlanofRecord:
                        val.PlanOfRecord != null
                            ? moment(val.PlanOfRecord).format("yyyy-MM-DD")
                            : null,

                    ProductionPlanID: parseInt(this.planID),
                    ModifiedBy: this.userId,
                    ModifiedOn: new Date(
                        new Date().getTime() -
                            new Date().getTimezoneOffset() * 60000
                    ),
                };
                this.modLevelCPGrid.push(ml);
            }
        });

        if (this.planNameValue === undefined) {
            this.showPlanNameInvalid = true;
        } else {
            this.showPlanNameInvalid = false;
        }
        if (this.planTypeValue["text"] === "") {
            this.showPlanTypeInvalid = true;
        } else {
            this.showPlanTypeInvalid = false;
        }

        const createCPObj: CreateCP = {
            PlantID: this.site?.plantId,
            PlantName: this.site?.plantName,
            PlanName: this.planNameValue,
            PlanType: this.planTypeValue["text"],
            Description: this.planDescriptionValue,
            PriorityOrder: this.PriorityListOrderValue,
            RecordTypePriorityOrder: this.RecordTypeOrderValue,
            RevenueTypePriorityOrder: this.RevenueTypeOrderValue,

            LaborResourcesHardConstraint: this.laborResourcesSwitch,
            BayResourcesHardConstraint: this.bayResourcesSwitch,

            UserID: this.userName,
            DataRefreshDate: new Date(
                new Date().getTime() - new Date().getTimezoneOffset() * 60000
            ),

            ModulesLevelCp: this.modLevelCPGrid,
            IsModLevel: isModLevel,
            ProductionPlanID: parseInt(this.planID),
            PilotProductIds: [],
            ModifiedById: this.userId,
        };
        this.batchesOfFive(createCPObj);
    }

    async batchesOfFive(createCPObj) {
        const originalModulesLevelCp = createCPObj.ModulesLevelCp;
        const totalBatches = Math.ceil(createCPObj.ModulesLevelCp.length / 5);

        for (let i = 0; i < totalBatches; i++) {
            const startIndex = i * 5;
            const endIndex = startIndex + 5;
            createCPObj.ModulesLevelCp = [];
            createCPObj.ModulesLevelCp = originalModulesLevelCp.slice(
                startIndex,
                endIndex
            );
            const res = await this.createCPService.getGeneratedSchedule(
                createCPObj
            );
            if (res) {
                this.successCount =
                    this.successCount + parseInt(res.value.split("|")[1]);
                if (res && res.value.split("|")[0] !== "") {
                    //Error
                    this.notificationMsg =
                        this.notificationMsg + res.value.split("|")[0];
                }

                //last batch
                if (i === totalBatches - 1) {
                    if (
                        this.notificationMsg &&
                        this.notificationMsg.length > 0
                    ) {
                        //Error
                        this.isLoading = false;
                        this.notificationMsg =
                            "Schedule not generated. " + this.notificationMsg;
                        this.showErrorDialogbox = true;
                        this.resetProgress();
                    } else {
                        //navigate
                        this.isLoading = false;
                        if (this.planTypeValue["text"].toString() === "POR") {
                            this.router.navigate(["/mps"]);
                        } else {
                            this.router.navigate([
                                "/schedule-generated/" + this.planID.toString(),
                            ]);
                        }
                    }
                }
            }
        }
    }

    public setSelectableSettings(): void {
        if (this.checkboxOnly || this.mode === "single") {
            this.drag = false;
        }

        this.selectableSettings = {
            checkboxOnly: this.checkboxOnly,
            mode: "single",
            drag: this.drag,
        };
    }

    keyChange2(e) {
        this.extract2();
    }
    public extract2() {
        this.extractDataItems2 = this.mySelection2.map((idx) => {
            return this.gridData2.find((item) => item.PriorityId === idx);
        });
        if (this.extractDataItems2.length == 1) {
            this.enableArrowButtons = true;
        } else {
            this.enableArrowButtons = false;
        }
    }
    onUpArrowClick() {
        this.extractDataItems3 = this.mySelection2.map((idx) => {
            return this.gridData2.find((item) => item.PriorityId === idx);
        });
        for (let i = 0; i < this.gridData2.length; i++) {
            if (
                this.gridData2[i].PriorityId ==
                this.extractDataItems3[0].PriorityId
            ) {
                if (i - 1 >= 0) {
                    this.gridData2.splice(
                        i - 1,
                        0,
                        this.gridData2.splice(i, 1)[0]
                    );
                }
            }
        }
    }
    onDownArrowClick() {
        this.extractDataItems3 = this.mySelection2.map((idx) => {
            return this.gridData2.find((item) => item.PriorityId === idx);
        });
        for (let i = 0; i < this.gridData2.length; i++) {
            if (
                this.gridData2[i].PriorityId ==
                this.extractDataItems3[0].PriorityId
            ) {
                this.gridData2.splice(i + 1, 0, this.gridData2.splice(i, 1)[0]);
                break;
            }
        }
    }
    openSetOrder(data) {
        if (data.PriorityName == "Record Type") {
            this.showRecordTypeGrid = true;
            this.showRevenueTypeGrid = false;
        } else if (data.PriorityName == "Revenue Type") {
            this.showRecordTypeGrid = false;
            this.showRevenueTypeGrid = true;
        }
    }

    keyChange3(e) {
        this.extract3();
    }
    public extract3() {
        this.extractRecordItems = this.recordTypeSelection.map((idx) => {
            return this.recordTypeGridData.find(
                (item) => item.PriorityId === idx
            );
        });
        if (this.extractRecordItems.length == 1) {
            this.enableRecordArrowButtons = true;
        } else {
            this.enableRecordArrowButtons = false;
        }
    }

    keyChange4(e) {
        this.extract4();
    }
    public extract4() {
        this.extractRevenueItems = this.revenueTypeSelection.map((idx) => {
            return this.gridData2.find((item) => item.PriorityId === idx);
        });
        if (this.extractRevenueItems.length == 1) {
            this.enableRevenueArrowButtons = true;
        } else {
            this.enableRevenueArrowButtons = false;
        }
    }
    onRecordUpArrowClick() {
        this.recordTypeGridData.splice(
            0,
            0,
            this.recordTypeGridData.splice(1, 1)[0]
        );
    }
    onRecordDownArrowClick() {
        this.recordTypeGridData.splice(
            1,
            0,
            this.recordTypeGridData.splice(0, 1)[0]
        );
    }
    onRevenueUpArrowClick() {
        this.revenueTypeGridData.splice(
            0,
            0,
            this.revenueTypeGridData.splice(1, 1)[0]
        );
    }
    onRevenueDownArrowClick() {
        this.revenueTypeGridData.splice(
            0,
            0,
            this.revenueTypeGridData.splice(1, 1)[0]
        );
    }
    onRecordTypeConfirmClick() {
        this.setOrderRecordType = "Complete";
        this.setOrderRecordTypeColor = "Blue";
        this.showRecordTypeGrid = false;
    }
    onRevenueTypeConfirmClick() {
        this.setOrderRevenueType = "Complete";
        this.setOrderRevenueTypeColor = "Blue";
        this.showRevenueTypeGrid = false;
    }
    getValueFromText(arr: Array<Item>, key: any) {
        let val = -1;
        if (typeof key === "string") {
            for (let i = 0; i < arr.length; i++) {
                if (arr[i].text == key) {
                    val = arr[i].value;
                }
            }
        } else {
            for (let i = 0; i < arr.length; i++) {
                if (arr[i].text == key.text) {
                    val = arr[i].value;
                }
            }
        }
        return val;
    }
    getTextFromValue(arr: Array<Item>, key: any) {
        let val = "";
        if (typeof key === "number") {
            for (let i = 0; i < arr.length; i++) {
                if (arr[i].value == key) {
                    val = arr[i].text;
                }
            }
        }
        return val;
    }

    planTypeSelectionChange(event) {
        if (event.text == "POR") {
            const count = this.planGridData.filter(
                (x) => x.PlanType == event.text
            ).length;
            if (count > 0) {
                this.showErrorMsg = true;
            } else {
                this.showErrorMsg = false;
            }
        } else {
            this.showErrorMsg = false;
        }
    }
    cancelModuleChangesHandler(data) {
        this.cancelPORChanges = false;
        this.onRemoveClick();
        this.isCancelChangesClicked = data;
        this.fillModuleGridOnTabChange();
    }
    updatedModuleHandler(data) {
        this.updateModuleObj = [];
        data[0].forEach((val) => {
            const updateModule: ModLevelCPGrid = {
                PilotProductID: val.Id,
                FCID: val.FCID,
                PilotRisk: val.PilotRisk,
                PilotSerialNumber: val.PilotSerialNumber,

                PriorityDateDDl: val.PriorityDate,

                BuildStyleId: val.BuildStyle,
                BuildScheduleId: val.BuildSchedule,
                DayShiftOnly:
                    val.DayShiftOnly != null ? val.dayShiftOnly : false,
                NoCapacity: val.NoCapacity,
                RecordType: val.RecordType,
                RevenueCode: val.RevenueType,
                ProductGroupName: val.ProductType,
                ToolTypeName: val.ToolType,
                ToolTypeId: val.ToolTypeID,

                BuildTypeId: parseInt(val.BuildTypeId),
                BaysRequired: 0,

                CompleteATP: val.CompleteATP,
                CustomerID: val.CustomerID,

                BaysRequiredSubassembly: val.SubAssyBaysNeeded,
                TotalAssemblyHours: val.SubAssyHrs,
                TechnicianRequiredSubassembly: val.SubAssyTechs,

                BaysRequiredIntegration: val.IntBaysNeeded,
                TotalIntegrationHours: val.IntHrs,
                TechnicianRequiredIntegration: val.IntTechs,

                BaysRequiredForTest: val.TestBaysNeeded,
                TotalTestHours: val.TestHrs,
                TechnicianRequiredTest: val.TestTechs,

                BaysRequiredPostTest: val.PostTestBaysNeeded,
                TotalPostTestHours: val.PostTestHrs,
                TechnicianRequiredPostTest: val.PostTestTechs,

                TotalLaborHour:
                    val.SubAssyHrs + val.IntHrs + val.TestHrs + val.PostTestHrs,
                ScheduleStatus: val.ScheduleStatus,
                ScheduleStatusId: val.ScheduleStatusId,

                //Dates
                PriorityDate: new Date(),
                EarliestStartDate:
                    val.EarliestAllowedLaunchDate != null
                        ? moment(val.EarliestAllowedLaunchDate).format(
                              "yyyy-MM-DD"
                          )
                        : null,
                MaterialReadiness:
                    val.MaterialReadiness != null
                        ? moment(val.MaterialReadiness).format("yyyy-MM-DD")
                        : null,
                ActualDMRF: null,
                ActualShipDate:
                    val.TranisitionDate != null
                        ? moment(val.TranisitionDate).format("yyyy-MM-DD")
                        : null, //Actual Ship date-->transistion date
                CommitLaunch:
                    val.Launch != null
                        ? moment(val.Launch).format("yyyy-MM-DD")
                        : null,
                CommittedIntegrationStart:
                    val.Integration != null
                        ? moment(val.Integration).format("yyyy-MM-DD")
                        : null,
                CommitTestStart:
                    val.TestStart != null
                        ? moment(val.TestStart).format("yyyy-MM-DD")
                        : null,
                CommitManufacturingComplete:
                    val.MfgComplete != null
                        ? moment(val.MfgComplete).format("yyyy-MM-DD")
                        : null,
                CRD:
                    val.CRD != null
                        ? moment(val.CRD).format("yyyy-MM-DD")
                        : null,
                SRD:
                    val.SRD != null
                        ? moment(val.SRD).format("yyyy-MM-DD")
                        : null,
                TSD:
                    val.TSD != null
                        ? moment(val.TSD).format("yyyy-MM-DD")
                        : null,
                PilotManufacturingCommitedShipDate:
                    val.MfgComplete != null
                        ? moment(val.MfgComplete).format("yyyy-MM-DD")
                        : null,
                POABOMReleaseDate:
                    val.BOM != null
                        ? moment(val.BOM).format("yyyy-MM-DD")
                        : null,
                PilotMCSD:
                    val.PilotMCSD != null
                        ? moment(val.PilotMCSD).format("yyyy-MM-DD")
                        : null,

                SalesPriority:
                    val.SalesPriority != null
                        ? val.SalesPriority.toString()
                        : null,
                CRDGapDays: val.CRDGap, //should be int
                CRDEsc: val.CRDEsc,

                CapacityPlanningColor: val.Color,
                Notes: val.Notes,

                ModuleIdSubassembly: val.ModuleIdSubassembly,
                ModuleIdIntegration: val.ModuleIdIntegration,
                ModuleIdTest: val.ModuleIdTest,
                ModuleIdPostTest: val.ModuleIdPostTest,
                PlanofRecord:
                    val.PlanOfRecord != null
                        ? moment(val.PlanOfRecord).format("yyyy-MM-DD")
                        : null,

                ProductionPlanID: parseInt(this.planID),
                ModifiedBy: this.userId,
                ModifiedOn: new Date(
                    new Date().getTime() -
                        new Date().getTimezoneOffset() * 60000
                ),
            };
            this.updateModuleObj.push(updateModule);
        });
        this.showGeneralTab = true;
        this.showModLevelTab = false;
        this.showModTab = false;
        if (parseInt(this.planID) == 0) {
            this.router.navigate(["/capacity/check-capacity"]);
        }
        this.createCPService
            .updateModuleLevelCP(this.updateModuleObj)
            .subscribe((res) => {
                if (res) {
                    this.newlyAddedPilotProductIds = [];
                    this.notificationMsg = "Data Saved Successfully";
                    this.showSuccess(this.notificationMsg);
                    this.savePORChanges = false;
                    this.onRemoveClick();
                    this.appStoreService.setPlanCreatedBy$(this.userName);
                    this.router.navigate([
                        "/create-capacity-plan/" +
                            res.value.split(",")[1] +
                            "/1",
                    ]);
                    this.fillModuleGridOnTabChange();
                    this.showGeneralTab = false;
                    this.showModLevelTab = true;
                    this.showModTab = true;
                    this.changeDetector.detectChanges();
                }
            });
    }
    generateScheduleModLevelHandler(event) {
        this.modLevelCPdata = JSON.parse(JSON.stringify(event));
        this.onGenerateSchedule(true);
    }
    public itemDisabled(itemArgs: { dataItem: string; index: number }) {
        return itemArgs.index === 1;
    }

    canDeactivate(
        nextState: RouterStateSnapshot
    ): Observable<boolean> | Promise<boolean> | boolean {
        if (nextState.url.includes("create-capacity-plan")) {
            if (this.editService.hasChanges()) {
                this.redirectUrl = nextState.url;
                this.isChanged = true;
                this.changeDetector.detectChanges();
                return false;
            } else {
                return true;
            }
        } else {
            if (
                this.planTypeValue !== undefined &&
                this.planTypeValue?.text !== undefined
            ) {
                if (this.planTypeValue.text.toUpperCase().trim() !== "POR") {
                    if (this.editService.hasChanges()) {
                        this.redirectUrl = nextState.url;
                        this.isChanged = true;
                        this.changeDetector.detectChanges();
                        return false;
                    } else {
                        return true;
                    }
                } else {
                    if (
                        this.navigationOff &&
                        this.planTypeValue.text.toUpperCase().trim() === "POR"
                    ) {
                        this.redirectUrl = nextState.url;
                        this.isURLChanged = true;
                        this.changeDetector.detectChanges();
                        return false;
                    } else {
                        return true;
                    }
                }
            } else {
                return true;
            }
        }
    }

    closeEdit() {
        this.isChanged = false;
    }

    discardChanges() {
        this.navigationOff = false;
        this.onCancelPORClick();
        this.modLevelCPdata = JSON.parse(JSON.stringify(this.modLevelCPdata2));
        if (this.redirectUrl != "") {
            this.router.navigate([this.redirectUrl]);
            this.redirectUrl = "";
        }
        this.isChanged = false;
    }

    onSaveModLevel() {
        this.onSavePORClick();
        this.navigationOff = false;
        if (this.redirectUrl != "") {
            this.router.navigate([this.redirectUrl]);
            this.redirectUrl = "";
        }
    }

    onTabSelect(e) {
        this.selectedTab = e.index;
        if (e.title === "General") {
            if (this.editService.hasChanges()) {
                e.prevented = true;
                this.isChanged = true;
                return;
            }
        } else if (e.title === "Module-level") {
            this.fillModuleGridOnTabChange();
        }
    }
    onChangePlanDetails() {
        if (+this.planID == 0 && +this.tabId == 0) {
            if (
                this.planNameValue == null ||
                this.planNameValue == undefined ||
                this.planNameValue == "" ||
                this.planTypeValue?.text == "" ||
                this.planDescriptionValue == null ||
                this.planDescriptionValue == undefined ||
                this.planDescriptionValue == ""
            ) {
                this.disableModLevelTab = true;
            } else {
                this.disableModLevelTab = false;
                this.showValidationErr = false;
            }
        }
    }
    removeModuleModLevelHandler(event) {
        this.showGeneralTab = true;
        this.showModLevelTab = false;
        this.showModTab = false;
        this.createCPService
            .deleteModuleProductionPlan(parseInt(this.planID), event)
            .subscribe((res) => {
                if (res) {
                    this.fillModuleGridOnTabChange();
                    this.showGeneralTab = false;
                    this.showModLevelTab = true;
                    this.showModTab = true;
                    this.changeDetector.detectChanges();
                }
            });
    }
    addModuleModLevelHandler(event) {
        this.newlyAddedPilotProductIds = event;
        if (this.planNameValue == "") {
            this.showValidationErr = true;
            return;
        } else if (
            this.planTypeValue == undefined ||
            this.planTypeValue["text"] == ""
        ) {
            this.showValidationErr = true;
            return;
        } else if (
            this.planDescriptionValue == undefined ||
            this.planDescriptionValue == ""
        ) {
            this.showValidationErr = true;
            return;
        } else {
            this.showPlanTypeInvalid = false;
        }
        const addModObj: CreateCP = {
            PlantID: this.site?.plantId,
            PlantName: this.site?.plantName,
            PlanName: this.planNameValue,
            PlanType:
                this.planTypeValue != undefined
                    ? this.planTypeValue["text"]
                    : "",
            Description: this.planDescriptionValue,
            PriorityOrder: [],
            RecordTypePriorityOrder: [],
            RevenueTypePriorityOrder: [],

            LaborResourcesHardConstraint: this.laborResourcesSwitch,
            BayResourcesHardConstraint: this.bayResourcesSwitch,

            UserID: this.userName,
            DataRefreshDate: new Date(
                new Date().getTime() - new Date().getTimezoneOffset() * 60000
            ),

            ModulesLevelCp: [],
            IsModLevel: false,
            ProductionPlanID: parseInt(this.planID),
            PilotProductIds: event,
            ModifiedById: this.userId,
        };
        this.showGeneralTab = true;
        this.showModLevelTab = false;
        this.showModTab = false;
        if (parseInt(this.planID) == 0) {
            this.router.navigate(["/capacity/check-capacity"]);
        }
        this.createCPService
            .addModuleProductionPlan(addModObj)
            .subscribe((res) => {
                if (res) {
                    this.appStoreService.setPlanCreatedBy$(this.userName);
                    this.router.navigate([
                        "/create-capacity-plan/" +
                            res.value.split(",")[1] +
                            "/1",
                    ]);
                    this.fillModuleGridOnTabChange();
                    this.showGeneralTab = false;
                    this.showModLevelTab = true;
                    this.showModTab = true;
                    this.changeDetector.detectChanges();
                }
            });
    }

    public labelSettings: LabelSettings = {
        position: "end",
        format: () => this.labelText,
    };

    public startProgress() {
        const notYetScheduledModules = [
            ...this.modLevelCPdata.filter((item) => item.AlreadyScheduled != 1),
        ];
        let totalTime = 0;
        for (let i = 0; i < notYetScheduledModules.length; i++) {
            if (notYetScheduledModules[i].TotalLaborHrs <= 150) {
                totalTime = totalTime + 70;
            } else if (
                notYetScheduledModules[i].TotalLaborHrs > 150 &&
                notYetScheduledModules[i].TotalLaborHrs <= 350
            ) {
                totalTime = totalTime + 100;
            } else if (
                notYetScheduledModules[i].TotalLaborHrs > 350 &&
                notYetScheduledModules[i].TotalLaborHrs <= 550
            ) {
                totalTime = totalTime + 200;
            } else if (
                notYetScheduledModules[i].TotalLaborHrs > 550 &&
                notYetScheduledModules[i].TotalLaborHrs <= 950
            ) {
                totalTime = totalTime + 300;
            } else if (
                notYetScheduledModules[i].TotalLaborHrs > 950 &&
                notYetScheduledModules[i].TotalLaborHrs <= 2000
            ) {
                totalTime = totalTime + 400;
            } else if (
                notYetScheduledModules[i].TotalLaborHrs > 2000 &&
                notYetScheduledModules[i].TotalLaborHrs <= 2800
            ) {
                totalTime = totalTime + 500;
            } else if (
                notYetScheduledModules[i].TotalLaborHrs > 2800 &&
                notYetScheduledModules[i].TotalLaborHrs <= 4200
            ) {
                totalTime = totalTime + 600;
            } else if (notYetScheduledModules[i].TotalLaborHrs > 4200) {
                totalTime = totalTime + 700;
            }
        }

        this.running = setInterval(() => {
            if (this.value <= 99) {
                this.labelText = this.value + "%";
                this.value++;
            }
        }, totalTime);
    }

    public stopProgress(): void {
        if (this.running) {
            clearInterval(this.running);
            this.running = null;
        }
    }

    public resetProgress(): void {
        this.value = 0;
        this.stopProgress();
    }

    onChangeLaborHCSwitch(event) {
        this.laborResourcesSwitch = event;
        this.appStoreService.setLaborHardConstraint$(event);
    }
    onChangeBayHCSwitch(event) {
        this.bayResourcesSwitch = event;
        this.appStoreService.setBayHardConstraint$(event);
    }

    onEditPORClick() {
        this.createCPService
            .checkIfPORIsBeingEdited(+this.planID)
            .subscribe((por) => {
                if (por.isBeingEdited) {
                    this.editModeOn = false;
                    this.navigationOff = false;
                    this.getPlanDetails();
                } else {
                    this.editModeOn = true;
                    this.navigationOff = true;
                    const data: ProductionPlan = {
                        ProductionPlanId: +this.planID,
                        IsBeingEditedById: this.userId,
                        IsBeingEditedBy: this.userName,
                        IsBeingEdited: true,
                    };
                    //api to set lock
                    this.mpsService
                        .UpdateEditStatus(data, +this.planID)
                        .subscribe((res) => {
                            if (res != null) {
                                this.appStoreService.setOperrationLogDetails$(
                                    true
                                );
                                this.getPlanDetails();
                            }
                        });
                }
            });
    }

    onSavePORClick() {
        this.createCPService
            .checkIfPORIsBeingEdited(+this.planID)
            .subscribe((por) => {
                if (por.isBeingEdited && por.isBeingEditedById == this.userId) {
                    this.savePORChanges = true;
                    this.changeDetector.detectChanges();
                } else {
                    this.editModeOn = false;
                    this.navigationOff = false;
                    this.getPlanDetails();
                    this.changeDetector.detectChanges();
                }
            });
    }

    onCancelPORClick() {
        if (+this.selectedTab === 0) {
            this.cancelModuleChangesHandler(true);
        } else {
            this.createCPService
                .checkIfPORIsBeingEdited(+this.planID)
                .subscribe((por) => {
                    if (
                        por.isBeingEdited &&
                        por.isBeingEditedById == this.userId
                    ) {
                        this.cancelPORChanges = true;
                        this.changeDetector.detectChanges();
                    } else {
                        this.getPlanDetails();
                    }
                });
        }
    }

    onRemoveClick() {
        this.createCPService
            .checkIfPORIsBeingEdited(+this.planID)
            .subscribe((por) => {
                if (por.isBeingEdited) {
                    //api to remove lock
                    const data: ProductionPlan = {
                        ProductionPlanId: +this.planID,
                        IsBeingEditedById: this.userId,
                        IsBeingEditedBy: this.userName,
                        IsBeingEdited: false,
                    };
                    this.mpsService
                        .UpdateEditStatus(data, +this.planID)
                        .subscribe((res) => {
                            if (res != null) {
                                this.appStoreService.setOperrationLogDetails$(
                                    true
                                );
                                this.getPlanDetails();
                            }
                        });
                } else {
                    this.getPlanDetails();
                }
            });
    }

    gridDataHasChanged(changed: boolean) {
        this.savePORClickable = changed;
    }

    closePOREdit() {
        this.isURLChanged = false;
    }

    onOKClick() {
        this.navigationOff = false;
        if (this.redirectUrl != "") {
            this.router.navigate([this.redirectUrl]);
            this.redirectUrl = "";
        }
    }

    public showSuccess(msg: string): void {
        this.notificationService.show({
            appendTo: this.appendTo,
            content: this.notificationMsg,
            position: { horizontal: "left", vertical: "top" },
            animation: { type: "fade", duration: 600 },
            type: { style: "success", icon: true },
        });
    }

    closeError() {
        this.showErrorDialogbox = false;
        if (this.successCount === 0) {
            this.modLevelCPdata = [];
            this.modLevelCPdataAlreadySc = [];
            this.modLevelCPdata2 = [];
            this.showGeneralTab = true;
            this.showModLevelTab = false;
            if (parseInt(this.planID) === 0) {
                this.router.navigate(["/capacity/check-capacity"]);
            }
            this.router.navigate([
              "/create-capacity-plan/" + this.planID.toString() + "/1",
            ]);
            this.fillModuleGridOnTabChange();
            this.showGeneralTab = false;
            this.showModLevelTab = true;
        } else {
            //navigate
            if (this.planTypeValue["text"].toString() === "POR") {
                this.router.navigate(["/mps"]);
            } else {
                this.router.navigate([
                    "/schedule-generated/" + this.planID.toString(),
                ]);
            }
        }
    }
}
