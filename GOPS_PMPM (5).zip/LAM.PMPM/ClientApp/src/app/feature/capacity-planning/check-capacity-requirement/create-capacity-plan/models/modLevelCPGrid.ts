export interface ModLevelCPGrid {
  PilotProductID: number | undefined;
  FCID: string;
  PilotRisk: string;
  //MCSDRiskLevel: string;
  PilotSerialNumber: string;

  PriorityDateDDl: string;
  PriorityDate: Date | undefined;

  BuildStyleId: number | undefined;
  BuildScheduleId: number | undefined;
  DayShiftOnly: boolean | undefined;
  NoCapacity: boolean | undefined;
  RecordType: string;
  RevenueCode: string;
  ProductGroupName: string;
  ToolTypeName: string;
  ToolTypeId: number;
  BuildTypeId: number;
  //BuildTypeName: string;
  BaysRequired: number | undefined;

  CustomerID: string;
  CompleteATP: string;

  BaysRequiredSubassembly: number | undefined;
  TotalAssemblyHours: number | undefined;
  TechnicianRequiredSubassembly: number | undefined;

  BaysRequiredIntegration: number | undefined;
  TotalIntegrationHours: number | undefined;
  TechnicianRequiredIntegration: number | undefined;

  BaysRequiredForTest: number | undefined;
  TotalTestHours: number | undefined;
  TechnicianRequiredTest: number | undefined;

  BaysRequiredPostTest: number | undefined;
  TotalPostTestHours: number | undefined;
  TechnicianRequiredPostTest: number | undefined;

  TotalLaborHour: number | undefined;

  //Dates
  EarliestStartDate: string;
  MaterialReadiness: string;
  ActualDMRF: string;
  ActualShipDate: string;//Transistion date
  CommitLaunch: string;
  //ActualIntegrationStart: string;
  CommittedIntegrationStart: string;
  CommitTestStart: string;
  CommitManufacturingComplete: string;
  CRD: string;
  SRD: string;
  TSD: string;

  PilotManufacturingCommitedShipDate: string;
  POABOMReleaseDate: string;
  PlanofRecord: string;
  SalesPriority: string;
  //CRDGap: string;//should be int
  CRDGapDays: number;
  CRDEsc: boolean | undefined;

  CapacityPlanningColor: string;
  Notes: string;

  ModuleIdSubassembly: number;
  ModuleIdIntegration: number;
  ModuleIdTest: number;
  ModuleIdPostTest: number;
  ProductionPlanID: number;

  PilotMCSD: string;
  ModifiedBy: number;
  ModifiedOn: Date;
  ScheduleStatus: string;
  ScheduleStatusId: number;
}
