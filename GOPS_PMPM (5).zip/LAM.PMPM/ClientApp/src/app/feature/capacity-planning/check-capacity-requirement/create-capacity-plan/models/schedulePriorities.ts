export class SchedulePriorities {
  SchedulePriorityID: number | undefined;
  Priorities: string;
}
