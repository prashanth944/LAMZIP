export class PriorityOrder {
  PriorityName: string;
  PriorityId: number;
}


