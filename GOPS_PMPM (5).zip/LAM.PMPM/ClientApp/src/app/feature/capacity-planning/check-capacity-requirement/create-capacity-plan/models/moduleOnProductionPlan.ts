export class ModuleOnProductionPlan {
  ModuleOnProductionPlanID: number;
  PilotProductID: number;
  ProductionPlanID: number;
}
