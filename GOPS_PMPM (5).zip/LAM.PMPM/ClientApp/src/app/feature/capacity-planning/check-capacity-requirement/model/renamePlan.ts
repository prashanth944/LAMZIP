export class renamePlan {
  PlanName: string;
  ProductionPlanID: number;
}
