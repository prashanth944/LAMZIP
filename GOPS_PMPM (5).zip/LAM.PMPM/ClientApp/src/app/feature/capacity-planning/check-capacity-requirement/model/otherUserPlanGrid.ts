export class OtherUserPlanGrid {
  PlanId: number;
  PlanName: string;
  PlanType: string;
  DataRefreshDate: string;
  Owner: string;
  LastModified: string;
  PlantId: number;
  Description: string;
  PlantName: string;
}
