export class duplicatePlan {
  PlantID: number;
  ProductionPlanID: number;
  PlanName: string;
  PlanType: string;
  UserID: string;
  DataRefreshDate: Date;
  ModifiedDate: Date;
  Description: string;
  ModifiedById: number;
}
