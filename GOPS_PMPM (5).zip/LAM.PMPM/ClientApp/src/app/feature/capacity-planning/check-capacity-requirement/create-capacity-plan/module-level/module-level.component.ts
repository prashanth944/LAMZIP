import {
    ChangeDetectorRef,
    Component,
    DoCheck,
    EventEmitter,
    Input,
    NgZone,
    OnChanges,
    OnDestroy,
    OnInit,
    Output,
    Renderer2,
    SimpleChanges,
    ViewChild,
    ViewChildren,
    ViewEncapsulation,
} from "@angular/core";
import {
    State,
    process,
    distinct,
    CompositeFilterDescriptor,
    filterBy,
} from "@progress/kendo-data-query";
import { EditService } from "src/app/feature/service/edit.service";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AppStoreService } from "src/app/core/app-store.service";
import { Observable, Subscription, fromEvent } from "rxjs";
import {
    DataBindingDirective,
    GridDataResult,
    RowClassArgs,
} from "@progress/kendo-angular-grid";
import * as moment from "moment";
import { Item } from "../../../../model/item";
import { AdjustModuleService } from "../../../adjust-module/adjust-module-service/adjustModule.service";
import { CreateCPService } from "../../create-capacity-plan/create-cp-service/createCP.service";
import { ModLevelCPGrid } from "../models/modLevelCPGrid";
import { SelectableSettings } from "@progress/kendo-angular-grid";
import { Plant } from "../../../../../core/model/user.model";
import { uiScreen } from "../../../../../core/model/common.constant";
import { ActivatedRoute, Router, RouterStateSnapshot } from "@angular/router";
import { TooltipDirective } from "@progress/kendo-angular-tooltip";
import { AddModuleLevelGrid } from "../models/addModuleLevelGrid";
import { ScheduleGeneratedService } from "../../../../schedule-generated/schedule-generated-service/schedule-generated.service";
import { MultiSelectComponent } from "@progress/kendo-angular-dropdowns";
import { ScheduleStatus } from "../../../../model/schedule-status.model";
import { RequestService } from "../../../../service/request.service";

@Component({
    selector: "pmpm-module-level",
    templateUrl: "./module-level.component.html",
    styleUrls: ["./module-level.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class ModuleLevelComponent implements OnInit, OnChanges, DoCheck {
    @ViewChild("multiselect") public multiselect: MultiSelectComponent;
    @ViewChildren(DataBindingDirective) public binding: DataBindingDirective[];
    @Input() modLevelCPdata: any[] = [];
    @Input() showErrorMsg: boolean;
    @Input() editableByUser: boolean;
    @Output() updatedModule: EventEmitter<any> = new EventEmitter();
    @Output() cancelModuleChanges: EventEmitter<any> = new EventEmitter();
    @Output() generateScheduleModLevel: EventEmitter<any> = new EventEmitter();
    @Output() removeModuleModLevel: EventEmitter<any> = new EventEmitter();
    @Output() addModuleModLevel: EventEmitter<any> = new EventEmitter();

    @Input() editModeOn = false;
    @Input() savePORChanges = false;
    @Input() cancelPORChanges = false;
    @Output() gridDataHasChanged: EventEmitter<boolean> =
        new EventEmitter<boolean>();

    @ViewChild(TooltipDirective) public tooltipDir: TooltipDirective;

    @ViewChild(DataBindingDirective, { static: true })
    dataBinding: DataBindingDirective;
    public gridState: State = {
        take: 20,
        skip: 0,
    };
    public view: Observable<GridDataResult>;

    moduleLevelGridData: Array<any> = [];
    tempModuleLevelGridData: any[] = [];
    moduleLevelGridData2: Array<any> = [];
    moduleLevelGridData3: Array<any> = [];
    public gridFilteredData: Array<any> = [];
    site: Plant;
    public isProductTypeChecked = false;
    public isDivisionChecked = false;
    public isBuildTypeChecked = false;
    public isToolTypeChecked = false;
    public isCustomerChecked = false;

    public productTypeData: any[] = [];
    public divisionData: any[] = [];
    public buildTypeData: any[] = [];
    public toolTypeData: any[] = [];
    public customerData: any[] = [];
    public onPORData: any[] = [];

    public PilotRiskLevelItems: Array<Item> = [
        { text: "", value: "0" },
        { text: "LOW", value: "1" },
        { text: "MEDIUM", value: "2" },
        { text: "HIGH", value: "3" },
        { text: "MISS", value: "3" },
    ];
    public SalesPriorityItems: Array<Item> = [
        { text: "", value: 0 },
        { text: "LOW", value: 1 },
        { text: "MEDIUM", value: 2 },
        { text: "HIGH", value: 3 },
    ];
    public PriorityDateItems: Array<Item> = [];
    public ToolTypeItems: Array<Item> = [];

    SalesPriorityGridValue = { text: "", value: 0 };
    ToolTypeGridValue = { text: "", value: 0 };

    buildTypeItems: Array<Item> = [];
    PilotRiskLevelGridValue = { text: "", value: 0 };
    PriorityDateGridValue = { text: "", value: 0 };
    buildTypeGridValue = { text: "", value: 0 };
    updateModuleObj: ModLevelCPGrid[] = [];
    generateScheduleOpened = false;
    noModulesAvailableForScheduleOpened = false;
    showNoModulesAvailableMsg = "";
    public planID: string;
    planNameValue = "";
    planTypeValue: { text: ""; value: 0 };
    planDescriptionValue = "";
    dataRefreshDate: string = moment(new Date())
        .format("MM-DD-yyyy hh:mm A")
        .toString();

    QV1 = false;
    QV2 = false;
    QV3 = false;
    QVDefault = true;

    filterChecked = false;

    public checkboxOnly = true;
    public mode = "multiple";
    public drag = false;
    public selectableSettings: SelectableSettings;
    public selectableSettings2: SelectableSettings;

    isUserAccess = false;

    enableArrowButtons = false;
    public mySelection: number[] = [];
    public mySelection2: number[] = [];

    public mySelection3: number[] = [];

    public extractDataItems;
    public extractDataItems2;
    public extractDataItems3;

    public extractDataItems4: AddModuleLevelGrid[] = [];

    loadTable = true;

    countWarning = 0;
    showPriorityErrorMsg = false;

    public isChanged = false;
    tooltipMsg = "";
    addOtherModulestoPlanOpened = false;
    addModuleLevelGridData: AddModuleLevelGrid[] = [];
    tempAddModuleLevelGridData: any[] = [];
    searchAddModLevelValue: string;
    loadSearch = false;
    setEditable = false;
    missingPriorityDateOpened = false;
    warningMsg = "";
    showWarningMsg = false;

    openConfirmationPopup = false;
    public removeModule: any;
    public filter: CompositeFilterDescriptor;
    public searchText = "";

    public tempProductTypeData: any[] = [];
    public tempDivisionData: any[] = [];
    public tempBuildTypeData: any[] = [];
    public tempToolTypeData: any[] = [];
    public tempCustomerData: any[] = [];
    public tempOnPORData: any[] = [];

    public productTypeDataItem: any[] = [];
    public divisionDataItem: any[] = [];
    public buildTypeDataItem: any[] = [];
    public toolTypeDataItem: any[] = [];
    public customerDataItem: any[] = [];
    public onPORDataItem: any[] = [];
    public scheduleStatusData: ScheduleStatus[] = [];
    public scheduleStatus: ScheduleStatus;

    public statusData = ["New", "Changed", "Dropped", "Shipped/Crated", "Null"];
    public tempStatusData = [
        "New",
        "Changed",
        "Dropped",
        "Shipped/Crated",
        "Null",
    ];
    public statusDataItem: string[] = [];
    public errMsg = "";
    public showErrMsg = false;

    constructor(
        private appStoreService: AppStoreService,
        private editService: EditService,
        private formBuilder: FormBuilder,
        private renderer: Renderer2,
        private zone: NgZone,
        private router: Router,
        private route: ActivatedRoute,
        private adjustModuleService: AdjustModuleService,
        private changeDetector: ChangeDetectorRef,
        private scheduleService: ScheduleGeneratedService,
        private createCPService: CreateCPService,
        private requestService: RequestService
    ) {}
    ngOnInit() {
        this.loadTable = true;
        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.CreateCP)
                    .subscribe((result) => {
                        this.isUserAccess = result;
                    });
            }
        });
        this.route.params.subscribe((param) => {
            this.planID = param.id;
        });
        this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site)
                this.site = {
                    plantName: site.plantName,
                    plantId: site.plantId,
                };
            this.adjustModuleService
                .getBuildTypeDDL(this.site?.plantId)
                .subscribe((bt) => {
                    bt.forEach((val) => {
                        const newBt: Item = {
                            value: val.value,
                            text: val.masterRecordName,
                        };
                        this.buildTypeItems.push(newBt);
                    });
                });
        });

        this.createCPService.getPriorityDate().subscribe((pd) => {
            pd.forEach((val) => {
                const newPD: Item = {
                    value: val.masterRecordID,
                    text: val.masterRecordName,
                };
                this.PriorityDateItems.push(newPD);
            });
        });
        this.adjustModuleService
            .getToolTypeDDL(this.site?.plantId)
            .subscribe((tt) => {
                tt.forEach((val) => {
                    const newTT: Item = {
                        value: val.toolTypeID,
                        text: val.toolTypeName,
                    };
                    this.ToolTypeItems.push(newTT);
                });
            });

        this.scheduleService
            .getProductionPlanByProdPlanID(parseInt(this.planID))
            .subscribe((val) => {
                if (val.length > 0) {
                    this.planNameValue = val[0]?.planName;
                    this.planTypeValue = { text: val[0]?.planType, value: 0 };
                    if (
                        this.planTypeValue.text.toUpperCase().trim() ===
                            "POR" &&
                        this.editableByUser
                    ) {
                        this.editableByUser = this.editModeOn;
                    }
                    this.planDescriptionValue = val[0]?.description;
                    this.dataRefreshDate = val[0]?.dataRefreshDate;

                    this.changeDetector.detectChanges();
                }
            });
        this.scheduleStatusData = [];
        this.requestService.GetScheduleStatus().subscribe((res) => {
            if (res && res.length > 0) {
                const data = JSON.parse(
                    JSON.stringify(
                        res.filter(
                            (item) =>
                                item.optionName !== "Dropped" &&
                                item.optionName !== "Shipped/Crated"
                        )
                    )
                );
                this.scheduleStatusData.push({
                    optionName: "",
                    scheduleStatusId: null,
                });
                this.scheduleStatusData = [...this.scheduleStatusData, ...data];
            }
        });
        this.gridDataHasChanged.emit(this.editService.hasChanges());
    }

    ngOnChanges(changes: SimpleChanges) {
        if (
            changes["modLevelCPdata"] &&
            changes["modLevelCPdata"] !== null &&
            changes["modLevelCPdata"].currentValue
        ) {
            this.modLevelCPdata = changes["modLevelCPdata"].currentValue;
            this.moduleLevelGridData = [];
            this.tempModuleLevelGridData = [];
            this.moduleLevelGridData3 = JSON.parse(
                JSON.stringify(this.modLevelCPdata)
            );
            this.moduleLevelGridData = JSON.parse(
                JSON.stringify(this.modLevelCPdata)
            );
            this.tempModuleLevelGridData = [...this.moduleLevelGridData];
            this.moduleLevelGridData2 = JSON.parse(
                JSON.stringify(this.moduleLevelGridData)
            );
            this.gridFilteredData = JSON.parse(
                JSON.stringify(this.modLevelCPdata)
            );
            this.loadTable = false;

            let data1: any = distinct(
                this.moduleLevelGridData,
                "ProductType"
            ).map((item) => item["ProductType"]);
            data1 = data1.flatMap((f) => (f ? [f] : []));
            data1.sort(function (a, b) {
                const textA = a?.toUpperCase();
                const textB = b?.toUpperCase();
                return textA < textB ? -1 : textA > textB ? 1 : 0;
            });
            this.productTypeData = [...data1];
            this.tempProductTypeData = [...this.productTypeData];

            let data2: any = distinct(
                this.moduleLevelGridData,
                "BuildType"
            ).map((item) => item["BuildType"]);
            data2 = data2.flatMap((f) => (f ? [f] : []));
            data2.sort(function (a, b) {
                const textA = a?.toUpperCase();
                const textB = b?.toUpperCase();
                return textA < textB ? -1 : textA > textB ? 1 : 0;
            });
            this.buildTypeData = [...data2];
            this.tempBuildTypeData = [...this.buildTypeData];

            let data3: any = distinct(this.moduleLevelGridData, "ToolType").map(
                (item) => item["ToolType"]
            );
            data3 = data3.flatMap((f) => (f ? [f] : []));
            data3.sort(function (a, b) {
                const textA = a?.toUpperCase();
                const textB = b?.toUpperCase();
                return textA < textB ? -1 : textA > textB ? 1 : 0;
            });
            this.toolTypeData = [...data3];
            this.tempToolTypeData = [...this.toolTypeData];

            let data4: any = distinct(
                this.moduleLevelGridData,
                "CustomerID"
            ).map((item) => item["CustomerID"]);
            data4 = data4.flatMap((f) => (f ? [f] : []));
            data4.sort(function (a, b) {
                const textA = a?.toUpperCase();
                const textB = b?.toUpperCase();
                return textA < textB ? -1 : textA > textB ? 1 : 0;
            });
            this.customerData = [...data4];
            this.tempCustomerData = [...this.customerData];

            this.setSelectableSettings();
            this.extract2();
            this.setSelectableSettings2();

            let data5: any = distinct(this.moduleLevelGridData, "onPOR").map(
                (item) => item["onPOR"]
            );
            data5 = data5.flatMap((f) => (f ? [f] : []));
            data5.sort(function (a, b) {
                const textA = a?.toUpperCase();
                const textB = b?.toUpperCase();
                return textA < textB ? -1 : textA > textB ? 1 : 0;
            });
            this.onPORData = [...data5];
            this.tempOnPORData = [...this.onPORData];

            this.statusDataItem = ["New", "Changed", "Dropped", "Null"];
            this.onSearchFilter();

            this.setSelectableSettings();
            this.extract2();
            this.setSelectableSettings2();
        }

        if (
            changes["savePORChanges"] &&
            changes["savePORChanges"] !== null &&
            changes["savePORChanges"].currentValue
        ) {
            this.savePORChanges = changes["savePORChanges"].currentValue;
            if (this.savePORChanges) {
                this.saveChanges();
            }
        }
        if (
            changes["cancelPORChanges"] &&
            changes["cancelPORChanges"] !== null &&
            changes["cancelPORChanges"].currentValue
        ) {
            this.cancelPORChanges = changes["cancelPORChanges"].currentValue;
            if (this.cancelPORChanges) {
                this.cancelChanges();
            }
        }
        if (
            changes["editableByUser"] &&
            changes["editableByUser"] !== null &&
            changes["editableByUser"].currentValue
        ) {
            this.editableByUser = changes["editableByUser"].currentValue;
        }
    }

    ngDoCheck() {
        this.editableByUser =
            this.planTypeValue?.text?.toUpperCase().trim() === "POR"
                ? this.editModeOn
                : this.editableByUser;
    }

    public setSelectableSettings(): void {
        if (this.checkboxOnly || this.mode === "single") {
            this.drag = false;
        }

        this.selectableSettings = {
            checkboxOnly: this.checkboxOnly,
            mode: "single",
            drag: this.drag,
        };
    }

    keyChange2(e) {
        this.extract2();
    }
    public extract2() {
        this.extractDataItems2 = this.mySelection2.map((idx) => {
            return this.moduleLevelGridData.find(
                (item) => item.Priority === idx
            );
        });
        if (this.extractDataItems2?.length == 1) {
            this.enableArrowButtons = true;
        } else {
            this.enableArrowButtons = false;
        }
    }
    onUpArrowClick() {
        this.extractDataItems3 = this.mySelection2.map((idx) => {
            return this.moduleLevelGridData.find(
                (item) => item.Priority === idx
            );
        });
        for (let i = 0; i < this.moduleLevelGridData.length; i++) {
            if (
                this.moduleLevelGridData[i].Priority ==
                this.extractDataItems3[0]?.Priority
            ) {
                if (i - 1 >= 0) {
                    const data = [...this.moduleLevelGridData];
                    this.moduleLevelGridData = data.splice(
                        i - 1,
                        0,
                        data.splice(i, 1)[0]
                    );
                    this.moduleLevelGridData = [...data];
                }
            }
        }
    }
    onDownArrowClick() {
        this.extractDataItems3 = this.mySelection2.map((idx) => {
            return this.moduleLevelGridData.find(
                (item) => item.Priority === idx
            );
        });
        for (let i = 0; i < this.moduleLevelGridData.length; i++) {
            if (
                this.moduleLevelGridData[i].Priority ==
                this.extractDataItems3[0]?.Priority
            ) {
                if (this.moduleLevelGridData[i + 1]?.AlreadyScheduled != true) {
                    const data = [...this.moduleLevelGridData];
                    this.moduleLevelGridData = data.splice(
                        i + 1,
                        0,
                        data.splice(i, 1)[0]
                    );
                    this.moduleLevelGridData = [...data];
                    break;
                }
            }
        }
    }
    //Addmodulelevelgrid
    public setSelectableSettings2(): void {
        if (this.checkboxOnly || this.mode === "single") {
            this.drag = false;
        }

        this.selectableSettings2 = {
            checkboxOnly: this.checkboxOnly,
            mode: "multiple",
            drag: this.drag,
        };
    }

    keyChange3(e) {
        this.extract3();
    }
    public extract3() {
        this.extractDataItems4 = this.mySelection3.map((idx) => {
            return this.addModuleLevelGridData.find(
                (item) => item.pilotProductID === idx
            );
        });
    }

    public cellClickHandlerForBuild({
        sender,
        rowIndex,
        columnIndex,
        dataItem,
        isEdited,
    }) {
        if (this.editableByUser == false) return;
        if (!isEdited) {
            sender.editCell(
                rowIndex,
                columnIndex,
                this.createFormGroupForBuild(dataItem)
            );
        }
    }
    public cellCloseHandlerForBuild(args: any) {
        const { formGroup, dataItem } = args;

        if (formGroup.dirty) {
            this.editService.assignValues(dataItem, formGroup.value);
            this.editService.update(dataItem, "");
        } else {
            this.editService.update(dataItem, "");
        }
        this.noCapacityCheckedChanged(dataItem);
        this.gridDataHasChanged.emit(this.editService.hasChanges());
    }
    public cancelHandlerForBuild({ sender, rowIndex }) {
        sender.closeRow(rowIndex);
    }
    public saveHandlerForBuild({ sender, formGroup, rowIndex }) {
        if (formGroup.valid) {
            this.editService.create(formGroup.value);
            sender.closeRow(rowIndex);
        }
    }
    public createFormGroupForBuild(dataItem: any): FormGroup {
        return this.formBuilder.group({
            Priority: dataItem.Priority,
            SalesPriority: dataItem.SalesPriority,
            FCID: dataItem.FCID,
            PilotSerialNumber: dataItem.PilotSerialNumber,
            PriorityDate: dataItem.PriorityDate,
            PilotRisk: dataItem.PilotRisk,
            DayShiftOnly: dataItem.DayShiftOnly,
            NoCapacity: dataItem.NoCapacity,
            RecordType: dataItem.RecordType,
            RevenueType: dataItem.RevenueType,
            ToolType: dataItem.ToolType,
            ProductType: dataItem.ProductType,
            BuildType: dataItem.BuildType,
            CustomerID: dataItem.CustomerID,
            CompleteATP: dataItem.CompleteATP,

            SubAssyBaysNeeded: [
                dataItem.SubAssyBaysNeeded,
                Validators.pattern("^[0-9]{1,3}"),
            ],
            SubAssyHrs: [
                dataItem.SubAssyHrs,
                Validators.pattern("^[0-9]{1,4}"),
            ],
            SubAssyTechs: [
                dataItem.SubAssyTechs,
                Validators.pattern("^[0-9]{1,3}"),
            ],

            IntBaysNeeded: [
                dataItem.IntBaysNeeded,
                Validators.pattern("^[0-9]{1,3}"),
            ],
            IntHrs: [dataItem.IntHrs, Validators.pattern("^[0-9]{1,4}")],
            IntTechs: [dataItem.IntTechs, Validators.pattern("^[0-9]{1,3}")],

            TestBaysNeeded: [
                dataItem.TestBaysNeeded,
                Validators.pattern("^[0-9]{1,3}"),
            ],
            TestHrs: [dataItem.TestHrs, Validators.pattern("^[0-9]{1,4}")],
            TestTechs: [dataItem.TestTechs, Validators.pattern("^[0-9]{1,3}")],

            PostTestBaysNeeded: [
                dataItem.PostTestBaysNeeded,
                Validators.pattern("^[0-9]{1,3}"),
            ],
            PostTestHrs: [
                dataItem.PostTestHrs,
                Validators.pattern("^[0-9]{1,4}"),
            ],
            PostTestTechs: [
                dataItem.PostTestTechs,
                Validators.pattern("^[0-9]{1,3}"),
            ],

            TestHours: dataItem.TestHours,

            EarliestAllowedLaunchDate: dataItem.EarliestAllowedLaunchDate,
            MaterialReadiness: dataItem.MaterialReadiness,
            BOM: dataItem.BOM,
            TranisitionDate: dataItem.TranisitionDate,
            Launch: dataItem.Launch,
            Integration: dataItem.Integration,
            TestStart: dataItem.TestStart,
            MfgComplete: dataItem.MfgComplete,

            TSD: dataItem.TSD,
            CRD: dataItem.CRD,
            CRDGap: dataItem.CRDGap,
            CRDEsc: dataItem.CRDEsc,
            SRD: dataItem.SRD,
            Notes: dataItem.Notes,
            PlanOfRecord: dataItem.PlanOfRecord,
            PilotMCSD: dataItem.PilotMCSD,
        });
    }

    public saveChanges(): void {
        this.errMsg = "";
        this.showErrMsg = false;
        this.loadTable = true;

        const abc = this.editService.getSavedData();
        abc[0].forEach((val) => {
            if (val.SubAssyBaysNeeded > 0) {
                if (val.SubAssyHrs == 0 || val.SubAssyTechs == 0) {
                    this.warningMsg =
                        "SubAssembly Bays greater than 0, SubAssembly Hours or SubAssembly Techs cannot be 0";
                    this.showWarningMsg = true;
                    return;
                } else {
                    this.warningMsg = "";
                    this.showWarningMsg = false;
                }
            }
            if (val.SubAssyHrs > 0) {
                if (val.SubAssyBaysNeeded == 0 || val.SubAssyTechs == 0) {
                    this.warningMsg =
                        "SubAssembly Hours greater than 0, SubAssembly Bays or SubAssembly Techs cannot be 0";
                    this.showWarningMsg = true;
                    return;
                } else {
                    this.warningMsg = "";
                    this.showWarningMsg = false;
                }
            }
            if (val.SubAssyTechs > 0) {
                if (val.SubAssyBaysNeeded == 0 || val.SubAssyHrs == 0) {
                    this.warningMsg =
                        "SubAssembly Techs greater than 0, SubAssembly Bays or SubAssembly Hours cannot be 0";
                    this.showWarningMsg = true;
                    return;
                } else {
                    this.warningMsg = "";
                    this.showWarningMsg = false;
                }
            }

            if (val.IntBaysNeeded > 0) {
                if (val.IntHrs == 0 || val.IntTechs == 0) {
                    this.warningMsg =
                        "Integration Bays greater than 0, Integration Hours or Integration Techs cannot be 0";
                    this.showWarningMsg = true;
                    return;
                } else {
                    this.warningMsg = "";
                    this.showWarningMsg = false;
                }
            }
            if (val.IntHrs > 0) {
                if (val.IntBaysNeeded == 0 || val.IntTechs == 0) {
                    this.warningMsg =
                        "Integration Hours greater than 0, Integration Bays or Integration Techs cannot be 0";
                    this.showWarningMsg = true;
                    return;
                } else {
                    this.warningMsg = "";
                    this.showWarningMsg = false;
                }
            }
            if (val.IntTechs > 0) {
                if (val.IntBaysNeeded == 0 || val.IntHrs == 0) {
                    this.warningMsg =
                        "Integration Techs greater than 0, Integration Bays or Integration Hours cannot be 0";
                    this.showWarningMsg = true;
                    return;
                } else {
                    this.warningMsg = "";
                    this.showWarningMsg = false;
                }
            }

            if (val.TestBaysNeeded > 0) {
                if (val.TestHrs == 0 || val.TestTechs == 0) {
                    this.warningMsg =
                        "Test Bays greater than 0, Test Hours or Test Techs cannot be 0";
                    this.showWarningMsg = true;
                    return;
                } else {
                    this.warningMsg = "";
                    this.showWarningMsg = false;
                }
            }
            if (val.TestHrs > 0) {
                if (val.TestBaysNeeded == 0 || val.TestTechs == 0) {
                    this.warningMsg =
                        "Test Hours greater than 0, Test Bays or Test Techs cannot be 0";
                    this.showWarningMsg = true;
                    return;
                } else {
                    this.warningMsg = "";
                    this.showWarningMsg = false;
                }
            }
            if (val.TestTechs > 0) {
                if (val.TestBaysNeeded == 0 || val.TestHrs == 0) {
                    this.warningMsg =
                        "Test Techs greater than 0, Test Bays or Test Hours cannot be 0";
                    this.showWarningMsg = true;
                    return;
                } else {
                    this.warningMsg = "";
                    this.showWarningMsg = false;
                }
            }

            if (val.PostTestBaysNeeded > 0) {
                if (val.PostTestHrs == 0 || val.PostTestTechs == 0) {
                    this.warningMsg =
                        "Post-test Bays greater than 0, Post-test Hours or Post-test Techs cannot be 0";
                    this.showWarningMsg = true;
                    return;
                } else {
                    this.warningMsg = "";
                    this.showWarningMsg = false;
                }
            }
            if (val.PostTestHrs > 0) {
                if (val.PostTestBaysNeeded == 0 || val.PostTestTechs == 0) {
                    this.warningMsg =
                        "Post-test Hours greater than 0, Post-test Bays or Post-test Techs cannot be 0";
                    this.showWarningMsg = true;
                    return;
                } else {
                    this.warningMsg = "";
                    this.showWarningMsg = false;
                }
            }
            if (val.PostTestTechs > 0) {
                if (val.PostTestBaysNeeded == 0 || val.PostTestHrs == 0) {
                    this.warningMsg =
                        "Post-test Techs greater than 0, Post-test Bays or Post-test Hours cannot be 0";
                    this.showWarningMsg = true;
                    return;
                } else {
                    this.warningMsg = "";
                    this.showWarningMsg = false;
                }
            }
        });

        if (!this.showWarningMsg) {
            this.updatedModule.emit(this.editService.saveChanges());
        }
        this.loadTable = false;
    }

    public cancelChanges(): void {
        this.moduleLevelGridData = [...[]];
        this.moduleLevelGridData = JSON.parse(
            JSON.stringify(this.moduleLevelGridData3)
        );
        this.tempModuleLevelGridData = [...this.moduleLevelGridData];
        this.changeDetector.detectChanges();

        this.editService.cancelChanges();
        this.gridDataHasChanged.emit(this.editService.hasChanges());
        this.warningMsg = "";
        this.showWarningMsg = false;
        this.cancelModuleChanges.emit(true);
    }
    loadItems() {
        if (!this.filterChecked) {
            this.productTypeData = this.distinctPrimitive("ProductType");
            this.buildTypeData = this.distinctPrimitive("BuildType");
            this.toolTypeData = this.distinctPrimitive("ToolType");
            this.customerData = this.distinctPrimitive("CustomerID");
        }
    }

    onItemClick(value, field) {
        this.filterChecked = true;
        this.onClearCheckbox(field);
        value.checked = true;
        this.onFilterData(value.text, field);
        this.setButtonColor(value, field);
    }
    setButtonColor(value, field) {
        switch (field) {
            case "ProductType":
                if (value.text === "None") {
                    this.isProductTypeChecked = false;
                } else {
                    this.isProductTypeChecked = true;
                }
                break;
            case "BuildType":
                if (value.text === "None") {
                    this.isBuildTypeChecked = false;
                } else {
                    this.isBuildTypeChecked = true;
                }
                break;
            case "ToolType":
                if (value.text === "None") {
                    this.isToolTypeChecked = false;
                } else {
                    this.isToolTypeChecked = true;
                }
                break;
            case "CustomerID":
                if (value.text === "None") {
                    this.isCustomerChecked = false;
                } else {
                    this.isCustomerChecked = true;
                }
                break;
            case "Division":
                if (value.text === "None") {
                    this.isDivisionChecked = false;
                } else {
                    this.isDivisionChecked = true;
                }
                break;
        }
    }
    onClearCheckbox(field) {
        switch (field) {
            case "ProductType":
                this.productTypeData.forEach((item) => (item.checked = false));
                break;
            case "BuildType":
                this.buildTypeData.forEach((item) => (item.checked = false));
                break;
            case "ToolType":
                this.toolTypeData.forEach((item) => (item.checked = false));
                break;
            case "CustomerID":
                this.customerData.forEach((item) => (item.checked = false));
                break;
            case "Division":
                this.divisionData.forEach((item) => (item.checked = false));
                break;
        }
    }
    public distinctPrimitive(fieldName: string): any {
        const distinctData: any[] = distinct(
            this.modLevelCPdata,
            fieldName
        ).map((item) => item[fieldName]);
        const data: any[] = [{ text: "None", checked: true }];
        distinctData.forEach((item) => {
            data.push({ text: item, checked: false });
        });
        return data;
    }
    public onFilterData(inputValue: string, field: string): void {
        if (inputValue === "None") {
            this.moduleLevelGridData = this.gridFilteredData;
            this.tempModuleLevelGridData = [...this.moduleLevelGridData];
        } else {
            this.moduleLevelGridData = process(this.gridFilteredData, {
                filter: {
                    logic: "and",
                    filters: [
                        {
                            field: field,
                            operator: "eq",
                            value: inputValue,
                        },
                    ],
                },
            }).data;
            this.dataBinding.skip = 0;
        }
    }

    public onSearchFilter(): void {
        const filter: CompositeFilterDescriptor = { filters: [], logic: "and" };
        if (this.searchText && this.searchText.length > 0) {
            const data1 = [
                {
                    field: "SalesPriority",
                    operator: "contains",
                    value: this.searchText,
                },
                {
                    field: "FCID",
                    operator: "contains",
                    value: this.searchText,
                },
                {
                    field: "PilotSerialNumber",
                    operator: "contains",
                    value: this.searchText,
                },
                {
                    field: "ToolType",
                    operator: "contains",
                    value: this.searchText,
                },
                {
                    field: "ProductType",
                    operator: "contains",
                    value: this.searchText,
                },
                {
                    field: "CustomerID",
                    operator: "contains",
                    value: this.searchText,
                },
                {
                    field: "Notes",
                    operator: "contains",
                    value: this.searchText,
                },
                {
                    field: "BEN",
                    operator: "contains",
                    value: this.searchText,
                },
            ];
            filter.filters.push({ filters: [...data1], logic: "or" });
        }
        if (this.productTypeDataItem && this.productTypeDataItem.length > 0) {
            const data2: any[] = [];
            this.productTypeDataItem.forEach((item) => {
                data2.push({
                    field: "ProductType",
                    operator: "eq",
                    value: item,
                });
            });
            filter.filters.push({ filters: [...data2], logic: "or" });
        }
        if (this.buildTypeDataItem && this.buildTypeDataItem.length > 0) {
            const data3: any[] = [];
            this.buildTypeDataItem.forEach((item) => {
                data3.push({
                    field: "BuildType",
                    operator: "eq",
                    value: item,
                });
            });
            filter.filters.push({ filters: [...data3], logic: "or" });
        }
        if (this.toolTypeDataItem && this.toolTypeDataItem.length > 0) {
            const data4: any[] = [];
            this.toolTypeDataItem.forEach((item) => {
                data4.push({
                    field: "ToolType",
                    operator: "eq",
                    value: item,
                });
            });
            filter.filters.push({ filters: [...data4], logic: "or" });
        }
        if (this.customerDataItem && this.customerDataItem.length > 0) {
            const data5: any[] = [];
            this.toolTypeDataItem.forEach((item) => {
                data5.push({
                    field: "Customer",
                    operator: "eq",
                    value: item,
                });
            });
            filter.filters.push({ filters: [...data5], logic: "or" });
        }
        if (this.onPORDataItem && this.onPORDataItem.length > 0) {
            const data6: any[] = [];
            this.onPORDataItem.forEach((item) => {
                data6.push({
                    field: "onPOR",
                    operator: "eq",
                    value: item,
                });
            });
            filter.filters.push({ filters: [...data6], logic: "or" });
        }
        if (this.statusDataItem && this.statusDataItem.length > 0) {
            const data7: any[] = [];
            this.statusDataItem.forEach((item) => {
                if (item === "Null") {
                    data7.push({
                        field: "ScheduleStatus",
                        operator: "eq",
                        value: null,
                    });
                } else {
                    data7.push({
                        field: "ScheduleStatus",
                        operator: "eq",
                        value: item,
                    });
                }
            });
            filter.filters.push({ filters: [...data7], logic: "or" });
        }
        this.moduleLevelGridData = filterBy(
            this.tempModuleLevelGridData,
            filter
        );
        if (this.binding) Array.from(this.binding)[0].skip = 0;
    }
    public getValue(event: Event): string {
        return (event.target as HTMLInputElement).value;
    }

    showWarning(dataItem) {
        let subAssyWarn = false;
        let inteWarn = false;
        let testWarn = false;
        let postTestWarn = false;

        if (
            (dataItem.SubAssyBaysNeeded == 0 ||
                dataItem.SubAssyHrs == 0 ||
                dataItem.SubAssyTechs == 0) &&
            !(
                dataItem.SubAssyBaysNeeded == 0 &&
                dataItem.SubAssyHrs == 0 &&
                dataItem.SubAssyTechs == 0
            )
        ) {
            subAssyWarn = true;
        }
        if (
            (dataItem.IntBaysNeeded == 0 ||
                dataItem.IntHrs == 0 ||
                dataItem.IntTechs == 0) &&
            !(
                dataItem.IntBaysNeeded == 0 &&
                dataItem.IntHrs == 0 &&
                dataItem.IntTechs == 0
            )
        ) {
            inteWarn = true;
        }
        if (
            (dataItem.TestBaysNeeded == 0 ||
                dataItem.TestHrs == 0 ||
                dataItem.TestTechs == 0) &&
            !(
                dataItem.TestBaysNeeded == 0 &&
                dataItem.TestHrs == 0 &&
                dataItem.TestTechs == 0
            )
        ) {
            testWarn = true;
        }
        if (
            (dataItem.PostTestBaysNeeded == 0 ||
                dataItem.PostTestHrs == 0 ||
                dataItem.PostTestTechs == 0) &&
            !(
                dataItem.PostTestBaysNeeded == 0 &&
                dataItem.PostTestHrs == 0 &&
                dataItem.PostTestTechs == 0
            )
        ) {
            postTestWarn = true;
        }

        if (
            ((dataItem.PostTestBaysNeeded == 0 &&
                dataItem.PostTestHrs == 0 &&
                dataItem.PostTestTechs == 0 &&
                dataItem.TestBaysNeeded == 0 &&
                dataItem.TestHrs == 0 &&
                dataItem.TestTechs == 0 &&
                dataItem.IntBaysNeeded == 0 &&
                dataItem.IntHrs == 0 &&
                dataItem.IntTechs == 0 &&
                dataItem.SubAssyBaysNeeded == 0 &&
                dataItem.SubAssyHrs == 0 &&
                dataItem.SubAssyTechs == 0) ||
                subAssyWarn ||
                inteWarn ||
                testWarn ||
                postTestWarn) &&
            dataItem.NoCapacity == false
        ) {
            dataItem.Warning = true;
            return true;
        }

        if (dataItem.PriorityDate === "CRD") {
            if (
                (dataItem.CRD == null || new Date(dataItem.CRD) < new Date()) &&
                !dataItem?.AlreadyScheduled
            ) {
                dataItem.Warning = true;
                return true;
            } else {
                dataItem.Warning = false;
                return false;
            }
        } else if (dataItem.PriorityDate === "MCSD") {
            if (
                (dataItem.PilotMCSD == null ||
                    new Date(dataItem.PilotMCSD) < new Date()) &&
                !dataItem?.AlreadyScheduled
            ) {
                dataItem.Warning = true;
                return true;
            } else {
                dataItem.Warning = false;
                return false;
            }
        } else if (dataItem.PriorityDate === "TSD") {
            if (
                (dataItem.TSD == null || new Date(dataItem.TSD) < new Date()) &&
                !dataItem?.AlreadyScheduled
            ) {
                dataItem.Warning = true;
                return true;
            } else {
                dataItem.Warning = false;
                return false;
            }
        } else if (dataItem.PriorityDate === "SRD") {
            if (
                (dataItem.SRD == null || new Date(dataItem.SRD) < new Date()) &&
                !dataItem?.AlreadyScheduled
            ) {
                dataItem.Warning = true;
                return true;
            } else {
                dataItem.Warning = false;
                return false;
            }
        } else if (dataItem.PriorityDate === "POR") {
            if (
                (dataItem.PlanOfRecord == null ||
                    new Date(dataItem.PlanOfRecord) < new Date()) &&
                !dataItem?.AlreadyScheduled
            ) {
                dataItem.Warning = true;
                return true;
            } else {
                dataItem.Warning = false;
                return false;
            }
        } else if (dataItem.PriorityDate === "Launch") {
            if (
                (dataItem.Launch == null ||
                    new Date(dataItem.Launch) < new Date()) &&
                !dataItem?.AlreadyScheduled
            ) {
                dataItem.Warning = true;
                return true;
            } else {
                dataItem.Warning = false;
                return false;
            }
        } else if (dataItem.PriorityDate == null) {
            if (
                dataItem.CRD == null &&
                dataItem.PilotMCSD == null &&
                dataItem.TSD == null &&
                dataItem.SRD == null &&
                dataItem.PlanOfRecord == null &&
                dataItem.Launch == null
            ) {
                dataItem.Warning = true;
                return true;
            }
        }
        dataItem.Warning = true;
        return true;
    }
    noCapacityCheckedChanged(data) {
        if (data.NoCapacity == true) {
            data.DisabledNoCapacity = true;
        }
    }
    getNoCapacityBackgroundColor(data) {
        if (data.NoCapacity == true || data?.AlreadyScheduled == true) {
            return "noCapacityClass";
        } else {
            return "capacityClass";
        }
    }
    showDataNoCapacity(data, col) {
        if (data.NoCapacity == true) {
            data.SubAssyBaysNeeded = 0;
            data.SubAssyHrs = 0;
            data.SubAssyTechs = 0;

            data.IntBaysNeeded = 0;
            data.IntHrs = 0;
            data.IntTechs = 0;

            data.TestBaysNeeded = 0;
            data.TestHrs = 0;
            data.TestTechs = 0;

            data.PostTestBaysNeeded = 0;
            data.PostTestHrs = 0;
            data.PostTestTechs = 0;

            data.TotalLaborHrs = 0;
            return 0;
        } else {
            if (col == "SubAssyBaysNeeded") return data.SubAssyBaysNeeded;
            else if (col == "SubAssyHrs") return data.SubAssyHrs;
            else if (col == "SubAssyTechs") return data.SubAssyTechs;
            else if (col == "IntBaysNeeded") return data.IntBaysNeeded;
            else if (col == "IntHrs") return data.IntHrs;
            else if (col == "IntTechs") return data.IntTechs;
            else if (col == "TestBaysNeeded") return data.TestBaysNeeded;
            else if (col == "TestHrs") return data.TestHrs;
            else if (col == "TestTechs") return data.TestTechs;
            else if (col == "PostTestBaysNeeded")
                return data.PostTestBaysNeeded;
            else if (col == "PostTestHrs") return data.PostTestHrs;
            else if (col == "PostTestTechs") return data.PostTestTechs;
        }
    }

    onChangeEarliestAllowedLaunchDate(value: Date, dataItem: any) {
        dataItem.EarliestAllowedLaunchDate = moment(value).format("M-D-YY");
        if (
            parseInt(dataItem.EarliestAllowedLaunchDate.split("-")[2]) > 99 ||
            parseInt(dataItem.EarliestAllowedLaunchDate.split("-")[2]) < 0
        ) {
            dataItem.EarliestAllowedLaunchDate = null;
        }
        this.createFormGroupForBuild(dataItem);
    }
    onChangeMaterialReadiness(value: Date, dataItem: any) {
        dataItem.MaterialReadiness = moment(value).format("M-D-YY");
        if (
            parseInt(dataItem.MaterialReadiness.split("-")[2]) > 99 ||
            parseInt(dataItem.MaterialReadiness.split("-")[2]) < 0
        ) {
            dataItem.MaterialReadiness = null;
        }
        this.createFormGroupForBuild(dataItem);
    }
    onChangeBOM(value: Date, dataItem: any) {
        dataItem.BOM = moment(value).format("M-D-YY");
        if (
            parseInt(dataItem.BOM.split("-")[2]) > 99 ||
            parseInt(dataItem.BOM.split("-")[2]) < 0
        ) {
            dataItem.BOM = null;
        }
        this.createFormGroupForBuild(dataItem);
    }
    onChangeTranisitionDate(value: Date, dataItem: any) {
        dataItem.TranisitionDate = moment(value).format("M-D-YY");
        if (
            parseInt(dataItem.TranisitionDate.split("-")[2]) > 99 ||
            parseInt(dataItem.TranisitionDate.split("-")[2]) < 0
        ) {
            dataItem.TranisitionDate = null;
        }
        this.createFormGroupForBuild(dataItem);
    }
    onChangeLaunch(value: Date, dataItem: any) {
        this.errMsg = "";
        this.showErrMsg = false;

        if (value < new Date()) {
            this.errMsg =
                "Please enter a Committed Launch date greater than current date!";
            this.showErrMsg = true;
        } else if (dataItem.commitLaunch != null) {
            if (
                parseInt(dataItem.Launch.split("-")[2]) > 99 ||
                parseInt(dataItem.Launch.split("-")[2]) < 0
            ) {
                this.errMsg = "Please enter a valid Committed Launch date!";
                this.showErrMsg = true;
            } else {
                dataItem.Launch = moment(value).format("M-D-YY");
                this.createFormGroupForBuild(dataItem);
            }
        } else {
            dataItem.Launch = moment(value).format("M-D-YY");
            this.createFormGroupForBuild(dataItem);
        }
    }
    onChangeIntegration(value: Date, dataItem: any) {
        dataItem.Integration = moment(value).format("M-D-YY");
        if (
            parseInt(dataItem.Integration.split("-")[2]) > 99 ||
            parseInt(dataItem.Integration.split("-")[2]) < 0
        ) {
            dataItem.Integration = null;
        }
        this.createFormGroupForBuild(dataItem);
    }
    onChangeTestStart(value: Date, dataItem: any) {
        dataItem.TestStart = moment(value).format("M-D-YY");
        if (
            parseInt(dataItem.TestStart.split("-")[2]) > 99 ||
            parseInt(dataItem.TestStart.split("-")[2]) < 0
        ) {
            dataItem.TestStart = null;
        }
        this.createFormGroupForBuild(dataItem);
    }
    onChangeMfgComplete(value: Date, dataItem: any) {
        dataItem.MfgComplete = moment(value).format("M-D-YY");
        if (
            parseInt(dataItem.MfgComplete.split("-")[2]) > 99 ||
            parseInt(dataItem.MfgComplete.split("-")[2]) < 0
        ) {
            dataItem.MfgComplete = null;
        }
        this.createFormGroupForBuild(dataItem);
    }
    onChangePilotMCSD(value: Date, dataItem: any) {
        this.errMsg = "";
        this.showErrMsg = false;

        if (value < new Date()) {
            this.errMsg =
                "Please enter a Pilot MCSD date greater than current date!";
            this.showErrMsg = true;
        } else if (dataItem.PilotMCSD != null) {
            if (
                parseInt(dataItem.PilotMCSD.split("-")[2]) > 99 ||
                parseInt(dataItem.PilotMCSD.split("-")[2]) < 0
            ) {
                this.errMsg = "Please enter a valid Pilot MCSD date!";
                this.showErrMsg = true;
            } else {
                dataItem.PilotMCSD = moment(value).format("M-D-YY");
                this.createFormGroupForBuild(dataItem);
            }
        } else {
            dataItem.PilotMCSD = moment(value).format("M-D-YY");
            this.createFormGroupForBuild(dataItem);
        }
    }
    onChangeCRD(value: Date, dataItem: any) {
        this.errMsg = "";
        this.showErrMsg = false;

        if (value < new Date()) {
            this.errMsg = "Please enter a CRD date greater than current date!";
            this.showErrMsg = true;
        } else if (dataItem.CRD != null) {
            if (
                parseInt(dataItem.CRD.split("-")[2]) > 99 ||
                parseInt(dataItem.CRD.split("-")[2]) < 0
            ) {
                this.errMsg = "Please enter a valid CRD date!";
                this.showErrMsg = true;
            } else {
                dataItem.CRD = moment(value).format("M-D-YY");
                this.createFormGroupForBuild(dataItem);
            }
        } else {
            dataItem.CRD = moment(value).format("M-D-YY");
            this.createFormGroupForBuild(dataItem);
        }
    }
    onChangeTSD(value: Date, dataItem: any) {
        dataItem.TSD = moment(value).format("M-D-YY");
        if (
            parseInt(dataItem.TSD.split("-")[2]) > 99 ||
            parseInt(dataItem.TSD.split("-")[2]) < 0
        ) {
            dataItem.TSD = null;
        }
        this.createFormGroupForBuild(dataItem);
    }
    onChangeSAPMCSD(value: Date, dataItem: any) {
        dataItem.SapMCSD = moment(value).format("M-D-YY");
        if (
            parseInt(dataItem.SapMCSD.split("-")[2]) > 99 ||
            parseInt(dataItem.SapMCSD.split("-")[2]) < 0
        ) {
            dataItem.SapMCSD = null;
        }
        this.createFormGroupForBuild(dataItem);
    }
    onChangeSRD(value: Date, dataItem: any) {
        dataItem.SRD = moment(value).format("M-D-YY");
        if (
            parseInt(dataItem.SRD.split("-")[2]) > 99 ||
            parseInt(dataItem.SRD.split("-")[2]) < 0
        ) {
            dataItem.SRD = null;
        }
        this.createFormGroupForBuild(dataItem);
    }
    onChangePOR(value: Date, dataItem: any) {
        this.errMsg = "";
        this.showErrMsg = false;

        if (value < new Date()) {
            this.errMsg = "Please enter a POR date greater than current date!";
            this.showErrMsg = true;
        } else if (dataItem.PlanOfRecord != null) {
            if (
                parseInt(dataItem.PlanOfRecord.split("-")[2]) > 99 ||
                parseInt(dataItem.PlanOfRecord.split("-")[2]) < 0
            ) {
                this.errMsg = "Please enter a valid POR date!";
                this.showErrMsg = true;
            } else {
                dataItem.PlanOfRecord = moment(value).format("M-D-YY");
                this.createFormGroupForBuild(dataItem);
            }
        } else {
            dataItem.PlanOfRecord = moment(value).format("M-D-YY");
            this.createFormGroupForBuild(dataItem);
        }
    }
    getValueFromText(arr: Array<Item>, key: any) {
        let val = -1;
        if (typeof key === "string") {
            for (var i = 0; i < arr.length; i++) {
                if (arr[i].text == key) {
                    val = arr[i].value;
                }
            }
        } else {
            for (var i = 0; i < arr.length; i++) {
                if (arr[i].text == key.text) {
                    val = arr[i].value;
                }
            }
        }
        return val;
    }
    getTextFromValue(arr: Array<Item>, key: any) {
        let val = "";
        if (typeof key === "number") {
            for (let i = 0; i < arr.length; i++) {
                if (arr[i].value == key) {
                    val = arr[i].text;
                }
            }
        }
        return val;
    }

    getPilotRiskLevelValue(data) {
        if (data != null) {
            this.PilotRiskLevelGridValue = {
                text: data,
                value: this.getValueFromText(this.PilotRiskLevelItems, data),
            };
        } else {
            this.PilotRiskLevelGridValue = { text: "", value: 0 };
        }
    }

    dataItemPilotRiskLevelSelectionChange(data, id, dataItem) {
        this.PilotRiskLevelGridValue = { text: data.text, value: data.value };
        dataItem.PilotRisk = data.text;
        this.editService.update(dataItem, "");
        this.gridDataHasChanged.emit(this.editService.hasChanges());
    }
    getPriorityDateValue(data) {
        if (data != null) {
            this.PriorityDateGridValue = {
                text: data,
                value: this.getValueFromText(this.PriorityDateItems, data),
            };
        } else {
            this.PriorityDateGridValue = { text: "", value: 0 };
        }
    }

    dataItemPriorityDateSelectionChange(data, id, dataItem) {
        this.PriorityDateGridValue = { text: data.text, value: data.value };
        dataItem.PriorityDate = data.text;
        this.editService.update(dataItem, "");
        this.gridDataHasChanged.emit(this.editService.hasChanges());
    }
    getBuildTypeValue(data) {
        if (data != null) {
            this.buildTypeGridValue = {
                text: this.getTextFromValue(this.buildTypeItems, data),
                value: data,
            };
        } else {
            this.buildTypeGridValue = { text: "", value: 0 };
        }
    }
    dataItembuildTypeSelectionChange(data, id, dataItem) {
        this.buildTypeGridValue = { text: data.text, value: data.value };
        dataItem.BuildTypeId = parseInt(data.value);
        this.editService.update(dataItem, "");
        this.gridDataHasChanged.emit(this.editService.hasChanges());
    }

    generateSchedule() {
        if (this.editService.hasChanges()) {
            this.isChanged = true;
        } else if (
            this.moduleLevelGridData.length == 0 ||
            this.checkUndscheduledModules() == 0
        ) {
            this.noModulesAvailableForScheduleOpened = true;
            if (parseInt(this.planID) > 0) {
                this.showNoModulesAvailableMsg =
                    "There are no modules added to be scheduled. Do you want to go to already existing schedule?";
            } else {
                this.showNoModulesAvailableMsg =
                    "There are no modules added to be scheduled. Please add a module first to continue.";
            }
        } else {
            this.countWarning = 0;
            this.moduleLevelGridData.forEach((val) => {
                if (val.Warning == true) {
                    this.countWarning = this.countWarning + 1;
                }
            });
            if (this.countWarning > 0) {
                this.missingPriorityDateOpened = true;
            } else {
                this.generateScheduleOpened = true;
            }
        }
    }
    checkUndscheduledModules() {
        let count = 0;
        this.moduleLevelGridData.forEach((val) => {
            if (
                val?.AlreadyScheduled == false ||
                val?.AlreadyScheduled == null
            ) {
                count += 1;
            }
        });
        return count;
    }
    onGenerateSchedule(isModLevel) {
        this.generateScheduleModLevel.emit(this.moduleLevelGridData);
        this.generateScheduleOpened = false;
    }
    onCancelGenerateSchedule() {
        this.generateScheduleOpened = false;
    }

    onProceedClick() {
        this.missingPriorityDateOpened = false;
        this.generateScheduleOpened = true;
    }
    onCancelProceedClick() {
        this.missingPriorityDateOpened = false;
    }

    getSalesPriorityValue(data) {
        if (data != null) {
            this.SalesPriorityGridValue = {
                text: data,
                value: this.getValueFromText(this.SalesPriorityItems, data),
            };
        } else {
            this.SalesPriorityGridValue = { text: "", value: 0 };
        }
    }
    dataItemSalesPrioritySelectionChange(data, id, dataItem) {
        this.SalesPriorityGridValue = { text: data.text, value: data.value };
        dataItem.SalesPriority = data.text;
        this.editService.update(dataItem, "");
        this.gridDataHasChanged.emit(this.editService.hasChanges());
    }

    getToolTypeValue(data) {
        if (data != null) {
            this.ToolTypeGridValue = {
                text: data,
                value: this.getValueFromText(this.ToolTypeItems, data),
            };
        } else {
            this.ToolTypeGridValue = { text: "", value: 0 };
        }
    }
    dataItemToolTypeSelectionChange(data, id, dataItem) {
        this.ToolTypeGridValue = { text: data.text, value: data.value };
        dataItem.ToolType = data.text;
        dataItem.ToolTypeID = data.value;
        this.editService.update(dataItem, "");
        this.gridDataHasChanged.emit(this.editService.hasChanges());
    }
    onQuickView1() {
        this.searchText = "";
        this.productTypeDataItem = [];
        this.buildTypeDataItem = [];
        this.toolTypeDataItem = [];
        this.customerDataItem = [];
        this.moduleLevelGridData = [...this.moduleLevelGridData2];
        this.tempModuleLevelGridData = [...this.moduleLevelGridData];
        this.QV1 = true;
        this.QV2 = false;
        this.QV3 = false;
        this.QVDefault = false;
    }
    onQuickView2() {
        this.searchText = "";
        this.productTypeDataItem = [];
        this.buildTypeDataItem = [];
        this.toolTypeDataItem = [];
        this.customerDataItem = [];
        this.moduleLevelGridData = [...this.moduleLevelGridData2];
        this.tempModuleLevelGridData = [...this.moduleLevelGridData];
        this.QV1 = false;
        this.QV2 = true;
        this.QV3 = false;
        this.QVDefault = false;
    }
    onQuickView3() {
        this.searchText = "";
        this.productTypeDataItem = [];
        this.buildTypeDataItem = [];
        this.toolTypeDataItem = [];
        this.customerDataItem = [];
        this.moduleLevelGridData = [...this.moduleLevelGridData2];
        this.tempModuleLevelGridData = [...this.moduleLevelGridData];
        this.QV1 = false;
        this.QV2 = false;
        this.QV3 = true;
        this.QVDefault = false;
    }
    onQuickViewPilot() {
        this.searchText = "";
        this.productTypeDataItem = [];
        this.buildTypeDataItem = [];
        this.toolTypeDataItem = [];
        this.customerDataItem = [];
        this.moduleLevelGridData = [...this.moduleLevelGridData2];
        this.moduleLevelGridData = this.moduleLevelGridData.filter(
            (x) => x.BuildType !== "H (HVM)" && x.BuildType !== "1H (First HVM)"
        );
        this.tempModuleLevelGridData = [...this.moduleLevelGridData];
    }
    onQuickViewSlotted() {
        this.searchText = "";
        this.productTypeDataItem = [];
        this.buildTypeDataItem = [];
        this.toolTypeDataItem = [];
        this.customerDataItem = [];
        this.moduleLevelGridData = [...this.moduleLevelGridData2];
        this.moduleLevelGridData = this.moduleLevelGridData.filter(
            (x) => x.RecordType === "Slotted"
        );
        this.tempModuleLevelGridData = [...this.moduleLevelGridData];
    }
    onQuickViewHVM() {
        this.searchText = "";
        this.productTypeDataItem = [];
        this.buildTypeDataItem = [];
        this.toolTypeDataItem = [];
        this.customerDataItem = [];
        this.moduleLevelGridData = [...this.moduleLevelGridData2];
        this.moduleLevelGridData = this.moduleLevelGridData.filter(
            (x) => x.BuildType === "H (HVM)" || x.BuildType === "1H (First HVM)"
        );
        this.tempModuleLevelGridData = [...this.moduleLevelGridData];
    }
    onQuickViewTransition() {
        this.searchText = "";
        this.productTypeDataItem = [];
        this.buildTypeDataItem = [];
        this.toolTypeDataItem = [];
        this.customerDataItem = [];
        this.moduleLevelGridData = [...this.moduleLevelGridData2];
        this.moduleLevelGridData = this.moduleLevelGridData.filter(
            (x) =>
                x.BuildType === "BQ (Build Qualify)" ||
                x.BuildType === "BV (Build Verify)" ||
                x.BuildType === "CB (Control Build)" ||
                x.BuildType === "FBQ (Fast Build Qualify)"
        );
        this.tempModuleLevelGridData = [...this.moduleLevelGridData];
    }
    onQuickViewSpecial() {}
    onQuickViewReset() {
        this.searchText = "";
        this.productTypeDataItem = [];
        this.buildTypeDataItem = [];
        this.toolTypeDataItem = [];
        this.customerDataItem = [];
        this.moduleLevelGridData = [...this.moduleLevelGridData2];
        this.QV1 = false;
        this.QV2 = false;
        this.QV3 = false;
        this.QVDefault = true;
        this.tempModuleLevelGridData = [...this.moduleLevelGridData];
    }

    canDeactivate(
        nextState: RouterStateSnapshot
    ): Observable<boolean> | Promise<boolean> | boolean {
        if (this.editService.hasChanges()) {
            this.isChanged = true;
            this.changeDetector.detectChanges();
            return false;
        } else {
            return true;
        }
    }

    closeEdit() {
        this.isChanged = false;
    }

    discardChanges() {
        this.moduleLevelGridData = [];
        this.moduleLevelGridData = JSON.parse(
            JSON.stringify(this.moduleLevelGridData3)
        );
        this.editService.cancelChanges();
        this.gridDataHasChanged.emit(this.editService.hasChanges());
        this.isChanged = false;
        this.changeDetector.detectChanges();
    }

    onSaveModLevel() {
        const updatedData: any[] = this.editService.saveChanges();
        this.updatedModule.emit(updatedData);
    }

    public showTooltip(e: MouseEvent): void {
        this.changeDetector.detectChanges();
        const element = e.target as HTMLElement;
        if (element.nodeName === "IMG") {
            this.tooltipMsg =
                "Selected Priority Date is missing or in the past / The Module's bays, hours and techs are all 0 for all module processes";
            this.tooltipDir.toggle(element);
        } else if (element.className == "k-icon k-i-x ng-star-inserted") {
            this.tooltipMsg = "Remove from plan";
            this.tooltipDir.toggle(element);
        } else {
            this.tooltipDir.hide();
        }
    }
    addOtherModulestoPlan() {
        this.addOtherModulestoPlanOpened = true;
        this.addModuleLevelGridData = [];
        this.loadSearch = true;
        this.changeDetector.detectChanges();
        //call search api
        this.createCPService
            .getModuleToAddProductionPlan(
                this.site?.plantId,
                parseInt(this.planID)
            )
            .subscribe((val) => {
                if (val && val.length > 0) {
                    this.addModuleLevelGridData = val;
                }
                this.loadSearch = false;
                this.tempAddModuleLevelGridData = JSON.parse(
                    JSON.stringify(this.addModuleLevelGridData)
                );
                this.changeDetector.detectChanges();
            });
    }
    onAddModuletoPlan() {
        this.addOtherModulestoPlanOpened = false;
        const addModLvlModules: any[] = [];
        if (this.extractDataItems4 && this.extractDataItems4.length > 0) {
            this.extractDataItems4.forEach((val) => {
                addModLvlModules.push(val.pilotProductID);
            });
        }
        this.addModuleModLevel.emit(addModLvlModules);
        this.addModuleLevelGridData = [];
        this.searchAddModLevelValue = "";
    }
    onCancelAddModuletoPlan() {
        this.addModuleLevelGridData = [];
        this.extractDataItems4 = [];
        this.mySelection3 = [];
        this.searchAddModLevelValue = "";
        this.addOtherModulestoPlanOpened = false;
    }
    onsearchAddModLevel() {
        this.addModuleLevelGridData = [];
        this.loadSearch = true;
        this.changeDetector.detectChanges();
        //call search api
        this.createCPService
            .getModuleSearch(
                this.searchAddModLevelValue,
                this.site?.plantId,
                parseInt(this.planID)
            )
            .subscribe((val) => {
                if (val) {
                    if (val && val.length > 0) {
                        this.addModuleLevelGridData = val;
                    }
                }
                this.loadSearch = false;
                this.mySelection3 = [];
                this.changeDetector.detectChanges();
                this.tempAddModuleLevelGridData = JSON.parse(
                    JSON.stringify(this.addModuleLevelGridData)
                );
            });
    }
    onRemoveModuleFromPlan() {
        this.openConfirmationPopup = false;
        this.removeModuleModLevel.emit(this.removeModule.Id);
    }
    onKeyDown(pressedKey) {
        if (pressedKey.key === "Enter") {
            this.onsearchAddModLevel();
        }
    }
    public rowCallback(context: RowClassArgs) {
        const dataset = context.dataItem;
        const AlreadySc = dataset["AlreadyScheduled"] || false;
        this.setEditable = dataset["AlreadyScheduled"] || false;

        const NoCapVal = dataset["NoCapacity"] || false;

        return {
            AlreadyScClass: AlreadySc,
            NoCapClass: NoCapVal,
        };
    }
    isAlreadySch(data) {
        this.setEditable = data;
    }

    onOkNoModulesAvailable() {
        this.noModulesAvailableForScheduleOpened = false;
        if (parseInt(this.planID) > 0) {
            if (this.planTypeValue["text"].toString() === "POR") {
                this.router.navigate(["/mps"]);
            } else {
                this.router.navigate([
                    "/schedule-generated/" + this.planID.toString(),
                ]);
            }
        }
    }
    onCancelNoModulesAvailable() {
        this.noModulesAvailableForScheduleOpened = false;
    }

    onRemoveClick(dataItem) {
        this.removeModule = dataItem;
        this.openConfirmationPopup = true;
    }
    showPilotPriority(dataItem, rowindex) {
        let pilotPriority = null;
        if (dataItem?.AlreadyScheduled == false) {
            pilotPriority = rowindex + 1;
        }
        return pilotPriority;
    }

    public distinctPrimitiveFilter(grid: string, fieldName: string): any {
        let data: any = [];
        if (grid == "moduleLevelGridData") {
            data = distinct(this.moduleLevelGridData3, fieldName)
                .map((item) => item[fieldName])
                .map((val) => ({ text: val, value: val }));
        } else if (grid == "addModuleLevelGridData") {
            data = distinct(this.tempAddModuleLevelGridData, fieldName)
                .map((item) => item[fieldName])
                .map((val) => ({ text: val, value: val }));
        }

        data.forEach((item) => {
            if (item.value === "") item.text = "BLANK";
            else if (item.value === null) {
                item.text = "NULL";
            }
        });
        data.sort(function (a, b) {
            const textA = a?.text.toUpperCase();
            const textB = b?.text.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
        });
        return data;
    }

    public filterChangeModLevelCP(filter: CompositeFilterDescriptor): void {
        this.filter = filter;
        this.moduleLevelGridData = filterBy(
            this.tempModuleLevelGridData,
            filter
        );
    }

    public filterChange(filter: CompositeFilterDescriptor): void {
        this.filter = filter;
        this.addModuleLevelGridData = filterBy(
            this.tempAddModuleLevelGridData,
            filter
        );
    }

    public dataStateChange(state: State) {}

    ngAfterViewInit() {
        window.addEventListener("scroll", this.scrollFixed);
    }

    ngOnDestroy() {
        window.removeEventListener("scroll", this.scrollFixed);
    }

    private scrollFixed() {
        const grid = <HTMLElement>(
            document.querySelector(".module-level-cp-grid")
        );
        const header = <HTMLElement>(
            grid.querySelector(".module-level-cp-grid .k-grid-header")
        );

        const offset = window.scrollY - (60 / 100) * window.scrollY;
        const tableOffsetTop = grid.offsetTop;
        const tableOffsetBottom =
            tableOffsetTop + grid.clientHeight - header.clientHeight;

        if (offset < tableOffsetTop || offset > tableOffsetBottom) {
            header.classList.remove("fixed-header");
        } else if (offset >= tableOffsetTop && offset <= tableOffsetBottom) {
            header.classList.add("fixed-header");
            header.style.width = grid.clientWidth + "px";
        }
    }
    handleProductFilter(value) {
        if (value.length >= 0) {
            this.productTypeData = this.tempProductTypeData.filter(
                (s) => s?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
            );
        } else {
            this.multiselect.toggle(false);
        }
    }
    handleBuildFilter(value) {
        if (value.length >= 0) {
            this.buildTypeData = this.tempBuildTypeData.filter(
                (s) => s?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
            );
        } else {
            this.multiselect.toggle(false);
        }
    }
    handleToolFilter(value) {
        if (value.length >= 0) {
            this.toolTypeData = this.tempToolTypeData.filter(
                (s) => s?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
            );
        } else {
            this.multiselect.toggle(false);
        }
    }
    handleCustomerFilter(value) {
        if (value.length >= 0) {
            this.customerData = this.tempCustomerData.filter(
                (s) => s?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
            );
        } else {
            this.multiselect.toggle(false);
        }
    }

    handleOnPORFilter(value) {
        if (value.length >= 0) {
            this.onPORData = this.tempOnPORData.filter(
                (s) => s?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
            );
        } else {
            this.multiselect.toggle(false);
        }
    }

    handleStatusFilter(value) {
        if (value.length >= 0) {
            this.statusData = this.tempStatusData.filter(
                (s) => s?.toLowerCase().indexOf(value?.toLowerCase()) !== -1
            );
        } else {
            this.multiselect.toggle(false);
        }
    }

    dataItemScheduleStatusChange(data, dataItem: any) {
        dataItem.ScheduleStatus = data.optionName;
        dataItem.ScheduleStatusId = data.scheduleStatusId;
        this.editService.update(dataItem, "");
        this.gridDataHasChanged.emit(this.editService.hasChanges());
    }
}
