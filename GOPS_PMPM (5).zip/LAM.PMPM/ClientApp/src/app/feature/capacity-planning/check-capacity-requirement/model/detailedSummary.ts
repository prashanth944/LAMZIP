export class DetailedSummary {
  description: string;
  detailedSummary: string[];
}
