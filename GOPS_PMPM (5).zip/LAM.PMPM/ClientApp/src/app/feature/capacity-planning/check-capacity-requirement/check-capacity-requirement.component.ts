import {
    ChangeDetectionStrategy,
    ChangeDetectorRef,
    Component,
    OnInit,
    ViewChild,
    ViewEncapsulation,
} from "@angular/core";
import { AppStoreService } from "../../../core/app-store.service";
import { Item } from "../../model/item";
import { CreateCPService } from "./create-capacity-plan/create-cp-service/createCP.service";
import { PlanGrid } from "./model/planGrid";
import { process } from "@progress/kendo-data-query";
import { Plant } from "../../../core/model/user.model";
import * as moment from "moment";
import { uiScreen } from "../../../core/model/common.constant";
import { Router } from "@angular/router";
import { renamePlan } from "./model/renamePlan";
import { duplicatePlan } from "./model/duplicatePlan";
import { EditService } from "../../service/edit.service";
import { environment } from "../../../../environments/environment.dev_server";
import { TooltipDirective } from "@progress/kendo-angular-tooltip";

@Component({
    selector: "pmpm-check-capacity",
    templateUrl: "./check-capacity-requirement.component.html",
    styleUrls: ["./check-capacity-requirement.component.css"],
    encapsulation: ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CheckCapacityRequirementComponent implements OnInit {
    @ViewChild(TooltipDirective)
    public tooltipDir: TooltipDirective;
    showCreateNewPlan = false;
    site: Plant;
    SitePlantName = "";

    planGridData: any[] = [];
    actionItems = ["Rename", "Duplicate", "Share", "Delete"];
    actionItems1 = ["Rename", "Duplicate", "Share"];
    actionItems2 = ["Duplicate", "Share"];

    createCPdata: any;
    public gridFilteredData: any[] = [];
    plantItems: Array<Item> = [];
    plantID = 0;
    isUserAccess = false;
    planID = 0;
    isLoading = true;
    deleteOpened = false;
    public deleteRowData: any;
    renameOpened = false;
    public renameRowData: any;
    planRenameValue = "";
    public isChanged = false;
    public userId: number;
    public userName: string;
    shareOpened = false;
    sharePlanValue = "";
    loadPlanTable = true;

    constructor(
        private createCPService: CreateCPService,
        private appStoreService: AppStoreService,
        private router: Router,
        private editService: EditService,
        private changeDetector: ChangeDetectorRef
    ) {}
    ngOnInit() {
        this.isLoading = true;
        this.loadPlanTable = true;
        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.CreateCP)
                    .subscribe((result) => {
                        this.isUserAccess = result;
                        this.isLoading = false;
                    });
            }
        });
        this.appStoreService.getCurrentSite().subscribe((site) => {
            this.loadPlanTable = true;
            if (site) {
                this.site = {
                    plantName: site.plantName,
                    plantId: site.plantId,
                };
                if (this.router.url.includes("/create-capacity-plan")) {
                    this.router.navigate(["/capacity/check-capacity"]);
                }
                this.appStoreService.getLoggedInUser().subscribe((user) => {
                    this.appStoreService
                        .getUserDetails(user.mail)
                        .subscribe((res) => {
                            this.userId = res?.userId;
                            this.userName =
                                res?.firstName + " " + res?.lastName;
                            this.fillProductionPlanGrid(this.site?.plantId);
                        });
                });
            }
        });

        this.SitePlantName = this.site?.plantName;
        this.createCPService.getPlant().subscribe((pt) => {
            pt.forEach((val) => {
                const newPT: Item = {
                    value: val.PlantId,
                    text: val.PlantName,
                };
                if (val.PlantName == this.site.plantName) {
                    this.plantID = val.PlantId;
                }
                this.plantItems.push(newPT);
            });
        });
    }

    fillProductionPlanGrid(plantId) {
        this.planGridData = [];
        this.loadPlanTable = true;
        this.createCPService.getProductionPlanData(plantId).subscribe((pp) => {
            pp.forEach((val) => {
                const newPt: PlanGrid = {
                    PlanId: val.productionPlanID,
                    PlanName: val.planName,
                    PlanType: val.planType,
                    DataRefreshDate: moment(val.dataRefreshDate)
                        .format("MM-DD-yyyy hh:mm A")
                        .toString(),
                    LastModified: moment(val.modifiedDate)
                        .format("MM-DD-yyyy hh:mm A")
                        .toString(),
                    Owner: val.userID,
                    Description: val.description,
                    PlantId: val.plantID,
                    CanEdit: val.userID == this.userName ? true : false,
                };
                this.planGridData.push(newPt);
            });

            //keep POR plan at the top
            const porPlan = this.planGridData.filter(
                (x) => x.PlanType.toUpperCase().trim() === "POR"
            )[0];
            this.planGridData.splice(
                this.planGridData
                    .map((x) => x.PlanType.toUpperCase().trim())
                    .indexOf("POR"),
                1
            );
            this.planGridData.unshift(porPlan);

            this.loadPlanTable = false;
            this.changeDetector.detectChanges();
        });
        this.gridFilteredData = this.planGridData;
    }

    onCreateNewPlan() {
        this.appStoreService.setPlanCreatedBy$(this.userName);
        this.appStoreService.setLaborHardConstraint$(true);
        this.appStoreService.setBayHardConstraint$(true);

        this.router.navigate(["/create-capacity-plan/" + "0" + "/0"]);
    }
    closeCreateCP() {
        this.router.navigate(["/capacity/check-capacity"]);
    }
    onOpenExistingPlanFromOther() {
        this.router.navigate(["/other-user-plans"]);
    }
    cellClickHandler(event) {
        if (event.column.field === "PlanName") {
            this.createCPdata = this.planGridData.filter(
                (x) => x.PlanId == event.dataItem.PlanId
            );
            this.planID = this.createCPdata[0].PlanId;
            this.appStoreService.setPlanCreatedBy$(this.createCPdata[0].Owner);
            this.router.navigate([
                "/create-capacity-plan/" + this.planID.toString() + "/0",
            ]);
        }
    }
    public onSearchFilter(inputValue: string): void {
        this.planGridData = process(this.gridFilteredData, {
            filter: {
                logic: "or",
                filters: [
                    {
                        field: "PlanName",
                        operator: "contains",
                        value: inputValue,
                    },
                    {
                        field: "Owner",
                        operator: "contains",
                        value: inputValue,
                    },
                ],
            },
        }).data;
    }
    public getValue(event: Event): string {
        return (event.target as HTMLInputElement).value;
    }

    actionItemSelectionChange(event, dataItem) {
        if (event == "Delete") {
            this.openDelete(dataItem);
        } else if (event == "Rename") {
            this.openRename(dataItem);
        } else if (event == "Duplicate") {
            this.duplicatePlan(dataItem);
        } else if (event == "Share") {
            this.openShare(dataItem);
        }
    }
    openDelete(data) {
        this.deleteOpened = true;
        this.deleteRowData = data;
    }
    closeDelete(status: string) {
        this.deleteOpened = false;
    }
    onSubmitDeletePlan() {
        // call delete api with this.deleteRowData.id
        this.loadPlanTable = true;
        this.createCPService
            .deleteProductionPlanData(this.deleteRowData["PlanId"])
            .subscribe((res) => {
                if (res) {
                    this.fillProductionPlanGrid(this.site?.plantId);
                }
            });
        this.deleteOpened = false;
    }

    openRename(data) {
        this.renameOpened = true;
        this.renameRowData = data;
        this.planRenameValue = data.PlanName;
    }
    closeRename(status: string) {
        this.renameOpened = false;
    }
    onSubmitRenamePlan() {
        const renamePlanObj: renamePlan = {
            PlanName: this.planRenameValue,
            ProductionPlanID: this.renameRowData["PlanId"],
        };
        this.createCPService
            .renameProductionPlan(renamePlanObj)
            .subscribe((res) => {
                if (res) {
                    this.fillProductionPlanGrid(this.site?.plantId);
                }
            });
        this.renameOpened = false;
    }
    duplicatePlan(dataItem) {
        const duplicatePlanObj: duplicatePlan = {
            PlantID: this.site?.plantId,
            ProductionPlanID: dataItem.PlanId,
            PlanName: dataItem.PlanName,
            PlanType: "What If",
            UserID: this.userName,
            DataRefreshDate: new Date(
                new Date().getTime() - new Date().getTimezoneOffset() * 60000
            ),
            ModifiedDate: new Date(
                new Date().getTime() - new Date().getTimezoneOffset() * 60000
            ),
            Description: dataItem.Description,
            ModifiedById: this.userId,
        };
        this.createCPService
            .duplicateProductionPlanData(duplicatePlanObj)
            .subscribe((res) => {
                if (res) {
                    this.fillProductionPlanGrid(this.site?.plantId);
                }
            });
    }
    onShowSchedule(planId) {
        const pd = this.planGridData.filter((x) => x.PlanId == planId);
        const pt = pd[0].PlanType;
        if (pt === "POR") {
            this.router.navigate(["/mps"]);
        } else {
            this.router.navigate(["/schedule-generated/" + planId.toString()]);
        }
    }
    onComparePlans() {
        this.router.navigate(["/compare-plans"]);
    }
    onShowPlan(planId) {
        this.createCPdata = this.planGridData.filter((x) => x.PlanId == planId);
        this.appStoreService.setPlanCreatedBy$(this.createCPdata[0].Owner);
        this.router.navigate([
            "/create-capacity-plan/" + planId.toString() + "/0",
        ]);
    }
    openShare(data) {
        this.shareOpened = true;
        this.sharePlanValue =
            environment.apiUrl.slice(0, -4) +
            "/schedule-generated/" +
            data.PlanId.toString();
    }
    closeShare(status: string) {
        this.shareOpened = false;
    }
    onCopySharePlan() {
        this.shareOpened = false;
    }
    copyInputMessage(inputElement) {
        inputElement.select();
        document.execCommand("copy");
        inputElement.setSelectionRange(0, 0);
    }
    public showTooltip(eventTarget: any): void {
        this.tooltipDir.toggle(eventTarget);
    }
}
