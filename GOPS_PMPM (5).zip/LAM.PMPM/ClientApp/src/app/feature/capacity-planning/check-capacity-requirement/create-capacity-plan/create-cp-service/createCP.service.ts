import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { environment } from "../../../../../../environments/environment.dev_server";
import { routes } from "../models/route";
import { AddModuleLevelGrid } from "../models/addModuleLevelGrid";

@Injectable({
    providedIn: "root",
})
export class CreateCPService {
    constructor(private http: HttpClient) {}

    // HttpClient API get() method => get bay summary

    getPlanType(): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(`${environment.apiUrl}${routes.getPlanType}`)
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    getSchedulePriority(plantId): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(
                    `${environment.apiUrl}${routes.getSchedulePriority}` +
                        "?plantId=" +
                        plantId
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    getRecordType(plantId): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(
                    `${environment.apiUrl}${routes.getRecordType}` +
                        "?plantId=" +
                        plantId
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    getRevenueType(plantId): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(
                    `${environment.apiUrl}${routes.getRevenueType}` +
                        "?plantId=" +
                        plantId
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    getPriorityDate(): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(`${environment.apiUrl}${routes.getPriorityDate}`)
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    getModuleLevelCP(plantName, planId): Observable<any[]> {
        const plant = "?PlantName=" + plantName;
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(
                    `${environment.apiUrl}${routes.getModuleLevelCP}${plant}` +
                        "&ProductionPlanId=" +
                        planId
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    getModuleLevelCP2(plantName, planId, createCPObj): Observable<any> {
        const plant = "?PlantName=" + plantName;
        return new Observable<any>((observer) => {
            this.http
                .post<any>(
                    `${environment.apiUrl}${routes.getModuleLevelCP}`,
                    createCPObj
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    addModuleProductionPlan(addModulePP): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .post<any>(
                    `${environment.apiUrl}${routes.addModuleProductionPlan}`,
                    addModulePP
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    getPlant(): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(`${environment.apiUrl}${routes.getPlant}`)
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    //CREATE CP on click of generate schedule button
    async getGeneratedSchedule(createCPObj): Promise<any> {
        return await this.http
            .post<any>(
                `${environment.apiUrl}${routes.getGeneratedSchedule}`,
                createCPObj
            )
            .toPromise();
    }

    updateModuleLevelCP(updateModuleObj): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .put<any>(
                    `${environment.apiUrl}${routes.updateModuleLevelCP}`,
                    updateModuleObj
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    getProductionPlanData(plantId): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(
                    `${environment.apiUrl}${routes.getProductionPlanData}` +
                        plantId
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    getOtherUserPlans(): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(`${environment.apiUrl}${routes.getOtherUserPlans}`)
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    deleteProductionPlanData(planId) {
        return new Observable<any>((observer) => {
            this.http
                .delete<any>(
                    `${environment.apiUrl}${routes.deleteProductionPlanData}` +
                        planId
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    renameProductionPlan(renamePlanObj): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .put<any>(
                    `${environment.apiUrl}${routes.renameProductionPlan}`,
                    renamePlanObj
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    duplicateProductionPlanData(duplicateObj): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .post<any>(
                    `${environment.apiUrl}${routes.duplicateProductionPlanData}`,
                    duplicateObj
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    getModuleSearch(
        searchText,
        plantId,
        planId
    ): Observable<AddModuleLevelGrid[]> {
        return new Observable<AddModuleLevelGrid[]>((observer) => {
            this.http
                .get<AddModuleLevelGrid[]>(
                    `${environment.apiUrl}${routes.getModuleSearch}` +
                        "?searchText=" +
                        searchText +
                        "&plantId=" +
                        plantId +
                        "&ProductionPlanID=" +
                        planId
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    getModuleToAddProductionPlan(plantId, planId): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(
                    `${environment.apiUrl}${routes.getModuleToAddProductionPlan}` +
                        "?plantId=" +
                        plantId +
                        "&ProductionPlanID=" +
                        planId
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    deleteModuleProductionPlan(ProductionPlanID, PilotProductID) {
        return new Observable<any>((observer) => {
            this.http
                .delete<any>(
                    `${environment.apiUrl}${routes.deleteModuleProductionPlan}` +
                        "?ProductionPlanID=" +
                        ProductionPlanID +
                        "&PilotProductID=" +
                        PilotProductID
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    getcomparisonweekly(planAId, planBId): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .get<any>(
                    `${environment.apiUrl}${routes.getcomparisonweekly}` +
                        planAId +
                        "/" +
                        planBId
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    getCompareSummaryReport(plantId, planAId, planBId): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .get<any>(
                    `${environment.apiUrl}${routes.getCompareSummaryReport}` +
                        "?plantId=" +
                        plantId +
                        "&PlanAProductionPlanID=" +
                        planAId +
                        "&PlanBProductionPlanID=" +
                        planBId
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    getCompareModuleViewData(
        interval,
        plantId,
        StartDate,
        planAId,
        planBId
    ): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .get<any>(
                    `${environment.apiUrl}${routes.getCompareModuleViewData}` +
                        "?interval=" +
                        interval +
                        "&PlantID=" +
                        plantId +
                        "&StartDate=" +
                        StartDate +
                        "&PlanAProductionPlanID=" +
                        planAId +
                        "&PlanBProductionPlanID=" +
                        planBId
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    getScheduleDatePicker(planAId, planBId): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .get<any>(
                    `${environment.apiUrl}${routes.getScheduleDatePicker}` +
                        planAId +
                        "/" +
                        planBId
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    getModule(): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(`${environment.apiUrl}${routes.getModule}`)
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    getBuildTypeDDL(plantId): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(
                    `${environment.apiUrl}${routes.getBuildTypeDDL}` +
                        "?plantID=" +
                        plantId
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    getBuildStyleDDL(): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(`${environment.apiUrl}${routes.getBuildStyleDDL}`)
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    getBuildScheduleDDL(): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(
                    `${environment.apiUrl}${routes.getBuildScheduleDDL}`
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    getAssosiatedBENDDL(): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(
                    `${environment.apiUrl}${routes.getAssosiatedBENDDL}`
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    getModuleToolType(): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(`${environment.apiUrl}${routes.getModuleToolType}`)
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    getToolTypeDDL(): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(`${environment.apiUrl}${routes.getToolTypeDDL}`)
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    getModuleColorDDL(): Observable<any[]> {
        return new Observable<any[]>((observer) => {
            this.http
                .get<any[]>(`${environment.apiUrl}${routes.getModuleColorDDL}`)
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    addModules(addModuleObj): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .post<any>(
                    `${environment.apiUrl}${routes.addModules}`,
                    addModuleObj
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    // HttpClient API put() method => Update Modules
    updateModules(updateModuleObj): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .put<any>(
                    `${environment.apiUrl}${routes.updateModules}`,
                    updateModuleObj
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }
    // HttpClient API put() method => Update Tool Type
    updateToolType(updateToolTypeObj): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .put<any>(
                    `${environment.apiUrl}${routes.updateToolType}`,
                    updateToolTypeObj
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    checkIfPORIsBeingEdited(planID: number): Observable<any> {
        return new Observable<any>((observer) => {
            this.http
                .get<any[]>(
                    `${environment.apiUrl}${routes.getplanbeingedited}` + planID
                )
                .subscribe(
                    (res) => {
                        observer.next(res);
                    },
                    (error) => {
                        this.handleError(error);
                    }
                );
        });
    }

    public handleError(error) {
        let errorMessage = "";
        if (error.error instanceof ErrorEvent) {
            // Get client-side error
            errorMessage = error.error.message;
        } else {
            // Get server-side error
            errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }
        return throwError(errorMessage);
    }
}
