export class ModuleGridCP {
  Id: number;
  Priority: number;
  Status: string;
  FCID: string;
  PriorityDate: string;
  PilotSerialNumber: string;
  PilotRisk: string;
  //MCSDRiskLevel: string;
  SalesPriority: number;
  BuildStyle: string;
  BuildSchedule: string;
  DayShiftOnly: boolean;
  NoCapacity: boolean;
  RecordType: string;
  RevenueType: string;
  ToolType: string;
  ToolTypeID: number;
  MPSName: string;
  ProductType: string;
  BuildTypeId: number;
  BuildType: string;

  CustomerID: string;
  CompleteATP: string;

  SubAssyBaysNeeded: number;
  SubAssyHrs: number;
  SubAssyTechs: number;
  IntBaysNeeded: number;
  IntHrs: number;
  IntTechs: number;
  TestBaysNeeded: number;
  TestHrs: number;
  TestTechs: number;
  PostTestBaysNeeded: number;
  PostTestHrs: number;
  PostTestTechs: number;
  TotalLaborHrs: number;
  EarliestAllowedLaunchDate: string;
  MaterialReadiness: string;
  BOM: string;
  TranisitionDate: string;
  Launch: string;
  Integration: string;
  TestStart: string;
  MfgComplete: string;
  TSD: string;
  CRD: string;
  CRDGap: number;
  CRDEsc: boolean;
  SRD: string;
  Color: string;
  Notes: string;
  DisabledNoCapacity = false

  ModuleIdSubassembly: number;
  ModuleIdIntegration: number;
  ModuleIdTest: number;
  ModuleIdPostTest: number;

  BEN: string;
  POM : string;
  ActualDMRF: string;
  PlannedDMRF: string;
  Warning: boolean;

  AlreadyScheduled: boolean;

  PlanOfRecord: string;
  T09Comment: string;

  PilotMCSD: string;
  SapMCSD: string;
  onPOR: string;
  ScheduleStatus: string;
  ScheduleStatusId: number;
}
