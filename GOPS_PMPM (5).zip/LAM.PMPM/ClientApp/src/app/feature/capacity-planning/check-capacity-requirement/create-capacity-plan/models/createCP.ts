import { PriorityOrder } from './PriorityOrder';
import { ModLevelCPGrid } from './modLevelCPGrid';
import { SchedulePriorities } from './schedulePriorities';

export class CreateCP {
  PlantID: number | undefined;
  PlantName: string;
  PlanType: string;
  PlanName: string;
  Description: string;
  PriorityOrder: SchedulePriorities[];
  RecordTypePriorityOrder: SchedulePriorities[];
  RevenueTypePriorityOrder: SchedulePriorities[];

  LaborResourcesHardConstraint: boolean;
  BayResourcesHardConstraint: boolean;

  UserID: string;
  DataRefreshDate: Date;

  ModulesLevelCp: ModLevelCPGrid[];
  IsModLevel: boolean;
  ProductionPlanID: number;
  PilotProductIds: number[];
  ModifiedById: number;
}
