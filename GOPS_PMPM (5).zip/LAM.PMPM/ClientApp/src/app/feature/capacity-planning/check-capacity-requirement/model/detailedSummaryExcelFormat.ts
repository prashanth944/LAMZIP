export class DetailedSummary {
  DetailedSummary: DetailedSummaryExcelFormat[];
}



export class DetailedSummaryExcelFormat {
  columnName: string;
  columnValue: string;
}
