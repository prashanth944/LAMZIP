export class AddModuleLevelGrid {
  pilotProductID: number;
  urbpid: string;
  fcid: string;
  pilotSerialNumber: string;
  ben: string;
  recordType: string;
  revenueType: string;
  toolType: string;
  productType: string;
  buildName: string;
  customer: string;
  onPOR: string;
  planofRecord: Date;
  actualManufacturingComplete: Date;
  scheduleStatus: string;
  scheduleStatusId: number;
  customerRequestDate: Date;
}
