import {
    ChangeDetectionStrategy,
    ChangeDetectorRef,
    Component,
    OnInit,
    ViewEncapsulation,
} from "@angular/core";

import { State, distinct, process } from "@progress/kendo-data-query";
import * as moment from "moment";
import { Router, RouterStateSnapshot } from "@angular/router";
import { CreateCPService } from "../create-capacity-plan/create-cp-service/createCP.service";
import { AppStoreService } from "../../../../core/app-store.service";
import { EditService } from "../../../service/edit.service";
import { Plant } from "../../../../core/model/user.model";
import { Item } from "../../../model/item";
import { CompareSummary } from "../model/compareSummary";
import { DetailedSummary } from "../model/detailedSummary";
import { ModuleView } from "../model/moduleView";
import { role, uiScreen } from "../../../../core/model/common.constant";
import { ClassGetter } from "@angular/compiler/src/output/output_ast";
import { math } from "@amcharts/amcharts4/core";
import { GridComponent } from "@progress/kendo-angular-grid";
import { DetailedSummaryExcelFormat } from "../model/detailedSummaryExcelFormat";
import { isNumber } from "@progress/kendo-angular-treelist/dist/es2015/utils";

@Component({
    selector: "pmpm-compare-plans",
    templateUrl: "./compare-plans.component.html",
    styleUrls: ["./compare-plans.component.css"],
    encapsulation: ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ComparePlansComponent implements OnInit {
    site: Plant;

    public userId: number;
    public userName: string;
    showComparePlansSection = false;

    showComparePlanErrMsg = false;
    disableCompare = true;

    canViewCompare = false;
    canEditCompare = false;

    firstPlanItems: Item[] = [];
    secondPlanItems: Item[] = [];
    PlanItems: Item[] = [];
    columnsItems: Item[] = [
        { text: "Col1", value: 1 },
        { text: "Col2", value: 2 },
        { text: "Col3", value: 3 },
    ];
    columnsItemsSource: Item[] = [
        { text: "Col1", value: 1 },
        { text: "Col2", value: 2 },
        { text: "Col3", value: 3 },
    ];

    firstPlanItemsSource: Item[] = [];
    secondPlanItemsSource: Item[] = [];

    firstPlanValue: Item = { text: "", value: 0 };
    secondPlanValue: Item = { text: "", value: 0 };
    columnsValueItem = { text: "", value: 0 };

    loadCompareSummaryTable = true;
    loadDetailedSummaryTable = true;
    loadModuleViewTable = true;
    compareSummaryGridData: CompareSummary[] = [];
    detailedSummaryGridData: DetailedSummary[] = [];
    moduleViewGridData: ModuleView[] = [];
    public gridFilteredData: ModuleView[] = [];

    columns: string[] = [];
    scheduleColHeader: string[] = [];

    timeViewList: Item[] = [
        { text: "Daily", value: 1 },
        { text: "Weekly", value: 2 },
        { text: "Monthly", value: 3 },
    ];
    timeViewValue: Item = { text: "Daily", value: 1 };

    minDate: Date = new Date();
    maxDate: Date = new Date();
    dateRangeStartValue: Date = new Date();
    editViewColumnsOpened = false;

    selectAllVal: boolean;
    spVal: boolean;
    fcidVal: boolean;
    psnVal: boolean;
    benVal: boolean;
    pilotRiskVal: boolean;
    plannedRiskVal: boolean;
    noCapVal: boolean;
    recordVal: boolean;
    revenueVal: boolean;
    toolTypeVal: boolean;
    productTypeVal: boolean;
    btVal: boolean;
    pomVal: boolean;
    t09Val: boolean;
    customerVal: boolean;
    atpVal: boolean;
    subasyHrsVal: boolean;
    intHrsVal: boolean;
    testHrsVal: boolean;
    postTestVal: boolean;
    totalLHVal: boolean;
    earliestLaunchVal: boolean;
    materialReadinessVal: boolean;
    planneddmrfVal: boolean;
    poabomVal: boolean;
    actualdmrfVal: boolean;
    transistionDateVal: boolean;
    lprLaunchVal: boolean;
    committedLaunchVal: boolean;
    projectedLaunchVal: boolean;
    actualLaunchVal: boolean;
    projectedIntStartVal: boolean;
    projectedTestStartVal: boolean;
    projectedTestCompleteVal: boolean;
    projectedMfgCompleteVal: boolean;
    committedIntegrationVal: boolean;
    committedTestStartVal: boolean;
    committedMfgCompleteVal: boolean;
    porVal: boolean;
    crdVal: boolean;
    crdGapVal: boolean;
    crdEscVal: boolean;
    srdVal: boolean;
    tsdVal: boolean;
    pilotMcsdVal: boolean;
    sapMcsdVal: boolean;
    notesVal: boolean;

    interval = "daily";
    startDate: string = moment(new Date()).format("M-D-yyyy");

    columnsConfig = [
        {
            field: "detailedSummary",
            title: "Date",
            hidden: false,
        },
    ];

    DetailedSummary: DetailedSummaryExcelFormat[];

    public colIndex;
    ScStart = 0;
    ScIndex = 0;
    flag = 0;

    scenarioA: string;
    scenarioB: string;

    constructor(
        private createCPService: CreateCPService,
        private appStoreService: AppStoreService,
        private router: Router,
        private editService: EditService,
        private changeDetector: ChangeDetectorRef
    ) {}
    ngOnInit() {
        this.loadCompareSummaryTable = true;
        this.appStoreService.getUserRoles().subscribe((res) => {
            if (res && res.length > 0) {
                this.appStoreService
                    .checkUserAccessRight(res, uiScreen.Compare)
                    .subscribe((result) => {
                        this.canViewCompare = result;

                        if (
                            res.includes(role.Manager) ||
                            res.includes(role.SuperUser) ||
                            res.includes(role.Supervisor) ||
                            res.includes(role.ProjectManager)
                        ) {
                            this.canEditCompare = true;
                        }
                        this.changeDetector.detectChanges();
                    });
            }
        });

        this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site) {
                this.site = {
                    plantName: site.plantName,
                    plantId: site.plantId,
                };
                this.createCPService
                    .getProductionPlanData(this.site?.plantId)
                    .subscribe((res) => {
                        if (res) {
                            res.forEach((val) => {
                                const planN =
                                    val.planName +
                                    " - Last Modified: " +
                                    moment(val.modifiedDate).format("M-D-YY");
                                const it: Item = {
                                    text: planN,
                                    value: val.productionPlanID,
                                };
                                const it2: Item = {
                                    text: val.planName,
                                    value: val.productionPlanID,
                                };
                                this.PlanItems.push(it2);
                                this.firstPlanItems.push(it);
                                this.secondPlanItems.push(it);
                            });
                            this.firstPlanItemsSource = this.firstPlanItems;
                            this.secondPlanItemsSource = this.secondPlanItems;
                        }
                    });
            }
        });
        this.appStoreService.getLoggedInUser().subscribe((user) => {
            this.appStoreService.getUserDetails(user.mail).subscribe((res) => {
                this.userId = res?.userId;
                this.userName = res?.firstName + " " + res?.lastName;
            });
        });
    }
    onComparePlan() {
        this.scenarioA = this.getPlanNName(this.firstPlanValue.value);
        this.scenarioB = this.getPlanNName(this.secondPlanValue.value);
        this.getScheduleDatePicker();
        this.fillDetailedSummaryGrid();
        this.fillComparisonSummaryGrid();
        this.fillModuleViewGrid("daily", this.startDate);
        this.showComparePlansSection = true;
    }
    getPlanNName(planId) {
        let planNm = "";
        this.PlanItems.forEach((val) => {
            if (val.value == planId) {
                planNm = val.text;
            }
        });
        return planNm;
    }
    getWeelyDetailedSummary(dailyWeeklyDates: any) {
        const data: string[] = [];
        const dailyWeeklyHeader: any[] = [];
        const dailyWeeklyValue: any[] = [];
        dailyWeeklyDates.forEach((val) => {
            dailyWeeklyHeader.push(moment(val.dateValue).format("M-D-YY"));
            dailyWeeklyValue.push(val.value);
        });
        this.columns.forEach((val) => {
            if (dailyWeeklyHeader.indexOf(val) != -1) {
                data.push(
                    dailyWeeklyValue[dailyWeeklyHeader.indexOf(val)].toString()
                );
            } else {
                data.push("0");
            }
        });
        return data;
    }
    fillComparisonSummaryGrid() {
        this.compareSummaryGridData = [];

        this.createCPService
            .getCompareSummaryReport(
                this.site?.plantId,
                this.firstPlanValue.value,
                this.secondPlanValue.value
            )
            .subscribe((val) => {
                if (val) {
                    val.forEach((v) => {
                        const compareSummary: CompareSummary = {
                            status: v.descriptions,
                            scenarioA: v.planAUtilization,
                            scenarioB: v.planBUtilization,
                            comparison: v.comparison,
                        };
                        this.compareSummaryGridData.push(compareSummary);
                    });
                }
                this.loadCompareSummaryTable = false;
                this.changeDetector.detectChanges();
            });
    }
    getComaparisonString(data) {
        const planAVal = +data.planAUtilization.split(" ")[0];
        const planBVal = +data.planBUtilization.split(" ")[0];
        let result = "";
        if (!isNaN(planAVal) && !isNaN(planBVal)) {
            if (planAVal > planBVal) {
                result =
                    this.firstPlanValue.text.split("-")[0] +
                    " utilizes " +
                    math.round((planAVal - planBVal) * 100).toString() +
                    " more than " +
                    this.secondPlanValue.text.split("-")[0];
            } else if (planAVal < planBVal) {
                result =
                    this.secondPlanValue.text.split("-")[0] +
                    " utilizes " +
                    math.round((planAVal - planBVal) * 100).toString() +
                    " more than " +
                    this.firstPlanValue.text.split("-")[0];
            } else {
                result =
                    this.secondPlanValue.text.split("-")[0] +
                    " utilizes similar to " +
                    this.firstPlanValue.text.split("-")[0];
            }
        }
        return result;
    }
    fillDetailedSummaryGrid() {
        this.columns = [];
        this.detailedSummaryGridData = [];
        this.createCPService
            .getcomparisonweekly(
                this.firstPlanValue.value,
                this.secondPlanValue.value
            )
            .subscribe((res) => {
                if (res) {
                    res.weeklyDates.forEach((val) => {
                        this.columns.push(moment(val).format("M-D-YY"));
                    });
                    res.comparisonLists.forEach((val) => {
                        const data: DetailedSummary = {
                            description: val.description,
                            detailedSummary: this.getWeelyDetailedSummary(
                                val.weeklyDates
                            ),
                        };
                        this.detailedSummaryGridData.push(data);
                    });
                    this.loadDetailedSummaryTable = false;
                }
            });
        this.loadDetailedSummaryTable = false;
        this.changeDetector.detectChanges();
    }

    timeViewChange(e) {
        if (e.text == "Daily") {
            this.interval = "daily";
            this.fillModuleViewGrid("daily", this.startDate);
        } else if (e.text == "Weekly") {
            this.interval = "week";
            this.fillModuleViewGrid("week", this.startDate);
        } else if (e.text == "Monthly") {
            this.interval = "month";
            this.fillModuleViewGrid("month", this.startDate);
        }
    }
    onChangedateRangeStartValue() {
        this.fillModuleViewGrid(
            this.interval,
            moment(this.dateRangeStartValue).format("M-D-yyyy")
        );
    }

    fillModuleViewGrid(interval, startDate) {
        this.loadModuleViewTable = true;
        this.moduleViewGridData = [];
        this.createCPService
            .getCompareModuleViewData(
                interval,
                this.site?.plantId,
                startDate,
                this.firstPlanValue.value,
                this.secondPlanValue.value
            )
            .subscribe((res) => {
                if (res.value == "Record not found! Please Try Again") {
                    this.loadModuleViewTable = false;
                } else if (res.length >= 0) {
                    this.getScheduleColHeader(res[0].BuildHoursDates);
                    res.forEach((val) => {
                        const det = val.ProductName;
                        const modView: ModuleView = {
                            scenario: det.ProductionPlanName,
                            moduleSummary: this.getSchedule(
                                val.BuildHoursDates
                            ),
                            pilotSerialNumber: det.PilotSerialNumber,
                            Id: det.PilotProductID,
                            Priority: 1,
                            Status: "",
                            FCID: det.FCID,
                            PriorityDate: "",
                            PilotSerialNumber: det.PilotSerialNumber,
                            PilotRisk: det.PilotRisk,
                            PlannedRiskLevel: det.PlannedRiskLevel,
                            SalesPriority: det.SalesPriority,

                            DayShiftOnly: det.DayShiftOnly,
                            NoCapacity: det.NoCapacity,
                            RecordType: det.RecordType,
                            RevenueType: det.RevenueType,
                            ToolType: det.ToolTypeName,
                            ToolTypeID: det.ToolTypeID,
                            MPSName: "",
                            ProductType: det.ProductName,
                            BuildTypeId: det.BuildTypeID,
                            BuildType: det.BuildName,
                            BuildStyle: det.buildStyleName,

                            CustomerID: det.CustomerID,
                            CompleteATP: det.CompleteATP,

                            SubAssyHrs: det.SubassemblyBuildHours,
                            IntHrs: det.IntegrationBuildHours,
                            TestHrs: det.TestBuildHours,
                            PostTestHrs: det.PostTestBuildHours,
                            TotalLaborHrs: det.TotalLaborHour,

                            EarliestAllowedLaunchDate:
                                det.EarliestStartDate != null
                                    ? moment(det.EarliestStartDate).format(
                                          "M-D-YY"
                                      )
                                    : null,
                            MaterialReadiness:
                                det.MaterialReadiness != null
                                    ? moment(det.MaterialReadiness).format(
                                          "M-D-YY"
                                      )
                                    : null,
                            BOM:
                                det.POABOMReleaseDate != null
                                    ? moment(det.POABOMReleaseDate).format(
                                          "M-D-YY"
                                      )
                                    : null,
                            TranisitionDate:
                                det.TransitionDate != null
                                    ? moment(det.TransitionDate).format(
                                          "M-D-YY"
                                      )
                                    : null,
                            Launch:
                                det.CommitLaunch != null
                                    ? moment(det.CommitLaunch).format("M-D-YY")
                                    : null,
                            Integration:
                                det.CommittedIntegrationStart != null
                                    ? moment(
                                          det.CommittedIntegrationStart
                                      ).format("M-D-YY")
                                    : null,
                            TestStart:
                                det.CommittedTestStart != null
                                    ? moment(det.CommittedTestStart).format(
                                          "M-D-YY"
                                      )
                                    : null,
                            MfgComplete:
                                det.CommitedManufacturingComplete != null
                                    ? moment(
                                          det.CommitedManufacturingComplete
                                      ).format("M-D-YY")
                                    : null,
                            PilotCommit:
                                det.PilotManufacturingCommitedShipDate != null
                                    ? moment(
                                          det.PilotManufacturingCommitedShipDate
                                      ).format("M-D-YY")
                                    : null,
                            TSD:
                                det.TargetShipDate != null
                                    ? moment(det.TargetShipDate).format(
                                          "M-D-YY"
                                      )
                                    : null,
                            MCSD:
                                det.ManufacturingCommitedShipDate != null
                                    ? moment(
                                          det.ManufacturingCommitedShipDate
                                      ).format("M-D-YY")
                                    : null,
                            CRD:
                                det.CustomerRequestDate != null
                                    ? moment(det.CustomerRequestDate).format(
                                          "M-D-YY"
                                      )
                                    : null,
                            CRDGap: det.CRDGapDays,
                            CRDEsc: det.CRDEsc,
                            SRD:
                                det.SalesOpsRequestDate != null
                                    ? moment(det.SalesOpsRequestDate).format(
                                          "M-D-YY"
                                      )
                                    : null,
                            Notes: det.Note,
                            DisabledNoCapacity: false,

                            ModuleIdSubassembly:
                                det.ModuleProcessIdForSubassembly,
                            ModuleIdIntegration:
                                det.ModuleProcessIdForIntegration,
                            ModuleIdTest: det.ModuleProcessIdForTest,
                            ModuleIdPostTest: det.ModuleProcessIdForPostTest,

                            BEN: det.BEN,
                            POM: det.POM,
                            ActualDMRF:
                                det.PlannedDMRF != null
                                    ? moment(det.PlannedDMRF).format("M-D-YY")
                                    : null,
                            PlannedDMRF:
                                det.ActualDMRF != null
                                    ? moment(det.ActualDMRF).format("M-D-YY")
                                    : null,

                            LPRLaunch:
                                det.LPRPlannedLaunchP09 != null
                                    ? moment(det.LPRPlannedLaunchP09).format(
                                          "M-D-YY"
                                      )
                                    : null,
                            ProjectedLaunch:
                                det.ProjectedLaunch != null
                                    ? moment(det.ProjectedLaunch).format(
                                          "M-D-YY"
                                      )
                                    : null,
                            ActualLaunch:
                                det.ActualLaunch != null
                                    ? moment(det.ActualLaunch).format("M-D-YY")
                                    : null,

                            ProjectedIntegrationStart:
                                det.ProjectedIntegrationStart != null
                                    ? moment(
                                          det.ProjectedIntegrationStart
                                      ).format("M-D-YY")
                                    : null,
                            ProjectedTestStart:
                                det.ProjectedTestStart != null
                                    ? moment(det.ProjectedTestStart).format(
                                          "M-D-YY"
                                      )
                                    : null,
                            ProjectedTestComplete:
                                det.ProjectedTestComplete != null
                                    ? moment(det.ProjectedTestComplete).format(
                                          "M-D-YY"
                                      )
                                    : null,
                            ProjectedManufacturingComplete:
                                det.ProjectedManufacturingComplete != null
                                    ? moment(
                                          det.ProjectedManufacturingComplete
                                      ).format("M-D-YY")
                                    : null,
                            CapacityPlanningColor: det.CapacityPlanningColor,

                            PlanOfRecord:
                                det.PlanofRecord != null
                                    ? moment(det.PlanofRecord).format("M-D-YY")
                                    : null,
                            T09Comment: det.T09Comment,
                        };
                        this.moduleViewGridData.push(modView);
                    });
                    this.gridFilteredData = this.moduleViewGridData;
                }
                this.loadModuleViewTable = false;
                this.changeDetector.detectChanges();
            });
    }
    getScheduleColHeader(BuildHoursDates) {
        this.scheduleColHeader = [];
        if (BuildHoursDates != null && BuildHoursDates.length > 0) {
            BuildHoursDates.forEach((val) => {
                this.scheduleColHeader.push(
                    moment(val.Datedaily).format("M-D-YY")
                );
            });
        }
    }
    getSchedule(BuildHoursDates) {
        const scheduleValues = [];
        if (BuildHoursDates != null && BuildHoursDates.length > 0) {
            BuildHoursDates.forEach((val) => {
                scheduleValues.push(val.baysbuilhoursOnHover);
            });
        }
        return scheduleValues;
    }
    getScheduleDatePicker() {
        this.createCPService
            .getScheduleDatePicker(
                this.firstPlanValue.value,
                this.secondPlanValue.value
            )
            .subscribe((res) => {
                if (res) {
                    this.minDate = new Date(res[0].minEarliestStartDate);
                    this.maxDate = new Date(res[0].maxProjectedDate);
                }
            });
    }
    handleFilter(value, dataItem) {
        if (dataItem === "columnsItems") {
            this.columnsItems = this.columnsItemsSource.filter(
                (s) => s.text.toLowerCase().indexOf(value.toLowerCase()) !== -1
            );
        }
    }
    columnsSelectionChange(e) {}
    closeCompare() {
        this.showComparePlansSection = false;
        this.moduleViewGridData = [];
        this.detailedSummaryGridData = [];
        this.compareSummaryGridData = [];
    }
    openEditViewColumns() {
        this.editViewColumnsOpened = true;
    }
    closeEditViewColumns() {
        this.editViewColumnsOpened = false;
    }
    onSubmitApply() {
        this.editViewColumnsOpened = false;
    }

    handleFilterFirstPlan(value, dataItem) {
        if (dataItem === "firstPlanItems") {
            this.firstPlanItems = this.firstPlanItemsSource.filter(
                (s) => s.text.toLowerCase().indexOf(value.toLowerCase()) !== -1
            );
        }
    }
    firstPlanSelectionChange(e) {
        if (this.secondPlanValue.text === e.text) {
            this.showComparePlanErrMsg = true;
            this.disableCompare = true;
        } else {
            this.showComparePlanErrMsg = false;
            if (this.secondPlanValue.text != "") this.disableCompare = false;
            else this.disableCompare = true;
        }
    }
    handleFilterSecondPlan(value, dataItem) {
        if (dataItem === "secondPlanItems") {
            this.secondPlanItems = this.secondPlanItemsSource.filter(
                (s) => s.text.toLowerCase().indexOf(value.toLowerCase()) !== -1
            );
        }
    }
    secondPlanSelectionChange(e) {
        if (this.firstPlanValue.text === e.text) {
            this.showComparePlanErrMsg = true;
            this.disableCompare = true;
        } else {
            this.showComparePlanErrMsg = false;
            if (this.firstPlanValue.text != "") this.disableCompare = false;
            else this.disableCompare = true;
        }
    }
    onToggleSelectAll() {
        if (this.selectAllVal) {
            this.spVal = true;
            this.fcidVal = true;
            this.psnVal = true;
            this.benVal = true;
            this.pilotRiskVal = true;
            this.plannedRiskVal = true;
            this.noCapVal = true;
            this.recordVal = true;
            this.revenueVal = true;
            this.toolTypeVal = true;
            this.productTypeVal = true;
            this.btVal = true;
            this.pomVal = true;
            this.t09Val = true;
            this.customerVal = true;
            this.atpVal = true;
            this.subasyHrsVal = true;
            this.intHrsVal = true;
            this.testHrsVal = true;
            this.postTestVal = true;
            this.totalLHVal = true;
            this.earliestLaunchVal = true;
            this.materialReadinessVal = true;
            this.planneddmrfVal = true;
            this.poabomVal = true;
            this.actualdmrfVal = true;
            this.transistionDateVal = true;
            this.lprLaunchVal = true;
            this.committedLaunchVal = true;
            this.projectedLaunchVal = true;
            this.actualLaunchVal = true;
            this.projectedIntStartVal = true;
            this.projectedTestStartVal = true;
            this.projectedTestCompleteVal = true;
            this.projectedMfgCompleteVal = true;
            this.committedIntegrationVal = true;
            this.committedTestStartVal = true;
            this.committedMfgCompleteVal = true;
            this.porVal = true;
            this.crdVal = true;
            this.crdGapVal = true;
            this.crdEscVal = true;
            this.srdVal = true;
            this.tsdVal = true;
            this.pilotMcsdVal = true;
            this.sapMcsdVal = true;
            this.notesVal = true;
        } else {
            this.spVal = false;
            this.fcidVal = false;
            this.psnVal = false;
            this.benVal = false;
            this.pilotRiskVal = false;
            this.plannedRiskVal = false;
            this.noCapVal = false;
            this.recordVal = false;
            this.revenueVal = false;
            this.toolTypeVal = false;
            this.productTypeVal = false;
            this.btVal = false;
            this.pomVal = false;
            this.t09Val = false;
            this.customerVal = false;
            this.atpVal = false;
            this.subasyHrsVal = false;
            this.intHrsVal = false;
            this.testHrsVal = false;
            this.postTestVal = false;
            this.totalLHVal = false;
            this.earliestLaunchVal = false;
            this.materialReadinessVal = false;
            this.planneddmrfVal = false;
            this.poabomVal = false;
            this.actualdmrfVal = false;
            this.transistionDateVal = false;
            this.lprLaunchVal = false;
            this.committedLaunchVal = false;
            this.projectedLaunchVal = false;
            this.actualLaunchVal = false;
            this.projectedIntStartVal = false;
            this.projectedTestStartVal = false;
            this.projectedTestCompleteVal = false;
            this.projectedMfgCompleteVal = false;
            this.committedIntegrationVal = false;
            this.committedTestStartVal = false;
            this.committedMfgCompleteVal = false;
            this.porVal = false;
            this.crdVal = false;
            this.crdGapVal = false;
            this.crdEscVal = false;
            this.srdVal = false;
            this.tsdVal = false;
            this.pilotMcsdVal = false;
            this.sapMcsdVal = false;
            this.notesVal = false;
        }
    }
    getBackgroundColor(data) {
        const yellowClass = "yellowClass";
        if (+data == 0) return;
        return yellowClass;
    }
    public onSearchFilter(inputValue: string): void {
        this.moduleViewGridData = process(this.gridFilteredData, {
            filter: {
                logic: "or",
                filters: [
                    {
                        field: "FCID",
                        operator: "contains",
                        value: inputValue,
                    },
                    {
                        field: "scenario",
                        operator: "contains",
                        value: inputValue,
                    },
                    {
                        field: "PilotSerialNumber",
                        operator: "contains",
                        value: inputValue,
                    },
                    {
                        field: "BEN",
                        operator: "contains",
                        value: inputValue,
                    },
                ],
            },
        }).data;
    }
    public getValue(event: Event): string {
        return (event.target as HTMLInputElement).value;
    }

    public exportToExcel(
        grid: GridComponent,
        grid1: GridComponent,
        grid2: GridComponent
    ): void {
        grid.saveAsExcel();
        grid1.saveAsExcel();
        grid2.saveAsExcel();
    }
    public save(component1: any, component2: any): void {
        Promise.all([
            component1.workbookOptions(),
            component2.workbookOptions(),
        ]).then((workbooks) => {
            workbooks[0].sheets = workbooks[0].sheets.concat(
                workbooks[1].sheets
            );
            component1.save(workbooks[0]);
        });
    }

    public onExcelExport(e: any): void {
        this.flag = 0;
        const rows = e.workbook.sheets[0].rows;

        rows.forEach((row, rowIndex) => {
            const currentItem = this.detailedSummaryGridData[rowIndex - 1];

            if (row.type === "header") {
                row.cells.forEach((cell, index) => {
                    if (parseInt(cell.value.split("-")[0]) > 0) {
                        this.colIndex = index;
                        if (this.flag == 0) {
                            this.ScStart = index;
                            this.ScIndex = index;
                        }
                        this.flag = 1;
                        return;
                    }
                });
            }

            // Use the column index to determine the content of the Total Price cell value
            if (row.type === "data") {
                row.cells.forEach((cell, index) => {
                    if (index === this.ScStart && index <= this.colIndex) {
                        const Schr =
                            currentItem.detailedSummary[
                                this.ScStart - this.ScIndex
                            ];
                        cell.value = Schr;
                        this.ScStart = this.ScStart + 1;
                    }
                });
            }
            this.ScStart = this.ScIndex;
        });
    }
    public onExcelExport2(e: any): void {
        this.flag = 0;
        const rows = e.workbook.sheets[0].rows;

        rows.forEach((row, rowIndex) => {
            const currentItem = this.moduleViewGridData[rowIndex - 1];

            if (row.type === "header") {
                row.cells.forEach((cell, index) => {
                    if (parseInt(cell.value.split("-")[0]) > 0) {
                        this.colIndex = index;
                        if (this.flag == 0) {
                            this.ScStart = index;
                            this.ScIndex = index;
                        }
                        this.flag = 1;
                        return;
                    }
                });
            }

            // Use the column index to determine the content of the Total Price cell value
            if (row.type === "data") {
                row.cells.forEach((cell, index) => {
                    if (index === this.ScStart && index <= this.colIndex) {
                        const Schr =
                            currentItem.moduleSummary[
                                this.ScStart - this.ScIndex
                            ];
                        cell.value = Schr;
                        this.ScStart = this.ScStart + 1;
                    }
                });
            }
            this.ScStart = this.ScIndex;
        });
    }
    getScenarioName(data: string) {
        return data.split("|")[0];
    }
    getComparisonString(data: string) {
        const ar = data.split(" ");
        let str = "";
        let str2 = "";
        let ii: number;
        for (let i = 0; i < ar.length; i++) {
            if (isNumber(+ar[i]) || ar[i].indexOf("%") != -1) {
                str = ar[i];
                ii = i;
                break;
            } else {
                str2 = str2 + " " + ar[i];
            }
        }
        let str3 = "";
        if (ii != undefined) {
            for (let j = ii + 1; j < ar.length; j++) {
                str3 = str3 + " " + ar[j];
            }
        }

        if (str2.split("|").length > 1) {
            return " " + str2.split("|")[1] + " ";
        }
        return "";
    }
    getMidPartStr(data: string) {
        const ar = data.split(" ");
        let str = "";
        let str2 = "";
        let ii: number;
        for (let i = 0; i < ar.length; i++) {
            if (isNumber(+ar[i]) || ar[i].indexOf("%") != -1) {
                str = ar[i];
                ii = i;
                break;
            } else {
                str2 = str2 + " " + ar[i];
            }
        }
        let str3 = "";
        if (ii != undefined) {
            for (let j = ii + 1; j < ar.length; j++) {
                str3 = str3 + " " + ar[j];
            }
        }
        return str + " ";
    }
    getEndPartStr(data: string) {
        const ar = data.split(" ");
        let str = "";
        let str2 = "";
        let ii: number;
        for (let i = 0; i < ar.length; i++) {
            if (isNumber(+ar[i]) || ar[i].indexOf("%") != -1) {
                str = ar[i];
                ii = i;
                break;
            } else {
                str2 = str2 + " " + ar[i];
            }
        }
        let str3 = "";
        if (ii != undefined) {
            for (let j = ii + 1; j < ar.length; j++) {
                str3 = str3 + " " + ar[j];
            }
        }
        return str3;
    }
}
