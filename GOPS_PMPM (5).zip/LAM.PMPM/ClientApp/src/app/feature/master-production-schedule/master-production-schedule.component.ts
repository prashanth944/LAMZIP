import {
    ChangeDetectorRef,
    Component,
    OnInit,
    ViewEncapsulation,
} from "@angular/core";
import { Router, RouterStateSnapshot } from "@angular/router";
import * as moment from "moment";
import { Observable } from "rxjs";
import { AppStoreService } from "../../core/app-store.service";
import { role, uiScreen } from "../../core/model/common.constant";
import { Plant, UserModel } from "../../core/model/user.model";
import { CreateCPService } from "../capacity-planning/check-capacity-requirement/create-capacity-plan/create-cp-service/createCP.service";
import { ProductionPlan } from "./model/mps-summary";
import { MpsService } from "./mps-service/mps.service";

@Component({
    selector: "pmpm-master-production-schedule",
    templateUrl: "./master-production-schedule.component.html",
    styleUrls: ["./master-production-schedule.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class MasterProductionScheduleComponent implements OnInit {
    dataRefreshDate: string = moment(new Date())
        .format("MM-DD-yyyy hh:mm A")
        .toString();
    userRoles: string[] = [];
    isUserAccess = false;
    isLoading = true;
    canUserEdit = false;
    isViewChart = false;
    SitePlantName = "";
    site: Plant;
    planID: string;
    UserID: string;
    userName: string;
    canRemoveModule = false;

    editModeOn = false;
    navigationOff = false;
    savePORChanges = false;
    cancelPORChanges = false;
    canRemoveLock = false;
    modifiedDate: Date;
    modifiedBy = "";
    userDetails: UserModel;
    porIsBeingEdited = true;
    porIsBeingEditedBy = "";
    isChanged = false;
    redirectUrl = "";
    savePORClickable = false;
    canEditPOR = false;

    constructor(
        private appStoreService: AppStoreService,
        private mpsService: MpsService,
        private changeDetector: ChangeDetectorRef,
        private router: Router,
        private createCPService: CreateCPService
    ) {}

    ngOnInit() {
        this.userRoles = [];

        this.appStoreService.getLoggedInUser().subscribe((user) => {
            this.appStoreService.getUserDetails(user.mail).subscribe((res) => {
                this.userDetails = res;
                this.userName = res?.firstName + " " + res?.lastName;
                this.appStoreService.getUserRoles().subscribe((res) => {
                    if (res && res.length > 0) {
                        this.userRoles = res;

                        this.appStoreService
                            .checkUserAccessRight(this.userRoles, uiScreen.MPS)
                            .subscribe((result) => {
                                this.isUserAccess = result;
                                if (
                                    res.includes(role.SuperUser) ||
                                    res.includes(role.Manager)
                                ) {
                                    this.canUserEdit = true;
                                }
                                this.isLoading = false;
                            });

                        this.canEditPOR = !res.includes(role.Supervisor);

                        this.appStoreService
                            .getCurrentSite()
                            .subscribe((site) => {
                                if (site) {
                                    this.site = {
                                        plantName: site.plantName,
                                        plantId: site.plantId,
                                    };
                                    this.SitePlantName = this.site?.plantName;
                                    this.getPORPlanId();
                                    this.getAdmindefaultTimeAndColorView(
                                        this.site.plantId
                                    );
                                }
                            });
                    }
                });
            });
        });
    }

    getPORPlanId() {
        this.mpsService
            .getPORProductionPlanID(this.site.plantId)
            .subscribe((res) => {
                if (res) {
                    this.planID = res[0].productionPlanID;
                    this.UserID = res[0].userID;
                    this.modifiedDate = new Date(res[0].modifiedDate);
                    this.porIsBeingEdited = res[0].isBeingEdited;
                    this.porIsBeingEditedBy = res[0].editedBy;
                    this.modifiedBy = res[0].modifiedBy;

                    if (this.porIsBeingEdited) {
                        if (this.userRoles.includes(role.SuperUser)) {
                            this.canRemoveLock = true;
                        }
                        this.editModeOn =
                            this.porIsBeingEditedBy.trim() ==
                            this.userName.trim()
                                ? true
                                : false;
                        this.navigationOff =
                            this.porIsBeingEditedBy.trim() ==
                            this.userName.trim()
                                ? true
                                : false;
                    } else {
                        this.canRemoveLock = false;
                        if (
                            !this.userRoles.includes(role.SuperUser) &&
                            !this.userRoles.includes(role.Manager)
                        ) {
                            this.porIsBeingEdited = true;
                        }
                    }

                    if (this.userName === this.UserID) {
                        this.canRemoveModule = true;
                    } else {
                        this.canRemoveModule = false;
                    }
                }
            });
    }

    onViewChart() {
        this.isViewChart = true;
    }

    closeGanttChart(event) {
        this.isViewChart = false;
    }

    getAdmindefaultTimeAndColorView(plantId) {
        this.mpsService
            .getAdmindefaultTimeAndColorView(plantId)
            .subscribe((res) => {
                if (res) {
                    this.appStoreService.setCurrentTimeView$(
                        res[0].scheduleTimePeriod
                    );
                    this.appStoreService.setColorView$(
                        res[0].scheduleColorView
                    );
                }
            });
    }

    onEditPORClick() {
        this.createCPService
            .checkIfPORIsBeingEdited(+this.planID)
            .subscribe((por) => {
                if (por.isBeingEdited) {
                    this.editModeOn = false;
                    this.navigationOff = false;
                    this.getPORPlanId();
                } else {
                    this.editModeOn = true;
                    this.navigationOff = true;
                    const data: ProductionPlan = {
                        ProductionPlanId: +this.planID,
                        IsBeingEditedById: this.userDetails.userId,
                        IsBeingEditedBy: this.userName,
                        IsBeingEdited: true,
                    };
                    //api to set lock
                    this.mpsService
                        .UpdateEditStatus(data, +this.planID)
                        .subscribe((res) => {
                            if (res != null) {
                                this.appStoreService.setOperrationLogDetails$(
                                    true
                                );
                            }
                        });
                }
            });
    }

    onSavePORClick() {
        this.createCPService
            .checkIfPORIsBeingEdited(+this.planID)
            .subscribe((por) => {
                if (
                    por.isBeingEdited &&
                    por.isBeingEditedById == this.userDetails.userId
                ) {
                    this.savePORChanges = true;
                    this.changeDetector.detectChanges();
                } else {
                    this.editModeOn = false;
                    this.navigationOff = false;
                    this.getPORPlanId();
                }
            });
    }

    onCancelPORClick() {
        if (this.userDetails == null) {
            this.appStoreService.getLoggedInUser().subscribe((user) => {
                this.appStoreService
                    .getUserDetails(user.mail)
                    .subscribe((res) => {
                        this.userDetails = res;
                        this.createCPService
                            .checkIfPORIsBeingEdited(+this.planID)
                            .subscribe((por) => {
                                if (
                                    por.isBeingEdited &&
                                    por.isBeingEditedById ==
                                        this.userDetails.userId
                                ) {
                                    this.cancelPORChanges = true;
                                    this.changeDetector.detectChanges();
                                } else {
                                    this.editModeOn = false;
                                    this.navigationOff = false;
                                    this.getPORPlanId();
                                }
                            });
                    });
            });
        } else {
            this.createCPService
                .checkIfPORIsBeingEdited(+this.planID)
                .subscribe((por) => {
                    if (
                        por.isBeingEdited &&
                        por.isBeingEditedById == this.userDetails.userId
                    ) {
                        this.cancelPORChanges = true;
                        this.changeDetector.detectChanges();
                    } else {
                        this.editModeOn = false;
                        this.navigationOff = false;
                        this.getPORPlanId();
                    }
                });
        }
    }

    resetSave(reset: boolean) {
        this.savePORChanges = false;
        this.onRemoveClick();
    }

    resetCancel(reset: boolean) {
        this.cancelPORChanges = false;
        this.onRemoveClick();
    }

    onRemoveClick() {
        this.createCPService
            .checkIfPORIsBeingEdited(+this.planID)
            .subscribe((por) => {
                if (por.isBeingEdited) {
                    //api to remove lock
                    const data: ProductionPlan = {
                        ProductionPlanId: +this.planID,
                        IsBeingEditedById: this.userDetails.userId,
                        IsBeingEditedBy: this.userName,
                        IsBeingEdited: false,
                    };
                    this.mpsService
                        .UpdateEditStatus(data, +this.planID)
                        .subscribe((res) => {
                            if (res != null) {
                                this.appStoreService.setOperrationLogDetails$(
                                    true
                                );
                                this.getPORPlanId();
                            }
                        });
                    this.editModeOn = false;
                    this.navigationOff = false;
                } else {
                    this.getPORPlanId();
                }
            });
    }

    canDeactivate(
        nextState: RouterStateSnapshot
    ): Observable<boolean> | Promise<boolean> | boolean {
        if (this.navigationOff) {
            this.isChanged = true;
            this.redirectUrl = nextState.url;
            this.changeDetector.detectChanges();
            return false;
        } else {
            return true;
        }
    }

    onOKClick() {
        this.navigationOff = false;
        if (this.redirectUrl != "") {
            this.router.navigate([this.redirectUrl]);
            this.redirectUrl = "";
        }
    }

    gridDataHasChanged(changed: boolean) {
        this.savePORClickable = changed;
    }

    reload() {
        this.getPORPlanId();
    }
}
