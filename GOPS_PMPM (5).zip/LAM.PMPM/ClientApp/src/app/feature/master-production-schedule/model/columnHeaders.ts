export class ColumnHeaders {
    field: string;
}
