export class BuildScheduleHours {
    Interval: string;
    PilotProductID: number;
    Baysbuilhours: string;
    ModuleProcessID: number;
    Datedaily: string;
    ProductionPlanID: number;
}
