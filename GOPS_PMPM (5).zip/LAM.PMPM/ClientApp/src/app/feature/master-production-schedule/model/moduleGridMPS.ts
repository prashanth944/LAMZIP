export class ModuleGridMPS {
    Id: number;
    Priority: number;
    Status: string;
    FCID: string;
    PriorityDate: string;
    PilotSerialNumber: string;
    PilotRisk: string;
    PlannedRiskLevel: string;
    SalesPriority: number;

    DayShiftOnly: boolean;
    NoCapacity: boolean;
    RecordType: string;
    RevenueType: string;
    ToolType: string;
    ToolTypeID: number;
    MPSName: string;
    ProductType: string;
    BuildTypeId: number;
    BuildType: string;
    BuildStyle: string;

    CustomerID: string;
    CompleteATP: string;

    SubAssyHrs: number;
    IntHrs: number;
    TestHrs: number;
    PostTestHrs: number;
    TotalLaborHrs: number;

    EarliestAllowedLaunchDate: string;
    MaterialReadiness: string;
    BOM: string;
    TranisitionDate: string;
    Launch: string;
    Integration: string;
    TestStart: string;
    MfgComplete: string;
    PilotCommit: string;
    TSD: string;
    MCSD: string;
    CRD: string;
    CRDGap: number;
    CRDEsc: boolean;
    SRD: string;
    Notes: string;
    DisabledNoCapacity = false;

    ModuleIdSubassembly: number;
    ModuleIdIntegration: number;
    ModuleIdTest: number;
    ModuleIdPostTest: number;

    BEN: string;
    POM: string;
    ActualDMRF: string;
    PlannedDMRF: string;

    BuildHoursDates: any[];

    LPRLaunch: string;
    ProjectedLaunch: string;
    ActualLaunch: string;

    ProjectedIntegrationStart: string;
    ProjectedTestStart: string;
    ProjectedTestComplete: string;
    ProjectedManufacturingComplete: string;
    CapacityPlanningColor: string;

    PlanOfRecord: string;
    T09Comment: string;
    ScheduleStatus: string;
    ScheduleStatusId: number;
}
