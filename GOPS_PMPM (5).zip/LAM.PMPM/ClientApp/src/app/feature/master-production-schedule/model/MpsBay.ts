export class MpsBay {
    ProductGroup: string;
    BayType: string;
    Building: string;
    WeekTotal: number[];
    WeekRequired: number[];
    WeekRemaining: number[];
    FCID: string;
    PilotSerialNumber: string;
    Customer: string;
    BuildName: string;
    ToolTypeName: string;
}
