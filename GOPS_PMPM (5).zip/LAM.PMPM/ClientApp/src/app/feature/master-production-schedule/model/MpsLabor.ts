export class MpsLabor {
    ManagementGroup: string;
    LaborGroup: string;
    WeekTotal: number[];
    WeekRequired: number[];
    WeekRemaining: number[];
    SumAvailableHours: number[];
    SumConsumedHours: number[];
    SumRemainingHours: number[];
    TotalAvailableHour: number[];
    FCID: string;
    PilotSerialNumber: string;
    Customer: string;
    BuildName: string;
    ProductGroup: string;
    ToolTypeName: string;
}
