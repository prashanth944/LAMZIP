import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { AppStoreService } from "../../core/app-store.service";
import { Plant } from "../../core/model/user.model";
import { RolesModel } from "../model/access-request-model";
import { AccessRequestModel } from "../model/access-request-model";
import { RequestService } from "../service/request.service";

@Component({
    selector: "pmpm-access-request",
    templateUrl: "./access-request.component.html",
    styleUrls: ["./access-request.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class AccessRequestComponent implements OnInit {
    public userId: number;
    public userName = "";
    public userDetails: any;
    public userMessage = "";
    public sites: Plant[] = [];
    public selectedSite: Plant = { plantId: 0, plantName: "" };
    public roles: RolesModel[] = [];
    public selectedRole: RolesModel = {
        roleId: 0,
        roleName: "",
        displayName: "",
    };
    public isSubmitEnabled = false;
    public request: AccessRequestModel;
    public status = "";
    public statusMessage = "";

    constructor(
        private appStoreService: AppStoreService,
        private requestService: RequestService
    ) {}

    ngOnInit(): void {
        this.appStoreService.getLoggedInUser().subscribe((user) => {
            this.userDetails = user;
            this.userName = user.givenName + " " + user.surname;
            this.appStoreService.getUserDetails(user.mail).subscribe((res) => {
                if (res && res.username.length > 0) {
                    this.userId = res?.userId;
                    this.getUserAccessRequest();
                }
            });
        });

        this.getAllPlants();
        this.getAllRoles();
    }

    getAllPlants() {
        this.appStoreService.getAllPlants().subscribe((res) => {
            if (res && res.length > 0) {
                this.sites = res;
            }
        });
    }

    getAllRoles() {
        this.requestService.getAllRoles().subscribe((res) => {
            if (res) {
                this.roles = res;
            }
        });
    }

    getUserAccessRequest() {
        this.requestService
            .getUserAccessRequest(this.userId)
            .subscribe((res) => {
                if (res) {
                    this.selectedSite = {
                        plantId: res.plantID,
                        plantName: res.plantName,
                    };
                    this.selectedRole = {
                        roleId: res.roleId,
                        roleName: res.roleName,
                        displayName: res.roleName,
                    };
                    this.userMessage = res.userMessage;
                    this.userDetails.mail = res.userEmail;
                    this.status = res.status;
                    this.isSubmitEnabled = false;
                    if (res.userAccessRequestStatusID == 3) {
                        this.statusMessage =
                            "Request Denied: " + res.statusMessage;
                    } else {
                        this.statusMessage = res.statusMessage;
                    }
                    this.isSubmitEnabled = false;
                } else {
                    this.setDefaultSite();
                    this.isSubmitEnabled = false;
                }
            });
    }

    onSubmit() {
        if (this.selectedSite !== undefined && this.selectedRole !== undefined) {
            const request = new AccessRequestModel();
            request.userId = this.userId;
            request.plantID = this.selectedSite.plantId;
            request.plantName = this.selectedSite.plantName;
            request.roleId = this.selectedRole.roleId;
            request.roleName = this.selectedRole.displayName;
            request.userMessage = this.userMessage;
            request.userFullName = this.userName;
            request.userEmail = this.userDetails.mail;

            request.userAccessRequestId = null;
            request.userAccessRequestStatusID = null;
            request.status = null;
            request.statusMessage = null;
            request.GUID = null;
            request.host = null;

            this.requestService
                .createAccessRequest(request)
                .subscribe((res) => {
                    if (res) {
                        this.getUserAccessRequest();
                    }
                });
        } else {
            this.isSubmitEnabled = false;
        }
    }

    onValueChange(event): void {
        if (
            this.selectedRole !== undefined &&
            this.selectedSite !== undefined &&
            this.selectedSite.plantId !== null &&
            this.selectedRole.roleId !== null
        ) {
            this.isSubmitEnabled = true;
        }
    }

    resetForm() {
        this.setDefaultSite();
        this.selectedRole = undefined;
        this.userMessage = "";
        this.statusMessage = "";
        this.isSubmitEnabled = true;
    }

    setDefaultSite() {
        this.appStoreService.getCurrentSite().subscribe((site) => {
            if (site) {
                this.selectedSite = {
                    plantName: site.plantName,
                    plantId: site.plantId,
                };
            }
        });
    }
}
