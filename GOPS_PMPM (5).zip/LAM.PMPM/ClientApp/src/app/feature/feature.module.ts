import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { SchedulerModule } from "@progress/kendo-angular-scheduler";
import { LayoutModule } from "@progress/kendo-angular-layout";
import { IndicatorsModule } from "@progress/kendo-angular-indicators";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { IconsModule } from "@progress/kendo-angular-icons";
import { NavigationModule } from "@progress/kendo-angular-navigation";
import { MenusModule } from "@progress/kendo-angular-menu";
import { GanttModule } from "@progress/kendo-angular-gantt";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule } from "@angular/router";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import {
  BodyModule,
  FilterMenuModule,
  GridModule,
  SharedModule,
} from "@progress/kendo-angular-grid";
import { DialogsModule } from "@progress/kendo-angular-dialog";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { DateInputsModule } from "@progress/kendo-angular-dateinputs";
import { LabelModule } from "@progress/kendo-angular-label";
import { HttpClientJsonpModule, HttpClientModule } from "@angular/common/http";
import { BayComponent } from "./capacity-planning/adjust-capacity/bay/bay.component";
import { CheckCapacityRequirementComponent } from "./capacity-planning/check-capacity-requirement/check-capacity-requirement.component";
import { AdjustModuleComponent } from "./capacity-planning/adjust-module/adjust-module.component";
import { LaborComponent } from "./capacity-planning/adjust-capacity/labor/labor.component";
import { ExecutionAndTrackingComponent } from "./execution-and-tracking/execution-and-tracking.component";
import { EditModuleDetailsComponent } from "./execution-and-tracking/edit-module-details/edit-module-details.component";
import { EditModuleHomeComponent } from "./execution-and-tracking/edit-module-details/home/edit-module-home.component";
import { HomeComponent } from "./home-page/home-page.component";
import { GanttChartComponent } from "./gantt-chart/gantt-chart.component";
import { MasterProductionScheduleComponent } from "./master-production-schedule/master-production-schedule.component";
import { ReportingAndDashboardComponent } from "./reporting-and-dashboards/reporting-and-dashboards.component";
import { EditorModule } from "@progress/kendo-angular-editor";
import { DatePipe } from "@angular/common";
import { ProgressBarModule } from "@progress/kendo-angular-progressbar";
import { MPSScheduleComponent } from "./master-production-schedule/schedule/mps-schedule.component";
import { AddHolidaysComponent } from "./other/admin/add-holidays/add-holidays.component";
import { SetDefaultsComponent } from "./other/admin/set-defaults/set-defaults.component";
import { TestAppComponent } from "./other/admin/test-app/test-app.component";
import { UpdateSitesComponent } from "./other/admin/update-sites/update-sites.component";
import { MPSByasComponent } from "./master-production-schedule/mps-bays/mps-bays.component";
import { MPSLaborComponent } from "./master-production-schedule/mps-labor/mps-labor.component";
import { CreateCapacityPlanComponent } from "./capacity-planning/check-capacity-requirement/create-capacity-plan/create-capacity-plan.component";
import { EditService } from "./service/edit.service";
import { UpdateZonesComponent } from "./other/admin/update-zones/update-zones.component";
import { ModuleLevelComponent } from "./capacity-planning/check-capacity-requirement/create-capacity-plan/module-level/module-level.component";
import { WipReportComponent } from "./execution-and-tracking/wip-report/wip-report.component";
import { MyModulesComponent } from "./execution-and-tracking/my-modules/my-modules.component";
import { ModuleSumaryComponent } from "./execution-and-tracking/module-sumary/module-sumary.component";
import { ProgressDivComponent } from "./execution-and-tracking/progress-div/progress-div.component";
import { ItemWarningsComponent } from "./execution-and-tracking/item-warnings/item-warnings.component";
import { HomeManagerComponent } from "./home-manager/home-manager.component";
import { CalendarDisplayComponent } from "./home-manager/calendar-display/calendar-display.component";
import { ModulesUpcomingComponent } from "./home-manager/modules-upcoming/modules-upcoming.component";
import { EditModuleOperationsComponent } from "./execution-and-tracking/edit-module-details/operations/edit-module-operations.component";
import { LogProgressComponent } from "./execution-and-tracking/log-progress/log-progress.component";
import { InterruptionsComponent } from "./execution-and-tracking/log-progress/interruptions/interruptions.component";
import { StepsComponent } from "./execution-and-tracking/log-progress/steps/steps.component";
import { WorkSummaryComponent } from "./execution-and-tracking/work-summary/work-summary.component";
import { HomeTechnicianComponent } from "./home-page/home-technician/home-technician.component";
import { HomeSuperUserComponent } from "./home-page/home-super-user/home-super-user.component";
import { HomeSupervisorComponent } from "./home-page/home-supervisor/home-supervisor.component";
import { HomeLeadComponent } from "./home-page/home-lead/home-lead.component";
import { HomeProjectManagerComponent } from "./home-page/home-project-manager/home-project-manager.component";
import { HomeOtherComponent } from "./home-page/home-other/home-other.component";
import { AccessRequestComponent } from "./access-request/access-request.component";
import { RequestApprovalComponent } from "./request-approval/request-approval.component";
import { RequestService } from "./service/request.service";
import { TooltipModule } from "@progress/kendo-angular-tooltip";
import { ReworkLogsComponent } from "./execution-and-tracking/edit-module-details/rework-logs/rework-logs.component";
import { ReworkComponent } from "./execution-and-tracking/log-progress/rework/rework.component";
import { CanDeactivateGuard } from "./service/rotuer-guard-service";
import { OtherUserPlansComponent } from "./capacity-planning/check-capacity-requirement/other-user-plans/other-user-plans.component";
import { ScheduleGeneratedComponent } from "./schedule-generated/schedule-generated.component";
import { SGScheduleComponent } from "./schedule-generated/schedule/sg-schedule.component";
import { SGBaysComponent } from "./schedule-generated/schedule-generated-bays/sg-bays.component";
import { SGLaborComponent } from "./schedule-generated/schedule-generated-labor/sg-labor.component";
import { CurrentlyRecordingTimeComponent } from "./execution-and-tracking/edit-module-details/currently-recording-time/currently-recording-time.component";
import { ExcelExportModule } from "@progress/kendo-angular-excel-export";
import { ExcelModule } from "@progress/kendo-angular-grid";
import { DownloadFileComponent } from "./download-file/download-file.component";
import { PDFExportModule } from "@progress/kendo-angular-pdf-export";
import { PDFModule } from "@progress/kendo-angular-grid";
import { ActionItemsComponent } from "./execution-and-tracking/edit-module-details/action-items/action-items.component";
import { TOIComponent } from "./execution-and-tracking/edit-module-details/action-items/toi/toi.component";
import { AuditItemsComponent } from "./execution-and-tracking/edit-module-details/action-items/audit-items/audit-items.component";
import { AuditOperationsComponent } from "./execution-and-tracking/audit-operations/audit-operations.component";
import { AuditOpComponent } from "./execution-and-tracking/audit-operations/audit-op/audit-op.component";
import { EditModuleScheduleComponent } from "./execution-and-tracking/edit-module-details/schedule/edit-module-schedule.component";
import { ViewTOIComponent } from "./execution-and-tracking/edit-module-details/action-items/toi/view-toi/view-toi.component";
import { EditModuleAdminComponent } from "./execution-and-tracking/edit-module-details/admin/edit-module-admin.component";
import { OpenItemsComponent } from "./execution-and-tracking/edit-module-details/action-items/audit-items/open-items/open-items.component";
import { CompleteItemsComponent } from "./execution-and-tracking/edit-module-details/action-items/audit-items/complete-items/complete-items.component";
import { OBCComponent } from "./execution-and-tracking/edit-module-details/action-items/obc/obc.component";
import { RTSComponent } from "./execution-and-tracking/edit-module-details/action-items/rts/rts.component";
import { SpecialSubassemblyComponent } from "./capacity-planning/adjust-module/special-subassemblies/special-subassembly.component";
import { ToolTypeComponent } from "./capacity-planning/adjust-module/tool-type/tool-type.component";
import { MttComponent } from "./execution-and-tracking/edit-module-details/action-items/mtt/mtt.component";
import { IssuesLogComponent } from "./execution-and-tracking/edit-module-details/action-items/issues-log/issues-log.component";
import { EditModulePassdownsComponent } from "./execution-and-tracking/edit-module-details/passdowns/edit-module-passdowns.component";
import { NCIComponent } from "./execution-and-tracking/edit-module-details/action-items/nci/nci.component";
import { GenPassdownsComponent } from "./execution-and-tracking/edit-module-details/passdowns/gen-passdowns/gen-passdowns.component";
import { ShortagesComponent } from "./execution-and-tracking/edit-module-details/action-items/shortages/shortages.component";
import { DateTrackingSearchComponent } from "./reporting-and-dashboards/date-tracking-search/date-tracking-search.component";
import { DateTrackingModComponent } from "./reporting-and-dashboards/date-tracking-mod/date-tracking-mod.component";
import { ComparePlansComponent } from "./capacity-planning/check-capacity-requirement/compare-plans/compare-plans.component";
import { LaborHourTrackingComponent } from "./labor-hour-tracking/labor-hour-tracking.component";
import { SharedCalendarComponent } from "./labor-hour-tracking/shared-calendar/shared-calendar.component";
import { AddLaborHoursComponent } from "./labor-hour-tracking/add-labor-hours/add-labor-hours.component";
import { VerifyHoursComponent } from "./labor-hour-tracking/verify-hours/verify-hours.component";
import { PilotFiscalCalendarComponent } from "./labor-hour-tracking/pilot-fiscal-calendar/pilot-fiscal-calendar.component";
import { CalendarReportComponent } from "./calendar-report/calendar-report.component";
import { ReportTableComponent } from "./calendar-report/report-table/report-table.component";
import { SchedulerReportComponent } from "./calendar-report/scheduler-report/scheduler-report.component";
import { EditPersonalEventComponent } from "./calendar-report/edit-personal-event/edit-personal-event.component";
import { MultiCheckFilterComponent } from "./capacity-planning/adjust-capacity/multicheck-filter.component";
import { DataMismatchComponent } from "./reporting-and-dashboards/data-mismatch/data-mismatch.component";
import { TechDashboardComponent } from "./labor-hour-tracking/verify-hours/tech-dashboard/tech-dashboard.component";
import { LeadDashboardComponent } from "./labor-hour-tracking/verify-hours/lead-dashboard/lead-dashboard.component";
import { OpsMgmtComponent } from "./execution-and-tracking/edit-module-details/ops-mgmt/ops-mgmt.component";
import { TOIDashboardComponent } from "./reporting-and-dashboards/toi-dashboard/toi-dashboard.component";
import { QuickLinksComponent } from "./home-page/quick-links/quick-links.component";
import { FiscalCalendarReportTableComponent } from "./labor-hour-tracking/pilot-fiscal-calendar/fiscal-calendar-report-table/fiscal-calendar-report-table.component";
import { FiscalCalendarAddEditDialogComponent } from "./labor-hour-tracking/pilot-fiscal-calendar/fiscal-calendar-add-edit-dialog/fiscal-calendar-add-edit-dialog.component";
import { ManagerDashboardComponent } from "./labor-hour-tracking/verify-hours/manager-dashboard/manager-dashboard.component";
import { PassDashboardComponent } from "./labor-hour-tracking/verify-hours/pass-dashboard/pass-dashboard.component";
import { SupervisorDashboardComponent } from "./labor-hour-tracking/verify-hours/supervisor-dashboard/supervisor-dashboard.component";
import { SuperUserDashboardComponent } from "./labor-hour-tracking/verify-hours/superuser-dashboard/superuser-dashboard.component";
import { CriticalGatingComponent } from "./execution-and-tracking/edit-module-details/action-items/critical-gating/critical-gating.component";
import { SafetyLinedownComponent } from "./execution-and-tracking/edit-module-details/action-items/safety-linedown/safety-linedown.component";
import { ClipboardModule } from "ngx-clipboard";
import { EmailsAdminComponent } from "./other/admin/emails-admin/emails-admin.component";
import { EditLaborHourComponent } from "./labor-hour-tracking/edit-labor-hours/edit-labor-hours.component";
import { OtherSapModulesComponent } from "./capacity-planning/adjust-module/other-sap-modules/other-sap-modules.component";
import { OperationDetailsComponent } from "./execution-and-tracking/operation-details/operation-details.component";
import { EditCycleTimeComponent } from "./labor-hour-tracking/verify-hours/edit-cycle-time/edit-cycle-time.component";
import { LaborHourSummaryComponent } from "./labor-hour-tracking/verify-hours/labor-hour-summary/labor-hour-summary.component";
import { TagsSnsDocsComponent } from "./execution-and-tracking/edit-module-details/tags-sns-docs/tags-sns-docs.component";
import { SerializationNumbersComponent } from "./execution-and-tracking/edit-module-details/tags-sns-docs/serialization-numbers/serialization-numbers.component";
import { SAFEPermitComponent } from './execution-and-tracking/edit-module-details/safepermit/safepermit.component';
import { AddReconfigComponent } from "./execution-and-tracking/edit-module-details/add-reconfig/add-reconfig.component";
import { DeleteReconfigComponent } from "./execution-and-tracking/edit-module-details/delete-reconfig/delete-reconfig.component";

@NgModule({
  declarations: [
    CheckCapacityRequirementComponent,
    AdjustModuleComponent,
    BayComponent,
    LaborComponent,
    ExecutionAndTrackingComponent,
    EditModuleDetailsComponent,
    EditModuleHomeComponent,
    HomeComponent,
    GanttChartComponent,
    MasterProductionScheduleComponent,
    ReportingAndDashboardComponent,
    MPSScheduleComponent,
    AddHolidaysComponent,
    SetDefaultsComponent,
    TestAppComponent,
    UpdateSitesComponent,
    MPSByasComponent,
    MPSLaborComponent,
    CreateCapacityPlanComponent,
    UpdateZonesComponent,
    ModuleLevelComponent,
    WipReportComponent,
    MyModulesComponent,
    ModuleSumaryComponent,
    ProgressDivComponent,
    ItemWarningsComponent,
    HomeManagerComponent,
    CalendarDisplayComponent,
    ModulesUpcomingComponent,
    EditModuleOperationsComponent,
    LogProgressComponent,
    InterruptionsComponent,
    StepsComponent,
    WorkSummaryComponent,
    HomeTechnicianComponent,
    HomeSuperUserComponent,
    HomeSupervisorComponent,
    HomeLeadComponent,
    HomeProjectManagerComponent,
    HomeOtherComponent,
    AccessRequestComponent,
    RequestApprovalComponent,
    ReworkLogsComponent,
    ReworkComponent,
    OtherUserPlansComponent,
    ComparePlansComponent,
    ScheduleGeneratedComponent,
    SGScheduleComponent,
    SGBaysComponent,
    SGLaborComponent,
    CurrentlyRecordingTimeComponent,
    DownloadFileComponent,
    ActionItemsComponent,
    TOIComponent,
    AuditItemsComponent,
    AuditOperationsComponent,
    AuditOpComponent,
    EditModuleScheduleComponent,
    ViewTOIComponent,
    EditModuleAdminComponent,
    OpenItemsComponent,
    CompleteItemsComponent,
    OBCComponent,
    RTSComponent,
    SpecialSubassemblyComponent,
    ToolTypeComponent,
    MttComponent,
    IssuesLogComponent,
    EditModulePassdownsComponent,
    NCIComponent,
    GenPassdownsComponent,
    ShortagesComponent,
    DateTrackingSearchComponent,
    DateTrackingModComponent,
    LaborHourTrackingComponent,
    SharedCalendarComponent,
    AddLaborHoursComponent,
    VerifyHoursComponent,
    PilotFiscalCalendarComponent,
    CalendarReportComponent,
    ReportTableComponent,
    SchedulerReportComponent,
    EditPersonalEventComponent,
    MultiCheckFilterComponent,
    DataMismatchComponent,
    TechDashboardComponent,
    LeadDashboardComponent,
    OpsMgmtComponent,
    TOIDashboardComponent,
    QuickLinksComponent,
    FiscalCalendarReportTableComponent,
    FiscalCalendarAddEditDialogComponent,
    ManagerDashboardComponent,
    PassDashboardComponent,
    SupervisorDashboardComponent,
    SuperUserDashboardComponent,
    CriticalGatingComponent,
    SafetyLinedownComponent,
    EmailsAdminComponent,
    EditLaborHourComponent,
    OtherSapModulesComponent,
    OperationDetailsComponent,
    EditCycleTimeComponent,
    LaborHourSummaryComponent,
    TagsSnsDocsComponent,
    SerializationNumbersComponent,
    SAFEPermitComponent,
    AddReconfigComponent,
    DeleteReconfigComponent,
  ],
  imports: [
    RouterModule,
    BrowserModule,
    BrowserAnimationsModule,
    LayoutModule,
    IndicatorsModule,
    InputsModule,
    IconsModule,
    NavigationModule,
    MenusModule,
    GanttModule,
    FormsModule,
    ReactiveFormsModule,
    ButtonsModule,
    GridModule,
    DialogsModule,
    DropDownsModule,
    DateInputsModule,
    LabelModule,
    HttpClientJsonpModule,
    HttpClientModule,
    EditorModule,
    ProgressBarModule,
    SharedModule,
    FilterMenuModule,
    BodyModule,
    TooltipModule,
    ExcelExportModule,
    ExcelModule,
    PDFExportModule,
    PDFModule,
    SchedulerModule,
    ClipboardModule,
  ],
  exports: [
    CheckCapacityRequirementComponent,
    AdjustModuleComponent,
    BayComponent,
    LaborComponent,
    RouterModule,
    EditModuleDetailsComponent,
    EditModuleHomeComponent,
    HomeComponent,
    GanttChartComponent,
    MasterProductionScheduleComponent,
    ReportingAndDashboardComponent,
    MPSScheduleComponent,
    AddHolidaysComponent,
    SetDefaultsComponent,
    TestAppComponent,
    UpdateSitesComponent,
    MPSByasComponent,
    MPSLaborComponent,
    CreateCapacityPlanComponent,
    UpdateZonesComponent,
    ModuleLevelComponent,
    LogProgressComponent,
    InterruptionsComponent,
    StepsComponent,
    WorkSummaryComponent,
    HomeTechnicianComponent,
    HomeSuperUserComponent,
    HomeSupervisorComponent,
    HomeLeadComponent,
    HomeProjectManagerComponent,
    HomeOtherComponent,
    AccessRequestComponent,
    RequestApprovalComponent,
    TooltipModule,
    ReworkLogsComponent,
    ReworkComponent,
    OtherUserPlansComponent,
    ComparePlansComponent,
    ScheduleGeneratedComponent,
    SGScheduleComponent,
    SGBaysComponent,
    SGLaborComponent,
    CurrentlyRecordingTimeComponent,
    DownloadFileComponent,
    ExcelExportModule,
    ExcelModule,
    PDFExportModule,
    PDFModule,
    ActionItemsComponent,
    TOIComponent,
    AuditItemsComponent,
    AuditOperationsComponent,
    AuditOpComponent,
    EditModuleScheduleComponent,
    ViewTOIComponent,
    EditModuleAdminComponent,
    OpenItemsComponent,
    CompleteItemsComponent,
    OBCComponent,
    RTSComponent,
    SpecialSubassemblyComponent,
    ToolTypeComponent,
    MttComponent,
    IssuesLogComponent,
    EditModulePassdownsComponent,
    NCIComponent,
    GenPassdownsComponent,
    ShortagesComponent,
    DateTrackingSearchComponent,
    DateTrackingModComponent,
    LaborHourTrackingComponent,
    SharedCalendarComponent,
    AddLaborHoursComponent,
    VerifyHoursComponent,
    PilotFiscalCalendarComponent,
    MultiCheckFilterComponent,
    DataMismatchComponent,
    TechDashboardComponent,
    LeadDashboardComponent,
    OpsMgmtComponent,
    TOIDashboardComponent,
    QuickLinksComponent,
    ManagerDashboardComponent,
    PassDashboardComponent,
    SupervisorDashboardComponent,
    SuperUserDashboardComponent,
    CriticalGatingComponent,
    SafetyLinedownComponent,
    EmailsAdminComponent,
    EditLaborHourComponent,
    OtherSapModulesComponent,
    EditCycleTimeComponent,
    LaborHourSummaryComponent,
    SerializationNumbersComponent,
    AddReconfigComponent,
    DeleteReconfigComponent,
  ],
  providers: [EditService, DatePipe, RequestService, CanDeactivateGuard],
})
export class FeatureModule { }
