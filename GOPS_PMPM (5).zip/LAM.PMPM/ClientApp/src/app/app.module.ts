import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CoreModule } from './core/core.module';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { IndicatorsModule } from '@progress/kendo-angular-indicators';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { IconsModule } from '@progress/kendo-angular-icons';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { MenuModule } from '@progress/kendo-angular-menu';
import { CapcityPlanningComponent } from './feature/capacity-planning/capacity-planning.component';
import { AdjustCapacityComponent } from './feature/capacity-planning/adjust-capacity/adjust-capacity.component';
import { ColumnResizingService, GridModule } from '@progress/kendo-angular-grid';
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { FeatureModule } from './feature/feature.module';
import { EditorModule } from '@progress/kendo-angular-editor';
import { OtherComponent } from './feature/other/other.component';
import { AdminComponent } from './feature/other/admin/admin.component';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { LabelModule } from '@progress/kendo-angular-label';
import { ProgressBarModule } from '@progress/kendo-angular-progressbar';
import { GanttModule } from '@progress/kendo-angular-gantt';
import { NotificationModule } from "@progress/kendo-angular-notification";
import { MsalService, MsalModule, MsalGuard, MsalInterceptor } from '@azure/msal-angular';
import { InteractionType, PublicClientApplication } from '@azure/msal-browser';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { environment } from '../environments/environment.dev_server';
import { TooltipModule } from '@progress/kendo-angular-tooltip';
import { ExcelExportModule } from '@progress/kendo-angular-excel-export';
import { ExcelModule } from '@progress/kendo-angular-grid';
import { PDFExportModule } from '@progress/kendo-angular-pdf-export';
import { PDFModule } from '@progress/kendo-angular-grid'


const isIE = window.navigator.userAgent.indexOf('MSIE ') > -1 || window.navigator.userAgent.indexOf('Trident/') > -1;
const getGroupsApi = '/security/groups';

@NgModule({
  declarations: [
    AppComponent,
    CapcityPlanningComponent,
    AdjustCapacityComponent,
    OtherComponent,
    AdminComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CoreModule,
    LayoutModule,
    BrowserAnimationsModule,
    IndicatorsModule,
    InputsModule,
    IconsModule,
    NavigationModule,
    MenuModule,
    GridModule,
    DialogsModule,
    FeatureModule,
    EditorModule,
    ButtonsModule,
    DropDownsModule,
    LabelModule,
    ProgressBarModule,
    GanttModule,
    NotificationModule,
    TooltipModule,
    ExcelExportModule,
    ExcelModule,
    PDFExportModule,
    PDFModule,
    MsalModule.forRoot(new PublicClientApplication({
      auth: {
        clientId: '671bb78a-8dca-4481-85f7-6360442d9cc4', // This is your client ID 
        authority: 'https://login.microsoftonline.com/918079db-c902-4e29-b22c-9764410d0375',  //
        redirectUri: 'https://dev-pmpm.lamresearch.com/home'// Change this---This is your redirect URI
        //redirectUri: 'http://localhost:4200/home'// Change this---This is your redirect URI
      },
      cache: {
        cacheLocation: 'localStorage',
        storeAuthStateInCookie: isIE,
      } 
    }), {
      interactionType: InteractionType.Redirect,
      authRequest: {
        scopes: ['api://671bb78a-8dca-4481-85f7-6360442d9cc4/user_impersonation', 'user.read'],
      }
    }, {
      interactionType: InteractionType.Redirect, // MSAL Interceptor Configuration
      protectedResourceMap: new Map([
        [`${environment.apiUrl}`, ['api://671bb78a-8dca-4481-85f7-6360442d9cc4/user_impersonation']],
        [`${environment.apiUrl}${getGroupsApi}`, ['api://671bb78a-8dca-4481-85f7-6360442d9cc4/user_impersonation']],
        ['https://graph.microsoft.com/v1.0/me', ['user.read']]
      ])
    })
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: MsalInterceptor,
      multi: true
    },
    MsalGuard,
    MsalService,
    ColumnResizingService],
  bootstrap: [AppComponent]
})
export class AppModule { }
