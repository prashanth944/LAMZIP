﻿using LAM.PMPM.DAL;
using LAM.PMPM.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Text;
using System.Linq;
using LAM.PMPM.Model.ViewModel;
namespace LAM.PMPM.BL
{
    public class EditSchedule
    {
        DataTable dataTable;
        public string GetScheduleSummary(string connString, string interval, int PlantID, DateTime StartDate, int productionPlanID)
        {
            try
            {
                dataTable = new DataTable();
                DateTime LaborDate;
                SqlParameter[] param = {
                    new SqlParameter("@Interval", interval),
                    new SqlParameter("@plantID", PlantID),
                    new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                    new SqlParameter("@ProductionPlanID", productionPlanID),
                    };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetScheduledSummaryWhatIf", param);

                SqlParameter[] param1 = { new SqlParameter("@Interval", interval),
                        new SqlParameter("@plantID", PlantID),
                        new SqlParameter("@ProductionPlanID", productionPlanID),
                        };
                DataTable dtDistinctDatedaily = new DataTable();
                dtDistinctDatedaily = SqlHelper.GetDataTable(connString, "uspGetSummaryDistinctDatedaily", param1);
                var DistinctDatedaily = (from x in dataTable.AsEnumerable()
                                         group x by (DateTime)x["LaborDate"] into g
                                         select g).ToList();



                for (int j = 0; j < dtDistinctDatedaily.Rows.Count; j++)
                {
                    var HeadcountType = dtDistinctDatedaily.Rows[j]["HeadcountType"].ToString();
                    for (int i = 0; i < DistinctDatedaily.Count; i++)
                    {
                        LaborDate = Convert.ToDateTime(DistinctDatedaily[i].Key);
                        bool contains = dataTable.AsEnumerable().Where(c => c.Field<string>("HeadcountType") == HeadcountType).Any(row => LaborDate == row.Field<DateTime?>("LaborDate"));
                        if (!contains)
                        {
                            DataRow dr = dataTable.NewRow();
                            dr["LaborDate"] = LaborDate; //string
                            dr["HeadcountType"] = HeadcountType; //string
                            dr["Headcount"] = 0; //string
                            dataTable.Rows.Add(dr);
                        }
                    }
                }
                List<MPSSummary> mpsSummary = null;
                var mpsSummarys = dataTable.Rows.Cast<DataRow>()
                .GroupBy(x => new { HeadcountType = x["HeadcountType"] })
                .OrderBy(x => x.Key.HeadcountType)
                .Select(x => new
                {
                    BayDetails = x.Key,
                    DailyWeeklyDates = x.Select(y => new
                    {
                        DailyDate = y.Field<DateTime>("LaborDate"),
                        DescriptionCount = y.Field<Int32>("Headcount")
                    })
                }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(mpsSummarys);

                return jsonString;

            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public string GetScheduleBay(string connString, string interval, int PlantID, DateTime StartDate, int productionPlanID)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = {
                        new SqlParameter("@Interval",interval),
                        new SqlParameter("@planID", PlantID),
                        new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                        new SqlParameter("@ProductionPlanID", productionPlanID),
                        };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetBaysForScheduledWhatIf", param); string bayScheduleList = null;
                dynamic baySchedule = null;
                baySchedule = dataTable.Rows.Cast<DataRow>()
                .GroupBy(x => new
                {
                    Product_Type = x["ProductName"],
                    BayTypeName = x["BayTypeName"],
                    BuildingName = x["BuildingName"],
                    FCID = x["FCID"],
                    PilotSerialNumber = x["PilotSerialNumber"],
                    Customer = x["Customer"],
                    BuildName = x["BuildName"],
                    ToolTypeName = x["ToolTypeName"],
                })
                .Select(x => new
                {
                    ProductName = x.Key,
                    WeeklyDates = x.Select(y => new
                    {
                        TotalBaysAvailablity = y.Field<Int32>("TotalBaysAvailablity"),
                        TotalConsumed = y.Field<Int32>("TotalConsumed"),
                        TotalRemaining = y.Field<Int32>("TotalRemaining"),
                        BayDate = y.Field<DateTime>("BayDate")
                    })
                }).ToList(); bayScheduleList = Newtonsoft.Json.JsonConvert.SerializeObject(baySchedule);
                return bayScheduleList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public string GetScheduleTotalBay(string connString, string interval, int PlantID, DateTime StartDate, int productionPlanID)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = {
                        new SqlParameter("@Interval",interval),
                        new SqlParameter("@planID", PlantID),
                        new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                        new SqlParameter("@ProductionPlanID", productionPlanID),
                        };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetTotalBaysForScheduledWhatIf", param); string bayScheduleList = null;
                dynamic baySchedule = null;
                baySchedule = dataTable.Rows.Cast<DataRow>()
                .GroupBy(x => new
                {
                    Product_Type = x["ProductName"],
                    BayTypeName = x["BayTypeName"],
                    BuildingName = x["BuildingName"],
                    FCID = x["FCID"],
                    PilotSerialNumber = x["PilotSerialNumber"],
                    Customer = x["Customer"],
                    BuildName = x["BuildName"],
                    ToolTypeName = x["ToolTypeName"],
                })
                .Select(x => new
                {
                    ProductName = x.Key,
                    WeeklyDates = x.Select(y => new
                    {
                        TotalBaysAvailablity = y.Field<Int32>("TotalBaysAvailablity"),
                        BayDate = y.Field<DateTime>("BayDate")
                    })
                }).ToList(); bayScheduleList = Newtonsoft.Json.JsonConvert.SerializeObject(baySchedule);
                return bayScheduleList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public string GetScheduleLabor(string connString, string interval, int PlantID, DateTime StartDate, int productionPlanID)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = {
                    new SqlParameter("@Interval",interval), new SqlParameter("@planID", PlantID),
                    new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                    new SqlParameter("@ProductionPlanID", productionPlanID),
                    };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetLaborhoursForScheduledWhatIf", param);
                string laborScheduleList = null;
                var laborSchedule = dataTable.Rows.Cast<DataRow>()
                .GroupBy(x => new
                {
                    ManagementName = x["ManagementName"],
                    ProductName = x["ProductName"],
                    Laborgroup = x["Laborgroup"],
                    FCID = x["FCID"],
                    PilotSerialNumber = x["PilotSerialNumber"],
                    Customer = x["Customer"],
                    BuildName = x["BuildName"],
                    ToolTypeName = x["ToolTypeName"],
                })
                .Select(x => new
                {
                    ProductName = x.Key,
                    WeeklyDates = x.Select(y => new
                    {
                        TotalAvailableHour = y.Field<decimal>("TotalAvailableHour"),
                        TotalConsumedHour = y.Field<Int32>("TotalConsumedHour"),
                        TotalRemainingHour = y.Field<decimal>("TotalRemainingHour"),
                        LaborDate = y.Field<DateTime>("LaborDate"),
                        SumAvailableHour = y.Field<decimal>("SumAvailableHour"),
                        SumConsumedHour = y.Field<Int32>("SumConsumedHour"),
                        SumRemainingHour = y.Field<decimal>("SumRemainingHour"),
                    })
                }).ToList();
                laborScheduleList = Newtonsoft.Json.JsonConvert.SerializeObject(laborSchedule);
                return laborScheduleList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public string GetScheduleTotalLabor(string connString, string interval, int PlantID, DateTime StartDate, int productionPlanID)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = {
                    new SqlParameter("@Interval",interval), new SqlParameter("@planID", PlantID),
                    new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                    new SqlParameter("@ProductionPlanID", productionPlanID),
                    };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetTotalLaborhoursForScheduledWhatIf", param);
                string laborScheduleList = null;
                var laborSchedule = dataTable.Rows.Cast<DataRow>()
                .GroupBy(x => new
                {
                    ManagementName = x["ManagementName"],
                    ProductName = x["ProductName"],
                    Laborgroup = x["Laborgroup"],
                    FCID = x["FCID"],
                    PilotSerialNumber = x["PilotSerialNumber"],
                    Customer = x["Customer"],
                    BuildName = x["BuildName"],
                    ToolTypeName = x["ToolTypeName"],
                })
                .Select(x => new
                {
                    ProductName = x.Key,
                    WeeklyDates = x.Select(y => new
                    {
                        TotalAvailableHour = y.Field<decimal>("TotalAvailableHour"),
                        LaborDate = y.Field<DateTime>("LaborDate"),
                        SumAvailableHour = y.Field<decimal>("SumAvailableHour"),
                    })
                }).ToList();
                laborScheduleList = Newtonsoft.Json.JsonConvert.SerializeObject(laborSchedule);
                return laborScheduleList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public string GetScheduleModuleData(string connString, string interval, int PlantID, DateTime StartDate, int productionPlanID)
        {
            try
            {
                DataTable dataTable;
                DateTime Datedaily;
                string MPSDataList = null;
                SqlParameter[] param = {
new SqlParameter("@Interval",interval),
new SqlParameter("@planID",PlantID),
new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
new SqlParameter("@ProductionPlanID", productionPlanID),
};
                dataTable = SqlHelper.GetDataTable(connString, "uspGetScheduledDataWhatIf", param);
                var DistinctList = (from x in dataTable.AsEnumerable()
                                    group x by (DateTime)x["Datedaily"] into g
                                    select g).ToList();
                DataTable copyDataTable = copyDataTable = dataTable.Copy();
                string[] ColumnsToBeDeleted = { "Datedaily", "baysbuilhours", "baysbuilhoursOnHover", "ModuleProcessID" };
                foreach (string ColName in ColumnsToBeDeleted)
                {
                    if (copyDataTable.Columns.Contains(ColName))
                        copyDataTable.Columns.Remove(ColName);
                }
                if (copyDataTable.Rows.Count > 0)
                {
                    DataTable DistinctListWithoutDateDaily = copyDataTable.AsEnumerable().Distinct(DataRowComparer.Default).CopyToDataTable<DataRow>(); for (int j = 0; j < DistinctListWithoutDateDaily.Rows.Count; j++)
                    {
                        var PilotProductID = Convert.ToInt32(DistinctListWithoutDateDaily.Rows[j]["PilotProductID"]);
                        for (int i = 0; i < DistinctList.Count; i++)
                        {
                            Datedaily = Convert.ToDateTime(DistinctList[i].Key);
                            bool contains = dataTable.AsEnumerable().Where(c => c.Field<Int64?>("PilotProductID") == PilotProductID).Any(row => Datedaily == row.Field<DateTime?>("Datedaily"));
                            if (!contains)
                            {
                                DataRow dr = dataTable.NewRow();
                                dr["Datedaily"] = Datedaily; //string
                                dr["PilotProductID"] = PilotProductID; //string
                                dr["SalesPriority"] = DistinctListWithoutDateDaily.Rows[j]["SalesPriority"];
                                dr["FCID"] = DistinctListWithoutDateDaily.Rows[j]["FCID"];
                                dr["PilotSerialNumber"] = DistinctListWithoutDateDaily.Rows[j]["PilotSerialNumber"];
                                dr["PilotRisk"] = DistinctListWithoutDateDaily.Rows[j]["PilotRisk"];
                                dr["PlannedRiskLevel"] = DistinctListWithoutDateDaily.Rows[j]["PlannedRiskLevel"];
                                dr["AlreadyScheduled"] = DistinctListWithoutDateDaily.Rows[j]["AlreadyScheduled"];
                                dr["DayShiftOnly"] = DistinctListWithoutDateDaily.Rows[j]["DayShiftOnly"];
                                dr["NoCapacity"] = DistinctListWithoutDateDaily.Rows[j]["NoCapacity"];
                                dr["RecordType"] = DistinctListWithoutDateDaily.Rows[j]["RecordType"];
                                dr["RevenueType"] = DistinctListWithoutDateDaily.Rows[j]["RevenueType"];
                                dr["ToolTypeName"] = DistinctListWithoutDateDaily.Rows[j]["ToolTypeName"];
                                dr["ToolTypeID"] = DistinctListWithoutDateDaily.Rows[j]["ToolTypeID"];
                                dr["ProductName"] = DistinctListWithoutDateDaily.Rows[j]["ProductName"];
                                dr["BuildTypeID"] = DistinctListWithoutDateDaily.Rows[j]["BuildTypeID"];
                                dr["BuildName"] = DistinctListWithoutDateDaily.Rows[j]["BuildName"];
                                dr["CustomerID"] = DistinctListWithoutDateDaily.Rows[j]["CustomerID"];
                                dr["CompleteATP"] = DistinctListWithoutDateDaily.Rows[j]["CompleteATP"];
                                dr["ModuleProcessIdForSubassembly"] = DistinctListWithoutDateDaily.Rows[j]["ModuleProcessIdForSubassembly"];
                                dr["SubassemblyBuildHours"] = DistinctListWithoutDateDaily.Rows[j]["SubassemblyBuildHours"];
                                dr["ModuleProcessIdForIntegration"] = DistinctListWithoutDateDaily.Rows[j]["ModuleProcessIdForIntegration"]; dr["ModuleProcessIdForIntegration"] = DistinctListWithoutDateDaily.Rows[j]["ModuleProcessIdForIntegration"];
                                dr["IntegrationBuildHours"] = DistinctListWithoutDateDaily.Rows[j]["IntegrationBuildHours"];
                                dr["ModuleProcessIdForTest"] = DistinctListWithoutDateDaily.Rows[j]["ModuleProcessIdForTest"];
                                dr["TestBuildHours"] = DistinctListWithoutDateDaily.Rows[j]["TestBuildHours"];
                                dr["ModuleProcessIdForPostTest"] = DistinctListWithoutDateDaily.Rows[j]["ModuleProcessIdForPostTest"];
                                dr["PostTestBuildHours"] = DistinctListWithoutDateDaily.Rows[j]["PostTestBuildHours"];
                                dr["TotalLaborHour"] = DistinctListWithoutDateDaily.Rows[j]["TotalLaborHour"];
                                dr["EarliestStartDate"] = DistinctListWithoutDateDaily.Rows[j]["EarliestStartDate"];
                                dr["MaterialReadiness"] = DistinctListWithoutDateDaily.Rows[j]["MaterialReadiness"];
                                dr["POABOMReleaseDate"] = DistinctListWithoutDateDaily.Rows[j]["POABOMReleaseDate"];
                                dr["TransitionDate"] = DistinctListWithoutDateDaily.Rows[j]["TransitionDate"];
                                dr["LPRPlannedLaunchP09"] = DistinctListWithoutDateDaily.Rows[j]["LPRPlannedLaunchP09"];
                                dr["TransitionDate"] = DistinctListWithoutDateDaily.Rows[j]["TransitionDate"];
                                dr["ProjectedLaunch"] = DistinctListWithoutDateDaily.Rows[j]["ProjectedLaunch"];
                                dr["ActualLaunch"] = DistinctListWithoutDateDaily.Rows[j]["ActualLaunch"];
                                dr["CommitLaunch"] = DistinctListWithoutDateDaily.Rows[j]["CommitLaunch"];
                                dr["CommittedIntegrationStart"] = DistinctListWithoutDateDaily.Rows[j]["CommittedIntegrationStart"];
                                dr["CommittedTestStart"] = DistinctListWithoutDateDaily.Rows[j]["CommittedTestStart"];
                                dr["CommitedManufacturingComplete"] = DistinctListWithoutDateDaily.Rows[j]["CommitedManufacturingComplete"];
                                dr["PilotManufacturingCommitedShipDate"] = DistinctListWithoutDateDaily.Rows[j]["PilotManufacturingCommitedShipDate"];
                                dr["CustomerRequestDate"] = DistinctListWithoutDateDaily.Rows[j]["CustomerRequestDate"];
                                dr["CRDEsc"] = DistinctListWithoutDateDaily.Rows[j]["CRDEsc"];
                                dr["CRDGapDays"] = DistinctListWithoutDateDaily.Rows[j]["CRDGapDays"];
                                dr["SalesOpsRequestDate"] = DistinctListWithoutDateDaily.Rows[j]["SalesOpsRequestDate"];
                                dr["TargetShipDate"] = DistinctListWithoutDateDaily.Rows[j]["TargetShipDate"];
                                dr["ManufacturingCommitedShipDate"] = DistinctListWithoutDateDaily.Rows[j]["ManufacturingCommitedShipDate"];
                                dr["Note"] = DistinctListWithoutDateDaily.Rows[j]["Note"];
                                dr["BEN"] = DistinctListWithoutDateDaily.Rows[j]["BEN"];
                                dr["POM"] = DistinctListWithoutDateDaily.Rows[j]["POM"];
                                dr["ActualDMRF"] = DistinctListWithoutDateDaily.Rows[j]["ActualDMRF"];
                                dr["PlannedDMRF"] = DistinctListWithoutDateDaily.Rows[j]["PlannedDMRF"];
                                dr["buildStyleName"] = DistinctListWithoutDateDaily.Rows[j]["buildStyleName"];
                                dr["ProjectedIntegrationStart"] = DistinctListWithoutDateDaily.Rows[j]["ProjectedIntegrationStart"];
                                dr["ProjectedTestStart"] = DistinctListWithoutDateDaily.Rows[j]["ProjectedTestStart"];
                                dr["ProjectedTestComplete"] = DistinctListWithoutDateDaily.Rows[j]["ProjectedTestComplete"];
                                dr["ProjectedManufacturingComplete"] = DistinctListWithoutDateDaily.Rows[j]["ProjectedManufacturingComplete"];
                                dr["ModuleProcessID"] = 0; //string
                                dr["baysbuilhours"] = "/";
                                dr["baysbuilhoursOnHover"] = ""; //string
                                dr["CapacityPlanningColor"] = DistinctListWithoutDateDaily.Rows[j]["CapacityPlanningColor"];
                                dr["PlanofRecord"] = DistinctListWithoutDateDaily.Rows[j]["PlanofRecord"];
                                dr["T09Comment"] = DistinctListWithoutDateDaily.Rows[j]["T09Comment"];
                                dr["SchedulingColor"] = DistinctListWithoutDateDaily.Rows[j]["SchedulingColor"];
                                dataTable.Rows.Add(dr);
                            }
                        }
                    }
                    var MPSData = dataTable.Rows.Cast<DataRow>()
                    .OrderBy(r => r.Field<DateTime>("Datedaily")).GroupBy(x => new
                    {
                        PilotProductID = x["PilotProductID"],
                        SalesPriority = x["SalesPriority"],
                        FCID = x["FCID"],
                        PilotSerialNumber = x["PilotSerialNumber"],
                        PilotRisk = x["PilotRisk"],
                        PlannedRiskLevel = x["PlannedRiskLevel"],
                        AlreadyScheduled = x["AlreadyScheduled"],
                        DayShiftOnly = x["DayShiftOnly"],
                        NoCapacity = x["NoCapacity"],
                        RecordType = x["RecordType"],
                        RevenueType = x["RevenueType"],
                        ToolTypeName = x["ToolTypeName"],
                        ToolTypeID = x["ToolTypeID"],
                        ProductName = x["ProductName"],
                        BuildTypeID = x["BuildTypeID"],
                        BuildName = x["BuildName"],
                        CustomerID = x["CustomerID"],
                        CompleteATP = x["CompleteATP"],
                        ModuleProcessIdForSubassembly = x["ModuleProcessIdForSubassembly"],
                        SubassemblyBuildHours = x["SubassemblyBuildHours"],
                        ModuleProcessIdForIntegration = x["ModuleProcessIdForIntegration"],
                        IntegrationBuildHours = x["IntegrationBuildHours"],
                        ModuleProcessIdForTest = x["ModuleProcessIdForTest"],
                        TestBuildHours = x["TestBuildHours"],
                        ModuleProcessIdForPostTest = x["ModuleProcessIdForPostTest"],
                        PostTestBuildHours = x["PostTestBuildHours"],
                        TotalLaborHour = x["TotalLaborHour"],
                        EarliestStartDate = x["EarliestStartDate"],
                        MaterialReadiness = x["MaterialReadiness"],
                        POABOMReleaseDate = x["POABOMReleaseDate"],
                        TransitionDate = x["TransitionDate"],
                        LPRPlannedLaunchP09 = x["LPRPlannedLaunchP09"],
                        ProjectedLaunch = x["ProjectedLaunch"],
                        ActualLaunch = x["ActualLaunch"],
                        CommitLaunch = x["CommitLaunch"],
                        CommittedIntegrationStart = x["CommittedIntegrationStart"],
                        CommittedTestStart = x["CommittedTestStart"],
                        CommitedManufacturingComplete = x["CommitedManufacturingComplete"],
                        PilotManufacturingCommitedShipDate = x["PilotManufacturingCommitedShipDate"],
                        CustomerRequestDate = x["CustomerRequestDate"],
                        CRDEsc = x["CRDEsc"],
                        CRDGapDays = x["CRDGapDays"],
                        SalesOpsRequestDate = x["SalesOpsRequestDate"],
                        TargetShipDate = x["TargetShipDate"],
                        ManufacturingCommitedShipDate = x["ManufacturingCommitedShipDate"],
                        Note = x["Note"],
                        BEN = x["BEN"],
                        POM = x["POM"],
                        ActualDMRF = x["ActualDMRF"],
                        PlannedDMRF = x["PlannedDMRF"],
                        buildStyleName = x["buildStyleName"],
                        ProjectedIntegrationStart = x["ProjectedIntegrationStart"],
                        ProjectedTestStart = x["ProjectedTestStart"],
                        ProjectedTestComplete = x["ProjectedTestComplete"],
                        ProjectedManufacturingComplete = x["ProjectedManufacturingComplete"],
                        CapacityPlanningColor = x["CapacityPlanningColor"],
                        PlanofRecord = x["PlanofRecord"],
                        T09Comment = x["T09Comment"],
                        SchedulingColor = x["SchedulingColor"]
                })
                    .Select(x => new
                    {
                        ProductName = x.Key,
                        BuildHoursDates = x.Select(y => new
                        {
                            baysbuilhours = y.Field<string>("baysbuilhours"),
                            baysbuilhoursOnHover = y.Field<string>("baysbuilhoursOnHover"),
                            ModuleProcessID = y.Field<Int32>("ModuleProcessID"),
                            Datedaily = y.Field<DateTime>("Datedaily")
                        })
                    }).ToList(); MPSDataList = Newtonsoft.Json.JsonConvert.SerializeObject(MPSData);
                }
                return MPSDataList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public int UpdateScheduleModuleData(string connString, ModulesSummary[] editMPSModuleData)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                foreach (var items in editMPSModuleData)
                {
                    foreach (var r in items.ScheduleBuildHours)
                    {
                        if (r != null)
                        {
                            if (r.Baysbuilhours != "T" && r.Baysbuilhours != null)
                            {
                                var BaysRequired = r.Baysbuilhours.Split('/')[0];
                                var LaborBuildHours = r.Baysbuilhours.Split('/')[1] != "" ? r.Baysbuilhours.Split('/')[1] : "0";
                                SqlParameter[] parameters = {
                                        new SqlParameter("@interval",r.Interval),
                                        new SqlParameter("@pilotProductID",r.PilotProductID),
                                        new SqlParameter("@moduleprocessID",r.ModuleProcessID),
                                        new SqlParameter("@dateDaily",r.Datedaily),
                                        new SqlParameter("@baysRequired",Convert.ToInt32(BaysRequired)),
                                        new SqlParameter("@laborBuildHours",Convert.ToDecimal(LaborBuildHours)),
                                        new SqlParameter("@ProductionPlanID",r.ProductionPlanID),
                                        };
                                SqlHelper.ExecuteNonQueryNoOutParam(connString, "uspUpdateScheduledBaysLaborDataDateWiseWhatIf", parameters);
                            }
                        }
                    }
                    SqlParameter[] param = {
                            new SqlParameter("@pilotProductID",items.PilotProductID),
                            new SqlParameter("@pilotSerialNumber",items.PilotSerialNumber),
                            new SqlParameter("@salesPriority",items.SalesPriority),
                            new SqlParameter("@buildTypeID",items.BuildTypeID),
                            new SqlParameter("@toolTypeID",items.ToolTypeID),
                            new SqlParameter("@buildName",items.BuildTypeName),
                            new SqlParameter("@toolTypeName",items.ToolTypeName),
                            new SqlParameter("@PilotRisk",items.PilotRisk),
                            new SqlParameter("@plannedRiskLevel",items.PlannedRiskLevel),
                            new SqlParameter("@earliestallowedlaunch",items.EarliestStartDate),
                            new SqlParameter("@customer",items.CustomerID),
                            new SqlParameter("@completeATP",items.CompleteATP),
                            new SqlParameter("@ModuleProcessIdForSubassembly",items.ModuleIdSubassembly),
                            new SqlParameter("@ModuleProcessIdForIntegration",items.ModuleIdIntegration),
                            new SqlParameter("@ModuleProcessIdForTest",items.ModuleIdTest),
                            new SqlParameter("@ModuleProcessIdForPostTest",items.ModuleIdPostTest),
                            new SqlParameter("@commitLaunch",items.CommitLaunch),
                            new SqlParameter("@commitIntegrationStart",items.CommitIntegrationStart),
                            new SqlParameter("@commitTestStart",items.CommitTestStart),
                            new SqlParameter("@commitManufacturingComplete",items.CommitManufacturingComplete),
                            new SqlParameter("@noCapacity",items.NoCapacity),
                            new SqlParameter("@notes",items.Notes),
                            new SqlParameter("@crdEsc",items.CRDEsc),
                            new SqlParameter("@ManufacturingCommitedShipDate",items.ManufacturingCommitedShipDate),
                            new SqlParameter("@PilotManufacturingCommitedShipDate",items.PilotManufacturingCommitedShipDate),
                            new SqlParameter("@PlanofRecord", items.PlanofRecord),
                            new SqlParameter("@ProductionPlanID",items.ProductionPlanID),
                            new SqlParameter("@ModifiedBy",items.ModifiedBy),
                            new SqlParameter("@ModifiedOn", items.ModifiedOn),
                            outParam
                            };
                    resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateScheduledDataWhatIf", param);
                }
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<MasterRecords> GetTimeViewDDL(string connString)
        {
            try
            {
                dataTable = new DataTable();

                dataTable = SqlHelper.GetDataTable(connString, "uspGetTimeViewDDL", null);
                List<MasterRecords> masterRecords = dataTable.AsEnumerable().Select(dtRow => new MasterRecords()
                {
                    MasterRecordID = dtRow.Field<Int64>("MasterRecordID"),
                    MasterRecordName = dtRow.Field<string>("MasterRecordName")
                }).ToList();
                return masterRecords;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<MasterRecords> GetColorViewDDL(string connString)
        {
            try
            {
                dataTable = new DataTable();
                dataTable = SqlHelper.GetDataTable(connString, "uspGetColorViewDDL", null);
                List<MasterRecords> masterRecords = dataTable.AsEnumerable().Select(dtRow => new MasterRecords()
                {
                    MasterRecordID = dtRow.Field<Int64>("MasterRecordID"),
                    MasterRecordName = dtRow.Field<string>("MasterRecordName")
                }).ToList();
                return masterRecords;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public string GetScheduleFixture(string connString, string interval, int PlantID)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = {
                new SqlParameter("@Interval",interval), new SqlParameter("@planID", PlantID)
            };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetScheduleFixture", param);


                string fixtureScheduleList = null;
                dynamic fixtureSchedule = null;
                if (interval.ToLower() == "daily")
                {


                    fixtureSchedule = dataTable.Rows.Cast<DataRow>()
                   .GroupBy(x => new { FixtureName = x["FixtureName"] })
                   .Select(x => new
                   {
                       FixtureName = x.Key,
                       WeeklyDates = x.Select(y => new
                       {
                           FixtureCount = y.Field<Int32>("FixtureCount"),
                           FixtureDate = y.Field<DateTime>("FixtureDate")

                       })
                   }).ToList();

                }
                else if (interval.ToLower() == "week")
                {

                    fixtureSchedule = dataTable.Rows.Cast<DataRow>()
                 .GroupBy(x => new { FixtureName = x["FixtureName"] })
                 .Select(x => new
                 {
                     FixtureName = x.Key,
                     WeeklyDates = x.Select(y => new
                     {
                         FixtureCount = y.Field<Int32>("FixtureCount"),
                         WeekStart = y.Field<DateTime>("WeekStart")

                     })
                 }).ToList();

                }
                fixtureScheduleList = Newtonsoft.Json.JsonConvert.SerializeObject(fixtureSchedule);
                return fixtureScheduleList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<MasterRecords> GetPlanTypeDDL(string connString)
        {
            try
            {
                dataTable = new DataTable();
                dataTable = SqlHelper.GetDataTable(connString, "uspGetPlanTypeDDL", null);
                List<MasterRecords> masterRecords = dataTable.AsEnumerable().Select(dtRow => new MasterRecords()
                {
                    MasterRecordID = dtRow.Field<int>("MasterRecordID"),
                    MasterRecordName = dtRow.Field<string>("MasterRecordName")
                }).ToList();
                return masterRecords;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<ScheduleCapacity> GetScheduleDatePicker(string connString, int plantID,int productionPlanID)
        {
            try
            {
                dataTable = new DataTable();
                SqlParameter[] param = {
                    new SqlParameter("@plantID",plantID),
                    new SqlParameter("@productionPlanID",productionPlanID),
                    };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetScheduleDatePickerWhatIf", param);
                List<ScheduleCapacity> ScheduleDatepicker = dataTable.AsEnumerable().Select(y => new ScheduleCapacity()
                {
                    MinEarliestStartDate = y.Field<DateTime?>("MinEarliestStartDate"),
                    MaxProjectedDate = y.Field<DateTime?>("MaxProjectedDate"),
                }).ToList();
                return ScheduleDatepicker;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<SchedulesViewModel> GetProductionPlanByProdPlanID(string connString, int productionPlanID)
        {
            dataTable = new DataTable();
            SqlParameter[] param = {
                new SqlParameter("@productionPlanID",productionPlanID),
                };
            List<SchedulesViewModel> ProdPlanData = new List<SchedulesViewModel>();
            dataTable = SqlHelper.GetDataTable(connString, "uspGetProductionPlanByProdPlanID", param);
            try
            {
                ProdPlanData = dataTable.AsEnumerable().Select(dtRow => new SchedulesViewModel()
                {
                    ProductionPlanID = dtRow.Field<long?>("ProductionPlanID"),
                    PlanName = dtRow.Field<string>("ProductionPlanName"),
                    PlanType = dtRow.Field<string>("PlanType"),
                    DataRefreshDate = dtRow.Field<DateTime?>("DataRefreshDate"),
                    Description = dtRow.Field<string>("DecriptionScenario"),
                    ModifiedDate = dtRow.Field<DateTime?>("ModifiedDate"),
                    UserID = dtRow.Field<string>("UserID"),
                    IsBeingEdited = dtRow.Field<bool?>("IsBeingEdited"),
                    ModifiedBy = dtRow.Field<string>("ModifiedBy"),
                    IsBeingEditedBy = dtRow.Field<string>("IsBeingEditedBy"),
                }).ToList();
            }
            catch (Exception ex)
            {
            }
            return ProdPlanData;
        }

        public List<SchedulesViewModel> GetPushToProductionTime(string connString, int productionPlanID, int plantID)
        {
            dataTable = new DataTable();
            SqlParameter[] param = {
                new SqlParameter("@productionPlanID",productionPlanID),
                new SqlParameter("@plantID",plantID),
                };
            List<SchedulesViewModel> ProdPlanTime = new List<SchedulesViewModel>();
            dataTable = SqlHelper.GetDataTable(connString, "uspPushToProductionTime", param);
            try
            {
                ProdPlanTime = dataTable.AsEnumerable().Select(dtRow => new SchedulesViewModel()
                {
                    PushToProductionTime = dtRow.Field<DateTime?>("PushToProductionTime"),
                }).ToList();
            }
            catch (Exception ex)
            {
            }
            return ProdPlanTime;
        }

        public string GetScheduleBayLimitedFilter(string connString, string interval, int PlantID, DateTime StartDate, int productionPlanID)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = {
                        new SqlParameter("@Interval",interval),
                        new SqlParameter("@planID", PlantID),
                        new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                        new SqlParameter("@ProductionPlanID", productionPlanID),
                        };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetBaysForScheduledWhatIfLimitedFilter", param); string bayScheduleList = null;
                dynamic baySchedule = null;
                baySchedule = dataTable.Rows.Cast<DataRow>()
                .GroupBy(x => new
                {
                    Product_Type = x["ProductName"],
                    BayTypeName = x["BayTypeName"],
                    BuildingName = x["BuildingName"],
                })
                .Select(x => new
                {
                    ProductName = x.Key,
                    WeeklyDates = x.Select(y => new
                    {
                        TotalBaysAvailablity = y.Field<Int32>("TotalBaysAvailablity"),
                        TotalConsumed = y.Field<Int32>("TotalConsumed"),
                        TotalRemaining = y.Field<Int32>("TotalRemaining"),
                        BayDate = y.Field<DateTime>("BayDate")
                    })
                }).ToList(); bayScheduleList = Newtonsoft.Json.JsonConvert.SerializeObject(baySchedule);
                return bayScheduleList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public string GetScheduleTotalBayLimitedFilter(string connString, string interval, int PlantID, DateTime StartDate, int productionPlanID)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = {
                        new SqlParameter("@Interval",interval),
                        new SqlParameter("@planID", PlantID),
                        new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                        new SqlParameter("@ProductionPlanID", productionPlanID),
                        };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetTotalBaysForScheduledWhatIfLimitedFilter", param); string bayScheduleList = null;
                dynamic baySchedule = null;
                baySchedule = dataTable.Rows.Cast<DataRow>()
                .GroupBy(x => new
                {
                    Product_Type = x["ProductName"],
                    BayTypeName = x["BayTypeName"],
                    BuildingName = x["BuildingName"],
                })
                .Select(x => new
                {
                    ProductName = x.Key,
                    WeeklyDates = x.Select(y => new
                    {
                        TotalBaysAvailablity = y.Field<Int32>("TotalBaysAvailablity"),
                        BayDate = y.Field<DateTime>("BayDate")
                    })
                }).ToList(); bayScheduleList = Newtonsoft.Json.JsonConvert.SerializeObject(baySchedule);
                return bayScheduleList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public string GetScheduleLaborLimitedFilter(string connString, string interval, int PlantID, DateTime StartDate, int productionPlanID)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = {
                            new SqlParameter("@Interval",interval), new SqlParameter("@planID", PlantID),
                            new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                            new SqlParameter("@ProductionPlanID", productionPlanID),
                            };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetLaborhoursForScheduledWhatIfLimitedFilter", param);
                string laborScheduleList = null;
                var laborSchedule = dataTable.Rows.Cast<DataRow>()
               .GroupBy(x => new
               {
                   ManagementName = x["ManagementName"],
                    Laborgroup = x["Laborgroup"],
                   LaborDate = x["LaborDate"]
                })
               .Select(x => new
               {
                   ProductName = new { x.Key.Laborgroup, x.Key.ManagementName },
                   WeeklyDates = x.Select(y => new
                   {
                       TotalAvailableHour = y.Field<decimal>("TotalAvailableHour"),
                       TotalConsumedHour = y.Field<decimal?>("TotalConsumedHour"),
                       TotalRemainingHour = y.Field<decimal>("TotalRemainingHour"),
                       LaborDate = x.Key.LaborDate,
                       SumAvailableHour = x.Sum(zz => zz.Field<decimal>("TotalAvailableHour")),
                       SumConsumedHour = x.Sum(zz => zz.Field<decimal?>("TotalConsumedHour")),
                       SumRemainingHour = x.Sum(zz => zz.Field<decimal>("TotalRemainingHour")),
                   })
               }).ToList().GroupBy(gg => gg.ProductName).Select(group => new { ProductName = group.Key, WeeklyDates = group.Select(zz => zz.WeeklyDates.FirstOrDefault()) })
               .OrderBy(x => x.ProductName.ManagementName).ThenBy(x => x.ProductName.Laborgroup).ToList();
                laborScheduleList = Newtonsoft.Json.JsonConvert.SerializeObject(laborSchedule);
                return laborScheduleList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public string GetGanttChartScheduleLaborLimitedFilter(string connString, int PlantID, DateTime StartDate, DateTime EndDate, int productionPlanID)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = {
                            new SqlParameter("@planID", PlantID),
                            new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                            new SqlParameter("@EndDate",Convert.ToDateTime(EndDate)),
                            new SqlParameter("@ProductionPlanID", productionPlanID),
                            };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetGanttChartLaborhoursForScheduledWhatIfLimitedFilter", param);
                string laborScheduleList = null;
                var laborSchedule = dataTable.Rows.Cast<DataRow>()
               .GroupBy(x => new
               {
                   ManagementName = x["ManagementName"],
                   Laborgroup = x["Laborgroup"],
                   LaborDate = x["LaborDate"]
               })
               .Select(x => new
               {
                   ProductName = new { x.Key.Laborgroup, x.Key.ManagementName },
                   WeeklyDates = x.Select(y => new
                   {
                       TotalAvailablity = y.Field<decimal>("TotalAvailableHour"),
                       TotalConsumedHour = y.Field<decimal?>("TotalConsumedHour"),
                       TotalRemainingHour = y.Field<decimal>("TotalRemainingHour"),
                       LaborDate = x.Key.LaborDate,
                       SumRemainingHour = x.Sum(zz => zz.Field<decimal>("TotalRemainingHour")),
                   })
               }).ToList().GroupBy(gg => gg.ProductName).Select(group => new { ProductName = group.Key, WeeklyDates = group.Select(zz => zz.WeeklyDates.FirstOrDefault()) }).ToList();
                laborScheduleList = Newtonsoft.Json.JsonConvert.SerializeObject(laborSchedule);
                return laborScheduleList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }



        public string GetGanttChartScheduleBayLimitedFilter(string connString, int PlantID, DateTime StartDate, DateTime EndDate, int productionPlanID)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = {
                        new SqlParameter("@planID", PlantID),
                        new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                        new SqlParameter("@EndDate",Convert.ToDateTime(EndDate)),
                        new SqlParameter("@ProductionPlanID", productionPlanID),
                        };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetGanttBaysForScheduledWhatIfLimitedFilter", param); string bayScheduleList = null;
                dynamic baySchedule = null;
                baySchedule = dataTable.Rows.Cast<DataRow>()
                .GroupBy(x => new
                {
                    Product_Type = x["ProductName"],
                    BayTypeName = x["BayTypeName"],
                    BuildingName = x["BuildingName"],
                })
                .Select(x => new
                {
                    ProductName = x.Key,
                    WeeklyDates = x.Select(y => new
                    {
                        TotalAvailablity = y.Field<Int32>("TotalBaysAvailablity"),
                        TotalRemaining = y.Field<Int32>("TotalRemaining"),
                        BayDate = y.Field<DateTime>("BayDate")
                    })
                }).ToList(); bayScheduleList = Newtonsoft.Json.JsonConvert.SerializeObject(baySchedule);
                return bayScheduleList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public string GetGanttChartSumScheduleBayLimitedFilter(string connString, int PlantID, DateTime StartDate, DateTime EndDate, int productionPlanID)
       {
            try
            {
                DataTable dataTable2;
            SqlParameter[] param2 = {
                        new SqlParameter("@planID", PlantID),
                        new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                        new SqlParameter("@EndDate",Convert.ToDateTime(EndDate)),
                        new SqlParameter("@ProductionPlanID", productionPlanID),
                        };
            dataTable2 = SqlHelper.GetDataTable(connString, "uspGetGanttBaysForScheduledWhatIfLimitedFilter", param2);



            string bayScheduleList = null;
            dynamic baySchedule = null;
            baySchedule = dataTable2.Rows.Cast<DataRow>()
                .GroupBy(x => new
                {
                    Date = x["BayDate"]
                })
                .Select(x => new
                {
                    WeeklyDates = x.Select(y => new
                    {
                        TotalRemaining = Convert.ToDecimal(x.Sum(y => y.Field<Int32>("TotalRemaining"))),
                        Date = y.Field<DateTime>("BayDate")
                    }).FirstOrDefault()
                }).ToList(); 
            bayScheduleList = Newtonsoft.Json.JsonConvert.SerializeObject(baySchedule); 
            return bayScheduleList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public string GetGanttChartLaunchDates(string connString, DateTime StartDate, DateTime EndDate, int productionPlanID)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = {
                            new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                            new SqlParameter("@EndDate",Convert.ToDateTime(EndDate)),
                            new SqlParameter("@ProductionPlanID", productionPlanID),
                            };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetGanttChartLaunchDates", param);
                string launchList = null;

                    var launchSchedule = dataTable.AsEnumerable().Select(item => new
                    {
                        TotalRemaining = item["NoOfLaunches"],
                        Date = item["ProjectedLaunch"]
                    }).ToList();
              
                launchList = Newtonsoft.Json.JsonConvert.SerializeObject(launchSchedule);
                return launchList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            }
             public string GetGanttChartSumScheduleLaborLimitedFilter(string connString, int PlantID, DateTime StartDate, DateTime EndDate, int productionPlanID)
            {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = {
                            new SqlParameter("@planID", PlantID),
                            new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                            new SqlParameter("@EndDate",Convert.ToDateTime(EndDate)),
                            new SqlParameter("@ProductionPlanID", productionPlanID),
                            };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetGanttChartLaborhoursForScheduledWhatIfLimitedFilter", param);
                string laborScheduleList = null;
                dynamic laborSchedule = null;
                laborSchedule = dataTable.Rows.Cast<DataRow>()
                    .GroupBy(x => new
                    {
                        Date = x["LaborDate"]
                    })
                    .Select(x => new
                    {
                        WeeklyDates = x.Select(y => new
                        {
                            TotalRemaining = x.Sum(y => y.Field<decimal>("TotalRemainingHour")),
                            Date = y.Field<DateTime>("LaborDate")
                        }).FirstOrDefault()
                    }).ToList();



                laborScheduleList = Newtonsoft.Json.JsonConvert.SerializeObject(laborSchedule);

                              
                return laborScheduleList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }




        public string GetScheduleTotalLaborLimitedFilter(string connString, string interval, int PlantID, DateTime StartDate, int productionPlanID)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = {
                            new SqlParameter("@Interval",interval), new SqlParameter("@planID", PlantID),
                            new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                            new SqlParameter("@ProductionPlanID", productionPlanID),
                            };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetTotalLaborhoursForScheduledWhatIfLimitedFilter", param);
                string laborScheduleList = null;
                var laborSchedule = dataTable.Rows.Cast<DataRow>()
                .GroupBy(x => new
                {
                    ManagementName = x["ManagementName"],
                    Laborgroup = x["Laborgroup"],
                })
                .Select(x => new
                {
                    ProductName = x.Key,
                    WeeklyDates = x.Select(y => new
                    {
                        TotalAvailableHour = y.Field<decimal>("TotalAvailableHour"),
                        LaborDate = y.Field<DateTime>("LaborDate"),
                        SumAvailableHour = y.Field<decimal>("SumAvailableHour"),
                 
                    })
                }).OrderBy(x => x.ProductName.ManagementName).ThenBy(x => x.ProductName.Laborgroup).ToList();
                laborScheduleList = Newtonsoft.Json.JsonConvert.SerializeObject(laborSchedule);
                return laborScheduleList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public List<TimeAndColorViewModel> GetAdmindefaultTimeAndColorView(string connString, int PlantID)
        {
            try
            {
                dataTable = new DataTable();
                SqlParameter[] param = {
                            new SqlParameter("@PlantID", PlantID),
                            };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetAdmindefaultTimeAndColorView", param);
                List<TimeAndColorViewModel> defaultTimeAndColorList = dataTable.AsEnumerable().Select(dtRow => new TimeAndColorViewModel()
                {
                    ScheduleTimePeriod = dtRow.Field<string>("ScheduleTimePeriod"),
                    ScheduleColorView = dtRow.Field<string>("ScheduleColorView")
                }).ToList();
                return defaultTimeAndColorList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
    }
}
