﻿using LAM.PMPM.DAL;
using LAM.PMPM.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace LAM.PMPM.BL
{
    public class AuditItemBL
    {
        public object GetAuditCategory(string connString)
        {
            DataTable dataTable;

            dataTable = SqlHelper.GetDataTable(connString, "uspGetAuditCategory");

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
            {
                AuditCategoryId = dtRow.Field<long?>("AuditCategoryId"),
                OptionName = dtRow.Field<string>("OptionName")
            }).ToList();

            return masterRecords;
        }

        public object GetAuditCause(string connString)
        {
            DataTable dataTable;

            dataTable = SqlHelper.GetDataTable(connString, "uspGetAuditCause");

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
            {
                AuditCauseId = dtRow.Field<long?>("AuditCauseId"),
                OptionName = dtRow.Field<string>("OptionName")
            }).ToList();

            return masterRecords;
        }

        public int CreateAuditItem(string connString, AuditItem auditItem)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@Description", auditItem.Description),
                    new SqlParameter("@AuditCategoryId",  auditItem.AuditCategoryID),
                    new SqlParameter("@AuditCauseId",  auditItem.AuditCauseID),
                    new SqlParameter("@PilotProductId ",  auditItem.PilotProductID),
                    new SqlParameter("@ZoneId",  auditItem.ZoneID),
                    new SqlParameter("@OperationID",  auditItem.OperationID),
                    new SqlParameter("@UserID",  auditItem.UserId),
                    new SqlParameter("@CreatedOnDate",  auditItem.CreatedOn),
                    outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateAddAuditItem", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int UpdateAuditFile(string connString, int audititemid, string beforeafter, string filename, int isAdd)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@AuditItemId", audititemid),
                    new SqlParameter("@BeforeOrAfter", beforeafter),
                    new SqlParameter("@FileName ", filename),
                    new SqlParameter("@Add ", isAdd)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateAuditFiles", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int DeleteFile(string connString, int audititemid, string beforeafter, string azFilename, int isAdd)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@AuditItemId", audititemid),
                    new SqlParameter("@BeforeOrAfter", beforeafter),
                    new SqlParameter("@FileName ", azFilename),
                    new SqlParameter("@Add ", isAdd)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateAuditFiles", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public AuditItemViewModelNoZone GetAuditOpWithoutZone(string connString, int pilotproductid, int zoneid)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@PilotProductId", pilotproductid),
                new SqlParameter("@ZoneId", zoneid)
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetAuditOpDetails", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new AuditItemDetails
            {
                PilotProductID = dtRow.Field<long?>("PilotProductID"),
                AuditItemId = dtRow.Field<long?>("AuditItemId"),
                AuditCategoryID = dtRow.Field<long?>("AuditCategoryId"),
                AuditCategory = dtRow.Field<string>("AuditCategory"),
                AuditCauseID = dtRow.Field<long?>("AuditCauseId"),
                AuditCause = dtRow.Field<string>("AuditCause"),
                Description = dtRow.Field<string>("Description"),
                CreatedDate = dtRow.Field<DateTime?>("CreatedDate"),
                CreatedBy = dtRow.Field<string>("CreatedBy"),
                CompletedBy = dtRow.Field<string>("CompletedBy"),
                BeforePicture = dtRow.Field<string>("BeforePicture").Split("|").Where(x => !string.IsNullOrEmpty(x)).ToList(),
                AfterPicture = dtRow.Field<string>("AfterPicture").Split("|").Where(x => !string.IsNullOrEmpty(x)).ToList(),
                Action = dtRow.Field<string>("Action"),
                IsOpen = dtRow.Field<bool?>("IsOpen"),
                ZoneID = dtRow.Field<long?>("ZoneID"),
                ZoneDescription = dtRow.Field<string>("ZoneDescription"),
                ZoneName = dtRow.Field<string>("ZoneDescription"),
                OperationID = dtRow.Field<long?>("OperationID"),
                OperationDescription = dtRow.Field<string>("OperationDescription"),
                WorkRecordID = dtRow.Field<long?>("WorkRecordID"),
                UserId = dtRow.Field<long?>("UserId"),
                StartTimestamp = dtRow.Field<DateTime?>("StartTimestamp")
            }).ToList();

            AuditItemViewModelNoZone auditItemViewModelNoZone = new AuditItemViewModelNoZone()
            {
                Open = masterRecords.Where(x => x.IsOpen.Value == true).ToList(),
                Close = masterRecords.Where(x => x.IsOpen.Value == false).ToList(),
                WorkRecordID = masterRecords.Max(x => x.WorkRecordID),
                UserId = masterRecords.Max(x => x.UserId)
            };

            return auditItemViewModelNoZone;
        }

        public object GetAuditOpByZone(string connString, int pilotproductid)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@PilotProductId", pilotproductid)
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetAuditOpDetailsByZone", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new AuditItemDetails
            {
                PilotProductID = dtRow.Field<long?>("PilotProductID"),
                AuditItemId = dtRow.Field<long?>("AuditItemId"),
                AuditCategoryID = dtRow.Field<long?>("AuditCategoryId"),
                AuditCategory = dtRow.Field<string>("AuditCategory"),
                AuditCauseID = dtRow.Field<long?>("AuditCauseId"),
                AuditCause = dtRow.Field<string>("AuditCause"),
                Description = dtRow.Field<string>("Description"),
                CreatedDate = dtRow.Field<DateTime?>("CreatedDate"),
                CreatedBy = dtRow.Field<string>("CreatedBy"),
                CompletedBy = dtRow.Field<string>("CompletedBy"),
                BeforePicture = dtRow.Field<string>("BeforePicture").Split("|").Where(x => !string.IsNullOrEmpty(x)).ToList(),
                AfterPicture = dtRow.Field<string>("AfterPicture").Split("|").Where(x => !string.IsNullOrEmpty(x)).ToList(),
                Action = dtRow.Field<string>("Action"),
                IsOpen = dtRow.Field<bool?>("IsOpen"),
                ZoneID = dtRow.Field<long?>("ZoneID"),
                OperationID = dtRow.Field<long?>("OperationId"),
                ZoneDescription = dtRow.Field<string>("ZoneDescription"),
                ZoneName = dtRow.Field<string>("ZoneName"),
                WorkRecordID = dtRow.Field<long?>("WorkRecordID"),
                UserId = dtRow.Field<long?>("UserId"),
                StartTimestamp = dtRow.Field<DateTime?>("StartTimestamp")
            }).ToList();

            var groupsZone = masterRecords.GroupBy(x => new { x.ZoneID, x.ZoneDescription, x.ZoneName }).ToList();

            AuditItemViewModelZone auditItemViewModelZone = new AuditItemViewModelZone();
            List<ZoneBrief> allZones = new List<ZoneBrief>();
            List<ZoneItems> zoneItemsOpen = new List<ZoneItems>();
            List<ZoneItems> zoneItemsClose = new List<ZoneItems>();
            groupsZone.ForEach(x =>
            {
                
                if (x.Where(z => z.IsOpen.Value == true && z.AuditItemId.HasValue).Count() > 0)
                {
                    zoneItemsOpen.Add(new ZoneItems()
                    {
                        AuditItems = x.Where(z => z.AuditItemId.HasValue).Where(z => z.IsOpen.Value == true).ToList(),
                        ZoneID = x.Key.ZoneID,
                        ZoneDescription = x.Key.ZoneDescription,
                        ZoneName = x.Key.ZoneName
                    });
                }
                
                if (x.Where(z => z.IsOpen.Value == false && z.AuditItemId.HasValue).Count() > 0)
                {
                    zoneItemsClose.Add(new ZoneItems()
                    {
                        AuditItems = x.Where(z => z.AuditItemId.HasValue).Where(z => z.IsOpen.Value == false).ToList(),
                        ZoneID = x.Key.ZoneID,
                        ZoneDescription = x.Key.ZoneDescription,
                        ZoneName = x.Key.ZoneName
                    });
                }

                allZones.Add(new ZoneBrief
                {
                    ZoneID = x.Key.ZoneID,
                    ZoneDescription = x.Key.ZoneDescription,
                    TotalAuditItems = x.Where(z => z.AuditItemId.HasValue).Count(),
                    TotalOpenItems = x.Where(z => z.AuditItemId.HasValue).Where(z => z.IsOpen.Value == true).Count()
                });

                auditItemViewModelZone.Open = zoneItemsOpen;
                auditItemViewModelZone.Close = zoneItemsClose;
                auditItemViewModelZone.AllZones = allZones;
                auditItemViewModelZone.UserId = x.Max(y => y.UserId);
                auditItemViewModelZone.WorkRecordID = x.Max(y => y.WorkRecordID);
            });

            return auditItemViewModelZone;
        }
    }
}
