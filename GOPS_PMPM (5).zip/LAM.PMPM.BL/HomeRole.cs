﻿using LAM.PMPM.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using LAM.PMPM.DAL;
using System.Linq;
using System.Data.SqlClient;

namespace LAM.PMPM.BL
{
    public class HomeRole
    {
        DataTable dataTable;

        public List<HomeRoleViewModel> GetHomeSupLaborHours(string connString, int plantID)
        {
            try
            {
                dataTable = new DataTable();
                SqlParameter[] param = {
                    new SqlParameter("@plantID", plantID),
                 };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetHomeSupLaborHours", param);
                List<HomeRoleViewModel> homeSupLaborHours = dataTable.AsEnumerable().Select(dtRow => new HomeRoleViewModel()
                {
                    UserName = dtRow.Field<string>("UserName"),
                    Description = dtRow.Field<string>("Description"),
                    PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                    StartTimestamp = dtRow.Field<DateTime?>("StartTimestamp"),
                    OperationPercent = dtRow.Field<decimal?>("OpPercent"),
                    OperationID = dtRow.Field<long?>("OperationId"),
                    UserId = dtRow.Field<long?>("UserId"),
                    PilotProductID = dtRow.Field<long?>("PilotProductID"),
                    BEN = dtRow.Field<string>("BEN"),
                    WorkRecordID = dtRow.Field<long?>("WorkRecordId"),
                    IsInterrupted = dtRow.Field<bool?>("IsInterrupted")
                }).ToList();
                return homeSupLaborHours;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public List<ModulesWIP> GetHomeWIPbuild(string connString, int plantID, int buildStyleID)
        {
            DataTable dataTable;
            SqlParameter[] param = {
                new SqlParameter("@plantID", plantID),
                  new SqlParameter("@buildStyleID", buildStyleID)
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetHomeWIPbuild", param);
            List<ModulesWIP> wipBuildlist = dataTable.AsEnumerable().Select(dtRow => new ModulesWIP()
            {
                BEN = dtRow.Field<string>("BEN"),
                PilotProductID = Convert.ToInt32(dtRow["PilotProductID"]),
                CompletePerc = dtRow.Field<string>("CompletePerc"),
                Bldg = dtRow.Field<string>("Bldg"),
                BuildingId = dtRow.Field<long?>("BuildingId"),
                BuildType = dtRow.Field<string>("BuildType"),
                Comments = dtRow.Field<string>("Comments"),
                Customer = dtRow.Field<string>("Customer"),
                CRD = dtRow.Field<DateTime?>("CRD"),
                EarliestStartDate = dtRow.Field<DateTime?>("EarliestStartDate"),
                FCID = dtRow.Field<string>("FCID"),
                IntegrationStart = dtRow.Field<DateTime?>("IntegrationStart"),
                IntegrationStartInfo = dtRow.Field<string>("IntegrationStartInfo"),
                Launch = dtRow.Field<DateTime?>("Launch"),
                LaunchInfo = dtRow.Field<string>("LaunchInfo"),
                LaunchCommit = dtRow.Field<DateTime?>("LaunchCommit"),
                LaunchDelta = dtRow.Field<int?>("LaunchDelta"),
                ManufacturingEngineer = dtRow.Field<string>("ManufacturingEngineer"),
                MCSD = dtRow.Field<DateTime?>("MCSD"),
                MCSDDelta = dtRow.Field<int?>("MCSDDelta"),
                PilotRisk = dtRow.Field<string>("PilotRisk"),
                MFGCompleteCommit = dtRow.Field<DateTime?>("MFGCompleteCommit"),
                MFGComplete = dtRow.Field<DateTime?>("MFGComplete"),
                MFGCompleteInfo = dtRow.Field<string>("MFGCompleteInfo"),
                MDGCompleteDelta = dtRow.Field<int?>("MDGCompleteDelta"),
                PBOM = dtRow.Field<string>("PBOM"),
                PilotSerialNumber = dtRow.Field<string?>("PilotSerialNumber"),
                WIPPriority = dtRow.Field<string?>("WIPPriority"),
                ProductType = dtRow.Field<string>("ProductType"),
                TestStart = dtRow.Field<DateTime?>("TestStart"),
                TestStartInfo = dtRow.Field<string>("TestStartInfo"),
                TestStartComited = dtRow.Field<DateTime?>("TestStartComited"),
                TestStartDelta = dtRow.Field<int?>("TestStartDelta"),
                TestComplete = dtRow.Field<DateTime?>("TestComplete"),
                TestCompleteInfo = dtRow.Field<string>("TestCompleteInfo"),
                TestCompleteCommit = dtRow.Field<DateTime?>("TestCompleteCommit"),
                TestEngineer = dtRow.Field<string?>("TestEngineer"),
                ToolType = dtRow.Field<string?>("ToolType"),
                Status = dtRow.Field<string>("Status"),
                TSD = dtRow.Field<DateTime?>("TSD"),
                Staffed = dtRow.Field<bool?>("Staffed"),
                Shift = dtRow.Field<string>("Shift"),
                FremontID = dtRow.Field<long?>("FremontID"),
                Idle = dtRow.Field<string>("Idle"),
                IsCritical = dtRow.Field<bool?>("IsCritical"),
                IsGating = dtRow.Field<bool?>("IsGating"),
                BuildStyle = dtRow.Field<string>("BuildStyle"),
                DayShiftOnly = dtRow.Field<bool?>("DayShiftOnly"),
                URBPBuildTypeName = dtRow.Field<string>("URBPBuildTypeName"),
                OpsApprovedForShift = dtRow.Field<string>("OpsApprovedForShift")
            }).ToList();
            return wipBuildlist;
        }

        public object GetVFDReleases(string connString, int plantID)
        {
            try
            {
                dataTable = new DataTable();
                SqlParameter[] param = {
                    new SqlParameter("@plantID", plantID)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetVFDZonesByPlant", param);

                var releases = dataTable.AsEnumerable().Select(dtRow => new
                {
                    VFDZoneId = dtRow.Field<long?>("VFDZoneId"),
                    VFDZoneName = dtRow.Field<string>("VFDZoneName"),
                }).ToList();
                return releases;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public WIPRelease GetWIPRelease(string connString, long pilotproductID)
        {
            try
            {
                DataSet dataSet;
                SqlParameter[] param = {
                    new SqlParameter("@pilotproductID", pilotproductID)
                };
                dataSet = SqlHelper.GetDataSet(connString, "uspGetWIPRelease", param);
                WIPRelease getWIPRelease = dataSet.Tables[0].AsEnumerable().Select(dtRow => new WIPRelease()
                {
                    PilotproductID = dtRow.Field<long?>("PilotproductID"),
                    BuildSchedule = dtRow.Field<int>("BuildScheduleID"),
                    ActualLaunchDate = dtRow.Field<DateTime?>("ActualLaunch"),
                    ModuleColor = dtRow.Field<string>("CapacityPlanningColor"),
                    TargetTestDays = dtRow.Field<int?>("TargetTestDays"),
                    PlannedLaunchDate = dtRow.Field<DateTime?>("PlannedLaunch"),
                    DayShiftOnly = dtRow.Field<bool?>("DayShiftOnly"),
                    CountOfShortages = dtRow.Field<int?>("CountOfShortages"),
                    BuildStyle = dtRow.Field<string>("MasterRecordName"),
                    BuildStyleID = dtRow.Field<long?>("MasterRecordID"),
                    BuildType = dtRow.Field<string>("BuildName"),
                    BuildTypeID = dtRow.Field<long?>("BuildTypeID"),
                    BENorPSNReconfiguredFrom = dtRow.Field<string>("BENorPSNReconfiguredFrom"),
                    ReworkPO = dtRow.Field<string>("ReworkPO"),
                    AddPO = dtRow.Field<string>("AddPO"),
                    DeletePO = dtRow.Field<string>("DeletePO"),
                    CurrentPartNumber = dtRow.Field<string>("CurrentPartNumber"),
                    NewPartNumber = dtRow.Field<string>("NewPartNumber"),
                    BuildingID = dtRow.Field<long?>("BuildingID"),
                    ProcessModule = dtRow.Field<int?>("ProcessModule")
                }).FirstOrDefault();

                if (getWIPRelease != null)
                {
                    List<ModuleVFDWithName> moduleVFDs = dataSet.Tables[1].AsEnumerable().Select(dtRow => new ModuleVFDWithName()
                    {
                        ModuleVFDId = dtRow.Field<long?>("ModuleVFDId"),
                        Assignable = dtRow.Field<bool?>("Assignable"),
                        BayName = dtRow.Field<string>("BayName"),
                        NumberOfDays = dtRow.Field<int?>("NumberOfDays"),
                        PilotProductId = dtRow.Field<long?>("PilotProductID"),
                        StatusId = dtRow.Field<long?>("StatusID"),
                        VFDZoneId = dtRow.Field<long?>("VFDZoneID"),
                        VFDZoneName = dtRow.Field<string>("VFDZoneName")
                    }).ToList();

                    getWIPRelease.ModuleVFDs = moduleVFDs;
                }

                return getWIPRelease;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public dynamic GetWIPStaffingMax(string connString, long plantID)
        {
            try
            {
                dataTable = new DataTable();
                SqlParameter[] param = {
                    new SqlParameter("@plantID", plantID)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetWIPStaffingMax", param);
                var getWIPRelease = dataTable.AsEnumerable().Select(row => row.Field<int>("WIPPriorityNum")).ToList().FirstOrDefault();
                return getWIPRelease;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int AddWIPRelease(string connString, WIPReleaseUpdate wipRelease, DateTime currentTime)
        {
            try
            {
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                  new SqlParameter("@pilotproductID",wipRelease.PilotproductID),
                  new SqlParameter("@actualLaunchDate",wipRelease.ActualLaunchDate),
                  new SqlParameter("@capacityColorPlanning",wipRelease.ModuleColor),
                  new SqlParameter("@targetTestDays",wipRelease.TargetTestDays),
                  new SqlParameter("@plannedLaunchDate",wipRelease.PlannedLaunchDate),
                  new SqlParameter("@DayShiftOnly",wipRelease.DayShiftOnly),
                  new SqlParameter("@BuildStyleID",wipRelease.BuildStyleID),
                  new SqlParameter("@BuildTypeID",wipRelease.BuildTypeID),
                  new SqlParameter("@BENorPSNReconfiguredFrom",wipRelease.BENorPSNReconfiguredFrom),
                  new SqlParameter("@ReworkPO",wipRelease.ReworkPO),
                  new SqlParameter("@AddPO",wipRelease.AddPO),
                  new SqlParameter("@DeletePO",wipRelease.DeletePO),
                  new SqlParameter("@CurrentPartNumber",wipRelease.CurrentPartNumber),
                  new SqlParameter("@NewPartNumber",wipRelease.NewPartNumber),
                  new SqlParameter("@BuildingID",wipRelease.BuildingID),
                  new SqlParameter("@CurrentTime", currentTime),
                  new SqlParameter("@ModuleVFDType", GetModuleVFDTable(wipRelease.ModuleVFDs)),
                  new SqlParameter("@ModifiedBy", wipRelease.ModifiedBy),
                  new SqlParameter("@ModifiedOn", wipRelease.ModifiedOn),
                  new SqlParameter("@ProcessModule", wipRelease.ProcessModule),

                    outParam
                };
                return SqlHelper.ExecuteNonQuery(connString, "uspAddWIPRelease", param);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        private DataTable GetModuleVFDTable(List<ModuleVFD> moduleVFDs)
        {
            DataTable moduleVFD = new DataTable();
            moduleVFD.Columns.Add("ModuleVFDId", typeof(long));
            moduleVFD.Columns.Add("PilotProductID", typeof(long));
            moduleVFD.Columns.Add("VFDZoneID", typeof(long));
            moduleVFD.Columns.Add("StatusID", typeof(long));
            moduleVFD.Columns.Add("BayName", typeof(string));
            moduleVFD.Columns.Add("Assignable", typeof(bool));
            moduleVFD.Columns.Add("NumberOfDays", typeof(int));

            foreach (ModuleVFD item in moduleVFDs)
            {
                moduleVFD.Rows.Add(item.ModuleVFDId, item.PilotProductId ,item.VFDZoneId, item.StatusId, item.BayName, item.Assignable, item.NumberOfDays);
            }

            return moduleVFD;
        }

        public int DeleteHomeSupRemoveUser(string connString, HomeRoleViewModel homeRoleViewModel)
        {
            try
            {
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)

                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter[] param = {

                new SqlParameter("@PilotProductID",homeRoleViewModel.PilotProductID),
                 new SqlParameter("@OperationID",homeRoleViewModel.OperationID),
                  new SqlParameter("@UserId",homeRoleViewModel.UserId),

                outParam
          };

                return SqlHelper.ExecuteNonQueryNoOutParam(connString, "uspDeleteHomeSupRemoveUser", param);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public List<CriticalGatingIssueLogModel> GetCriticalGating(string connString, int PlantID)
        {
            try
            {
                dataTable = new DataTable();
                SqlParameter[] sp = {
                    new SqlParameter("@PlantID",PlantID),
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetCriticalGating", sp);
                List<CriticalGatingIssueLogModel> CriticalGating = dataTable.AsEnumerable().Select(dtRow => new CriticalGatingIssueLogModel()
                {
                    PilotProductID = dtRow.Field<long>("PilotProductID"),
                    PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                    BEN = dtRow.Field<string>("BEN"),
                    ProductionOrderNum = dtRow.Field<string>("ProductionOrderNum"),
                    Urgency = dtRow.Field<string>("Urgency"),
                    Title = dtRow.Field<string>("Title"),
                    IssueDescription = dtRow.Field<string>("IssueDescription"),
                    ExpectedCloseDate = dtRow.Field<DateTime?>("ExpectedCloseDate"),
                    GatingDate = dtRow.Field<DateTime?>("GatingDate"),
                    Comments = dtRow.Field<string>("Comments")
                }).ToList();
                return CriticalGating;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public List<SafetyLineDownIssueLogModel> GetSafetyAndLineDown(string connString, int PlantID)
        {
            try
            {
                dataTable = new DataTable();
                SqlParameter[] sp = {
                    new SqlParameter("@PlantID",PlantID),
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetSafetyLineDown", sp);
                List<SafetyLineDownIssueLogModel> SafetyLineDown = dataTable.AsEnumerable().Select(dtRow => new SafetyLineDownIssueLogModel()
                {
                    PilotProductID = dtRow.Field<long?>("PilotProductID"),
                    DateCreated = dtRow.Field<DateTime?>("DateCreated"),
                    Status = dtRow.Field<string>("Status"),
                    Urgency = dtRow.Field<string>("Urgency"),
                    IssueLogNum = dtRow.Field<string>("IssueLogNum"),
                    SerialNo = dtRow.Field<string>("SerialNo"),
                    BEN = dtRow.Field<string>("BEN"),
                    IssueTitle = dtRow.Field<string>("IssueTitle"),
                    IssueType = dtRow.Field<string>("IssueType"),
                    ProductDesignCategory = dtRow.Field<string>("ProductDesignCategory"),
                    ToolSerial = dtRow.Field<string>("ToolSerial")
                }).ToList();
                return SafetyLineDown;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
    }
}
