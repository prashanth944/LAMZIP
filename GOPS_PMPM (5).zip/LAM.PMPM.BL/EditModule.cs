﻿using LAM.PMPM.DAL;
using LAM.PMPM.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using LAM.PMPM.Model;

namespace LAM.PMPM.BL
{
    public class EditModule
    {
        public int UpdateMyModule(string connString, EditModuleViewModel modules)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@PilotProductID", modules.PilotProductID),
                    new SqlParameter("@BuildStyleId",  modules.BuildStyleId),
                    new SqlParameter("@ProductionStatus",  modules.ProductionStatus),
                    new SqlParameter("@PilotRiskLevel ",  modules.PilotRiskLevel ),
                    new SqlParameter("@BuildTypeID",  modules.BuildTypeID),
                    new SqlParameter("@ToolTypeID",  modules.ToolTypeID),
                    new SqlParameter("@PilotToolType", modules.PilotToolType),
                    new SqlParameter("@ProductGroupId ",  modules.ProductGroupId ),
                    new SqlParameter("@Customer",  modules.Customer),
                    new SqlParameter("@RecordType",  modules.RecordType),
                    new SqlParameter("@CapacityPlanningColor",  modules.CapacityPlanningColor),
                    new SqlParameter("@ProductManager",  modules.ProductManager),
                    new SqlParameter("@ProgramManager",  modules.ProgramManager),
                    new SqlParameter("@SystemProjectManager",  modules.SystemProjectManager),
                    new SqlParameter("@Scheduler",  modules.Scheduler),
                    new SqlParameter("@ManufacturingEngineer",  modules.ManufacturingEngineer),
                    new SqlParameter("@TestEngineer",  modules.TestEngineer),
                    new SqlParameter("@Note",  modules.Note),
                    new SqlParameter("@TestDate",  modules.TestDate),
                    new SqlParameter("@Qty",  modules.Qty),
                    new SqlParameter("@DemandTypeID",  modules.DemandTypeID),
                    new SqlParameter("@PCWOReleased",  modules.PCWOReleased),
                    new SqlParameter("@Hot",  modules.hot),
                    new SqlParameter("@SpclProcess",  modules.SpclProcess),
                    new SqlParameter("@PlannerName",  modules.PlannerName),
                    new SqlParameter("@EngineeringPOC",  modules.EngineeringPOC),
                    new SqlParameter("@TechBuild",  modules.TechBuild),
                    new SqlParameter("@TechTest",  modules.TechTest),
                    new SqlParameter("@Auditor",  modules.Auditor),
                    new SqlParameter("@SerialNum",  modules.SerialNum),
                    new SqlParameter("@Rework",  modules.Rework),
                    new SqlParameter("@ProcessModule",  modules.ProcessModule),
                    new SqlParameter("@ModifiedBy",  modules.ModifiedBy),
                    new SqlParameter("@ModifiedOn",  modules.ModifiedOn),
                    outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspEditMyModule", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int UpdateMyModule(string connString, EditModuleViewModelStandard modules, int pilotProductId)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@PilotProductID", pilotProductId),
                    new SqlParameter("@BuildStyleId",  modules.BuildStyleId),
                    new SqlParameter("@PilotRiskLevel ",  modules.PilotRiskLevel ),
                    new SqlParameter("@BuildTypeID",  modules.BuildTypeID),
                    new SqlParameter("@ProductGroupId ",  modules.ProductGroupId ),
                    new SqlParameter("@Customer",  modules.Customer),
                    new SqlParameter("@RecordType",  modules.RecordType)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspEditMyModuleStandard", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public EditModuleViewModel GetMyModuleSummary(string connString, int pilotProductID)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
               new SqlParameter("@PilotProductID",pilotProductID)
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetMyModuleSummaryById", param);

            EditModuleViewModel masterRecords = dataTable.AsEnumerable().Select(dtRow => new EditModuleViewModel()
            {
                PilotProductID = dtRow.Field<long?>("PilotProductID"),
                BuildStyleId = dtRow.Field<int?>("BuildStyleId"),
                BuildStyle = dtRow.Field<string>("BuildStyle"),
                BEN = dtRow.Field<string>("BEN"),
                PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                FCID = dtRow.Field<string>("FCID"),
                Status = dtRow.Field<string>("Status"),
                ProductionStatus = dtRow.Field<string>("ProductionStatus"),
                PilotRiskLevel = dtRow.Field<string>("PilotRiskLevel"),
                BuildTypeID = dtRow.Field<long?>("BuildTypeID"),
                BuildTypeName = dtRow.Field<string>("BuildName"),
                ToolTypeID = dtRow.Field<long?>("ToolTypeID"),
                ToolTypeName = dtRow.Field<string>("ToolTypeName"),
                PilotToolType = dtRow.Field<string>("PilotToolType"),
                ProductGroupId = dtRow.Field<long?>("ProductGroupId"),
                ProductName = dtRow.Field<string>("ProductName"),
                Customer = dtRow.Field<string>("Customer"),
                RecordType = dtRow.Field<string>("RecordType"),
                RevenueCode = dtRow.Field<string>("RevenueCode"),
                CapacityPlanningColor = dtRow.Field<string>("CapacityPlanningColor"),
                PurchaseOrderNumber = dtRow.Field<string>("PurchaseOrderNumber"),
                SalesOrderNumber = dtRow.Field<string>("SalesOrderNumber"),
                BOMNumber = dtRow.Field<string>("BOMNumber"),
                ProductManager = dtRow.Field<string>("ProductManager"),
                ProgramManager = dtRow.Field<string>("ProgramManager"),
                SystemProjectManager = dtRow.Field<string>("SystemProjectManager"),
                Scheduler = dtRow.Field<string>("Scheduler"),
                ManufacturingEngineer = dtRow.Field<string>("ManufacturingEngineer"),
                TestEngineer = dtRow.Field<string>("TestEngineer"),
                Note = dtRow.Field<string>("Note"),
                FremontID = dtRow.Field<long?>("FremontID"),
                InWIP = dtRow.Field<bool?>("InWIP"),
                PO = dtRow.Field<string>("PO"),
                DivisionID = dtRow.Field<long?>("DivisionID"),
                DivisionName = dtRow.Field<string>("DivisionName"),
                PartNumber = dtRow.Field<string>("PartNumber"),
                SerialNum = dtRow.Field<string>("SerialNum"),
                Qty = dtRow.Field<int?>("Qty"),
                DemandTypeID = dtRow.Field<long?>("DemandTypeID"),
                partDescription = dtRow.Field<string>("partDescription"),
                PCWOReleased = dtRow.Field<bool?>("PCWOReleased"),
                hot = dtRow.Field<bool?>("hot"),
                Rework = dtRow.Field<bool?>("Rework"),
                SpclProcess = dtRow.Field<bool?>("SpclProcess"),
                PlannerName = dtRow.Field<string>("PlannerName"),
                EngineeringPOC = dtRow.Field<string>("EngineeringPOC"),
                TechBuild = dtRow.Field<string>("TechBuild"),
                TechTest = dtRow.Field<string>("TechTest"),
                Auditor = dtRow.Field<string>("Auditor"),
                BENorPSNReconfiguredFrom = dtRow.Field<string>("BENorPSNReconfiguredFrom"),
                ProcessModule = dtRow.Field<int?>("ProcessModule")
            }).FirstOrDefault();
            return masterRecords;
        }

        public List<ModuleVFDWithName> GetModuleVFDSummary(string connString, int pilotProductID)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
                new SqlParameter("@PPId", pilotProductID)
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetModuleVFDByPPId", param);
            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new ModuleVFDWithName
            {
                BayName = dtRow.Field<string>("Bay"),
                VFDZoneName = dtRow.Field<string>("Zone")
            }).ToList();
            return masterRecords;
        }

        public object GetReworkLog(string connString, int pilotProductID)
        {
            DataTable dataTable;
            Regex rg = new Regex(@"\d+");
            SqlParameter[] param =
            {
               new SqlParameter("@PilotProductID",pilotProductID)
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetModuleReworkLog", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
            {
                WorkRecordID = dtRow.Field<long?>("WorkRecordID"),
                PilotProductID = dtRow.Field<long?>("PilotProductID"),
                OperationID = dtRow.Field<long?>("OperationID"),
                Operation = dtRow.Field<string>("Operation"),
                OperationNumber = string.IsNullOrEmpty(dtRow.Field<string>("Operation")) ? "99999" : rg.Match(dtRow.Field<string>("Operation")).Value,
                ZoneID = dtRow.Field<long?>("ZoneID"),
                ZoneDescription = dtRow.Field<string>("ZoneDescription"),
                ReworkDescription = dtRow.Field<string>("ReworkDescription"),
                ReworkTechnician = dtRow.Field<string>("ReworkTechnician"),
                IsOBC = dtRow.Field<bool?>("IsOBC"),
                IsOBCText = dtRow.Field<bool?>("IsOBC").HasValue ? dtRow.Field<bool?>("IsOBC").Value ? "Yes" : "No" : "",
                RWCause = dtRow.Field<string>("RWCause"),
                StartTimestamp = dtRow.Field<DateTime?>("StartTimestamp"),
                EndTimestamp = dtRow.Field<DateTime?>("EndTimestamp"),
                ReworkDuration = dtRow.Field<int?>("RWDuration"),
                InterruptionMinutes = dtRow.Field<int?>("InterruptionMinutes"),
                ReworkCategoryId = dtRow.Field<long?>("ReworkCategoryId"),
                OptionName = dtRow.Field<string>("OptionName"),
                ReworkNumber = dtRow.Field<int?>("ReworkNumber")
            });
            return masterRecords;
        }

        public List<ModuleVFDWithName> GetModuleReleases(string connString, int pilotProductId)
        {
            try
            {
                DataTable dataTable;

                SqlParameter[] param =
                {
                   new SqlParameter("@PilotProductID",pilotProductId)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetModuleVFDReleases", param);

                List<ModuleVFDWithName> moduleVFDs = dataTable.AsEnumerable().Select(dtRow => new ModuleVFDWithName()
                {
                    ModuleVFDId = dtRow.Field<long?>("ModuleVFDId"),
                    Assignable = dtRow.Field<bool?>("Assignable"),
                    BayName = dtRow.Field<string>("BayName"),
                    NumberOfDays = dtRow.Field<int?>("NumberOfDays"),
                    PilotProductId = dtRow.Field<long?>("PilotProductID"),
                    StatusId = dtRow.Field<long?>("StatusID"),
                    VFDZoneId = dtRow.Field<long?>("VFDZoneID"),
                    VFDZoneName = dtRow.Field<string>("VFDZoneName")
                }).ToList();

                return moduleVFDs;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public object GetMyModuleOperationPercent(string connString, int pilotProductID)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
               new SqlParameter("@PilotProductID", pilotProductID),

            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetTestPostTestPercent", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
            {
                ModuleProcess = dtRow.Field<string>("PercentType"),
                Percent = dtRow.Field<int>("Percentage")
            }).FirstOrDefault();
            return masterRecords;
        }

        public List<OperationViewUIModel> GetMyModuleOperation(string connString, int pilotProductID, int userId)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
               new SqlParameter("@PilotProductID", pilotProductID),
               new SqlParameter("@UserId", userId)
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetMyModuleOperationByPPId", param);
            Regex rg = new Regex(@"\d+");

            List<OperationViewUIModel> operationViewUIModels = new List<OperationViewUIModel>();

            List<OperationViewModel> masterRecords = dataTable.AsEnumerable().Select(dtRow => new OperationViewModel()
            {
                PilotProductID = dtRow.Field<long?>("PilotProductID"),
                UserId = dtRow.Field<long?>("UserId"),
                CycleTimeHours = dtRow.Field<double?>("CycleTimeMinutes"),
                OPSDescription = string.IsNullOrEmpty(dtRow.Field<string>("OperationDescription")) ? "" : dtRow.Field<string>("OperationDescription"),
                NumberOfSteps = dtRow.Field<int?>("NumberofSteps"),
                OperationId = dtRow.Field<long?>("OperationID"),
                OPPercent = dtRow.Field<decimal?>("OpPercent"),
                ZoneDescription = dtRow.Field<string>("ZoneDescription"),
                ModuleProcess = dtRow.Field<string>("ModuleProcess"),
                Action = dtRow.Field<string>("Action"),
                StepsCompleteTime = dtRow.Field<double?>("StepsCompleteTime"),
                TotalStepsTime = dtRow.Field<double?>("TotalStepsTime"),
                ZoneId = dtRow.Field<long?>("ZoneId"),
                ModuleProcessId = dtRow.Field<long?>("ModuleProcessId"),
                ZoneOrder = dtRow.Field<int?>("ZoneOrder"),
                IsAudit = dtRow.Field<bool?>("IsAudit"),
                DayNightApproved = dtRow.Field<string>("DayNightApproved"),
                Status = dtRow.Field<string>("OperationStatus"),
                TestPercent = dtRow.Field<double?>("TestPercent"),
                PostTestPercent = dtRow.Field<double?>("PostTestPercent"),
            }).ToList();


            var groups = masterRecords.GroupBy(x => new { x.ModuleProcess, x.ModuleProcessId });
            groups.ToList().ForEach(x =>
            {
                List<Zone> zonesList = new List<Zone>();
                var zones = x.GroupBy(z => new { z.ZoneId, z.ZoneDescription }).ToList();
                zones.ForEach(zone =>
                {
                    List<Operation> operations = new List<Operation>();
                    zone.ToList().ForEach(op =>
                    {
                        operations.Add(new Operation()
                        {
                            OperationId = op.OperationId,
                            OPSDescription = op.OPSDescription,
                            UserId = op.UserId,
                            PilotProductID = op.PilotProductID,
                            NumberOfSteps = op.NumberOfSteps,
                            CycleTimeMinutes = op.CycleTimeHours,
                            OPPercent = op.OPPercent,
                            Action = op.Action,
                            WorkRecordId = op.WorkRecordId,
                            StepsCompleteTime = op.StepsCompleteTime,
                            TotalStepsTime = op.TotalStepsTime,
                            IsAudit = op.IsAudit,
                            DayNightApproved = op.DayNightApproved,
                            Status = op.Status,
                            Order = string.IsNullOrEmpty(op.OPSDescription) ? 99999 : string.IsNullOrEmpty(rg.Match(op.OPSDescription).Value.Trim()) ? 99999 : Convert.ToInt32(rg.Match(op.OPSDescription).Value)
                        });

                        operations.RemoveAll(x => x.OperationId == null);
                    });
                    zonesList.Add(new Zone
                    {
                        ZoneDescription = zone.Key.ZoneDescription,
                        ZoneId = zone.Key.ZoneId,
                        Operations = operations.OrderBy(x => x.Order).ToList(),
                        CycleTimeMinutesSum = operations.Sum(x => x.CycleTimeMinutes),
                        CycleTimeMinutesAvg = operations.Average(x => x.CycleTimeMinutes),
                        TotalSteps = operations.Sum(x => x.NumberOfSteps),
                        ZoneOPPercent = operations.Sum(x => x.CycleTimeMinutes) == 0 ? 0 : operations.Sum(x => Convert.ToDouble(x.OPPercent) * x.CycleTimeMinutes / 100) / operations.Sum(x => x.CycleTimeMinutes) * 100
                    });

                });

                operationViewUIModels.Add(new OperationViewUIModel()
                {
                    ModuleProcess = x.Key.ModuleProcess,
                    ModuleProcessId = x.Key.ModuleProcessId,
                    Zones = zonesList.OrderBy(x => x.ZoneOrder).ToList(),
                    PercentComplete = x.Key.ModuleProcess == "Test" ? x.FirstOrDefault().TestPercent : x.Key.ModuleProcess == "Post-test" ? x.FirstOrDefault().PostTestPercent :
                    zonesList.Sum(zl => zl.Operations.Sum(op => op.CycleTimeMinutes)) == 0 ? 0 : zonesList.Sum(zl => zl.Operations.Sum(op => Convert.ToDouble(op.OPPercent) * op.CycleTimeMinutes / 100)) / zonesList.Sum(zl => zl.Operations.Sum(op => op.CycleTimeMinutes)) * 100
                });
            }
            );


            return operationViewUIModels.OrderBy(x => x.ModuleProcessId).ToList();
        }

        public int UpdateOperation(string connString, OperationViewModel operation, int operationId)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@OperationId", operationId),
                    new SqlParameter("@NumberOfSteps",  operation.NumberOfSteps)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateOperationSteps", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int UpdateWorkRecord(string connString, WorkRecordViewModel workrecord)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                if (workrecord.EndOrResume)
                {
                    SqlParameter[] param = {
                    new SqlParameter("@UserId", workrecord.UserId),
                    new SqlParameter("@PilotProductID",  workrecord.PilotProductID),
                    new SqlParameter("@OperationId",  workrecord.OperationId),
                    new SqlParameter("@EndDateTime",  workrecord.EndDateTime),
                    new SqlParameter("@IsRework",  workrecord.IsRework),
                    new SqlParameter("@IsAudit",  workrecord.IsAudit),
                    new SqlParameter("@AuditItemId",  workrecord.AuditItemId),
                    outParam
                    };
                    resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateWorkRecordEndtDateTime", param);
                }
                else
                {
                    SqlParameter[] param = {
                    new SqlParameter("@UserId", workrecord.UserId),
                    new SqlParameter("@PilotProductID",  workrecord.PilotProductID),
                    new SqlParameter("@OperationId",  workrecord.OperationId),
                    new SqlParameter("@StartDateTime ",  workrecord.StartDateTime),
                    new SqlParameter("@IsRework",  workrecord.IsRework),
                    new SqlParameter("@IsAudit",  workrecord.IsAudit),
                    new SqlParameter("@AuditItemId",  workrecord.AuditItemId),
                    outParam
                    };
                    resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateWorkRecordStartDateTime", param);
                }
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public int UpdateMyModuleProductionStatus(string connString, int pilotProductID)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@PilotProductID",pilotProductID),

                    outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateModuleProductionStatus", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int UpdateAuditOperationComplete(string connString, int operationId, int pilotproductid)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@OperationID", operationId),
                    new SqlParameter("@PilotProductId", pilotproductid),
                    outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateOperationAuditComplete", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public EditModuleAdminViewModel GetEditModuleAdminSummary(string connString, int pilotProductID)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
               new SqlParameter("@PilotProductID",pilotProductID)
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetEditModuleAdminById", param);

            EditModuleAdminViewModel masterRecords = dataTable.AsEnumerable().Select(dtRow => new EditModuleAdminViewModel()
            {
                PilotProductID = dtRow.Field<long?>("PilotProductID"),
                PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                BuildPlanPacketLoaded = dtRow.Field<bool?>("BuildPlanPacketLoaded"),

                Code = dtRow.Field<string>("Code"),
                POM = dtRow.Field<string>("POM"),
                ChamberReleased = dtRow.Field<bool?>("ChamberReleased"),
                SubFrameReleased = dtRow.Field<bool?>("SubFrameReleased"),
                EnclosureReleased = dtRow.Field<bool?>("EnclosureReleased"),
                TopPlateReleased = dtRow.Field<bool?>("TopPlateReleased"),
                Status = dtRow.Field<string>("Status"),
                ProductionStatus = dtRow.Field<string>("ProductionStatus"),
                InWip = dtRow.Field<bool?>("InWIP")

            }).FirstOrDefault();
            return masterRecords;
        }

        public List<MasterRecords> GetVFDAssignmentStatusDLL(string connString)
        {
            try
            {

                DataTable dataTable = new DataTable();
                dataTable = SqlHelper.GetDataTable(connString, "uspGetVFDAssignmentStatus", null);
                List<MasterRecords> masterRecords = dataTable.AsEnumerable().Select(dtRow => new MasterRecords()
                {
                    MasterRecordID = Convert.ToInt32(dtRow["MasterRecordID"]),
                    MasterRecordName = Convert.ToString(dtRow["MasterRecordName"]),
                }).ToList();
                return masterRecords;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }



        public List<EditModuleAdminVFDAssignmentTable> GetVFDAssignmentTable(string connString, int pilotProductID)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param =
                {
               new SqlParameter("@PilotProductID",pilotProductID)
               };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetVFDAssignmentTableById", param);
                List<EditModuleAdminVFDAssignmentTable> masterRecords = dataTable.AsEnumerable().Select(dtRow => new EditModuleAdminVFDAssignmentTable()
                {
                    PilotProductID = dtRow.Field<long?>("PilotProductID"),
                    VFDZoneID = dtRow.Field<long?>("ZoneID"),
                    ZoneName = dtRow.Field<string>("ZoneName"),
                    VFDStatusID = dtRow.Field<long?>("StatusID"),
                    Status = dtRow.Field<string>("Status"),
                    BayName = dtRow.Field<string>("BayName"),
                    Assignable = dtRow.Field<bool?>("Assignable"),
                    IsAssignable = dtRow.Field<bool?>("Assignable").HasValue ? dtRow.Field<bool?>("Assignable").Value ? "Yes" : "No" : "",
                    CapacityPlanningColor = dtRow.Field<string>("CapacityPlanningColor")

                }).ToList();
                return masterRecords;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int UpdateEditModAdmin(string connString, EditModuleAdminViewModelStandard modules)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@PilotProductId",  modules.pilotProductId),
                    new SqlParameter("@ModuleVFDType", GetModuleVFDTable(modules.ModuleVFDs))
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspEditMyModuleAdminStandard", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        private DataTable GetModuleVFDTable(List<ModuleVFD> moduleVFDs)
        {
            DataTable moduleVFD = new DataTable();
            moduleVFD.Columns.Add("ModuleVFDId", typeof(long));
            moduleVFD.Columns.Add("PilotProductID", typeof(long));
            moduleVFD.Columns.Add("VFDZoneID", typeof(long));
            moduleVFD.Columns.Add("StatusID", typeof(long));
            moduleVFD.Columns.Add("BayName", typeof(string));
            moduleVFD.Columns.Add("Assignable", typeof(bool));
            moduleVFD.Columns.Add("NumberOfDays", typeof(int));

            foreach (ModuleVFD item in moduleVFDs)
            {
                moduleVFD.Rows.Add(item.ModuleVFDId, item.PilotProductId, item.VFDZoneId, item.StatusId, item.BayName, item.Assignable, item.NumberOfDays);
            }

            return moduleVFD;
        }

        public int UpdateEditModAdminVFDAssignment(string connString, EditModuleAdminVFDAssignmentTable[] VFDTable)
        {
            var resultCount = 0;
            var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            try
            {
                foreach (var items in VFDTable)
                {
                    SqlParameter[] param = {
               new SqlParameter("@PilotProductID", items.PilotProductID),
                    new SqlParameter("@StatusID",  items.VFDStatusID),
                    new SqlParameter("@BayName ",  items.BayName ),
                    new SqlParameter("@VFDZoneID",  items.VFDZoneID),
                 outParam

            };

                    resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateVFDAssignmentTableData", param);
                }
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<EditModuleAdminVFDAssignmentTable> GetVFDAssignmentBayDLL(string connString)
        {
            DataTable dataTable = new DataTable();
            dataTable = SqlHelper.GetDataTable(connString, "uspGetVFDAssignmentBay", null);
            List<EditModuleAdminVFDAssignmentTable> masterRecords = dataTable.AsEnumerable().Select(dtRow => new EditModuleAdminVFDAssignmentTable()
            {

                BayName = dtRow.Field<string>("Bayname")
            }).ToList();
            return masterRecords;
        }


        public List<EditModuleViewModel> GetTimeViewDDL(string connString)
        {
            try
            {
                DataTable dataTable;
                dataTable = SqlHelper.GetDataTable(connString, "uspGetTimeViewDDL", null);
                List<EditModuleViewModel> masterRecords = dataTable.AsEnumerable().Select(dtRow => new EditModuleViewModel()
                {
                    ProcessModule = Convert.ToInt32(dtRow["ProcessModule"])
                }).ToList();
                return masterRecords;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }





        #region OpsMgmt
        public object GetModuleProcess(string connString, int pilotProductID)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
               new SqlParameter("@PilotProductID", pilotProductID),

            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetOPMGModuleProcessByPPId", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
            {
                ModuleProcessID = dtRow.Field<long?>("ModuleProcessID"),
                ModuleProcess = dtRow.Field<string>("ModuleProcess")
            }).ToList();
            return masterRecords;
        }


        public object GetZonesOfModuleProcess(string connString, int pilotProductID, int moduleprocessid)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
               new SqlParameter("@PilotProductID", pilotProductID),
               new SqlParameter("@ModuleProcessId", moduleprocessid)
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetOPMGZonesOfMPByPPId", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
            {
                ZoneID = dtRow.Field<long?>("ZoneID"),
                ZoneDescription = dtRow.Field<string>("ZoneDescription")
            }).ToList();
            return masterRecords;
        }

        public List<OPSMGUIModel> GetOPMGOperations(string connString, int pilotProductID, DateTime todaydate)
        {
            try
            {
                bool IsFeederLine = false;
                bool IsEnclosure = false;
                bool IsChamber = false;
                bool IsSubframe = false;
                bool IsToplate = false;
                DataSet dataSet;
                SqlParameter[] param =
                {
               new SqlParameter("@PilotProductID", pilotProductID),
            };
                dataSet = SqlHelper.GetDataSet(connString, "uspGetOPMGOperationByZone", param);
                Regex rg = new Regex(@"\d+");

                List<OPSMGUIModel> operationViewUIModels = new List<OPSMGUIModel>();

                var masterRecords = dataSet.Tables[0].AsEnumerable().Select(dtRow => new OPSMGOperation
                {
                    PilotProductID = dtRow.Field<long?>("PilotProductID"),
                    OperationID = dtRow.Field<long?>("OperationID"),
                    DayNightApproved = dtRow.Field<string>("DayNightApproved"),
                    ModDayShiftOnly = dtRow.Field<bool?>("ModDayShiftOnly"),
                    Status = dtRow.Field<string>("OperationStatus"),
                    OpPercent = dtRow.Field<decimal?>("OpPercent"),
                    Description = dtRow.Field<string>("OPDescription"),
                    ManualOpPercent = dtRow.Field<double?>("ManualOpPercent"),
                    DayShiftOnly = dtRow.Field<bool?>("DayShiftOnly"),
                    NightShiftOnly = dtRow.Field<bool?>("NightShiftOnly"),
                    ActualPlannedStartDate = dtRow.Field<DateTime?>("ActualStartDate"),
                    CalculatedFinish = dtRow.Field<DateTime?>("CalculatedFinish"),
                    StandardTimeHours = dtRow.Field<double?>("StandardTimeHours"),
                    STOverrideReason = dtRow.Field<string>("STOverrideReason"),
                    STUpdatedBy = dtRow.Field<string?>("STUpdatedBy"),
                    STUpdatedById = dtRow.Field<long?>("STUpdatedById"),
                    CalculatedStandardTimeDays = dtRow.Field<decimal?>("CalculatedStandardTimeDays"),
                    AverageCycleTimeHours = dtRow.Field<double?>("AverageCycleTimeHours"),
                    TotalCycleTimeHours = dtRow.Field<decimal?>("TotalCycleTimeHours"),
                    TotalReworkHours = dtRow.Field<decimal?>("TotalReworkHours"),
                    ZoneID = dtRow.Field<long?>("ZoneID"),
                    Order = string.IsNullOrEmpty(dtRow.Field<string>("OPDescription")) ? 99999 : string.IsNullOrEmpty(rg.Match(dtRow.Field<string>("OPDescription")).Value.Trim()) ? 99999 : Convert.ToInt32(rg.Match(dtRow.Field<string>("OPDescription")).Value),
                    HoursPerDay = dtRow.Field<int>("HoursPerDay"),
                    ModuleProcess = dtRow.Field<string>("ModuleProcess"),
                    ModuleProcessID = dtRow.Field<long?>("ModuleProcessID"),
                    ZoneDescription = dtRow.Field<string>("ZoneDescription"),
                    ZoneName = dtRow.Field<string>("ZoneName"),
                    GatingDate = dtRow.Field<DateTime?>("GatingDate"),
                    ZoneOrder = string.IsNullOrEmpty(dtRow.Field<string>("ZoneDescription")) ? 99999 : string.IsNullOrEmpty(rg.Match(dtRow.Field<string>("ZoneDescription")).Value.Trim()) ? 99999 : Convert.ToInt32(rg.Match(dtRow.Field<string>("ZoneDescription")).Value),
                    ActualPlannedLaunch = dtRow.Field<DateTime?>("ActualPlannedLaunch"),
                    NumberOfSteps = dtRow.Field<int?>("NumberofSteps"),
                    CompletedSteps = dtRow.Field<int?>("CompletedSteps"),
                    ModuleShiftHours = dtRow.Field<int?>("ModuleShiftHours"),
                    Plant = dtRow.Field<string>("Plant")
                }).OrderBy(x => x.ZoneOrder).ThenBy(x => x.Order).ToList();

                List<ModuleVFDWithName> moduleVFDs = dataSet.Tables[1].AsEnumerable().Select(dtRow => new ModuleVFDWithName()
                {
                    ModuleVFDId = dtRow.Field<long?>("ModuleVFDId"),
                    Assignable = dtRow.Field<bool?>("Assignable"),
                    BayName = dtRow.Field<string>("BayName"),
                    NumberOfDays = dtRow.Field<int?>("NumberOfDays"),
                    PilotProductId = dtRow.Field<long?>("PilotProductID"),
                    StatusId = dtRow.Field<long?>("StatusID"),
                    VFDZoneId = dtRow.Field<long?>("VFDZoneID"),
                    VFDZoneName = dtRow.Field<string>("VFDZoneName")
                }).ToList();

                List<ModuleVFDWithName> moduleVFDAssignable = dataSet.Tables[2].AsEnumerable().Select(dtRow => new ModuleVFDWithName()
                {
                    ModuleVFDId = dtRow.Field<long?>("ModuleVFDId"),
                    Assignable = dtRow.Field<bool?>("Assignable"),
                    BayName = dtRow.Field<string>("BayName"),
                    NumberOfDays = dtRow.Field<int?>("NumberOfDays"),
                    PilotProductId = dtRow.Field<long?>("PilotProductID"),
                    StatusId = dtRow.Field<long?>("StatusID"),
                    VFDZoneId = dtRow.Field<long?>("VFDZoneID"),
                    VFDZoneName = dtRow.Field<string>("VFDZoneName")
                }).ToList();


                //if you make a change in this region, make the same change in method - GetOPMGEngineerOperations in EditModule.cs and method - SetDatesOfOperations in CommonHelper.cs
                #region Operation Dates
                //condition for gating date becuase if gating date is present and if its less than today then use today's date else use gating date
                //condition for actualLaunchdate because same as gating date if less than today then use today's date
                masterRecords.GroupBy(x => x.ZoneID).ToList().ForEach(x =>
                {
                    if (x.ToList().Count > 0)
                    {
                        x.ToList().FirstOrDefault().FirstInZone = true;
                        x.ToList().LastOrDefault().DaysRemainingInZone = x.ToList().Sum(zz => (zz.StandardTimeHours - ((zz.StandardTimeHours / (zz.NumberOfSteps == 0 ? 1 : zz.NumberOfSteps)) * zz.CompletedSteps)) / zz.ModuleShiftHours);
                        x.ToList().LastOrDefault().LastInZone = true;
                    }
                });

                if (masterRecords.Count > 0)
                {
                    if (!masterRecords[0].ActualPlannedStartDate.HasValue)
                    {
                        if (masterRecords[0].ZoneName.ToLower() == "Chamber_SF Integration".ToLower())
                        {
                            //chamber in split because only need zone with chamber word
                            masterRecords[0].ActualPlannedStartDate = (masterRecords[0].GatingDate.HasValue ? (masterRecords[0].GatingDate < todaydate ? todaydate : masterRecords[0].GatingDate) : null) ?? (masterRecords
                                .Where(x => x.ZoneName.ToLower() == "Chamber".ToLower() || x.ZoneName.ToLower() == "Sub Frame".ToLower())
                                .Count() > 0 ? masterRecords
                                .Where(x => x.ZoneName.ToLower() == "Chamber".ToLower() || x.ZoneName.ToLower() == "Sub Frame".ToLower())
                                .Max(x => x.CalculatedFinish) : todaydate);
                            masterRecords[0].CalculatedFinish = masterRecords[0].ActualPlannedStartDate.Value.AddDays(masterRecords[0].CalculatedStandardTimeDays.HasValue
                            ? Decimal.ToDouble(masterRecords[0].CalculatedStandardTimeDays.Value) : 0);
                        }
                        else if (masterRecords[0].ZoneName.ToLower() == "Chamber_Frame Integration".ToLower() && masterRecords[0].Plant.ToLower() == "Fremont".ToLower())
                        {
                            //chamber in split because only need zone with chamber word
                            masterRecords[0].ActualPlannedStartDate = (masterRecords[0].GatingDate.HasValue ? (masterRecords[0].GatingDate < todaydate ? todaydate : masterRecords[0].GatingDate) : null) ?? (masterRecords
                                .Where(x => x.ZoneName.ToLower() == "Chamber".ToLower() || x.ZoneName.ToLower() == "Frame".ToLower())
                                .Count() > 0 ? masterRecords
                                .Where(x => x.ZoneName.ToLower() == "Chamber".ToLower() || x.ZoneName.ToLower() == "Frame".ToLower())
                                .Max(x => x.CalculatedFinish) : todaydate);
                            masterRecords[0].CalculatedFinish = masterRecords[0].ActualPlannedStartDate.Value.AddDays(masterRecords[0].CalculatedStandardTimeDays.HasValue
                            ? Decimal.ToDouble(masterRecords[0].CalculatedStandardTimeDays.Value) : 0);
                        }
                        else if (masterRecords[0].ZoneName.ToLower() == "Enclosure_TP Integration".ToLower())
                        {
                            masterRecords[0].ActualPlannedStartDate = (masterRecords[0].GatingDate.HasValue ? (masterRecords[0].GatingDate < todaydate ? todaydate : masterRecords[0].GatingDate) : null) ?? (masterRecords
                                .Where(x => x.ZoneName.ToLower() == "Enclosure".ToLower() || x.ZoneName.ToLower() == "Top Plate".ToLower())
                                .Count() > 0 ? masterRecords
                                .Where(x => x.ZoneName.ToLower() == "Enclosure".ToLower() || x.ZoneName.ToLower() == "Top Plate".ToLower())
                                .Max(x => x.CalculatedFinish) : todaydate);
                            masterRecords[0].CalculatedFinish = masterRecords[0].ActualPlannedStartDate.Value.AddDays(masterRecords[0].CalculatedStandardTimeDays.HasValue
                            ? Decimal.ToDouble(masterRecords[0].CalculatedStandardTimeDays.Value) : 0);
                        }
                        else if (masterRecords[0].ZoneName.ToLower() == "TP_Canopy Integration".ToLower() && masterRecords[0].Plant.ToLower() == "Fremont".ToLower())
                        {
                            masterRecords[0].ActualPlannedStartDate = (masterRecords[0].GatingDate.HasValue ? (masterRecords[0].GatingDate < todaydate ? todaydate : masterRecords[0].GatingDate) : null) ?? (masterRecords
                                .Where(x => x.ZoneName.ToLower() == "Canopy".ToLower() || x.ZoneName.ToLower() == "Top Plate".ToLower())
                                .Count() > 0 ? masterRecords
                                .Where(x => x.ZoneName.ToLower() == "Canopy".ToLower() || x.ZoneName.ToLower() == "Top Plate".ToLower())
                                .Max(x => x.CalculatedFinish) : todaydate);
                            masterRecords[0].CalculatedFinish = masterRecords[0].ActualPlannedStartDate.Value.AddDays(masterRecords[0].CalculatedStandardTimeDays.HasValue
                            ? Decimal.ToDouble(masterRecords[0].CalculatedStandardTimeDays.Value) : 0);
                        }
                        else if (masterRecords[0].ZoneName.ToLower() == "Final Integration".ToLower())
                        {
                            masterRecords[0].ActualPlannedStartDate = (masterRecords[0].GatingDate.HasValue ? (masterRecords[0].GatingDate < todaydate ? todaydate : masterRecords[0].GatingDate) : null) ?? (masterRecords
                                .Where(x => x.ZoneName.ToLower() == "Chamber_SF Integration".ToLower() || x.ZoneName.ToLower() == "Enclosure_TP Integration".ToLower())
                                .Count() > 0 ? masterRecords
                                .Where(x => x.ZoneName.ToLower() == "Chamber_SF Integration".ToLower() || x.ZoneName.ToLower() == "Enclosure_TP Integration".ToLower())
                                .Max(x => x.CalculatedFinish) : todaydate);
                            masterRecords[0].CalculatedFinish = masterRecords[0].ActualPlannedStartDate.Value.AddDays(masterRecords[0].CalculatedStandardTimeDays.HasValue
                            ? Decimal.ToDouble(masterRecords[0].CalculatedStandardTimeDays.Value) : 0);
                        }
                        else if (masterRecords[0].ZoneName.ToLower() == "Final Integration".ToLower() && masterRecords[0].Plant.ToLower() == "Fremont".ToLower())
                        {
                            masterRecords[0].ActualPlannedStartDate = (masterRecords[0].GatingDate.HasValue ? (masterRecords[0].GatingDate < todaydate ? todaydate : masterRecords[0].GatingDate) : null) ?? (masterRecords
                                .Where(x => x.ZoneName.ToLower() == "Chamber_Frame Integration".ToLower() || x.ZoneName.ToLower() == "TP_Canopy Integration".ToLower())
                                .Count() > 0 ? masterRecords
                                .Where(x => x.ZoneName.ToLower() == "Chamber_Frame Integration".ToLower() || x.ZoneName.ToLower() == "TP_Canopy Integration".ToLower())
                                .Max(x => x.CalculatedFinish) : todaydate);
                            masterRecords[0].CalculatedFinish = masterRecords[0].ActualPlannedStartDate.Value.AddDays(masterRecords[0].CalculatedStandardTimeDays.HasValue
                            ? Decimal.ToDouble(masterRecords[0].CalculatedStandardTimeDays.Value) : 0);
                        }
                        else if (masterRecords[0].ZoneName.ToLower() == "Final Test".ToLower())
                        {
                            masterRecords[0].ActualPlannedStartDate = (masterRecords[0].GatingDate.HasValue ? (masterRecords[0].GatingDate < todaydate ? todaydate : masterRecords[0].GatingDate) : null) ?? (masterRecords
                                .Where(x => x.ZoneName.ToLower() == "Final Integration".ToLower())
                                .Count() > 0 ? masterRecords
                                .Where(x => x.ZoneName.ToLower() == "Final Integration".ToLower())
                                .Max(x => x.CalculatedFinish) : todaydate);

                            masterRecords[0].CalculatedFinish = masterRecords[0].ActualPlannedStartDate.Value.AddDays(masterRecords[0].CalculatedStandardTimeDays.HasValue
                            ? Decimal.ToDouble(masterRecords[0].CalculatedStandardTimeDays.Value) : 0);
                        }
                        else if (masterRecords[0].ZoneName.ToLower() == "Preship".ToLower() || masterRecords[0].ZoneName.ToLower() == "Pre-Ship".ToLower())
                        {
                            masterRecords[0].ActualPlannedStartDate = (masterRecords[0].GatingDate.HasValue ? (masterRecords[0].GatingDate < todaydate ? todaydate : masterRecords[0].GatingDate) : null) ?? (masterRecords
                                .Where(x => x.ZoneName.ToLower() == "Final Test".ToLower())
                                .Count() > 0 ? masterRecords
                                .Where(x => x.ZoneName.ToLower() == "Final Test".ToLower())
                                .Max(x => x.CalculatedFinish) : masterRecords[0].LastInZone ? masterRecords[0].CalculatedFinish.Value.AddDays(masterRecords[0].DaysRemainingInZone ?? 0) : masterRecords[0].CalculatedFinish.Value);

                            masterRecords[0].CalculatedFinish = masterRecords[0].ActualPlannedStartDate.Value.AddDays(masterRecords[0].CalculatedStandardTimeDays.HasValue
                            ? Decimal.ToDouble(masterRecords[0].CalculatedStandardTimeDays.Value) : 0);
                        }

                        else if (masterRecords[0].ZoneName.ToLower() == "Feeder Line".ToLower())
                        {
                            masterRecords[0].ActualPlannedStartDate = (masterRecords[0].GatingDate.HasValue ? (masterRecords[0].GatingDate < todaydate ? todaydate : masterRecords[0].GatingDate) : null) ??
                          (masterRecords[0].ActualPlannedLaunch.HasValue ?
                              (masterRecords[0].ActualPlannedLaunch
                                  < todaydate ?
                              todaydate : masterRecords[0].ActualPlannedLaunch)
                                  : todaydate);
                            masterRecords[0].CalculatedFinish = masterRecords[0].ActualPlannedStartDate.Value.AddDays(masterRecords[0].CalculatedStandardTimeDays.HasValue
                            ? Decimal.ToDouble(masterRecords[0].CalculatedStandardTimeDays.Value) : 0);

                        }
                        else if (moduleVFDAssignable.Where(x => x.VFDZoneName.ToLower() == masterRecords[0].ZoneName.ToLower() && x.Assignable == true).Count() > 0)
                        {

                            masterRecords[0].ActualPlannedStartDate = (masterRecords[0].GatingDate.HasValue ? (masterRecords[0].GatingDate < todaydate ? todaydate : masterRecords[0].GatingDate) : null) ??
                               (masterRecords[0].ActualPlannedLaunch.HasValue ?
                                   (masterRecords[0].ActualPlannedLaunch
                                       < todaydate ?
                                   todaydate : masterRecords[0].ActualPlannedLaunch)
                                       : todaydate);
                            masterRecords[0].CalculatedFinish = masterRecords[0].ActualPlannedStartDate.Value.AddDays(masterRecords[0].CalculatedStandardTimeDays.HasValue
                            ? Decimal.ToDouble(masterRecords[0].CalculatedStandardTimeDays.Value) : 0);
                        }
                        else if (moduleVFDAssignable.Where(x => x.VFDZoneName.ToLower().Contains("Frame".ToLower()) && masterRecords[0].ZoneName.ToLower().Contains("Frame".ToLower()) && x.Assignable == true && masterRecords[0].Plant.ToLower() == "Fremont".ToLower()).Count() > 0)
                        {

                            masterRecords[0].ActualPlannedStartDate = (masterRecords[0].GatingDate.HasValue ? (masterRecords[0].GatingDate < todaydate ? todaydate : masterRecords[0].GatingDate) : null) ??
                               (masterRecords[0].ActualPlannedLaunch.HasValue ?
                                   (masterRecords[0].ActualPlannedLaunch
                                       < todaydate ?
                                   todaydate : masterRecords[0].ActualPlannedLaunch)
                                       : todaydate);
                            masterRecords[0].CalculatedFinish = masterRecords[0].ActualPlannedStartDate.Value.AddDays(masterRecords[0].CalculatedStandardTimeDays.HasValue
                            ? Decimal.ToDouble(masterRecords[0].CalculatedStandardTimeDays.Value) : 0);
                        }

                        else if (moduleVFDs.Where(x => x.VFDZoneName.ToLower() == masterRecords[0].ZoneName.ToLower()).Count() > 0)
                        {
                            masterRecords[0].ActualPlannedStartDate = (masterRecords[0].GatingDate.HasValue ? (masterRecords[0].GatingDate < todaydate ? todaydate : masterRecords[0].GatingDate) : null) ??
                                (masterRecords[0].ActualPlannedLaunch.HasValue ?
                                    (masterRecords[0].ActualPlannedLaunch.Value.AddDays(moduleVFDs.Where(x => x.VFDZoneName.ToLower() == masterRecords[0].ZoneName.ToLower()).FirstOrDefault().NumberOfDays ?? 0)
                                        < todaydate ?
                                    todaydate : masterRecords[0].ActualPlannedLaunch.Value.AddDays(moduleVFDs.Where(x => x.VFDZoneName.ToLower() == masterRecords[0].ZoneName.ToLower()).FirstOrDefault().NumberOfDays ?? 0))
                                        : todaydate);
                            masterRecords[0].CalculatedFinish = masterRecords[0].ActualPlannedStartDate.Value.AddDays(masterRecords[0].CalculatedStandardTimeDays.HasValue
                            ? Decimal.ToDouble(masterRecords[0].CalculatedStandardTimeDays.Value) : 0);
                        }
                        else if (moduleVFDs.Where(x => x.VFDZoneName.ToLower().Contains("Frame".ToLower()) && masterRecords[0].ZoneName.ToLower().Contains("Frame".ToLower()) && masterRecords[0].Plant.ToLower() == "Fremont".ToLower()).Count() > 0)
                        {
                            masterRecords[0].ActualPlannedStartDate = (masterRecords[0].GatingDate.HasValue ? (masterRecords[0].GatingDate < todaydate ? todaydate : masterRecords[0].GatingDate) : null) ??
                                (masterRecords[0].ActualPlannedLaunch.HasValue ?
                                    (masterRecords[0].ActualPlannedLaunch.Value.AddDays(moduleVFDs.Where(x => x.VFDZoneName.ToLower().Contains("Frame".ToLower()) && masterRecords[0].ZoneName.ToLower().Contains("Frame".ToLower())).FirstOrDefault().NumberOfDays ?? 0)
                                        < todaydate ?
                                    todaydate : masterRecords[0].ActualPlannedLaunch.Value.AddDays(moduleVFDs.Where(x => x.VFDZoneName.ToLower().Contains("Frame".ToLower()) && masterRecords[0].ZoneName.ToLower().Contains("Frame".ToLower())).FirstOrDefault().NumberOfDays ?? 0))
                                        : todaydate);
                            masterRecords[0].CalculatedFinish = masterRecords[0].ActualPlannedStartDate.Value.AddDays(masterRecords[0].CalculatedStandardTimeDays.HasValue
                            ? Decimal.ToDouble(masterRecords[0].CalculatedStandardTimeDays.Value) : 0);
                        }
                        else
                        {
                            masterRecords[0].ActualPlannedStartDate = (masterRecords[0].GatingDate.HasValue ? (masterRecords[0].GatingDate < todaydate ? todaydate : masterRecords[0].GatingDate) : null) ?? todaydate;
                            masterRecords[0].CalculatedFinish = masterRecords[0].ActualPlannedStartDate.Value.AddDays(masterRecords[0].CalculatedStandardTimeDays.HasValue
                                ? Decimal.ToDouble(masterRecords[0].CalculatedStandardTimeDays.Value) : 0);
                        }
                    }
                    else
                    {
                        masterRecords[0].CalculatedFinish = masterRecords[0].ActualPlannedStartDate.Value.AddDays(masterRecords[0].CalculatedStandardTimeDays.HasValue
                           ? Decimal.ToDouble(masterRecords[0].CalculatedStandardTimeDays.Value) : 0);
                    }


                    for (int i = 0; i < masterRecords.Count - 1; i++)
                    {

                        if (masterRecords[i + 1].FirstInZone)
                        {
                            if (!masterRecords[i + 1].ActualPlannedStartDate.HasValue)
                            {
                                if (masterRecords[i + 1].ZoneName.ToLower() == "Chamber_SF Integration".ToLower())
                                {
                                    masterRecords[i + 1].ActualPlannedStartDate = (masterRecords[i + 1].GatingDate.HasValue ? (masterRecords[i + 1].GatingDate < todaydate ? todaydate : masterRecords[i + 1].GatingDate) : null) ?? (masterRecords
                                        .Where(x => x.ZoneName.ToLower() == "Chamber".ToLower() || x.ZoneName.ToLower() == "Sub Frame".ToLower())
                                        .Count() > 0 ? masterRecords
                                        .Where(x => x.ZoneName.ToLower() == "Chamber".ToLower() || x.ZoneName.ToLower() == "Sub Frame".ToLower()) //chamber in split because only need zone with chamber word
                                        .Max(x => x.CalculatedFinish) : masterRecords[i].LastInZone ? masterRecords[i].CalculatedFinish.Value.AddDays(masterRecords[i].DaysRemainingInZone ?? 0) : masterRecords[i].CalculatedFinish.Value); 

                                    masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                    ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                                }
                                else if (masterRecords[i + 1].ZoneName.ToLower() == "Chamber_Frame Integration".ToLower() && masterRecords[i + 1].Plant.ToLower() == "Fremont".ToLower())
                                {
                                    masterRecords[i + 1].ActualPlannedStartDate = (masterRecords[i + 1].GatingDate.HasValue ? (masterRecords[i + 1].GatingDate < todaydate ? todaydate : masterRecords[i + 1].GatingDate) : null) ?? (masterRecords
                                        .Where(x => x.ZoneName.ToLower() == "Chamber".ToLower() || x.ZoneName.ToLower() == "Frame".ToLower())
                                        .Count() > 0 ? masterRecords
                                        .Where(x => x.ZoneName.ToLower() == "Chamber".ToLower() || x.ZoneName.ToLower() == "Frame".ToLower()) //chamber in split because only need zone with chamber word
                                        .Max(x => x.CalculatedFinish) : masterRecords[i].LastInZone ? masterRecords[i].CalculatedFinish.Value.AddDays(masterRecords[i].DaysRemainingInZone ?? 0) : masterRecords[i].CalculatedFinish.Value); 

                                    masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                    ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                                }

                                else if (masterRecords[i + 1].ZoneName.ToLower() == "Enclosure_TP Integration".ToLower())
                                {
                                    masterRecords[i + 1].ActualPlannedStartDate = (masterRecords[i + 1].GatingDate.HasValue ? (masterRecords[i + 1].GatingDate < todaydate ? todaydate : masterRecords[i + 1].GatingDate) : null) ?? (masterRecords
                                        .Where(x => x.ZoneName.ToLower() == "Enclosure".ToLower() || x.ZoneName.ToLower() == "Top Plate".ToLower())
                                        .Count() > 0 ? masterRecords
                                        .Where(x => x.ZoneName.ToLower() == "Enclosure".ToLower() || x.ZoneName.ToLower() == "Top Plate".ToLower())
                                        .Max(x => x.CalculatedFinish) : masterRecords[i].LastInZone ? masterRecords[i].CalculatedFinish.Value.AddDays(masterRecords[i].DaysRemainingInZone ?? 0) : masterRecords[i].CalculatedFinish.Value);

                                    masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                    ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                                }
                                else if (masterRecords[i + 1].ZoneName.ToLower() == "TP_Canopy Integration".ToLower() && masterRecords[i + 1].Plant.ToLower() == "Fremont".ToLower())
                                {
                                    masterRecords[i + 1].ActualPlannedStartDate = (masterRecords[i + 1].GatingDate.HasValue ? (masterRecords[i + 1].GatingDate < todaydate ? todaydate : masterRecords[i + 1].GatingDate) : null) ?? (masterRecords
                                        .Where(x => x.ZoneName.ToLower() == "Canopy".ToLower() || x.ZoneName.ToLower() == "Top Plate".ToLower())
                                        .Count() > 0 ? masterRecords
                                        .Where(x => x.ZoneName.ToLower() == "Canopy".ToLower() || x.ZoneName.ToLower() == "Top Plate".ToLower())
                                        .Max(x => x.CalculatedFinish) : masterRecords[i].LastInZone ? masterRecords[i].CalculatedFinish.Value.AddDays(masterRecords[i].DaysRemainingInZone ?? 0) : masterRecords[i].CalculatedFinish.Value);

                                    masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                    ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                                }
                                else if (masterRecords[i + 1].ZoneName.ToLower() == "Final Integration".ToLower())
                                {
                                    masterRecords[i + 1].ActualPlannedStartDate = (masterRecords[i + 1].GatingDate.HasValue ? (masterRecords[i + 1].GatingDate < todaydate ? todaydate : masterRecords[i + 1].GatingDate) : null) ?? (masterRecords
                                        .Where(x => x.ZoneName.ToLower() == "Chamber_SF Integration".ToLower() || x.ZoneName.ToLower() == "Enclosure_TP Integration".ToLower())
                                        .Count() > 0 ? masterRecords
                                        .Where(x => x.ZoneName.ToLower() == "Chamber_SF Integration".ToLower() || x.ZoneName.ToLower() == "Enclosure_TP Integration".ToLower())
                                        .Max(x => x.CalculatedFinish) : masterRecords[i].LastInZone ? masterRecords[i].CalculatedFinish.Value.AddDays(masterRecords[i].DaysRemainingInZone ?? 0) : masterRecords[i].CalculatedFinish.Value);

                                    masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                    ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                                }
                                else if (masterRecords[i + 1].ZoneName.ToLower() == "Final Integration".ToLower() && masterRecords[0].Plant.ToLower() == "Fremont".ToLower())
                                {
                                    masterRecords[i + 1].ActualPlannedStartDate = (masterRecords[i + 1].GatingDate.HasValue ? (masterRecords[i + 1].GatingDate < todaydate ? todaydate : masterRecords[i + 1].GatingDate) : null) ?? (masterRecords
                                        .Where(x => x.ZoneName.ToLower() == "Chamber_Frame Integration".ToLower() || x.ZoneName.ToLower() == "TP_Canopy Integration".ToLower())
                                        .Count() > 0 ? masterRecords
                                        .Where(x => x.ZoneName.ToLower() == "Chamber_Frame Integration".ToLower() || x.ZoneName.ToLower() == "TP_Canopy Integration".ToLower())
                                        .Max(x => x.CalculatedFinish) : masterRecords[i].LastInZone ? masterRecords[i].CalculatedFinish.Value.AddDays(masterRecords[i].DaysRemainingInZone ?? 0) : masterRecords[i].CalculatedFinish.Value);

                                    masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                    ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                                }
                                #region Newly Added
                                /*Based on Final integration take latest finish date into Final test*/
                                else if (masterRecords[i + 1].ZoneName.ToLower() == "Final Test".ToLower())
                                {
                                    masterRecords[i + 1].ActualPlannedStartDate = (masterRecords[i + 1].GatingDate.HasValue ? (masterRecords[i + 1].GatingDate < todaydate ? todaydate : masterRecords[i + 1].GatingDate) : null) ?? (masterRecords
                                        .Where(x => x.ZoneName.ToLower() == "Final Integration".ToLower())
                                        .Count() > 0 ? masterRecords
                                        .Where(x => x.ZoneName.ToLower() == "Final Integration".ToLower())
                                        .Max(x => x.CalculatedFinish) : masterRecords[i].LastInZone ? masterRecords[i].CalculatedFinish.Value.AddDays(masterRecords[i].DaysRemainingInZone ?? 0) : masterRecords[i].CalculatedFinish.Value);

                                    masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                    ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                                }

                                /*Based on Final test take latest finish date into Post- test*/
                                else if (masterRecords[i + 1].ZoneName.ToLower() == "Preship".ToLower() || masterRecords[i + 1].ZoneName.ToLower() == "Pre-Ship".ToLower())
                                {
                                    masterRecords[i + 1].ActualPlannedStartDate = (masterRecords[i + 1].GatingDate.HasValue ? (masterRecords[i + 1].GatingDate < todaydate ? todaydate : masterRecords[i + 1].GatingDate) : null) ?? (masterRecords
                                        .Where(x => x.ZoneName.ToLower() == "Final Test".ToLower())
                                        .Count() > 0 ? masterRecords
                                        .Where(x => x.ZoneName.ToLower() == "Final Test".ToLower())
                                        .Max(x => x.CalculatedFinish) : masterRecords[i].LastInZone ? masterRecords[i].CalculatedFinish.Value.AddDays(masterRecords[i].DaysRemainingInZone ?? 0) : masterRecords[i].CalculatedFinish.Value);

                                    masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                    ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                                }

                                /* WIP Release Actual launch date display in feeder line*/
                                else if (masterRecords[i + 1].ZoneName.ToLower() == "Feeder Line".ToLower())
                                {
                                    if (!masterRecords[i + 1].ActualPlannedStartDate.HasValue)
                                    {
                                        masterRecords[i + 1].ActualPlannedStartDate = (masterRecords[i + 1].GatingDate.HasValue ? (masterRecords[i + 1].GatingDate < todaydate ? todaydate : masterRecords[i + 1].GatingDate) : null) ??
                                                                               (masterRecords[i + 1].ActualPlannedLaunch.HasValue ?
                                                                                   (masterRecords[i + 1].ActualPlannedLaunch
                                                                                       < todaydate ?
                                                                                   todaydate : masterRecords[i + 1].ActualPlannedLaunch)
                                                                                       : todaydate);
                                        masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                        ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                                    }
                                    else
                                    {
                                        masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                                                      ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                                    }
                                }

                                /* WIP Release Zone checked basis to display the Actual planned Lauch date*/
                                else if (moduleVFDAssignable.Where(x => x.VFDZoneName.ToLower() == masterRecords[i + 1].ZoneName.ToLower() && x.Assignable == true).Count() > 0)
                                {                                    
                                    masterRecords[i + 1].ActualPlannedStartDate = (masterRecords[i + 1].GatingDate.HasValue ? (masterRecords[i + 1].GatingDate < todaydate ? todaydate : masterRecords[i + 1].GatingDate) : null) ??
                                       (masterRecords[i + 1].ActualPlannedLaunch.HasValue ?
                                           (masterRecords[i + 1].ActualPlannedLaunch
                                               < todaydate ?
                                           todaydate : masterRecords[i + 1].ActualPlannedLaunch)
                                               : todaydate);
                                    masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                    ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                                }
                                else if (moduleVFDAssignable.Where(x => x.VFDZoneName.ToLower().Contains("Frame".ToLower()) && masterRecords[i + 1].ZoneName.ToLower().Contains("Frame".ToLower()) && x.Assignable == true && masterRecords[i + 1].Plant.ToLower() == "Fremont".ToLower()).Count() > 0)
                                {

                                    masterRecords[i + 1].ActualPlannedStartDate = (masterRecords[i + 1].GatingDate.HasValue ? (masterRecords[i + 1].GatingDate < todaydate ? todaydate : masterRecords[i + 1].GatingDate) : null) ??
                                       (masterRecords[i + 1].ActualPlannedLaunch.HasValue ?
                                           (masterRecords[i + 1].ActualPlannedLaunch
                                               < todaydate ?
                                           todaydate : masterRecords[i + 1].ActualPlannedLaunch)
                                               : todaydate);
                                    masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                    ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                                }
                                else if (moduleVFDAssignable.Where(x => x.VFDZoneName.ToLower().Contains("top plate") && masterRecords[i + 1].ZoneName.ToLower().Contains("top plate") && x.Assignable == true && masterRecords[i + 1].Plant.ToLower() == "Fremont".ToLower()).Count() > 0)
                                {
                                    masterRecords[i + 1].ActualPlannedStartDate = (masterRecords[i + 1].GatingDate.HasValue ? (masterRecords[i + 1].GatingDate < todaydate ? todaydate : masterRecords[i + 1].GatingDate) : null) ??
                                       (masterRecords[i + 1].ActualPlannedLaunch.HasValue ?
                                           (masterRecords[i + 1].ActualPlannedLaunch
                                               < todaydate ?
                                           todaydate : masterRecords[i + 1].ActualPlannedLaunch)
                                               : todaydate);
                                    masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                    ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                                }
                                #endregion
                                /* WIP Release Zone against numberof days choosen basis to display the Actual planned Lauch date*/
                                else if (moduleVFDs.Where(x => x.VFDZoneName.ToLower() == masterRecords[i + 1].ZoneName.ToLower()).Count() > 0)
                                {
                                    masterRecords[i + 1].ActualPlannedStartDate = (masterRecords[i + 1].GatingDate.HasValue ? (masterRecords[i + 1].GatingDate < todaydate ? todaydate : masterRecords[i + 1].GatingDate) : null) ??
                                        (masterRecords[i + 1].ActualPlannedLaunch.HasValue ?
                                            (masterRecords[i + 1].ActualPlannedLaunch.Value.AddDays(moduleVFDs.Where(x => x.VFDZoneName.ToLower() == masterRecords[i + 1].ZoneName.ToLower()).FirstOrDefault().NumberOfDays ?? 0)
                                                < todaydate ?
                                            todaydate : masterRecords[i + 1].ActualPlannedLaunch.Value.AddDays(moduleVFDs.Where(x => x.VFDZoneName.ToLower() == masterRecords[i + 1].ZoneName.ToLower()).FirstOrDefault().NumberOfDays ?? 0))
                                                : todaydate);
                                    masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                    ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                                }
                                else if (moduleVFDs.Where(x => x.VFDZoneName.ToLower().Contains("top plate") && masterRecords[i + 1].ZoneName.ToLower().Contains("top plate") && masterRecords[i + 1].Plant.ToLower() == "fremont").Count() > 0)
                                {
                                    masterRecords[i + 1].ActualPlannedStartDate = (masterRecords[i + 1].GatingDate.HasValue ? (masterRecords[i + 1].GatingDate < todaydate ? todaydate : masterRecords[i + 1].GatingDate) : null) ??
                                        (masterRecords[i + 1].ActualPlannedLaunch.HasValue ?
                                            (masterRecords[i + 1].ActualPlannedLaunch.Value.AddDays(moduleVFDs.Where(x => x.VFDZoneName.ToLower().Contains("top plate") && masterRecords[i + 1].ZoneName.ToLower().Contains("top plate")).FirstOrDefault().NumberOfDays ?? 0)
                                                < todaydate ?
                                            todaydate : masterRecords[i + 1].ActualPlannedLaunch.Value.AddDays(moduleVFDs.Where(x => x.VFDZoneName.ToLower().Contains("top plate") && masterRecords[i + 1].ZoneName.ToLower().Contains("top plate")).FirstOrDefault().NumberOfDays ?? 0))
                                                : todaydate);
                                    masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                    ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                                }
                                else if (moduleVFDs.Where(x => x.VFDZoneName.ToLower().Contains("Frame".ToLower()) && masterRecords[i + 1].ZoneName.ToLower().Contains("Frame".ToLower()) && masterRecords[i + 1].Plant.ToLower() == "Fremont".ToLower()).Count() > 0)
                                {
                                    masterRecords[i + 1].ActualPlannedStartDate = (masterRecords[i + 1].GatingDate.HasValue ? (masterRecords[i + 1].GatingDate < todaydate ? todaydate : masterRecords[i + 1].GatingDate) : null) ??
                                        (masterRecords[i + 1].ActualPlannedLaunch.HasValue ?
                                            (masterRecords[i + 1].ActualPlannedLaunch.Value.AddDays(moduleVFDs.Where(x => x.VFDZoneName.ToLower().Contains("Frame".ToLower()) && masterRecords[i + 1].ZoneName.ToLower().Contains("Frame".ToLower())).FirstOrDefault().NumberOfDays ?? 0)
                                                < todaydate ?
                                            todaydate : masterRecords[i + 1].ActualPlannedLaunch.Value.AddDays(moduleVFDs.Where(x => x.VFDZoneName.ToLower().Contains("Frame".ToLower()) && masterRecords[i + 1].ZoneName.ToLower().Contains("Frame".ToLower())).FirstOrDefault().NumberOfDays ?? 0))
                                                : todaydate);
                                    masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                    ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                                }

                                else
                                {
                                    masterRecords[i + 1].ActualPlannedStartDate = (masterRecords[i + 1].GatingDate.HasValue ? (masterRecords[i + 1].GatingDate < todaydate ? todaydate : masterRecords[i + 1].GatingDate) : null) ??
                                        (masterRecords[i].LastInZone ? masterRecords[i].CalculatedFinish.Value.AddDays(masterRecords[i].DaysRemainingInZone ?? 0) : masterRecords[i].CalculatedFinish.Value);
                                    masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                        ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                                }

                            }
                           
                            else if (masterRecords[i + 1].ActualPlannedStartDate.HasValue)
                            {
                                masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                            }
                        }
                        else
                        {
                            
                            if (!masterRecords[i + 1].ActualPlannedStartDate.HasValue)
                            {

                                 masterRecords[i + 1].ActualPlannedStartDate = (masterRecords[i].CalculatedFinish.Value < todaydate ? todaydate : masterRecords[i].CalculatedFinish.Value);
                                masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                    ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                            }


                            else if (masterRecords[i + 1].ActualPlannedStartDate.HasValue)
                            {

                                masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                            }
                        }

                    }
                }
                #endregion
                var groups = masterRecords.GroupBy(x => new { x.ModuleProcess, x.ModuleProcessID, x.ModDayShiftOnly });
                groups.ToList().ForEach(x =>
                {
                    List<OPSMGZone> oPSMGZones = new List<OPSMGZone>();
                    var zones = x.GroupBy(z => new { z.ZoneID, z.ZoneDescription }).ToList();
                    zones.ForEach(zone =>
                    {
                        List<OPSMGOperation> operations = new List<OPSMGOperation>();
                        zone.ToList().ForEach(op =>
                        {
                            operations.Add(new OPSMGOperation()
                            {
                                ActualPlannedStartDate = op.ActualPlannedStartDate,
                                AverageCycleTimeHours = op.AverageCycleTimeHours,
                                CalculatedFinish = op.CalculatedFinish,
                                CalculatedStandardTimeDays = op.CalculatedStandardTimeDays,
                                DayNightApproved = op.DayNightApproved,
                                DayShiftOnly = op.DayShiftOnly,
                                Description = op.Description,
                                HoursPerDay = op.HoursPerDay,
                                ManualOpPercent = op.ManualOpPercent,
                                OperationID = op.OperationID,
                                ModDayShiftOnly = op.ModDayShiftOnly,
                                ModuleProcess = op.ModuleProcess,
                                ModuleProcessID = op.ModuleProcessID,
                                NightShiftOnly = op.NightShiftOnly,
                                OpPercent = op.OpPercent,
                                Order = op.Order,
                                PilotProductID = op.PilotProductID,
                                StandardTimeHours = op.StandardTimeHours,
                                Status = op.Status,
                                STOverrideReason = op.STOverrideReason,
                                STUpdatedBy = op.STUpdatedBy,
                                STUpdatedById = op.STUpdatedById,
                                TotalCycleTimeHours = op.TotalCycleTimeHours,
                                TotalReworkHours = op.TotalReworkHours,
                                ZoneDescription = op.ZoneDescription,
                                ZoneID = op.ZoneID,
                                GatingDate = op.GatingDate
                            });
                            operations.RemoveAll(x => x.OperationID == null);
                        });

                        oPSMGZones.Add(new OPSMGZone()
                        {
                            ZoneID = zone.Key.ZoneID,
                            Zone = zone.Key.ZoneDescription,
                            Order = Convert.ToInt32(rg.Match(zone.Key.ZoneDescription).Value.Trim()),
                            OPSMGOperations = operations.OrderBy(x => x.Order).ToList()
                        }); ;
                    });



                    operationViewUIModels.Add(new OPSMGUIModel()
                    {
                        ModuleProcess = x.Key.ModuleProcess,
                        ModuleProcessId = x.Key.ModuleProcessID,
                        ModDayShiftOnly = x.Key.ModDayShiftOnly,
                        OPSMGZones = oPSMGZones.OrderBy(x => x.Order).ToList()
                    });

                });

                return operationViewUIModels.OrderBy(x => x.ModuleProcessId).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<OPSMGEngineerUIModel> GetOPMGEngineerOperations(string connString, int pilotProductID, DateTime todaydate)
        {
            try
            {
                DataSet dataSet;
                SqlParameter[] param =
                {
               new SqlParameter("@PilotProductID", pilotProductID)
            };
                dataSet = SqlHelper.GetDataSet(connString, "uspGetOPMGOperationByZoneForEngineer", param);
                Regex rg = new Regex(@"\d+");

                List<OPSMGEngineerUIModel> operationViewUIModels = new List<OPSMGEngineerUIModel>();

                var masterRecords = dataSet.Tables[0].AsEnumerable().Select(dtRow => new OPSMGOperationEngineer
                {
                    PilotProductID = dtRow.Field<long?>("PilotProductID"),
                    OperationID = dtRow.Field<long?>("OperationID"),
                    Status = dtRow.Field<string>("OperationStatus"),
                    OpPercent = dtRow.Field<decimal?>("OpPercent"),
                    Description = dtRow.Field<string>("OPDescription"),
                    ActualPlannedStartDate = dtRow.Field<DateTime?>("ActualStartDate"),
                    CalculatedFinish = dtRow.Field<DateTime?>("CalculatedFinish"),
                    TotalDirectHours = dtRow.Field<decimal?>("TotalDirectHours"),
                    TotalRework = dtRow.Field<decimal?>("TotalRework"),
                    TotalInterrupt = dtRow.Field<decimal?>("TotalInterrupt"),
                    TotalCycleTime = dtRow.Field<decimal?>("TotalCycleTime"),
                    StandardTimeHours = dtRow.Field<double?>("StandardTimeHours"),
                    ZoneID = dtRow.Field<long?>("ZoneID"),
                    CalculatedStandardTimeDays = dtRow.Field<decimal?>("CalculatedStandardTimeDays"),
                    Order = string.IsNullOrEmpty(dtRow.Field<string>("OPDescription")) ? 99999 : string.IsNullOrEmpty(rg.Match(dtRow.Field<string>("OPDescription")).Value.Trim()) ? 99999 : Convert.ToInt32(rg.Match(dtRow.Field<string>("OPDescription")).Value),
                    ModuleProcess = dtRow.Field<string>("ModuleProcess"),
                    ModuleProcessID = dtRow.Field<long?>("ModuleProcessID"),
                    ZoneDescription = dtRow.Field<string>("ZoneDescription"),
                    ZoneName = dtRow.Field<string>("ZoneName"),
                    ZoneOrder = string.IsNullOrEmpty(dtRow.Field<string>("ZoneDescription")) ? 99999 : string.IsNullOrEmpty(rg.Match(dtRow.Field<string>("ZoneDescription")).Value.Trim()) ? 99999 : Convert.ToInt32(rg.Match(dtRow.Field<string>("ZoneDescription")).Value),
                    ActualPlannedLaunch = dtRow.Field<DateTime?>("ActualPlannedLaunch"),
                    NumberOfSteps = dtRow.Field<int?>("NumberofSteps"),
                    CompletedSteps = dtRow.Field<int?>("CompletedSteps"),
                    ModuleShiftHours = dtRow.Field<int?>("ModuleShiftHours")
                }).OrderBy(x => x.ZoneOrder).ThenBy(x => x.Order).ToList();

                List<ModuleVFDWithName> moduleVFDs = dataSet.Tables[1].AsEnumerable().Select(dtRow => new ModuleVFDWithName()
                {
                    ModuleVFDId = dtRow.Field<long?>("ModuleVFDId"),
                    Assignable = dtRow.Field<bool?>("Assignable"),
                    BayName = dtRow.Field<string>("BayName"),
                    NumberOfDays = dtRow.Field<int?>("NumberOfDays"),
                    PilotProductId = dtRow.Field<long?>("PilotProductID"),
                    StatusId = dtRow.Field<long?>("StatusID"),
                    VFDZoneId = dtRow.Field<long?>("VFDZoneID"),
                    VFDZoneName = dtRow.Field<string>("VFDZoneName")
                }).ToList();

                //if you make a change in this region, make the same change in method - GetOPMGEngineerOperations in EditModule.cs and method - SetDatesOfOperations in CommonHelper.cs
                #region Operation Dates
                //condition for gating date becuase if gating date is present and if its less than today then use today's date else use gating date
                //condition for actualLaunchdate because same as gating date if less than today then use today's date
                masterRecords.GroupBy(x => x.ZoneID).ToList().ForEach(x =>
                {
                    if (x.ToList().Count > 0)
                    {
                        x.ToList().FirstOrDefault().FirstInZone = true;
                        x.ToList().LastOrDefault().DaysRemainingInZone = x.ToList().Sum(zz => (zz.StandardTimeHours - ((zz.StandardTimeHours / (zz.NumberOfSteps == 0 ? 1 : zz.NumberOfSteps)) * zz.CompletedSteps)) / zz.ModuleShiftHours);
                        x.ToList().LastOrDefault().LastInZone = true;
                    }
                });

                if (masterRecords.Count > 0)
                {
                    if (!masterRecords[0].ActualPlannedStartDate.HasValue)
                    {
                        if (masterRecords[0].ZoneName.ToLower() == "Chamber_SF Integration".ToLower())
                        {
                            //chamber in split because only need zone with chamber word
                            masterRecords[0].ActualPlannedStartDate = (masterRecords[0].GatingDate.HasValue ? (masterRecords[0].GatingDate < todaydate ? todaydate : masterRecords[0].GatingDate) : null) ?? (masterRecords
                                .Where(x => x.ZoneName.ToLower() == "Chamber".ToLower() || x.ZoneName.ToLower() == "Sub Frame".ToLower())
                                .Count() > 0 ? masterRecords
                                .Where(x => x.ZoneName.ToLower() == "Chamber".ToLower() || x.ZoneName.ToLower() == "Sub Frame".ToLower())
                                .Max(x => x.CalculatedFinish) : todaydate);
                            masterRecords[0].CalculatedFinish = masterRecords[0].ActualPlannedStartDate.Value.AddDays(masterRecords[0].CalculatedStandardTimeDays.HasValue
                            ? Decimal.ToDouble(masterRecords[0].CalculatedStandardTimeDays.Value) : 0);
                        }

                        else if (masterRecords[0].ZoneName.ToLower() == "Enclosure_TP Integration".ToLower())
                        {
                            masterRecords[0].ActualPlannedStartDate = (masterRecords[0].GatingDate.HasValue ? (masterRecords[0].GatingDate < todaydate ? todaydate : masterRecords[0].GatingDate) : null) ?? (masterRecords
                                .Where(x => x.ZoneName.ToLower() == "Enclosure".ToLower() || x.ZoneName.ToLower() == "Top Plate".ToLower())
                                .Count() > 0 ? masterRecords
                                .Where(x => x.ZoneName.ToLower() == "Enclosure".ToLower() || x.ZoneName.ToLower() == "Top Plate".ToLower())
                                .Max(x => x.CalculatedFinish) : todaydate);
                            masterRecords[0].CalculatedFinish = masterRecords[0].ActualPlannedStartDate.Value.AddDays(masterRecords[0].CalculatedStandardTimeDays.HasValue
                            ? Decimal.ToDouble(masterRecords[0].CalculatedStandardTimeDays.Value) : 0);
                        }

                        else if (masterRecords[0].ZoneName.ToLower() == "Final Integration".ToLower())
                        {
                            masterRecords[0].ActualPlannedStartDate = (masterRecords[0].GatingDate.HasValue ? (masterRecords[0].GatingDate < todaydate ? todaydate : masterRecords[0].GatingDate) : null) ?? (masterRecords
                                .Where(x => x.ZoneName.ToLower() == "Chamber_SF Integration".ToLower() || x.ZoneName.ToLower() == "Enclosure_TP Integration".ToLower())
                                .Count() > 0 ? masterRecords
                                .Where(x => x.ZoneName.ToLower() == "Chamber_SF Integration".ToLower() || x.ZoneName.ToLower() == "Enclosure_TP Integration".ToLower())
                                .Max(x => x.CalculatedFinish) : todaydate);
                            masterRecords[0].CalculatedFinish = masterRecords[0].ActualPlannedStartDate.Value.AddDays(masterRecords[0].CalculatedStandardTimeDays.HasValue
                            ? Decimal.ToDouble(masterRecords[0].CalculatedStandardTimeDays.Value) : 0);
                        }

                        else if (moduleVFDs.Where(x => x.VFDZoneName.ToLower() == masterRecords[0].ZoneName.ToLower()).Count() > 0)
                        {
                            masterRecords[0].ActualPlannedStartDate = (masterRecords[0].GatingDate.HasValue ? (masterRecords[0].GatingDate < todaydate ? todaydate : masterRecords[0].GatingDate) : null) ??
                                (masterRecords[0].ActualPlannedLaunch.HasValue ?
                                    (masterRecords[0].ActualPlannedLaunch.Value.AddDays(moduleVFDs.Where(x => x.VFDZoneName.ToLower() == masterRecords[0].ZoneName.ToLower()).FirstOrDefault().NumberOfDays ?? 0)
                                        < todaydate ?
                                    todaydate : masterRecords[0].ActualPlannedLaunch.Value.AddDays(moduleVFDs.Where(x => x.VFDZoneName.ToLower() == masterRecords[0].ZoneName.ToLower()).FirstOrDefault().NumberOfDays ?? 0))
                                        : todaydate);
                            masterRecords[0].CalculatedFinish = masterRecords[0].ActualPlannedStartDate.Value.AddDays(masterRecords[0].CalculatedStandardTimeDays.HasValue
                            ? Decimal.ToDouble(masterRecords[0].CalculatedStandardTimeDays.Value) : 0);
                        }

                        else
                        {
                            masterRecords[0].ActualPlannedStartDate = (masterRecords[0].GatingDate.HasValue ? (masterRecords[0].GatingDate < todaydate ? todaydate : masterRecords[0].GatingDate) : null) ?? todaydate;
                            masterRecords[0].CalculatedFinish = masterRecords[0].ActualPlannedStartDate.Value.AddDays(masterRecords[0].CalculatedStandardTimeDays.HasValue
                                ? Decimal.ToDouble(masterRecords[0].CalculatedStandardTimeDays.Value) : 0);
                        }
                    }
                    else
                    {
                        masterRecords[0].CalculatedFinish = masterRecords[0].ActualPlannedStartDate.Value.AddDays(masterRecords[0].CalculatedStandardTimeDays.HasValue
                           ? Decimal.ToDouble(masterRecords[0].CalculatedStandardTimeDays.Value) : 0);
                    }


                    for (int i = 0; i < masterRecords.Count - 1; i++)
                    {
                        if (masterRecords[i + 1].FirstInZone)
                        {
                            if (!masterRecords[i + 1].ActualPlannedStartDate.HasValue)
                            {
                                if (masterRecords[i + 1].ZoneName.ToLower() == "Chamber_SF Integration".ToLower())
                                {
                                    masterRecords[i + 1].ActualPlannedStartDate = (masterRecords[i + 1].GatingDate.HasValue ? (masterRecords[i + 1].GatingDate < todaydate ? todaydate : masterRecords[i + 1].GatingDate) : null) ?? (masterRecords
                                        .Where(x => x.ZoneName.ToLower() == "Chamber".ToLower() || x.ZoneName.ToLower() == "Sub Frame".ToLower())
                                        .Count() > 0 ? masterRecords
                                        .Where(x => x.ZoneName.ToLower() == "Chamber".ToLower() || x.ZoneName.ToLower() == "Sub Frame".ToLower()) //chamber in split because only need zone with chamber word
                                        .Max(x => x.CalculatedFinish) : masterRecords[i].LastInZone ? masterRecords[i].CalculatedFinish.Value.AddDays(masterRecords[i].DaysRemainingInZone ?? 0) : masterRecords[i].CalculatedFinish.Value); 

                                    masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                    ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                                }

                                else if (masterRecords[i + 1].ZoneName.ToLower() == "Enclosure_TP Integration".ToLower())
                                {
                                    masterRecords[i + 1].ActualPlannedStartDate = (masterRecords[i + 1].GatingDate.HasValue ? (masterRecords[i + 1].GatingDate < todaydate ? todaydate : masterRecords[i + 1].GatingDate) : null) ?? (masterRecords
                                        .Where(x => x.ZoneName.ToLower() == "Enclosure".ToLower() || x.ZoneName.ToLower() == "Top Plate".ToLower())
                                        .Count() > 0 ? masterRecords
                                        .Where(x => x.ZoneName.ToLower() == "Enclosure".ToLower() || x.ZoneName.ToLower() == "Top Plate".ToLower())
                                        .Max(x => x.CalculatedFinish) : masterRecords[i].LastInZone ? masterRecords[i].CalculatedFinish.Value.AddDays(masterRecords[i].DaysRemainingInZone ?? 0) : masterRecords[i].CalculatedFinish.Value);

                                    masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                    ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                                }

                                else if (masterRecords[i + 1].ZoneName.ToLower() == "Final Integration".ToLower())
                                {
                                    masterRecords[i + 1].ActualPlannedStartDate = (masterRecords[i + 1].GatingDate.HasValue ? (masterRecords[i + 1].GatingDate < todaydate ? todaydate : masterRecords[i + 1].GatingDate) : null) ?? (masterRecords
                                        .Where(x => x.ZoneName.ToLower() == "Chamber_SF Integration".ToLower() || x.ZoneName.ToLower() == "Enclosure_TP Integration".ToLower())
                                        .Count() > 0 ? masterRecords
                                        .Where(x => x.ZoneName.ToLower() == "Chamber_SF Integration".ToLower() || x.ZoneName.ToLower() == "Enclosure_TP Integration".ToLower())
                                        .Max(x => x.CalculatedFinish) : masterRecords[i].LastInZone ? masterRecords[i].CalculatedFinish.Value.AddDays(masterRecords[i].DaysRemainingInZone ?? 0) : masterRecords[i].CalculatedFinish.Value);

                                    masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                    ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                                }

                                else if (moduleVFDs.Where(x => x.VFDZoneName.ToLower() == masterRecords[i + 1].ZoneName.ToLower()).Count() > 0)
                                {
                                    masterRecords[i + 1].ActualPlannedStartDate = (masterRecords[i + 1].GatingDate.HasValue ? (masterRecords[i + 1].GatingDate < todaydate ? todaydate : masterRecords[i + 1].GatingDate) : null) ??
                                        (masterRecords[i + 1].ActualPlannedLaunch.HasValue ?
                                            (masterRecords[i + 1].ActualPlannedLaunch.Value.AddDays(moduleVFDs.Where(x => x.VFDZoneName.ToLower() == masterRecords[i + 1].ZoneName.ToLower()).FirstOrDefault().NumberOfDays ?? 0)
                                                < todaydate ?
                                            todaydate : masterRecords[i + 1].ActualPlannedLaunch.Value.AddDays(moduleVFDs.Where(x => x.VFDZoneName.ToLower() == masterRecords[i + 1].ZoneName.ToLower()).FirstOrDefault().NumberOfDays ?? 0))
                                                : todaydate);
                                    masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                    ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                                }

                                else
                                {
                                    masterRecords[i + 1].ActualPlannedStartDate = (masterRecords[i + 1].GatingDate.HasValue ? (masterRecords[i + 1].GatingDate < todaydate ? todaydate : masterRecords[i + 1].GatingDate) : null) ??
                                        (masterRecords[i].LastInZone ? masterRecords[i].CalculatedFinish.Value.AddDays(masterRecords[i].DaysRemainingInZone ?? 0) : masterRecords[i].CalculatedFinish.Value);
                                    masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                        ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                                }

                            }
                            else if (masterRecords[i + 1].ActualPlannedStartDate.HasValue)
                            {
                                masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                            }
                        }
                        else
                        {
                            if (!masterRecords[i + 1].ActualPlannedStartDate.HasValue)
                            {
                                masterRecords[i + 1].ActualPlannedStartDate = (masterRecords[i].CalculatedFinish.Value < todaydate ? todaydate : masterRecords[i].CalculatedFinish.Value);
                                masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                    ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                            }
                            else if (masterRecords[i + 1].ActualPlannedStartDate.HasValue)
                            {
                                masterRecords[i + 1].CalculatedFinish = masterRecords[i + 1].ActualPlannedStartDate.Value.AddDays(masterRecords[i + 1].CalculatedStandardTimeDays.HasValue
                                ? Decimal.ToDouble(masterRecords[i + 1].CalculatedStandardTimeDays.Value) : 0);
                            }
                        }

                    }
                }
                #endregion
                var groups = masterRecords.GroupBy(x => new { x.ModuleProcess, x.ModuleProcessID });
                groups.ToList().ForEach(x =>
                {
                    List<OPSMGZoneEngineer> oPSMGZones = new List<OPSMGZoneEngineer>();
                    var zones = x.GroupBy(z => new { z.ZoneID, z.ZoneDescription }).ToList();
                    zones.ForEach(zone =>
                    {
                        List<OPSMGOperationEngineer> operations = new List<OPSMGOperationEngineer>();
                        zone.ToList().ForEach(op =>
                        {
                            operations.Add(new OPSMGOperationEngineer()
                            {
                                ModuleProcessID = op.ModuleProcessID,
                                ActualPlannedStartDate = op.ActualPlannedStartDate,
                                CalculatedFinish = op.CalculatedFinish,
                                CalculatedStandardTimeDays = op.CalculatedStandardTimeDays,
                                Description = op.Description,
                                ModuleProcess = op.ModuleProcess,
                                OperationID = op.OperationID,
                                OpPercent = op.OpPercent,
                                Order = op.Order,
                                PilotProductID = op.PilotProductID,
                                Status = op.Status,
                                TotalCycleTime = op.TotalCycleTime,
                                TotalDirectHours = op.TotalDirectHours,
                                TotalInterrupt = op.TotalInterrupt,
                                TotalRework = op.TotalRework,
                                ZoneDescription = op.ZoneDescription,
                                ZoneID = op.ZoneID
                            });
                            operations.RemoveAll(x => x.OperationID == null);
                        });

                        oPSMGZones.Add(new OPSMGZoneEngineer()
                        {
                            ZoneID = zone.Key.ZoneID,
                            Zone = zone.Key.ZoneDescription,
                            Order = Convert.ToInt32(rg.Match(zone.Key.ZoneDescription).Value.Trim()),
                            OPSMGOperationsEngineer = operations.OrderBy(x => x.Order).ToList(),
                            SumTotalDirectHours = operations.Sum(xx => xx.TotalDirectHours ?? 0),
                            SumTotalRework = operations.Sum(xx => xx.TotalRework ?? 0),
                            SumTotalInterrupt = operations.Sum(xx => xx.TotalInterrupt ?? 0),
                            AvgTotalCycleTime = operations.Sum(xx => xx.TotalDirectHours ?? 0) / masterRecords.Count
                        });
                    });



                    operationViewUIModels.Add(new OPSMGEngineerUIModel()
                    {
                        ModuleProcess = x.Key.ModuleProcess,
                        ModuleProcessId = x.Key.ModuleProcessID,
                        OPSMGZonesEngineer = oPSMGZones
                    });

                });

                return operationViewUIModels;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public object GetAssemblyTestPostTestPercent(string connString, int pilotProductID)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
               new SqlParameter("@PilotProductID", pilotProductID)
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetAssemblyTestPostTestPercent", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new ModulePercentage
            {
                PilotProductID = dtRow.Field<long?>("PilotProductID"),
                AssemblyPercent = dtRow.Field<double?>("AssemblyPercent"),
                TestPercent = dtRow.Field<int?>("TestPercent"),
                PostTestPercent = dtRow.Field<int?>("PostTestPercent"),
            }).FirstOrDefault();
            return masterRecords;
        }


        public int UpdateOperationManagement(string connString, OPSMGOperationEdit oPSMGOperationEdit)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };


                SqlParameter[] param = {
                    new SqlParameter("@PilotProductId", oPSMGOperationEdit.PilotProductID),
                    new SqlParameter("@AssemblyPercent",  oPSMGOperationEdit.AssemblyPercent),
                    new SqlParameter("@TestPercent ",  oPSMGOperationEdit.TestPercent),
                    new SqlParameter("@PostTestPercent",  oPSMGOperationEdit.PostTestPercent),
                    new SqlParameter("@OperationManagement",  GetOperationManagementEditTable(oPSMGOperationEdit.OPSMGOperationEditFields)),
                    outParam
                    };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateOperations", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        private DataTable GetOperationManagementEditTable(List<OPSMGOperationEditFields> oPSMGOperationEditFields)
        {
            DataTable operationEditTable = new DataTable();

            operationEditTable.Columns.Add("PilotProductId", typeof(long));
            operationEditTable.Columns.Add("OperationId", typeof(long));
            operationEditTable.Columns.Add("ManualOpPercent", typeof(int));
            operationEditTable.Columns.Add("DayShiftOnly", typeof(bool));
            operationEditTable.Columns.Add("NightShiftOnly", typeof(bool));
            operationEditTable.Columns.Add("StandardTimeHours", typeof(float));
            operationEditTable.Columns.Add("STOverrideReason", typeof(string));
            operationEditTable.Columns.Add("STUpdatedByID", typeof(long));

            if (oPSMGOperationEditFields != null)
            {
                foreach (OPSMGOperationEditFields item in oPSMGOperationEditFields)
                {
                    operationEditTable.Rows.Add(item.PilotProductID, item.OperationID, item.ManualOpPercent, item.DayShiftOnly, item.NightShiftOnly
                        , item.StandardTimeHours, item.STOverrideReason, item.STUpdatedById);
                }
            }

            return operationEditTable;
        }


        #endregion

        #region EditmodSubassebly
        public OPSSubassemblyModel GetOpsManagementSubassembly(string connString, int pilotProductID)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
               new SqlParameter("@PilotProductID",pilotProductID)
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetOpsManagementSubassembly", param);
            OPSSubassemblyModel OPSSubassembly = dataTable.AsEnumerable().Select(dtRow => new OPSSubassemblyModel()
            {
                PilotProductID = dtRow.Field<long?>("PilotProductID"),
                SubassemblyBuildHours = dtRow.Field<decimal?>("SubassemblyBuildHours"),
                TestBuildHours = dtRow.Field<decimal?>("TestBuildHours"),
                ModuleProcessIdForSubassembly = dtRow.Field<long?>("ModuleProcessIdForSubassembly"),
                ModuleProcessIdForTest = dtRow.Field<long?>("ModuleProcessIdForTest"),
                PilotMEApproved = dtRow.Field<bool?>("PilotMEApproved"),
                SOELink = dtRow.Field<string>("SOELink"),
                MfgApproved = dtRow.Field<bool?>("MfgApproved"),
                CA10ShortageFree = dtRow.Field<bool?>("CA10ShortageFree"),
                AssemblyPercent = dtRow.Field<double?>("AssemblyPercent"),
                PercentType = dtRow.Field<string>("PercentType"),
                TestPercent = dtRow.Field<int?>("TestPercent"),
                PostTestPercent = dtRow.Field<int?>("PostTestPercent"),
                InWIP = dtRow.Field<bool?>("InWIP"),
            }).FirstOrDefault();
            return OPSSubassembly;
        }

        public int UpdateOpsManagementSubassembly(string connString, OPSSubassemblyModel oPSSubassemblyModel)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@PilotProductId", oPSSubassemblyModel.PilotProductID),
                    new SqlParameter("@AssemblyPercent",  oPSSubassemblyModel.AssemblyPercent),
                    new SqlParameter("@TestPercent",  oPSSubassemblyModel.TestPercent),
                    new SqlParameter("@PostTestPercent",  oPSSubassemblyModel.PostTestPercent),
                    new SqlParameter("@SubassemblyBuildHours",  oPSSubassemblyModel.SubassemblyBuildHours),
                    new SqlParameter("@TestBuildHours",  oPSSubassemblyModel.TestBuildHours),
                    new SqlParameter("@ModuleProcessIdForSubassembly",  oPSSubassemblyModel.ModuleProcessIdForSubassembly),
                    new SqlParameter("@ModuleProcessIdForTest",  oPSSubassemblyModel.ModuleProcessIdForTest),
                    new SqlParameter("@PilotMEApproved",  oPSSubassemblyModel.PilotMEApproved),
                    new SqlParameter("@SOELink",  oPSSubassemblyModel.SOELink),
                    new SqlParameter("@MfgApproved",  oPSSubassemblyModel.MfgApproved),
                    new SqlParameter("@CA10ShortageFree",  oPSSubassemblyModel.CA10ShortageFree),
                    outParam
                    };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateOpsManagementSubassembly", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public ScheduleSubassemblyModel GetScheduleSubassembly(string connString, int pilotProductID)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
               new SqlParameter("@PilotProductID",pilotProductID)
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetScheduleSubassembly", param);
            ScheduleSubassemblyModel ScheduleSub = dataTable.AsEnumerable().Select(dtRow => new ScheduleSubassemblyModel()
            {
                PilotProductID = dtRow.Field<long?>("PilotProductID"),
                KitDateDelivered = dtRow.Field<DateTime?>("KitDateDelivered"),
                KitReceivedDate = dtRow.Field<DateTime?>("KitReceivedDate"),
                ActualTestStart = dtRow.Field<DateTime?>("ActualTestStart"),
                ActualTestComplete = dtRow.Field<DateTime?>("ActualTestComplete"),
                CommitedManufacturingComplete = dtRow.Field<DateTime?>("CommitedManufacturingComplete"),
                PilotManufacturingCommitedShipDate = dtRow.Field<DateTime?>("PilotManufacturingCommitedShipDate"),
                CustomerRequestDate = dtRow.Field<DateTime?>("CustomerRequestDate"),
                InWIP = dtRow.Field<bool?>("InWIP"),
            }).FirstOrDefault();
            return ScheduleSub;
        }

        public int UpdateScheduleSubassembly(string connString, ScheduleSubassemblyModel scheduleSubassemblyModel)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@PilotProductId", scheduleSubassemblyModel.PilotProductID),
                    new SqlParameter("@KitDateDelivered",  scheduleSubassemblyModel.KitDateDelivered),
                    new SqlParameter("@KitReceivedDate",  scheduleSubassemblyModel.KitReceivedDate),
                    new SqlParameter("@ActualTestStart",  scheduleSubassemblyModel.ActualTestStart),
                    new SqlParameter("@ActualTestComplete",  scheduleSubassemblyModel.ActualTestComplete),
                    new SqlParameter("@CommitedManufacturingComplete",  scheduleSubassemblyModel.CommitedManufacturingComplete),
                    new SqlParameter("@PilotManufacturingCommitedShipDate",scheduleSubassemblyModel.PilotManufacturingCommitedShipDate ),
                    new SqlParameter("@CustomerRequestDate",  scheduleSubassemblyModel.CustomerRequestDate),
                    new SqlParameter("@ModifiedBy",  scheduleSubassemblyModel.ModifiedBy),
                    new SqlParameter("@ModifiedOn",  scheduleSubassemblyModel.ModifiedOn),
                    outParam
                    };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateScheduleSubassembly", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        #endregion 


    }
}
