﻿using LAM.PMPM.DAL;
using LAM.PMPM.Model;
using LAM.PMPM.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace LAM.PMPM.BL
{
   public class ReportingBL
    {
        public List<DateTracking> GetDateTrackingSearch(string connString, int plantid)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@PlantId", plantid),
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetHistoricDateByPlantOrPPId", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new DateTracking
            {
                PilotProductID = dtRow.Field<long?>("PilotProductID"),
                FCID = dtRow.Field<string>("FCID"),
                BEN = dtRow.Field<string>("BEN"),
                PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                DateName = dtRow.Field<string>("DateName"),
                Status = dtRow.Field<string>("Status"),
                PriorDate = dtRow.Field<DateTime?>("PriorDate"),
                NewDate = dtRow.Field<DateTime?>("NewDate"),
                DifferenceInDays = dtRow.Field<int?>("DifferenceInDays"),
                LastUpdated = dtRow.Field<DateTime?>("LastUpdated"),
                UpdatedByID = dtRow.Field<long?>("UpdatedById"),
                UpdatedBy = dtRow.Field<string>("UpdatedBy")
            }).ToList();

            return masterRecords;
        }

        public List<DateTracking> GetDateTrackingModuleByPPId(string connString, int pilotproductid)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@PilotProductId", pilotproductid),
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetHistoricDateByPlantOrPPId", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new DateTracking
            {
                PilotProductID = dtRow.Field<long?>("PilotProductID"),
                FCID = dtRow.Field<string>("FCID"),
                BEN = dtRow.Field<string>("BEN"),
                PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                DateName = dtRow.Field<string>("DateName"),
                Status = dtRow.Field<string>("Status"),
                PriorDate = dtRow.Field<DateTime?>("PriorDate"),
                NewDate = dtRow.Field<DateTime?>("NewDate"),
                DifferenceInDays = dtRow.Field<int?>("DifferenceInDays"),
                LastUpdated = dtRow.Field<DateTime?>("LastUpdated"),
                UpdatedByID = dtRow.Field<long?>("UpdatedById"),
                UpdatedBy = dtRow.Field<string>("UpdatedBy")
            }).ToList();

            return masterRecords;
        }

        public List<POMDataMissmatchReportingView> GetPOMBuildingMismatchData(string connString, long PlantID)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@PlantId", PlantID),
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetPOMBuildingMismatchData", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new POMDataMissmatchReportingView
            {               
                FCID = dtRow.Field<string>("FCID"),
                BEN = dtRow.Field<string>("BEN"),
                POM = dtRow.Field<string>("POM"),
                BuildingName = dtRow.Field<string>("BuildingName")              
            }).ToList();

            return masterRecords;
        }
        public List<DateDataMissmatchReportingView> GetDateMismatchData(string connString, long PlantID)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@PlantId", PlantID),
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetDateMismatchData", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new DateDataMissmatchReportingView
            {                
                FCID = dtRow.Field<string>("FCID"),
                BEN = dtRow.Field<string>("BEN"),
                PSN = dtRow.Field<string>("PilotSerialNumber"),
                SAPLaunchDate = dtRow.Field<DateTime?>("SAPLaunchDate"),
                PilotLaunchDate = dtRow.Field<DateTime?>("PilotLaunchDate"),
                SAPMCSD = dtRow.Field<DateTime?>("SAPMCSD"),
                PilotMCSD = dtRow.Field<DateTime?>("PilotMCSD")
            }).ToList();

            return masterRecords;
        }


        public List<DateOperationMissmatchReportingView> GetOperationMismatchData(string connString, long PlantID,int MinVal,int MaxVal)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@PlantId", PlantID),
                new SqlParameter("@MinVal", MinVal),
                new SqlParameter("@MaxVal", MaxVal),
            };

            Regex rg = new Regex(@"\d+");

            dataTable = SqlHelper.GetDataTable(connString, "uspOperationMismatchData", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new DateOperationMissmatchReportingView
            {
                ProductName = dtRow.Field<string>("ProductName"),
                operationID = dtRow.Field<long?>("operationID"),
                OperationName = dtRow.Field<string>("OperationName"),
                StandardTimeHours = dtRow.Field<decimal?>("StandardTimeHours"),
                AvgActualCycleTime = dtRow.Field<decimal?>("AvgActualCycleTime"),
                OveraOrUnderSDTime = dtRow.Field<decimal?>("OveraOrUnderSDTime"),
                OperationNumber = string.IsNullOrEmpty(dtRow.Field<string>("OperationName")) ? "" : rg.Match(dtRow.Field<string>("OperationName")).Value
            }).ToList();

            return masterRecords;
        }
    }  

}
