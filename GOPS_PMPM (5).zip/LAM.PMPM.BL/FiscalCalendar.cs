﻿using LAM.PMPM.DAL;
using LAM.PMPM.Model;
using LAM.PMPM.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace LAM.PMPM.BL
{
    public class FiscalCalendar
    {
        public string GetFiscalCalendar(string connString)
        {
            DataTable dataTable = null;
            try
            {
                dataTable = SqlHelper.GetDataTable(connString, "uspGetFiscalCalendar");
                var eventInfo = dataTable.AsEnumerable().Select(dtRow => new
                {
                    id = Convert.ToInt32(dtRow["id"]),
                    FiscalYear = Convert.ToInt32(dtRow["FiscalYear"]),
                    Quarter = Convert.ToInt32(dtRow["Quarter"]),
                    startDate = dtRow.Field<DateTime?>("startDate"),
                    endDate = dtRow.Field<DateTime?>("endDate"),
                    WWinQuarter = Convert.ToInt32(dtRow["WWinQuarter"]),
                    WWCumulative = Convert.ToInt32(dtRow["WWCumulative"]),
                    QuarterDescription = dtRow.Field<string>("QuarterDescription")
                }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(eventInfo);
                return jsonString;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }
        
        public string AddFiscalCalendar(string connString,FiscalCalendarViewModel fiscalCalendarViewModel)
        {
            DataTable dataTable = null;
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@FiscalYear",fiscalCalendarViewModel.FiscalYear),
                    new SqlParameter("@Quarter",fiscalCalendarViewModel.Quarter),
                    new SqlParameter("@startDate",fiscalCalendarViewModel.StartDate),
                    new SqlParameter("@endDate",fiscalCalendarViewModel.EndDate),
                    new SqlParameter("@WWinQuarter",fiscalCalendarViewModel.WWinQuarter),
                };
                var newId = SqlHelper.ExecuteProcedureReturnInt(connString, "uspAddFiscalCalendar",param);
                if (newId <0)
                {
                    throw new Exception("Error on the Insertion of new Data");
                }
                SqlParameter[] param2 = {
                    new SqlParameter("@FiscalYear",fiscalCalendarViewModel.FiscalYear)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetFiscalCalendarByYear",param2);
                var eventInfo = dataTable.AsEnumerable().Select(dtRow => new
                {
                    id = Convert.ToInt32(dtRow["id"]),
                    FiscalYear = Convert.ToInt32(dtRow["FiscalYear"]),
                    Quarter = Convert.ToInt32(dtRow["Quarter"]),
                    startDate = dtRow.Field<DateTime?>("startDate"),
                    endDate = dtRow.Field<DateTime?>("endDate"),
                    WWinQuarter = Convert.ToInt32(dtRow["WWinQuarter"]),
                    WWCumulative = Convert.ToInt32(dtRow["WWCumulative"]),
                    QuarterDescription = dtRow.Field<string>("QuarterDescription")
                }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(eventInfo);
                return jsonString;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }

        public string UpdateFiscalCalendar(string connString,FiscalCalendarViewModel fiscalCalendarViewModel)
        {
            DataTable dataTable = null;
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@id",fiscalCalendarViewModel.id),
                    new SqlParameter("@FiscalYear",fiscalCalendarViewModel.FiscalYear),
                    new SqlParameter("@Quarter",fiscalCalendarViewModel.Quarter),
                    new SqlParameter("@startDate",fiscalCalendarViewModel.StartDate),
                    new SqlParameter("@endDate",fiscalCalendarViewModel.EndDate),
                    new SqlParameter("@WWinQuarter",fiscalCalendarViewModel.WWinQuarter),
                };
                var newId = SqlHelper.ExecuteProcedureReturnInt(connString, "uspUpdateFiscalCalendar",param);
                if (newId <0)
                {
                    throw new Exception("Error on the Insertion of new Data");
                }
                SqlParameter[] param2 = {
                    new SqlParameter("@FiscalYear",fiscalCalendarViewModel.FiscalYear)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetFiscalCalendarByYear",param2);
                var eventInfo = dataTable.AsEnumerable().Select(dtRow => new
                {
                    id = Convert.ToInt32(dtRow["id"]),
                    FiscalYear = Convert.ToInt32(dtRow["FiscalYear"]),
                    Quarter = Convert.ToInt32(dtRow["Quarter"]),
                    startDate = dtRow.Field<DateTime?>("startDate"),
                    endDate = dtRow.Field<DateTime?>("endDate"),
                    WWinQuarter = Convert.ToInt32(dtRow["WWinQuarter"]),
                    WWCumulative = Convert.ToInt32(dtRow["WWCumulative"]),
                    QuarterDescription = dtRow.Field<string>("QuarterDescription")
                }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(eventInfo);
                return jsonString;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }

        public string DeleteFiscalCalendar(string connString,FiscalCalendarViewModel fiscalCalendarViewModel)
        {
            DataTable dataTable = null;
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@id",fiscalCalendarViewModel.id),
                };
                var newId = SqlHelper.ExecuteProcedureReturnInt(connString, "uspDeleteFiscalCalendar",param);
                if (newId <0)
                {
                    throw new Exception("Error on the Insertion of new Data");
                }
                SqlParameter[] param2 = {
                    new SqlParameter("@FiscalYear",fiscalCalendarViewModel.FiscalYear)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetFiscalCalendarByYear",param2);
                var eventInfo = dataTable.AsEnumerable().Select(dtRow => new
                {
                    id = Convert.ToInt32(dtRow["id"]),
                    FiscalYear = Convert.ToInt32(dtRow["FiscalYear"]),
                    Quarter = Convert.ToInt32(dtRow["Quarter"]),
                    startDate = dtRow.Field<DateTime?>("startDate"),
                    endDate = dtRow.Field<DateTime?>("endDate"),
                    WWinQuarter = Convert.ToInt32(dtRow["WWinQuarter"]),
                    WWCumulative = Convert.ToInt32(dtRow["WWCumulative"]),
                    QuarterDescription = dtRow.Field<string>("QuarterDescription")
                }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(eventInfo);
                return jsonString;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }
    }
}