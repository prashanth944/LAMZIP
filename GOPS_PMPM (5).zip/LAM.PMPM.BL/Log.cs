﻿using LAM.PMPM.DAL;
using LAM.PMPM.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace LAM.PMPM.BL
{
    public class Log
    {
        DataTable dataTable;
        public List<LogProgressView> GetLogProgress(string connString)
        {
            try
            {
                dataTable = new DataTable();
                dataTable = SqlHelper.GetDataTable(connString, "USPGetLogProgress", null);
                List<LogProgressView> logProgressList = dataTable.AsEnumerable().Select(dtRow => new LogProgressView()
                {
                    StepNo = dtRow.Field<int>("StepNo"),
                    UserID = dtRow.Field<long>("UserID"),
                    TechnicianNote = dtRow.Field<string>("TechnicianNotes")
                }).ToList();
                return logProgressList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<StepDetail> GetStepsDetails(string connString, int pilotproductId, int operationId)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
               new SqlParameter("@PilotProductID", pilotproductId),
               new SqlParameter("@OperationId", operationId)
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetStepsByOPAndPPId", param);

            List<StepDetail> masterRecords = dataTable.AsEnumerable().Select(dtRow => new StepDetail()
            {
                StepRecordId = dtRow.Field<long?>("StepRecordID"),
                StepNo = dtRow.Field<int?>("StepNo"),
                Completed = dtRow.Field<bool?>("Completed"),
                Skipped = dtRow.Field<bool?>("Skipped"),
                Excluded = dtRow.Field<bool?>("Excluded"),
                CompletedBy = dtRow.Field<string>("CompletedBy"),
                CompletedById = dtRow.Field<long?>("CompletedById"),
                TechnicianNotes = dtRow.Field<string>("TechnicianNotes"),
                NumberofSteps = dtRow.Field<int>("NumberofSteps"),
                OperationId = dtRow.Field<long?>("OperationId"),
                CycleTimeMinutes = dtRow.Field<double?>("CycleTimeMinutes"),
                PilotProductId = dtRow.Field<long?>("PilotProductId"),
                Reworked = dtRow.Field<bool?>("Reworked"),
                ReworkedBy = dtRow.Field<string>("ReWorkerdBy")
            }).ToList();

            StepDetail lastStepDetail = masterRecords.Where(x => x.StepNo == masterRecords.Max(y => y.StepNo)).FirstOrDefault();
            if (lastStepDetail != null)
            {
                int numberOfSteps = lastStepDetail.NumberofSteps;
                int? lastStep = lastStepDetail.StepNo;
                List<int?> steps = new List<int?>();

                if (!lastStep.HasValue)
                {
                    lastStep = 1;
                    lastStepDetail.StepNo = 1;
                }

                for (int? i = 1; i <= numberOfSteps; i++)
                {
                    steps.Add(i);
                }


                foreach (int? i in steps)
                {
                    if (masterRecords.Where(x => x.StepNo == i).Count() <= 0)
                    {
                        masterRecords.Add(new StepDetail()
                        {
                            StepRecordId = null,
                            StepNo = i,
                            Completed = false,
                            Skipped = false,
                            Excluded = false,
                            CompletedBy = null,
                            CompletedById = null,
                            TechnicianNotes = null,
                            NumberofSteps = lastStepDetail.NumberofSteps,
                            OperationId = lastStepDetail.OperationId,
                            CycleTimeMinutes = lastStepDetail.CycleTimeMinutes,
                            PilotProductId = lastStepDetail.PilotProductId
                        });
                    }
                }
            }


            return masterRecords.OrderBy(x => x.StepNo).ToList();
        }

        public int UpdateStepRecordRework(string connString, StepDetail stepDetail)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@StepRecordId",  stepDetail.StepRecordId),
                    new SqlParameter("@Reworked",  stepDetail.Reworked),
                    new SqlParameter("@ReworkedBy",  stepDetail.ReworkedById),
                    new SqlParameter("@TechnicianNotes",  stepDetail.TechnicianNotes),
                    new SqlParameter("@IsOnlyTechNote", stepDetail.IsOnlyTechNote)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateStepRecordRework", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<StepDetail> GetStepsDetailsRework(string connString, int pilotproductId, int operationId)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
               new SqlParameter("@PilotProductID", pilotproductId),
               new SqlParameter("@OperationId", operationId)
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetStepsReworkByOPAndPPId", param);

            List<StepDetail> masterRecords = dataTable.AsEnumerable().Select(dtRow => new StepDetail()
            {
                StepRecordId = dtRow.Field<long?>("StepRecordID"),
                StepNo = dtRow.Field<int?>("StepNo"),
                Reworked = dtRow.Field<bool?>("Reworked"),// since it will always be false on this screen
                ReworkedBy = dtRow.Field<string>("ReworkedBy"),
                ReworkedById = dtRow.Field<long?>("ReworkedById"),
                TechnicianNotes = dtRow.Field<string>("TechnicianNotes"),
                NumberofSteps = dtRow.Field<int>("NumberofSteps"),
                OperationId = dtRow.Field<long?>("OperationId"),
                CycleTimeMinutes = dtRow.Field<double?>("CycleTimeMinutes"),
                PilotProductId = dtRow.Field<long?>("PilotProductId"),
                Completed = dtRow.Field<bool?>("Completed"),
                CompletedBy = dtRow.Field<string>("CompletedBy"),
                CompletedById = dtRow.Field<long?>("CompletedById"),
            }).ToList();

            StepDetail lastStepDetail = masterRecords.Where(x => x.StepNo == masterRecords.Max(y => y.StepNo)).FirstOrDefault();

            int numberOfSteps = lastStepDetail.NumberofSteps;
            int? lastStep = lastStepDetail.StepNo;
            List<int?> steps = new List<int?>();

            if (!lastStep.HasValue)
            {
                lastStep = 1;
                lastStepDetail.StepNo = 1;
            }

            for (int? i = 1; i <= numberOfSteps; i++)
            {
                steps.Add(i);
            }


            foreach (int? i in steps)
            {
                if (masterRecords.Where(x => x.StepNo == i).Count() <= 0)
                {
                    masterRecords.Add(new StepDetail()
                    {
                        StepRecordId = null,
                        StepNo = i,
                        Completed = false,
                        Skipped = false,
                        Excluded = false,
                        CompletedBy = null,
                        CompletedById = null,
                        TechnicianNotes = null,
                        NumberofSteps = lastStepDetail.NumberofSteps,
                        OperationId = lastStepDetail.OperationId,
                        CycleTimeMinutes = lastStepDetail.CycleTimeMinutes,
                        PilotProductId = lastStepDetail.PilotProductId,
                        ReworkedById = null,
                        ReworkedBy = null,
                        Reworked = false
                    });
                }
            }

            return masterRecords.OrderBy(x => x.StepNo).ToList();
        }

        public List<StepDetail> GetStepsDetailsReworkForEmail(string connString, int pilotproductId, int operationId)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
               new SqlParameter("@PilotProductID", pilotproductId),
               new SqlParameter("@OperationId", operationId)
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetStepsReworkByOPAndPPId", param);

            List<StepDetail> masterRecords = dataTable.AsEnumerable().Select(dtRow => new StepDetail()
            {
                StepRecordId = dtRow.Field<long?>("StepRecordID"),
                StepNo = dtRow.Field<int?>("StepNo"),
                Reworked = dtRow.Field<bool?>("Reworked"), // since it will always be false on this screen
                ReworkedBy = dtRow.Field<string>("ReworkedBy"),
                ReworkedById = dtRow.Field<long?>("ReworkedById"),
                TechnicianNotes = dtRow.Field<string>("TechnicianNotes"),
                NumberofSteps = dtRow.Field<int>("NumberofSteps"),
                OperationId = dtRow.Field<long?>("OperationId"),
                CycleTimeMinutes = dtRow.Field<double?>("CycleTimeMinutes"),
                PilotProductId = dtRow.Field<long?>("PilotProductId"),
                Completed = dtRow.Field<bool?>("Completed"),
                CompletedBy = dtRow.Field<string>("CompletedBy"),
                CompletedById = dtRow.Field<long?>("CompletedById"),
            }).ToList();

            StepDetail lastStepDetail = masterRecords.Where(x => x.StepNo == masterRecords.Max(y => y.StepNo)).FirstOrDefault();

            int numberOfSteps = lastStepDetail.NumberofSteps;
            int? lastStep = lastStepDetail.StepNo;
            List<int?> steps = new List<int?>();

            if (!lastStep.HasValue)
            {
                lastStep = 1;
                lastStepDetail.StepNo = 1;
            }

            for (int? i = 1; i <= numberOfSteps; i++)
            {
                steps.Add(i);
            }


            foreach (int? i in steps)
            {
                if (masterRecords.Where(x => x.StepNo == i).Count() <= 0)
                {
                    masterRecords.Add(new StepDetail()
                    {
                        StepRecordId = null,
                        StepNo = i,
                        Completed = false,
                        Skipped = false,
                        Excluded = false,
                        CompletedBy = null,
                        CompletedById = null,
                        TechnicianNotes = null,
                        NumberofSteps = lastStepDetail.NumberofSteps,
                        OperationId = lastStepDetail.OperationId,
                        CycleTimeMinutes = lastStepDetail.CycleTimeMinutes,
                        PilotProductId = lastStepDetail.PilotProductId,
                        ReworkedById = null,
                        ReworkedBy = null,
                        Reworked = false
                    });
                }
            }

            return masterRecords.OrderBy(x => x.StepNo).ToList();
        }

        public int DeleteFile(string connString, int workrecordId, string beforeafter, string azFilename, int isAdd)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@WorkRecordId", workrecordId),
                    new SqlParameter("@BeforeOrAfter", beforeafter),
                    new SqlParameter("@FileName ", azFilename),
                    new SqlParameter("@Add ", isAdd)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateWorkRecordReworkFiles", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public long? GetWorkrecordReworkGUID(string connString, string guid)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
               new SqlParameter("@guid", guid)
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetWorkRecordIdByReworkGUID", param);

            WorkRecordReworkModel masterRecords = dataTable.AsEnumerable().Select(dtRow => new WorkRecordReworkModel
            {

                WorkRecordId = dtRow.Field<long?>("WorkRecordID"),

            }).FirstOrDefault();

            return masterRecords.WorkRecordId;
        }

        public void SendEmail(string connString, int workrecordid, string host, SmtpMailHelper smtpMailHelper, string fromEmail)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param =
                {
                    new SqlParameter("@WorkRecordId", workrecordid)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetReworkByWorkRecordId", param);

                Regex rg = new Regex(@"\d+");

                WorkRecordReworkModel masterRecords = dataTable.AsEnumerable().Select(dtRow => new WorkRecordReworkModel
                {
                    WorkRecordReworkId = dtRow.Field<long?>("WorkRecordReworkId"),
                    WorkRecordId = dtRow.Field<long?>("WorkRecordID"),
                    OperationId = dtRow.Field<long?>("OperationID"),
                    PilotProductId = dtRow.Field<long?>("PilotProductId"),
                    OperationDescription = dtRow.Field<string>("Operation"),
                    OperationNumber = string.IsNullOrEmpty(dtRow.Field<string>("Operation")) ? "99999" : rg.Match(dtRow.Field<string>("Operation")).Value,
                    IsOBC = dtRow.Field<bool>("IsOBC"),
                    ReworkDescription = dtRow.Field<string>("ReworkDescription"),
                    BeforePicture = dtRow.Field<string>("BeforePicture").Split("|").Where(x => !string.IsNullOrEmpty(x)).ToList(),
                    AfterPicture = dtRow.Field<string>("AfterPicture").Split("|").Where(x => !string.IsNullOrEmpty(x)).ToList(),
                    RWCause = dtRow.Field<string>("RWCause"),
                    PilotOrSupplier = dtRow.Field<string>("PilotOrSupplierCaused"),
                    ReworkCategoryId = dtRow.Field<long?>("ReworkCategoryId"),
                    ReworkCategory = dtRow.Field<string>("OptionName"),
                    StartTime = dtRow.Field<DateTime>("StartTimestamp"),
                    EndTime = dtRow.Field<DateTime>("EndTimestamp"),
                    IsRunning = dtRow.Field<bool>("IsRunning"),
                    GUID = dtRow.Field<string>("GUID"),
                    ToEmail = dtRow.Field<string>("ToEmail"),
                    CCEmail = dtRow.Field<string>("CCEmail"),
                    ReworkBy = dtRow.Field<string>("ReworkBy"),
                    InterruptionMinutes = dtRow.Field<int>("InterruptionMinutes"),
                    PSNOrBen = dtRow.Field<string>("PSNOrBen")
                }).FirstOrDefault();

                var stepRecord = GetStepsDetailsReworkForEmail(connString, Convert.ToInt32(masterRecords.PilotProductId), Convert.ToInt32(masterRecords.OperationId));

                int maxCount = masterRecords.BeforePicture.Count > masterRecords.AfterPicture.Count ? masterRecords.BeforePicture.Count : masterRecords.AfterPicture.Count;
                StringBuilder photosHTML = new StringBuilder();

                string beforeFirstURL = masterRecords.BeforePicture.Count > 0 ? Uri.EscapeUriString($"https://{host}/downloadFromURL/{masterRecords.GUID}/b/{masterRecords.BeforePicture[0]}") : "";
                string beforeFirst = masterRecords.BeforePicture.Count > 0 ? $"<a href=\"{beforeFirstURL}\">{masterRecords.BeforePicture[0].Replace(masterRecords.WorkRecordId.ToString() + "_b_", "")}</a>" : "";

                string afterFirstURL = masterRecords.AfterPicture.Count > 0 ? Uri.EscapeUriString($"https://{host}/downloadFromURL/{masterRecords.GUID}/a/{masterRecords.AfterPicture[0]}") : "";
                string afterFirst = masterRecords.AfterPicture.Count > 0 ? $"<a href=\"{afterFirstURL}\">{masterRecords.AfterPicture[0].Replace(masterRecords.WorkRecordId.ToString() + "_a_", "")}</a>" : "";

                photosHTML.Append($"<tr><td>Before Picture(s)</td><td>{beforeFirst}</td>" +
                    $"<td>After Picture(s)</td><td>{afterFirst}</td></tr>");


                for (int i = 0 + 1; i < maxCount; i++)
                {
                    string html = "<tr><td></td>";
                    if (i < masterRecords.BeforePicture.Count)
                    {
                        string beforeURL = Uri.EscapeUriString($"https://{host}/downloadFromURL/{masterRecords.GUID}/b/{masterRecords.BeforePicture[i]}");
                        html += $"<td><a href=\"{beforeURL}\">{masterRecords.BeforePicture[i].Replace(masterRecords.WorkRecordId.ToString() + "_b_", "")}</a></td>";
                    }
                    else
                    {
                        html += $"<td></td>";
                    }
                    html += "<td></td>"; //after picture column
                    if (i < masterRecords.AfterPicture.Count)
                    {
                        string afterURL = Uri.EscapeUriString($"https://{host}/downloadFromURL/{masterRecords.GUID}/a/{masterRecords.AfterPicture[i]}");
                        html += $"<td><a href=\"${afterURL}\">{masterRecords.AfterPicture[i].Replace(masterRecords.WorkRecordId.ToString() + "_a_", "")}</a></td>";
                    }
                    else
                    {
                        html += $"<td></td>";
                    }
                    html += "</tr>";
                    photosHTML.Append(html);
                }

                StringBuilder stepsHTML = new StringBuilder();
                foreach (var step in stepRecord)
                {
                    string checkedHTML = step.Reworked.HasValue ? step.Reworked.Value ? "checked" : "" : "";
                    //string checkedHTML = step.Reworked.Value ? "checked" : "";
                    List<string> technicianNotes = !string.IsNullOrEmpty(step.TechnicianNotes) ? step.TechnicianNotes.Split("|").ToList().Select(x => x.Trim()).ToList() : new List<string>();
                    technicianNotes.RemoveAll(x => string.IsNullOrWhiteSpace(x));
                    stepsHTML.Append($"<tr>" +
                        $"  <td style=\"border: 1px solid black;border-collapse: collapse;\">{step.StepNo}</td>" +
                        $"  <td style=\"border: 1px solid black;border-collapse: collapse;\"><input type=\"checkbox\" disabled onclick=\"return false\" {checkedHTML}></td>" +
                        $"  <td style=\"border: 1px solid black;border-collapse: collapse;\">{step.CompletedBy}</td>" +
                        $"  <td style=\"border: 1px solid black;border-collapse: collapse;\">{step.ReworkedBy}</td>" +
                        $"  <td style=\"border: 1px solid black;border-collapse: collapse;\">{string.Join("<br />", technicianNotes)}</td>" +
                        $"  </tr>");
                }

                string body =
                        $"<h1>{masterRecords.PSNOrBen} - Op {masterRecords.OperationNumber}</h1>" +
                        $"<div>" +
                        $"<table style = \"width:100%\">" +
                        $"	<tr><td>Individual Completing Rework</td><td  style=\"border:1px solid;padding: 3px;background-color:lightgray\">{masterRecords.ReworkBy}</td></tr>" +
                        $"    <tr><td>Start Time</td><td style=\"border:1px solid;padding: 3px;background-color:lightgray\">{(masterRecords.StartTime.Value):MM-dd-yyyy hh:mm tt}</td><td style=\"text-align: right;\">End Time</td><td style=\"border:1px solid;padding: 3px;background-color:lightgray\">{(masterRecords.EndTime.Value):MM-dd-yyyy hh:mm tt}</td>" +
                        $"    <td style=\"text-align: right;\">Rework Duration(minutes)</td><td style=\"border:1px solid;padding: 3px;background-color:lightgray\">{Math.Round(((masterRecords.EndTime - masterRecords.StartTime).Value.TotalMinutes) - masterRecords.InterruptionMinutes)}</td></tr>" +
                        $"    <tr><td>Is this rework due to an OBC?</td><td style=\"border:1px solid;padding: 3px;background-color:lightgray\">" + (masterRecords.IsOBC.Value ? "Yes" : "No") + "</td></tr>" +
                        (masterRecords.IsOBC.Value == false ? $"<tr><td>Pilot or Supplier Caused?</td><td style=\"border:1px solid;padding: 3px;background-color:lightgray\">{masterRecords.RWCause}</td></tr>" : "") +
                        (masterRecords.PilotOrSupplier == "P" ? $"<tr><td><b>Rework Category</b></td><td style=\"border:1px solid;padding: 3px;background-color:lightgray\">{masterRecords.ReworkCategory}</td></tr>" : "") +
                        $"    <tr rowspan=\"2\"><td><b>Rework Description</b></td><td colspan=\"5\" style=\"border:1px solid;padding: 3px;background-color:lightgray\">{masterRecords.ReworkDescription}</td></tr>" +
                        $"</table>" +
                        $"</div>" +
                        $"<br />" +
                        $"<p>Click <a href=\"https://{host}/log-progress/{masterRecords.GUID}\">here</a> to see the rework log in PMPM web application.</p>" +
                        $"<div>" +
                        $"	<h3>Pictures</h3>" +
                        $"    <hr>" +
                        $"    <table style = \"width:100%;border: 1px solid black;border-collapse: collapse;\">{photosHTML}</table>" +
                        $"</div>" +
                        $"<br />" +
                        $"<div>" +
                        $"	<h3>Steps</h3>" +
                        $"    <hr>	" +
                        $"    <table style = \"width:100%\">" +
                        $"    	<thead style=\"background-color:lightgray\">" +
                        $"        	  <td style=\"border: 1px solid black;border-collapse: collapse;width:40px\">Step</td>" +
                        $"            <td style=\"border: 1px solid black;border-collapse: collapse;width:60px\">Reworked</td>" +
                        $"            <td style=\"border: 1px solid black;border-collapse: collapse;width:120px\">Original Work completed By</td>" +
                        $"            <td style=\"border: 1px solid black;border-collapse: collapse;width:120px\">Reworked By</td>" +
                        $"            <td style=\"border: 1px solid black;border-collapse: collapse;\">Technician Notes</td>" +
                        $"        </thead>" +
                        $"        <tbody>{stepsHTML}</tbody>" +
                        $"    </table>" +
                        $"</div>" +
                        $"<div>" +
                        $"<img src=\"\"/>" +
                        $"<h4>Note: this email was sent from a notification-only email address that cannot accept incoming e-mail. Please do not reply to this message.</h4>" +
                        $"</div>" +
                        $"<div>" +
                        $"	<p style=\"font-size: 8px;\">LAM RESEARCH CONFIDENTIALITY NOTICE: This e-mail transmission, and any documents, files, or previous e-mail messages attached" +
                        $" to it, (collectively, \"E-mail Transmission\") may be subject to one or more of the following based on the associated sensitivity level: E-mail Transmission" +
                        $" (i) contains confidential information, (ii) is prohibited from distribution outside of Lam, and/or (iii) is intended solely for and restricted to the specified" +
                        $" recipient(s). If you are not the intended recipient, or a person responsible for delivering it to the intended recipient, you are hereby notified that any " +
                        $"disclosure, copying, distribution or use of any of the information contained in or attached to this message is STRICTLY PROHIBITED. If you have received this" +
                        $" transmission in error, please immediately notify the sender and destroy the original transmission and its attachments without reading them or saving them " +
                        $"to disk. Thank you.</p>" +
                        $"</div>";


                smtpMailHelper.Body = body;
                smtpMailHelper.Recipient = masterRecords.ToEmail;
                smtpMailHelper.RecipientCC = masterRecords.CCEmail;
                smtpMailHelper.Sender = fromEmail;
                smtpMailHelper.Subject = $"Rework Log for {masterRecords.PSNOrBen} – Op {masterRecords.OperationNumber}";

                smtpMailHelper.Send();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public object GetWorkrecordReworkByGUID(string connString, string guid)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
               new SqlParameter("@guid", guid)
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetReworkByGUID", param);

            WorkRecordReworkModel masterRecords = dataTable.AsEnumerable().Select(dtRow => new WorkRecordReworkModel
            {
                WorkRecordReworkId = dtRow.Field<long?>("WorkRecordReworkId"),
                WorkRecordId = dtRow.Field<long?>("WorkRecordID"),
                OperationId = dtRow.Field<long?>("OperationID"),
                OperationDescription = dtRow.Field<string>("Operation"),
                IsOBC = dtRow.Field<bool?>("IsOBC"),
                ReworkDescription = dtRow.Field<string>("ReworkDescription"),
                BeforePicture = dtRow.Field<string>("BeforePicture").Split("|").Where(x => !string.IsNullOrEmpty(x)).ToList(),
                AfterPicture = dtRow.Field<string>("AfterPicture").Split("|").Where(x => !string.IsNullOrEmpty(x)).ToList(),
                RWCause = dtRow.Field<string>("RWCause"),
                PilotOrSupplier = dtRow.Field<string>("PilotOrSupplierCaused"),
                ReworkCategoryId = dtRow.Field<long?>("ReworkCategoryId"),
                ReworkCategory = dtRow.Field<string>("OptionName"),
                StartTime = dtRow.Field<DateTime?>("StartTimestamp"),
                EndTime = dtRow.Field<DateTime?>("EndTimestamp"),
                IsRunning = dtRow.Field<bool>("IsRunning"),
                PilotProductId = dtRow.Field<long?>("PilotProductId"),
                PSNOrBen = dtRow.Field<string>("PSNOrBen")
            }).FirstOrDefault();

            return masterRecords;
        }

        public int UpdateReworkFile(string connString, int workrecordId, string beforeafter, string filename, int isAdd)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@WorkRecordId", workrecordId),
                    new SqlParameter("@BeforeOrAfter", beforeafter),
                    new SqlParameter("@FileName ", filename),
                    new SqlParameter("@Add ", isAdd)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateWorkRecordReworkFiles", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int UpdateAllStepRecord(string connString, List<StepDetail> stepDetails)
        {
            try
            {
                List<int> results = new List<int>();
                foreach (var stepDetail in stepDetails)
                {
                    var resultCount = 0;
                    var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                    {
                        Direction = ParameterDirection.Output
                    };

                    SqlParameter[] param = {
                    new SqlParameter("@PilotProductId", stepDetail.PilotProductId),
                    new SqlParameter("@OperationId",  stepDetail.OperationId),
                    new SqlParameter("@CompletedBy ",  stepDetail.CompletedById),
                    new SqlParameter("@SkippedBy",  stepDetail.SkippedById),
                    new SqlParameter("@ExcludedBy ",  stepDetail.ExcludedById),
                    new SqlParameter("@Completed",  stepDetail.Completed),
                    new SqlParameter("@Skipped",  stepDetail.Skipped),
                    new SqlParameter("@Excluded", stepDetail.Excluded),
                    new SqlParameter("@TechnicianNotes",  stepDetail.TechnicianNotes),
                    new SqlParameter("@StepNo ",  stepDetail.StepNo),
                    new SqlParameter("@StepRecordId",  stepDetail.StepRecordId),
                    new SqlParameter("@IsAllUpdate",  true),
                    new SqlParameter("@Reworked",  stepDetail.Reworked),
                    new SqlParameter("@ReworkedBy",  stepDetail.ReworkedById)
                    ,outParam
                };
                    resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateAddStepRecord", param);
                    results.Add(resultCount);
                }

                foreach (var item in results)
                {
                    if (item == 0)
                    {
                        return 0;
                    }
                    else
                    {
                        return 1;
                    }
                }

                return 0;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public object GetWorkrecordRework(string connString, int workrecordId)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
               new SqlParameter("@WorkRecordId", workrecordId)
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetReworkByWorkRecordId", param);

            WorkRecordReworkModel masterRecords = dataTable.AsEnumerable().Select(dtRow => new WorkRecordReworkModel
            {
                WorkRecordReworkId = dtRow.Field<long?>("WorkRecordReworkId"),
                WorkRecordId = dtRow.Field<long?>("WorkRecordID"),
                OperationId = dtRow.Field<long?>("OperationID"),
                OperationDescription = dtRow.Field<string>("Operation"),
                IsOBC = dtRow.Field<bool?>("IsOBC"),
                ReworkDescription = dtRow.Field<string>("ReworkDescription"),
                BeforePicture = dtRow.Field<string>("BeforePicture").Split("|").Where(x => !string.IsNullOrEmpty(x)).ToList(),
                AfterPicture = dtRow.Field<string>("AfterPicture").Split("|").Where(x => !string.IsNullOrEmpty(x)).ToList(),
                RWCause = dtRow.Field<string>("RWCause"),
                PilotOrSupplier = dtRow.Field<string>("PilotOrSupplierCaused"),
                ReworkCategoryId = dtRow.Field<long?>("ReworkCategoryId"),
                ReworkCategory = dtRow.Field<string>("OptionName"),
                StartTime = dtRow.Field<DateTime?>("StartTimestamp"),
                EndTime = dtRow.Field<DateTime?>("EndTimestamp"),
                IsRunning = dtRow.Field<bool>("IsRunning")
            }).FirstOrDefault();

            return masterRecords;
        }

        public object GetWorkrecordReworkGUID(string connString, int workrecordId)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
               new SqlParameter("@WorkRecordId", workrecordId)
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetReworkGUIDByWorkRecordId", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
            {
                GUID = dtRow.Field<string>("GUID"),
            }).FirstOrDefault();

            return masterRecords;
        }

        public int UpdateWorkrecord(string connString, WorkRecordModel workRecordModel, int workrecordid)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@WorkRecordId", workrecordid),
                    new SqlParameter("@StandardExceptionCategoryId", workRecordModel.StandardTimeExceptionCategoryId),
                    new SqlParameter("@Notes ", workRecordModel.Notes),
                    new SqlParameter("@EndTime",workRecordModel.EndTime),
                    new SqlParameter("@IsUserCancelled",workRecordModel.IsUserCancelled),
                    new SqlParameter("@UserCancelledBy",workRecordModel.UserCancelledBy)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateWorkRecordExceptions", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int UpdateWorkrecordRework(string connString, WorkRecordReworkModel workRecordModel, int workrecordid)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@WorkRecordId", workrecordid),
                    new SqlParameter("@IsOBC", workRecordModel.IsOBC),
                    new SqlParameter("@PilotOrSupplier ", workRecordModel.PilotOrSupplier),
                    new SqlParameter("@ReworkCategoryId",workRecordModel.ReworkCategoryId),
                    new SqlParameter("@ReworkDescription", workRecordModel.ReworkDescription),
                    new SqlParameter("@EndTime",workRecordModel.EndTime)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateWorkRecordRework", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int LogOperationDelete(string connString, int workrecordid)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@WorkRecordId", workrecordid)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateLogOperationCancel", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int LogOperationInterruptionDelete(string connString, int workrecordid)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@WorkRecordId", workrecordid)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateInterruptionCancel", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public object GetInterruptsByWorkRecordId(string connString, int workrecordId)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
               new SqlParameter("@WorkRecordId", workrecordId)
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetInterruptionsOfUser", param);

            List<Interrupt> masterRecords = dataTable.AsEnumerable().Select(dtRow => new Interrupt
            {
                InterruptionCategory = dtRow.Field<string>("Category"),
                InterruptionCategoryId = dtRow.Field<long?>("InterruptionCategoryId"),
                Notes = dtRow.Field<string>("Notes"),
                InterruptTime = dtRow.Field<int?>("InterruptTime")
            }).ToList();

            return masterRecords;
        }

        public object GetInterruptsByOperationAndPPId(string connString, int PPId, int OperationId)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
               new SqlParameter("@PPId", PPId),
               new SqlParameter("@OperationID", OperationId)
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetInterruptionsByOperation", param);

            List<InterruptByOperation> masterRecords = dataTable.AsEnumerable().Select(dtRow => new InterruptByOperation
            {
                Category = dtRow.Field<string>("Category"),
                UserName = dtRow.Field<string>("UserName"),
                InterruptionStartTime = dtRow.Field<DateTime?>("InterruptionStart"),
                InterruptionEndTime = dtRow.Field<DateTime?>("InterruptionEnd"),
                InterruptionMinutes = dtRow.Field<int?>("InterruptionMin"),
                Notes = dtRow.Field<string>("Notes"),
                
            }).ToList();

            return masterRecords;
        }

        public object GetStandardTimeExceptionCategory(string connString)
        {
            DataTable dataTable;

            dataTable = SqlHelper.GetDataTable(connString, "uspGetStandardTimeCategory");

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
            {
                StandardTimeExceptionCategoryId = dtRow.Field<long?>("StandardTimeExceptionCategoryId"),
                OptionName = dtRow.Field<string>("OptionName")
            }).ToList();

            return masterRecords;
        }

        public object GetReworkCategory(string connString)
        {
            DataTable dataTable;

            dataTable = SqlHelper.GetDataTable(connString, "uspGetReworkCategory");

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
            {
                Id = dtRow.Field<long?>("ReworkCategoryId"),
                Category = dtRow.Field<string>("OptionName")
            }).ToList();

            return masterRecords;
        }

        public object GetInterruptionCategory(string connString)
        {
            DataTable dataTable;

            dataTable = SqlHelper.GetDataTable(connString, "uspGetInterruptionCategory");

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
            {
                InterruptionCategoryId = dtRow.Field<long?>("InterruptionCategoryId"),
                OptionName = dtRow.Field<string>("OptionName")
            }).ToList();

            return masterRecords;
        }

        public int StartEndInterruption(string connString, InterruptionModel interruptionModel)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@PilotProductId", interruptionModel.PilotProductId),
                    new SqlParameter("@OperationId",  interruptionModel.OperationId),
                    new SqlParameter("@UserId ",  interruptionModel.UserId),
                    new SqlParameter("@InterruptionStartTime",  interruptionModel.InterruptionStartTime),
                    new SqlParameter("@InterruptionEndTime",  interruptionModel.InterruptionEndTime),
                    new SqlParameter("@MaxCurrentWorkId",  interruptionModel.WorkRecordId),
                    new SqlParameter("@InterruptionCategoryId",  interruptionModel.InterruptionCategoryId),
                    new SqlParameter("@Notes",  interruptionModel.Notes)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspStartEndInterruption", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public OperationLogDetail GetOperationLogDetails(string connString, int pilotproductId, int operationId, int userId, bool isRework)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
               new SqlParameter("@PilotProductID", pilotproductId),
               new SqlParameter("@OperationId", operationId),
               new SqlParameter("@UserId", userId),
               new SqlParameter("@IsRework", isRework),
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetLogDetails", param);

            OperationLogDetail masterRecords = dataTable.AsEnumerable().Select(dtRow => new OperationLogDetail()
            {
                OperationId = dtRow.Field<long?>("OperationID"),
                Description = dtRow.Field<string>("Description"),
                CycleTimeMinutes = dtRow.Field<double?>("CycleTimeMinutes"),
                OriginalStartTime = dtRow.Field<DateTime?>("OriginalOperationStartTime"),
                StartTime = dtRow.Field<DateTime?>("CurrentStartTime"),
                EndTime = dtRow.Field<DateTime?>("CurrentEndTime"),
                IsRunning = dtRow.Field<bool?>("IsRunning"),
                IsInterrupted = dtRow.Field<bool?>("IsInterrupted"),
                LatestInterruptionTime = dtRow.Field<DateTime?>("LatestInterruptionTime"),
                TotalInterruptionMinutes = dtRow.Field<int?>("TotalInterruptionMinutes"),
                TotalInterruptionSeconds = dtRow.Field<int?>("TotalInterruptionSeconds"),
                NumberOfSteps = dtRow.Field<int?>("NumberofSteps"),
                WorkRecordId = dtRow.Field<long?>("WorkRecordId"),
                OtherUserNotes = dtRow.Field<string>("OtherUserNotes"),
                Notes = dtRow.Field<string>("Notes"),
                ExceptionCategory = dtRow.Field<string>("ExceptionCategory"),
                StandardTimeExceptionCategoryId = dtRow.Field<long?>("StandardTimeExceptionCategoryId"),
                SOELink = dtRow.Field<string>("SOELink"),
                BEN = dtRow.Field<string>("BEN"),
                PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                BeforePicture = dtRow.Field<string>("BeforePicture").Split("|").Where(x => !string.IsNullOrEmpty(x)).ToList(),
                AfterPicture = dtRow.Field<string>("AfterPicture").Split("|").Where(x => !string.IsNullOrEmpty(x)).ToList(),
                BuildStyleID = dtRow.Field<long>("BuildStyleID"),
                BuildStyleName = dtRow.Field<string>("BuildStyleName"),
            }).FirstOrDefault();

            return masterRecords;
        }

        public OperationLogDetailGeneral OperationLogDetailGeneral(string connString, int pilotproductId,
            int operationId)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
                new SqlParameter("@PilotProductID", pilotproductId),
                new SqlParameter("@OperationId", operationId),
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetLogDetailsByOperation", param);

            OperationLogDetailGeneral masterRecords = dataTable.AsEnumerable().Select(dtRow => new OperationLogDetailGeneral()
            {
                Description = dtRow.Field<string>("Description"),
                MinStartTime = dtRow.Field<DateTime?>("MinStartTime"),
                LastEndTime = dtRow.Field<DateTime?>("LastEndTime"),
                TotalInterruptionMinutes = dtRow.Field<int?>("TotalInterruptionMinutes"),
                TotalDurationMinutes = dtRow.Field<int?>("TotalDurationMinutes"),
                BEN = dtRow.Field<string>("BEN"),
                PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber")

            }).FirstOrDefault();

            return masterRecords;
        }

        public int UpdateStepRecord(string connString, StepDetail stepDetail)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@PilotProductId", stepDetail.PilotProductId),
                    new SqlParameter("@OperationId",  stepDetail.OperationId),
                    new SqlParameter("@CompletedBy ",  stepDetail.CompletedById),
                    new SqlParameter("@SkippedBy",  stepDetail.SkippedById),
                    new SqlParameter("@ExcludedBy ",  stepDetail.ExcludedById),
                    new SqlParameter("@Completed",  stepDetail.Completed),
                    new SqlParameter("@Skipped",  stepDetail.Skipped),
                    new SqlParameter("@Excluded", stepDetail.Excluded),
                    new SqlParameter("@TechnicianNotes",  stepDetail.TechnicianNotes),
                    new SqlParameter("@StepNo ",  stepDetail.StepNo),
                    new SqlParameter("@StepRecordId",  stepDetail.StepRecordId)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateAddStepRecord", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public object GetSOELink(string connString, long plantID, long operationId,long PilotProductId)
        {
            try
            {
                string SOELink = null;

                dataTable = new DataTable();
                SqlParameter[] param = {
                 new SqlParameter("@OperationId", operationId),
                  new SqlParameter("@plantID", plantID),
                   new SqlParameter("@PilotProductId", PilotProductId),
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetSOELink", param);

               
                if (dataTable.Rows.Count > 0)
                {
                    string ProductName = dataTable.Rows[0].Field<string>("ProductName");
                    string zoneDescription = dataTable.Rows[0].Field<string>("Description");                    
                    string PlantName = dataTable.Rows[0].Field<string>("PlantName");
                    string SOELinkData = dataTable.Rows[0].Field<string>("SOELink");      
                    string OperationName= dataTable.Rows[0].Field<string>("OperationName");
                    SOELink = SOELinkData + System.Uri.EscapeUriString(ProductName) + "/" + System.Uri.EscapeUriString(zoneDescription)+ "/" + System.Uri.EscapeUriString(OperationName) + "?web=1";
                    return new { URL = SOELink };
                }
                return null;
              
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public object GetSOELinkFileExtension(string connString, long plantID, long operationId, long PilotProductId)
        {
            try
            {
                dataTable = new DataTable();
                SqlParameter[] param = {
                 new SqlParameter("@OperationId", operationId),
                  new SqlParameter("@plantID", plantID),
                   new SqlParameter("@PilotProductId", PilotProductId)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetSOELinkFileExtension", param);


                if (dataTable.Rows.Count > 0)
                {
                    string FileExtension = dataTable.Rows[0].Field<string>("SOEFileExt");
                    
                    return FileExtension;
                }
                return null;

            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int UpdateSOELinkFileExtension(string connString, long plantID, long operationId, long PilotProductId, string FileExtension)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@OperationId", operationId),
                  new SqlParameter("@plantID", plantID),
                   new SqlParameter("@PilotProductId", PilotProductId),
                    new SqlParameter("@FileExtension", FileExtension)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateSOELinkFileExtension", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
    }
}
