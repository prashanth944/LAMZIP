﻿using LAM.PMPM.DAL;
using LAM.PMPM.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Text;
using System.Linq;
using LAM.PMPM.Model.ViewModel;

namespace LAM.PMPM.BL
{
    public class OBCBL
    {
        DataSet dataset = null;
        DataTable dataTable = null;
        public OBCDetails GetOBCDetails(string connString, string status, string BEN)
        {
            dataset = new DataSet();
            SqlParameter[] param = {
                    new SqlParameter("@Status",status),
                new SqlParameter("@BEN",BEN),
                    };
            OBCDetails objList = new OBCDetails();
            List<OBCView> OBCData1 = new List<OBCView>();
            List<OBCView> OBCData2 = new List<OBCView>();
            dataset = SqlHelper.GetDataSet(connString, "uspGetOBCByStatus", param);
            
            try
            {     
                    DataTable dt = dataset.Tables[0];
                    DataTable dt1 = dataset.Tables[1];
                    OBCView OBCData= new OBCView();
                OBCData1 = dt.AsEnumerable().Select(dtRow => new OBCView()
                    {
                        Status = dtRow.Field<string>("RecordStatus"),
                        ID = dtRow.Field<string>("OBC"),

                        PartCost = dtRow.Field<decimal>("PartCost"),
                        MaterialDescription = dtRow.Field<string>("MaterialDescription"),
                        LineItemNumber = dtRow.Field<string>("LineItemNumber"),
                        Operation = dtRow.Field<string>("Operation"),
                        RequiredQty = dtRow.Field<decimal>("RequiredQty"),
                        WithdrawnQty = dtRow.Field<decimal>("WithdrawnQty"),
                        Variance = dtRow.Field<decimal>("Variance"),
                        ScrapVal = dtRow.Field<bool?>("ScrapVal"),
                        LongText = dtRow.Field<string>("LongText"),
                        CompletionDate = dtRow.Field<DateTime?>("CompletionDate"),
                        RecID = dtRow.Field<int?>("RecID"),
                        PartNumber = dtRow.Field<string>("PartNumber"),
                        CompletionText = dtRow.Field<string>("CompletionTxt"),

                    }).ToList();
                    OBCData2 = dt1.AsEnumerable().Select(dtRow => new OBCView()
                    {
                        Status = dtRow.Field<string>("RecordStatus"),
                        ID = dtRow.Field<string>("OBC"),

                        PartCost = dtRow.Field<decimal>("PartCost"),
                        MaterialDescription = dtRow.Field<string>("MaterialDescription"),
                        LineItemNumber = dtRow.Field<string>("LineItemNumber"),
                        Operation = dtRow.Field<string>("Operation"),
                        RequiredQty = dtRow.Field<decimal>("RequiredQty"),
                        WithdrawnQty = dtRow.Field<decimal>("WithdrawnQty"),
                        Variance = dtRow.Field<decimal>("Variance"),
                        ScrapVal = dtRow.Field<bool?>("ScrapVal"),
                        LongText = dtRow.Field<string>("LongText"),
                        CompletionDate = dtRow.Field<DateTime?>("CompletionDate"),
                        RecID = dtRow.Field<int?>("RecID"),
                        PartNumber = dtRow.Field<string>("PartNumber"),
                        CompletionText = dtRow.Field<string>("CompletionTxt"),

                    }).ToList();
                objList.OBCADD = OBCData1;
                objList.OBCRTS = OBCData2;
               
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            return objList;
        }

        public List<OBCView> GetRTSDetails(string connString, string status, string BEN)
        {
            dataTable = new DataTable();
            SqlParameter[] param = {
                    new SqlParameter("@Status",status),
                new SqlParameter("@BEN",BEN),
                    };
            List<OBCView> RTSData = new List<OBCView>();
            dataTable = SqlHelper.GetDataTable(connString, "uspGetRTSByStatus", param);
            try
            {
                RTSData = dataTable.AsEnumerable().Select(dtRow => new OBCView()
                {
                    Status = dtRow.Field<string>("Status"),
                    ID = dtRow.Field<string>("ID"),
                    VarianceType = dtRow.Field<string>("VarianceType"),
                    Type = dtRow.Field<string>("Type"),
                    PartCost = dtRow.Field<decimal>("PartCost"),
                    MaterialDescription = dtRow.Field<string>("MaterialDescription"),
                    LineItemNumber = dtRow.Field<string>("LineItemNumber"),
                    Operation = dtRow.Field<string>("Operation"),
                    RequiredQty = dtRow.Field<decimal>("RequiredQty"),
                    WithdrawnQty = dtRow.Field<decimal>("WithdrawnQty"),
                    Variance = dtRow.Field<decimal>("Variance"),
                    ScrapVal = dtRow.Field<bool?>("ScrapVal"),
                    LongText = dtRow.Field<string>("LongText"),
                    RecID = dtRow.Field<int?>("RecID"),
                    PartNumber = dtRow.Field<string>("PartNumber"),
                }).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            return RTSData;
        }


        public List<NCIView> GetNCIDetails(string connString, string status, string ID,int PlantID)
        {
            dataTable = new DataTable();
            SqlParameter[] param = {
                    new SqlParameter("@Status",status),
                new SqlParameter("@ID",ID),
                 new SqlParameter("@PlantID",PlantID),
                    };
            List<NCIView> RTSData = new List<NCIView>();
            dataTable = SqlHelper.GetDataTable(connString, "uspGetNCIByStatusandPlantID", param);
            try
            {
                RTSData = dataTable.AsEnumerable().Select(dtRow => new NCIView()
                {
                    Status = dtRow.Field<string>("CurrentState"),
                    DateOpened = dtRow.Field<DateTime>("DateOpened"),
                    Requestor = dtRow.Field<string>("Requestor"),
                    Title = dtRow.Field<string>("Title"),
                    PartNumber = dtRow.Field<string>("PartNumber"),
                    Impact = dtRow.Field<string>("Impact"),
                    POM = dtRow.Field<string>("POM"),
                    POMDescripton = dtRow.Field<string>("POMDescription"),
                    Symptom = dtRow.Field<string>("Symptom"),
                    SymptomDetail = dtRow.Field<string>("SymptomDetail"),
                    ID = dtRow.Field<int?>("IQMSID"),
                    ISClosed = dtRow.Field<string>("ISClosed"),
                    LineDown = dtRow.Field<string>("LineDown"),
                    InvestigationGroup = dtRow.Field<string>("InvestigationGroup"),
                    InvestigationGroupDetail = dtRow.Field<string>("InvestigationGroupDetail"),
                    Resolution = dtRow.Field<string>("Resolution"),


                }).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            return RTSData;
        }


        public List<NCIView> GetMTTDetails(string connString, string ID)
        {
            dataTable = new DataTable();
            SqlParameter[] param = {
                    new SqlParameter("@ID",ID),
                
                    };
            List<NCIView> MTTData = new List<NCIView>();
            dataTable = SqlHelper.GetDataTable(connString, "uspGetMTTData", param);
            try
            {
                MTTData = dataTable.AsEnumerable().Select(dtRow => new NCIView()
                {
                    RecID = dtRow.Field<int?>("RecID"),
                    PartNumber = dtRow.Field<string>("PartNumber"),
                    Quantity= dtRow.Field<decimal>("Quantity"),
                    PartDescription = dtRow.Field<string>("PartDescription"),
                    Status = dtRow.Field<string>("Status"),
                    PurchOrd = dtRow.Field<string>("PurchOrd"),
                    CreDate = dtRow.Field<DateTime>("CreDate"),
                    reasonCode = dtRow.Field<string>("reasonCode"),
                    TechnicianNotes = dtRow.Field<string>("TechnicianNotes"),
                    AddorRemoved = dtRow.Field<string>("AddRemoved"),
                    MTTNo = dtRow.Field<string>("MTTNo"),

                }).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            return MTTData;
        }

        public List<IssueLogView> GetIssueLogDetails(string connString, string ID, int PlantID)
        {
            dataTable = new DataTable();
            SqlParameter[] param = {
                    new SqlParameter("@ID",ID),                      
                new SqlParameter("@PlantID",PlantID),              
                    };
            List<IssueLogView> IssueData = new List<IssueLogView>();
            dataTable = SqlHelper.GetDataTable(connString, "uspIssuesLogData", param);
            try
            {
                IssueData = dataTable.AsEnumerable().Select(dtRow => new IssueLogView()
                {
                    RecID = dtRow.Field<int?>("RecID"),
                    Urgency = dtRow.Field<string>("Urgency"),
                    IssueLog = dtRow.Field<string>("IssueLog"),
                    IssueType = dtRow.Field<string>("IssueType"),
                    IssueTitle = dtRow.Field<string>("IssueTitle"),
                    Status = dtRow.Field<string>("Status"),
                    Part = dtRow.Field<string>("Part"),
                    IssueDetail = dtRow.Field<string>("IssueDetail"),
                    IssueDisposition = dtRow.Field<string>("IssueDisposition"),
                    DateCreated = dtRow.Field<DateTime?>("DateCreated"),
                    DivisionID = dtRow.Field<long?>("DivisionID"),
                    DivisionName = dtRow.Field<string>("DivisionName")
                }).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            return IssueData;
        }

        public List<IssueLogView> GetIssueLogStatusCount(string connString, string ID, int PlantID)
        {
            dataTable = new DataTable();
            SqlParameter[] param = {
                    new SqlParameter("@ID",ID),
                new SqlParameter("@PlantID",PlantID),
                    };
            List<IssueLogView> IssueData = new List<IssueLogView>();
            dataTable = SqlHelper.GetDataTable(connString, "uspIssuesLogDataStatusCount", param);
            try
            {
                IssueData = dataTable.AsEnumerable().Select(dtRow => new IssueLogView()
                {
                    Count = dtRow.Field<int?>("Count"),
                    StatusforCount = dtRow.Field<string>("Status"),

                }).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            return IssueData;
        }

        public List<ShortagesView> GetShortagesDetails(string connString, string ID)
        {
            dataTable = new DataTable();
            SqlParameter[] param = {
                    new SqlParameter("@ID",ID),

                    };
            List<ShortagesView> ShortagesData = new List<ShortagesView>();
            dataTable = SqlHelper.GetDataTable(connString, "uspGetShortages", param);
            try
            {
                ShortagesData = dataTable.AsEnumerable().Select(dtRow => new ShortagesView()
                {
                 
                    PartNumber = dtRow.Field<string>("Matnr"),
                    Description = dtRow.Field<string>("Maktx"),
                    Qty = dtRow.Field<decimal?>("ShortQty"),
                    Supplies = dtRow.Field<string>("Supplies"),
                    DueDate = dtRow.Field<DateTime?>("ShortDueDate"),
                    NeedDate = dtRow.Field<DateTime?>("ShortNeedDate"),
                    OP = dtRow.Field<string>("Vornr"),

                }).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            return ShortagesData;
        }

        public List<MasterRecords> GetMTTStatusDLL(string connString)
        {
            try
            {

                DataTable dataTable = new DataTable();
                dataTable = SqlHelper.GetDataTable(connString, "uspGetMTTStatus", null);
                List<MasterRecords> masterRecords = dataTable.AsEnumerable().Select(dtRow => new MasterRecords()
                {
                    MasterRecordID = Convert.ToInt32(dtRow["MasterRecordID"]),
                    MasterRecordName = Convert.ToString(dtRow["MasterRecordName"]),
                }).ToList();
                return masterRecords;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public List<MasterRecords> GetMTTAddRemoveDLL(string connString)
        {
            try
            {

                DataTable dataTable = new DataTable();
                dataTable = SqlHelper.GetDataTable(connString, "uspGetMTTAddRemove", null);
                List<MasterRecords> masterRecords = dataTable.AsEnumerable().Select(dtRow => new MasterRecords()
                {
                    MasterRecordID = Convert.ToInt32(dtRow["MasterRecordID"]),
                    MasterRecordName = Convert.ToString(dtRow["MasterRecordName"]),
                }).ToList();
                return masterRecords;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int UpdateMTTData(string connString, NCIView[] MTT)
        {
            var resultCount = 0;
            var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            try
            {
                foreach (var items in MTT)
                {
                    SqlParameter[] param = {
               new SqlParameter("@MTTNo", items.MTTNo),
                    new SqlParameter("@Status", items.Status),
                    new SqlParameter("@TechnicianNotes ",  items.TechnicianNotes),
                    new SqlParameter("@AddRemoved", items.AddorRemoved),
                    new SqlParameter("@RECID", items.RecID),
                 outParam

            };

                    resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateMTTOverlayData", param);
                }
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public int UpdateStatusRTS(string connString, RTSStatusUpdate info)
        {
            var resultCount = 0;
            var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            try
            {
                
                    SqlParameter[] param = {
                        new SqlParameter("@NewStatus", info.Status),
                        new SqlParameter("@Id", info.Id),
                        outParam
                    };

                    resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateRTSStatusById", param);
                
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


    }
}
