﻿using LAM.PMPM.DAL;
using LAM.PMPM.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Text;
using System.Linq;
using LAM.PMPM.Model.ViewModel;
using static LAM.PMPM.Model.ViewModel.AdminDefaultPrioityView;

namespace LAM.PMPM.BL
{
    public class AdminDefaultsBL
    {

        DataTable dataTable = null;
        public List<AdminDefaultsView> GetAdminDefaultData(string connString, long PlantID)
        {
            dataTable = new DataTable();
            SqlParameter[] param = {
                    new SqlParameter("@PlantID",PlantID),
                    };
            List<AdminDefaultsView> DefaultData = new List<AdminDefaultsView>();
            dataTable = SqlHelper.GetDataTable(connString, "uspGetDefaultOptions", param);
            try
            {
                DefaultData = dataTable.AsEnumerable().Select(dtRow => new AdminDefaultsView()
                {
                    PlantID = dtRow.Field<long>("PlantID"),
                    MaxLaunchesInaWeekRed = dtRow.Field<int?>("MaxLaunchesInaWeekRed"),
                    MaxLaunchesInaWeekYellow = dtRow.Field<int?>("MaxLaunchesInaWeekYellow"),
                    BayUsageWarningRed = dtRow.Field<int?>("BayUsageWarningRed"),
                    BayUsageWarningYellow = dtRow.Field<int?>("BayUsageWarningYellow"),
                    PlannedHighRiskMCSD = dtRow.Field<int?>("PlannedHighRiskMCSD"),
                    PlannedMedRiskMCSD = dtRow.Field<int?>("PlannedMedRiskMCSD"),
                    ScheduleBufferDays = dtRow.Field<int?>("ScheduleBufferDays"),
                    EfficencyFactory = dtRow.Field<int?>("EfficencyFactory"),
                    LaborUtilization = dtRow.Field<int?>("LaborUtilization"),
                    OvertimePerc = dtRow.Field<int?>("OvertimePerc"),
                    PTOPerc = dtRow.Field<int?>("PTOPerc"),
                    LeadDirectPerc = dtRow.Field<int?>("LeadDirectPerc"),
                    PASSDirectPerc = dtRow.Field<int?>("PASSDirectPerc"),
                    ScheduleTimePeriod = dtRow.Field<string>("ScheduleTimePeriod"),
                    ScheduleColorView = dtRow.Field<string>("ScheduleColorView"),
                    OpTimeSTELow = dtRow.Field<int?>("OpTimeSTELow"),
                    OpTimeSTEHigh = dtRow.Field<int?>("OpTimeSTEHigh"),
                }).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            return DefaultData;
        }
        public List<AdminDefaultPrioityView> GetRevenueTypeDefaultDDL(string connString, long PlantID)
        {
            try
            {
                dataTable = new DataTable();
                SqlParameter[] param = {
                    new SqlParameter("@PlantID",PlantID),
                    };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetRevenueTypeDefaultDDL", param);
                List<AdminDefaultPrioityView> revenueList = dataTable.AsEnumerable().Select(dtRow => new AdminDefaultPrioityView()
                {
                    SchedulePriorityRevenueTypeID = dtRow.Field<int?>("SchedulePriorityrevenueTypeID"),
                    RevenueType = dtRow.Field<string>("RevenueType"),
                    RevenuePriorityLevel = dtRow.Field<int?>("PriorityLevel"),
                    RevenueTypeID = dtRow.Field<int?>("RevenueTypeID")

                }).ToList();
                return revenueList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<AdminDefaultPrioityView> GetRecordTypeDefaultDDL(string connString, long PlantID)
        {
            try
            {
                DataTable dataTable;
                dataTable = new DataTable();
                SqlParameter[] param = {
                    new SqlParameter("@PlantID",PlantID),
                    };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetRecordTypeDefaultDDL", param);
                List<AdminDefaultPrioityView> recordList = dataTable.AsEnumerable().Select(dtRow => new AdminDefaultPrioityView()
                {
                    SchedulePriorityRecordTypeID = dtRow.Field<int>("SchedulePriorityRecordTypeID"),
                    RecordType = dtRow.Field<string>("RecordType"),
                    RecordTypePriorityLevel = dtRow.Field<int?>("PriorityLevel"),
                    RecordTypeID = dtRow.Field<int?>("RecordTypeID")


                }).ToList();
                return recordList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<AdminDefaultsView> GetModuleDefaultData(string connString)
        {
            try
            {
                DataTable dataTable;
                dataTable = new DataTable();
                dataTable = SqlHelper.GetDataTable(connString, "uspGetModuleDefaultOptions", null);
                List<AdminDefaultsView> recordList = dataTable.AsEnumerable().Select(dtRow => new AdminDefaultsView()
                {
                    PlantID = dtRow.Field<long>("PlantID"),
                    MaxLaunchesInaWeekRed = dtRow.Field<int?>("MaxLaunchesInaWeekRed"),
                    MaxLaunchesInaWeekYellow = dtRow.Field<int?>("MaxLaunchesInaWeekYellow"),
                    BayUsageWarningRed = dtRow.Field<int?>("BayUsageWarningRed"),
                    BayUsageWarningYellow = dtRow.Field<int?>("BayUsageWarningYellow"),
                    PlannedHighRiskMCSD = dtRow.Field<int?>("PlannedHighRiskMCSD"),
                    PlannedMedRiskMCSD = dtRow.Field<int?>("PlannedMedRiskMCSD"),
                    ScheduleBufferDays = dtRow.Field<int?>("ScheduleBufferDays")

                }).ToList();
                return recordList;
            }

            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }

        }
        public List<AdminDefaultsView> GetLabourDefaultData(string connString)
        {
            dataTable = new DataTable();

            try
            {
                DataTable dataTable;
                dataTable = new DataTable();
                dataTable = SqlHelper.GetDataTable(connString, "uspGetLabourDefaultOptions", null);
                List<AdminDefaultsView> recordList = dataTable.AsEnumerable().Select(dtRow => new AdminDefaultsView()
                {
                    PlantID = dtRow.Field<long>("PlantID"),
                    EfficencyFactory = dtRow.Field<int?>("EfficencyFactory"),
                    LaborUtilization = dtRow.Field<int?>("LaborUtilization"),
                    OvertimePerc = dtRow.Field<int?>("OvertimePerc"),
                    PTOPerc = dtRow.Field<int?>("PTOPerc"),
                    LeadDirectPerc = dtRow.Field<int?>("LeadDirectPerc"),
                    PASSDirectPerc = dtRow.Field<int?>("PASSDirectPerc"),
                    CycleTimeUtilization = dtRow.Field<int?>("CycleTimeUtilization"),
                    LaborUsageWarningRed = dtRow.Field<int?>("LaborUsageWarningRed"),
                    LaborUsageWarningYellow = dtRow.Field<int?>("LaborUsageWarningYellow"),
                }).ToList();
                return recordList;
            }

            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }

        }
        public List<AdminDefaultsView> GetOperationsDefaultData(string connString)
        {
            dataTable = new DataTable();

            AdminDefaultsView DefaultData = new AdminDefaultsView();
            dataTable = SqlHelper.GetDataTable(connString, "uspGetOperationsDefaultOptions", null);
            try
            {
                DataTable dataTable;
                dataTable = new DataTable();
                dataTable = SqlHelper.GetDataTable(connString, "uspGetOperationsDefaultOptions", null);
                List<AdminDefaultsView> recordList = dataTable.AsEnumerable().Select(dtRow => new AdminDefaultsView()
                {
                    PlantID = dtRow.Field<long>("PlantID"),
                    OpTimeSTELow = dtRow.Field<int?>("OpTimeSTELow"),
                    OpTimeSTEHigh = dtRow.Field<int?>("OpTimeSTEHigh")

                }).ToList();
                return recordList;
            }

            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }

        }

        public List<AdminDefaultColourAndTimePeriodView> GetDefaultColorViewDDL(string connString)
        {
            try
            {
                DataTable dataTable;
                dataTable = new DataTable();
                dataTable = SqlHelper.GetDataTable(connString, "uspGetDefaultColorViewDDL", null);
                List<AdminDefaultColourAndTimePeriodView> recordList = dataTable.AsEnumerable().Select(dtRow => new AdminDefaultColourAndTimePeriodView()
                {
                    ColorName = dtRow.Field<string>("RecordName"),
                    ColorID = dtRow.Field<long>("RecordID"),

                }).ToList();
                return recordList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<AdminDefaultColourAndTimePeriodView> GetDefaultTimePeriodDDL(string connString)
        {
            try
            {
                DataTable dataTable;
                dataTable = new DataTable();

                dataTable = SqlHelper.GetDataTable(connString, "uspGetDefaultTimePeriodDDL", null);
                List<AdminDefaultColourAndTimePeriodView> recordList = dataTable.AsEnumerable().Select(dtRow => new AdminDefaultColourAndTimePeriodView()
                {
                    TimePeriodName = dtRow.Field<string>("RecordName"),
                    TimePeriodID = dtRow.Field<long>("RecordID"),

                }).ToList();
                return recordList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<AdminDefaultColourAndTimePeriodView> GetOtherDefaultOptions(string connString)
        {
            dataTable = new DataTable();

            List<AdminDefaultColourAndTimePeriodView> DefaultData = new List<AdminDefaultColourAndTimePeriodView>();
            dataTable = SqlHelper.GetDataTable(connString, "uspGetOtherDefaultOptions", null);
            try
            {
                DefaultData = dataTable.AsEnumerable().Select(dtRow => new AdminDefaultColourAndTimePeriodView()
                {
                    PlantID = dtRow.Field<long>("PlantID"),
                    ColorName = dtRow.Field<string>("ScheduleColorView"),
                    TimePeriodName = dtRow.Field<string>("ScheduleTimePeriod"),
                }).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            return DefaultData;
        }

        //Updations 
        public int UpdateModuleDefaultOptions(string connString, AdminDefaultsView AD)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                     new SqlParameter("@PlantID",  AD.PlantID),
                    new SqlParameter("@MaxLaunchesInaWeekRed", AD.MaxLaunchesInaWeekRed),
                    new SqlParameter("@MaxLaunchesInaWeekYellow", AD.MaxLaunchesInaWeekYellow),
                    new SqlParameter("@BayUsageWarningYellow", AD.BayUsageWarningYellow),
                    new SqlParameter("@BayUsageWarningRed", AD.BayUsageWarningRed),
                    new SqlParameter("@PlannedHighRiskMCSD", AD.PlannedHighRiskMCSD),
                    new SqlParameter("@PlannedMedRiskMCSD", AD.PlannedMedRiskMCSD),
                    new SqlParameter("@ScheduleBufferDays", AD.ScheduleBufferDays)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateModuleDefaultOptions", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public int UpdateLabourDefaultOptions(string connString, AdminDefaultsView AD)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                     new SqlParameter("@PlantID",  AD.PlantID),
                    new SqlParameter("@EfficencyFactory", AD.EfficencyFactory),
                    new SqlParameter("@LaborUtilization", AD.LaborUtilization),
                    new SqlParameter("@OvertimePerc", AD.OvertimePerc),
                    new SqlParameter("@PTOPerc", AD.PTOPerc),
                    new SqlParameter("@LeadDirectPerc", AD.LeadDirectPerc),
                    new SqlParameter("@PASSDirectPerc", AD.PASSDirectPerc),
                    new SqlParameter("@CycleTimeUtilization", AD.CycleTimeUtilization),
                    new SqlParameter("@LaborUsageWarningRed", AD.LaborUsageWarningRed),
                    new SqlParameter("@LaborUsageWarningYellow", AD.LaborUsageWarningYellow)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateLabourDefaultOptions", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public int UpdateOperationsDefaultOptions(string connString, AdminDefaultsView AD)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                     new SqlParameter("@PlantID",  AD.PlantID),
                    new SqlParameter("@OpTimeSTELow", AD.OpTimeSTELow),
                    new SqlParameter("@OpTimeSTEHigh", AD.OpTimeSTEHigh)

                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateOperationsDefaultOptions", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public int UpdateOtherDefaultOptions(string connString, AdminDefaultColourAndTimePeriodView AD)
        {


            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                     new SqlParameter("@PlantID",  AD.PlantID),
                    new SqlParameter("@TimePeriodName", AD.TimePeriodName),
                    new SqlParameter("@ColourName", AD.ColorName)

                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateOtherDefaultOptions", param);

                return resultCount;
            }

            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public int UpdatePriorityDefaultOptions(string connString, AdminDefaultPrioityView[] AD)
        {
            var resultCount = 0;
            var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            try
            {
                foreach (var items in AD)
                {
                    SqlParameter[] param = {
                 new SqlParameter("@PlantID",  items.PlantID),
                    new SqlParameter("@SchedulePriorityID", items.SchedulePriorityID),
                    new SqlParameter("@SchedulePriorityLevel", items.ScheduleTypePriorityLevel),
                 outParam

            };

                    resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdatePriorityDefaultOptions", param);
                }
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public int UpdateRevenueTypePriorityDefaultOptions(string connString, AdminDefaultPrioityView[] AD)
        {
            var resultCount = 0;
            var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            try
            {
                foreach (var items in AD)
                {
                    SqlParameter[] param = {
               new SqlParameter("@SchedulePriorityRevenueTypeID", items.SchedulePriorityRevenueTypeID),
                    new SqlParameter("@RevenuePriorityLevel", items.RevenuePriorityLevel),
                 outParam

            };

                    resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateRevenueTypePriorityDefaultOptions", param);
                }
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }

        }
        public int UpdateRecordTypePriorityDefaultOptions(string connString, AdminDefaultPrioityView[] AD)
        {
            var resultCount = 0;
            var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            try
            {
                foreach (var items in AD)
                {
                    SqlParameter[] param = {
               new SqlParameter("@SchedulePriorityRecordtypeID", items.SchedulePriorityRecordTypeID),
                    new SqlParameter("@RecordPriorityLevel", items.RecordTypePriorityLevel),
                 outParam

            };

                    resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateRecordTypePriorityDefaultOptions", param);
                }
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }

        }

        public PriorityDetails GetPriorityDefaultOptions(string connString)
        {
            DataSet dataset = new DataSet();
            PriorityDetails objList = new PriorityDetails();
            List<AdminDefaultPrioityView> Data1 = new List<AdminDefaultPrioityView>();
            List<AdminDefaultPrioityView> Data2 = new List<AdminDefaultPrioityView>();
            List<AdminDefaultPrioityView> Data3 = new List<AdminDefaultPrioityView>();
            dataset = SqlHelper.GetDataSet(connString, "uspGetPriorityDefaultOptions", null);

            try
            {
                DataTable dt = dataset.Tables[0];
                DataTable dt1 = dataset.Tables[1];
                DataTable dt2 = dataset.Tables[2];
                AdminDefaultPrioityView OBCData = new AdminDefaultPrioityView();
                Data1 = dt.AsEnumerable().Select(dtRow => new AdminDefaultPrioityView()
                {
                    SchedulePriorityID = dtRow.Field<int?>("SchedulePriorityID"),
                    ScheduleType = dtRow.Field<string>("Priorities"),
                    ScheduleTypePriorityLevel = dtRow.Field<int?>("PriorityLevel"),
                    PlantID = dtRow.Field<long>("PlantID"),

                }).ToList();
                Data2 = dt1.AsEnumerable().Select(dtRow => new AdminDefaultPrioityView()
                {
                    SchedulePriorityRevenueTypeID = dtRow.Field<int?>("SchedulePriorityRevenueTypeID"),
                    RevenueType = dtRow.Field<string>("RevenueType"),
                    RevenueTypeID = dtRow.Field<int?>("RevenueTypeID"),
                    RevenuePriorityLevel = dtRow.Field<int?>("PriorityLevel"),
                    PlantID = dtRow.Field<long>("PlantID"),

                }).ToList();

                Data3 = dt2.AsEnumerable().Select(dtRow => new AdminDefaultPrioityView()
                {
                    SchedulePriorityRecordTypeID = dtRow.Field<int?>("SchedulePriorityRecordTypeID"),
                    RecordType = dtRow.Field<string>("RecordType"),
                    RecordTypeID = dtRow.Field<int?>("RecordTypeID"),
                    RecordTypePriorityLevel = dtRow.Field<int?>("PriorityLevel"),
                    PlantID = dtRow.Field<long>("PlantID"),

                }).ToList();
                objList.SchedulePriority = Data1;
                objList.RevenueTypePriority = Data2;
                objList.RecordTypePriority = Data3;

            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            return objList;
        }

        public object GetLaborHourLoanTo(string connString, int plantid)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@PlantId", plantid)
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetLaborHourLoanTo", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
            {
                LaborHourLoanToId = dtRow.Field<long?>("LaborHourLoanToId"),
                OptionName = dtRow.Field<string>("OptionName"),
                isActive = dtRow.Field<bool>("isActive")
            }).ToList();

            return masterRecords;
        }
        public int UpdateLaborHourLoanTo(string connString, LaborHourLoanTo[] lt)
        {
            try
            {
                var resultCount = 0;
                foreach (var item in lt)
                {

                    var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                    {
                        Direction = ParameterDirection.Output
                    };

                    SqlParameter[] param = {
                             new SqlParameter("@PlantID",  item.PlantID),
                            new SqlParameter("@OptionName", item.OptionName.ToString().Trim()),
                            new SqlParameter("@IsActive",item.IsActive),
                            new SqlParameter("@LaborHourLoanToId", item.LaborHourLoanToId)
                            ,outParam
                        };
                    resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateLaborHourLoanTo", param);
                }
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
    }
}