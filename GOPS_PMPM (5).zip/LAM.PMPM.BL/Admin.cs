using LAM.PMPM.DAL;
using LAM.PMPM.Model;
using LAM.PMPM.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace LAM.PMPM.BL
{
    public class Admin
    {
        public string GetPlants(string connString)
        {
            DataTable dataTable = null;
            try
            {
                dataTable = SqlHelper.GetDataTable(connString, "uspGetPlantInfo");
                var plantInfo = dataTable.AsEnumerable().Select(dtRow => new
                    {
                        PlantId = dtRow.Field<Int64>("PlantID"),
                        PlantName = dtRow.Field<string>("PlantName"),
                        Code = dtRow.Field<string>("Code"),
                        
                    }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(plantInfo);
                return jsonString;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }
        public string GetHolidays(string connString,int plantId)
        {
            DataTable dataTable = null;
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@PlantID",plantId)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetHolidayByPlantID",param);
                var plantInfo = dataTable.AsEnumerable().Select(dtRow => new
                    {
                        Name = dtRow.Field<string>("Name"),
                        FactoryShutDown = dtRow.Field<Boolean>("FactoryShutDown"),
                        HolidayDateDaily = dtRow.Field<DateTime?>("HolidayDateDaily"),
                        HolidayID = Convert.ToInt32(dtRow["HolidayID"]),
                        PlantID = Convert.ToInt32(dtRow["PlantID"]),
                        
                    }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(plantInfo);
                return jsonString;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }
        public string AddHolidays(string connString,  HolidayViewModel holidayViewModel )
        {
            DataTable dataTable = null;
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@Name",holidayViewModel.Name),
                    new SqlParameter("@HolidayDateDaily",holidayViewModel.HolidayDateDaily),
                    new SqlParameter("@FactoryShutDown",holidayViewModel.FactoryShutDown),
                    new SqlParameter("@PlantID",holidayViewModel.PlantID)
                };
                var newId = SqlHelper.ExecuteProcedureReturnInt(connString, "uspAddHoliday",param);
                if (newId <0)
                {
                    throw new Exception("Error on the Insertion of new Data");
                }
                
                SqlParameter[] param2 = {
                    new SqlParameter("@HolidayID",newId)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetHolidayByID", param2);
                var HolidayInfo = dataTable.AsEnumerable().Select(dtRow => new
                    {
                        HolidayID = Convert.ToInt32(dtRow["HolidayID"]),
                        Name = dtRow.Field<string>("Name"),
                        FactoryShutDown = dtRow.Field<Boolean>("FactoryShutDown"),
                        HolidayDateDaily = dtRow.Field<DateTime?>("HolidayDateDaily"),
                        PlantID = Convert.ToInt32(dtRow["PlantID"]),
                        
                    }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(HolidayInfo);
                return jsonString;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }
        public string EditHolidays(string connString,  HolidayViewModel holidayViewModel )
        {
            DataTable dataTable = null;
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter[] param = {
                    new SqlParameter("@HolidayID",holidayViewModel.HolidayID),
                    new SqlParameter("@Name",holidayViewModel.Name),
                    new SqlParameter("@HolidayDateDaily",holidayViewModel.HolidayDateDaily),
                    new SqlParameter("@FactoryShutDown",holidayViewModel.FactoryShutDown),
                    new SqlParameter("@PlantID",holidayViewModel.PlantID),
                    outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspEditHoliday",param);
                if (resultCount <=0)
                {
                    throw new Exception("Error on the edit of the Holiday");
                }
                
                SqlParameter[] param2 = {
                    new SqlParameter("@HolidayID",holidayViewModel.HolidayID)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetHolidayByID", param2);
                var holidayInfo = dataTable.AsEnumerable().Select(dtRow => new
                    {
                        HolidayID = Convert.ToInt32(dtRow["HolidayID"]),
                        Name = dtRow.Field<string>("Name"),
                        FactoryShutDown = dtRow.Field<Boolean>("FactoryShutDown"),
                        HolidayDateDaily = dtRow.Field<DateTime?>("HolidayDateDaily"),
                        PlantID = Convert.ToInt32(dtRow["PlantID"]),
                        
                    }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(holidayInfo);
                return jsonString;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }

        public int DeleteHolidays(string connString, int holidayID)
        {
            
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@HolidayID",holidayID),
                };
                return SqlHelper.ExecuteNonQueryNoOutParam(connString, "uspDeleteHolidayByID", param);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            
        }

        public string GetBuildings(string connString)
        {
            DataTable dataTable = null;
            try
            {
                dataTable = SqlHelper.GetDataTable(connString, "uspGetBuildingInfo");
                var plantInfo = dataTable.AsEnumerable().Select(dtRow => new
                {
                    BuildingID = dtRow.Field<Int64>("BuildingID"),
                    PlantID = dtRow.Field<Int64>("PlantID"),
                    BuildingName = dtRow.Field<string>("BuildingName"),
                    Code = dtRow.Field<string>("Code"),
                }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(plantInfo);
                return jsonString;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }

        public string AddPlant(string connString, PlantViewModel plantViewModel)
        {
            DataTable dataTable = null;
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@PlantName",plantViewModel.PlantName),
                    new SqlParameter("@Code",plantViewModel.Code)
                };
                var newId = SqlHelper.ExecuteProcedureReturnInt(connString, "uspAddPlant",param);
                if (newId <0)
                {
                    throw new Exception("Error on the Insertion of new Data");
                }
                
                SqlParameter[] param2 = {
                    new SqlParameter("@PlantId",newId)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetPlantbyID", param2);
                var plantInfo = dataTable.AsEnumerable().Select(dtRow => new
                {
                    PlantId = dtRow.Field<Int64>("PlantID"),
                    PlantName = dtRow.Field<string>("PlantName"),
                    Code = dtRow.Field<string>("Code"),
                        
                }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(plantInfo);
                return jsonString;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }
        public string AddBuilding(string connString, BuildingViewModel buildingViewModel)
        {
            DataTable dataTable = null;
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@BuildingName",buildingViewModel.BuildingName),
                    new SqlParameter("@Code",buildingViewModel.Code),
                    new SqlParameter("@PlantID",buildingViewModel.PlantID)
                };
                var newId = SqlHelper.ExecuteProcedureReturnInt(connString, "uspAddBuilding",param);
                if (newId <0)
                {
                    throw new Exception("Error on the Insertion of new Data");
                }
                
                SqlParameter[] param2 = {
                    new SqlParameter("@BuildingID",newId)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetBuildingbyID", param2);
                var plantInfo = dataTable.AsEnumerable().Select(dtRow => new
                {
                    BuildingID = dtRow.Field<Int64>("BuildingID"),
                    PlantID = dtRow.Field<Int64>("PlantID"),
                    BuildingName = dtRow.Field<string>("BuildingName"),
                    Code = dtRow.Field<string>("Code"),
                }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(plantInfo);
                return jsonString;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }
        
        public string EditPlant(string connString,  PlantViewModel plantViewModel )
        {
            DataTable dataTable = null;
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter[] param = {
                    new SqlParameter("@PlantId",plantViewModel.PlantId),
                    new SqlParameter("@PlantName",plantViewModel.PlantName),
                    new SqlParameter("@Code",plantViewModel.Code),
                    outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspEditPlant",param);
                if (resultCount <=0)
                {
                    throw new Exception("Error on the edit of the Holiday");
                }
                
                SqlParameter[] param2 = {
                    new SqlParameter("@PlantId",plantViewModel.PlantId)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetPlantbyID", param2);
                var holidayInfo = dataTable.AsEnumerable().Select(dtRow => new
                    {
                        PlantId = dtRow.Field<Int64>("PlantID"),
                        PlantName = dtRow.Field<string>("PlantName"),
                        Code = dtRow.Field<string>("Code"),
                        
                    }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(holidayInfo);
                return jsonString;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }
        
        public string EditBuilding(string connString,  BuildingViewModel buildingViewModel )
        {
            DataTable dataTable = null;
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter[] param = {
                    new SqlParameter("@BuildingID",buildingViewModel.BuildingID),
                    new SqlParameter("@BuildingName",buildingViewModel.BuildingName),
                    new SqlParameter("@Code",buildingViewModel.Code),
                    new SqlParameter("@PlantID",buildingViewModel.PlantID),
                    outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspEditBuilding",param);
                if (resultCount <=0)
                {
                    throw new Exception("Error on the edit of the Holiday");
                }
                
                SqlParameter[] param2 = {
                    new SqlParameter("@BuildingID",buildingViewModel.BuildingID)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetBuildingbyID", param2);
                var holidayInfo = dataTable.AsEnumerable().Select(dtRow => new
                {
                    BuildingID = dtRow.Field<Int64>("BuildingID"),
                    PlantID = dtRow.Field<Int64>("PlantID"),
                    BuildingName = dtRow.Field<string>("BuildingName"),
                    Code = dtRow.Field<string>("Code"),
                        
                }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(holidayInfo);
                return jsonString;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }
        
        public int DeletePlant(string connString, int plantId)
        {
            
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@PlantId",plantId),
                };
                return SqlHelper.ExecuteNonQueryNoOutParam(connString, "uspDeletePlantById", param);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            
        }
        public int DeleteBuildings(string connString, int buildingId)
        {
            
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@BuildingID",buildingId),
                };
                return SqlHelper.ExecuteNonQueryNoOutParam(connString, "uspDeleteBuildingByID", param);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            
        }
        public string GetMails(string connString,int plantId)
        {
            DataTable dataTable = null;
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@PlantId",plantId)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetEmailByPlantID",param);
                var plantInfo = dataTable.AsEnumerable().Select(dtRow => new
                {
                    EmailAddressId = Convert.ToInt32(dtRow["EmailAddressId"]),
                    EmailAddress = dtRow.Field<string>("EmailAddress"),
                    IncludeInWIPEmail = dtRow.Field<Boolean>("IncludeInWIPEmail"),
                    PlantId = Convert.ToInt32(dtRow["PlantId"]),
                }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(plantInfo);
                return jsonString;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }
        
        public string AddEmail(string connString,  EmailAdminViewModel EmailViewModel )
        {
            DataTable dataTable = null;
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@EmailAddress",EmailViewModel.EmailAddress),
                    new SqlParameter("@IncludeInWIPEmail",EmailViewModel.IncludeInWIPEmail),
                    new SqlParameter("@PlantId",EmailViewModel.PlantId),
                };
                var newId = SqlHelper.ExecuteProcedureReturnInt(connString, "uspAddEmail",param);
                if (newId <0)
                {
                    throw new Exception("Error on the Insertion of new Data");
                }
                
                SqlParameter[] param2 = {
                    new SqlParameter("@Id",newId)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetEmailByID", param2);
                var HolidayInfo = dataTable.AsEnumerable().Select(dtRow => new
                {
                    EmailAddressId = Convert.ToInt32(dtRow["EmailAddressId"]),
                    EmailAddress = dtRow.Field<string>("EmailAddress"),
                    IncludeInWIPEmail = dtRow.Field<Boolean>("IncludeInWIPEmail"),
                    PlantId = Convert.ToInt32(dtRow["PlantId"]),
                }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(HolidayInfo);
                return jsonString;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }public string UpdateEmail(string connString,  EmailAdminViewModel EmailViewModel )
        {
            DataTable dataTable = null;
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@EmailAddress",EmailViewModel.EmailAddress),
                    new SqlParameter("@IncludeInWIPEmail",EmailViewModel.IncludeInWIPEmail),
                    new SqlParameter("@PlantId",EmailViewModel.PlantId),
                    new SqlParameter("@Id",EmailViewModel.Id),
                };
                var newId = SqlHelper.ExecuteProcedureReturnInt(connString, "uspUpdateEmail",param);
                if (newId <0)
                {
                    throw new Exception("Error on the Insertion of new Data");
                }
                
                SqlParameter[] param2 = {
                    new SqlParameter("@Id",EmailViewModel.Id)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetEmailByID", param2);
                var HolidayInfo = dataTable.AsEnumerable().Select(dtRow => new
                {
                    EmailAddressId = Convert.ToInt32(dtRow["EmailAddressId"]),
                    EmailAddress = dtRow.Field<string>("EmailAddress"),
                    IncludeInWIPEmail = dtRow.Field<Boolean>("IncludeInWIPEmail"),
                    PlantId = Convert.ToInt32(dtRow["PlantId"]),
                }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(HolidayInfo);
                return jsonString;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }
        
        public int DeleteEmailAdmin(string connString, int EmailID)
        {
            
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@Id",EmailID),
                };
                return SqlHelper.ExecuteNonQueryNoOutParam(connString, "uspDeleteEmailByID", param);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            
        }
    }
}