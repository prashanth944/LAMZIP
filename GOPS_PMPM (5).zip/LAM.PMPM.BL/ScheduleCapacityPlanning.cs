﻿using LAM.PMPM.DAL;
using LAM.PMPM.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;


namespace LAM.PMPM.BL
{
    public class ScheduleCapacityPlanning
    {
        public List<MasterRecords> GetTimeViewDDL(string connString)
        {
            try
            {
                DataTable dataTable;
                dataTable = SqlHelper.GetDataTable(connString, "uspGetTimeViewDDL", null);
                List<MasterRecords> masterRecords = dataTable.AsEnumerable().Select(dtRow => new MasterRecords()
                {
                    MasterRecordID = Convert.ToInt32(dtRow["MasterRecordID"]),
                    MasterRecordName = Convert.ToString(dtRow["MasterRecordName"])
                }).ToList();
                return masterRecords;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
    }
}
