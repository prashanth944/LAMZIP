﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Mail;
using System.Text;

namespace LAM.PMPM.BL
{
    public class SmtpMailHelper
    {
        public string Sender { get; set; } = "";
        public string Recipient { get; set; } = "";
        public string RecipientCC { get; set; } = "";
        public string Subject { get; set; } = "";
        public string Body { get; set; } = "";
        public string AttachmentFile { get; set; }

        private const int Timeout = 180000;
        private readonly string _host;
        private readonly int _port;
        private readonly string _user;
        private readonly string _pass;
        private readonly bool _ssl;

        public SmtpMailHelper(string mailServer, int port, string mailAuthUser, string mailAuthPass, bool enableSSL)
        {
            this._host = mailServer;
            this._port = port;
            this._user = mailAuthUser;
            this._pass = mailAuthPass;
            this._ssl = enableSSL;
        }

        public void Send()
        {
            try
            {

                var message = new MailMessage() { IsBodyHtml = true };

                message.From = new MailAddress(Sender);
                message.Subject = Subject;
                message.Body = Body;

                foreach (string to in Recipient.Split(";"))
                {
                    if (!string.IsNullOrEmpty(to) && !message.To.Contains(new MailAddress(to)))
                    {
                        message.To.Add(to);
                    }
                }

                foreach (string cc in RecipientCC.Split(";"))
                {
                    if (!string.IsNullOrEmpty(cc) && !message.CC.Contains(new MailAddress(cc)))
                    {
                        message.CC.Add(cc);
                    }
                }

                var smtp = new SmtpClient(_host, _port);

                if (_user.Length > 0 && _pass.Length > 0)
                {
                    smtp.UseDefaultCredentials = false;
                    smtp.Credentials = new NetworkCredential(_user, _pass);
                    smtp.EnableSsl = _ssl;
                }
                else
                {
                    smtp.UseDefaultCredentials = true;
                }

                smtp.Send(message);

                message.Dispose();
                smtp.Dispose();
            }

            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }


        }
    }
}
