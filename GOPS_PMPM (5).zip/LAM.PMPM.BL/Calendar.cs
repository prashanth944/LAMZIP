﻿using LAM.PMPM.DAL;
using LAM.PMPM.Model;
using LAM.PMPM.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace LAM.PMPM.BL
{
    public class Calendar
    {
        public string GetUsers(string connString,PTOEventsViewModel ptoEventsViewModel)
        {
            DataTable dataTable = null;
            try
            {
                SqlParameter[] param =
                {
                    new SqlParameter("@userEmail",ptoEventsViewModel.userEmail),
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetUsersDetails",param);
                var eventInfo = dataTable.AsEnumerable().Select(dtRow => new
                {
                    EmployeeDataID = dtRow.Field<Int64>("EmployeeDataID"),
                    Username = dtRow.Field<string>("Username"),
                    JobTitle = dtRow.Field<string>("JobTitle"),
                    JobCode = dtRow.Field<string>("JobCode"),
                    FirstName = dtRow.Field<string>("FirstName"),
                    LastName = dtRow.Field<string>("LastName"),

                }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(eventInfo);
                return jsonString;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
            
        }
        
        public string AddPTOEvent(string connString,PTOEventsViewModel ptoEventsViewModel){
            DataTable dataTable = null;
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@employeeDataID",ptoEventsViewModel.employeeDataID),
                    new SqlParameter("@GroupName",ptoEventsViewModel.groupName),
                    new SqlParameter("@TypeName",ptoEventsViewModel.typeName),
                    new SqlParameter("@CovidRelated",ptoEventsViewModel.covidRelated),
                    new SqlParameter("@startDate",ptoEventsViewModel.StartDate),
                    new SqlParameter("@endDate",ptoEventsViewModel.EndDate),
                    new SqlParameter("@plantId",ptoEventsViewModel.plantId),
                    new SqlParameter("@comments",ptoEventsViewModel.comments),
                };
                var newId = SqlHelper.ExecuteProcedureReturnInt(connString, "uspAddPTOEvents",param);
                if (newId <0)
                {
                    throw new Exception("Error on the Insertion of new Data");
                }
                SqlParameter[] param2 = {
                    new SqlParameter("@eventId",newId),
                    new SqlParameter("@userEmail",ptoEventsViewModel.userEmail)
                };
                
                dataTable = SqlHelper.GetDataTable(connString, "uspGetPTOEventsById", param2);
                var eventInfo = dataTable.AsEnumerable().Select(dtRow => new
                {
                    id = Convert.ToInt32(dtRow["id"]),
                    employeeDataID = Convert.ToInt32(dtRow["employeeDataID"]),
                    Username = dtRow.Field<string>("Username"),
                    groupName = dtRow.Field<string>("groupName"),
                    typeName = dtRow.Field<string>("typeName"),
                    covidRelated = dtRow.Field<Boolean>("covidRelated"),
                    startDate = dtRow.Field<DateTime?>("startDate"),
                    endDate = dtRow.Field<DateTime?>("endDate"),
                    comment = dtRow.Field<string>("comment"),
                    statusLabel = dtRow.Field<string>("statusLabel"),
                    JobTitle = dtRow.Field<string>("JobTitle"),
                    FirstName = dtRow.Field<string>("FirstName"),
                    LastName = dtRow.Field<string>("LastName"),
                    levelUser = Convert.ToInt32(dtRow["levelUser"]),
                        
                }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(eventInfo[0]);
                return jsonString;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
            
        }

        public string getPTOEvents(string connString,PTOEventsViewModel ptoEventsViewModel)
        {
            DataTable dataTable = null;
            try
            {
                SqlParameter[] param =
                {
                    new SqlParameter("@userEmail",ptoEventsViewModel.userEmail),
                    new SqlParameter("@plantId",ptoEventsViewModel.plantId),
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetPTOEvents",param);
                var eventInfo = dataTable.AsEnumerable().Select(dtRow => new
                {
                    id = Convert.ToInt32(dtRow["id"]),
                    employeeDataID = Convert.ToInt32(dtRow["employeeDataID"]),
                    Username = dtRow.Field<string>("Username"),
                    groupName = dtRow.Field<string>("groupName"),
                    typeName = dtRow.Field<string>("typeName"),
                    covidRelated = dtRow.Field<Boolean>("covidRelated"),
                    startDate = dtRow.Field<DateTime?>("startDate"),
                    endDate = dtRow.Field<DateTime?>("endDate"),
                    comment = dtRow.Field<string>("comment"),
                    statusLabel = dtRow.Field<string>("statusLabel"),
                    JobTitle = dtRow.Field<string>("JobTitle"),
                    FirstName = dtRow.Field<string>("FirstName"),
                    LastName = dtRow.Field<string>("LastName"),
                    levelUser = Convert.ToInt32(dtRow["levelUser"]),

                }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(eventInfo);
                return jsonString;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }
        
        public string updateStatusPTOEvents(string connString,PTOEventsViewModel ptoEventsViewModel)
        {
            DataTable dataTable = null;
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@eventId",ptoEventsViewModel.id),
                    new SqlParameter("@newState",ptoEventsViewModel.statusLabel),

                };
                var newId = SqlHelper.ExecuteProcedureReturnInt(connString, "uspUpdateStatusOfEventById",param);
                if (newId <0)
                {
                    throw new Exception("Error on the Insertion of new Data");
                }
                
                return "{\"message\": \"OK\"}";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }
        
         public string UpdatePTOEvent(string connString,PTOEventsViewModel ptoEventsViewModel){
            DataTable dataTable = null;
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@employeeDataID",ptoEventsViewModel.employeeDataID),
                    new SqlParameter("@GroupName",ptoEventsViewModel.groupName),
                    new SqlParameter("@TypeName",ptoEventsViewModel.typeName),
                    new SqlParameter("@CovidRelated",ptoEventsViewModel.covidRelated),
                    new SqlParameter("@startDate",ptoEventsViewModel.StartDate),
                    new SqlParameter("@endDate",ptoEventsViewModel.EndDate),
                    new SqlParameter("@comments",ptoEventsViewModel.comments),
                    new SqlParameter("@eventId",ptoEventsViewModel.id),
                };
                var newId = SqlHelper.ExecuteProcedureReturnInt(connString, "uspUpdatePTOEvents",param);
                if (newId <0)
                {
                    throw new Exception("Error on the Insertion of new Data");
                }
                SqlParameter[] param2 = {
                    new SqlParameter("@eventId",ptoEventsViewModel.id),
                    new SqlParameter("@userEmail",ptoEventsViewModel.userEmail)
                };
                
                dataTable = SqlHelper.GetDataTable(connString, "uspGetPTOEventsById", param2);
                var eventInfo = dataTable.AsEnumerable().Select(dtRow => new
                {
                    id = Convert.ToInt32(dtRow["id"]),
                    employeeDataID = Convert.ToInt32(dtRow["employeeDataID"]),
                    Username = dtRow.Field<string>("Username"),
                    groupName = dtRow.Field<string>("groupName"),
                    typeName = dtRow.Field<string>("typeName"),
                    covidRelated = dtRow.Field<Boolean>("covidRelated"),
                    startDate = dtRow.Field<DateTime?>("startDate"),
                    endDate = dtRow.Field<DateTime?>("endDate"),
                    comment = dtRow.Field<string>("comment"),
                    statusLabel = dtRow.Field<string>("statusLabel"),
                    JobTitle = dtRow.Field<string>("JobTitle"),
                    FirstName = dtRow.Field<string>("FirstName"),
                    LastName = dtRow.Field<string>("LastName"),
                    levelUser = Convert.ToInt32(dtRow["levelUser"]),
                        
                }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(eventInfo[0]);
                return jsonString;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
            
        }
         
         public string dropPTOEvents(string connString,PTOEventsViewModel ptoEventsViewModel)
         {
             DataTable dataTable = null;
             try
             {
                 SqlParameter[] param = {
                     new SqlParameter("@eventId",ptoEventsViewModel.id)
                 };
                 var newId = SqlHelper.ExecuteProcedureReturnInt(connString, "uspDropPTOEventById",param);
                 if (newId <0)
                 {
                     throw new Exception("Error on the Insertion of new Data");
                 }
                
                 return "{\"message\": \"OK\"}";
             }
             catch (Exception ex)
             {
                 throw new Exception(ex.ToString());
             }
             finally
             {
                 if (dataTable != null)
                     dataTable.Dispose();
             }
         }
    }
}