﻿using LAM.PMPM.DAL;
using LAM.PMPM.Model;
using LAM.PMPM.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace LAM.PMPM.BL
{
    public class BayPlanning
    {
        public List<ToolType> GetToolType(string connString, int plantID)
        {
            DataTable dataTable = null;
            try
            {
                SqlParameter[] param = { new SqlParameter("@plantID", plantID) };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetToolType", param);
                List<ToolType> toolTypes = dataTable.AsEnumerable().Select(dtRow => new ToolType()
                {
                    ToolTypeID = Convert.ToInt32(dtRow["ToolTypeID"]),
                    ToolTypeName = Convert.ToString(dtRow["ToolTypeName"])
                }).ToList();
                return toolTypes;
            }
            catch (Exception ex)
            {

                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }
        public string GetBaysDetails(string connString, string interval, int plantID, string startDate, string endDate)
        {
            DataTable dataTable = null;
            try
            {
                SqlParameter[] param = {
                new SqlParameter("@Interval",interval),
                    new SqlParameter("@plantID",plantID),
                    new SqlParameter("@minDate",startDate),
                    new SqlParameter("@maxDate",endDate),
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetBaysDetailsV2", param);
                var baySummaryDetails = dataTable.Rows.Cast<DataRow>()
                .GroupBy(x => new { Bay_Name = x["BayName"], Product_Type = x["ProductName"] == DBNull.Value ? "" : x["ProductName"], Building_Name = x["BuildingName"], Bay_Type = x["BayTypeName"], Status = x["Status"] })
                .OrderBy(x => x.Key.Product_Type)
                .Select(x => new
                {
                    BayDetails = x.Key,
                    DailyWeeklyDates = x.Select(y => new
                    {
                        WeekStart = y.Field<DateTime>("WeekStart"),
                        Bays_Availablity = y.Field<Decimal>("BaysAvailablity")
                    })
                }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(baySummaryDetails);
                return jsonString;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }



        public BaySummaryByBaytype GetBaysSummaryByBayType(string connString, string interval, int plantID, string startDate, string endDate)
        {
            DataSet dataSet;
            try
            {
                if (startDate == "null")
                {
                    startDate = null;
                }
                if (endDate == "null")
                {
                    endDate = null;
                }
                BaySummaryByBaytype baySummaryByBaytype = new BaySummaryByBaytype();
                SqlParameter[] param = {
                new SqlParameter("@Interval",interval),
                    new SqlParameter("@plantID",plantID),
                    new SqlParameter("@minDate",startDate),
                    new SqlParameter("@maxDate",endDate),
                };
                dataSet = SqlHelper.GetDataSet(connString, "uspGetBaysDetailsByBayType", param);

                var bayAssemblyIntegration = dataSet.Tables[0].AsEnumerable()
                    .Select(dtRow => new BayAssemblyIntegration
                    {
                        AssemblyIntegration = dtRow.Field<string>("BayTypeName"),
                        BayDate = dtRow.Field<DateTime>("WeekStart"),
                        BaysAvailablity = dtRow.Field<decimal>("BaysAvailablity"),
                    })
                .ToList();

                baySummaryByBaytype.bayAssemblyIntegration = bayAssemblyIntegration;


                var bayIntegration = dataSet.Tables[1].AsEnumerable().Select(dtRow => new BayIntegration
                {
                    Integration = dtRow.Field<string>("BayTypeName"),
                    BayDate = dtRow.Field<DateTime?>("WeekStart"),
                    BaysAvailablity = dtRow.Field<decimal>("BaysAvailablity"),
                }).ToList();
                baySummaryByBaytype.bayIntegration = bayIntegration;



                var bayTest = dataSet.Tables[2].AsEnumerable().Select(dtRow => new BayTest
                {
                    Test = dtRow.Field<string>("BayTypeName"),
                    BayDate = dtRow.Field<DateTime>("WeekStart"),
                    BaysAvailablity = dtRow.Field<decimal>("BaysAvailablity"),
                }).ToList();

                baySummaryByBaytype.bayTest = bayTest;

                return baySummaryByBaytype;

            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }

        }









        public string GetBaysSummary(string connString, string interval, int plantID, string startDate, string maxDate)
        {
            DataTable dataTable = null;
            try
            {
                SqlParameter[] param = {
                new SqlParameter("@Interval",interval),
                    new SqlParameter("@plantID",plantID),
                    new SqlParameter("@minDate",startDate),
                    new SqlParameter("@maxDate",maxDate)

                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetBaysSummaryV2", param);
                var baySummarys = dataTable.Rows.Cast<DataRow>()
                .GroupBy(x => new { Product_Type = x["ProductName"], Building_Name = x["BuildingName"], Bay_Type = x["BayTypeName"], Status = x["Status"] })
                .OrderBy(x => x.Key.Product_Type)
                .Select(x => new
                {
                    BayDetails = x.Key,
                    DailyWeeklyDates = x.Select(y => new
                    {
                        WeekStart = y.Field<DateTime>("WeekStart"),
                        Bays_Availablity = y.Field<Decimal>("BaysAvailablity")
                    })
                }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(baySummarys);
                return jsonString;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }

        public string GetBaysSummaryTualatin(string connString, string interval, int plantID, string startDate, string maxDate)
        {
            DataTable dataTable = null;
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@Interval",interval),
                    new SqlParameter("@plantID",plantID),
                    new SqlParameter("@minDate",startDate),
                    new SqlParameter("@maxDate",maxDate)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetBaysSummaryV2", param);
                var baySummarys = dataTable.Rows.Cast<DataRow>()
                    .GroupBy(x => new
                    { Product_Type = "defProduct", Building_Name = x["BuildingName"], Bay_Type = x["BayTypeName"], Status = x["Status"] }
                            , x => x,
                            (key, list) => new
                            {
                                BayDetails = key,
                                DailyWeeklyDates = list.GroupBy(y => y.Field<DateTime>("WeekStart"),
                                        y => y,
                                        (key2, list2) => new
                                        {
                                            WeekStart = key2,
                                            Bays_Availablity = list2.Sum(z => z.Field<Decimal>("BaysAvailablity"))
                                        }).ToList()
                            }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(baySummarys);
                return jsonString;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }

        public int DeleteBays(string connString, string BayName)
        {
            try
            {
                SqlParameter[] param = {
               new SqlParameter("@bayName",BayName)
            };
                return SqlHelper.ExecuteNonQueryNoOutParam(connString, "USPDeleteBay", param);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public int AddUpdateBays(string connString, string input, BaySummaryViewModel baySummaryViewModel)
        {
            try
            {
                SqlParameter[] param = {
               new SqlParameter("@bayName",baySummaryViewModel.BayName),
               new SqlParameter("@statusID",baySummaryViewModel.StatusID),
               new SqlParameter("@effectiveDate",baySummaryViewModel.EffectiveDate),
                new SqlParameter("@endDate",baySummaryViewModel.EndDate),
               new SqlParameter("@productIDs",baySummaryViewModel.ProductTypeGroupListID),
               new SqlParameter("@buildingID",baySummaryViewModel.BuildingID),
               new SqlParameter("@bayTypeID",baySummaryViewModel.BayTypeID),
               new SqlParameter("@noEndDate",baySummaryViewModel.NoEndDate),
               new SqlParameter("@bayAvailablity",Convert.ToInt32(baySummaryViewModel.BaysAvailablity))
            };
                if (input == "AddBays")
                {
                    return SqlHelper.ExecuteNonQueryNoOutParam(connString, "USPAddBay", param);
                }
                else if (input == "UpdateBays")
                {
                    return SqlHelper.ExecuteNonQueryNoOutParam(connString, "USPUpdateBay", param);
                }
                else
                {
                    return -1;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<Building> GetBuilding(string connString, int plantID)
        {
            DataTable dataTable = null;
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@plantID",plantID)
                };

                dataTable = SqlHelper.GetDataTable(connString, "uspGetBuildingDDL", param);
                List<Building> buildings = dataTable.AsEnumerable().Select(dtRow => new Building()
                {
                    BuildingID = Convert.ToInt32(dtRow["BuildingID"]),
                    BuildingName = Convert.ToString(dtRow["BuildingName"])
                }).ToList();
                return buildings;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }


        public List<BayType> GetBayType(string connString)
        {
            DataTable dataTable = null;
            try
            {

                dataTable = SqlHelper.GetDataTable(connString, "uspGetBayTypeDDL", null);
                List<BayType> bayType = dataTable.AsEnumerable().Select(dtRow => new BayType()
                {
                    BayTypeID = Convert.ToInt32(dtRow["BayTypeID"]),
                    BayTypeName = Convert.ToString(dtRow["BayTypeName"])
                }).ToList();
                return bayType;
            }
            catch (Exception ex)
            {

                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }

        public List<ProductType> GetProductType(string connString, int plantid)
        {
            DataTable dataTable = null;
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@plantID", plantid)
                };

                dataTable = SqlHelper.GetDataTable(connString, "uspProductTypeDDL", param);
                List<ProductType> productType = dataTable.AsEnumerable().Select(dtRow => new ProductType()
                {
                    ProductGroupID = Convert.ToInt32(dtRow["ProductGroupID"]),
                    ProductName = Convert.ToString(dtRow["ProductName"])
                }).ToList();
                return productType;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }

        public List<MasterRecords> GetBayStatusDDL(string connString)
        {
            DataTable dataTable = null;
            try
            {

                dataTable = SqlHelper.GetDataTable(connString, "uspGetBayStatusDDL", null);
                List<MasterRecords> masterRecords = dataTable.AsEnumerable().Select(dtRow => new MasterRecords()
                {
                    MasterRecordID = dtRow.Field<long>("MasterRecordID"),
                    MasterRecordName = dtRow.Field<string>("MasterRecordName")
                }).ToList();
                return masterRecords;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataTable != null)
                    dataTable.Dispose();
            }
        }



    }
}
