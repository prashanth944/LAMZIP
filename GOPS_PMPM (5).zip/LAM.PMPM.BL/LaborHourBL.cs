﻿using LAM.PMPM.DAL;
using LAM.PMPM.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;

namespace LAM.PMPM.BL
{
    public class LaborHourBL
    {
        public object GetPSNOrBEN(string connString, int plantid, string searchtext = "", string BENOrPSN = "")
        {
            DataTable dataTable;

            if (string.IsNullOrEmpty(searchtext))
            {
                SqlParameter[] param =
                {
                    new SqlParameter("@PlantId", plantid)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetPSNAndBENByPlantId", param);

                var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
                {
                    PilotProductID = dtRow.Field<long?>("PilotProductID"),
                    PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                    BEN = dtRow.Field<string>("BEN"),
                }).ToList();

                return masterRecords;
            }
            else
            {
                SqlParameter[] param =
                {
                    new SqlParameter("@PlantId", plantid),
                    new SqlParameter("@SearchText", searchtext),
                    new SqlParameter("@BENOrPSN", BENOrPSN),
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetPSNAndBENByPlantId", param);

                var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
                {
                    PilotProductID = dtRow.Field<long?>("PilotProductID"),
                    PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                    BEN = dtRow.Field<string>("BEN"),
                }).ToList();

                return masterRecords;
            }
        }

        public object GetLaborHourItems(string connString, string type)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@Type", type)
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetLaborHourItems", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
            {
                LaborHourItemTypeId = dtRow.Field<long?>("LaborHourItemTypeId"),
                OptionName = dtRow.Field<string>("OptionName"),
                Type = dtRow.Field<string>("Type"),
            }).ToList();

            return masterRecords;
        }

        public object GetWOPO(string connString, int plantid, string etchormecha, string searchtext)
        {
            DataTable dataTable;

            if (string.IsNullOrEmpty(searchtext))
            {
                SqlParameter[] param =
                {
                    new SqlParameter("@PlantId", plantid),
                    new SqlParameter("@EtchOrMecha", etchormecha)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetWOPOSPecialSubassemblyByPlantId", param);

                var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
                {
                    PilotProductID = dtRow.Field<long?>("PilotProductID"),
                    PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber")
                }).ToList();

                return masterRecords;
            }
            else
            {
                SqlParameter[] param =
                {
                    new SqlParameter("@PlantId", plantid),
                    new SqlParameter("@EtchOrMecha", etchormecha),
                    new SqlParameter("@SearchText", searchtext),
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetWOPOSPecialSubassemblyByPlantId", param);

                var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
                {
                    PilotProductID = dtRow.Field<long?>("PilotProductID"),
                    PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber")
                }).ToList();

                return masterRecords;
            }
        }

        public object GetLaborHourTypeForLaborHours(string connString, int plantid)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@PlantId", plantid)
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetLaborHourTypeForLaborHours", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
            {
                LaborHourTypeId = dtRow.Field<long?>("LaborHourTypeId"),
                OptionName = dtRow.Field<string>("OptionName"),
                Type = dtRow.Field<string>("Type")
            }).ToList();

            return masterRecords;
        }

        public object GetLaborHourLoanTo(string connString, int plantid)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@PlantId", plantid)
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetLaborHourLoanTo", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
            {
                LaborHourLoanToId = dtRow.Field<long?>("LaborHourLoanToId"),
                OptionName = dtRow.Field<string>("OptionName")
            }).ToList();

            return masterRecords;
        }

        public object GetLaborHourTypes(string connString)
        {
            DataTable dataTable;

            dataTable = SqlHelper.GetDataTable(connString, "uspGetLaborHourType");

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
            {
                LaborTypeID = dtRow.Field<int?>("LaborTypeID"),
                LaborTypeName = dtRow.Field<string>("LaborTypeName")
            }).ToList();

            return masterRecords;
        }

        public int AddLaborHours(string connString, LaborHourAddDetails laborHourAddDetails)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@LaborHourId", laborHourAddDetails.LaborHourId),
                    new SqlParameter("@UserId", laborHourAddDetails.UserId),
                    new SqlParameter("@PlantId",  laborHourAddDetails.PlantId),
                    new SqlParameter("@LaborHourDate",  laborHourAddDetails.LaborHourDate),
                    new SqlParameter("@LaborHourTypeId",  laborHourAddDetails.LaborHourTypeId),
                    new SqlParameter("@LaborHourLoanToId",  laborHourAddDetails.LaborHourLoanToId),
                    new SqlParameter("@BEN",  laborHourAddDetails.BEN),
                    new SqlParameter("@PSN",  laborHourAddDetails.PSN),
                    new SqlParameter("@CreatedOn",  laborHourAddDetails.CreatedOn),
                    new SqlParameter("@CreatedBy ",  laborHourAddDetails.CreatedBy),
                    new SqlParameter("@ModifedOn",  laborHourAddDetails.ModifiedOn),
                    new SqlParameter("@ModifiedBy ",  laborHourAddDetails.ModifiedBy),
                    new SqlParameter("@LaborHourValuesType", GetLaborHourValueTable(laborHourAddDetails.LaborHourValues)),
                    new SqlParameter("@LaborHourModuleMappingType",  GetLaborHourModuleMapping(laborHourAddDetails.LaborHourModuleMappings)),
                    new SqlParameter("@CurrentDate",  laborHourAddDetails.CurrentDate),
                    outParam
                    };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspAddLaborHours", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        private DataTable GetLaborHourValueTable(List<LaborHourValues> laborHourValues)
        {
            DataTable laborHourValue = new DataTable();

            laborHourValue.Columns.Add("LaborHourValuesId", typeof(long));
            laborHourValue.Columns.Add("LaborHourId", typeof(long));
            laborHourValue.Columns.Add("LaborTypeId", typeof(int));
            laborHourValue.Columns.Add("LaborHourItemTypeId", typeof(long));
            laborHourValue.Columns.Add("LaborHourValue", typeof(decimal));
            laborHourValue.Columns.Add("SpecialSubAssemblyPilotProductId", typeof(long));
            laborHourValue.Columns.Add("IsRework", typeof(bool));
            laborHourValue.Columns.Add("BOMChange", typeof(bool));
            laborHourValue.Columns.Add("PilotOrSupplierCaused", typeof(string));
            laborHourValue.Columns.Add("ReworkCategoryId", typeof(long));

            foreach (LaborHourValues laborHour in laborHourValues)
            {
                laborHourValue.Rows.Add(laborHour.LaborHourValuesId, laborHour.LaborHourId, laborHour.LaborTypeId, laborHour.LaborHourItemTypeId, laborHour.LaborHourValue
                    , laborHour.SpecialSubAssemblyPilotProductId, laborHour.IsRework, laborHour.BOMChange, laborHour.PilotOrSupplierCaused, laborHour.ReworkCategoryId);
            }

            return laborHourValue;
        }

        private DataTable GetLaborHourModuleMapping(List<LaborHourModuleMapping> laborHourModuleMappings)
        {
            DataTable laborHourModuleMapping = new DataTable();

            laborHourModuleMapping.Columns.Add("LaborHourModuleMappingId", typeof(long));
            laborHourModuleMapping.Columns.Add("LaborHourId", typeof(long));
            laborHourModuleMapping.Columns.Add("PilotProductId", typeof(long));
            laborHourModuleMapping.Columns.Add("IsSpecialSubAssembly", typeof(bool));

            foreach (LaborHourModuleMapping laborMapping in laborHourModuleMappings)
            {
                laborHourModuleMapping.Rows.Add(laborMapping.LaborHourModuleMappingId, laborMapping.LaborHourId, laborMapping.PilotProductId
                    , laborMapping.IsSpecialSubAssembly);
            }

            return laborHourModuleMapping;
        }

        public LaborHourDashboard GetLaborHours(string connString, int userid, DateTime currenttime)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@UserId", userid),
                new SqlParameter("@CurrentTime", currenttime),
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetLaborHourLeadDashboard", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new LaborHourDashboard()
            {
                UserId = dtRow.Field<long?>("UserId"),
                WorkingHours = dtRow.Field<decimal?>("WorkingHours"),
                RecordedHours = dtRow.Field<decimal?>("RecordedHours"),
                IsVerified = dtRow.Field<bool?>("IsVerified")
            }).FirstOrDefault();

            return masterRecords;
        }

        public object GetLeadBENorPSN(string connString, int userid)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@UserId", userid)
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetLHLeadBENorPSN", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
            {
                PilotProductID = dtRow.Field<long?>("PilotProductID"),
                BEN = dtRow.Field<string>("BEN"),
                PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber")
            }).ToList();

            return masterRecords;
        }

        public object GetBuildingOfUser(string connString, int userid)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@UserId", userid)
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetLHBuildingOfUser", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
            {
                BuildingID = dtRow.Field<long?>("BuildingID"),
                Code = dtRow.Field<string>("Code"),
                IsSelected = dtRow.Field<bool?>("IsSelected")
            }).ToList();

            return masterRecords;
        }

        public List<LaborHourTechWorkLog> GetLHTechWorkLogData(string connString, long UserID, int PlantID, long ShiftID, DateTime CurrentTime)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@UserID", UserID),
                new SqlParameter("@PlantID", PlantID),
                new SqlParameter("@ShiftId", ShiftID),
                new SqlParameter("@CurrentTime", CurrentTime),
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetLHTechWorkLogData", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new LaborHourTechWorkLog
            {
                BEN = dtRow.Field<string>("BEN"),
                PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                OperationName = dtRow.Field<string>("Description"),
                IsRework = dtRow.Field<bool?>("IsRework"),
                StartTime = dtRow.Field<DateTime?>("StartTime"),
                EndTime = dtRow.Field<DateTime?>("EndTime"),
                InterruptionHours = dtRow.Field<decimal?>("InterruptionHours"),
                TotalHours = dtRow.Field<decimal?>("TotalHours"),
                buildStyle = dtRow.Field<string>("buildStyle"),

            }).ToList();

            return masterRecords;
        }

        public int UpdateInsertNotes(string connString, LaborHourNotesViewModel laborHourNotesViewModel)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                     new SqlParameter("@LaborHourVerificationId", laborHourNotesViewModel.LaborHourVerificationId),
                     new SqlParameter("@UserId", laborHourNotesViewModel.UserId),
                     new SqlParameter("@CurrentDate", laborHourNotesViewModel.CurrentDate),
                     new SqlParameter("@Notes", laborHourNotesViewModel.Notes)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateOrInsertLaborHourNotes", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<LaborHourSupDashboardView> GetSupervisorLaborHours(string connString, int userid, DateTime currenttime, int plantid)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@UserID", userid),
                new SqlParameter("@CurrentTime", currenttime),
                new SqlParameter("@PlantId", plantid)
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetLaborHourSupervisorDashboard", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new LaborHourSupDashboardView
            {
                LaborHourVerificationId = dtRow.Field<long?>("LaborHourVerificationId"),
                UserName = dtRow.Field<string>("Name"),
                WorkingHours = dtRow.Field<decimal?>("WorkingHours"),
                FinanceHours = dtRow.Field<decimal?>("FinanceHours"),
                Utilization = dtRow.Field<decimal?>("Utilization"),
                DirectCT = dtRow.Field<decimal?>("DirectCT"),
                Interrupts = dtRow.Field<decimal?>("Interrupts"),
                BreakLunchInterrupt = dtRow.Field<decimal?>("BreakLunchInterrupt"),
                TotalReworkHours = dtRow.Field<decimal?>("TotalReworkHours"),
                Total = dtRow.Field<decimal?>("Total"),
                Notes = dtRow.Field<string>("Notes"),
                CalendarEvent = dtRow.Field<string>("CalendarEvent"),
                CalendarEventStatus = dtRow.Field<string>("CalendarEventStatus"),
                UserId = dtRow.Field<long?>("UserId"),
                RowColor = dtRow.Field<string>("RowColor"),
                ShiftDescription = dtRow.Field<string>("ShiftShortDescription")
            }).ToList();

            return masterRecords;
        }

        public int UpdateBuilding(string connString, int userid, int buildingid)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                     new SqlParameter("@UserID", userid),
                     new SqlParameter("@BuildingId", buildingid)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateUserBuilding", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public LaborHourEditDisplayModel GetLaborHoursById(string connString, int laborhourid)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@LaborHourId", laborhourid)
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetEditLaborHour", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new LaborHourEditViewModel
            {
                UserId = dtRow.Field<long?>("UserId"),
                LaborHourDate = dtRow.Field<DateTime?>("LaborHourDate"),
                UserName = dtRow.Field<string>("UserName"),
                LaborHourId = dtRow.Field<long?>("LaborHourId"),
                LaborTypeId = dtRow.Field<int?>("LaborTypeId"),
                LaborTypeName = dtRow.Field<string>("LaborTypeName"),
                LaborHourItemTypeId = dtRow.Field<long?>("LaborHourItemTypeId"),
                LaborHourValue = dtRow.Field<decimal?>("LaborHourValue"),
                SpecialSubAssemblyPilotProductId = dtRow.Field<long?>("SpecialSubAssemblyPilotProductId"),
                IsSpecialSubAssembly = dtRow.Field<bool?>("IsSpecialSubAssembly"),
                IsSingleModule = dtRow.Field<bool?>("IsSingleModule"),
                IsMultiSelectModule = dtRow.Field<bool?>("IsMultiSelectModule"),
                LaborHourTypeId = dtRow.Field<long?>("LaborHourTypeId"),
                PilotProductId = dtRow.Field<long?>("PilotProductId"),
                LaborHourValuesId = dtRow.Field<long?>("LaborHourValuesId"),
                WOPO = dtRow.Field<string>("WOPO"),
                BENorPSN = dtRow.Field<string>("BENorPSN"),
                LaborHourLoanToId = dtRow.Field<long?>("LaborHourLoanToId"),
                BENTextEntered = dtRow.Field<string>("BENTextEntered"),
                PSNTextEntered = dtRow.Field<string>("PSNTextEntered"),
                PlantId = dtRow.Field<long?>("PlantId"),
                IsRework = dtRow.Field<bool?>("IsRework"),
                BOMChange = dtRow.Field<bool?>("BOMChange"),
                PilotOrSupplierCaused = dtRow.Field<string>("PilotOrSupplierCaused"),
                ReworkCategoryId = dtRow.Field<long?>("ReworkCategoryId"),
                ReworkCategory = dtRow.Field<string>("ReworkCategory"),
            }).ToList();

            LaborHourEditUserDetail laborHourEditUserDetail = masterRecords.GroupBy(x => new { x.UserId, x.UserName, x.LaborHourDate, x.LaborHourTypeId, x.LaborHourLoanToId, x.BENTextEntered, x.PSNTextEntered, x.PlantId }).Select(x => new LaborHourEditUserDetail()
            {
                UserId = x.Key.UserId,
                LaborHourDate = x.Key.LaborHourDate,
                UserName = x.Key.UserName,
                BEN = x.Key.BENTextEntered,
                PSN = x.Key.PSNTextEntered,
                LaborHourLoanToId = x.Key.LaborHourLoanToId,
                LaborHourTypeId = x.Key.LaborHourTypeId,
                PlantId = x.Key.PlantId
            }).FirstOrDefault();

            List<LaborHourPilotProductIdEdit> pilotProductId = new List<LaborHourPilotProductIdEdit>();
            List<LaborHourSpecialSubAssemblyPilotProductIdEdit> specialSubAssemblyPilotProductId = new List<LaborHourSpecialSubAssemblyPilotProductIdEdit>();

            masterRecords.ForEach(x =>
            {
                if (pilotProductId.Where(z => z.PilotProductId == x.PilotProductId).Count() == 0)
                {
                    pilotProductId.Add(new LaborHourPilotProductIdEdit { BENorPSN = x.BENorPSN, PilotProductId = x.PilotProductId });
                }

                if (specialSubAssemblyPilotProductId.Where(z => z.SpecialSubAssemblyPilotProductId == x.SpecialSubAssemblyPilotProductId).Count() == 0)
                {
                    specialSubAssemblyPilotProductId.Add(new LaborHourSpecialSubAssemblyPilotProductIdEdit { SpecialSubAssemblyPilotProductId = x.SpecialSubAssemblyPilotProductId, WOPO = x.WOPO });
                }

            });

            pilotProductId.RemoveAll(x => x.PilotProductId == null);

            specialSubAssemblyPilotProductId.RemoveAll(x => x.SpecialSubAssemblyPilotProductId == null);

            bool? isSingleModule = masterRecords.Select(x => x.IsSingleModule).FirstOrDefault();
            bool? isMultiSelectModule = masterRecords.Select(x => x.IsMultiSelectModule).FirstOrDefault();
            bool? isSpecialSubAssembly = masterRecords.Select(x => x.IsSpecialSubAssembly).FirstOrDefault();

            List<LaborHourValueEdit> laborHourValueEdits = masterRecords.Where(x => x.IsRework != true).GroupBy(zz => zz.LaborHourValuesId).Select(x => new LaborHourValueEdit()
            {
                LaborHourId = x.FirstOrDefault().LaborHourId,
                LaborHourItemTypeId = x.FirstOrDefault().LaborHourItemTypeId,
                WOPO = x.FirstOrDefault().WOPO,
                LaborHourValue = x.FirstOrDefault().LaborHourValue,
                LaborHourValuesId = x.FirstOrDefault().LaborHourValuesId,
                LaborTypeId = x.FirstOrDefault().LaborTypeId,
                SpecialSubAssemblyPilotProductId = x.FirstOrDefault().SpecialSubAssemblyPilotProductId
            }).Distinct().ToList();

            List<LaborHourReworks> laborHourReworks = masterRecords.Where(x => x.IsRework == true).GroupBy(zz => zz.LaborHourValuesId).Select(x => new LaborHourReworks()
            {
                BOMChange = x.FirstOrDefault().BOMChange,
                LaborHourValue = x.FirstOrDefault().LaborHourValue,
                Phase = x.FirstOrDefault().LaborTypeName,
                PilotOrSupplierCaused = x.FirstOrDefault().PilotOrSupplierCaused,
                ReworkCategory = x.FirstOrDefault().ReworkCategory,
                ReworkCategoryId = x.FirstOrDefault().ReworkCategoryId
            }).Distinct().ToList();

            LaborHourEditDisplayModel laborHourEditDisplayModel = new LaborHourEditDisplayModel()
            {
                SpecialSubAssemblyPilotProductId = specialSubAssemblyPilotProductId,
                LaborHourEditUserDetail = laborHourEditUserDetail,
                LaborHourValueEdits = laborHourValueEdits,
                PilotProductId = pilotProductId,
                IsSpecialSubAssembly = isSpecialSubAssembly,
                IsMultiSelectModule = isMultiSelectModule,
                IsSingleModule = isSingleModule,
                LaborHourReworks = laborHourReworks
            };

            return laborHourEditDisplayModel;
        }

        public object GetLaborhoursSubmittedForToday(string connString, int userid, int plantid, int shiftid, DateTime currenttime)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@UserID", userid),
                new SqlParameter("@CurrentTime", currenttime),
                new SqlParameter("@PlantId", plantid),
                new SqlParameter("@ShiftId", shiftid)
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetLaborhoursSubmittedForToday", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
            {
                ReworkHours = dtRow.Field<decimal?>("ReworkHours"),
                StandardHours = dtRow.Field<decimal?>("StandardHours"),
            }).ToList();

            return masterRecords;
        }

        public LaborHourManagerDetails GetManagerSummary(string connString, int lamid, int plantid, string type, DateTime currenttime)
        {
            DataSet dataSet;

            SqlParameter[] param =
            {
                new SqlParameter("@LamId", lamid),
                new SqlParameter("@CurrentTime", currenttime),
                new SqlParameter("@PlantId", plantid),
                new SqlParameter("@Type", type)
            };

            dataSet = SqlHelper.GetDataSet(connString, "uspGetLaborHourManagerSummary", param);

            var masterRecords = dataSet.Tables[0].AsEnumerable().Select(dtRow => new LaborHourManagerSummary
            {
                LaborHourVerificationId = dtRow.Field<long?>("LaborHourVerificationId"),
                LaborHourDate = dtRow.Field<DateTime?>("Date"),
                UserName = dtRow.Field<string>("Name"),
                WorkingHours = dtRow.Field<decimal?>("WorkingHours"),
                RecordedHours = dtRow.Field<decimal?>("RecordedHours"),
                FinanceHours = dtRow.Field<decimal?>("FinanceHours"),
                Utilization = dtRow.Field<decimal?>("Utilization"),
                DirectCT = dtRow.Field<decimal?>("DirectCT"),
                Interrupts = dtRow.Field<decimal?>("Interrupts"),
                BreakLunchInterrupt = dtRow.Field<decimal?>("BreakLunchInterrupt"),
                TotalReworkHours = dtRow.Field<decimal?>("TotalReworkHours"),
                Total = dtRow.Field<decimal?>("Total"),
                Notes = dtRow.Field<string>("Notes"),
                CalendarEvent = dtRow.Field<string>("CalendarEvent"),
                CalendarEventStatus = dtRow.Field<string>("CalendarEventStatus"),
                UserId = dtRow.Field<long?>("UserId"),
                RowColor = dtRow.Field<string>("RowColor"),
                ShiftStartTime = dtRow.Field<TimeSpan?>("ShiftStartTime"),
                ShiftShortDescription = dtRow.Field<string>("ShiftShortDescription"),
                LamHoliday = dtRow.Field<string>("LamHoliday"),
            }).ToList();

            var laborHourManagerDetails = dataSet.Tables[1].AsEnumerable().Select(dtRow => new LaborHourManagerDetails
            {
                LamId = dtRow.Field<int?>("LamId"),
                UserId = dtRow.Field<long?>("UserId"),
                Name = dtRow.Field<string>("Name"),
                VerifiedApprovedCount = dtRow.Field<int?>("Numerator"),
                TotalCount = dtRow.Field<int?>("Denominator"),
                Percentage = dtRow.Field<int?>("Percentage"),

            }).FirstOrDefault();

            if (laborHourManagerDetails != null)
            {
                laborHourManagerDetails.LaborHourManagerSummary = masterRecords;
            }


            return laborHourManagerDetails;
        }

        public int UpdateCycleTime(string connString, CycleTimeUpdateViewModel[] cycleTimeUpdateView, DateTime currenttime)
        {
            try
            {
                var resultCount = 0;
                foreach (var item in cycleTimeUpdateView)
                {
                    var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                    {
                        Direction = ParameterDirection.Output
                    };

                    SqlParameter[] param = {
                    new SqlParameter("@WorkRecordId", item.WorkRecordId),
                    new SqlParameter("@WorkRecordInterruptionId",  item.WorkRecordInterruptionId),
                    new SqlParameter("@EndMinutes",  item.EndMinutes),
                    new SqlParameter("@CurrentTime",  currenttime),
                    outParam
                };
                    resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateCycleTimeByWorkrecordId", param);
                }

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<CycleTimeViewModel> GetCycleTimeOfUser(string connString, int userid, int plantid, string type, DateTime currenttime)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@UserID", userid),
                new SqlParameter("@CurrentTime", currenttime),
                new SqlParameter("@PlantId", plantid),
                new SqlParameter("@Type", type)
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetCycleTimeByUser", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new CycleTimeViewModel
            {
                WorkType = dtRow.Field<string>("WorkType"),
                WorkRecordID = dtRow.Field<long?>("WorkRecordID"),
                PilotProductID = dtRow.Field<long?>("PilotProductID"),
                BEN = dtRow.Field<string>("BEN"),
                PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                OperationID = dtRow.Field<long?>("OperationID"),
                OPDescription = dtRow.Field<string>("Description"),
                StartTimestamp = dtRow.Field<DateTime?>("StartTimestamp"),
                EndTimestamp = dtRow.Field<DateTime?>("EndTimestamp"),
                RecordedTime = dtRow.Field<decimal?>("RecordedTime"),
                ModifiedTime = dtRow.Field<decimal?>("ModifiedTime"),
                IsModified = dtRow.Field<bool?>("IsModified"),
                WorkRecordInterruptionId = dtRow.Field<long?>("WorkRecordInterruptionId")
            }).ToList();

            return masterRecords;
        }

        public int DeleteLaborHour(string connString, int laborhourid)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                     new SqlParameter("@LaborHourId", laborhourid)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateDeleteLaborHour", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
                
        public List<LaborHourSubmitted> GetSubmittedLaborHours(string connString, int userid, DateTime currenttime, int shiftid)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@UserID", userid),
                new SqlParameter("@CurrentTime", currenttime),
                new SqlParameter("@ShiftId", shiftid)
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetLaborHourSubmitted", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new LaborHourSubmitted
            {
                LaborHourId = dtRow.Field<long?>("LaborHourId"),
                LaborHourDate = dtRow.Field<DateTime?>("LaborHourDate"),
                TotalLaborHours = dtRow.Field<decimal?>("TotalLaborHours"),
                BENorPSN = dtRow.Field<string>("BENorPSN"),
                IsEditable = dtRow.Field<bool?>("IsEditable")
            }).ToList();

            return masterRecords;
        }

        public List<LaborHourTechWorkLog> GetLHTechInterruptionData(string connString, long UserID, int PlantID, long ShiftID, DateTime CurrentTime)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@UserID", UserID),
                 new SqlParameter("@PlantID", PlantID),
                    new SqlParameter("@ShiftId", ShiftID),
                new SqlParameter("@CurrentTime", CurrentTime),
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetLHTechInterruptionData", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new LaborHourTechWorkLog
            {
                BEN = dtRow.Field<string>("BEN"),
                PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                InterruptionCategory = dtRow.Field<string>("OptionName"),
                StartTime = dtRow.Field<DateTime?>("StartTime"),
                EndTime = dtRow.Field<DateTime?>("EndTime"),
                InterruptionHours = dtRow.Field<decimal?>("InterruptionHours"),
                Notes = dtRow.Field<string>("Notes")

            }).ToList();

            return masterRecords;
        }
        public int UpdateLHTechIsVerify(string connString, long UserID, bool verify, long ShiftID, DateTime CurrentTime, int PlantID)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                     new SqlParameter("@UserID", UserID)   ,
                     new SqlParameter("@verify", verify),
                      new SqlParameter("@ShiftId", ShiftID),
                       new SqlParameter("@CurrentTime", CurrentTime),
                       new SqlParameter("@PlantID", PlantID)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateLaborTechIsVerify", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int UpdateLaborTechWorkHours(string connString, long UserID, decimal Hours, long ShiftID, DateTime CurrentTime, int PlantID)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                     new SqlParameter("@UserID", UserID),
                      new SqlParameter("@Hours", Hours),
                      new SqlParameter("@ShiftId", ShiftID),
                      new SqlParameter("@CurrentTime", CurrentTime),
                        new SqlParameter("@PlantID", PlantID)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateLaborTechWorkHours", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public LaborHourTechDashBoard GetLHTechDashBoard(string connString, long UserID, int PlantID, long ShiftID, DateTime CurrentTime)
        {
            LaborHourTechDashBoard objLaborHourTechDashBoard = new LaborHourTechDashBoard();
            DataSet dataset;
            SqlParameter[] param =
            {
               new SqlParameter("@UserID",UserID),
                 new SqlParameter("@PlantID",PlantID),
                  new SqlParameter("@ShiftId",ShiftID),
                   new SqlParameter("@CurrentTime",CurrentTime)
            };
            dataset = SqlHelper.GetDataSet(connString, "uspGetLHTechDashBoard", param);
            try
            {
                DataTable dataTable = dataset.Tables[0];
                objLaborHourTechDashBoard.Working = Convert.ToDecimal(dataTable.Rows[0]["Working"]);
                objLaborHourTechDashBoard.Recorded = Convert.ToDecimal(dataTable.Rows[0]["Recorded"]);
                objLaborHourTechDashBoard.Direct = Convert.ToDecimal(dataTable.Rows[0]["Direct"]);
                objLaborHourTechDashBoard.Interrupts = Convert.ToDecimal(dataTable.Rows[0]["Interrupts"]);
                objLaborHourTechDashBoard.BreaksOrLunch = Convert.ToDecimal(dataTable.Rows[0]["LunchBreak"]);
                objLaborHourTechDashBoard.Rework = Convert.ToDecimal(dataTable.Rows[0]["Rework"]);
                objLaborHourTechDashBoard.Total = Convert.ToDecimal(dataTable.Rows[0]["Total"]);
                objLaborHourTechDashBoard.IsVerify = Convert.ToBoolean(dataTable.Rows[0]["IsVerify"]);
                objLaborHourTechDashBoard.IsSwitched = Convert.ToBoolean(dataTable.Rows[0]["IsSwitched"]);
                DataTable dt = dataset.Tables[1];
                List<LaborHourTechDashBoardBENDetails> LaborTechBENDetails = new List<LaborHourTechDashBoardBENDetails>();
                LaborTechBENDetails = ConvertDataTable<LaborHourTechDashBoardBENDetails>(dt);
                objLaborHourTechDashBoard.LaborTechBENDetails = LaborTechBENDetails;

            }
            catch (Exception Ex)
            {
                Ex.Message.ToString();
            }
            return objLaborHourTechDashBoard;
        }


        public LaborHourManagerData GetLHManagerData(string connString, long UserID, int PlantID, long ShiftID, DateTime CurrentTime)
        {
            try
            {
                LaborHourManagerData objLaborHourTechDashBoard = new LaborHourManagerData();
                DataSet dataset;
                SqlParameter[] param =
                {
                   new SqlParameter("@UserID",UserID),
                   new SqlParameter("@PlantID",PlantID),
                   new SqlParameter("@ShiftId",ShiftID),
                   new SqlParameter("@CurrentTime",CurrentTime)
                };

                dataset = SqlHelper.GetDataSet(connString, "uspGetLaborMangerData", param);


                DataTable dt = dataset.Tables[0];

                var masterRecords = dt.AsEnumerable().Select(dtRow => new LaborHourManagerDataDetails
                {
                    LamId = dtRow.Field<int?>("LamId"),
                    UserId = dtRow.Field<long?>("UserId"),
                    Name = dtRow.Field<string>("Name"),
                    Percentage = dtRow.Field<int?>("Percentage"),

                }).ToList();

                DataTable dataTableDate = dataset.Tables[1];
                objLaborHourTechDashBoard.StartDate = Convert.ToDateTime(dataTableDate.Rows[0]["StartDate"]);
                objLaborHourTechDashBoard.EndDate = Convert.ToDateTime(dataTableDate.Rows[0]["EndDate"]);

                objLaborHourTechDashBoard.LaborHourManagerDataDetails = masterRecords;

                return objLaborHourTechDashBoard;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }

        }

        public LaborHourManagerData GetLHManagerDataForCurrentQuarter(string connString, long UserID, int PlantID, long ShiftID, DateTime CurrentTime)
        {
            try
            {
                LaborHourManagerData objLaborHourTechDashBoard = new LaborHourManagerData();
                DataSet dataset;
                SqlParameter[] param =
                {
                   new SqlParameter("@UserID",UserID),
                   new SqlParameter("@PlantID",PlantID),
                   new SqlParameter("@ShiftId",ShiftID),
                   new SqlParameter("@CurrentTime",CurrentTime)
                };

                dataset = SqlHelper.GetDataSet(connString, "uspGetLaborMangerDataForCurrentQuarter", param);

                DataTable dt = dataset.Tables[0];

                var masterRecords = dt.AsEnumerable().Select(dtRow => new LaborHourManagerDataDetails
                {
                    LamId = dtRow.Field<int?>("LamId"),
                    UserId = dtRow.Field<long?>("UserId"),
                    Name = dtRow.Field<string>("Name"),
                    Percentage = dtRow.Field<int?>("Percentage"),

                }).ToList();


                DataTable dataTableDate = dataset.Tables[1];
                objLaborHourTechDashBoard.StartDate = Convert.ToDateTime(dataTableDate.Rows[0]["StartDate"]);
                objLaborHourTechDashBoard.EndDate = Convert.ToDateTime(dataTableDate.Rows[0]["EndDate"]);

                objLaborHourTechDashBoard.LaborHourManagerDataDetails = masterRecords;

                return objLaborHourTechDashBoard;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }

        }

        public int UpdateLHTechIsSwitched(string connString, long UserID, bool IsSwitched, long ShiftID, DateTime CurrentTime, int PlantID)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                     new SqlParameter("@UserID", UserID)   ,
                     new SqlParameter("@IsSwitched", IsSwitched),
                      new SqlParameter("@ShiftId", ShiftID),
                       new SqlParameter("@CurrentTime", CurrentTime),
                       new SqlParameter("@PlantID", PlantID)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateLaborTechIsSwitched", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        private static List<T> ConvertDataTable<T>(DataTable dt)
        {
            List<T> data = new List<T>();
            foreach (DataRow row in dt.Rows)
            {
                T item = GetItem<T>(row);
                data.Add(item);
            }
            return data;
        }
        private static T GetItem<T>(DataRow dr)
        {
            Type temp = typeof(T);
            T obj = Activator.CreateInstance<T>();

            foreach (DataColumn column in dr.Table.Columns)
            {
                foreach (PropertyInfo pro in temp.GetProperties())
                {
                    if (pro.Name == column.ColumnName)
                        pro.SetValue(obj, dr[column.ColumnName], null);
                    else
                        continue;
                }
            }
            return obj;
        }
    }
}
