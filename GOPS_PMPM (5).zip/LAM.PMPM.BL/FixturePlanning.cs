﻿using LAM.PMPM.DAL;
using LAM.PMPM.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace LAM.PMPM.BL
{
    public class FixturePlanning
    {
        public List<FixtureSummaryViewModel> GetFixtureSummary(string connString)
        {
          try{
                DataTable dataTable;
            dataTable = SqlHelper.GetDataTable(connString, "USPGetFixtureSummary", null);
            List<FixtureSummaryViewModel> fixtureSummary = dataTable.AsEnumerable().Select(dtRow => new FixtureSummaryViewModel()
            {
                FixtureName = Convert.ToString(dtRow["FixtureName"]),
                FixtureQuantity = Convert.ToInt32(dtRow["FixtureQuantity"])
            }).ToList();
            return fixtureSummary;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public List<FixtureListViewModel> GetFixtureList(string connString)
        {
          try{
                DataTable dataTable;
            dataTable = SqlHelper.GetDataTable(connString, "USPGetFixtureList", null);
            List<FixtureListViewModel> fixtureList = dataTable.AsEnumerable().Select(dtRow => new FixtureListViewModel()
            {
                FixtureName = Convert.ToString(dtRow["FixtureName"]),
                AssetTagNo = Convert.ToString(dtRow["AssetTagNo"])
            }).ToList();
            return fixtureList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int UpdateFixture(string connString, FixtureListViewModel fixtureListViewModel)
        {
            try{
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            SqlParameter[] param = {
                 new SqlParameter("@FixtureID",fixtureListViewModel.FixtureID),
               new SqlParameter("@FixtureName",fixtureListViewModel.FixtureName),
               new SqlParameter("@Status",fixtureListViewModel.Status),
                      new SqlParameter("@ProductType",fixtureListViewModel.ProductType),
                new SqlParameter("@AssetTagNo",fixtureListViewModel.AssetTagNo),
                new SqlParameter("@PilotSerialPartNumber",fixtureListViewModel.PilotSerialPartNumber),
                new SqlParameter("@ModuleProcess",fixtureListViewModel.ModuleProcess),
                outParam
            };

            return SqlHelper.ExecuteNonQuery(connString, "USPUpdateFixtures", param);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public int AddFixture(string connString, FixtureListViewModel fixture)
        {
           try{
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            SqlParameter[] param = {
                new SqlParameter("@assetTagNo",fixture.AssetTagNo),
               new SqlParameter("@fixtureName",fixture.FixtureName),
               new SqlParameter("@status",fixture.Status),
               new SqlParameter("@pilotSerialPartNumber",fixture.PilotSerialPartNumber),
               new SqlParameter("@productType",fixture.ProductType),
               new SqlParameter("@moduleProcess",fixture.ModuleProcess),
               outParam
            };
            return SqlHelper.ExecuteNonQuery(connString, "USPAddFixture", param);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public int DeleteFixture(string connString, int FixtureID)
        {
           try{
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            SqlParameter[] param = {
               new SqlParameter("@FixtureID",FixtureID),
               outParam
            };
            return SqlHelper.ExecuteNonQuery(connString, "USPDeleteFixtures", param);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public List<FixtureModuleMissing> GetModuleMissingFixture(string connString)
        {
            try{
                DataTable dataTable;
            dataTable = SqlHelper.GetDataTable(connString, "USPGetModuleMissingFixture", null);
            List<FixtureModuleMissing> fixtureList = dataTable.AsEnumerable().Select(dtRow => new FixtureModuleMissing()
            {
                PilotSerialNumber = Convert.ToInt32(dtRow["PilotSerialNumber"]),
                ProductType = Convert.ToString(dtRow["ProductType"])
            }).ToList();
            return fixtureList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

    }
}
