﻿using LAM.PMPM.DAL;
using LAM.PMPM.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using LAM.PMPM.Model.ViewModel;
using Newtonsoft.Json;
using System.Text.RegularExpressions;

namespace LAM.PMPM.BL
{
    public class LaborCapacityPlanning
    {
        DataTable dataTable;

        public int AddManagementGroup(string connString, LaborManagementGroup laborManagementGroup)
        {
            try
            {
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter[] param = {
                new SqlParameter("@ManagementName",laborManagementGroup.ManagementName),
                new SqlParameter("@EfficencyFactor",laborManagementGroup.EfficencyFactor),
                new SqlParameter("@OvertimeAllowance",laborManagementGroup.OvertimeAllowance),
                new SqlParameter("@UtilizationTarget",laborManagementGroup.UtilizationTarget),
                new SqlParameter("@PTO",laborManagementGroup.PTOPercentage),
                new SqlParameter("@PlantID",laborManagementGroup.PlantID),
                new SqlParameter("@CreatedOn",laborManagementGroup.CreatedOn),
                outParam
            };

                return SqlHelper.ExecuteNonQuery(connString, "USPAddManagementGroup", param);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public int AddShift(string connString, Shifts[] shifts)
        {
            try
            {
                int count = 1;
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                foreach (var items in shifts)
                {


                    SqlParameter[] param = {
                new SqlParameter("@PlantID",items.PlantID),
                new SqlParameter("@ShiftName",items.ShiftName),
                new SqlParameter("@ShortDescription",items.ShortDescription),
                new SqlParameter("@Comperession",items.Compression),
                new SqlParameter("@DayShiftType",items.DayShiftType),
                new SqlParameter("@Description",items.Description),
                new SqlParameter("@HoursPerDay",items.HoursPerDay),

                new SqlParameter("@Monday", items.Monday1),
                new SqlParameter("@Tuesday", items.Tuesday1),
                new SqlParameter("@Wednesday", items.Wednesday1),
                new SqlParameter("@Thursday", items.Thursday1),
                new SqlParameter("@Friday", items.Friday1),
                new SqlParameter("@Saturday", items.Saturday1),
                new SqlParameter("@Sunday", items.Sunday1),
                new SqlParameter("@ShiftStartTime", items.ShiftStartTime),
                new SqlParameter("@ShiftEndTime", items.ShiftEndTime),
                new SqlParameter("@weekNum", count),
                outParam

            };
                    resultCount = SqlHelper.ExecuteNonQuery(connString, "USPAddShift", param);
                    count = count + 1;
                }
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<LaborManagementGroup> GetManagementGroup(string connString, int PlantID)
        {
            try
            {
                SqlParameter[] param = {
                new SqlParameter("@PlantID", PlantID),
                };
                dataTable = new DataTable();
                dataTable = SqlHelper.GetDataTable(connString, "USPGetManagementGroup", param);
                List<LaborManagementGroup> laborManagementGroups = dataTable.AsEnumerable().Select(dtRow => new LaborManagementGroup()
                {
                    LaborManagmentGroupID = dtRow.Field<long>("LaborManagmentGroupID"),
                    ManagementName = dtRow.Field<string>("ManagementName"),
                    EfficencyFactor = dtRow.Field<decimal?>("EfficencyFactor"),
                    OvertimeAllowance = dtRow.Field<decimal?>("OvertimeAllowance"),
                    UtilizationTarget = dtRow.Field<decimal?>("UtilizationTarget"),
                    PTOPercentage = dtRow.Field<decimal?>("PTOPercentage"),
                    CreatedOn = dtRow.Field<DateTime?>("CreatedOn"),
                }).ToList();
                return laborManagementGroups;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<LabourManagementGroupMapping> GetLaborManagementProductGroup(string connString, int PlantID)
        {
            DataTable dataTable;
            SqlParameter[] param = {
                new SqlParameter("@PlantID", PlantID),
                };
            dataTable = SqlHelper.GetDataTable(connString, "USPGetProductManagmentMap", param);
            Regex rg = new Regex(@"\d+");

            List<LabourManagementGroupMapping> operationViewUIModels = new List<LabourManagementGroupMapping>();

            List<LaborManagementProductGroupViewModel> laborManagementProductGroups = dataTable.AsEnumerable().Select(dtRow => new LaborManagementProductGroupViewModel()
            {
                LaborManagmentGroupID = dtRow.Field<long?>("LaborManagmentGroupID"),
                ManagementName = dtRow.Field<string>("ManagementName"),
                LaborManagmentProductGroupID = dtRow.Field<long?>("LaborManagmentGroupID"),
                ProductGroupID = dtRow.Field<long?>("ProductGroupID"),
                LaborProductGroupID = dtRow.Field<long?>("ProductGroupID"),
                LaborProductName = dtRow.Field<string>("ProductName"),
            }).ToList();

            List<LaborManagementProductGroupViewModelMapping> LaborManagementProductGroupViewModelMapping = dataTable.AsEnumerable().Select(dtRow => new LaborManagementProductGroupViewModelMapping()

            {
                LaborManagmentGroupID = dtRow.Field<long?>("LaborManagmentGroupID"),
                ProductGroupID = dtRow.Field<long?>("ProductGroupID"),
                LaborProductName = dtRow.Field<string>("ProductName"),
            }).ToList();

            if (dataTable != null && dataTable.Rows.Count > 0)
            {

                if (laborManagementProductGroups != null && laborManagementProductGroups.Count > 0)
                {
                    foreach (var item in laborManagementProductGroups)
                    {
                        if (operationViewUIModels.FindAll(x => x.LaborManagmentGroupID == item.LaborManagmentGroupID).Count == 0)
                        {
                            LabourManagementGroupMapping objempd = new LabourManagementGroupMapping();
                            objempd.LaborManagmentGroupID = item.LaborManagmentGroupID;
                            objempd.ManagementName = item.ManagementName;
                            objempd.LaborManagmentProductGroupID = item.LaborManagmentProductGroupID;
                            objempd.LaborProductGroupID = item.LaborProductGroupID;


                            objempd.LaborMgmtGrpDetails = LaborManagementProductGroupViewModelMapping.FindAll(x => x.LaborManagmentGroupID == item.LaborManagmentGroupID).ToList();
                            operationViewUIModels.Add(objempd);
                        }
                    }
                }
            }
            return operationViewUIModels;
        }

        public List<BuildType> GetBuildType(string connString, int PlantID)
        {
            try
            {
                SqlParameter[] param = {
                new SqlParameter("@PlantID", PlantID),
                };
                dataTable = new DataTable();
                dataTable = SqlHelper.GetDataTable(connString, "USPGetLaborMultiplier", param);
                List<BuildType> laborManagementProductGroups = dataTable.AsEnumerable().Select(dtRow => new BuildType()
                {
                    BuildTypeID = dtRow.Field<long>("BuildTypeID"),
                    BuildTypeName = dtRow.Field<string>("BuildTypeName"),
                    LaborMultiplier = dtRow.Field<string>("LaborMultiplier"),
                    MultiplierValue = dtRow.Field<decimal?>("MultiplierValue"),
                }).ToList();
                return laborManagementProductGroups;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public string GetLaborhours(string connString, string interval, int plantID,  string minDate, string maxDate, string shiftDetails = null)
        {
            try
            {
                dataTable = new DataTable();
                SqlParameter[] param = { new SqlParameter("@Interval", interval),
                new SqlParameter("@ShiftDetails", shiftDetails),
                 new SqlParameter("@plantID", plantID),
                 new SqlParameter("@minDate", minDate),
                 new SqlParameter("@maxDate", maxDate)
                };
                dataTable = SqlHelper.GetDataTable(connString, "USPGetLaborhoursV2", param);

                string laborHoursList = null;
                dynamic laborHours = null;
                if (interval.ToLower() == "daily")
                {

                    laborHours = dataTable.Rows.Cast<DataRow>()
                    .GroupBy(x => new { ManagementName = x["ManagementName"], Assembly = x["Assembly"], ShiftDetails = x["ShiftDetails"] })
                    .Select(x => new
                    {
                        ManagementName = x.Key,
                        WeeklyDates = x.Select(y => new
                        {
                            TotalAvailableHour = y.Field<decimal?>("TotalAvailableHour"),
                            LaborDate = y.Field<DateTime>("LaborDate").ToString("M-d-yy")

                        })
                    }).ToList();
                }
                else if (interval.ToLower() == "week")
                {
                    laborHours = dataTable.Rows.Cast<DataRow>()
                   .GroupBy(x => new { ManagementName = x["ManagementName"], Assembly = x["Assembly"], ShiftDetails = x["ShiftDetails"] })
                   .Select(x => new
                   {
                       ManagementName = x.Key,
                       WeeklyDates = x.Select(y => new
                       {
                           TotalAvailableHour = y.Field<decimal?>("TotalAvailableHour"),
                           WeekStart = y.Field<DateTime>("WeekStart").ToString("M-d-yy")

                       })
                   }).ToList();
                }

                else if (interval.ToLower() == "month")
                {
                    laborHours = dataTable.Rows.Cast<DataRow>()
                   .GroupBy(x => new { ManagementName = x["ManagementName"], Assembly = x["Assembly"], ShiftDetails = x["ShiftDetails"] })
                   .Select(x => new
                   {
                       ManagementName = x.Key,
                       WeeklyDates = x.Select(y => new
                       {
                           TotalAvailableHour = y.Field<decimal?>("TotalAvailableHour"),
                           WeekStart = y.Field<DateTime>("MonthStart").ToString("M-d-yy")

                       })
                   }).ToList();
                }
                laborHoursList = Newtonsoft.Json.JsonConvert.SerializeObject(laborHours);
                return laborHoursList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public string GetLaborPool(string connString, string interval, int plantID, string minDate, string maxDate)
        {
            try
            {
                dataTable = new DataTable();
                SqlParameter[] param =
                {
                    new SqlParameter("@Interval", interval), 
                    new SqlParameter("@plantID", plantID),
                    new SqlParameter("@minDate", minDate),
                    new SqlParameter("@maxDate", maxDate)
                };
                dataTable = SqlHelper.GetDataTable(connString, "USPGetLaborPoolV2", param);

                string laborPoolList = null;
                dynamic laborPool = null;
                if (interval.ToLower() == "daily")
                {

                    laborPool = dataTable.Rows.Cast<DataRow>()
                    .GroupBy(x => new { ManagementName = x["ManagementName"], LaborManagmentGroupID = x["LaborManagmentGroupID"], Status = x["StatusValue"], Department = x["Department"], ShortDescription = x["ShortDescription"], DayShiftOnly = x["DayShiftOnly"], AssemblyName = x["AssemblyName"] })
                    .Select(x => new
                    {
                        ManagementName = x.Key,
                        WeeklyDates = x.Select(y => new
                        {
                            AssemblyTestCount = y.Field<decimal?>("AssemblyTestCount"),
                            LaborDate = y.Field<DateTime?>("LaborDate")?.ToString("M-d-yy")



                        })
                    }).ToList();
                }
                else if (interval.ToLower() == "week")
                {

                    laborPool = dataTable.Rows.Cast<DataRow>()
                    .GroupBy(x => new { ManagementName = x["ManagementName"], LaborManagmentGroupID = x["LaborManagmentGroupID"], Status = x["StatusValue"], Department = x["Department"], ShortDescription = x["ShortDescription"], DayShiftOnly = x["DayShiftOnly"], AssemblyName = x["AssemblyName"] })
                    .Select(x => new
                    {
                        ManagementName = x.Key,
                        WeeklyDates = x.Select(y => new
                        {
                            AssemblyTestCount = y.Field<decimal?>("AssemblyTestCount"),
                            WeekStart = y.Field<DateTime?>("WeekStart")?.ToString("M-d-yy")



                        })
                    }).ToList();
                }


                else if (interval.ToLower() == "month")
                {

                    laborPool = dataTable.Rows.Cast<DataRow>()
                    .GroupBy(x => new { ManagementName = x["ManagementName"], LaborManagmentGroupID = x["LaborManagmentGroupID"], Status = x["StatusValue"], Department = x["Department"], ShortDescription = x["ShortDescription"], DayShiftOnly = x["DayShiftOnly"], AssemblyName = x["AssemblyName"] })
                    .Select(x => new
                    {
                        ManagementName = x.Key,
                        WeeklyDates = x.Select(y => new
                        {
                            AssemblyTestCount = y.Field<decimal?>("AssemblyTestCount"),
                            WeekStart = y.Field<DateTime?>("MonthStart")?.ToString("M-d-yy")



                        })
                    }).ToList();
                }
                laborPoolList = Newtonsoft.Json.JsonConvert.SerializeObject(laborPool);
                return laborPoolList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<MasterRecords> GetAssemblyTestDDL(string connString)
        {
            try
            {
                dataTable = new DataTable();
                dataTable = SqlHelper.GetDataTable(connString, "USPGetAssemblyTestDDL", null);
                List<MasterRecords> laborManagementProductGroups = dataTable.AsEnumerable().Select(dtRow => new MasterRecords()
                {
                    MasterRecordID = Convert.ToInt32(dtRow["MasterRecordID"]),
                    MasterRecordName = Convert.ToString(dtRow["MasterRecordName"])
                }).ToList();
                return laborManagementProductGroups;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public List<MasterRecords> GetCompressionDDL(string connString)
        {
            try
            {
                dataTable = new DataTable();
                dataTable = SqlHelper.GetDataTable(connString, "USPGetCompressionDDL", null);
                List<MasterRecords> laborManagementProductGroups = dataTable.AsEnumerable().Select(dtRow => new MasterRecords()
                {
                    MasterRecordID = Convert.ToInt32(dtRow["MasterRecordID"]),
                    MasterRecordName = Convert.ToString(dtRow["MasterRecordName"])
                }).ToList();
                return laborManagementProductGroups;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<MasterRecords> GetDepartmentFromToDDL(string connString)
        {
            try
            {
                dataTable = new DataTable();
                dataTable = SqlHelper.GetDataTable(connString, "USPGetDepartmentFromToDDL", null);
                List<MasterRecords> laborManagementProductGroups = dataTable.AsEnumerable().Select(dtRow => new MasterRecords()
                {
                    MasterRecordID = Convert.ToInt32(dtRow["MasterRecordID"]),
                    MasterRecordName = Convert.ToString(dtRow["MasterRecordName"])
                }).ToList();
                return laborManagementProductGroups;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<MasterRecords> GetManagementGroupDDL(string connString, int PlantID)
        {
            try
            {
                dataTable = new DataTable();
                SqlParameter[] param = {
                new SqlParameter("@PlantID", PlantID),
                };
                dataTable = SqlHelper.GetDataTable(connString, "USPGetManagementGroupDDL", param);
                List<MasterRecords> laborManagementProductGroups = dataTable.AsEnumerable().Select(dtRow => new MasterRecords()
                {
                    MasterRecordID = Convert.ToInt32(dtRow["MasterRecordID"]),
                    MasterRecordName = Convert.ToString(dtRow["MasterRecordName"])
                }).ToList();
                return laborManagementProductGroups;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public List<Shifts> GetShiftTypeDDL(string connString, int plantid)
        {
            try
            {
                dataTable = new DataTable();
                SqlParameter[] param = {
                new SqlParameter("@PlantID", plantid),
                };
                dataTable = SqlHelper.GetDataTable(connString, "USPGetShiftTypeDDL", param);
                List<Shifts> laborManagementProductGroups = dataTable.AsEnumerable().Select(dtRow => new Shifts()
                {
                    ShiftID = Convert.ToInt64(dtRow["shiftID"]),
                    ShortDescription = Convert.ToString(dtRow["ShortDescription"])
                }).ToList();
                return laborManagementProductGroups;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<MasterRecords> GetStatusDDL(string connString)
        {
            try
            {
                dataTable = new DataTable();
                dataTable = SqlHelper.GetDataTable(connString, "USPGetStatusDDL", null);
                List<MasterRecords> laborManagementProductGroups = dataTable.AsEnumerable().Select(dtRow => new MasterRecords()
                {
                    MasterRecordID = Convert.ToInt32(dtRow["MasterRecordID"]),
                    MasterRecordName = Convert.ToString(dtRow["MasterRecordName"]),
                    Type = Convert.ToString(dtRow["Type"]),
                }).ToList();
                return laborManagementProductGroups;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<LaborManagementProductGroupViewModel> GetProductTypeDDL(string connString, int plantid)
        {
            try
            {
                dataTable = new DataTable();
                SqlParameter[] param = {
                new SqlParameter("@PlantID", plantid),
                };

                dataTable = SqlHelper.GetDataTable(connString, "uspGetProductTypeDDL", param);
                List<LaborManagementProductGroupViewModel> laborProductGroups = dataTable.AsEnumerable().Select(dtRow => new LaborManagementProductGroupViewModel()
                {
                    ProductGroupID = Convert.ToInt64(dtRow["ProductGroupID"]),
                    ProductName = Convert.ToString(dtRow["ProductName"])
                }).ToList();
                return laborProductGroups;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        //-------------------------DDL END ---------------------------------------------------
        public int AddAssemblyTechnician(string connString, LaborAssemblyTechnicianViewModel laborAssemblyTechnicianViewModel)
        {
            try
            {
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)

                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter[] param = {

                new SqlParameter("@AssembleyTest",laborAssemblyTechnicianViewModel.AssembleyTest),
                new SqlParameter("@Status",laborAssemblyTechnicianViewModel.Status),
                new SqlParameter("@ManagementGroup",laborAssemblyTechnicianViewModel.ManagementGroup),
                new SqlParameter("@shiftID",laborAssemblyTechnicianViewModel.ShiftID),
                 new SqlParameter("@EffectiveDateString",laborAssemblyTechnicianViewModel.EffectiveDateString),
                 new SqlParameter("@EndDateString",laborAssemblyTechnicianViewModel.EndDateString),
                new SqlParameter("@LoanDeptFromTo",laborAssemblyTechnicianViewModel.LoanDeptFromTo),
                 new SqlParameter("@plantID",laborAssemblyTechnicianViewModel.PlantID),
                new SqlParameter("@HeadCount",laborAssemblyTechnicianViewModel.HeadCount),
                outParam
          };

                return SqlHelper.ExecuteNonQueryNoOutParam(connString, "USPAddAssemblyTechnician", param);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public string GetHeadCount(string connString, string interval, int plantID, string minDate, string maxDate, string shiftDetails = null)
        {
            try
            {
                dataTable = new DataTable();
                SqlParameter[] param = {
                    new SqlParameter("@Interval", interval),
                    new SqlParameter("@ShiftDetails", shiftDetails ),
                    new SqlParameter("@plantID", plantID ),
                    new SqlParameter("@minDate", minDate ),
                    new SqlParameter("@maxDate", maxDate )
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetHeadCountV2", param);

                string laborHeadCountList = null;
                dynamic laborHeadCount = null;

                if (interval.ToLower() == "daily")
                {
                    laborHeadCount = dataTable.Rows.Cast<DataRow>()
                   .GroupBy(x => new { ManagementName = x["ManagementName"], Assembly = x["HeadcountType"], ShiftDetails = x["ShiftDetails"] })
                   .Select(x => new
                   {
                       ManagementName = x.Key,
                       WeeklyDates = x.Select(y => new
                       {
                           Headcount = y.Field<decimal?>("Headcount"),
                           LaborDate = y.Field<DateTime>("LaborDate").ToString("M-d-yy")

                       })
                   }).ToList();

                }
                else if (interval.ToLower() == "week")
                {
                    laborHeadCount = dataTable.Rows.Cast<DataRow>()
                   .GroupBy(x => new { ManagementName = x["ManagementName"], Assembly = x["HeadcountType"], ShiftDetails = x["ShiftDetails"] })
                   .Select(x => new
                   {
                       ManagementName = x.Key,
                       WeeklyDates = x.Select(y => new
                       {
                           Headcount = y.Field<decimal?>("Headcount"),
                           LaborDate = y.Field<DateTime>("LaborDate").ToString("M-d-yy")

                       })
                   }).ToList();
                }

                else if (interval.ToLower() == "month")
                {
                    laborHeadCount = dataTable.Rows.Cast<DataRow>()
                   .GroupBy(x => new { ManagementName = x["ManagementName"], Assembly = x["HeadcountType"], ShiftDetails = x["ShiftDetails"] })
                   .Select(x => new
                   {
                       ManagementName = x.Key,
                       WeeklyDates = x.Select(y => new
                       {
                           Headcount = y.Field<decimal?>("Headcount"),
                           LaborDate = y.Field<DateTime>("MonthStart").ToString("M-d-yy")

                       })
                   }).ToList();
                }

                laborHeadCountList = Newtonsoft.Json.JsonConvert.SerializeObject(laborHeadCount);
                return laborHeadCountList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
       
        public string GetLaborLoanedOut(string connString, string interval, int plantID, string minDate, string maxDate ,string shiftDetails = null)
        {
            try
            {
                dataTable = new DataTable();
                SqlParameter[] param = { new SqlParameter("@Interval", interval),
                 new SqlParameter("@ShiftDetails", shiftDetails),
                   new SqlParameter("@plantID", plantID),
                   new SqlParameter("@minDate", minDate),
                   new SqlParameter("@maxDate", maxDate)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetLoanedOutV2", param);

                string laborLoanedList = null;
                dynamic laborLoaned = null;
                if (interval.ToLower() == "daily")
                {

                    laborLoaned = dataTable.Rows.Cast<DataRow>()
                    .GroupBy(x => new { Department = x["Department"], ShiftDetails = x["ShiftDetails"] })
                    .Select(x => new
                    {
                        Department = x.Key,
                        WeeklyDates = x.Select(y => new
                        {
                            TotalAvailableHour = y.Field<decimal?>("TotalAvailableHour"),
                            LaborDate = y.Field<DateTime>("LaborDate").ToString("M-d-yy")

                        })
                    }).ToList();

                }
                else if (interval.ToLower() == "week")
                {
                    laborLoaned = dataTable.Rows.Cast<DataRow>()
                   .GroupBy(x => new { Department = x["Department"], ShiftDetails = x["ShiftDetails"] })
                   .Select(x => new
                   {
                       Department = x.Key,
                       WeeklyDates = x.Select(y => new
                       {
                           TotalAvailableHour = y.Field<decimal?>("TotalAvailableHour"),
                           WeekStart = y.Field<DateTime>("WeekStart").ToString("M-d-yy")

                       })
                   }).ToList();

                }

                else if (interval.ToLower() == "month")
                {
                    laborLoaned = dataTable.Rows.Cast<DataRow>()
                   .GroupBy(x => new { Department = x["Department"], ShiftDetails = x["ShiftDetails"] })
                   .Select(x => new
                   {
                       Department = x.Key,
                       WeeklyDates = x.Select(y => new
                       {
                           TotalAvailableHour = y.Field<decimal?>("TotalAvailableHour"),
                           WeekStart = y.Field<DateTime>("MonthStart").ToString("M-d-yy")

                       })
                   }).ToList();

                }

                laborLoanedList = Newtonsoft.Json.JsonConvert.SerializeObject(laborLoaned);
                return laborLoanedList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
   
        public string GetLaborOverTime(string connString, string interval, int plantID, string minDate, string maxDate, string shiftDetails = null)
        {
            try
            {
                dataTable = new DataTable();
                SqlParameter[] param = { new SqlParameter("@Interval", interval),
                    new SqlParameter("@ShiftDetails", shiftDetails),
                    new SqlParameter("@plantID", plantID),
                    new SqlParameter("@minDate", minDate ),
                    new SqlParameter("@maxDate", maxDate )
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetLaborOverTimeV2", param);

                string laborOverHoursList = null;
                dynamic laborOverHours = null;
                if (interval.ToLower() == "daily")
                {

                    laborOverHours = dataTable.Rows.Cast<DataRow>()
                    .GroupBy(x => new { ManagementName = x["ManagementName"], Assembly = x["Assembly"], ShiftDetails = x["ShiftDetails"] })
                    .Select(x => new
                    {
                        ManagementName = x.Key,
                        WeeklyDates = x.Select(y => new
                        {
                            TotalAvailableOvertimeHour = y.Field<decimal?>("TotalAvailableOvertimeHour"),
                            LaborDate = y.Field<DateTime?>("LaborDate")?.ToString("M-d-yy")

                        })
                    }).ToList();

                }
                else if (interval.ToLower() == "week")
                {
                    laborOverHours = dataTable.Rows.Cast<DataRow>()
                   .GroupBy(x => new { ManagementName = x["ManagementName"], Assembly = x["Assembly"], ShiftDetails = x["ShiftDetails"] })
                   .Select(x => new
                   {
                       ManagementName = x.Key,
                       WeeklyDates = x.Select(y => new
                       {
                           TotalAvailableOvertimeHour = y.Field<decimal?>("TotalAvailableOvertimeHour"),
                           WeekStart = y.Field<DateTime?>("WeekStart")?.ToString("M-d-yy")

                       })
                   }).ToList();

                }

                else if (interval.ToLower() == "month")
                {
                    laborOverHours = dataTable.Rows.Cast<DataRow>()
                   .GroupBy(x => new { ManagementName = x["ManagementName"], Assembly = x["Assembly"], ShiftDetails = x["ShiftDetails"] })
                   .Select(x => new
                   {
                       ManagementName = x.Key,
                       WeeklyDates = x.Select(y => new
                       {
                           TotalAvailableOvertimeHour = y.Field<decimal?>("TotalAvailableOvertimeHour"),
                           WeekStart = y.Field<DateTime?>("MonthStart")?.ToString("M-d-yy")

                       })
                   }).ToList();

                }


                laborOverHoursList = Newtonsoft.Json.JsonConvert.SerializeObject(laborOverHours);
                return laborOverHoursList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public string GetHeadCountSnapShot(string connString, int plantID, string minDate)
        {
            try
            {
                dataTable = new DataTable();
                SqlParameter[] param = {
                 new SqlParameter("@plantID", plantID),
                 new SqlParameter("@minDate", minDate)
                };
                dataTable = SqlHelper.GetDataTable(connString, "USPGetHeadCountSnapShotV2", param);
                dynamic totalLaborHour = dataTable.Rows.Cast<DataRow>()
                    .GroupBy(x => new { LaborDate = x["LaborDate"] })
                    .Select(x => new
                    {
                        DayName = x.Select(x => x.Field<string>("DayName")).Distinct(),
                        TotalLaborHour = x.Select(x => x.Field<decimal>("TotalLaborHour")).Distinct(),

                    }).ToList();

                string laborHeadCountSnapshotListjson = null;
                string laborHourjson = null;
                dynamic laborHeadCountSnapshot = null;


                laborHeadCountSnapshot = dataTable.Rows.Cast<DataRow>()
                    .GroupBy(x => new { DayShiftOnly = x["DayShiftOnly"] })
                    .Select(x => new
                    {
                        DayShiftOnly = x.Key,

                        WeeklyValues = x.Select(y => new
                        {

                            TotalAvailableHour = y.Field<decimal>("TotalAvailableHour"),
                            DayName = y.Field<string>("DayName"),

                        }),

                    }).ToList();



                laborHourjson = Newtonsoft.Json.JsonConvert.SerializeObject(totalLaborHour);
                laborHeadCountSnapshotListjson = Newtonsoft.Json.JsonConvert.SerializeObject(laborHeadCountSnapshot);

                var laborHour = JsonConvert.DeserializeObject(laborHourjson);
                var laborHeadCountSnapshotList = JsonConvert.DeserializeObject(laborHeadCountSnapshotListjson);

                var resultJson = Newtonsoft.Json.JsonConvert.SerializeObject(new { laborHour, laborHeadCountSnapshotList });

                return resultJson;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<Shifts> GetShiftType(string connString, int plantID)
        {
            try
            {
                dataTable = new DataTable();
                SqlParameter[] param = {
                 new SqlParameter("@plantID", plantID)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetShiftTypes", param);



                List<Shifts> shifts = null;

                shifts = dataTable.AsEnumerable().Select(dtRow => new Shifts()
                {


                    ShiftID = dtRow.Field<long?>("ShiftID"),
                    Description = dtRow.Field<string>("Description"),
                    ShortDescription = dtRow.Field<string>("ShortDescription"),
                    Compression = dtRow.Field<string>("Compression"),
                    DayShiftType = dtRow.Field<string>("SetDayShiftType"),
                    Time = dtRow.Field<string>("Time"),
                    Monday1 = dtRow.Field<int?>("Monday1"),
                    Tuesday1 = dtRow.Field<int?>("Tuesday1"),
                    Wednesday1 = dtRow.Field<int?>("Wednesday1"),
                    Thursday1 = dtRow.Field<int?>("Thursday1"),
                    Friday1 = dtRow.Field<int?>("Friday1"),
                    Saturday1 = dtRow.Field<int?>("Saturday1"),
                    Sunday1 = dtRow.Field<int?>("Sunday1"),
                    Monday2 = dtRow.Field<int?>("Monday2"),
                    Tuesday2 = dtRow.Field<int?>("Tuesday2"),
                    Wednesday2 = dtRow.Field<int?>("Wednesday2"),
                    Thursday2 = dtRow.Field<int?>("Thursday2"),
                    Friday2 = dtRow.Field<int?>("Friday2"),
                    Saturday2 = dtRow.Field<int?>("Saturday2"),
                    Sunday2 = dtRow.Field<int?>("Sunday2"),
                    ShiftStartTime = dtRow.Field<string>("ShiftSetStartTime"),
                    ShiftEndTime = dtRow.Field<string>("ShiftSetEndTime"),
                }).ToList();

                return shifts;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        //----------Update API ------------------------------
        public int UpdateManagementGroup(string connString, LaborManagementGroup laborManagementGroup)
        {
            var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            try
            {
                SqlParameter[] param = {
               new SqlParameter("@laborManagmentGroupID",laborManagementGroup.LaborManagmentGroupID),
                new SqlParameter("@managementName",laborManagementGroup.ManagementName),
                new SqlParameter("@efficencyFactor",laborManagementGroup.EfficencyFactor),
                new SqlParameter("@overtimeAllowance",laborManagementGroup.OvertimeAllowance),
                new SqlParameter("@utilizationTarget",laborManagementGroup.UtilizationTarget),
                new SqlParameter("@pTOPercentage",laborManagementGroup.PTOPercentage),
                outParam
            };

                return SqlHelper.ExecuteNonQuery(connString, "uspEditManagementGroup", param);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int UpdateBuildType(string connString, BuildTypeMultiplierView[] buildTypeMultiplier)
        {
            var resultCount = 0;
            var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            try
            {
                foreach (var items in buildTypeMultiplier)
                {
                    SqlParameter[] param = {
                new SqlParameter("@buildTypeID",items.BuildTypeID),
                new SqlParameter("@multiplierValue",items.MultiplierValue),
                new SqlParameter("@plantID",items.PlantID),
                 outParam

            };

                    resultCount = SqlHelper.ExecuteNonQuery(connString, "uspEditLaborMultiplier", param);
                }
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int UpdateProductManagmentMap(string connString, LabourManagementGroupMapping[] AD)
        {
            var resultCount = 0;
            var Count = 0;
            var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            try
            {
                foreach (var items in AD)
                {
                    SqlParameter[] param1 = {
               new SqlParameter("@laborManagmentGroupID", items.LaborManagmentGroupID),
               outParam
            };
                    Count = SqlHelper.ExecuteNonQuery(connString, "uspdeleteProductManagmentMap", param1);

                    foreach (var item in items.LaborMgmtGrpDetails)
                    {
                        SqlParameter[] param = {
                                            new SqlParameter("@laborManagmentGroupID", items.LaborManagmentGroupID),
                                            new SqlParameter("@productGroupID", item.ProductGroupID),
                                         
                   outParam

            };

                        resultCount = SqlHelper.ExecuteNonQuery(connString, "uspEditProductManagmentMap", param);
                    }
                }
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }

        }
       
        public int UpdateShift(string connString, Shifts[] shifts)
        {
            try
            {
                int count = 1;
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                foreach (var items in shifts)
                {
                    SqlParameter[] param = {
                new SqlParameter("@ShiftID",items.ShiftID),
                new SqlParameter("@ShortDescription",items.ShortDescription),
                new SqlParameter("@Comperession",items.Compression),
                new SqlParameter("@DayShiftType",items.DayShiftType),
                new SqlParameter("@Description",items.Description),
                new SqlParameter("@HoursPerDay",items.HoursPerDay),

                 new SqlParameter("@Monday", items.Monday1),
                new SqlParameter("@Tuesday", items.Tuesday1),
                new SqlParameter("@Wednesday", items.Wednesday1),
                new SqlParameter("@Thursday", items.Thursday1),
                new SqlParameter("@Friday", items.Friday1),
                new SqlParameter("@Saturday", items.Saturday1),
                new SqlParameter("@Sunday", items.Sunday1),
                new SqlParameter("@ShiftStartTime", items.ShiftStartTime),
                new SqlParameter("@ShiftEndTime", items.ShiftEndTime),
                new SqlParameter("@weekNum", count),

                outParam
            };
                    resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateShift", param);
                    count = count + 1;
                }
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int UpdateLaborPool(string connString, UpdateLaborPoolView[] updateLaborPoolView)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                foreach (var items in updateLaborPoolView)
                {
                    SqlParameter[] param = {
                new SqlParameter("@laborManagmentGroupID",items.LaborManagmentGroupID),
                new SqlParameter("@Status",items.Status),
                new SqlParameter("@Department",items.Department),
                new SqlParameter("@DayShiftOnly",items.DayShiftOnly),
                outParam
            };
                    resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateLaborPool", param);
                }
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int UpdateAssemblyTechnician(string connString, LaborAssemblyTechnicianViewModel laborAssemblyTechnicianViewModel)
        {
            try
            {
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)

                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter[] param = {
                new SqlParameter("@AssembleyTest",laborAssemblyTechnicianViewModel.AssembleyTest),
                new SqlParameter("@Status",laborAssemblyTechnicianViewModel.Status),
                new SqlParameter("@ManagementGroup",laborAssemblyTechnicianViewModel.ManagementGroup),
                new SqlParameter("@shiftID",laborAssemblyTechnicianViewModel.ShiftID),
                new SqlParameter("@EffectiveDateString",laborAssemblyTechnicianViewModel.EffectiveDateString),
                new SqlParameter("@EndDateString",laborAssemblyTechnicianViewModel.EndDateString),
                new SqlParameter("@LoanDeptFromTo",laborAssemblyTechnicianViewModel.LoanDeptFromTo),
                 new SqlParameter("@plantID",laborAssemblyTechnicianViewModel.PlantID),
                new SqlParameter("@HeadCount",laborAssemblyTechnicianViewModel.HeadCount),
                outParam
          };

                return SqlHelper.ExecuteNonQueryNoOutParam(connString, "uspUpdateAssemblyTechnician", param);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int DeleteLaborPool(string connString, LaborAssemblyTechnicianViewModel laborAssemblyTechnicianViewModel)
        {
            try
            {
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)

                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter[] param = {

                new SqlParameter("@AssembleyTest",laborAssemblyTechnicianViewModel.AssembleyTest),
                new SqlParameter("@Status",laborAssemblyTechnicianViewModel.Status),
                new SqlParameter("@ManagementGroup",laborAssemblyTechnicianViewModel.ManagementGroup),
                new SqlParameter("@shiftID",laborAssemblyTechnicianViewModel.ShiftID),
                new SqlParameter("@LoanDeptFromTo",laborAssemblyTechnicianViewModel.LoanDeptFromTo),
                 new SqlParameter("@plantID",laborAssemblyTechnicianViewModel.PlantID),
                outParam
          };

                return SqlHelper.ExecuteNonQueryNoOutParam(connString, "uspDeleteLaborPool", param);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }

        }
    }
}
