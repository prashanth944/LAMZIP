﻿using LAM.PMPM.DAL;
using LAM.PMPM.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Text;
using System.Linq;
using LAM.PMPM.Model.ViewModel;
using System.Text.RegularExpressions;

namespace LAM.PMPM.BL
{
    public class MPSSchedule
    {
        DataTable dataTable;
        public string GetMPSSummary(string connString, string interval, int PlantID, string StartDate, int productionPlanID)
        {
            try
            {
                dataTable = new DataTable();
                DateTime LaborDate;
                SqlParameter[] param = { new SqlParameter("@Interval", interval),
                        new SqlParameter("@plantID", PlantID),
                        new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                        new SqlParameter("@ProductionPlanID", productionPlanID),
                        };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetScheduledSummaryWhatIf", param);
                SqlParameter[] param1 = { new SqlParameter("@Interval", interval),
                            new SqlParameter("@plantID", PlantID),
                            new SqlParameter("@ProductionPlanID", productionPlanID),
                            };
                DataTable dtDistinctDatedaily = new DataTable();
                dtDistinctDatedaily = SqlHelper.GetDataTable(connString, "uspGetSummaryDistinctDatedaily", param1);
                var DistinctDatedaily = (from x in dataTable.AsEnumerable()
                                         group x by (DateTime)x["LaborDate"] into g
                                         select g).ToList();

                for (int j = 0; j < dtDistinctDatedaily.Rows.Count; j++)
                {
                    var HeadcountType = dtDistinctDatedaily.Rows[j]["HeadcountType"].ToString();
                    for (int i = 0; i < DistinctDatedaily.Count; i++)
                    {
                        LaborDate = Convert.ToDateTime(DistinctDatedaily[i].Key);
                        bool contains = dataTable.AsEnumerable().Where(c => c.Field<string>("HeadcountType") == HeadcountType).Any(row => LaborDate == row.Field<DateTime?>("LaborDate"));
                        if (!contains)
                        {
                            DataRow dr = dataTable.NewRow();
                            dr["LaborDate"] = LaborDate; //string
                            dr["HeadcountType"] = HeadcountType; //string
                            dr["Headcount"] = 0; //string
                            dataTable.Rows.Add(dr);
                        }
                    }
                }

                List<MPSSummary> mpsSummary = null;
                var mpsSummarys = dataTable.Rows.Cast<DataRow>()
                .GroupBy(x => new { HeadcountType = x["HeadcountType"] })
                .OrderBy(x => x.Key.HeadcountType)
                .Select(x => new
                {
                    BayDetails = x.Key,
                    DailyWeeklyDates = x.Select(y => new
                    {
                        DailyDate = y.Field<DateTime>("LaborDate"),
                        DescriptionCount = y.Field<Int32>("Headcount")
                    })
                }).ToList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(mpsSummarys);
                return jsonString;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public List<ScheduleLaborHours> GetScheduleLaborhours(string connString, string interval, int PlantID, string StartDate, int productionPlanID)
        {
            try
            {
                dataTable = new DataTable();
                SqlParameter[] param = { new SqlParameter("@Interval", interval),
                    new SqlParameter("@planID", PlantID),
                    new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                    new SqlParameter("@ProductionPlanID", productionPlanID),};
                dataTable = SqlHelper.GetDataTable(connString, "uspGetLaborhoursForMPS", param);

                List<ScheduleLaborHours> scheduleLaborHours = null;
                if (interval.ToLower() == "daily")
                {
                    scheduleLaborHours = dataTable.AsEnumerable().Select(dtRow => new ScheduleLaborHours()
                    {
                        ManagementName = Convert.ToString(dtRow["ManagementName"]),
                        TotalAvailableHour = Convert.ToInt32(dtRow["TotalAvailableHour"]),
                        TotalConsumedHours = Convert.ToInt32(dtRow["TotalConsumedHours"]),
                        TotalRemainingHour = Convert.ToInt32(dtRow["TotalRemainingHour"]),
                        Assembly = Convert.ToChar(dtRow["Assembly"]),
                        LaborDate = Convert.ToDateTime(dtRow["LaborDate"]),
                    }).ToList();
                }
                else if (interval.ToLower() == "week")
                {
                    scheduleLaborHours = dataTable.AsEnumerable().Select(dtRow => new ScheduleLaborHours()
                    {
                        ManagementName = Convert.ToString(dtRow["ManagementName"]),
                        TotalAvailableHour = Convert.ToInt32(dtRow["TotalAvailableHour"]),
                        TotalConsumedHours = Convert.ToInt32(dtRow["TotalConsumedHours"]),
                        TotalRemainingHour = Convert.ToInt32(dtRow["TotalRemainingHour"]),
                        Assembly = Convert.ToChar(dtRow["Assembly"]),
                        LaborDate = Convert.ToDateTime(dtRow["LaborDate"]),
                        WeekStart = Convert.ToDateTime(dtRow["WeekStart"]),
                    }).ToList();
                }
                else if (interval.ToLower() == "month")
                {
                    scheduleLaborHours = dataTable.AsEnumerable().Select(dtRow => new ScheduleLaborHours()
                    {
                        ManagementName = Convert.ToString(dtRow["ManagementName"]),
                        TotalAvailableHour = Convert.ToInt32(dtRow["TotalAvailableHour"]),
                        TotalConsumedHours = Convert.ToInt32(dtRow["TotalConsumedHours"]),
                        TotalRemainingHour = Convert.ToInt32(dtRow["TotalRemainingHour"]),
                        Assembly = Convert.ToChar(dtRow["Assembly"]),
                        LaborDate = Convert.ToDateTime(dtRow["LaborDate"]),
                        WeekStart = Convert.ToDateTime(dtRow["MonthStart"]),
                    }).ToList();
                }
                else if (interval.ToLower() == "quarter")
                {
                    scheduleLaborHours = dataTable.AsEnumerable().Select(dtRow => new ScheduleLaborHours()
                    {
                        ManagementName = Convert.ToString(dtRow["ManagementName"]),
                        TotalAvailableHour = Convert.ToInt32(dtRow["TotalAvailableHour"]),
                        TotalConsumedHours = Convert.ToInt32(dtRow["TotalConsumedHours"]),
                        TotalRemainingHour = Convert.ToInt32(dtRow["TotalRemainingHour"]),
                        Assembly = Convert.ToChar(dtRow["Assembly"]),
                        LaborDate = Convert.ToDateTime(dtRow["LaborDate"]),
                        WeekStart = Convert.ToDateTime(dtRow["QuarterStart"]),
                    }).ToList();
                }
                else if (interval.ToLower() == "annual")
                {
                    scheduleLaborHours = dataTable.AsEnumerable().Select(dtRow => new ScheduleLaborHours()
                    {
                        ManagementName = Convert.ToString(dtRow["ManagementName"]),
                        TotalAvailableHour = Convert.ToInt32(dtRow["TotalAvailableHour"]),
                        TotalConsumedHours = Convert.ToInt32(dtRow["TotalConsumedHours"]),
                        TotalRemainingHour = Convert.ToInt32(dtRow["TotalRemainingHour"]),
                        Assembly = Convert.ToChar(dtRow["Assembly"]),
                        LaborDate = Convert.ToDateTime(dtRow["LaborDate"]),
                        WeekStart = Convert.ToDateTime(dtRow["AannualStart"]),
                    }).ToList();
                }

                return scheduleLaborHours;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public string GetMPSBay(string connString, string interval, int PlantID, string StartDate, int productionPlanID)
        {

            try
            {
                DataTable dataTable;
                SqlParameter[] param = {
                new SqlParameter("@Interval",interval),
                    new SqlParameter("@planID", PlantID),
                    new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                    new SqlParameter("@ProductionPlanID", productionPlanID),
            };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetBaysForMPS", param);

                string bayScheduleList = null;
                dynamic baySchedule = null;
                baySchedule = dataTable.Rows.Cast<DataRow>()
                .GroupBy(x => new
                {
                    Product_Type = x["ProductName"],
                    BayTypeName = x["BayTypeName"],
                    BuildingName = x["BuildingName"],
                    FCID = x["FCID"],
                    PilotSerialNumber = x["PilotSerialNumber"],
                    Customer = x["Customer"],
                    BuildName = x["BuildName"],
                    ToolTypeName = x["ToolTypeName"],

                })
                 .Select(x => new
                 {
                     ProductName = x.Key,
                     WeeklyDates = x.Select(y => new
                     {
                         TotalBaysAvailablity = y.Field<Int32>("TotalBaysAvailablity"),
                         TotalConsumed = y.Field<Int32>("TotalConsumed"),
                         TotalRemaining = y.Field<Int32>("TotalRemaining"),
                         BayDate = y.Field<DateTime>("BayDate")
                     })
                 }).ToList();

                bayScheduleList = Newtonsoft.Json.JsonConvert.SerializeObject(baySchedule);
                return bayScheduleList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public string GetMPSTotalBay(string connString, string interval, int PlantID, string StartDate, int productionPlanID)
        {

            try
            {
                DataTable dataTable;
                SqlParameter[] param = {
                new SqlParameter("@Interval",interval),
                    new SqlParameter("@planID", PlantID),
                    new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                    new SqlParameter("@ProductionPlanID", productionPlanID),
             };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetTotalBaysForMPS", param);

                string bayScheduleList = null;
                dynamic baySchedule = null;

                baySchedule = dataTable.Rows.Cast<DataRow>()
                .GroupBy(x => new
                {
                    Product_Type = x["ProductName"],
                    BayTypeName = x["BayTypeName"],
                    BuildingName = x["BuildingName"],
                    FCID = x["FCID"],
                    PilotSerialNumber = x["PilotSerialNumber"],
                    Customer = x["Customer"],
                    BuildName = x["BuildName"],
                    ToolTypeName = x["ToolTypeName"],

                })
                 .Select(x => new
                 {
                     ProductName = x.Key,
                     WeeklyDates = x.Select(y => new
                     {
                         TotalBaysAvailablity = y.Field<Int32>("TotalBaysAvailablity"),
                         BayDate = y.Field<DateTime>("BayDate")
                     })
                 }).ToList();

                bayScheduleList = Newtonsoft.Json.JsonConvert.SerializeObject(baySchedule);
                return bayScheduleList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public string GetMPSLabor(string connString, string interval, int PlantID, string StartDate, int productionPlanID)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = {
                new SqlParameter("@Interval",interval),
                    new SqlParameter("@planID", PlantID),
                    new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                    new SqlParameter("@ProductionPlanID", productionPlanID),
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetLaborhoursForMPS", param);
                string laborScheduleList = null;
                var laborSchedule = dataTable.Rows.Cast<DataRow>()
                .GroupBy(x => new
                {
                    ManagementName = x["ManagementName"],
                    ProductName = x["ProductName"],
                    Laborgroup = x["Laborgroup"],
                    FCID = x["FCID"],
                    PilotSerialNumber = x["PilotSerialNumber"],
                    Customer = x["Customer"],
                    BuildName = x["BuildName"],
                    ToolTypeName = x["ToolTypeName"],
                })
                .Select(x => new
                {
                    ProductName = x.Key,
                    WeeklyDates = x.Select(y => new
                    {
                        TotalAvailableHour = y.Field<decimal>("TotalAvailableHour"),
                        TotalConsumedHour = y.Field<Int32>("TotalConsumedHour"),
                        TotalRemainingHour = y.Field<decimal>("TotalRemainingHour"),
                        LaborDate = y.Field<DateTime>("LaborDate"),
                        SumAvailableHour = y.Field<decimal>("SumAvailableHour"),
                        SumConsumedHour = y.Field<Int32>("SumConsumedHour"),
                        SumRemainingHour = y.Field<decimal>("SumRemainingHour"),
                    })
                }).ToList();
                laborScheduleList = Newtonsoft.Json.JsonConvert.SerializeObject(laborSchedule);
                return laborScheduleList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int UpdateEditStatus(string connString, ProductionPlan productionPlan, int productionplanid)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                new SqlParameter("@ProductionPlanId", productionplanid),
                new SqlParameter("@IsBeingEditedById",  productionPlan.IsBeingEditedById),
                new SqlParameter("@IsBeingEdited",  productionPlan.IsBeingEdited),
                outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateProductionPlanEditedBy", param);


                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public string GetMPSTotalLabor(string connString, string interval, int PlantID, string StartDate, int productionPlanID)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = {
                new SqlParameter("@Interval",interval),
                    new SqlParameter("@planID", PlantID),
                    new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                    new SqlParameter("@ProductionPlanID", productionPlanID),
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetTotalLaborhoursForMPS", param);
                string laborScheduleList = null;
                var laborSchedule = dataTable.Rows.Cast<DataRow>()
                .GroupBy(x => new
                {
                    ManagementName = x["ManagementName"],
                    ProductName = x["ProductName"],
                    Laborgroup = x["Laborgroup"],
                    FCID = x["FCID"],
                    PilotSerialNumber = x["PilotSerialNumber"],
                    Customer = x["Customer"],
                    BuildName = x["BuildName"],
                    ToolTypeName = x["ToolTypeName"],
                })
                .Select(x => new
                {
                    ProductName = x.Key,
                    WeeklyDates = x.Select(y => new
                    {
                        TotalAvailableHour = y.Field<decimal>("TotalAvailableHour"),
                        LaborDate = y.Field<DateTime>("LaborDate"),
                        SumAvailableHour = y.Field<decimal>("SumAvailableHour"),
                    })
                }).ToList();
                laborScheduleList = Newtonsoft.Json.JsonConvert.SerializeObject(laborSchedule);
                return laborScheduleList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public string GetScheduleFixture(string connString, string interval, int PlantID, string StartDate, int productionPlanID)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = {
                new SqlParameter("@Interval",interval),
                    new SqlParameter("@planID", PlantID),
                    new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
            };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetScheduleFixture", param);


                string fixtureScheduleList = null;
                dynamic fixtureSchedule = null;
                if (interval.ToLower() == "daily")
                {


                    fixtureSchedule = dataTable.Rows.Cast<DataRow>()
                   .GroupBy(x => new { FixtureName = x["FixtureName"] })
                   .Select(x => new
                   {
                       FixtureName = x.Key,
                       WeeklyDates = x.Select(y => new
                       {
                           FixtureCount = y.Field<Int32>("FixtureCount"),
                           FixtureDate = y.Field<DateTime>("FixtureDate")

                       })
                   }).ToList();

                }
                else if (interval.ToLower() == "week")
                {

                    fixtureSchedule = dataTable.Rows.Cast<DataRow>()
                 .GroupBy(x => new { FixtureName = x["FixtureName"] })
                 .Select(x => new
                 {
                     FixtureName = x.Key,
                     WeeklyDates = x.Select(y => new
                     {
                         FixtureCount = y.Field<Int32>("FixtureCount"),
                         WeekStart = y.Field<DateTime>("WeekStart")

                     })
                 }).ToList();

                }
                fixtureScheduleList = Newtonsoft.Json.JsonConvert.SerializeObject(fixtureSchedule);
                return fixtureScheduleList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public string GetMPSModuleData(string connString, string interval, int PlantID, string StartDate, int productionPlanID)
        {
            try
            {
                DataTable dataTable;
                DateTime Datedaily;
                string MPSDataList = null;
                SqlParameter[] param = {
                            new SqlParameter("@Interval",interval),
                            new SqlParameter("@planID",PlantID),
                            new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                            new SqlParameter("@ProductionPlanID", productionPlanID),
                            };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetMPSData", param);
                var DistinctList = (from x in dataTable.AsEnumerable()
                                    group x by (DateTime)x["Datedaily"] into g
                                    select g).ToList();
                DataTable copyDataTable = copyDataTable = dataTable.Copy();
                string[] ColumnsToBeDeleted = { "Datedaily", "baysbuilhours", "baysbuilhoursOnHover", "ModuleProcessID" };
                foreach (string ColName in ColumnsToBeDeleted)
                {
                    if (copyDataTable.Columns.Contains(ColName))
                        copyDataTable.Columns.Remove(ColName);
                }

                if (copyDataTable.Rows.Count > 0)
                {
                    DataTable DistinctListWithoutDateDaily = copyDataTable.AsEnumerable().Distinct(DataRowComparer.Default).CopyToDataTable<DataRow>();

                    for (int j = 0; j < DistinctListWithoutDateDaily.Rows.Count; j++)
                    {
                        var PilotProductID = Convert.ToInt32(DistinctListWithoutDateDaily.Rows[j]["PilotProductID"]);
                        for (int i = 0; i < DistinctList.Count; i++)
                        {
                            Datedaily = Convert.ToDateTime(DistinctList[i].Key);
                            bool contains = dataTable.AsEnumerable().Where(c => c.Field<Int64?>("PilotProductID") == PilotProductID).Any(row => Datedaily == row.Field<DateTime?>("Datedaily"));
                            if (!contains)
                            {
                                DataRow dr = dataTable.NewRow();
                                dr["Datedaily"] = Datedaily; //string
                                dr["PilotProductID"] = PilotProductID; //string
                                dr["SalesPriority"] = DistinctListWithoutDateDaily.Rows[j]["SalesPriority"];
                                dr["FCID"] = DistinctListWithoutDateDaily.Rows[j]["FCID"];
                                dr["PilotSerialNumber"] = DistinctListWithoutDateDaily.Rows[j]["PilotSerialNumber"];
                                dr["PilotRisk"] = DistinctListWithoutDateDaily.Rows[j]["PilotRisk"];
                                dr["PlannedRiskLevel"] = DistinctListWithoutDateDaily.Rows[j]["PlannedRiskLevel"];
                                dr["AlreadyScheduled"] = DistinctListWithoutDateDaily.Rows[j]["AlreadyScheduled"];
                                dr["DayShiftOnly"] = DistinctListWithoutDateDaily.Rows[j]["DayShiftOnly"];
                                dr["NoCapacity"] = DistinctListWithoutDateDaily.Rows[j]["NoCapacity"];
                                dr["RecordType"] = DistinctListWithoutDateDaily.Rows[j]["RecordType"];
                                dr["RevenueType"] = DistinctListWithoutDateDaily.Rows[j]["RevenueType"];
                                dr["ToolTypeName"] = DistinctListWithoutDateDaily.Rows[j]["ToolTypeName"];
                                dr["ToolTypeID"] = DistinctListWithoutDateDaily.Rows[j]["ToolTypeID"];
                                dr["ProductName"] = DistinctListWithoutDateDaily.Rows[j]["ProductName"];
                                dr["BuildTypeID"] = DistinctListWithoutDateDaily.Rows[j]["BuildTypeID"];
                                dr["BuildName"] = DistinctListWithoutDateDaily.Rows[j]["BuildName"];
                                dr["CustomerID"] = DistinctListWithoutDateDaily.Rows[j]["CustomerID"];
                                dr["CompleteATP"] = DistinctListWithoutDateDaily.Rows[j]["CompleteATP"];
                                dr["ModuleProcessIdForSubassembly"] = DistinctListWithoutDateDaily.Rows[j]["ModuleProcessIdForSubassembly"];
                                dr["SubassemblyBuildHours"] = DistinctListWithoutDateDaily.Rows[j]["SubassemblyBuildHours"];
                                dr["ModuleProcessIdForIntegration"] = DistinctListWithoutDateDaily.Rows[j]["ModuleProcessIdForIntegration"]; dr["ModuleProcessIdForIntegration"] = DistinctListWithoutDateDaily.Rows[j]["ModuleProcessIdForIntegration"];
                                dr["IntegrationBuildHours"] = DistinctListWithoutDateDaily.Rows[j]["IntegrationBuildHours"];
                                dr["ModuleProcessIdForTest"] = DistinctListWithoutDateDaily.Rows[j]["ModuleProcessIdForTest"];
                                dr["TestBuildHours"] = DistinctListWithoutDateDaily.Rows[j]["TestBuildHours"];
                                dr["ModuleProcessIdForPostTest"] = DistinctListWithoutDateDaily.Rows[j]["ModuleProcessIdForPostTest"];
                                dr["PostTestBuildHours"] = DistinctListWithoutDateDaily.Rows[j]["PostTestBuildHours"];
                                dr["TotalLaborHour"] = DistinctListWithoutDateDaily.Rows[j]["TotalLaborHour"];
                                dr["EarliestStartDate"] = DistinctListWithoutDateDaily.Rows[j]["EarliestStartDate"];
                                dr["MaterialReadiness"] = DistinctListWithoutDateDaily.Rows[j]["MaterialReadiness"];
                                dr["POABOMReleaseDate"] = DistinctListWithoutDateDaily.Rows[j]["POABOMReleaseDate"];
                                dr["TransitionDate"] = DistinctListWithoutDateDaily.Rows[j]["TransitionDate"];
                                dr["LPRPlannedLaunchP09"] = DistinctListWithoutDateDaily.Rows[j]["LPRPlannedLaunchP09"];
                                dr["TransitionDate"] = DistinctListWithoutDateDaily.Rows[j]["TransitionDate"];
                                dr["ProjectedLaunch"] = DistinctListWithoutDateDaily.Rows[j]["ProjectedLaunch"];
                                dr["ActualLaunch"] = DistinctListWithoutDateDaily.Rows[j]["ActualLaunch"];
                                dr["CommitLaunch"] = DistinctListWithoutDateDaily.Rows[j]["CommitLaunch"];
                                dr["CommittedIntegrationStart"] = DistinctListWithoutDateDaily.Rows[j]["CommittedIntegrationStart"];
                                dr["CommittedTestStart"] = DistinctListWithoutDateDaily.Rows[j]["CommittedTestStart"];
                                dr["CommitedManufacturingComplete"] = DistinctListWithoutDateDaily.Rows[j]["CommitedManufacturingComplete"];
                                dr["PilotManufacturingCommitedShipDate"] = DistinctListWithoutDateDaily.Rows[j]["PilotManufacturingCommitedShipDate"];
                                dr["CustomerRequestDate"] = DistinctListWithoutDateDaily.Rows[j]["CustomerRequestDate"];
                                dr["CRDEsc"] = DistinctListWithoutDateDaily.Rows[j]["CRDEsc"];
                                dr["CRDGapDays"] = DistinctListWithoutDateDaily.Rows[j]["CRDGapDays"];
                                dr["SalesOpsRequestDate"] = DistinctListWithoutDateDaily.Rows[j]["SalesOpsRequestDate"];
                                dr["TargetShipDate"] = DistinctListWithoutDateDaily.Rows[j]["TargetShipDate"];
                                dr["ManufacturingCommitedShipDate"] = DistinctListWithoutDateDaily.Rows[j]["ManufacturingCommitedShipDate"];
                                dr["Note"] = DistinctListWithoutDateDaily.Rows[j]["Note"];
                                dr["BEN"] = DistinctListWithoutDateDaily.Rows[j]["BEN"];
                                dr["POM"] = DistinctListWithoutDateDaily.Rows[j]["POM"];
                                dr["ActualDMRF"] = DistinctListWithoutDateDaily.Rows[j]["ActualDMRF"];
                                dr["PlannedDMRF"] = DistinctListWithoutDateDaily.Rows[j]["PlannedDMRF"];
                                dr["buildStyleName"] = DistinctListWithoutDateDaily.Rows[j]["buildStyleName"];
                                dr["ProjectedIntegrationStart"] = DistinctListWithoutDateDaily.Rows[j]["ProjectedIntegrationStart"];
                                dr["ProjectedTestStart"] = DistinctListWithoutDateDaily.Rows[j]["ProjectedTestStart"];
                                dr["ProjectedTestComplete"] = DistinctListWithoutDateDaily.Rows[j]["ProjectedTestComplete"];
                                dr["ProjectedManufacturingComplete"] = DistinctListWithoutDateDaily.Rows[j]["ProjectedManufacturingComplete"];
                                dr["ModuleProcessID"] = 0; //string
                                dr["baysbuilhours"] = "/";
                                dr["baysbuilhoursOnHover"] = ""; //string
                                dr["CapacityPlanningColor"] = DistinctListWithoutDateDaily.Rows[j]["CapacityPlanningColor"];
                                dr["PlanofRecord"] = DistinctListWithoutDateDaily.Rows[j]["PlanofRecord"];
                                dr["T09Comment"] = DistinctListWithoutDateDaily.Rows[j]["T09Comment"];
                                dr["ScheduleStatus"] = DistinctListWithoutDateDaily.Rows[j]["ScheduleStatus"];
                                dr["ScheduleStatusId"] = DistinctListWithoutDateDaily.Rows[j]["ScheduleStatusId"];
                                dataTable.Rows.Add(dr);
                            }
                        }
                    }
                    var MPSData = dataTable.Rows.Cast<DataRow>()
                    .OrderBy(r => r.Field<DateTime>("Datedaily")).GroupBy(x => new
                    {
                        PilotProductID = x["PilotProductID"],
                        SalesPriority = x["SalesPriority"],
                        FCID = x["FCID"],
                        PilotSerialNumber = x["PilotSerialNumber"],
                        PilotRisk = x["PilotRisk"],
                        PlannedRiskLevel = x["PlannedRiskLevel"],
                        AlreadyScheduled = x["AlreadyScheduled"],
                        DayShiftOnly = x["DayShiftOnly"],
                        NoCapacity = x["NoCapacity"],
                        RecordType = x["RecordType"],
                        RevenueType = x["RevenueType"],
                        ToolTypeName = x["ToolTypeName"],
                        ToolTypeID = x["ToolTypeID"],
                        ProductName = x["ProductName"],
                        BuildTypeID = x["BuildTypeID"],
                        BuildName = x["BuildName"],
                        CustomerID = x["CustomerID"],
                        CompleteATP = x["CompleteATP"],
                        ModuleProcessIdForSubassembly = x["ModuleProcessIdForSubassembly"],
                        SubassemblyBuildHours = x["SubassemblyBuildHours"],
                        ModuleProcessIdForIntegration = x["ModuleProcessIdForIntegration"],
                        IntegrationBuildHours = x["IntegrationBuildHours"],
                        ModuleProcessIdForTest = x["ModuleProcessIdForTest"],
                        TestBuildHours = x["TestBuildHours"],
                        ModuleProcessIdForPostTest = x["ModuleProcessIdForPostTest"],
                        PostTestBuildHours = x["PostTestBuildHours"],
                        TotalLaborHour = x["TotalLaborHour"],
                        EarliestStartDate = x["EarliestStartDate"],
                        MaterialReadiness = x["MaterialReadiness"],
                        POABOMReleaseDate = x["POABOMReleaseDate"],
                        TransitionDate = x["TransitionDate"],
                        LPRPlannedLaunchP09 = x["LPRPlannedLaunchP09"],
                        ProjectedLaunch = x["ProjectedLaunch"],
                        ActualLaunch = x["ActualLaunch"],
                        CommitLaunch = x["CommitLaunch"],
                        CommittedIntegrationStart = x["CommittedIntegrationStart"],
                        CommittedTestStart = x["CommittedTestStart"],
                        CommitedManufacturingComplete = x["CommitedManufacturingComplete"],
                        PilotManufacturingCommitedShipDate = x["PilotManufacturingCommitedShipDate"],
                        CustomerRequestDate = x["CustomerRequestDate"],
                        CRDEsc = x["CRDEsc"],
                        CRDGapDays = x["CRDGapDays"],
                        SalesOpsRequestDate = x["SalesOpsRequestDate"],
                        TargetShipDate = x["TargetShipDate"],
                        ManufacturingCommitedShipDate = x["ManufacturingCommitedShipDate"],
                        Note = x["Note"],
                        BEN = x["BEN"],
                        POM = x["POM"],
                        ActualDMRF = x["ActualDMRF"],
                        PlannedDMRF = x["PlannedDMRF"],
                        buildStyleName = x["buildStyleName"],
                        ProjectedIntegrationStart = x["ProjectedIntegrationStart"],
                        ProjectedTestStart = x["ProjectedTestStart"],
                        ProjectedTestComplete = x["ProjectedTestComplete"],
                        ProjectedManufacturingComplete = x["ProjectedManufacturingComplete"],
                        CapacityPlanningColor = x["CapacityPlanningColor"],
                        PlanofRecord = x["PlanofRecord"],
                        T09Comment = x["T09Comment"],
                        ScheduleStatus = x["ScheduleStatus"],
                        ScheduleStatusId = x["ScheduleStatusId"]
                    })
                    .Select(x => new
                    {
                        ProductName = x.Key,
                        BuildHoursDates = x.Select(y => new
                        {
                            baysbuilhours = y.Field<string>("baysbuilhours"),
                            baysbuilhoursOnHover = y.Field<string>("baysbuilhoursOnHover"),
                            ModuleProcessID = y.Field<Int32>("ModuleProcessID"),
                            Datedaily = y.Field<DateTime>("Datedaily")
                        })
                    }).ToList();

                    MPSDataList = Newtonsoft.Json.JsonConvert.SerializeObject(MPSData);
                }
                return MPSDataList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int UpdateMPSModuleData(string connString, ModulesSummary[] editMPSModuleData)
        {
            try
            {



                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                foreach (var items in editMPSModuleData)
                {
                    foreach (var r in items.ScheduleBuildHours)
                    {
                        if (r != null)
                        {
                            if (r.Baysbuilhours != "T" && r.Baysbuilhours != null)
                            {
                                var BaysRequired = r.Baysbuilhours.Split('/')[0];
                                var LaborBuildHours = r.Baysbuilhours.Split('/')[1] != "" ? r.Baysbuilhours.Split('/')[1] : "0";
                                SqlParameter[] parameters = {
                                    new SqlParameter("@interval",r.Interval),
                                    new SqlParameter("@pilotProductID",r.PilotProductID),
                                    new SqlParameter("@moduleprocessID",r.ModuleProcessID),
                                    new SqlParameter("@dateDaily",r.Datedaily),
                                    new SqlParameter("@baysRequired",Convert.ToInt32(BaysRequired)),
                                    new SqlParameter("@laborBuildHours",Convert.ToDecimal(LaborBuildHours)),
                                    new SqlParameter("@ProductionPlanID",r.ProductionPlanID),
                                    };
                                SqlHelper.ExecuteNonQueryNoOutParam(connString, "uspUpdateMPSBaysLaborDataDateWise", parameters);
                            }

                        }
                    }

                    SqlParameter[] param = {
                            new SqlParameter("@pilotProductID",items.PilotProductID),
                            new SqlParameter("@pilotSerialNumber",items.PilotSerialNumber),
                            new SqlParameter("@salesPriority",items.SalesPriority),
                            new SqlParameter("@buildTypeID",items.BuildTypeID),
                            new SqlParameter("@toolTypeID",items.ToolTypeID),
                            new SqlParameter("@buildName",items.BuildTypeName),
                            new SqlParameter("@toolTypeName",items.ToolTypeName),
                            new SqlParameter("@PilotRisk",items.PilotRisk),
                            new SqlParameter("@plannedRiskLevel",items.PlannedRiskLevel),
                            new SqlParameter("@earliestallowedlaunch",items.EarliestStartDate),
                            new SqlParameter("@customer",items.CustomerID),
                            new SqlParameter("@completeATP",items.CompleteATP),
                            new SqlParameter("@ModuleProcessIdForSubassembly",items.ModuleIdSubassembly),
                            new SqlParameter("@ModuleProcessIdForIntegration",items.ModuleIdIntegration),
                            new SqlParameter("@ModuleProcessIdForTest",items.ModuleIdTest),
                            new SqlParameter("@ModuleProcessIdForPostTest",items.ModuleIdPostTest),
                            new SqlParameter("@commitLaunch",items.CommitLaunch),
                            new SqlParameter("@commitIntegrationStart",items.CommitIntegrationStart),
                            new SqlParameter("@commitTestStart",items.CommitTestStart),
                            new SqlParameter("@commitManufacturingComplete",items.CommitManufacturingComplete),
                            new SqlParameter("@noCapacity",items.NoCapacity),
                            new SqlParameter("@notes",items.Notes),
                            new SqlParameter("@crdEsc",items.CRDEsc),
                            new SqlParameter("@ManufacturingCommitedShipDate",items.ManufacturingCommitedShipDate),
                            new SqlParameter("@PilotManufacturingCommitedShipDate",items.PilotManufacturingCommitedShipDate),
                            new SqlParameter("@PlanofRecord", items.PlanofRecord),
                            new SqlParameter("@ProductionPlanID",items.ProductionPlanID),
                            new SqlParameter("@ModifiedBy",items.ModifiedBy),
                            new SqlParameter("@ModifiedOn", items.ModifiedOn),
                            new SqlParameter("@ScheduleStatusId", items.ScheduleStatusId),
                            outParam
                            };
                    resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateMPSData", param);
                }
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<ScheduleCapacity> GetMPSDatePicker(string connString, int plantID, int productionPlanID)
        {
            try
            {
                dataTable = new DataTable();
                SqlParameter[] param = {
                    new SqlParameter("@plantID",plantID),
                    new SqlParameter("@ProductionPlanID", productionPlanID),
                    };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetMPSDatePicker", param);
                List<ScheduleCapacity> ScheduleDatepicker = dataTable.AsEnumerable().Select(y => new ScheduleCapacity()
                {
                    MinEarliestStartDate = y.Field<DateTime?>("MinEarliestStartDate"),
                    MaxProjectedDate = y.Field<DateTime?>("MaxProjectedDate"),
                }).ToList();
                return ScheduleDatepicker;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<SchedulesViewModel> GetPORProductionPlanID(string connString, int plantId)
        {
            dataTable = new DataTable();
            SqlParameter[] param = {
                    new SqlParameter("@plantID",plantId),
                    };
            List<SchedulesViewModel> ProductionPlanData = new List<SchedulesViewModel>();
            dataTable = SqlHelper.GetDataTable(connString, "uspGetProductionPlanID", param);
            try
            {
                ProductionPlanData = dataTable.AsEnumerable().Select(dtRow => new SchedulesViewModel()
                {
                    ProductionPlanID = dtRow.Field<long?>("ProductionPlanID"),
                    UserID = dtRow.Field<string>("UserID"),
                    ModifiedDate = dtRow.Field<DateTime?>("ModifiedDate"),
                    IsBeingEdited = dtRow.Field<bool?>("IsBeingEdited"),
                    EditedBy = dtRow.Field<string>("EditedBy"),
                    ModifiedBy = dtRow.Field<string>("ModifiedBy")
                }).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            return ProductionPlanData;
        }

        public List<GanttChartViewModel> GetGanttChartData(string connString, long plantID, bool inWIP, long productionPlanID)
        {
            DataTable dataTable;
            SqlParameter[] param = {
                new SqlParameter("@plantID", plantID),
                new SqlParameter("@inWIP", inWIP),
                new SqlParameter("@productionPlanID", productionPlanID)

            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetGanttChartData", param);

            List<GanttChartViewModel> ganttChartData = dataTable.AsEnumerable().Select(dtRow => new GanttChartViewModel()
            {
                PilotProductID = dtRow.Field<long?>("PilotProductID"),
                FCID = dtRow.Field<string>("FCID"),
                PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                BEN = dtRow.Field<string>("BEN"),
                FremontID = dtRow.Field<long?>("FremontID"),
                LPRID = dtRow.Field<long?>("LPRID"),
                ProductionStatus = dtRow.Field<string>("ProductionStatus"),
                PilotToolType = dtRow.Field<string>("PilotToolType"),
                Customer = dtRow.Field<string>("Customer"),
                PriorityDate = dtRow.Field<DateTime?>("PriorityDate"),
                NoCapacity = dtRow.Field<bool?>("NoCapacity"),
                RecordType = dtRow.Field<string>("RecordType"),
                RevenueCode = dtRow.Field<string>("RevenueCode"),
                BuildTypeID = dtRow.Field<long?>("BuildTypeID"),
                ToolTypeID = dtRow.Field<long?>("ToolTypeID"),
                ProductGroupID = dtRow.Field<long?>("ProductGroupID"),
                BuildTypeName = dtRow.Field<string>("BuildTypeName"),
                ToolTypeName = dtRow.Field<string>("ToolTypeName"),
                ProductGroupName = dtRow.Field<string>("ProductGroupName"),

                Building = dtRow.Field<long?>("BuildingID"),
                SalesOrderNumber = dtRow.Field<string>("SalesOrderNumber"),
                SalesOrder = dtRow.Field<string>("SalesOrder"),
                BOMNumber = dtRow.Field<int?>("BOMNumber"),
                DayShiftOnly = dtRow.Field<bool?>("DayShiftOnly"),
                BuildStyleId = dtRow.Field<int?>("BuildStyleId"),
                BuildScheduleId = dtRow.Field<int?>("BuildScheduleId"),

                POM = dtRow.Field<string>("POM"),


                CRDEsc = dtRow.Field<bool?>("CRDEsc"),
                SalesPriority = dtRow.Field<string>("SalesPriority"),

                PurchaseOrderNumber = dtRow.Field<string>("PurchaseOrderNumber"),
                PilotRisk = dtRow.Field<string>("PilotRisk"),
                LPRPercComplete = dtRow.Field<string>("LPRPercComplete"),
                InWIP = dtRow.Field<bool?>("InWIP"),
                PlannedRiskLevel = dtRow.Field<string>("PlannedRiskLevel"),
                Status = dtRow.Field<string>("Status"),
                PlantID = dtRow.Field<long?>("PlantID"),

                ProjectedMRPP08 = dtRow.Field<DateTime?>("ProjectedMRPP08"),
                MRPP08 = dtRow.Field<DateTime?>("MRPP08"),
                LPRPlannedLaunchP09 = dtRow.Field<DateTime?>("LPRPlannedLaunchP09"),
                ProjectedLaunch = dtRow.Field<DateTime?>("ProjectedLaunch"),
                CommitLaunch = dtRow.Field<DateTime?>("CommitLaunch"),
                ActualLaunch = dtRow.Field<DateTime?>("ActualLaunch"),

                ProjectedIntegrationStart = dtRow.Field<DateTime?>("ProjectedIntegrationStart"),
                ActualIntegrationStart = dtRow.Field<DateTime?>("ActualIntegrationStart"),
                ProjectedTestStart = dtRow.Field<DateTime?>("ProjectedTestStart"),
                ActualTestStart = dtRow.Field<DateTime?>("ActualTestStart"),
                ProjectedTestComplete = dtRow.Field<DateTime?>("ProjectedTestComplete"),
                ActualTestComplete = dtRow.Field<DateTime?>("ActualTestComplete"),
                ProjectedManufacturingComplete = dtRow.Field<DateTime?>("ProjectedManufacturingComplete"),

                CommitedManufacturingComplete = dtRow.Field<DateTime?>("CommitedManufacturingComplete"),
                ActualManufacturingComplete = dtRow.Field<DateTime?>("ActualManufacturingComplete"),
                ManufacturingCommitedShipDate = dtRow.Field<DateTime?>("ManufacturingCommitedShipDate"),
                ProjectedCrateComplete = dtRow.Field<DateTime?>("ProjectedCrateComplete"),
                ActualCrateComplete = dtRow.Field<DateTime?>("ActualCrateComplete"),
                TargetShipDate = dtRow.Field<DateTime?>("TargetShipDate"),

                SalesOpsRequestDate = dtRow.Field<DateTime?>("SalesOpsRequestDate"),
                CustomerRequestDate = dtRow.Field<DateTime?>("CustomerRequestDate"),
                EarliestStartDate = dtRow.Field<DateTime?>("EarliestStartDate"),
                PlannedDMRF = dtRow.Field<DateTime?>("PlannedDMRF"),
                ActualDMRF = dtRow.Field<DateTime?>("ActualDMRF"),
                IdleTestDay = dtRow.Field<DateTime?>("IdleTestDay"),
                PilotManufacturingCommitedShipDate = dtRow.Field<DateTime?>("PilotManufacturingCommitedShipDate"),
                PlanofRecord = dtRow.Field<DateTime?>("PlanofRecord"),
                PlannedShipDate = dtRow.Field<DateTime?>("PlannedShipDate"),

                ActualShipDate = dtRow.Field<DateTime?>("ActualShipDate"),
                PlannedManufacturingComplete = dtRow.Field<DateTime?>("PlannedManufacturingComplete"),
                PlannedTestStart = dtRow.Field<DateTime?>("PlannedTestStart"),
                PlannedCrateComplete = dtRow.Field<DateTime?>("PlannedCrateComplete"),
                LPRPlannedPilotLaunchP47 = dtRow.Field<DateTime?>("LPRPlannedPilotLaunchP47"),
                CommittedTestComplete = dtRow.Field<DateTime?>("CommittedTestComplete"),
                CommittedTestStart = dtRow.Field<DateTime?>("CommittedTestStart"),
                CommittedIntegrationStart = dtRow.Field<DateTime?>("CommittedIntegrationStart"),
                PlannedIntegrationStart = dtRow.Field<DateTime?>("PlannedIntegrationStart"),
                PlannedTestComplete = dtRow.Field<DateTime?>("PlannedTestComplete"),
                AlreadyScheduled = dtRow.Field<bool?>("AlreadyScheduled"),
                ProductionPlanID = dtRow.Field<long?>("ProductionPlanID"),
                MaterialReadiness = dtRow.Field<DateTime?>("MaterialReadiness"),

                SubAssemblyHours = dtRow.Field<decimal?>("SubAssemblyHours"),
                IntegrationHours = dtRow.Field<decimal?>("IntegrationHours"),
                TestHours = dtRow.Field<decimal?>("TestHours"),
                PosttestHours = dtRow.Field<decimal?>("PosttestHours"),

            }).ToList();

            return ganttChartData;
        }
        public string GetMPSBayLimitedFilter(string connString, string interval, int PlantID, string StartDate, int productionPlanID)
        {

            try
            {
                DataTable dataTable;
                SqlParameter[] param = {
                new SqlParameter("@Interval",interval),
                    new SqlParameter("@planID", PlantID),
                    new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                    new SqlParameter("@ProductionPlanID", productionPlanID),
            };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetBaysForScheduledWhatIfLimitedFilter", param);

                string bayScheduleList = null;
                dynamic baySchedule = null;

                baySchedule = dataTable.Rows.Cast<DataRow>()
                .GroupBy(x => new
                {
                    Product_Type = x["ProductName"],
                    BayTypeName = x["BayTypeName"],
                    BuildingName = x["BuildingName"]
                })
                 .Select(x => new
                 {
                     ProductName = x.Key,
                     WeeklyDates = x.Select(y => new
                     {
                         TotalBaysAvailablity = y.Field<Int32>("TotalBaysAvailablity"),
                         TotalConsumed = y.Field<Int32>("TotalConsumed"),
                         TotalRemaining = y.Field<Int32>("TotalRemaining"),
                         BayDate = y.Field<DateTime>("BayDate")
                     })
                 }).ToList();

                bayScheduleList = Newtonsoft.Json.JsonConvert.SerializeObject(baySchedule);
                return bayScheduleList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public string GetMPSTotalBayLimitedFilter(string connString, string interval, int PlantID, string StartDate, int productionPlanID)
        {

            try
            {
                DataTable dataTable;
                SqlParameter[] param = {
                new SqlParameter("@Interval",interval),
                    new SqlParameter("@planID", PlantID),
                    new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                    new SqlParameter("@ProductionPlanID", productionPlanID),
            };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetTotalBaysForScheduledWhatIfLimitedFilter", param);

                string bayScheduleList = null;
                dynamic baySchedule = null;
                baySchedule = dataTable.Rows.Cast<DataRow>()
                .GroupBy(x => new
                {
                    Product_Type = x["ProductName"],
                    BayTypeName = x["BayTypeName"],
                    BuildingName = x["BuildingName"],
                })
                 .Select(x => new
                 {
                     ProductName = x.Key,
                     WeeklyDates = x.Select(y => new
                     {
                         TotalBaysAvailablity = y.Field<Int32>("TotalBaysAvailablity"),
                         BayDate = y.Field<DateTime>("BayDate")
                     })
                 }).ToList();

                bayScheduleList = Newtonsoft.Json.JsonConvert.SerializeObject(baySchedule);
                return bayScheduleList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public string GetMPSLaborLimitedFilter(string connString, string interval, int PlantID, string StartDate, int productionPlanID)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = {
                new SqlParameter("@Interval",interval),
                    new SqlParameter("@planID", PlantID),
                    new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                    new SqlParameter("@ProductionPlanID", productionPlanID),
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetLaborhoursForScheduledWhatIfLimitedFilter", param);
                string laborScheduleList = null;
                var laborSchedule = dataTable.Rows.Cast<DataRow>()
                .GroupBy(x => new
                {
                    ManagementName = x["ManagementName"],
                    Laborgroup = x["Laborgroup"],
                    LaborDate = x["LaborDate"]
                })
                .Select(x => new
                {
                    ProductName = new { x.Key.Laborgroup, x.Key.ManagementName },
                    WeeklyDates = x.Select(y => new
                    {
                        TotalAvailableHour = y.Field<decimal?>("TotalAvailableHour"),
                        TotalConsumedHour = y.Field<decimal?>("TotalConsumedHour"),
                        TotalRemainingHour = y.Field<decimal?>("TotalRemainingHour"),
                        LaborDate = x.Key.LaborDate,
                        SumAvailableHour = x.Sum(zz => zz.Field<decimal?>("TotalAvailableHour")),
                        SumConsumedHour = x.Sum(zz => zz.Field<decimal?>("TotalConsumedHour")),
                        SumRemainingHour = x.Sum(zz => zz.Field<decimal?>("TotalRemainingHour")),
                    })
                }).ToList().GroupBy(gg => gg.ProductName).Select(group => new { ProductName = group.Key, WeeklyDates = group.Select(zz => zz.WeeklyDates.FirstOrDefault()) })
                .OrderBy(x => x.ProductName.ManagementName).ThenBy(x => x.ProductName.Laborgroup).ToList();
                laborScheduleList = Newtonsoft.Json.JsonConvert.SerializeObject(laborSchedule);
                return laborScheduleList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public string GetMPSTotalLaborLimitedFilter(string connString, string interval, int PlantID, string StartDate, int productionPlanID)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = {
                new SqlParameter("@Interval",interval),
                    new SqlParameter("@planID", PlantID),
                    new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                    new SqlParameter("@ProductionPlanID", productionPlanID),
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetTotalLaborhoursForScheduledWhatIfLimitedFilter", param);
                string laborScheduleList = null;
                var laborSchedule = dataTable.Rows.Cast<DataRow>()
                .GroupBy(x => new
                {
                    ManagementName = x["ManagementName"],
                    Laborgroup = x["Laborgroup"],
                })
                .Select(x => new
                {
                    ProductName = x.Key,
                    WeeklyDates = x.Select(y => new
                    {
                        TotalAvailableHour = y.Field<decimal>("TotalAvailableHour"),
                        LaborDate = y.Field<DateTime>("LaborDate"),
                        SumAvailableHour = y.Field<decimal>("SumAvailableHour"),
                    })
                }).OrderBy(x => x.ProductName.ManagementName).ThenBy(x => x.ProductName.Laborgroup).ToList();
                laborScheduleList = Newtonsoft.Json.JsonConvert.SerializeObject(laborSchedule);
                return laborScheduleList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int DeleteModuleFromSchedule(string connString, int PilotProductId, int ProductionPlanID)
        {
            SqlParameter[] param = {
                    new SqlParameter("@pilotProductID",PilotProductId),
                    new SqlParameter("@productionPlanID",ProductionPlanID)
                    };
            return SqlHelper.ExecuteNonQueryNoOutParam(connString, "uspDeleteModuleFromSchedule", param);
        }

    }
}
