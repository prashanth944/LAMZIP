﻿
using LAM.PMPM.DAL;
using LAM.PMPM.Model;
using LAM.PMPM.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace LAM.PMPM.BL
{
    public class Schedule
    {
        DataTable dataTable = null;

        public List<SchedulesViewModel> GetPlanType(string connString)
        {
            dataTable = new DataTable();
            dataTable = SqlHelper.GetDataTable(connString, "uspGetPlanType", null);
            List<SchedulesViewModel> plantType = dataTable.AsEnumerable().Select(dtRow => new SchedulesViewModel()
            {
                PlantID = Convert.ToInt32(dtRow["PlantID"]),
                PlanName = Convert.ToString(dtRow["PlantName"])
            }).ToList();
            return plantType;
        }

        public List<PriorityOrder> GetSchedulePriority(string connString, int plantId)
        {
            SqlParameter[] param = {
                        new SqlParameter("@PlantID",plantId),
                        };
            dataTable = new DataTable();
            dataTable = SqlHelper.GetDataTable(connString, "uspGetSchedulePriority", param);
            List<PriorityOrder> plantType = dataTable.AsEnumerable().Select(dtRow => new PriorityOrder()
            {
                SchedulePriorityID = Convert.ToInt32(dtRow["SchedulePriorityID"]),
                Priorities = Convert.ToString(dtRow["Priorities"])
            }).ToList();
            return plantType;
        }

        public List<PriorityOrder> GetRecordType(string connString, int plantId)
        {
            SqlParameter[] param = {
                        new SqlParameter("@PlantID",plantId),
                        };
            dataTable = new DataTable();
            dataTable = SqlHelper.GetDataTable(connString, "uspGetRecordType", param);
            List<PriorityOrder> plantType = dataTable.AsEnumerable().Select(dtRow => new PriorityOrder()
            {
                SchedulePriorityID = Convert.ToInt32(dtRow["SchedulePriorityRecordTypeID"]),
                Priorities = Convert.ToString(dtRow["RecordType"])
            }).ToList();
            return plantType;
        }

        public List<PriorityOrder> GetRevenueType(string connString, int plantId)
        {
            SqlParameter[] param = {
                        new SqlParameter("@PlantID",plantId),
                        };
            dataTable = new DataTable();
            dataTable = SqlHelper.GetDataTable(connString, "uspGetRevenueType", param);
            List<PriorityOrder> plantType = dataTable.AsEnumerable().Select(dtRow => new PriorityOrder()
            {
                SchedulePriorityID = Convert.ToInt32(dtRow["SchedulePriorityRevenueTypeID"]),
                Priorities = Convert.ToString(dtRow["RevenueType"])
            }).ToList();
            return plantType;
        }

        public List<MasterRecords> GetPriorityDate(string connString)
        {
            dataTable = new DataTable();
            dataTable = SqlHelper.GetDataTable(connString, "uspGetPriorityDate", null);
            List<MasterRecords> priorityDate = dataTable.AsEnumerable().Select(dtRow => new MasterRecords()
            {
                MasterRecordID = Convert.ToInt32(dtRow["PriorityID"]),
                MasterRecordName = Convert.ToString(dtRow["Priority"])
            }).ToList();
            return priorityDate;
        }
        public int AddProductionPlan(string connString, SchedulesViewModel schedules)
        {
            var resultCount = 0;
            var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            SqlParameter[] param = {
                new SqlParameter("@plantID",schedules.PlantID),
                new SqlParameter("@productionPlanName",schedules.PlanName),
                new SqlParameter("@planType",schedules.PlanType),
                new SqlParameter("@userID",schedules.UserID),
                new SqlParameter("@dataRefreshDate",schedules.DataRefreshDate),
                new SqlParameter("@decriptionScenario",schedules.Description),
                new SqlParameter("@ModifiedById",schedules.ModifiedById),
                outParam
            };

            resultCount = SqlHelper.ExecuteNonQuery(connString, "uspAddProductionPlan", param);
            return resultCount;
        }

        public List<ModulesSummary> GetModuleLevelCP(string connString, string PlantName, long? ProductionPlanId, SchedulesViewModel schedules)
        {
            dataTable = new DataTable();
            string SortList = string.Empty;
            // Need to get Sorted list based on the module priority
            SortList = GetSortedList(connString, schedules.PriorityOrder.ToList(), schedules.RecordTypePriorityOrder.ToList(), schedules.RevenueTypePriorityOrder.ToList());
            List<ModulesSummary> ModuleLevelCP = new List<ModulesSummary>();
            SqlParameter[] param = {
                        new SqlParameter("@PlantName",PlantName),
                        new SqlParameter("@productionplanid",ProductionPlanId),
                        new SqlParameter("@sortedPriority",SortList)
                        };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetModuleLevelCPPORWhatIfSort", param);
            try
            {
                ModuleLevelCP = dataTable.AsEnumerable().Select(dtRow => new ModulesSummary()
                {
                    PilotProductID = dtRow.Field<long?>("PilotProductID"),
                    SalesPriority = dtRow.Field<string>("SalesPriority"),
                    FCID = dtRow.Field<string>("FCID"),
                    PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                    PriorityDateDDl = dtRow.Field<string>("Priorities"),
                    PriorityDate = dtRow.Field<DateTime?>("PriorityDate"),
                    PilotRisk = dtRow.Field<string>("PilotRisk"),
                    DayShiftOnly = dtRow.Field<bool?>("DayShiftOnly"),
                    NoCapacity = dtRow.Field<bool?>("NoCapacity"),
                    RecordType = dtRow.Field<string>("RecordType"),
                    RevenueCode = dtRow.Field<string>("RevenueCode"),
                    BuildTypeID = dtRow.Field<long?>("BuildTypeID"),
                    BuildTypeName = dtRow.Field<string>("BuildName"),
                    ToolTypeName = dtRow.Field<string>("ToolTypeName"),
                    ToolTypeID = dtRow.Field<int?>("ToolTypeID"),
                    ProductGroupName = dtRow.Field<string>("ProductName"),
                    CustomerID = dtRow.Field<string>("CustomerID"),
                    CompleteATP = dtRow.Field<string>("CompleteATP"),
                    ModuleIdSubassembly = dtRow.Field<int?>("ModuleProcessIdForSubassembly"),
                    ModuleIdIntegration = dtRow.Field<int?>("ModuleProcessIdForIntegration"),
                    ModuleIdTest = dtRow.Field<int?>("ModuleProcessIdForTest"),
                    ModuleIdPostTest = dtRow.Field<int?>("ModuleProcessIdForPostTest"),
                    MPSName = dtRow.Field<string>("MPSName"),
                    BEN = dtRow.Field<string>("BEN"),
                    POM = dtRow.Field<string>("POM"),
                    ActualDMRF = dtRow.Field<DateTime?>("ActualDMRF"),
                    PlannedDMRF = dtRow.Field<DateTime?>("PlannedDMRF"),
                    BaysRequiredSubassembly = dtRow.Field<int?>("BaysRequiredSubassembly"),
                    BaysRequiredIntegration = dtRow.Field<int?>("BaysRequiredIntegration"),
                    BaysRequiredForTest = dtRow.Field<int?>("BaysRequiredTest"),
                    BaysRequiredPostTest = dtRow.Field<int?>("BaysRequiredPostTest"),
                    TotalAssemblyHours = dtRow.Field<decimal?>("SubassemblyBuildHours"),
                    TotalIntegrationHours = dtRow.Field<decimal?>("IntegrationBuildHours"),
                    TotalTestHours = dtRow.Field<decimal?>("TestBuildHours"),
                    TotalPostTestHours = dtRow.Field<decimal?>("PostTestBuildHours"),
                    TechnicianRequiredSubassembly = dtRow.Field<int?>("SubassemblyTechnician"),
                    TechnicianRequiredIntegration = dtRow.Field<int?>("IntegrationTechnician"),
                    TechnicianRequiredTest = dtRow.Field<int?>("TestTechnician"),
                    TechnicianRequiredPostTest = dtRow.Field<int?>("PostTestTechnician"),
                    TotalLaborHour = dtRow.Field<decimal?>("TotalLaborHour"),
                    EarliestStartDate = dtRow.Field<DateTime?>("EarliestStartDate"),
                    MaterialReadiness = dtRow.Field<DateTime?>("MaterialReadiness"),
                    POABOMReleaseDate = dtRow.Field<DateTime?>("POABOMReleaseDate"),
                    TransitionDate = dtRow.Field<DateTime?>("TransitionDate"),
                    CommitLaunch = dtRow.Field<DateTime?>("CommitLaunch"),
                    CommittedIntegrationStart = dtRow.Field<DateTime?>("CommittedIntegrationStart"),
                    CommitTestStart = dtRow.Field<DateTime?>("CommittedTestStart"),
                    CommitManufacturingComplete = dtRow.Field<DateTime?>("CommitedManufacturingComplete"),
                    PilotCommit = dtRow.Field<DateTime?>("PilotManufacturingCommitedShipDate"),
                    CRD = dtRow.Field<DateTime?>("CustomerRequestDate"),
                    CRDEsc = dtRow.Field<bool?>("CRDEsc"),
                    CRDGapDays = dtRow.Field<int?>("CRDGapDays"),
                    SRD = dtRow.Field<DateTime?>("SalesOpsRequestDate"),
                    TSD = dtRow.Field<DateTime?>("TargetShipDate"),
                    MCSD = dtRow.Field<DateTime?>("ManufacturingCommitedShipDate"),
                    Notes = dtRow.Field<string>("Note"),
                    AlreadyScheduled = dtRow.Field<bool?>("AlreadyScheduled"),
                    PlanofRecord = dtRow.Field<DateTime?>("PlanofRecord"),
                    T09Comment = dtRow.Field<string>("T09Comment"),
                    PilotMCSD = dtRow.Field<DateTime?>("PilotManufacturingCommitedShipDate"),
                    SapMCSD = dtRow.Field<DateTime?>("ManufacturingCommitedShipDate"),
                    OnPOR = dtRow.Field<string>("OnPOR"),
                    ScheduleStatusId = dtRow.Field<long?>("ScheduleStatusId"),
                    ScheduleStatus = dtRow.Field<string>("ScheduleStatus"),
                }).ToList();
            }
            catch (Exception ex)
            {
            }
            return ModuleLevelCP;
        }


        public int UpdateModuleLevelCP(string connString, ModulesSummary[] editModuleLevelCP)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                foreach (var items in editModuleLevelCP)
                {
                    SqlParameter[] param = {
                    new SqlParameter("@pilotProductID",items.PilotProductID),
                    new SqlParameter("@priorityDate",items.PriorityDateDDl),
                    new SqlParameter("@pilotSerialNumber",items.PilotSerialNumber),
                    new SqlParameter("@salesPriority",items.SalesPriority),
                    new SqlParameter("@buildTypeID",items.BuildTypeID),
                    new SqlParameter("@toolTypeID",items.ToolTypeID),
                    new SqlParameter("@buildName",items.BuildTypeName),
                    new SqlParameter("@toolTypeName",items.ToolTypeName),
                    new SqlParameter("@pilotRisk",items.PilotRisk),
                    new SqlParameter("@earliestallowedlaunch",items.EarliestStartDate),
                    new SqlParameter("@customer",items.CustomerID),
                    new SqlParameter("@completeATP",items.CompleteATP),
                    new SqlParameter("@ModuleProcessIdForSubassembly",items.ModuleIdSubassembly),
                    new SqlParameter("@ModuleProcessIdForIntegration",items.ModuleIdIntegration),
                    new SqlParameter("@ModuleProcessIdForTest",items.ModuleIdTest),
                    new SqlParameter("@ModuleProcessIdForPostTest",items.ModuleIdPostTest),
                    new SqlParameter("@totalAssemblyHours",items.TotalAssemblyHours),
                    new SqlParameter("@totalIntegrationHour",items.TotalIntegrationHours),
                    new SqlParameter("@totalTestHour",items.TotalTestHours),
                    new SqlParameter("@totalPostTestHour",items.TotalPostTestHours),
                    new SqlParameter("@commitLaunch",items.CommitLaunch),
                    new SqlParameter("@commitIntegrationStart",items.CommittedIntegrationStart),
                    new SqlParameter("@commitTestStart",items.CommitTestStart),
                    new SqlParameter("@commitManufacturingComplete",items.CommitManufacturingComplete),
                    new SqlParameter("@noCapacity",items.NoCapacity),
                    new SqlParameter("@notes",items.Notes),
                    new SqlParameter("@crdEsc",items.CRDEsc),

                    new SqlParameter("@assemblyTechnician", items.TechnicianRequiredSubassembly),
                    new SqlParameter("@integrationTechnician", items.TechnicianRequiredIntegration),
                    new SqlParameter("@testTechnician", items.TechnicianRequiredTest),
                    new SqlParameter("@postTestTechnician", items.TechnicianRequiredPostTest),
                    new SqlParameter("@assemblyBaysRequired", items.BaysRequiredSubassembly),
                    new SqlParameter("@integrationBaysRequired", items.BaysRequiredIntegration),
                    new SqlParameter("@testBaysRequired", items.BaysRequiredForTest),
                    new SqlParameter("@postTestBaysRequired", items.BaysRequiredPostTest),
                    new SqlParameter("@PilotManufacturingCommitedShipDate",items.PilotMCSD),
                    new SqlParameter("@TargetShipDate",items.TSD),
                    new SqlParameter("@SalesOpsRequestDate",items.SRD),
                    new SqlParameter("@CustomerRequestDate",items.CRD),
                    new SqlParameter("@DayShiftOnly",items.DayShiftOnly),
                    new SqlParameter("@PlanofRecord",items.PlanofRecord),
                    new SqlParameter("@ProductionPlanID",items.ProductionPlanID),
                    new SqlParameter("@ModifiedBy",items.ModifiedBy),
                    new SqlParameter("@ModifiedOn", items.ModifiedOn),
                    new SqlParameter("@ScheduleStatusId", items.ScheduleStatusId),
                    outParam
                    };
                    resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateModuleLevelCP", param);
                }
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public object GetScheduleDatePicker(string connString, int PlanAId, int PlanBId)
        {
            try
            {
                dataTable = new DataTable();
                SqlParameter[] param = {
                    new SqlParameter("@PlanAId", PlanAId),
                    new SqlParameter("@PlanBId", PlanBId),
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetDatePickerComparePlan", param);
                List<ScheduleCapacity> ScheduleDatepicker = dataTable.AsEnumerable().Select(y => new ScheduleCapacity()
                {
                    MinEarliestStartDate = y.Field<DateTime?>("MinEarliestStartDate"),
                    MaxProjectedDate = y.Field<DateTime?>("MaxProjectedDate"),
                }).ToList();
                return ScheduleDatepicker;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public ComparisonListWithDate GetWeeklyComparisonView(string connString, int planAId, int planBId)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@ProductionPlanAId", planAId),
                new SqlParameter("@ProductionPlanBId", planBId)
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetWeeklyComparison", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new ComparisonModel
            {
                WeekDate = dtRow.Field<DateTime?>("WeekDate"),
                LaborType = dtRow.Field<string>("LaborType"),
                LaborDifference = dtRow.Field<int?>("LaborDifference"),
                HighRisk = dtRow.Field<string>("HighRisk"),
                HighRiskDifference = dtRow.Field<int?>("HighRiskDifference"),
                MediumRisk = dtRow.Field<string>("MediumRisk"),
                MediumRiskDifference = dtRow.Field<int?>("MediumRiskDifference"),
                LaunchingTool = dtRow.Field<string>("LaunchingTool"),
                LaunchingToolDifference = dtRow.Field<int?>("LaunchingToolDifference"),
            }).ToList();

            ComparisonListWithDate comparisonListWithDate = new ComparisonListWithDate();

            List<ComparisonList> comparisonList = new List<ComparisonList>();

            List<DateTime> dates = new List<DateTime>();

            masterRecords.GroupBy(x => x.WeekDate).ToList().ForEach(zz =>
            {
                dates.Add(zz.Key.Value);
            });

            masterRecords.GroupBy(x => x.LaborType).ToList().ForEach(x =>
            {
                comparisonList.Add(new ComparisonList() { Description = x.Key, WeeklyDates = x.ToList().Select(z => new WeeklyDate { DateValue = z.WeekDate, Value = z.LaborDifference.Value }).ToList() });
            });

            masterRecords.GroupBy(x => x.HighRisk).ToList().ForEach(x =>
            {
                comparisonList.Add(new ComparisonList() { Description = x.Key, WeeklyDates = x.ToList().Select(z => new WeeklyDate { DateValue = z.WeekDate, Value = z.HighRiskDifference.Value }).ToList() });
            });

            masterRecords.GroupBy(x => x.MediumRisk).ToList().ForEach(x =>
            {
                comparisonList.Add(new ComparisonList() { Description = x.Key, WeeklyDates = x.ToList().Select(z => new WeeklyDate { DateValue = z.WeekDate, Value = z.MediumRiskDifference.Value }).ToList() });
            });

            masterRecords.GroupBy(x => x.LaunchingTool).ToList().ForEach(x =>
            {
                comparisonList.Add(new ComparisonList() { Description = x.Key, WeeklyDates = x.ToList().Select(z => new WeeklyDate { DateValue = z.WeekDate, Value = z.LaunchingToolDifference.Value }).ToList() });
            });

            comparisonList.RemoveAll(x => string.IsNullOrEmpty(x.Description));

            comparisonListWithDate.ComparisonLists = comparisonList;
            comparisonListWithDate.WeeklyDates = dates;

            return comparisonListWithDate;
        }

        public object GetIsPlanBeingEdited(string connString, int productionplanid)
        {

            dataTable = new DataTable();
            SqlParameter[] param = {
                 new SqlParameter("@ProductionPlanId", productionplanid),
                 };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetIfProductionPlanIsBeingEditedByOtherUser", param);
            try
            {
                var masterrecord = dataTable.AsEnumerable().Select(dtRow => new
                {
                    ProductionPlanID = dtRow.Field<long?>("ProductionPlanID"),
                    IsBeingEdited = dtRow.Field<bool?>("IsBeingEdited"),
                    IsBeingEditedById = dtRow.Field<long?>("IsBeingEditedById"),
                }).FirstOrDefault();

                return masterrecord;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }

        }

        public void UpdateLeadTimeDays(string connString, string ModuleProcess, int NoOfDays)
        {

            var outParamBayAvail = new SqlParameter("@NoOfDays", SqlDbType.Int) //4
            {
                Direction = ParameterDirection.Output
            };
            var outParamModSuccess = new SqlParameter("@ModuleProcess", SqlDbType.Text) //5
            {
                Direction = ParameterDirection.Output
            };
            SqlParameter[] param = {
                                        new SqlParameter("@ModuleProcess",ModuleProcess),
                                        new SqlParameter ("@NoOfDays", NoOfDays)
                                        };
            SqlHelper.ExecuteNonQueryNoOutParam(connString, "[uspUpdateLeadTimeDays]", param);
        }
        public int GetCheckLeadTimeDays(string connString, string ModuleProcess, int NoOfDays, int pilotProductID, long? ProductionPlanID2)
         {
            
            int outVal = 0;
            var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            var outParamBayAvail = new SqlParameter("@NoOfDays", SqlDbType.Int) //4
            {
                Direction = ParameterDirection.Output
            };
            var outParamModSuccess = new SqlParameter("@ModuleProcess", SqlDbType.Text) //5
            {
                Direction = ParameterDirection.Output
            };

            SqlParameter[] param = {
                                        new SqlParameter("@ModuleProcess",ModuleProcess),
                                        new SqlParameter ("@NoOfDays", NoOfDays),
                                        new SqlParameter ("@pilotProductID", pilotProductID),
                                        new SqlParameter ("@ProductionPlanID", ProductionPlanID2),
                                        outParam
                                        };
            outVal = SqlHelper.ExecuteNonQuery(connString, "[uspCheckLeadtimedays]", param);
            return outVal;
        }


        public GenerateScheduleOutputViewModel AdjustGeneratedSchedule(string connString, AdjustScheduleViewModule schedules)
        {

            string[] substringArr = null;
            GenerateScheduleOutputViewModel generateScheduleOutputViewModel = new GenerateScheduleOutputViewModel();
            DateTime EarliestStartDate = schedules.EarliestStartDate;
            string generatedSchedule = "0,";

            if (schedules.EarliestStartDate != null)
            {
                if (Convert.ToDateTime(schedules.EarliestStartDate) <= DateTime.Today)
                    schedules.EarliestStartDate = DateTime.Today.AddDays(1);
            }

            var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            var outParamErrormsg = new SqlParameter("@errorMessage", SqlDbType.VarChar, 500) //0
            {
                Direction = ParameterDirection.Output
            };
            var outParamBEN = new SqlParameter("@outParamBEN", SqlDbType.VarChar, 500) //1
            {
                Direction = ParameterDirection.Output
            };
            var outParamPilotSer = new SqlParameter("@outParamPilotSer", SqlDbType.VarChar, 500) //2
            {
                Direction = ParameterDirection.Output
            };
            var outParamLaborAvail = new SqlParameter("@outParamLaborAvail", SqlDbType.Int) //3
            {
                Direction = ParameterDirection.Output
            };
            var outParamBayAvail = new SqlParameter("@outParamBayAvail", SqlDbType.Int) //4
            {
                Direction = ParameterDirection.Output
            };
            var outParamModSuccess = new SqlParameter("@outParamModSuccess", SqlDbType.Int) //5
            {
                Direction = ParameterDirection.Output
            };
       
            SqlParameter[] param = {
                                        new SqlParameter("@pilotProductID",schedules.PilotProductID),
                                        new SqlParameter("@BoolBayHardConstraint",false),
                                        new SqlParameter("@BoolLaborHardConstraint",false),
                                        new SqlParameter("@earliestAllowedStartDate",schedules.EarliestStartDate),
                                        new SqlParameter("@ProductionPlanID",schedules.ProductionPlanID),
                                        //Added newly
                                        new SqlParameter("@plantId", schedules.PlantID),
                                        new SqlParameter ("@PlantName", schedules.PlantName),
                                        //Added newly
                                        new SqlParameter ("@NoOfDays", schedules.NoOfDays),
                                        new SqlParameter ("@ModuleProcess", schedules.ModuleProcess),
                                        outParam,
                                        outParamErrormsg, outParamBEN, outParamPilotSer, outParamLaborAvail,outParamBayAvail, outParamModSuccess
                                        };
            generatedSchedule = SqlHelper.ExecuteNonQueryWithSevenOutParam(connString, "[uspGenerateModuleScheduleAlgorithmEnsureLaborBay]", param);

            substringArr = generatedSchedule.Split(',');

            if (generatedSchedule != null && generatedSchedule != "")
            {
                substringArr = generatedSchedule.Split(',');
                if (substringArr[4] != null && substringArr[4] != "")
                {
                    generateScheduleOutputViewModel.BayAvail = Convert.ToInt32(substringArr[4]);
                }
                else
                {
                    substringArr[4] = "0";
                }
                if (substringArr[5] != null && substringArr[5] != "")
                {
                    generateScheduleOutputViewModel.LaborAvail = Convert.ToInt32(substringArr[5]);
                }
                else
                {
                    substringArr[5] = "0";
                }
                if (substringArr[6] != null && substringArr[6] != "")
                {

                    generateScheduleOutputViewModel.ModSuccess = Convert.ToInt32(substringArr[6]);
                }
                else
                {
                    substringArr[6] = "0";
                }
            }
            return generateScheduleOutputViewModel;

        }

        public GenerateScheduleOutputViewModel GetGeneratedSchedule(string connString, SchedulesViewModel schedules)
        {
            GenerateScheduleOutputViewModel generateScheduleOutputViewModel = new GenerateScheduleOutputViewModel();
            string[] substringArr = null;
            int Iteration = 0;
            //Need to save production plan into table.
            Schedule schedule = new Schedule();
            long? ProductionPlanID = schedules.ProductionPlanID;

            //lead time in days
            // bool IsModLeval = true;
            string generatedSchedule = "0,";
            List<PriorityOrder> priorityOrder = schedules.PriorityOrder.ToList();
            List<PriorityOrder> RecordTypePriorityOrder = schedules.RecordTypePriorityOrder.ToList();
            List<PriorityOrder> RevenueTypePriorityOrder = schedules.RevenueTypePriorityOrder.ToList();
            bool BoolBayHardConstraint = schedules.BayResourcesHardConstraint;
            bool BoolLaborHardConstraint = schedules.LaborResourcesHardConstraint;
            DataTable dtSortList = new DataTable();
            dtSortList.Columns.Add("PilotProductID", typeof(System.Int32));
            dtSortList.Columns.Add("EarliestStartDate", typeof(System.DateTime));
            dtSortList.Columns.Add("DayShiftOnly", typeof(System.Boolean));
            if (schedules.ModulesLevelCp.Count() > 0)
            {
                for (int i = 0; i < schedules.ModulesLevelCp.Count(); i++)
                {
                    DataRow row = dtSortList.NewRow();
                    if (schedules.ModulesLevelCp[i].EarliestStartDate != null)
                    {
                        if (Convert.ToDateTime(schedules.ModulesLevelCp[i].EarliestStartDate) <= DateTime.Today)
                            schedules.ModulesLevelCp[i].EarliestStartDate = DateTime.Today.AddDays(1);
                    }
                    if (schedules.ModulesLevelCp[i].EarliestStartDate != null)
                    {
                        row["PilotProductID"] = schedules.ModulesLevelCp[i].PilotProductID;
                        row["EarliestStartDate"] = schedules.ModulesLevelCp[i].EarliestStartDate;

                        if (schedules.ModulesLevelCp[i].DayShiftOnly == null)
                            schedules.ModulesLevelCp[i].DayShiftOnly = false;

                        row["DayShiftOnly"] = schedules.ModulesLevelCp[i].DayShiftOnly;
                        dtSortList.Rows.Add(row);
                    }
                }
                foreach (DataRow row in dtSortList.Rows)
                {
                    int PilotProductID = Convert.ToInt32(row["PilotProductID"]);
                    bool DayShiftOnly = Convert.ToBoolean(row["DayShiftOnly"]);
                    DataTable ModulesLeadTime = CalculateLeadTime(connString, PilotProductID, schedules.ProductionPlanID);

                    if (row["EarliestStartDate"] != null && row["EarliestStartDate"].ToString() != string.Empty)
                    {
                        DateTime EarliestStartDate = Convert.ToDateTime(row["EarliestStartDate"]);
                        var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                        {
                            Direction = ParameterDirection.Output
                        };
                        var outParamErrormsg = new SqlParameter("@errorMessage", SqlDbType.VarChar, 500) //0
                        {
                            Direction = ParameterDirection.Output
                        };
                        var outParamBEN = new SqlParameter("@outParamBEN", SqlDbType.VarChar, 500) //1
                        {
                            Direction = ParameterDirection.Output
                        };
                        var outParamPilotSer = new SqlParameter("@outParamPilotSer", SqlDbType.VarChar, 500) //2
                        {
                            Direction = ParameterDirection.Output
                        };
                        var outParamLaborAvail = new SqlParameter("@outParamLaborAvail", SqlDbType.Int) //3
                        {
                            Direction = ParameterDirection.Output
                        };
                        var outParamBayAvail = new SqlParameter("@outParamBayAvail", SqlDbType.Int) //4
                        {
                            Direction = ParameterDirection.Output
                        };
                        var outParamModSuccess = new SqlParameter("@outParamModSuccess", SqlDbType.Int) //5
                        {
                            Direction = ParameterDirection.Output
                        };
                  
                        SqlParameter[] param = {
                                        new SqlParameter("@pilotProductID",PilotProductID),
                                        new SqlParameter("@BoolBayHardConstraint",BoolBayHardConstraint),
                                        new SqlParameter("@BoolLaborHardConstraint",BoolLaborHardConstraint),
                                        new SqlParameter("@earliestAllowedStartDate",EarliestStartDate),
                                        new SqlParameter("@ProductionPlanID",ProductionPlanID),
                                        //Added newly
                                        new SqlParameter("@plantId", schedules.PlantID),
                                        new SqlParameter ("@PlantName", schedules.PlantName),
                                        //new SqlParameter ("@Dayshift", DayShiftOnly),    //Added newly
                                        new SqlParameter ("@NoOfDays", 0),
                                        new SqlParameter ("@ModuleProcess", ""),
                                        outParam,
                                        outParamErrormsg, outParamBEN, outParamPilotSer, outParamLaborAvail,outParamBayAvail, outParamModSuccess
                                        };
                        generatedSchedule = SqlHelper.ExecuteNonQueryWithSevenOutParam(connString, "[uspGenerateModuleScheduleAlgorithmEnsureLaborBay]", param);
                        if (generatedSchedule != null && generatedSchedule != "")
                        {
                            substringArr = generatedSchedule.Split(',');
                          
                            if (substringArr[0] != null && substringArr[0] == "-1")

                            {

                                generateScheduleOutputViewModel.rowCount = Convert.ToInt32(substringArr[0]);
                            }
                            if (substringArr[2] != null && substringArr[2] != "" && substringArr[6] == "0")
                            {
                                if (generateScheduleOutputViewModel.BENArr != null && generateScheduleOutputViewModel.BENArr != "")
                                    generateScheduleOutputViewModel.BENArr = generateScheduleOutputViewModel.BENArr + ',' + substringArr[2];
                                else
                                    generateScheduleOutputViewModel.BENArr = substringArr[2];
                            }
                            if (substringArr[3] != null && substringArr[3] != "" && substringArr[6] == "0")
                            {
                                if (generateScheduleOutputViewModel.PilotSer != null && generateScheduleOutputViewModel.PilotSer != "")
                                    generateScheduleOutputViewModel.PilotSer = generateScheduleOutputViewModel.PilotSer + ',' + substringArr[3];
                                else
                                    generateScheduleOutputViewModel.PilotSer = substringArr[3];
                            }
                            if (substringArr[4] != null && substringArr[4] != "")
                            {
                                generateScheduleOutputViewModel.BayAvail = generateScheduleOutputViewModel.BayAvail + Convert.ToInt32(substringArr[4]);
                            }
                            else
                            {
                                substringArr[4] = "0";
                            }
                            if (substringArr[5] != null && substringArr[5] != "")
                            {
                                generateScheduleOutputViewModel.LaborAvail = generateScheduleOutputViewModel.LaborAvail + Convert.ToInt32(substringArr[5]);
                            }
                            else
                            {
                                substringArr[5] = "0";
                            }
                            if (substringArr[6] != null && substringArr[6] != "")
                            {

                                generateScheduleOutputViewModel.ModSuccess = generateScheduleOutputViewModel.ModSuccess + Convert.ToInt32(substringArr[6]);
                            }
                            else
                            {
                                substringArr[6] = "0";
                            }
                        }
                        Iteration = Iteration + 1;
                    }
                }


                if (schedules.PlantName.Equals("Fremont")/* && schedules.BayResourcesHardConstraint == true && schedules.LaborResourcesHardConstraint == true*/)
                {
                    if (generateScheduleOutputViewModel.BayAvail == 0 && generateScheduleOutputViewModel.LaborAvail == 0 && (generateScheduleOutputViewModel.rowCount == -1))
                    { //Both are failed
                        generateScheduleOutputViewModel.errorMessageArr = "For " + generateScheduleOutputViewModel.PilotSer + " No Bays and Labor available, SubAssembly,Integration,Test,Post-Test Build hours are zero" + '|' + generateScheduleOutputViewModel.ModSuccess;
                    }
                    else if (generateScheduleOutputViewModel.BayAvail > 0 && generateScheduleOutputViewModel.LaborAvail == 0 && (generateScheduleOutputViewModel.rowCount == -1))
                    { //Bays is passed but build hours are failed
                        generateScheduleOutputViewModel.errorMessageArr = "For " + generateScheduleOutputViewModel.PilotSer + " No Labor available, SubAssembly,Integration,Test,Post-Test Build hours are zero" + '|' + generateScheduleOutputViewModel.ModSuccess;
                    }
                    else if (generateScheduleOutputViewModel.BayAvail == 0 && generateScheduleOutputViewModel.LaborAvail > 0 && (generateScheduleOutputViewModel.rowCount == -1))
                    { //Labor is passed but build hours are failed
                        generateScheduleOutputViewModel.errorMessageArr = "For " + generateScheduleOutputViewModel.PilotSer + " No Bays available, SubAssembly,Integration,Test,Post-Test Build hours are zero" + '|' + generateScheduleOutputViewModel.ModSuccess;
                    }
                    else if (generateScheduleOutputViewModel.BayAvail > 0 && generateScheduleOutputViewModel.LaborAvail > 0 && (generateScheduleOutputViewModel.rowCount == -1))
                    { //Build hours only failed
                        generateScheduleOutputViewModel.errorMessageArr = "For " + generateScheduleOutputViewModel.PilotSer + " SubAssembly,Integration,Test,Post-Test Build hours are zero" + '|' + generateScheduleOutputViewModel.ModSuccess;
                    }
                    else if ((generateScheduleOutputViewModel.BayAvail == 0) && generateScheduleOutputViewModel.LaborAvail == 0)
                    {
                        generateScheduleOutputViewModel.errorMessageArr = "For " + generateScheduleOutputViewModel.PilotSer + " No Bays and Labor available." + '|' + generateScheduleOutputViewModel.ModSuccess;
                    }
                    else if ((generateScheduleOutputViewModel.BayAvail == 0) && generateScheduleOutputViewModel.LaborAvail > 0)
                    {
                        generateScheduleOutputViewModel.errorMessageArr = "For " + generateScheduleOutputViewModel.PilotSer + " No Bays available." + '|' + generateScheduleOutputViewModel.ModSuccess;
                    }
                    else if ((generateScheduleOutputViewModel.BayAvail > 0) && generateScheduleOutputViewModel.LaborAvail == 0)
                    {
                        generateScheduleOutputViewModel.errorMessageArr = "For " + generateScheduleOutputViewModel.PilotSer + " No Labor available." + '|' + generateScheduleOutputViewModel.ModSuccess;
                    }





                    //Added Newly 
                    else if (generateScheduleOutputViewModel.BayAvail < Iteration && generateScheduleOutputViewModel.LaborAvail < Iteration && (generateScheduleOutputViewModel.rowCount == -1))
                    { //Build hours only failed
                        generateScheduleOutputViewModel.errorMessageArr = "For " + generateScheduleOutputViewModel.PilotSer + " SubAssembly,Integration,Test,Post-Test Build hours are zero" + '|' + generateScheduleOutputViewModel.ModSuccess;
                    }
                    else if (generateScheduleOutputViewModel.BayAvail == Iteration && generateScheduleOutputViewModel.LaborAvail < Iteration)
                    { //Build hours only failed
                        generateScheduleOutputViewModel.errorMessageArr = "For " + generateScheduleOutputViewModel.PilotSer + " No Labor available." + '|' + generateScheduleOutputViewModel.ModSuccess;
                    }
                    else if (generateScheduleOutputViewModel.BayAvail < Iteration && generateScheduleOutputViewModel.LaborAvail == Iteration)
                    { //Build hours only failed
                        generateScheduleOutputViewModel.errorMessageArr = "For " + generateScheduleOutputViewModel.PilotSer + " No Bays available." + '|' + generateScheduleOutputViewModel.ModSuccess;
                    }
                    else if (generateScheduleOutputViewModel.BayAvail < Iteration && generateScheduleOutputViewModel.LaborAvail < Iteration)
                    { //Build hours only failed
                        generateScheduleOutputViewModel.errorMessageArr = "For " + generateScheduleOutputViewModel.PilotSer + " No Bays and Labor available." + '|' + generateScheduleOutputViewModel.ModSuccess;
                    }
                    else if ((Convert.ToInt32(generateScheduleOutputViewModel.ModSuccess) > 0) && generateScheduleOutputViewModel.BayAvail == Iteration && generateScheduleOutputViewModel.LaborAvail == Iteration)
                    {
                        generateScheduleOutputViewModel.errorMessageArr = generateScheduleOutputViewModel.errorMessageArr + '|' + generateScheduleOutputViewModel.ModSuccess.ToString();
                    }

                    else if ((Convert.ToInt32(generateScheduleOutputViewModel.ModSuccess) > 0))
                    {
                        generateScheduleOutputViewModel.errorMessageArr = generateScheduleOutputViewModel.errorMessageArr + '|' + generateScheduleOutputViewModel.ModSuccess.ToString();
                    }
                    else if ((Convert.ToInt32(generateScheduleOutputViewModel.ModSuccess) > 0) && (generateScheduleOutputViewModel.rowCount != null && generateScheduleOutputViewModel.rowCount == -1) && (generateScheduleOutputViewModel.rowCount == -1))
                    {//Labor/Bay is fine but all build hrs are zero 
                        generateScheduleOutputViewModel.errorMessageArr = "For " + generateScheduleOutputViewModel.PilotSer + " SubAssembly,Integration,Test,Post-Test Build hours are zero" + '|' + generateScheduleOutputViewModel.ModSuccess;
                    }

                }
                else if (schedules.PlantName.ToLower().Equals("tualatin")/* && schedules.BayResourcesHardConstraint == true && schedules.LaborResourcesHardConstraint == true*/)
                {
                    if (generateScheduleOutputViewModel.BayAvail == 0 && generateScheduleOutputViewModel.LaborAvail == 0 && (generateScheduleOutputViewModel.rowCount == -1))
                    { //Both are failed
                        generateScheduleOutputViewModel.errorMessageArr = "For " + generateScheduleOutputViewModel.BENArr + " No Bays and Labor available, SubAssembly,Integration,Test,Post-Test Build hours are zero" + '|' + generateScheduleOutputViewModel.ModSuccess;
                    }
                    else if (generateScheduleOutputViewModel.BayAvail > 0 && generateScheduleOutputViewModel.LaborAvail == 0 && (generateScheduleOutputViewModel.rowCount == -1))
                    { //Bays is passed but build hours are failed
                        generateScheduleOutputViewModel.errorMessageArr = "For " + generateScheduleOutputViewModel.BENArr + " No Labor available, SubAssembly,Integration,Test,Post-Test Build hours are zero" + '|' + generateScheduleOutputViewModel.ModSuccess;
                    }
                    else if (generateScheduleOutputViewModel.BayAvail == 0 && generateScheduleOutputViewModel.LaborAvail > 0 && (generateScheduleOutputViewModel.rowCount == -1))
                    { //Labor is passed but build hours are failed
                        generateScheduleOutputViewModel.errorMessageArr = "For " + generateScheduleOutputViewModel.BENArr + " No Bays available, SubAssembly,Integration,Test,Post-Test Build hours are zero" + '|' + generateScheduleOutputViewModel.ModSuccess;
                    }
                    else if (generateScheduleOutputViewModel.BayAvail > 0 && generateScheduleOutputViewModel.LaborAvail > 0 && (generateScheduleOutputViewModel.rowCount == -1))
                    { //Build hours only failed
                        generateScheduleOutputViewModel.errorMessageArr = "For " + generateScheduleOutputViewModel.BENArr + " SubAssembly,Integration,Test,Post-Test Build hours are zero" + '|' + generateScheduleOutputViewModel.ModSuccess;
                    }
                    else if ((generateScheduleOutputViewModel.BayAvail == 0) && generateScheduleOutputViewModel.LaborAvail == 0)
                    {
                        generateScheduleOutputViewModel.errorMessageArr = "For " + generateScheduleOutputViewModel.BENArr + " No Bays and Labor available." + '|' + generateScheduleOutputViewModel.ModSuccess;
                    }
                    else if ((generateScheduleOutputViewModel.BayAvail == 0) && generateScheduleOutputViewModel.LaborAvail > 0)
                    {
                        generateScheduleOutputViewModel.errorMessageArr = "For " + generateScheduleOutputViewModel.BENArr + " No Bays available." + '|' + generateScheduleOutputViewModel.ModSuccess;
                    }
                    else if ((generateScheduleOutputViewModel.BayAvail > 0) && generateScheduleOutputViewModel.LaborAvail == 0)
                    {
                        generateScheduleOutputViewModel.errorMessageArr = "For " + generateScheduleOutputViewModel.BENArr + " No Labor available." + '|' + generateScheduleOutputViewModel.ModSuccess;
                    }

                    //Added Newly 
                    else if (generateScheduleOutputViewModel.BayAvail < Iteration && generateScheduleOutputViewModel.LaborAvail < Iteration && (generateScheduleOutputViewModel.rowCount == -1))
                    { //Build hours only failed
                        generateScheduleOutputViewModel.errorMessageArr = "For " + generateScheduleOutputViewModel.BENArr + " SubAssembly,Integration,Test,Post-Test Build hours are zero" + '|' + generateScheduleOutputViewModel.ModSuccess;
                    }
                    else if (generateScheduleOutputViewModel.BayAvail == Iteration && generateScheduleOutputViewModel.LaborAvail < Iteration)
                    { //Build hours only failed
                        generateScheduleOutputViewModel.errorMessageArr = "For " + generateScheduleOutputViewModel.BENArr + " No Labor available." + '|' + generateScheduleOutputViewModel.ModSuccess;
                    }
                    else if (generateScheduleOutputViewModel.BayAvail < Iteration && generateScheduleOutputViewModel.LaborAvail == Iteration)
                    { //Build hours only failed
                        generateScheduleOutputViewModel.errorMessageArr = "For " + generateScheduleOutputViewModel.BENArr + " No Bays available." + '|' + generateScheduleOutputViewModel.ModSuccess;
                    }
                    else if (generateScheduleOutputViewModel.BayAvail < Iteration && generateScheduleOutputViewModel.LaborAvail < Iteration)
                    { //Build hours only failed
                        generateScheduleOutputViewModel.errorMessageArr = "For " + generateScheduleOutputViewModel.BENArr + " No Bays and Labor available." + '|' + generateScheduleOutputViewModel.ModSuccess;
                    }
                    else if ((Convert.ToInt32(generateScheduleOutputViewModel.ModSuccess) > 0) && generateScheduleOutputViewModel.BayAvail == Iteration && generateScheduleOutputViewModel.LaborAvail == Iteration)
                    {
                        generateScheduleOutputViewModel.errorMessageArr = generateScheduleOutputViewModel.errorMessageArr + '|' + generateScheduleOutputViewModel.ModSuccess.ToString();
                    }


                    else if ((Convert.ToInt32(generateScheduleOutputViewModel.ModSuccess) > 0))
                    {
                        generateScheduleOutputViewModel.errorMessageArr = generateScheduleOutputViewModel.errorMessageArr + '|' + generateScheduleOutputViewModel.ModSuccess.ToString();
                    }
                    else if ((Convert.ToInt32(generateScheduleOutputViewModel.ModSuccess) > 0) && (generateScheduleOutputViewModel.rowCount != null && generateScheduleOutputViewModel.rowCount == -1))
                    {//Labor/Bay is fine but all build hrs are zero 
                        generateScheduleOutputViewModel.errorMessageArr = "For " + generateScheduleOutputViewModel.BENArr + " SubAssembly,Integration,Test,Post-Test Build hours are zero" + '|' + generateScheduleOutputViewModel.ModSuccess;
                    }
                }

            }
            else
            {
                generateScheduleOutputViewModel.errorMessageArr = "No Modules Available|-99";
            }
            return generateScheduleOutputViewModel;
        }

        public string GetSortedList(string connString, List<PriorityOrder> PriorityOrder, List<PriorityOrder> RecordTypePriorityOrder, List<PriorityOrder> RevenueTypePriorityOrder)
        {
            DataTable dataTable = new DataTable();
            var priority = "";
            for (int i = 0; i < PriorityOrder.Count; i++)
            {
                if (PriorityOrder[i].Priorities.Equals("Record Type"))
                {
                    priority += "(CASE WHEN (a.RecordType IS NOT NULL AND a.RecordType <> '''') THEN 1 ELSE 2 end), a.RecordType ";
                    if (RecordTypePriorityOrder[0].Priorities.Equals("Forecasted"))
                    {
                        priority += "ASC" + ',';
                    }
                    else
                    {
                        priority += "DESC" + ',';
                    }
                }

                else if (PriorityOrder[i].Priorities.Equals("Revenue Type"))
                {
                    priority += "(CASE WHEN (a.RevenueCode IS NOT NULL AND a.RevenueCode <> '''') THEN 1 ELSE 2 end), a.RevenueCode ";
                    if (RevenueTypePriorityOrder[0].Priorities.Equals("Eval"))
                    {
                        priority += "ASC" + ',';
                    }
                    else
                    {
                        priority += "DESC" + ',';
                    }
                }
                else if (PriorityOrder[i].Priorities.Equals("Priority Date"))
                {
                    PriorityOrder[i].Priorities = "(CASE WHEN (a.PriorityDate IS NOT NULL) THEN 1 ELSE 2 end), a.PriorityDate ASC ";
                    priority += PriorityOrder[i].Priorities + ',';
                }
                else
                {
                    if (PriorityOrder[i].Priorities == "MCSD")
                    {
                        PriorityOrder[i].Priorities = "(CASE WHEN (a.ManufacturingCommitedShipDate IS NOT NULL) THEN 1 ELSE 2 end), a.ManufacturingCommitedShipDate ASC ";
                    }
                    priority += PriorityOrder[i].Priorities + ',';

                }
            }
            priority = priority.Substring(0, priority.Length - 1);
            return priority;
        }


        public DataTable CalculateLeadTime(string connString, long pilotProductID, long? productionPlanID)
        {

            //input -module build schedule 
            //input - total labor hour
            //output - lead time in days
            SqlParameter[] param = {
                        new SqlParameter("@PilotProductId",pilotProductID),
                new SqlParameter("@ProductionPlanID",productionPlanID)
                            };
            DataTable dtLeadTime = SqlHelper.GetDataTable(connString, "uspCalculateLeadTime", param);
            return dtLeadTime;
        }


        public DataTable CalculateLatestStartDate(DataTable ModulesLeadTime, string connString)
        {

            // Description : In order to determine start date of Scheduling.
            //input - priority date , lead time , earliest start date
            // output -  launch date

            //Questions?
            // In the above inputs how to decide which one for launch date Latest one?
            //Exact caluculation logic required,Can you please explain the logic to calculate StartDate?
            //Diffrence between Earliest start date and latest start date?
            //Ans: Yes
            //will get priority date from module table or we will get it from the frontend UI?

            DataTable dtLatestStartDate = SqlHelper.GetDataTable(connString, "uspGetLatestStartDate", null);
            return dtLatestStartDate;
        }


        public void CheckFixtueAvailability()
        {

            //Description :check fixture availability  .

            // input - may come from DB fixture tabels in order to check .

            //output - fixture available or required then method will cater to CheckBayLaborAvailability().

            //Questions:
            //Exact caluculation logic required?

        }


        public DataTable UpdateLeadTime(DataTable ModulesLeadTime, string connString)
        {
            //purpose: checks if there is a holiday within the lead time and then adds extra day(s) to account for the holidays

            //input: lead time(days)

            //output: lead time(days)
            DateTime CurrentDate = DateTime.Now;
            DataTable dtUpdatedLeadTime = new DataTable();
            DataTable dtHolidays = GetHolidayList(connString); //-- Required tabel to store holiday list
            foreach (DataRow row in ModulesLeadTime.Rows)
            {
                int ModuleProcessID = (int)row["ModuleProcessID"];
                SqlParameter[] param = {
                new SqlParameter("@ModuleProcessID",ModuleProcessID)
                 };
                DateTime DateRangeForHoliday = (DateTime)row["DateRangeForHoliday"];
                while (CurrentDate <= DateRangeForHoliday)
                {
                    bool exists = dtHolidays.Select().ToList().Exists(row => (DateTime)row["HolidayDateDaily"] == CurrentDate);
                    if (exists)
                    {

                        dtUpdatedLeadTime = SqlHelper.GetDataTable(connString, "uspUpdateLeadTime", param);                   
                    }
                    CurrentDate = CurrentDate.AddDays(1);
                }

            }
            return ModulesLeadTime;
        }

        public DataTable GetHolidayList(string connString)
        {

            // Description : Get holiday list from tabel to check . 
            //input: need input from DB table maintain off list in one table
            //output: lead time(days)

            // question: how to get holiday list (table/or else)?
            DataTable dtHolidays = SqlHelper.GetDataTable(connString, "uspGetHolidayList", null);
            return dtHolidays;
        }


        public List<SchedulesViewModel> GetProductionPlanData(string connString, int plantId)
        {
            dataTable = new DataTable();
            SqlParameter[] param = {
                new SqlParameter("@plantID",plantId),
                };
            List<SchedulesViewModel> ProductionPlanData = new List<SchedulesViewModel>();
            dataTable = SqlHelper.GetDataTable(connString, "uspGetProductionPlanData", param);
            try
            {
                ProductionPlanData = dataTable.AsEnumerable().Select(dtRow => new SchedulesViewModel()
                {
                    PlantID = dtRow.Field<long?>("PlantID"),
                    ProductionPlanID = dtRow.Field<long?>("ProductionPlanID"),
                    PlanName = dtRow.Field<string>("ProductionPlanName"),
                    PlanType = dtRow.Field<string>("PlanType"),
                    DataRefreshDate = dtRow.Field<DateTime?>("DataRefreshDate"),
                    UserID = dtRow.Field<string>("UserID"),
                    Description = dtRow.Field<string>("DecriptionScenario"),
                    ModifiedDate = dtRow.Field<DateTime?>("ModifiedDate"),
                }).ToList();
            }
            catch (Exception ex)
            {
            }
            return ProductionPlanData;
        }


        public int DeleteProductionPlanData(string connString, int ProductionPlanID)
        {
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@productionPlanID",ProductionPlanID)
                    };
                return SqlHelper.ExecuteNonQueryNoOutParam(connString, "uspDeleteProductionPlanData", param);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int RenameProductionPlanData(string connString, SchedulesViewModel schedules)
        {
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@ProductionPlanName",schedules.PlanName),
                    new SqlParameter("@productionPlanID",schedules.ProductionPlanID)
                    };
                return SqlHelper.ExecuteNonQueryNoOutParam(connString, "uspRenameProductionPlanData", param);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int DuplicateProductionPlanData(string connString, SchedulesViewModel schedules)
        {
            var resultCount = 0;
            var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            SqlParameter[] param = {
                new SqlParameter("@plantID",schedules.PlantID),
                new SqlParameter("@productionPlanID",schedules.ProductionPlanID),
                new SqlParameter("@productionPlanName",schedules.PlanName),
                new SqlParameter("@planType",schedules.PlanType),
                new SqlParameter("@userID",schedules.UserID),
                new SqlParameter("@dataRefreshDate",schedules.DataRefreshDate),
                new SqlParameter("@lastmodified",schedules.ModifiedDate),
                new SqlParameter("@description",schedules.Description),
                new SqlParameter("@ModifiedById",schedules.ModifiedById),
                outParam
                };

            resultCount = SqlHelper.ExecuteNonQuery(connString, "uspDuplicateProductionPlan", param);
            return resultCount;
        }
        public int PushToProduction(string connString, SchedulesViewModel schedules)
        {
            var resultCount = 0;
            var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            SqlParameter[] param = {
                new SqlParameter("@plantID",schedules.PlantID),
                new SqlParameter("@productionPlanName",schedules.PlanName),
                new SqlParameter("@productionPlanID",schedules.ProductionPlanID),
                new SqlParameter("@userID",schedules.UserID),
                new SqlParameter("@dataRefreshDate",schedules.DataRefreshDate),
                new SqlParameter("@lastmodified",schedules.ModifiedDate),
                new SqlParameter("@ModifiedById",schedules.ModifiedById),
                outParam
                };

            resultCount = SqlHelper.ExecuteNonQuery(connString, "uspPushToProductionPlan", param);
            return resultCount;
        }
        public List<SchedulesViewModel> GetOtherUserPlanData(string connString)
        {
            dataTable = new DataTable();
            List<SchedulesViewModel> OtherUserPlansData = new List<SchedulesViewModel>();
            dataTable = SqlHelper.GetDataTable(connString, "uspGetOtherUserPlansData", null);
            try
            {
                OtherUserPlansData = dataTable.AsEnumerable().Select(dtRow => new SchedulesViewModel()
                {
                    PlantID = dtRow.Field<long?>("PlantID"),
                    ProductionPlanID = dtRow.Field<long?>("ProductionPlanID"),
                    PlanName = dtRow.Field<string>("ProductionPlanName"),
                    PlanType = dtRow.Field<string>("PlanType"),
                    DataRefreshDate = dtRow.Field<DateTime?>("DataRefreshDate"),
                    UserID = dtRow.Field<string>("UserID"),
                    // Description = dtRow.Field<string>("DecriptionScenario"),
                    ModifiedDate = dtRow.Field<DateTime?>("ModifiedDate"),
                    PlantName = dtRow.Field<string>("PlantName"),
                }).ToList();
            }
            catch (Exception ex)
            {
            }
            return OtherUserPlansData;
        }


        public string AddModuleProductionPlan(string connString, SchedulesViewModel schedulesViewModel)
        {
            try
            {
                var resultCount = 0;
                long ProductionPlanID = 0;
                if (schedulesViewModel.ProductionPlanID == 0)
                {
                    ProductionPlanID = AddProductionPlan(connString, schedulesViewModel);
                }
                else
                {
                    ProductionPlanID = schedulesViewModel.ProductionPlanID.Value;
                }
                for (int i = 0; i < schedulesViewModel.PilotProductIds.Length; i++)
                {
                    var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                    {
                        Direction = ParameterDirection.Output
                    };
                    SqlParameter[] param = {
                        new SqlParameter("@pilotProductID", schedulesViewModel.PilotProductIds[i]),
                        new SqlParameter("@productionPlanID", ProductionPlanID),
                        outParam
                        };
                    resultCount = SqlHelper.ExecuteNonQuery(connString, "uspAddModuleIntoPlan", param);
                }
                return resultCount.ToString() + ',' + ProductionPlanID;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public int DeleteModuleFromSchedule(string connString, long PilotProductId, int ProductionPlanID)
        {
            SqlParameter[] param = {
                new SqlParameter("@pilotProductID",PilotProductId),
                new SqlParameter("@productionPlanID",ProductionPlanID)
                };

            return SqlHelper.ExecuteNonQueryNoOutParam(connString, "uspDeleteModuleFromSchedule", param);
        }
        public int DeleteModuleAdjustSchedule(string connString, long PilotProductId, int ProductionPlanID)
        {
            SqlParameter[] param = {
                new SqlParameter("@pilotProductID",PilotProductId),
                new SqlParameter("@productionPlanID",ProductionPlanID)
                };

            return SqlHelper.ExecuteNonQueryNoOutParam(connString, "uspDeleteModuleAdjustSchedule", param);
        }

        public List<CompareSummaryReport> GetCompareSummaryReport(string connString, int plantId, int PlanAProductionPlanID, int PlanBProductionPlanID)
        {
            dataTable = new DataTable();
            SqlParameter[] param = {
                    new SqlParameter("@plantID",plantId),
                    new SqlParameter("@FirstProductionPlanID",PlanAProductionPlanID),
                    new SqlParameter("@SecondProductionPlanID",PlanBProductionPlanID),
                    };
            List<CompareSummaryReport> CompareSummaryReportData = new List<CompareSummaryReport>();
            dataTable = SqlHelper.GetDataTable(connString, "uspGetCompareSummaryReport", param);
            try
            {
                CompareSummaryReportData = dataTable.AsEnumerable().Select(dtRow => new CompareSummaryReport()
                {
                    Descriptions = dtRow.Field<string>("Descriptions"),
                    planAUtilization = dtRow.Field<string>("planAUtilization"),
                    planBUtilization = dtRow.Field<string>("planBUtilization"),
                    Comparison = dtRow.Field<string>("Comparison"),
                }).ToList();
            }
            catch (Exception ex)
            {                
            }
            return CompareSummaryReportData;
        }

        public string GetCompareModuleViewData(string connString, string interval, int PlantID, string StartDate, int PlanAProductionPlanID, int PlanBProductionPlanID)
        {
            try
            {
                DataTable dataTable;
                DateTime Datedaily;
                string CompareModuleDataList = null;
                SqlParameter[] param = {
                    new SqlParameter("@Interval",interval),
                    new SqlParameter("@planID",PlantID),
                    new SqlParameter("@StartDate",Convert.ToDateTime(StartDate)),
                    new SqlParameter("@PlanAProductionPlanID", PlanAProductionPlanID),
                    new SqlParameter("@PlanBProductionPlanID", PlanBProductionPlanID),
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetCompareModuleViewData", param);
                var DistinctList = (from x in dataTable.AsEnumerable()
                                    group x by (DateTime)x["Datedaily"] into g
                                    select g).ToList();
                DataTable copyDataTable = copyDataTable = dataTable.Copy();
                string[] ColumnsToBeDeleted = { "Datedaily", "baysbuilhours", "baysbuilhoursOnHover", "ModuleProcessID" };
                foreach (string ColName in ColumnsToBeDeleted)
                {
                    if (copyDataTable.Columns.Contains(ColName))
                        copyDataTable.Columns.Remove(ColName);
                }
                if (copyDataTable.Rows.Count > 0)
                {
                    DataTable DistinctListWithoutDateDaily = copyDataTable.AsEnumerable().Distinct(DataRowComparer.Default).CopyToDataTable<DataRow>();
                    for (int j = 0; j < DistinctListWithoutDateDaily.Rows.Count; j++)
                    {
                        var PilotProductID = Convert.ToInt32(DistinctListWithoutDateDaily.Rows[j]["PilotProductID"]);
                        var ProductionPlanID = Convert.ToInt32(DistinctListWithoutDateDaily.Rows[j]["ProductionPlanID"]);
                        for (int i = 0; i < DistinctList.Count; i++)
                        {
                            Datedaily = Convert.ToDateTime(DistinctList[i].Key);
                            bool contains = dataTable.AsEnumerable().Where(c => (c.Field<Int64?>("PilotProductID") == PilotProductID && c.Field<Int64?>("ProductionPlanID") == ProductionPlanID)).Any(row => Datedaily == row.Field<DateTime?>("Datedaily"));
                            if (!contains)
                            {
                                DataRow dr = dataTable.NewRow();
                                dr["Datedaily"] = Datedaily; //string
                                dr["PilotProductID"] = PilotProductID; //string
                                dr["ProductionPlanName"] = DistinctListWithoutDateDaily.Rows[j]["ProductionPlanName"]; //string
                                dr["SalesPriority"] = DistinctListWithoutDateDaily.Rows[j]["SalesPriority"];
                                dr["FCID"] = DistinctListWithoutDateDaily.Rows[j]["FCID"];
                                dr["PilotSerialNumber"] = DistinctListWithoutDateDaily.Rows[j]["PilotSerialNumber"];
                                dr["PilotRisk"] = DistinctListWithoutDateDaily.Rows[j]["PilotRisk"];
                                dr["PlannedRiskLevel"] = DistinctListWithoutDateDaily.Rows[j]["PlannedRiskLevel"];
                                dr["AlreadyScheduled"] = DistinctListWithoutDateDaily.Rows[j]["AlreadyScheduled"];
                                dr["DayShiftOnly"] = DistinctListWithoutDateDaily.Rows[j]["DayShiftOnly"];
                                dr["NoCapacity"] = DistinctListWithoutDateDaily.Rows[j]["NoCapacity"];
                                dr["RecordType"] = DistinctListWithoutDateDaily.Rows[j]["RecordType"];
                                dr["RevenueType"] = DistinctListWithoutDateDaily.Rows[j]["RevenueType"];
                                dr["ToolTypeName"] = DistinctListWithoutDateDaily.Rows[j]["ToolTypeName"];
                                dr["ToolTypeID"] = DistinctListWithoutDateDaily.Rows[j]["ToolTypeID"];
                                dr["ProductName"] = DistinctListWithoutDateDaily.Rows[j]["ProductName"];
                                dr["BuildTypeID"] = DistinctListWithoutDateDaily.Rows[j]["BuildTypeID"];
                                dr["BuildName"] = DistinctListWithoutDateDaily.Rows[j]["BuildName"];
                                dr["CustomerID"] = DistinctListWithoutDateDaily.Rows[j]["CustomerID"];
                                dr["CompleteATP"] = DistinctListWithoutDateDaily.Rows[j]["CompleteATP"];
                                dr["ModuleProcessIdForSubassembly"] = DistinctListWithoutDateDaily.Rows[j]["ModuleProcessIdForSubassembly"];
                                dr["SubassemblyBuildHours"] = DistinctListWithoutDateDaily.Rows[j]["SubassemblyBuildHours"];
                                dr["ModuleProcessIdForIntegration"] = DistinctListWithoutDateDaily.Rows[j]["ModuleProcessIdForIntegration"]; dr["ModuleProcessIdForIntegration"] = DistinctListWithoutDateDaily.Rows[j]["ModuleProcessIdForIntegration"];
                                dr["IntegrationBuildHours"] = DistinctListWithoutDateDaily.Rows[j]["IntegrationBuildHours"];
                                dr["ModuleProcessIdForTest"] = DistinctListWithoutDateDaily.Rows[j]["ModuleProcessIdForTest"];
                                dr["TestBuildHours"] = DistinctListWithoutDateDaily.Rows[j]["TestBuildHours"];
                                dr["ModuleProcessIdForPostTest"] = DistinctListWithoutDateDaily.Rows[j]["ModuleProcessIdForPostTest"];
                                dr["PostTestBuildHours"] = DistinctListWithoutDateDaily.Rows[j]["PostTestBuildHours"];
                                dr["TotalLaborHour"] = DistinctListWithoutDateDaily.Rows[j]["TotalLaborHour"];
                                dr["EarliestStartDate"] = DistinctListWithoutDateDaily.Rows[j]["EarliestStartDate"];
                                dr["MaterialReadiness"] = DistinctListWithoutDateDaily.Rows[j]["MaterialReadiness"];
                                dr["POABOMReleaseDate"] = DistinctListWithoutDateDaily.Rows[j]["POABOMReleaseDate"];
                                dr["TransitionDate"] = DistinctListWithoutDateDaily.Rows[j]["TransitionDate"];
                                dr["LPRPlannedLaunchP09"] = DistinctListWithoutDateDaily.Rows[j]["LPRPlannedLaunchP09"];
                                dr["TransitionDate"] = DistinctListWithoutDateDaily.Rows[j]["TransitionDate"];
                                dr["ProjectedLaunch"] = DistinctListWithoutDateDaily.Rows[j]["ProjectedLaunch"];
                                dr["ActualLaunch"] = DistinctListWithoutDateDaily.Rows[j]["ActualLaunch"];
                                dr["CommitLaunch"] = DistinctListWithoutDateDaily.Rows[j]["CommitLaunch"];
                                dr["CommittedIntegrationStart"] = DistinctListWithoutDateDaily.Rows[j]["CommittedIntegrationStart"];
                                dr["CommittedTestStart"] = DistinctListWithoutDateDaily.Rows[j]["CommittedTestStart"];
                                dr["CommitedManufacturingComplete"] = DistinctListWithoutDateDaily.Rows[j]["CommitedManufacturingComplete"];
                                dr["PilotManufacturingCommitedShipDate"] = DistinctListWithoutDateDaily.Rows[j]["PilotManufacturingCommitedShipDate"];
                                dr["CustomerRequestDate"] = DistinctListWithoutDateDaily.Rows[j]["CustomerRequestDate"];
                                dr["CRDEsc"] = DistinctListWithoutDateDaily.Rows[j]["CRDEsc"];
                                dr["CRDGapDays"] = DistinctListWithoutDateDaily.Rows[j]["CRDGapDays"];
                                dr["SalesOpsRequestDate"] = DistinctListWithoutDateDaily.Rows[j]["SalesOpsRequestDate"];
                                dr["TargetShipDate"] = DistinctListWithoutDateDaily.Rows[j]["TargetShipDate"];
                                dr["ManufacturingCommitedShipDate"] = DistinctListWithoutDateDaily.Rows[j]["ManufacturingCommitedShipDate"];
                                dr["Note"] = DistinctListWithoutDateDaily.Rows[j]["Note"];
                                dr["BEN"] = DistinctListWithoutDateDaily.Rows[j]["BEN"];
                                dr["POM"] = DistinctListWithoutDateDaily.Rows[j]["POM"];
                                dr["ActualDMRF"] = DistinctListWithoutDateDaily.Rows[j]["ActualDMRF"];
                                dr["PlannedDMRF"] = DistinctListWithoutDateDaily.Rows[j]["PlannedDMRF"];
                                dr["buildStyleName"] = DistinctListWithoutDateDaily.Rows[j]["buildStyleName"];
                                dr["ProjectedIntegrationStart"] = DistinctListWithoutDateDaily.Rows[j]["ProjectedIntegrationStart"];
                                dr["ProjectedTestStart"] = DistinctListWithoutDateDaily.Rows[j]["ProjectedTestStart"];
                                dr["ProjectedTestComplete"] = DistinctListWithoutDateDaily.Rows[j]["ProjectedTestComplete"];
                                dr["ProjectedManufacturingComplete"] = DistinctListWithoutDateDaily.Rows[j]["ProjectedManufacturingComplete"];
                                dr["ModuleProcessID"] = 0; //string
                                dr["baysbuilhours"] = "/";
                                dr["baysbuilhoursOnHover"] = ""; //string
                                dr["CapacityPlanningColor"] = DistinctListWithoutDateDaily.Rows[j]["CapacityPlanningColor"];
                                dr["PlanofRecord"] = DistinctListWithoutDateDaily.Rows[j]["PlanofRecord"];
                                dr["T09Comment"] = DistinctListWithoutDateDaily.Rows[j]["T09Comment"];
                                dataTable.Rows.Add(dr);
                            }
                        }
                    }
                    var MPSData = dataTable.Rows.Cast<DataRow>()
                    .OrderBy(r => r.Field<DateTime>("Datedaily")).GroupBy(x => new
                    {
                        PilotProductID = x["PilotProductID"],
                        SalesPriority = x["SalesPriority"],
                        ProductionPlanName = x["ProductionPlanName"],
                        FCID = x["FCID"],
                        PilotSerialNumber = x["PilotSerialNumber"],
                        PilotRisk = x["PilotRisk"],
                        PlannedRiskLevel = x["PlannedRiskLevel"],
                        AlreadyScheduled = x["AlreadyScheduled"],
                        DayShiftOnly = x["DayShiftOnly"],
                        NoCapacity = x["NoCapacity"],
                        RecordType = x["RecordType"],
                        RevenueType = x["RevenueType"],
                        ToolTypeName = x["ToolTypeName"],
                        ToolTypeID = x["ToolTypeID"],
                        ProductName = x["ProductName"],
                        BuildTypeID = x["BuildTypeID"],
                        BuildName = x["BuildName"],
                        CustomerID = x["CustomerID"],
                        CompleteATP = x["CompleteATP"],
                        ModuleProcessIdForSubassembly = x["ModuleProcessIdForSubassembly"],
                        SubassemblyBuildHours = x["SubassemblyBuildHours"],
                        ModuleProcessIdForIntegration = x["ModuleProcessIdForIntegration"],
                        IntegrationBuildHours = x["IntegrationBuildHours"],
                        ModuleProcessIdForTest = x["ModuleProcessIdForTest"],
                        TestBuildHours = x["TestBuildHours"],
                        ModuleProcessIdForPostTest = x["ModuleProcessIdForPostTest"],
                        PostTestBuildHours = x["PostTestBuildHours"],
                        TotalLaborHour = x["TotalLaborHour"],
                        EarliestStartDate = x["EarliestStartDate"],
                        MaterialReadiness = x["MaterialReadiness"],
                        POABOMReleaseDate = x["POABOMReleaseDate"],
                        TransitionDate = x["TransitionDate"],
                        LPRPlannedLaunchP09 = x["LPRPlannedLaunchP09"],
                        ProjectedLaunch = x["ProjectedLaunch"],
                        ActualLaunch = x["ActualLaunch"],
                        CommitLaunch = x["CommitLaunch"],
                        CommittedIntegrationStart = x["CommittedIntegrationStart"],
                        CommittedTestStart = x["CommittedTestStart"],
                        CommitedManufacturingComplete = x["CommitedManufacturingComplete"],
                        PilotManufacturingCommitedShipDate = x["PilotManufacturingCommitedShipDate"],
                        CustomerRequestDate = x["CustomerRequestDate"],
                        CRDEsc = x["CRDEsc"],
                        CRDGapDays = x["CRDGapDays"],
                        SalesOpsRequestDate = x["SalesOpsRequestDate"],
                        TargetShipDate = x["TargetShipDate"],
                        ManufacturingCommitedShipDate = x["ManufacturingCommitedShipDate"],
                        Note = x["Note"],
                        BEN = x["BEN"],
                        POM = x["POM"],
                        ActualDMRF = x["ActualDMRF"],
                        PlannedDMRF = x["PlannedDMRF"],
                        buildStyleName = x["buildStyleName"],
                        ProjectedIntegrationStart = x["ProjectedIntegrationStart"],
                        ProjectedTestStart = x["ProjectedTestStart"],
                        ProjectedTestComplete = x["ProjectedTestComplete"],
                        ProjectedManufacturingComplete = x["ProjectedManufacturingComplete"],
                        CapacityPlanningColor = x["CapacityPlanningColor"],
                        PlanofRecord = x["PlanofRecord"],
                        T09Comment = x["T09Comment"]
                    })
                    .Select(x => new
                    {
                        ProductName = x.Key,
                        BuildHoursDates = x.Select(y => new
                        {
                            baysbuilhours = y.Field<string>("baysbuilhours"),
                            baysbuilhoursOnHover = y.Field<string>("baysbuilhoursOnHover"),
                            ModuleProcessID = y.Field<Int32>("ModuleProcessID"),
                            Datedaily = y.Field<DateTime>("Datedaily")
                        })
                    }).ToList(); CompareModuleDataList = Newtonsoft.Json.JsonConvert.SerializeObject(MPSData);
                }
                return CompareModuleDataList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public List<ScheduleModuleProcess> GetModuleProcess(string connString, long pilotProductID, int productionPlanID)
        {
            dataTable = new DataTable();
            SqlParameter[] param = {
                    new SqlParameter("@pilotProductID",pilotProductID),
                    new SqlParameter("@productionPlanID",productionPlanID),
                    };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetModuleProcess", param);

            List<ScheduleModuleProcess> ModuleProcess = dataTable.AsEnumerable().Select(dtRow => new ScheduleModuleProcess()
            {
                ModuleProcessID = Convert.ToInt32(dtRow["ModuleProcessID"]),
                ModuleProcess = Convert.ToString(dtRow["ModuleProcess"])
            }).ToList();
            return ModuleProcess;
        }
    }
}

