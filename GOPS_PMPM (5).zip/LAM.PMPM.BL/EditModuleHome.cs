﻿using LAM.PMPM.DAL;
using LAM.PMPM.Model;
using LAM.PMPM.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace LAM.PMPM.BL
{
    public class EditModuleHome
    {


        public List<SchedulePriorityRevenueType> GetRevenueTypeDDL(string connString)
        {
            try
            {
                DataTable dataTable;
                dataTable = SqlHelper.GetDataTable(connString, "uspGetRevenueTypeDDL", null);
                List<SchedulePriorityRevenueType> revenueList = dataTable.AsEnumerable().Select(dtRow => new SchedulePriorityRevenueType()
                {
                    SchedulePriorityRevenueTypeID = dtRow.Field<int>("SchedulePriorityrevenueTypeID"),
                    RevenueType = dtRow.Field<string>("RevenueType")

                }).ToList();
                return revenueList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }



        public List<SchedulePriorityRecordType> GetRecordTypeDDL(string connString)
        {
            try
            {
                DataTable dataTable;
                dataTable = SqlHelper.GetDataTable(connString, "uspGetRecordTypeDDL", null);
                List<SchedulePriorityRecordType> recordList = dataTable.AsEnumerable().Select(dtRow => new SchedulePriorityRecordType()
                {
                    SchedulePriorityRecordTypeID = dtRow.Field<int>("SchedulePriorityRecordTypeID"),
                    RecordType = dtRow.Field<string>("RecordType")

                }).ToList();
                return recordList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<MasterRecords> GetModuleColorDDL(string connString)
        {
            DataTable dataTable;
            dataTable = SqlHelper.GetDataTable(connString, "uspGetModuleColorDDL", null);
            List<MasterRecords> masterRecords = dataTable.AsEnumerable().Select(dtRow => new MasterRecords()
            {
                MasterRecordID = dtRow.Field<long>("MasterRecordID"),
                MasterRecordName = dtRow.Field<string>("MasterRecordName"),
                Value = dtRow.Field<string>("Value")
            }).ToList();
            return masterRecords;
        }

        public List<CustomerViewModel> GetCustomerDDL(string connString)
        {
            DataTable dataTable;
            dataTable = SqlHelper.GetDataTable(connString, "uspGetCustomerDDL", null);
            List<CustomerViewModel> masterRecords = dataTable.AsEnumerable().Select(dtRow => new CustomerViewModel()
            {

                Customer = dtRow.Field<string>("Customer"),

            }).ToList();
            return masterRecords;
        }


        public List<ModulesSummaryWip> GetPilotRiskDDL(string connString)
        {
            DataTable dataTable;
            dataTable = SqlHelper.GetDataTable(connString, "uspGetPilotRiskDDL", null);
            List<ModulesSummaryWip> pilotRisk = dataTable.AsEnumerable().Select(dtRow => new ModulesSummaryWip()
            {

                pilotRisk = dtRow.Field<string>("PilotRiskLevel"),

            }).ToList();
            return pilotRisk;
        }


        public List<CustomerViewModel> GetProductionStatusDDL(string connString)
        {
            DataTable dataTable;
            dataTable = SqlHelper.GetDataTable(connString, "uspGetProductionStatusDDL", null);
            List<CustomerViewModel> pilotRisk = dataTable.AsEnumerable().Select(dtRow => new CustomerViewModel()
            {

                ProductionStatus = dtRow.Field<string>("ProductionStatus"),

            }).ToList();
            return pilotRisk;
        }

        public int UpdateMyModule(string connString, EditModuleViewModel modules)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@PilotProductID", modules.PilotProductID),
                    new SqlParameter("@BuildStyleId",  modules.BuildStyleId),
                    new SqlParameter("@ProductionStatus",  modules.ProductionStatus),
                    new SqlParameter("@PilotRiskLevel ",  modules.PilotRiskLevel ),
                    new SqlParameter("@BuildTypeID",  modules.BuildTypeID),
                    new SqlParameter("@ToolTypeID",  modules.ToolTypeID),
                    new SqlParameter("@ProductGroupId ",  modules.ProductGroupId ),
                    new SqlParameter("@Customer",  modules.Customer),
                    new SqlParameter("@RecordType",  modules.RecordType),
                    new SqlParameter("@CapacityPlanningColor",  modules.CapacityPlanningColor),
                    new SqlParameter("@ProductManager",  modules.ProductManager),
                    new SqlParameter("@ProgramManager",  modules.ProgramManager),
                    new SqlParameter("@SystemProjectManager",  modules.SystemProjectManager),
                    new SqlParameter("@Scheduler",  modules.Scheduler),
                    new SqlParameter("@ManufacturingEngineer",  modules.ManufacturingEngineer),
                    new SqlParameter("@TestEngineer",  modules.TestEngineer),
                    new SqlParameter("@ProcessModule",  modules.ProcessModule)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspEditMyModule", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public EditModuleViewModel GetMyModuleSummary(string connString, int pilotProductID)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
               new SqlParameter("@PilotProductID",pilotProductID)
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetMyModuleSummaryById", param);

            EditModuleViewModel masterRecords = dataTable.AsEnumerable().Select(dtRow => new EditModuleViewModel()
            {
                PilotProductID = dtRow.Field<long>("PilotProductID"),
                BuildStyleId = dtRow.Field<int>("BuildStyleId"),
                BuildStyle = dtRow.Field<string>("BuildStyle"),
                BEN = dtRow.Field<string>("BEN"),
                PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                FCID = dtRow.Field<string>("FCID"),
                Status = dtRow.Field<string>("Status"),
                ProductionStatus = dtRow.Field<string>("ProductionStatus"),
                PilotRiskLevel = dtRow.Field<string>("PilotRiskLevel"),
                BuildTypeID = dtRow.Field<long>("BuildTypeID"),
                BuildTypeName = dtRow.Field<string>("BuildName"),
                MPSName = dtRow.Field<string>("MPSName"),
                ToolTypeID = dtRow.Field<long>("ToolTypeID"),
                ToolTypeName = dtRow.Field<string>("ToolTypeName"),
                ProductGroupId = dtRow.Field<long?>("ProductGroupId"),
                ProductName = dtRow.Field<string>("ProductName"),
                Customer = dtRow.Field<string>("Customer"),
                RecordType = dtRow.Field<string>("RecordType"),
                RevenueCode = dtRow.Field<string>("RevenueCode"),
                CapacityPlanningColor = dtRow.Field<string>("CapacityPlanningColor"),
                PurchaseOrderNumber = dtRow.Field<string>("PurchaseOrderNumber"),
                SalesOrderNumber = dtRow.Field<string>("SalesOrderNumber"),
                BOMNumber = dtRow.Field<string>("BOMNumber"),
                ProductManager = dtRow.Field<string>("ProductManager"),
                ProgramManager = dtRow.Field<string>("ProgramManager"),
                SystemProjectManager = dtRow.Field<string>("SystemProjectManager"),
                Scheduler = dtRow.Field<string>("Scheduler"),
                ManufacturingEngineer = dtRow.Field<string>("ManufacturingEngineer"),
                TestEngineer = dtRow.Field<string>("TestEngineer"),
                Note = dtRow.Field<string>("Note"),
                DivisionID = dtRow.Field<long?>("DivisionID"),
                DivisionName = dtRow.Field<string>("DivisionName"),
                PartNumber = dtRow.Field<string>("PartNumber"),
                SerialNum = dtRow.Field<string>("SerialNum"),
                Qty = dtRow.Field<int?>("Qty"),
                DemandTypeID = dtRow.Field<long?>("DemandTypeID"),
                partDescription = dtRow.Field<string>("partDescription"),
                PCWOReleased = dtRow.Field<bool?>("PCWOReleased"),
                hot = dtRow.Field<bool?>("hot"),
                Rework = dtRow.Field<bool?>("Rework"),
                SpclProcess = dtRow.Field<bool?>("SpclProcess"),
                PlannerName = dtRow.Field<string>("PlannerName"),
                EngineeringPOC = dtRow.Field<string>("EngineeringPOC"),
                TechBuild = dtRow.Field<string>("TechBuild"),
                TechTest = dtRow.Field<string>("TechTest"),
                Auditor = dtRow.Field<string>("Auditor"),
                ProcessModule = dtRow.Field<int?>("ProcessModule")

            }).FirstOrDefault();
            return masterRecords;
        }

        public EditModScheduleViewModel GetEditModScheduledSummary(string connString, int pilotProductID, int plantID, DateTime todaydate)
        {


            DataSet dataSet;

            SqlParameter[] param =
            {
               new SqlParameter("@PilotProductID",pilotProductID),
               new SqlParameter("@PlantID",plantID),
            };

            Regex rg = new Regex(@"\d+");

            dataSet = SqlHelper.GetDataSet(connString, "uspGetEditModScheduledSummary", param);

            DataTable dataTable = dataSet.Tables[0];

            EditModScheduleViewModel EditScheduledSummary = dataTable.AsEnumerable().Select(dtRow => new EditModScheduleViewModel()
            {
                PilotProductID = dtRow.Field<long?>("PilotProductID"),
                InWIP = dtRow.Field<bool?>("InWIP"),

                CommitLaunch = dtRow.Field<DateTime?>("CommitLaunch"),
                CommittedIntegrationStart = dtRow.Field<DateTime?>("CommittedIntegrationStart"),
                CommittedTestStart = dtRow.Field<DateTime?>("CommittedTestStart"),
                CommittedTestComplete = dtRow.Field<DateTime?>("CommittedTestComplete"),
                CommitedManufacturingComplete = dtRow.Field<DateTime?>("CommitedManufacturingComplete"),

                ProjectedLaunch = dtRow.Field<DateTime?>("ProjectedLaunch"),
                ProjectedIntegrationStart = dtRow.Field<DateTime?>("ProjectedIntegrationStart"),
                ProjectedTestStart = dtRow.Field<DateTime?>("ProjectedTestStart"),
                ProjectedTestComplete = dtRow.Field<DateTime?>("ProjectedTestComplete"),
                ProjectedManufacturingComplete = dtRow.Field<DateTime?>("ProjectedManufacturingComplete"),
                ProjectedCrateComplete = dtRow.Field<DateTime?>("ProjectedCrateComplete"),

                PlannedLaunch = dtRow.Field<DateTime?>("PlannedLaunch"),
                PlannedIntegrationStart = dtRow.Field<DateTime?>("PlannedIntegrationStart"),
                PlannedTestStart = dtRow.Field<DateTime?>("PlannedTestStart"),
                PlannedTestComplete = dtRow.Field<DateTime?>("PlannedTestComplete"),
                PlannedManufacturingComplete = dtRow.Field<DateTime?>("PlannedManufacturingComplete"),
                PlannedCrateComplete = dtRow.Field<DateTime?>("PlannedCrateComplete"),

                ActualLaunch = dtRow.Field<DateTime?>("ActualLaunch"),
                ActualIntegrationStart = dtRow.Field<DateTime?>("ActualIntegrationStart"),
                ActualTestStart = dtRow.Field<DateTime?>("ActualTestStart"),
                ActualTestComplete = dtRow.Field<DateTime?>("ActualTestComplete"),
                ActualManufacturingComplete = dtRow.Field<DateTime?>("ActualManufacturingComplete"),

                ActualIntegrationStartManual = dtRow.Field<DateTime?>("ActualIntegrationStartManual"),
                ActualTestStartManual = dtRow.Field<DateTime?>("ActualTestStartManual"),
                ActualTestCompleteManual = dtRow.Field<DateTime?>("ActualTestCompleteManual"),
                ActualManufacturingCompleteManual = dtRow.Field<DateTime?>("ActualManufacturingCompleteManual"),

                ActualCrateComplete = dtRow.Field<DateTime?>("ActualCrateComplete"),

                IdleTestDay = dtRow.Field<int?>("IdleTestDay"),
                PostTestDays = dtRow.Field<int?>("PostTestDays"),
                TargetTestDays = dtRow.Field<int?>("TargetTestDays"),

                TargetShipDate = dtRow.Field<DateTime?>("TargetShipDate"),
                ManufacturingCommitedShipDate = dtRow.Field<DateTime?>("ManufacturingCommitedShipDate"),
                CustomerRequestDate = dtRow.Field<DateTime?>("CustomerRequestDate"),
                EarliestStartDate = dtRow.Field<DateTime?>("EarliestStartDate"),

                NoCapacity = dtRow.Field<bool?>("NoCapacity"),
                BuildScheduleId = dtRow.Field<long?>("BuildScheduleId"),
                BuildScheduleName = dtRow.Field<string>("BuildScheduleName"),
                ProductionStatus = dtRow.Field<string>("ProductionStatus"),

                LaunchMissCategory = dtRow.Field<string>("LaunchMissCategory"),
                LaunchMissCategoryId = dtRow.Field<long?>("LaunchMissCategoryId"),
                LaunchMissReason = dtRow.Field<string>("LaunchMissReason"),

                IntegrationMissCategory = dtRow.Field<string>("IntegrationMissCategory"),
                IntegrationMissCategoryId = dtRow.Field<long?>("IntegrationMissCategoryId"),
                IntegrationMissReason = dtRow.Field<string>("IntegrationMissReason"),

                TestCompleteMissCategory = dtRow.Field<string>("TestCompleteMissCategory"),
                TestCompleteMissCategoryId = dtRow.Field<long?>("TestCompleteMissCategoryId"),
                TestCompleteMissReason = dtRow.Field<string>("TestCompleteMissReason"),

                TeststartMissCategory = dtRow.Field<string>("TeststartMissCategory"),
                TeststartMissCategoryId = dtRow.Field<long?>("TeststartMissCategoryId"),
                TeststartMissReason = dtRow.Field<string>("TeststartMissReason"),

                MfgCompleteMissCategory = dtRow.Field<string>("MfgCompleteMissCategory"),
                MfgCompleteMissCategoryId = dtRow.Field<long?>("MfgCompleteMissCategoryId"),
                MfgCompleteMissReason = dtRow.Field<string>("MfgCompleteMissReason"),

                PilotManufacturingCommitedShipDate = dtRow.Field<DateTime?>("PilotManufacturingCommitedShipDate")
            }).FirstOrDefault();

            List<OperationDateModel> operationDateModel = dataSet.Tables[1].AsEnumerable().Select(dtRow => new OperationDateModel()
            {
                PilotProductID = dtRow.Field<long?>("PilotProductID"),
                OperationID = dtRow.Field<long?>("OperationID"),
                OPDescription = dtRow.Field<string>("OPDescription"),
                OpOrder = string.IsNullOrEmpty(dtRow.Field<string>("OPDescription")) ? 99999 : string.IsNullOrEmpty(rg.Match(dtRow.Field<string>("OPDescription")).Value.Trim()) ? 99999 : Convert.ToInt32(rg.Match(dtRow.Field<string>("OPDescription")).Value),
                ZoneID = dtRow.Field<long?>("ZoneID"),
                ZoneDescription = dtRow.Field<string>("ZoneDescription"),
                ZoneName = dtRow.Field<string>("ZoneName"),
                ZoneOrder = string.IsNullOrEmpty(dtRow.Field<string>("ZoneDescription")) ? 99999 : string.IsNullOrEmpty(rg.Match(dtRow.Field<string>("ZoneDescription")).Value.Trim()) ? 99999 : Convert.ToInt32(rg.Match(dtRow.Field<string>("ZoneDescription")).Value),
                ActualPlannedStartDate = dtRow.Field<DateTime?>("ActualStartDate"),
                GatingDate = dtRow.Field<DateTime?>("GatingDate"),
                CalculatedStandardTimeDays = dtRow.Field<decimal?>("CalculatedStandardTimeDays"),
                ModuleProcess = dtRow.Field<string>("ModuleProcess"),
                ActualPlannedLaunch = dtRow.Field<DateTime?>("ActualPlannedLaunch"),
                NumberOfSteps = dtRow.Field<int?>("NumberofSteps"),
                CompletedSteps = dtRow.Field<int?>("CompletedSteps"),
                ModuleShiftHours = dtRow.Field<int?>("ModuleShiftHours"),
                StandardTimeHours = dtRow.Field<double?>("StandardTimeHours"),
                Plant = dtRow.Field<string>("Plant"),
            }).OrderBy(x => x.ZoneOrder).ThenBy(x => x.OpOrder).ToList();

            List<ModuleVFDWithName> moduleVFDs = dataSet.Tables[2].AsEnumerable().Select(dtRow => new ModuleVFDWithName()
            {
                ModuleVFDId = dtRow.Field<long?>("ModuleVFDId"),
                Assignable = dtRow.Field<bool?>("Assignable"),
                BayName = dtRow.Field<string>("BayName"),
                NumberOfDays = dtRow.Field<int?>("NumberOfDays"),
                PilotProductId = dtRow.Field<long?>("PilotProductID"),
                StatusId = dtRow.Field<long?>("StatusID"),
                VFDZoneId = dtRow.Field<long?>("VFDZoneID"),
                VFDZoneName = dtRow.Field<string>("VFDZoneName")
            }).ToList();
            List<ModuleVFDWithName> moduleVFDAssignable = dataSet.Tables[3].AsEnumerable().Select(dtRow => new ModuleVFDWithName()
            {
                ModuleVFDId = dtRow.Field<long?>("ModuleVFDId"),
                Assignable = dtRow.Field<bool?>("Assignable"),
                BayName = dtRow.Field<string>("BayName"),
                NumberOfDays = dtRow.Field<int?>("NumberOfDays"),
                PilotProductId = dtRow.Field<long?>("PilotProductID"),
                StatusId = dtRow.Field<long?>("StatusID"),
                VFDZoneId = dtRow.Field<long?>("VFDZoneID"),
                VFDZoneName = dtRow.Field<string>("VFDZoneName")
            }).ToList();

            operationDateModel = CommonHelper.SetDatesOfOperations(operationDateModel, todaydate, moduleVFDs, moduleVFDAssignable);

            //whenever you change the logic in the below updation codes, change the login where else these lines are writtne e.g - GetModuleWIP of ModulesPlanning.cs
            EditScheduledSummary.ActualIntegrationStartIsManual = EditScheduledSummary.ActualIntegrationStart.HasValue;
            if (operationDateModel.Where(x => x.ZoneDescription.ToLower().Contains("Final Integration".ToLower())).Count() > 0)
            {
                EditScheduledSummary.ActualIntegrationStart = EditScheduledSummary.ActualIntegrationStart ?? operationDateModel.Where(x => x.ZoneDescription.ToLower().Contains("Final Integration".ToLower())).FirstOrDefault().ActualPlannedStartDate;
            }

            EditScheduledSummary.ActualTestStartIsManual = EditScheduledSummary.ActualTestStart.HasValue;

            if (operationDateModel.Where(x => x.ZoneDescription.ToLower().Contains("Final Test".ToLower())).Count() > 0)
            {
                EditScheduledSummary.ActualTestStart = EditScheduledSummary.ActualTestStart ?? operationDateModel.Where(x => x.ZoneDescription.ToLower().Contains("Final Test".ToLower())).FirstOrDefault().ActualPlannedStartDate;
            }

            EditScheduledSummary.ActualTestCompleteIsManual = EditScheduledSummary.ActualTestComplete.HasValue;
            EditScheduledSummary.PlannedTestComplete = EditScheduledSummary.ActualTestStart.HasValue ? EditScheduledSummary.ActualTestStart.Value.AddDays(EditScheduledSummary.TargetTestDays ?? 0 + EditScheduledSummary.IdleTestDay ?? 0) : EditScheduledSummary.ActualTestComplete;

            EditScheduledSummary.ActualManufacturingCompleteIsManual = EditScheduledSummary.ActualManufacturingComplete.HasValue;
            if (EditScheduledSummary.ActualManufacturingComplete == null)
            {
                EditScheduledSummary.ActualManufacturingComplete = EditScheduledSummary.ActualTestComplete.HasValue ? EditScheduledSummary.ActualTestComplete.Value.AddDays(EditScheduledSummary.PostTestDays ?? 0) : EditScheduledSummary.ActualTestComplete;
            }

            return EditScheduledSummary;
        }

        public List<MasterRecords> GetMissCategoryDDL(string connString)
        {
            try
            {
                DataTable dataTable = new DataTable();
                dataTable = SqlHelper.GetDataTable(connString, "uspGetMissCategoryDDL", null);
                List<MasterRecords> masterRecords = dataTable.AsEnumerable().Select(dtRow => new MasterRecords()
                {
                    MasterRecordID = dtRow.Field<long>("MasterRecordID"),
                    MasterRecordName = dtRow.Field<string>("MasterRecordName")
                }).ToList();
                return masterRecords;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int UpdateModScheduleSummary(string connString, EditModScheduleViewModel editMod)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter[] param = {
                    new SqlParameter("@PilotProductID", editMod.PilotProductID),
                    new SqlParameter("@PlannedLaunch",  editMod.PlannedLaunch),
                    new SqlParameter("@PlannedIntegrationStart",  editMod.PlannedIntegrationStart),
                    new SqlParameter("@PlannedTestStart",  editMod.PlannedTestStart),
                    new SqlParameter("@PlannedTestComplete",  editMod.PlannedTestComplete),
                    new SqlParameter("@PlannedManufacturingComplete",  editMod.PlannedManufacturingComplete),

                    new SqlParameter("@ActualLaunch",  editMod.ActualLaunch),
                    new SqlParameter("@ActualIntegrationStart",  editMod.ActualIntegrationStartManual),
                    new SqlParameter("@ActualTestStart",  editMod.ActualTestStartManual),
                    new SqlParameter("@ActualTestComplete",  editMod.ActualTestCompleteManual),
                    new SqlParameter("@ActualManufacturingComplete",  editMod.ActualManufacturingCompleteManual),

                    new SqlParameter("@TargetShipDate",  editMod.TargetShipDate),
                    new SqlParameter("@ManufacturingCommitedShipDate",  editMod.ManufacturingCommitedShipDate),
                    new SqlParameter("@CustomerRequestDate",  editMod.CustomerRequestDate),
                    new SqlParameter("@ActualCrateComplete",  editMod.ActualCrateComplete),
                    new SqlParameter("@EarliestStartDate",  editMod.EarliestStartDate),


                    new SqlParameter("@TestDays",  editMod.TargetTestDays ),
                    new SqlParameter("@IdleTestDays",  editMod.IdleTestDay),
                    new SqlParameter("@PostTestDays",  editMod.PostTestDays),


                    new SqlParameter("@NoCapacity",  editMod.NoCapacity),
                    new SqlParameter("@BuildScheduleId",  editMod.BuildScheduleId),
                    new SqlParameter("@ProductionStatus",  editMod.ProductionStatus),

                    new SqlParameter("@LaunchMissCategory",  editMod.LaunchMissCategoryId),
                    new SqlParameter("@LaunchMissReason",  editMod.LaunchMissReason),
                    new SqlParameter("@IntegrationMissCategory",  editMod.IntegrationMissCategoryId),
                    new SqlParameter("@IntegrationMissReason",  editMod.IntegrationMissReason),
                    new SqlParameter("@TeststartMissCategory",  editMod.TeststartMissCategoryId),
                    new SqlParameter("@TeststartMissReason",  editMod.TeststartMissReason),
                    new SqlParameter("@TestCompleteMissCategory",  editMod.TestCompleteMissCategoryId),
                    new SqlParameter("@TestCompleteMissReason",  editMod.TestCompleteMissReason),
                    new SqlParameter("@MfgCompleteMissCategory",  editMod.MfgCompleteMissCategoryId),
                    new SqlParameter("@MfgCompleteMissReason",  editMod.MfgCompleteMissReason),
                    new SqlParameter("@TestDate",  editMod.TestDate),
                    new SqlParameter("@ModifiedBy",editMod.ModifiedBy),
                    new SqlParameter("@ModifiedOn", editMod.ModifiedOn),

                    new SqlParameter("@PilotManufacturingCommitedShipDate", editMod.PilotManufacturingCommitedShipDate),
                    outParam

                  };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateModScheduleSummary", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public object GetReconfig(string connString, string status,string BEN, int plantId)
        {
            DataSet dataSet;

            SqlParameter[] param =
            {
                 new SqlParameter("@BEN", BEN),
                 new SqlParameter("@Status", status),
                 new SqlParameter("@PlantId", plantId)
            };

            dataSet = SqlHelper.GetDataSet(connString, "uspGetReconfig", param);
            DataTable dataTable = dataSet.Tables[0];
            ReconfigData data = new ReconfigData();
            List<Reconfig> masterRecords = dataTable.AsEnumerable().Select(dtRow => new Reconfig()
            {
                AddOrRTSProdOrder = dtRow.Field<string>("AddOrRTSProdOrder"),
                PartNumber = dtRow.Field<string>("PartNumber"),
                Description = dtRow.Field<string>("Description"),
                Qty = dtRow.Field<decimal?>("Qty"),
                QtyAdded = dtRow.Field<int?>("QtyAdded"),
                TechnicianComments = dtRow.Field<string>("TechnicianComments"),
                Status = dtRow.Field<string>("Status"),
            }).ToList();

            var prodOrderCount = dataSet.Tables[1].AsEnumerable().Select(dtRow => new
            {
                ProdOrderCount = dtRow.Field<int?>("ProdOrderCount"),
            }).FirstOrDefault();

            data.Reconfig = masterRecords;
            data.ProdOrderCount = prodOrderCount.ProdOrderCount;

            return data;
        }
        public object GetReconfigDelete(string connString, string status, string BEN, int plantId)
        {
            DataSet dataSet;

            SqlParameter[] param =
            {
                 new SqlParameter("@BEN", BEN),
                 new SqlParameter("@Status", status),
                  new SqlParameter("@PlantId", plantId)
            };

            dataSet = SqlHelper.GetDataSet(connString, "uspGetReconfigDelete", param);
            DataTable dataTable = dataSet.Tables[0];
            ReconfigData data = new ReconfigData();
            List<Reconfig> masterRecords = dataTable.AsEnumerable().Select(dtRow => new Reconfig()
            {
                AddOrRTSProdOrder = dtRow.Field<string>("AddOrRTSProdOrder"),
                PartNumber = dtRow.Field<string>("PartNumber"),
                Description = dtRow.Field<string>("Description"),
                Qty = dtRow.Field<decimal?>("Qty"),
                QtyAdded = dtRow.Field<int?>("QtyAdded"),
                TechnicianComments = dtRow.Field<string>("TechnicianComments"),
                Status = dtRow.Field<string>("Status"),
            }).ToList();

            var prodOrderCount = dataSet.Tables[1].AsEnumerable().Select(dtRow => new
            {
                ProdOrderCount = dtRow.Field<int?>("ProdOrderCount"),
            }).FirstOrDefault();

            data.Reconfig = masterRecords;
            data.ProdOrderCount = prodOrderCount.ProdOrderCount;

            return data;
        }
        public int UpdateReconfig(string connString, ReconfigEditFields[] reconfigEdit)
        {
           
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
            try
            {
                foreach (var items in reconfigEdit)
                {
                    SqlParameter[] param = {

                    new SqlParameter("@AddOrRTSProdOrder", items.AddOrRTSProdOrder),
                    new SqlParameter("@PartNumber",  items.PartNumber),
                    new SqlParameter("@QtyAddedReturned ",  items.QtyAddedReturned ),
                    new SqlParameter("@Status",  items.Status),
                     new SqlParameter("@TechnicianComments",  items.TechnicianComments),
                 outParam

            };

                    // resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateVFDAssignmentTableData", param);
                    resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateReconfig", param);
                }
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        //private DataTable GetReconfigEditTable(List<ReconfigEditFields> reconfigEditFields)
        //{
        //    DataTable reconfigEditTable = new DataTable();

        //    reconfigEditTable.Columns.Add("AddRTSProdOrder", typeof(string));
        //    reconfigEditTable.Columns.Add("Component", typeof(string));
        //    reconfigEditTable.Columns.Add("QtyAddedReturned", typeof(int));
        //    reconfigEditTable.Columns.Add("Status", typeof(int));
        //    reconfigEditTable.Columns.Add("TechnicianComments", typeof(string));

        //    if (reconfigEditFields != null)
        //    {
        //        foreach (ReconfigEditFields item in reconfigEditFields)
        //        {
        //            reconfigEditTable.Rows.Add(item.AddRTSProdOrder, item.Component, item.QtyAddedReturned, item.Status, item.TechnicianComments
        //                );
        //        }
        //    }

        //    return reconfigEditTable;
        //}
        public object GetReconfigStatus(string connString)
        {
            DataTable dataTable;

            dataTable = SqlHelper.GetDataTable(connString, "uspGetReconfigStatus");

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
            {

                StatusId = dtRow.Field<long>("StatusId"),
                Status = dtRow.Field<string>("Status"),
            }).ToList();

            return masterRecords;
        }
    }
}
