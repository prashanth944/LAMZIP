﻿using LAM.PMPM.DAL;
using LAM.PMPM.Model;
using LAM.PMPM.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;


namespace LAM.PMPM.BL
{
    public class ModulesPlanning
    {
        public List<MasterRecords> GetBuildTypeDDL(string connString, int plantID)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = { new SqlParameter("@plantID", plantID) };
                dataTable = SqlHelper.GetDataTable(connString, "USPGetBuildTypeDDL", param);
                List<MasterRecords> masterRecords = dataTable.AsEnumerable().Select(dtRow => new MasterRecords()
                {
                    MasterRecordID = dtRow.Field<long>("MasterRecordID"),
                    MasterRecordName = dtRow.Field<string>("MasterRecordName"),
                    Value = dtRow.Field<string>("Value")
                }).ToList();
                return masterRecords;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public List<MasterRecords> GetBuildStyleDDL(string connString)
        {
            try
            {
                DataTable dataTable;
                dataTable = SqlHelper.GetDataTable(connString, "USPGetBuildStyleDDL", null);
                List<MasterRecords> masterRecords = dataTable.AsEnumerable().Select(dtRow => new MasterRecords()
                {
                    MasterRecordID = Convert.ToInt32(dtRow["MasterRecordID"]),
                    MasterRecordName = Convert.ToString(dtRow["MasterRecordName"])
                }).ToList();
                return masterRecords;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public string GetAddPO(string connString, string ProductionOrderNum)
        {
            try
            {
                string POValue;
                SqlParameter[] param = { new SqlParameter("@ProductionOrderNum", ProductionOrderNum) };

                POValue = SqlHelper.ExecuteScalar(connString, "uspGetAddPO", param).ToString();
                return POValue;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public string GetDeletePO(string connString, string ProductionOrderNum)
        {
            try
            {
                string POValue;
                SqlParameter[] param = { new SqlParameter("@ProductionOrderNum", ProductionOrderNum) };

                POValue = SqlHelper.ExecuteScalar(connString, "uspGetDeletePO", param).ToString();
                return POValue;                
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<MasterRecords> GetBuildStyleDDLForAddPOPUp(string connString)
        {
            try
            {
                DataTable dataTable;
                dataTable = SqlHelper.GetDataTable(connString, "uspGetBuildStyleDDLForAddPOPUp", null);
                List<MasterRecords> masterRecords = dataTable.AsEnumerable().Select(dtRow => new MasterRecords()
                {
                    MasterRecordID = Convert.ToInt32(dtRow["MasterRecordID"]),
                    MasterRecordName = Convert.ToString(dtRow["MasterRecordName"])
                }).ToList();
                return masterRecords;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<MasterRecords> GetBuildScheduleDDL(string connString)
        {
            try
            {
                DataTable dataTable;
                dataTable = SqlHelper.GetDataTable(connString, "USPGetBuildScheduleDDL", null);
                List<MasterRecords> masterRecords = dataTable.AsEnumerable().Select(dtRow => new MasterRecords()
                {
                    MasterRecordID = Convert.ToInt32(dtRow["MasterRecordID"]),
                    MasterRecordName = Convert.ToString(dtRow["MasterRecordName"])
                }).ToList();
                return masterRecords;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public List<Modules> GetAssosiatedBENDDL(string connString, int PlantID)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = { new SqlParameter("@PlantID", PlantID) };

                dataTable = SqlHelper.GetDataTable(connString, "USPGetAssosiatedBENDDL", param);
                List<Modules> modules = dataTable.AsEnumerable().Select(dtRow => new Modules()
                {

                    BEN = Convert.ToString(dtRow["BEN"])
                }).ToList();
                return modules;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public string GetModuleToolType(string connString, int plantID)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = { new SqlParameter("@plantID", plantID) };

                dataTable = SqlHelper.GetDataTable(connString, "USPGetModuleToolType", param);

                string moduleToolTypeList = null;
                dynamic moduleToolType = null;


                moduleToolType = dataTable.Rows.Cast<DataRow>()
                     .GroupBy(x => new { ToolTypeName = x["ToolTypeName"], ToolTypeID = x["ToolTypeID"] })
                     .Select(x => new
                     {
                         ToolTypeName = x.Key,
                         TotalLaborHour = x.Select(x => x.Field<Int32>("HourRequired")).Sum(),
                         ModuleProcess = x.Select(y => new
                         {
                             ModuleProcessID = y.Field<long?>("ModuleProcessID"),
                             ModuleProcessName = y.Field<string>("ModuleProcess"),
                             BayRequired = y.Field<int?>("BayRequired"),
                             HourRequired = y.Field<int?>("HourRequired"),
                             TechnicianRequired = y.Field<int?>("TechnicianRequired"),


                             TransitionDate = y.Field<DateTime?>("TransitionDate"),
                             POABOMReleaseDate = y.Field<DateTime?>("POABOMReleaseDate"),
                             UpdatedBy = y.Field<string>("UpdatedBy"),
                             LastUpdated = y.Field<DateTime?>("LastUpdated"),
                         })

                     }).ToList();

                moduleToolTypeList = Newtonsoft.Json.JsonConvert.SerializeObject(moduleToolType);
                return moduleToolTypeList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int UpdateModuleDemand(string connString, ModulesSummary modulesSummary, int pilotproductid)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };


                SqlParameter[] param = {
                        new SqlParameter("@PilotProductID", pilotproductid),
                        new SqlParameter("@BuildScheduleId",modulesSummary.BuildScheduleId),
                        new SqlParameter("@BaysRequiredSubassembly",modulesSummary.BaysRequiredSubassembly),
                        new SqlParameter("@TotalAssemblyHours",modulesSummary.TotalAssemblyHours),
                        new SqlParameter("@BaysRequiredIntegration",modulesSummary.BaysRequiredIntegration),
                        new SqlParameter("@TotalIntegrationHours",modulesSummary.TotalIntegrationHours),
                        new SqlParameter("@BaysRequiredForTest",modulesSummary.BaysRequiredForTest),
                        new SqlParameter("@TotalTestHours",modulesSummary.TotalTestHours),
                        new SqlParameter("@BaysRequiredPostTest",modulesSummary.BaysRequiredPostTest),
                        new SqlParameter("@TotalPostTestHours",modulesSummary.TotalPostTestHours),
                        new SqlParameter("@TechnicianRequiredSubassembly",modulesSummary.TechnicianRequiredSubassembly),
                        new SqlParameter("@TechnicianRequiredIntegration",modulesSummary.TechnicianRequiredIntegration),
                        new SqlParameter("@TechnicianRequiredTest",modulesSummary.TechnicianRequiredTest),
                        new SqlParameter("@TechnicianRequiredPostTest",modulesSummary.TechnicianRequiredPostTest),
                        new SqlParameter("@ModuleProcessSubassembly",modulesSummary.ModuleProcessSubassembly),
                        new SqlParameter("@ModuleProcessIntegration",modulesSummary.ModuleProcessIntegration),
                        new SqlParameter("@ModuleProcessTest",modulesSummary.ModuleProcessTest),
                        new SqlParameter("@ModuleProcessPostTest",modulesSummary.ModuleProcessPostTest),
                        outParam
                    };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspEditModuleDemandByPilotProductId", param);
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public ModulesSummary GetModuleDemand(string connString, int pilotproductid)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = { new SqlParameter("@pilotProductId", pilotproductid) };

                dataTable = SqlHelper.GetDataTable(connString, "USPGetModuleDemandByPilotProductId", param);

                ModulesSummary masterRecords = dataTable.AsEnumerable().Select(dtRow => new ModulesSummary()
                {
                    PilotProductID = dtRow.Field<long?>("PilotProductID"),
                    PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                    BEN = dtRow.Field<string>("BEN"),

                    BuildScheduleId = dtRow.Field<int?>("BuildScheduleId"),
                    BuildSchedule = dtRow.Field<int?>("BuildSchedule"),

                    ProductGroupName = dtRow.Field<string>("ProductGroupName"),
                    ToolTypeName = dtRow.Field<string>("ToolTypeName"),
                    ToolTypeID = dtRow.Field<long?>("ToolTypeID"),
                    ProductGroupID = dtRow.Field<long?>("ProductGroupID"),

                    BaysRequiredSubassembly = dtRow.Field<int?>("BaysRequiredSubassembly"),
                    TotalAssemblyHours = dtRow.Field<decimal?>("TotalAssemblyHour"),
                    BaysRequiredIntegration = dtRow.Field<int?>("BaysRequiredIntegration"),
                    TotalIntegrationHours = dtRow.Field<decimal?>("TotalIntegrationHour"),
                    BaysRequiredForTest = dtRow.Field<int?>("BaysRequiredForTest"),
                    TotalTestHours = dtRow.Field<decimal?>("TotalTestHour"),
                    BaysRequiredPostTest = dtRow.Field<int?>("BaysRequiredPostTest"),
                    TotalPostTestHours = dtRow.Field<decimal?>("TotalPostTestHour"),
                    TotalLaborHour = dtRow.Field<decimal?>("TotalLaborHour"),

                    TechnicianRequiredSubassembly = dtRow.Field<int?>("TechnicianRequiredSubassembly"),
                    TechnicianRequiredIntegration = dtRow.Field<int?>("TechnicianRequiredIntegration"),
                    TechnicianRequiredTest = dtRow.Field<int?>("TechnicianRequiredTest"),
                    TechnicianRequiredPostTest = dtRow.Field<int?>("TechnicianRequiredPostTest"),

                    CalendarDaysSubAssembly = dtRow.Field<int?>("CalendarDaysSubAssembly"),
                    CalendarDaysIntegration = dtRow.Field<int?>("CalendarDaysIntegration"),
                    CalendarDaysTest = dtRow.Field<int?>("CalendarDaysTest"),
                    CalendarDaysPostTest = dtRow.Field<int?>("CalendarDaysPostTest"),

                }).FirstOrDefault();

                return masterRecords;
            }
            catch (Exception ex)
            {

                throw new Exception(ex.ToString());
            }
        }

        public ModuleInfoTag GetModuleInfoForTag(string connString, int pilotproductid, int plantId, DateTime todaydate)
        {
            try
            {
                //DataTable dataTable;
                SqlParameter[] param = { new SqlParameter("@pilotProductId", pilotproductid)
                 ,new SqlParameter("@plantID", plantId)};
                Regex rg = new Regex(@"\d+");
                DataSet dataSet;
                // dataTable = SqlHelper.GetDataTable(connString, "uspGetModuleForTagById", param);
                dataSet = SqlHelper.GetDataSet(connString, "uspGetModuleForTagById", param);

                DataTable dataTable = dataSet.Tables[0];
                ModuleInfoTag masterRecords = dataTable.AsEnumerable().Select(dtRow => new ModuleInfoTag()
                {
                    PurchaseOrderNumber = dtRow.Field<string>("PurchaseOrderNumber"),
                    SalesOrder = dtRow.Field<string>("SalesOrder"),
                    BEN = dtRow.Field<string>("BEN"),
                    SalesOrderNumber = dtRow.Field<string>("SalesOrderNumber"),

                    ProcessModule = dtRow.Field<int?>("ProcessModule"),
                    PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                    ToolTypeName = dtRow.Field<string>("ToolTypeName"),
                    CapacityPlanningColor = dtRow.Field<string>("CapacityPlanningColor"),

                    //PlannedIntegrationStart = dtRow.Field<DateTime?>("PlannedIntegrationStart"),
                    //PlannedTestStart = dtRow.Field<DateTime?>("PlannedTestStart"),
                    //PlannedManufacturingComplete = dtRow.Field<DateTime?>("PlannedManufacturingComplete"),
                    //ActualLaunch = dtRow.Field<DateTime?>("ActualLaunch"),
                    FCID = dtRow.Field<string>("FCID")

                }).FirstOrDefault();

                EditModScheduleViewModel EditScheduledSummary = dataSet.Tables[1].AsEnumerable().Select(dtRow => new EditModScheduleViewModel()
                {
                    PilotProductID = dtRow.Field<long?>("PilotProductID"),
                    InWIP = dtRow.Field<bool?>("InWIP"),

                    CommitLaunch = dtRow.Field<DateTime?>("CommitLaunch"),
                    CommittedIntegrationStart = dtRow.Field<DateTime?>("CommittedIntegrationStart"),
                    CommittedTestStart = dtRow.Field<DateTime?>("CommittedTestStart"),
                    CommittedTestComplete = dtRow.Field<DateTime?>("CommittedTestComplete"),
                    CommitedManufacturingComplete = dtRow.Field<DateTime?>("CommitedManufacturingComplete"),

                    ProjectedLaunch = dtRow.Field<DateTime?>("ProjectedLaunch"),
                    ProjectedIntegrationStart = dtRow.Field<DateTime?>("ProjectedIntegrationStart"),
                    ProjectedTestStart = dtRow.Field<DateTime?>("ProjectedTestStart"),
                    ProjectedTestComplete = dtRow.Field<DateTime?>("ProjectedTestComplete"),
                    ProjectedManufacturingComplete = dtRow.Field<DateTime?>("ProjectedManufacturingComplete"),
                    ProjectedCrateComplete = dtRow.Field<DateTime?>("ProjectedCrateComplete"),

                    PlannedLaunch = dtRow.Field<DateTime?>("PlannedLaunch"),
                    PlannedIntegrationStart = dtRow.Field<DateTime?>("PlannedIntegrationStart"),
                    PlannedTestStart = dtRow.Field<DateTime?>("PlannedTestStart"),
                    PlannedTestComplete = dtRow.Field<DateTime?>("PlannedTestComplete"),
                    PlannedManufacturingComplete = dtRow.Field<DateTime?>("PlannedManufacturingComplete"),
                    PlannedCrateComplete = dtRow.Field<DateTime?>("PlannedCrateComplete"),

                    ActualLaunch = dtRow.Field<DateTime?>("ActualLaunch"),
                    ActualIntegrationStart = dtRow.Field<DateTime?>("ActualIntegrationStart"),
                    ActualTestStart = dtRow.Field<DateTime?>("ActualTestStart"),
                    ActualTestComplete = dtRow.Field<DateTime?>("ActualTestComplete"),
                    ActualManufacturingComplete = dtRow.Field<DateTime?>("ActualManufacturingComplete"),

                    ActualIntegrationStartManual = dtRow.Field<DateTime?>("ActualIntegrationStartManual"),
                    ActualTestStartManual = dtRow.Field<DateTime?>("ActualTestStartManual"),
                    ActualTestCompleteManual = dtRow.Field<DateTime?>("ActualTestCompleteManual"),
                    ActualManufacturingCompleteManual = dtRow.Field<DateTime?>("ActualManufacturingCompleteManual"),

                    ActualCrateComplete = dtRow.Field<DateTime?>("ActualCrateComplete"),

                    IdleTestDay = dtRow.Field<int?>("IdleTestDay"),
                    PostTestDays = dtRow.Field<int?>("PostTestDays"),
                    TargetTestDays = dtRow.Field<int?>("TargetTestDays"),

                    TargetShipDate = dtRow.Field<DateTime?>("TargetShipDate"),
                    ManufacturingCommitedShipDate = dtRow.Field<DateTime?>("ManufacturingCommitedShipDate"),
                    CustomerRequestDate = dtRow.Field<DateTime?>("CustomerRequestDate"),
                    EarliestStartDate = dtRow.Field<DateTime?>("EarliestStartDate"),

                    NoCapacity = dtRow.Field<bool?>("NoCapacity"),
                    BuildScheduleId = dtRow.Field<long?>("BuildScheduleId"),
                    BuildScheduleName = dtRow.Field<string>("BuildScheduleName"),
                    ProductionStatus = dtRow.Field<string>("ProductionStatus"),

                    LaunchMissCategory = dtRow.Field<string>("LaunchMissCategory"),
                    LaunchMissCategoryId = dtRow.Field<long?>("LaunchMissCategoryId"),
                    LaunchMissReason = dtRow.Field<string>("LaunchMissReason"),

                    IntegrationMissCategory = dtRow.Field<string>("IntegrationMissCategory"),
                    IntegrationMissCategoryId = dtRow.Field<long?>("IntegrationMissCategoryId"),
                    IntegrationMissReason = dtRow.Field<string>("IntegrationMissReason"),

                    TestCompleteMissCategory = dtRow.Field<string>("TestCompleteMissCategory"),
                    TestCompleteMissCategoryId = dtRow.Field<long?>("TestCompleteMissCategoryId"),
                    TestCompleteMissReason = dtRow.Field<string>("TestCompleteMissReason"),

                    TeststartMissCategory = dtRow.Field<string>("TeststartMissCategory"),
                    TeststartMissCategoryId = dtRow.Field<long?>("TeststartMissCategoryId"),
                    TeststartMissReason = dtRow.Field<string>("TeststartMissReason"),

                    MfgCompleteMissCategory = dtRow.Field<string>("MfgCompleteMissCategory"),
                    MfgCompleteMissCategoryId = dtRow.Field<long?>("MfgCompleteMissCategoryId"),
                    MfgCompleteMissReason = dtRow.Field<string>("MfgCompleteMissReason"),

                    PilotManufacturingCommitedShipDate = dtRow.Field<DateTime?>("PilotManufacturingCommitedShipDate")
                }).FirstOrDefault();
                List<OperationDateModel> operationDateModel = dataSet.Tables[2].AsEnumerable().Select(dtRow => new OperationDateModel()
                {
                    PilotProductID = dtRow.Field<long?>("PilotProductID"),
                    OperationID = dtRow.Field<long?>("OperationID"),
                    OPDescription = dtRow.Field<string>("OPDescription"),
                    OpOrder = string.IsNullOrEmpty(dtRow.Field<string>("OPDescription")) ? 99999 : string.IsNullOrEmpty(rg.Match(dtRow.Field<string>("OPDescription")).Value.Trim()) ? 99999 : Convert.ToInt32(rg.Match(dtRow.Field<string>("OPDescription")).Value),
                    ZoneID = dtRow.Field<long?>("ZoneID"),
                    ZoneDescription = dtRow.Field<string>("ZoneDescription"),
                    ZoneName = dtRow.Field<string>("ZoneName"),
                    ZoneOrder = string.IsNullOrEmpty(dtRow.Field<string>("ZoneDescription")) ? 99999 : string.IsNullOrEmpty(rg.Match(dtRow.Field<string>("ZoneDescription")).Value.Trim()) ? 99999 : Convert.ToInt32(rg.Match(dtRow.Field<string>("ZoneDescription")).Value),
                    ActualPlannedStartDate = dtRow.Field<DateTime?>("ActualStartDate"),
                    GatingDate = dtRow.Field<DateTime?>("GatingDate"),
                    CalculatedStandardTimeDays = dtRow.Field<decimal?>("CalculatedStandardTimeDays"),
                    ModuleProcess = dtRow.Field<string>("ModuleProcess"),
                    ActualPlannedLaunch = dtRow.Field<DateTime?>("ActualPlannedLaunch"),
                    NumberOfSteps = dtRow.Field<int?>("NumberofSteps"),
                    CompletedSteps = dtRow.Field<int?>("CompletedSteps"),
                    ModuleShiftHours = dtRow.Field<int?>("ModuleShiftHours"),
                    StandardTimeHours = dtRow.Field<double?>("StandardTimeHours"),
                    Plant = dtRow.Field<string>("Plant"),
                }).OrderBy(x => x.ZoneOrder).ThenBy(x => x.OpOrder).ToList();

                List<ModuleVFDWithName> moduleVFDs = dataSet.Tables[3].AsEnumerable().Select(dtRow => new ModuleVFDWithName()
                {
                    ModuleVFDId = dtRow.Field<long?>("ModuleVFDId"),
                    Assignable = dtRow.Field<bool?>("Assignable"),
                    BayName = dtRow.Field<string>("BayName"),
                    NumberOfDays = dtRow.Field<int?>("NumberOfDays"),
                    PilotProductId = dtRow.Field<long?>("PilotProductID"),
                    StatusId = dtRow.Field<long?>("StatusID"),
                    VFDZoneId = dtRow.Field<long?>("VFDZoneID"),
                    VFDZoneName = dtRow.Field<string>("VFDZoneName")
                }).ToList();
                List<ModuleVFDWithName> moduleVFDAssignable = dataSet.Tables[4].AsEnumerable().Select(dtRow => new ModuleVFDWithName()
                {
                    ModuleVFDId = dtRow.Field<long?>("ModuleVFDId"),
                    Assignable = dtRow.Field<bool?>("Assignable"),
                    BayName = dtRow.Field<string>("BayName"),
                    NumberOfDays = dtRow.Field<int?>("NumberOfDays"),
                    PilotProductId = dtRow.Field<long?>("PilotProductID"),
                    StatusId = dtRow.Field<long?>("StatusID"),
                    VFDZoneId = dtRow.Field<long?>("VFDZoneID"),
                    VFDZoneName = dtRow.Field<string>("VFDZoneName")
                }).ToList();
                operationDateModel = CommonHelper.SetDatesOfOperations(operationDateModel, todaydate, moduleVFDs, moduleVFDAssignable);

                //whenever you change the logic in the below updation codes, change the login where else these lines are writtne e.g - GetModuleWIP of ModulesPlanning.cs
                EditScheduledSummary.ActualIntegrationStartIsManual = EditScheduledSummary.ActualIntegrationStart.HasValue;
                if (operationDateModel.Where(x => x.ZoneDescription.ToLower().Contains("Final Integration".ToLower())).Count() > 0)
                {
                    EditScheduledSummary.ActualIntegrationStart = EditScheduledSummary.ActualIntegrationStart ?? operationDateModel.Where(x => x.ZoneDescription.ToLower().Contains("Final Integration".ToLower())).FirstOrDefault().ActualPlannedStartDate;
                }

                EditScheduledSummary.ActualTestStartIsManual = EditScheduledSummary.ActualTestStart.HasValue;

                if (operationDateModel.Where(x => x.ZoneDescription.ToLower().Contains("Final Test".ToLower())).Count() > 0)
                {
                    EditScheduledSummary.ActualTestStart = EditScheduledSummary.ActualTestStart ?? operationDateModel.Where(x => x.ZoneDescription.ToLower().Contains("Final Test".ToLower())).FirstOrDefault().ActualPlannedStartDate;
                }

                EditScheduledSummary.ActualTestCompleteIsManual = EditScheduledSummary.ActualTestComplete.HasValue;
                EditScheduledSummary.PlannedTestComplete = EditScheduledSummary.ActualTestStart.HasValue ? EditScheduledSummary.ActualTestStart.Value.AddDays(EditScheduledSummary.TargetTestDays ?? 0 + EditScheduledSummary.IdleTestDay ?? 0) : EditScheduledSummary.ActualTestComplete;

                EditScheduledSummary.ActualManufacturingCompleteIsManual = EditScheduledSummary.ActualManufacturingComplete.HasValue;
                if (EditScheduledSummary.ActualManufacturingComplete == null)
                {
                    EditScheduledSummary.ActualManufacturingComplete = EditScheduledSummary.ActualTestComplete.HasValue ? EditScheduledSummary.ActualTestComplete.Value.AddDays(EditScheduledSummary.PostTestDays ?? 0) : EditScheduledSummary.ActualTestComplete;
                }
                masterRecords.PlannedLaunch = EditScheduledSummary.PlannedLaunch;
                masterRecords.PlannedIntegrationStart = EditScheduledSummary.PlannedIntegrationStart;
                masterRecords.PlannedTestStart = EditScheduledSummary.PlannedTestStart;
                masterRecords.PlannedTestComplete = EditScheduledSummary.PlannedTestComplete;
                masterRecords.PlannedManufacturingComplete = EditScheduledSummary.PlannedManufacturingComplete;
                masterRecords.PlannedCrateComplete = EditScheduledSummary.PlannedCrateComplete;
                masterRecords.ActualLaunch = EditScheduledSummary.ActualLaunch;

                masterRecords.ActualIntegrationStart = EditScheduledSummary.ActualIntegrationStart;
                masterRecords.ActualTestStart = EditScheduledSummary.ActualTestStart;
                masterRecords.ActualTestComplete = EditScheduledSummary.ActualTestComplete;
                masterRecords.ActualManufacturingComplete = EditScheduledSummary.ActualManufacturingComplete;

                masterRecords.ActualIntegrationStartManual = EditScheduledSummary.ActualIntegrationStartManual;
                masterRecords.ActualTestStartManual = EditScheduledSummary.ActualTestStartManual;
                masterRecords.ActualTestCompleteManual = EditScheduledSummary.ActualTestCompleteManual;
                masterRecords.ActualManufacturingCompleteManual = EditScheduledSummary.ActualManufacturingComplete;

                masterRecords.ActualCrateComplete = EditScheduledSummary.ActualCrateComplete;

                masterRecords.IdleTestDay = EditScheduledSummary.IdleTestDay;
                masterRecords.PostTestDays = EditScheduledSummary.PostTestDays;
                masterRecords.TargetTestDays = EditScheduledSummary.TargetTestDays;

                return masterRecords;
            }
            catch (Exception ex)
            {

                throw new Exception(ex.ToString());
            }
        }

        public int AddModules(string connString, Modules modules)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                new SqlParameter("@ProductGroupID",modules.ProductGroupID),
                new SqlParameter("@ToolTypeID",modules.ToolTypeID),
                new SqlParameter("@BuildStyleID",modules.BuildStyleId),
                new SqlParameter("@BuildScheduleID",modules.BuildScheduleId),
                new SqlParameter("@BuildingID",modules.BuildingID),
                new SqlParameter("@FCID",modules.FCID),
                new SqlParameter("@PilotSerialNumber",modules.PilotSerialNumber),
                new SqlParameter("@BuildTypeID",modules.BuildTypeID),
                new SqlParameter("@BaysRequiredSubassembly",modules.BaysRequiredSubassembly),
                new SqlParameter("@TotalAssemblyHour",modules.TotalAssemblyHours),
                new SqlParameter("@BaysRequiredIntegration",modules.BaysRequiredIntegration),
                new SqlParameter("@TotalIntegrationHour",modules.TotalIntegrationHours),
                new SqlParameter("@BaysRequiredForTest",modules.BaysRequiredForTest),
                new SqlParameter("@TotalTestHour",modules.TotalTestHours),
                new SqlParameter("@BaysRequiredPostTest",modules.BaysRequiredPostTest),
                new SqlParameter("@TotalPostTestHour",modules.TotalPostTestHours),
                new SqlParameter("@TechnicianRequiredSubassembly",modules.TechnicianRequiredSubassembly),
                new SqlParameter("@TechnicianRequiredIntegration",modules.TechnicianRequiredIntegration),
                new SqlParameter("@TechnicianRequiredTest",modules.TechnicianRequiredTest),
                new SqlParameter("@TechnicianRequiredPostTest",modules.TechnicianRequiredPostTest),
                new SqlParameter("@CapacityPlanningColor",modules.CapacityPlanningColor),
                new SqlParameter("@CurrentPartNumber",modules.CurrentPartNumber),
                new SqlParameter("@ReworkPO",modules.ReworkPO),
                new SqlParameter("@NewPartNumber",modules.NewPartNumber),
                new SqlParameter("@BEN",modules.BEN),
                new SqlParameter("@CommitLaunch",modules.CommitLaunch),
                new SqlParameter("@POM",modules.POM),
                new SqlParameter("@AssociatedBEN",modules.AssociatedBEN),
                new SqlParameter("@ModuleProcessSubassembly",modules.ModuleProcessSubassembly),
                new SqlParameter("@ModuleProcessIntegration",modules.ModuleProcessIntegration),
                new SqlParameter("@ModuleProcessTest",modules.ModuleProcessTest),
                new SqlParameter("@ModuleProcessPostTest",modules.ModuleProcessPostTest),
                new SqlParameter("@RecordType",modules.RecordType),
                new SqlParameter("@RevenueType",modules.RevenueType),
                new SqlParameter("@PlantID",modules.PlantID),
                new SqlParameter("@CRD",modules.CRD),
                new SqlParameter("@POR",modules.POR),
                new SqlParameter("@AddPO",modules.AddPO),
                new SqlParameter("@DeletePO",modules.DeletePO),
                new SqlParameter("@BENorPSNReconfiguredFrom",modules.BENorPSNReconfiguredFrom),
                new SqlParameter("@ModifiedBy",modules.ModifiedBy),
                new SqlParameter("@ModifiedOn", modules.ModifiedOn),
                new SqlParameter("@AssociatedPSN", modules.AssociatedPSN),
                new SqlParameter("ProductionOrderNum", modules.ProductionOrderNum),
               outParam
             };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspAddModule", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public int UpdateModule(string connString, ModulesSummary[] modules)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                foreach (var items in modules)
                {
                    SqlParameter[] param = {
                new SqlParameter("@PlantName", items.PlantName),
                 new SqlParameter("@PilotProductID", items.PilotProductID),
                new SqlParameter("@PriorityDate",  items.PriorityDate),
                new SqlParameter("@BuildStyleId",items.BuildStyleId),
                new SqlParameter("@BuildScheduleId",items.BuildScheduleId),
                new SqlParameter("@NoCapacity",items.NoCapacity),
                new SqlParameter("@BaysRequiredSubassembly",items.BaysRequiredSubassembly),
                new SqlParameter("@TotalAssemblyHours",items.TotalAssemblyHours),
                new SqlParameter("@BaysRequiredIntegration",items.BaysRequiredIntegration),
                new SqlParameter("@TotalIntegrationHours",items.TotalIntegrationHours),
                new SqlParameter("@BaysRequiredForTest",items.BaysRequiredForTest),
                new SqlParameter("@TotalTestHours",items.TotalTestHours),
                new SqlParameter("@BaysRequiredPostTest",items.BaysRequiredPostTest),
                new SqlParameter("@TotalPostTestHours",items.TotalPostTestHours),
                new SqlParameter("@CapacityPlanningColor",items.CapacityPlanningColor),
                new SqlParameter("@Notes",items.Notes),
                new SqlParameter("@ActualShipDate",items.ActualShipDate),
                new SqlParameter("@CommitLaunch",items.CommitLaunch),
                new SqlParameter("@CommittedIntegrationStart",items.CommittedIntegrationStart),
                new SqlParameter("@CommitTestStart",items.CommitTestStart),
                new SqlParameter("@CommitManufacturingComplete",items.CommitManufacturingComplete),
                new SqlParameter("@ManufacturingCommitedShipDate",items.SapMCSD),
                new SqlParameter("@PilotRisk",items.PilotRisk),
                new SqlParameter("@SalesPriority",items.SalesPriority),
                new SqlParameter("@EarliestStartDate",items.EarliestStartDate),
                new SqlParameter("@CRDEsc",items.CRDEsc),
                new SqlParameter("@BuildTypeID",items.BuildTypeID),
                new SqlParameter("@TechnicianRequiredSubassembly",items.TechnicianRequiredSubassembly),
                new SqlParameter("@TechnicianRequiredIntegration",items.TechnicianRequiredIntegration),
                new SqlParameter("@TechnicianRequiredTest",items.TechnicianRequiredTest),
                new SqlParameter("@TechnicianRequiredPostTest",items.TechnicianRequiredPostTest),
                 new SqlParameter("@ModuleProcessSubassembly",items.ModuleProcessSubassembly),
                new SqlParameter("@ModuleProcessIntegration",items.ModuleProcessIntegration),
                new SqlParameter("@ModuleProcessTest",items.ModuleProcessTest),
                new SqlParameter("@ModuleProcessPostTest",items.ModuleProcessPostTest),
                new SqlParameter("@TargetShipDate",items.TSD),
                new SqlParameter("@SalesOpsRequestDate",items.SRD),
                new SqlParameter("@CustomerRequestDate",items.CRD),
                new SqlParameter("@PilotManufacturingCommitedShipDate",items.PilotMCSD),
                new SqlParameter("@PlanofRecord", items.PlanofRecord),
                new SqlParameter("@ModifiedBy",items.ModifiedBy),
                new SqlParameter("@ModifiedOn", items.ModifiedOn),
                new SqlParameter("@PilotToolType", items.PilotToolType),
                new SqlParameter("@SchedulingColor",items.SchedulingColor),
                new SqlParameter("@ScheduleStatusId",items.ScheduleStatusId),
           outParam
             };
                    resultCount = SqlHelper.ExecuteNonQuery(connString, "uspEditModule", param);
                }
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int ResetStaffPriority(string connString, int plantID)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@PlantID", plantID),
                    outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateStaffingPriority", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int UpdateStaffing(string connString, StaffedViewModel staffedViewModel)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@PilotProductId", staffedViewModel.PilotProductID),
                    new SqlParameter("@Staffed",  staffedViewModel.Staffed),
                    new SqlParameter("@Shift",  staffedViewModel.Shift)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "USPUdpatingStaffingOfModule", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public object GetPSNBENExists(string connString, int plantid, string text)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = {
                    new SqlParameter("@plantID", plantid),
                    new SqlParameter("@Text", text),
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetBENorPSNExists", param);

                var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
                {
                    Exist = Convert.ToInt32(dtRow["Exist"]),
                }).FirstOrDefault();
                return masterRecords;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<ModulesSummary> GetModule(string connString, int plantID)//make return type string
        {
            DataTable dataTable;
            SqlParameter[] param = { new SqlParameter("@plantID", plantID) };

            dataTable = SqlHelper.GetDataTable(connString, "USPGetModule", param);

            List<ModulesSummary> masterRecords = dataTable.AsEnumerable().Select(dtRow => new ModulesSummary()
            {
                PilotProductID = dtRow.Field<long?>("PilotProductID"),
                FCID = dtRow.Field<string>("FCID"),
                PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                BEN = dtRow.Field<string>("BEN"),
                PriorityDate = dtRow.Field<DateTime?>("PriorityDate"),
                BuildStyleId = dtRow.Field<int?>("BuildStyleId"),
                BuildScheduleId = dtRow.Field<int?>("BuildScheduleId"),
                NoCapacity = dtRow.Field<bool?>("NoCapacity"),
                RecordType = dtRow.Field<string>("RecordType"),
                RevenueCode = dtRow.Field<string>("RevenueCode"),
                ProductGroupName = dtRow.Field<string>("ProductGroupName"),
                ToolTypeName = dtRow.Field<string>("ToolTypeName"),
                BuildTypeID = dtRow.Field<long?>("BuildTypeID"),
                BuildTypeName = dtRow.Field<string>("BuildTypeName"),
                BaysRequired = dtRow.Field<int?>("BaysRequired"),
                BaysRequiredSubassembly = dtRow.Field<int?>("BaysRequiredSubassembly"),
                TotalAssemblyHours = dtRow.Field<decimal?>("TotalAssemblyHour"),
                BaysRequiredIntegration = dtRow.Field<int?>("BaysRequiredIntegration"),
                TotalIntegrationHours = dtRow.Field<decimal?>("TotalIntegrationHour"),
                BaysRequiredForTest = dtRow.Field<int?>("BaysRequiredForTest"),
                TotalTestHours = dtRow.Field<decimal?>("TotalTestHour"),
                BaysRequiredPostTest = dtRow.Field<int?>("BaysRequiredPostTest"),
                TotalPostTestHours = dtRow.Field<decimal?>("TotalPostTestHour"),
                TotalLaborHour = dtRow.Field<decimal?>("TotalLaborHour"),
                EarliestStartDate = dtRow.Field<DateTime?>("EarliestStartDate"),
                MaterialReadiness = dtRow.Field<DateTime?>("MaterialReadiness"),
                ActualDMRF = dtRow.Field<DateTime?>("ActualDMRF"),
                TransitionDate = dtRow.Field<DateTime?>("TransitionDate"),
                CommitLaunch = dtRow.Field<DateTime?>("CommitLaunch"),
                ActualIntegrationStart = dtRow.Field<DateTime?>("ActualIntegrationStart"),
                CommittedIntegrationStart = dtRow.Field<DateTime?>("CommittedIntegrationStart"),
                CommitTestStart = dtRow.Field<DateTime?>("CommittedTestStart"),
                CommitManufacturingComplete = dtRow.Field<DateTime?>("CommitedManufacturingComplete"),
                PilotCommit = dtRow.Field<DateTime?>("PilotCommit"),
                TSD = dtRow.Field<DateTime?>("TSD"),
                CRD = dtRow.Field<DateTime?>("CRD"),
                SRD = dtRow.Field<DateTime?>("SRD"),
                MCSD = dtRow.Field<DateTime?>("MCSD"),
                CapacityPlanningColor = dtRow.Field<string>("CapacityPlanningColor"),
                Notes = dtRow.Field<string>("Note"),
                PilotRisk = dtRow.Field<string>("PilotRisk"),
                SalesPriority = dtRow.Field<string>("SalesPriority"),
                CRDGapDays = dtRow.Field<int?>("CRDGap"),
                CRDEsc = dtRow.Field<bool?>("CRDEsc"),
                POABOMReleaseDate = dtRow.Field<DateTime?>("POABOMReleaseDate"),
                TechnicianRequiredSubassembly = dtRow.Field<int?>("TechnicianRequiredSubassembly"),
                TechnicianRequiredIntegration = dtRow.Field<int?>("TechnicianRequiredIntegration"),
                TechnicianRequiredTest = dtRow.Field<int?>("TechnicianRequiredTest"),
                TechnicianRequiredPostTest = dtRow.Field<int?>("TechnicianRequiredPostTest"),
                FremontID = dtRow.Field<long?>("FremontID"),
                PlanofRecord = dtRow.Field<DateTime?>("PlanofRecord"),
                T09Comment = dtRow.Field<string>("T09Comment"),
                PilotMCSD = dtRow.Field<DateTime?>("PilotCommit"),
                SapMCSD = dtRow.Field<DateTime?>("MCSD"),
                URBPBuildTypeName = dtRow.Field<string>("URBPBuildTypeName"),
                PilotToolType = dtRow.Field<string>("PilotToolType"),
                SchedulingColor = dtRow.Field<string>("SchedulingColor"),
                OnPOR = dtRow.Field<string>("OnPOR"),
                ScheduleStatus = dtRow.Field<string>("ScheduleStatus"),
                ScheduleStatusId = dtRow.Field<long?>("ScheduleStatusId"),
            }).ToList();
            return masterRecords;
        }

        public object GetScheduleStatus(string connString)
        {
            DataTable dataTable;

            dataTable = SqlHelper.GetDataTable(connString, "uspGetScheduleStatus");

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
            {
                ScheduleStatusId = dtRow.Field<long?>("ScheduleStatusId"),
                OptionName = dtRow.Field<string>("OptionName")
            }).ToList();

            return masterRecords;
        }

        public int UpdateModuleWip(string connString, ModulesSummaryWip[] modules)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                foreach (var items in modules)
                {
                    SqlParameter[] param = {
                        new SqlParameter("@PilotProductID", items.pilotProductID),
                        new SqlParameter("@PilotRisk",items.pilotRisk),
                        new SqlParameter("@Comment",items.comments),
                        new SqlParameter("@Status",items.status),
                        new SqlParameter("@StaffPriority",items.wipPriority),
                        new SqlParameter("@Staffed",items.Staffed),
                        new SqlParameter("@Shift",items.Shift),
                        new SqlParameter("@BuildingId",items.BuildingId),
                        new SqlParameter("@CurrentDayShift",items.CurrentDayShift),
                        new SqlParameter("@LastDayShift",items.LastDayShift),
                        new SqlParameter("@CurrentNightShift",items.CurrentNightShift),
                        new SqlParameter("@LastNightShift",items.LastNightShift),
                        outParam
                    };
                    resultCount += SqlHelper.ExecuteNonQuery(connString, "uspEditModuleWIP", param);
                }
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public int UpdateModuleWipFlat(string connString, ModuleSumaryWIPFlat modules)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@PilotProductID", modules.pilotProductID),
                    new SqlParameter("@WIPflat", modules.wipFlat),
                    outParam
                };

                resultCount += SqlHelper.ExecuteNonQuery(connString, "uspEditModuleSummary", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public List<ModulesWIP> GetModuleWIP(string connString, int plantID, DateTime todaydate)
        {
            DataSet dataSet;
            SqlParameter[] param = { new SqlParameter("@plantID", plantID) };

            Regex rg = new Regex(@"\d+");

            dataSet = SqlHelper.GetDataSet(connString, "USPGetModuleWIP", param); //if you add a column here, add in the Method - SendWIPEmail too, thanks :) 
            //also add the column's name and the corresponding property name entry in the db table - WIPReportEmailColumnMapping, if not added the email send will fail. // do not duplicate the column name
            List<ModulesWIP> masterRecords = dataSet.Tables[0].AsEnumerable().Select(dtRow => new ModulesWIP()
            {
                IsCritical = dtRow.Field<bool?>("IsCritical"),
                IsGating = dtRow.Field<bool?>("IsGating"),
                WIPPriority = dtRow.Field<string?>("WIPPriority"),
                PilotRisk = dtRow.Field<string>("PilotRisk"),
                URBPBuildTypeName = dtRow.Field<string>("URBPBuildTypeName"),
                PilotProductID = Convert.ToInt32(dtRow["PilotProductID"]),
                PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                BEN = dtRow.Field<string>("BEN"),
                CompletePerc = dtRow.Field<string>("CompletePerc"),
                ToolType = dtRow.Field<string?>("ToolType"),
                BuildType = dtRow.Field<string>("BuildType"),
                PBOM = dtRow.Field<string>("PBOM"),
                OpsApprovedForShift = dtRow.Field<string>("OpsApprovedForShift"),
                DayShiftOnly = dtRow.Field<bool?>("DayShiftOnly"),

                ActualLaunch = dtRow.Field<DateTime?>("ActualLaunch"),
                PlannedLaunch = dtRow.Field<DateTime?>("PlannedLaunch"),
                LaunchDelta = dtRow.Field<int?>("LaunchDelta"),
                ActualLaunchHover = dtRow.Field<string>("ActualLaunchHover"),
                PreviousUpdatePlannedLaunchHover = dtRow.Field<string>("PreviousUpdatePlannedLaunchHover"),
                LastUpdatedPlannedLaunchHover = dtRow.Field<string>("LastUpdatedPlannedLaunchHover"),

                ActualIntegrationStart = dtRow.Field<DateTime?>("ActualIntegrationStart"),
                PlannedIntegrationStart = dtRow.Field<DateTime?>("PlannedIntegrationStart"),
                IntegrationDelta = dtRow.Field<int?>("IntegrationDelta"),
                ActualIntegrationStarthHover = dtRow.Field<string>("ActualIntegrationStarthHover"),
                PreviousUpdatePlannedIntegrationStartHover = dtRow.Field<string>("PreviousUpdatePlannedIntegrationStartHover"),
                LastUpdatedPlannedIntegrationStartHover = dtRow.Field<string>("LastUpdatedPlannedIntegrationStartHover"),

                ActualTestStart = dtRow.Field<DateTime?>("ActualTestStart"),
                PlannedTestStart = dtRow.Field<DateTime?>("PlannedTestStart"),
                TestStartDelta = dtRow.Field<int?>("TestStartDelta"),
                ActualTestStartHover = dtRow.Field<string>("ActualTestStartHover"),
                PreviousUpdatePlannedTestStartHover = dtRow.Field<string>("PreviousUpdatePlannedTestStartHover"),
                LastUpdatedPlannedTestStartHover = dtRow.Field<string>("LastUpdatedPlannedTestStartHover"),

                ActualManufacturingComplete = dtRow.Field<DateTime?>("ActualManufacturingComplete"),
                PlannedManufacturingComplete = dtRow.Field<DateTime?>("PlannedManufacturingComplete"),
                ManufacturingCompleteDelta = dtRow.Field<int?>("ManufacturingCompleteDelta"),
                ActualManufacturingCompletetHover = dtRow.Field<string>("ActualManufacturingCompletetHover"),
                PreviousUpdatePlannedManufacturingCompleteHover = dtRow.Field<string>("PreviousUpdatePlannedManufacturingCompleteHover"),
                LastUpdatedPlannedManufacturingCompleteHover = dtRow.Field<string>("LastUpdatedPlannedManufacturingCompleteHover"),

                MCSD = dtRow.Field<DateTime?>("MCSD"),
                MCSDDelta = dtRow.Field<int?>("MCSDDelta"),
                CRD = dtRow.Field<DateTime?>("CRD"),
                ShortagesAtLaunch = dtRow.Field<int?>("ShortagesAtLaunch"),
                ProductType = dtRow.Field<string>("ProductType"),
                Staffed = dtRow.Field<bool?>("Staffed"),
                Idle = dtRow.Field<string>("Idle"),
                FremontID = dtRow.Field<long?>("FremontID"),
                FCID = dtRow.Field<string>("FCID"),
                BuildStyle = dtRow.Field<string>("BuildStyle"),
                Status = dtRow.Field<string>("Status"),
                Comments = dtRow.Field<string>("Comments"),
                Bldg = dtRow.Field<string>("Bldg"),
                BuildingId = dtRow.Field<long?>("BuildingId"),
                ActualTestComplete = dtRow.Field<DateTime?>("ActualTestComplete"),
                PlannedTestComplete = dtRow.Field<DateTime?>("PlannedTestComplete"),
                IdleTestDay = dtRow.Field<int?>("IdleTestDay"),
                PostTestDays = dtRow.Field<int?>("PostTestDays"),
                TargetTestDays = dtRow.Field<int?>("TargetTestDays"),
                ModulesInWIP = dtRow.Field<int?>("ModulesInWIP"),
                CurrentDayShift = dtRow.Field<bool?>("CurrentDayShift"),
                LastDayShift = dtRow.Field<bool?>("LastDayShift"),
                CurrentNightShift = dtRow.Field<bool?>("CurrentNightShift"),
                LastNightShift = dtRow.Field<bool?>("LastNightShift"),
                ProcessModule = dtRow.Field<int?>("ProcessModule")


            }).ToList();

            List<ModuleOperationDateModels> operationDateModel = dataSet.Tables[1].AsEnumerable().Select(dtRow => new OperationDateModel()
            {
                PilotProductID = dtRow.Field<long?>("PilotProductID"),
                OperationID = dtRow.Field<long?>("OperationID"),
                OPDescription = dtRow.Field<string>("OPDescription"),
                OpOrder = string.IsNullOrEmpty(dtRow.Field<string>("OPDescription")) ? 99999 : string.IsNullOrEmpty(rg.Match(dtRow.Field<string>("OPDescription")).Value.Trim()) ? 99999 : Convert.ToInt32(rg.Match(dtRow.Field<string>("OPDescription")).Value),
                ZoneID = dtRow.Field<long?>("ZoneID"),
                ZoneDescription = dtRow.Field<string>("ZoneDescription"),
                ZoneName = dtRow.Field<string>("ZoneName"),
                ZoneOrder = string.IsNullOrEmpty(dtRow.Field<string>("ZoneDescription")) ? 99999 : string.IsNullOrEmpty(rg.Match(dtRow.Field<string>("ZoneDescription")).Value.Trim()) ? 99999 : Convert.ToInt32(rg.Match(dtRow.Field<string>("ZoneDescription")).Value),
                ActualPlannedStartDate = dtRow.Field<DateTime?>("ActualStartDate"),
                GatingDate = dtRow.Field<DateTime?>("GatingDate"),
                CalculatedStandardTimeDays = dtRow.Field<decimal?>("CalculatedStandardTimeDays"),
                ModuleProcess = dtRow.Field<string>("ModuleProcess"),
                ActualPlannedLaunch = dtRow.Field<DateTime?>("ActualPlannedLaunch"),
                NumberOfSteps = dtRow.Field<int?>("NumberofSteps"),
                CompletedSteps = dtRow.Field<int?>("CompletedSteps"),
                ModuleShiftHours = dtRow.Field<int?>("ModuleShiftHours"),
                StandardTimeHours = dtRow.Field<double?>("StandardTimeHours"),
                Plant = dtRow.Field<string>("Plant")
            }).OrderBy(x => x.ZoneOrder).ThenBy(x => x.OpOrder).ToList().GroupBy(x => x.PilotProductID)
            .Select(z => new ModuleOperationDateModels() { PilotProductId = z.Key.Value, OperationDateModels = z.Where(x => x.ActualPlannedLaunch != null).ToList() }).ToList();


            List<ModuleListOfModuleVFDWithName> moduleVFDs = dataSet.Tables[2].AsEnumerable().Select(dtRow => new ModuleVFDWithName()
            {
                ModuleVFDId = dtRow.Field<long?>("ModuleVFDId"),
                Assignable = dtRow.Field<bool?>("Assignable"),
                BayName = dtRow.Field<string>("BayName"),
                NumberOfDays = dtRow.Field<int?>("NumberOfDays"),
                PilotProductId = dtRow.Field<long?>("PilotProductID"),
                StatusId = dtRow.Field<long?>("StatusID"),
                VFDZoneId = dtRow.Field<long?>("VFDZoneID"),
                VFDZoneName = dtRow.Field<string>("VFDZoneName")
            }).GroupBy(x => x.PilotProductId).Select(z => new ModuleListOfModuleVFDWithName()
            { PilotProductId = z.Key.Value, ModuleVFDWithNames = z.ToList() }).ToList();

            List<ModuleListOfModuleVFDWithName> moduleVFDAssignable = dataSet.Tables[3].AsEnumerable().Select(dtRow => new ModuleVFDWithName()
            {
                ModuleVFDId = dtRow.Field<long?>("ModuleVFDId"),
                Assignable = dtRow.Field<bool?>("Assignable"),
                BayName = dtRow.Field<string>("BayName"),
                NumberOfDays = dtRow.Field<int?>("NumberOfDays"),
                PilotProductId = dtRow.Field<long?>("PilotProductID"),
                StatusId = dtRow.Field<long?>("StatusID"),
                VFDZoneId = dtRow.Field<long?>("VFDZoneID"),
                VFDZoneName = dtRow.Field<string>("VFDZoneName")
            }).GroupBy(x => x.PilotProductId).Select(z => new ModuleListOfModuleVFDWithName()
            { PilotProductId = z.Key.Value, ModuleVFDWithNames = z.ToList() }).ToList();

            foreach (ModuleOperationDateModels item in operationDateModel)
            {
                ModulesWIP modulesWIP = masterRecords.FirstOrDefault(x => x.PilotProductID == item.PilotProductId);
                List<ModuleVFDWithName> moduleVFDWithNames = new List<ModuleVFDWithName>();
                List<ModuleVFDWithName> moduleVFDAssignableWithNames = new List<ModuleVFDWithName>();

                if (moduleVFDs.Where(x => x.PilotProductId == item.PilotProductId).Count() > 0)
                {
                    moduleVFDWithNames = moduleVFDs.FirstOrDefault(x => x.PilotProductId == item.PilotProductId).ModuleVFDWithNames;
                }
                if (moduleVFDAssignable.Where(x => x.PilotProductId == item.PilotProductId).Count() > 0)
                {
                    moduleVFDAssignableWithNames = moduleVFDAssignable.FirstOrDefault(x => x.PilotProductId == item.PilotProductId).ModuleVFDWithNames;
                }
                List<OperationDateModel> dateModels = CommonHelper.SetDatesOfOperations(item.OperationDateModels, todaydate, moduleVFDWithNames, moduleVFDAssignableWithNames);

                //whenever you change the logic in the below updation codes, change the login where else these lines are writtne e.g - GetEditModScheduledSummary of EditModuleHome.cs
                modulesWIP.ActualIntegrationStartIsManual = modulesWIP.ActualIntegrationStart.HasValue;
                if (dateModels.Where(x => x.PilotProductID == item.PilotProductId && x.ZoneDescription.ToLower().Contains("Final Integration".ToLower())).Count() > 0)
                {
                    modulesWIP.ActualIntegrationStart = modulesWIP.ActualIntegrationStart
                        ?? dateModels.Where(x => x.ZoneDescription.ToLower().Contains("Final Integration".ToLower()))
                        .FirstOrDefault().ActualPlannedStartDate;
                }

                modulesWIP.ActualTestStartIsManual = modulesWIP.ActualTestStart.HasValue;
                if (dateModels.Where(x => x.ModuleProcess == "Test").Count() > 0)
                {
                    modulesWIP.ActualTestStart = modulesWIP.ActualTestStart
                                ?? dateModels.Where(x => x.PilotProductID == item.PilotProductId && x.ModuleProcess == "Test").OrderBy(z => z.ActualPlannedStartDate).FirstOrDefault().ActualPlannedStartDate;
                }

                modulesWIP.ActualTestCompleteIsManual = modulesWIP.ActualTestComplete.HasValue;
                modulesWIP.PlannedTestComplete = modulesWIP.ActualTestStart.HasValue
                    ? modulesWIP.ActualTestStart.Value.AddDays(modulesWIP.TargetTestDays
                        ?? 0 + modulesWIP.IdleTestDay ?? 0) : modulesWIP.ActualTestComplete; // to keep it the same

                modulesWIP.ActualManufacturingCompleteIsManual = modulesWIP.ActualManufacturingComplete.HasValue;

                if (modulesWIP.ActualTestComplete != null)
                {
                    modulesWIP.PlannedManufacturingComplete = modulesWIP.ActualTestComplete.HasValue ? modulesWIP.ActualTestComplete.Value.AddDays(modulesWIP.PostTestDays ?? 1) : modulesWIP.ActualTestComplete;
                }
                else if (modulesWIP.ActualTestStart != null)
                {
                    modulesWIP.PlannedManufacturingComplete = modulesWIP.ActualTestStart.HasValue ? modulesWIP.ActualTestStart.Value.AddDays(modulesWIP.PostTestDays ?? 1).AddDays(modulesWIP.IdleTestDay ?? 0).AddDays(modulesWIP.TargetTestDays ?? 0) : modulesWIP.ActualTestComplete;
                }
                else
                {
                    modulesWIP.PlannedManufacturingComplete = null;
                }

                if (modulesWIP.ActualManufacturingCompleteIsManual)
                {
                    modulesWIP.ActualManufacturingComplete = modulesWIP.ActualManufacturingComplete != null ? modulesWIP.ActualManufacturingComplete : null;
                }
                else if (modulesWIP.ActualTestComplete != null)
                {
                    modulesWIP.ActualManufacturingComplete = modulesWIP.ActualTestComplete.HasValue
                        ? modulesWIP.ActualTestComplete.Value.AddDays(modulesWIP.PostTestDays ?? 1) : modulesWIP.ActualTestComplete;
                }
                else if (modulesWIP.ActualTestStart != null)
                {
                    modulesWIP.ActualManufacturingComplete = modulesWIP.ActualTestStart.HasValue
                        ? modulesWIP.ActualTestStart.Value.AddDays(modulesWIP.PostTestDays ?? 1).AddDays(modulesWIP.IdleTestDay ?? 0).AddDays(modulesWIP.TargetTestDays ?? 0) : modulesWIP.ActualTestComplete;
                }
                else
                {
                    modulesWIP.ActualManufacturingComplete = null;
                }

                //setting the delta  (99999 is invalid data which gets converted to NULL in Front end)
                modulesWIP.LaunchDelta = (modulesWIP.PlannedLaunch - modulesWIP.ActualLaunch).HasValue ? (modulesWIP.PlannedLaunch - modulesWIP.ActualLaunch).Value.Days : 99999;
                modulesWIP.IntegrationDelta = (modulesWIP.PlannedIntegrationStart - modulesWIP.ActualIntegrationStart).HasValue ? (modulesWIP.PlannedIntegrationStart - modulesWIP.ActualIntegrationStart).Value.Days : 99999;
                modulesWIP.TestStartDelta = (modulesWIP.PlannedTestStart - modulesWIP.ActualTestStart).HasValue ? (modulesWIP.PlannedTestStart - modulesWIP.ActualTestStart).Value.Days : 99999;
                modulesWIP.ManufacturingCompleteDelta = (modulesWIP.PlannedManufacturingComplete - modulesWIP.ActualManufacturingComplete).HasValue ? (modulesWIP.PlannedManufacturingComplete - modulesWIP.ActualManufacturingComplete).Value.Days : 99999;
                modulesWIP.MCSDDelta = (modulesWIP.MCSD - modulesWIP.ActualManufacturingComplete).HasValue ? (modulesWIP.MCSD - modulesWIP.ActualManufacturingComplete).Value.Days : 99999;
            }

            foreach (ModulesWIP modulesWIP in masterRecords)
            {
                if (todaydate >= modulesWIP.ActualLaunch && todaydate <= modulesWIP.ActualIntegrationStart)
                {
                    modulesWIP.CurrentStage = "Launch";
                }
                else if (todaydate >= modulesWIP.ActualIntegrationStart && todaydate <= modulesWIP.ActualTestStart)
                {
                    modulesWIP.CurrentStage = "Integration";
                }
                else if (todaydate >= modulesWIP.ActualTestStart && todaydate <= modulesWIP.ActualManufacturingComplete)
                {
                    modulesWIP.CurrentStage = "Test";
                }
                else if (todaydate >= modulesWIP.ActualManufacturingComplete)
                {
                    modulesWIP.CurrentStage = "Mfg";
                }
            }

            return masterRecords;
        }
        public DataTable ToDataTable<T>(IList<T> data)
        {
            PropertyDescriptorCollection properties =
                TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();
            foreach (PropertyDescriptor prop in properties)
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            foreach (T item in data)
            {
                DataRow row = table.NewRow();
                foreach (PropertyDescriptor prop in properties)
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                table.Rows.Add(row);
            }
            return table;
        }
        public int UpdateToolType(string connString, ModuleToolType[] moduleToolType)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                foreach (var items in moduleToolType)
                {
                    SqlParameter[] param = {
               new SqlParameter("@ToolTypeID",items.ToolTypeID),
                 new SqlParameter("@ModuleProcessID",items.ModuleProcessID),
                new SqlParameter("@BayRequired",items.BayRequired ),
                new SqlParameter("@HourRequired",items.HourRequired ),
                new SqlParameter("@TechnicianRequired",items.TechnicianRequired ),
                new SqlParameter("@TransitionDate",items.TransitionDate),
                new SqlParameter("@POABOMReleaseDate",items.POABOMReleaseDate),
                outParam
           };
                    resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateToolType", param);
                }
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public List<MasterRecords> GetModuleColorDDL(string connString)
        {
            DataTable dataTable;
            dataTable = SqlHelper.GetDataTable(connString, "uspGetModuleColorDDL", null);
            List<MasterRecords> masterRecords = dataTable.AsEnumerable().Select(dtRow => new MasterRecords()
            {
                MasterRecordID = dtRow.Field<long>("MasterRecordID"),
                MasterRecordName = dtRow.Field<string>("MasterRecordName"),
                Value = dtRow.Field<string>("Value")
            }).ToList();
            return masterRecords;
        }


        public string GetModuleSummary(string connString, int plantID, int UserID)
        {
            SqlParameter[] param = {
                new SqlParameter("@PlantID",plantID),
                new SqlParameter("@UserID",UserID),
            };
            DataTable dataTable;
            dataTable = SqlHelper.GetDataTable(connString, "uspGetModuleSummary", param); // if you add a column here add in the method - GetModuleSummarybyID too..

            Regex sortReg = new Regex("\\d+");

            var dataOutput = dataTable.Rows.Cast<DataRow>()
               .GroupBy(x => new
               {
                   FremontID = x["FremontID"],
                   PO = x["PO"],
                   SO = x["SO"],
                   BOMItem = x["BOMItem"],
                   InWIP = x["InWip"],
                   BEN = x["BEN"],
                   FCID = x["FCID"],
                   ProductType = x["ProductType"],
                   PilotSerialNumber = x["PilotSerialNumber"],
                   PostText = x["PostText"],
                   PilotProductID = x["PilotProductID"],
                   Active = x["Active"],
                   BuildStyleId = x["BuildStyleId"],
                   BuildStyle = x["BuildStyle"],
                   ProductionStatus = x["ProductionStatus"].ToString(),
                   PercentType = x["PercentType"].ToString(),
                   TestPostTestPercentage = x["TestPostTestPercentage"].ToString(),
                   AuditItems = x["AuditItems"],
                   TOIs = x["TOIs"],
                   OBCs = x["OBCs"],
                   IssueLogs = x["IssueLogs"],
                   NCIs = x["NCIs"],
                   Shortages = x["Shortages"],
                   IsCustomAssemblyPercent = x["IsCustomAssemblyPercent"],
                   CustomAssemblyPercent = x["CustomAssemblyPercent"],
                   PartNumber = x["PartNumber"],
                   SubassemblyType = x["SubassemblyType"],
                   IsWorkedOn = x["IsWorkedOn"],
                   PostTestPercent = x["PostTestPercent"],
                   TestPercent = x["TestPercent"],
                   BENorPSNReconfiguredFrom = x["BENorPSNReconfiguredFrom"],
                   PilotToolType = x["PilotToolType"]
               }, x => x,
                   (key, list) =>
                       new
                       {
                           ModuleInfo = key,
                           Zones = list.Select(y => new
                           {
                               ZoneDescription = y["ZoneDescription"],
                               Progress = (double?)y["TimeComplete"] / ((double?)y["TotalTime"] == 0 ? 1 : (double?)y["TotalTime"]) * 100,
                               ZoneID = y.Field<long?>("ZoneID"),
                               ZoneOrder = y.Field<int?>("ZoneOrder"),
                               ModuleProcessID = y.Field<long?>("ModuleProcessID"),
                               ModuleProcess = y.Field<string>("ModuleProcess")
                           }).ToList().OrderBy(x => x.ModuleProcessID).ThenBy(x => x.ZoneOrder).ThenBy(x => x.ZoneDescription),
                           Integration = Convert.ToBoolean(key.IsCustomAssemblyPercent) ? Convert.ToDouble(key.CustomAssemblyPercent) : list.Where(x => x["ModuleProcess"].ToString() == "Subassembly" || x["ModuleProcess"].ToString() == "Integration").Sum(y => (double?)y["TimeComplete"]) /
                                (list.Where(x => x["ModuleProcess"].ToString() == "Subassembly" || x["ModuleProcess"].ToString() == "Integration").Sum(y => (double?)y["TotalTime"]) == 0 ? 1 :
                                  list.Where(x => x["ModuleProcess"].ToString() == "Subassembly" || x["ModuleProcess"].ToString() == "Integration").Sum(y => (double?)y["TotalTime"])) * 100,
                           SubAssemblyPercentage = list.Where(x => x["ModuleProcess"].ToString() == "Subassembly").Sum(y => (double?)y["TimeComplete"]) /
                                (list.Where(x => x["ModuleProcess"].ToString() == "Subassembly").Sum(y => (double?)y["TotalTime"]) == 0 ? 1 :
                                  list.Where(x => x["ModuleProcess"].ToString() == "Subassembly").Sum(y => (double?)y["TotalTime"])) * 100,
                           IntegrationPercentage = list.Where(x => x["ModuleProcess"].ToString() == "Integration").Sum(y => (double?)y["TimeComplete"]) /
                                (list.Where(x => x["ModuleProcess"].ToString() == "Integration").Sum(y => (double?)y["TotalTime"]) == 0 ? 1 :
                                  list.Where(x => x["ModuleProcess"].ToString() == "Integration").Sum(y => (double?)y["TotalTime"])) * 100,
                           TestPercentage = key.PercentType.ToString() == "T" ? Convert.ToInt32(key.TestPostTestPercentage) : (key.PercentType.ToString() == "P" ? 100 : 0),
                           PostTestPercentage = key.PercentType.ToString() == "P" ? Convert.ToInt32(key.TestPostTestPercentage) : 0

                       }).Select(x =>
                       {
                           string ModuleProcess = "";
                           if (x.PostTestPercentage > 0)
                           {
                               ModuleProcess = "POST-TEST";
                           }
                           else if (x.TestPercentage > 0)
                           {
                               ModuleProcess = "TEST";
                           }
                           else if (x.Integration > 0)
                           {
                               ModuleProcess = "INTEGRATION";
                           }
                           else
                           {
                               ModuleProcess = "SUB ASSEMBLY";
                           }
                           return new
                           {
                               x.ModuleInfo,
                               x.Zones,
                               x.Integration,
                               x.SubAssemblyPercentage,
                               x.IntegrationPercentage,
                               x.TestPercentage,
                               x.PostTestPercentage,
                               ModuleProcess
                           };
                       }
                       ).ToList();

            return Newtonsoft.Json.JsonConvert.SerializeObject(dataOutput);
        }
        private int GetNumbertoOrder(object line, Regex regex)
        {
            var stringVal = (line == DBNull.Value) ? string.Empty : line.ToString();

            var haveValue = stringVal != null && regex.IsMatch(stringVal);

            return haveValue ? int.Parse(regex.Match(stringVal).Value) : 999999;
        }

        public string GetModuleSummarybyID(string connString, int pilotProductID)
        {
            SqlParameter[] param = {
                new SqlParameter("@PilotProductID",pilotProductID),
            };

            DataTable dataTable;
            dataTable = SqlHelper.GetDataTable(connString, "uspGetModuleSummaryById", param); //  // if you add a column here add in the method - GetModuleSummary too..

            Regex sortReg = new Regex("\\d+");

            var dataOutput = dataTable.Rows.Cast<DataRow>()
               .GroupBy(x => new
               {
                   FremontID = x["FremontID"],
                   PO = x["PO"],
                   SO = x["SO"],
                   BOMItem = x["BOMItem"],
                   InWIP = x["InWip"],
                   BEN = x["BEN"],
                   FCID = x["FCID"],
                   ProductType = x["ProductType"],
                   PilotSerialNumber = x["PilotSerialNumber"],
                   PostText = x["PostText"],
                   PilotProductID = x["PilotProductID"],
                   Active = x["Active"],
                   BuildStyleId = x["BuildStyleId"],
                   BuildStyle = x["BuildStyle"],
                   ProductionStatus = x["ProductionStatus"].ToString(),
                   PercentType = x["PercentType"].ToString(),
                   TestPostTestPercentage = x["TestPostTestPercentage"].ToString(),
                   AuditItems = x["AuditItems"],
                   TOIs = x["TOIs"],
                   OBCs = x["OBCs"],
                   IssueLogs = x["IssueLogs"],
                   NCIs = x["NCIs"],
                   Shortages = x["Shortages"],
                   IsCustomAssemblyPercent = x["IsCustomAssemblyPercent"],
                   CustomAssemblyPercent = x["CustomAssemblyPercent"],
                   PartNumber = x["PartNumber"],
                   SubassemblyType = x["SubassemblyType"],
                   PostTestPercent = x["PostTestPercent"],
                   TestPercent = x["TestPercent"],
                   BENorPSNReconfiguredFrom = x["BENorPSNReconfiguredFrom"],
                   PilotToolType = x["PilotToolType"]
               }, x => x,
                   (key, list) =>
                       new
                       {
                           ModuleInfo = key,
                           Zones = list.Select(y => new
                           {
                               ZoneDescription = y["ZoneDescription"],
                               Progress = (double?)y["TimeComplete"] / ((double?)y["TotalTime"] == 0 ? 1 : (double?)y["TotalTime"]) * 100,
                               ZoneID = y.Field<long?>("ZoneID"),
                               ZoneOrder = y.Field<int?>("ZoneOrder"),
                               ModuleProcessID = y.Field<long?>("ModuleProcessID"),
                               ModuleProcess = y.Field<string>("ModuleProcess")
                           }).ToList().OrderBy(x => x.ModuleProcessID).ThenBy(x => x.ZoneOrder).ThenBy(x => x.ZoneDescription),
                           Integration = Convert.ToBoolean(key.IsCustomAssemblyPercent) ? Convert.ToDouble(key.CustomAssemblyPercent) : list.Where(x => x["ModuleProcess"].ToString() == "Subassembly" || x["ModuleProcess"].ToString() == "Integration").Sum(y => (double?)y["TimeComplete"]) /
                                (list.Where(x => x["ModuleProcess"].ToString() == "Subassembly" || x["ModuleProcess"].ToString() == "Integration").Sum(y => (double?)y["TotalTime"]) == 0 ? 1 :
                                  list.Where(x => x["ModuleProcess"].ToString() == "Subassembly" || x["ModuleProcess"].ToString() == "Integration").Sum(y => (double?)y["TotalTime"])) * 100,
                           SubAssemblyPercentage = list.Where(x => x["ModuleProcess"].ToString() == "Subassembly").Sum(y => (double?)y["TimeComplete"]) /
                                (list.Where(x => x["ModuleProcess"].ToString() == "Subassembly").Sum(y => (double?)y["TotalTime"]) == 0 ? 1 :
                                  list.Where(x => x["ModuleProcess"].ToString() == "Subassembly").Sum(y => (double?)y["TotalTime"])) * 100,
                           IntegrationPercentage = list.Where(x => x["ModuleProcess"].ToString() == "Integration").Sum(y => (double?)y["TimeComplete"]) /
                                (list.Where(x => x["ModuleProcess"].ToString() == "Integration").Sum(y => (double?)y["TotalTime"]) == 0 ? 1 :
                                  list.Where(x => x["ModuleProcess"].ToString() == "Integration").Sum(y => (double?)y["TotalTime"])) * 100,
                           TestPercentage = key.PercentType.ToString() == "T" ? Convert.ToInt32(key.TestPostTestPercentage) : (key.PercentType.ToString() == "P" ? 100 : 0),
                           PostTestPercentage = key.PercentType.ToString() == "P" ? Convert.ToInt32(key.TestPostTestPercentage) : 0

                       }).Select(x =>
                       {
                           string ModuleProcess = "";
                           if (x.PostTestPercentage > 0)
                           {
                               ModuleProcess = "POST-TEST";
                           }
                           else if (x.TestPercentage > 0)
                           {
                               ModuleProcess = "TEST";
                           }
                           else if (x.Integration > 0)
                           {
                               ModuleProcess = "INTEGRATION";
                           }
                           else
                           {
                               ModuleProcess = "SUB ASSEMBLY";
                           }
                           return new
                           {
                               x.ModuleInfo,
                               x.Zones,
                               x.Integration,
                               x.SubAssemblyPercentage,
                               x.IntegrationPercentage,
                               x.TestPercentage,
                               x.PostTestPercentage,
                               ModuleProcess
                           };
                       }
                       ).ToList();

            return Newtonsoft.Json.JsonConvert.SerializeObject(dataOutput);
        }

        public string GetModuleSummaryInfo(string connString, int plantID)
        {
            SqlParameter[] param = {
                new SqlParameter("@PlantID",plantID),
            };

            DataTable dataTable;
            dataTable = SqlHelper.GetDataTable(connString, "uspGetModuleSummaryInfo", param);


            var dataOutput = dataTable.Rows.Cast<DataRow>()
                .Select(x => new
                {
                    ModuleInfo = new
                    {
                        FremontID = x["FremontID"],
                        PO = x["PO"],
                        SO = x["SO"],
                        BOMItem = x["BOMItem"],
                        BEN = x["BEN"],
                        FCID = x["FCID"],
                        ProductType = x["ProductType"],
                        PilotSerialNumber = x["PilotSerialNumber"],
                        PostText = x["PostText"],
                        PilotProductID = x["PilotProductID"],
                        Active = x["Active"],
                        CommitLaunch = x["CommitLaunch"],
                        PlannedLaunch = x["PlannedLaunch"],
                        WIPFlag = x["WIPFlag"],
                        PartNumber = x["PartNumber"],
                        SubassemblyType = x["SubassemblyType"],
                        PilotToolType = x["PilotToolType"],
                        BuildStyleId = x["BuildStyleId"],
                        BuildStyle = x["BuildStyle"]
                    }
                });

            return Newtonsoft.Json.JsonConvert.SerializeObject(dataOutput);
        }

        public int DeleteModuleProductionPlan(string connString, int ProductionPlanID, long PilotProductID)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@pilotProductID", PilotProductID),
                    new SqlParameter("@productionPlanID",  ProductionPlanID),
                    outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspDeleteModuleProductionPlan", param);
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }

        }


        public List<ModuleSearch> GetModuleSearch(string connString, string searchText, int plantID, int ProductionPlanID)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = { new SqlParameter("@plantID", plantID),
                        new SqlParameter("@SearchText", searchText),
                          new SqlParameter("@ProductionPlanID", ProductionPlanID)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetModuleSearch", param);
                List<ModuleSearch> moduleSearch = dataTable.AsEnumerable().Select(dtRow => new ModuleSearch()
                {
                    PilotProductID = dtRow.Field<long?>("PilotProductID"),
                    URBPID = dtRow.Field<long?>("URBPID"),
                    FCID = dtRow.Field<string>("FCID"),
                    PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                    RevenueType = dtRow.Field<string>("RevenueType"),
                    RecordType = dtRow.Field<string>("RecordType"),
                    ToolType = dtRow.Field<string>("ToolType"),
                    BuildName = dtRow.Field<string>("BuildName"),
                    Customer = dtRow.Field<string>("Customer"),
                    ProductType = dtRow.Field<string>("ProductType"),
                    BEN = dtRow.Field<string>("BEN"),
                    OnPOR = dtRow.Field<string>("OnPOR"),
                    ActualManufacturingComplete = dtRow.Field<DateTime?>("ActualManufacturingComplete"),
                    PlanofRecord = dtRow.Field<DateTime?>("PlanofRecord"),
                    CustomerRequestDate = dtRow.Field<DateTime?>("CustomerRequestDate"),
                    ScheduleStatusId = dtRow.Field<long?>("ScheduleStatusId"),
                    ScheduleStatus = dtRow.Field<string>("ScheduleStatus")
                }).ToList();
                return moduleSearch;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<ModuleSearch> GetModuleToAddProductionPlan(string connString, int plantID, int ProductionPlanID)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = { new SqlParameter("@plantID", plantID),
                          new SqlParameter("@ProductionPlanID", ProductionPlanID)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetModuleToAddProductionPlan", param);
                List<ModuleSearch> moduleSearch = dataTable.AsEnumerable().Select(dtRow => new ModuleSearch()
                {
                    PilotProductID = dtRow.Field<long?>("PilotProductID"),
                    URBPID = dtRow.Field<long?>("URBPID"),
                    FCID = dtRow.Field<string>("FCID"),
                    PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                    RevenueType = dtRow.Field<string>("RevenueType"),
                    RecordType = dtRow.Field<string>("RecordType"),
                    ToolType = dtRow.Field<string>("ToolType"),
                    BuildName = dtRow.Field<string>("BuildName"),
                    Customer = dtRow.Field<string>("Customer"),
                    ProductType = dtRow.Field<string>("ProductType"),
                    BEN = dtRow.Field<string>("BEN"),
                    OnPOR = dtRow.Field<string>("OnPOR"),
                    ActualManufacturingComplete = dtRow.Field<DateTime?>("ActualManufacturingComplete"),
                    PlanofRecord = dtRow.Field<DateTime?>("PlanofRecord"),
                    CustomerRequestDate = dtRow.Field<DateTime?>("CustomerRequestDate"),
                    ScheduleStatusId = dtRow.Field<long?>("ScheduleStatusId"),
                    ScheduleStatus = dtRow.Field<string>("ScheduleStatus")
                }).ToList();
                return moduleSearch;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public List<ModuleSubAssembly> GetSpecialSubAssySummary(string connString, int plantID, string SubassemblyType, long PilotProductId)
        {
            DataTable dataTable;
            SqlParameter[] param = { new SqlParameter("@plantID", plantID),
                new SqlParameter("@SubassemblyType", SubassemblyType),
                new SqlParameter("@PilotProductId", PilotProductId)};

            dataTable = SqlHelper.GetDataTable(connString, "USPGetSpecialSubAssySummary", param);
            List<ModuleSubAssembly> masterRecords = dataTable.AsEnumerable().Select(dtRow => new ModuleSubAssembly()
            {
                PilotProductID = dtRow.Field<long?>("PilotProductID"),
                Hot = dtRow.Field<bool?>("hot"),
                PurchaseOrderNumber = dtRow.Field<string>("PurchaseOrderNumber"),
                PCWOReleased = dtRow.Field<bool?>("PCWOReleased"),
                CA10ShortageFree = dtRow.Field<bool?>("CA10ShortageFree"),
                DateDelivered = dtRow.Field<DateTime?>("DateDelivered"),
                MfgApproved = dtRow.Field<bool?>("MfgApproved"),
                PCFSAuditedBy = dtRow.Field<string>("PCFSAuditedBy"),
                Qty = dtRow.Field<int?>("Qty"),
                PlannerName = dtRow.Field<string>("PlannerName"),
                PartNumber = dtRow.Field<string>("PartNumber"),
                Description = dtRow.Field<string>("DESCRIPTION"),
                MaterialReadiness = dtRow.Field<DateTime?>("MaterialReadiness"),
                CRD = dtRow.Field<DateTime?>("CRD"),
                CommitLaunch = dtRow.Field<DateTime?>("CommitLaunch"),
                CommittedTestStart = dtRow.Field<DateTime?>("CommittedTestStart"),
                CommitedManufacturingComplete = dtRow.Field<DateTime?>("CommitedManufacturingComplete"),
                PilotCommit = dtRow.Field<DateTime?>("PilotCommit"),
                AssemblyTechnicianName = dtRow.Field<string>("AssemblyTechnicianName"),
                TestTechnicianName = dtRow.Field<string>("TestTechnicianName"),
                MRPDemand = dtRow.Field<string>("MRPDemand"),
                MRPDemandID = dtRow.Field<long?>("MRPDemandID"),
                CapacityPlanningColor = dtRow.Field<string>("CapacityPlanningColor"),
                Note = dtRow.Field<string>("Note"),
                CreatedDate = dtRow.Field<DateTime?>("CreatedDate"),
                ModifiedDate = dtRow.Field<DateTime?>("ModifiedDate"),
                SubassemblyBays = dtRow.Field<int?>("SubassemblyBays"),
                TestBays = dtRow.Field<int?>("TestBays"),
                SubassemblyBuildHours = dtRow.Field<decimal?>("SubassemblyBuildHours"),
                TestBuildHours = dtRow.Field<decimal?>("TestBuildHours"),
                SubassemblyTechnician = dtRow.Field<int?>("SubassemblyTechnician"),
                TestTechnician = dtRow.Field<int?>("TestTechnician"),
                TotalLaborHour = dtRow.Field<decimal?>("TotalLaborHour"),
                ActualTestStart = dtRow.Field<DateTime?>("ActualTestStart"),
                ActualTestComplete = dtRow.Field<DateTime?>("ActualTestComplete"),
                AssemblySerialNumber = dtRow.Field<string>("AssemblySerialNumber"),
                InShipping = dtRow.Field<bool?>("InShipping"),
                EngineeringPOC = dtRow.Field<string>("EngineeringPOC"),
                PilotMEApproved = dtRow.Field<bool?>("PilotMEApproved"),
                SOELink = dtRow.Field<string>("SOELink"),
                PCFSShortageFreeAudit = dtRow.Field<bool?>("PCFSShortageFreeAudit"),
                Auditor = dtRow.Field<string>("Auditor"),
                KitReceivedDate = dtRow.Field<DateTime?>("KitReceivedDate"),
                SerialNum = dtRow.Field<string>("SerialNum"),
                TechBuild = dtRow.Field<string>("TechBuild"),
                TechTest = dtRow.Field<string>("TechTest"),
                Rework = dtRow.Field<bool?>("Rework"),
                SpclProcess = dtRow.Field<bool?>("SpclProcess"),
                SpecialSubAssyType = dtRow.Field<string>("SubassemblyType"),
                EstimatedBuildTime = dtRow.Field<int>("EstimatedBuildTime"),
                ProductionOrderNum = dtRow.Field<string>("ProductionOrderNum"),
            }).ToList();

            return masterRecords;
        }

        public List<MasterRecords> GetMRPDemand(string connString)
        {
            try
            {
                DataTable dataTable;
                dataTable = SqlHelper.GetDataTable(connString, "uspGetMRPDemand", null);
                List<MasterRecords> masterRecords = dataTable.AsEnumerable().Select(dtRow => new MasterRecords()
                {
                    MasterRecordID = Convert.ToInt32(dtRow["MasterRecordID"]),
                    MasterRecordName = Convert.ToString(dtRow["MasterRecordName"])
                }).ToList();
                return masterRecords;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public int AddEditSpecialSubAssy(string connString, ModuleSubAssembly modulesSubAssembly)
        {
            try
            {

                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@PlantId", modulesSubAssembly.PlantId),
                    new SqlParameter("@PilotProductID", modulesSubAssembly.PilotProductID),
                    new SqlParameter("@SpecialSubAssyType",modulesSubAssembly.SpecialSubAssyType),
                    new SqlParameter("@PCWOReleased",modulesSubAssembly.PCWOReleased),
                    new SqlParameter("@PurchaseOrderNumber",modulesSubAssembly.PurchaseOrderNumber),
                    new SqlParameter("@PlannerName",modulesSubAssembly.PlannerName),
                    new SqlParameter("@MRPDemandTypeID",modulesSubAssembly.MRPDemandID),
                    new SqlParameter("@PartNumber",modulesSubAssembly.PartNumber),
                    new SqlParameter("@DESCRIPTION",modulesSubAssembly.Description),
                    new SqlParameter("@Qty",modulesSubAssembly.Qty),
                    new SqlParameter("@CRD",modulesSubAssembly.CRD),
                    new SqlParameter("@Hot",modulesSubAssembly.Hot),
                    new SqlParameter("@Rework",modulesSubAssembly.Rework),
                    new SqlParameter("@SpclProcess",modulesSubAssembly.SpclProcess),
                    new SqlParameter("@EstimatedBuildTime",modulesSubAssembly.EstimatedBuildTime),
                    new SqlParameter("@EstimatedTestTime",modulesSubAssembly.EstimatedTestTime),
                    new SqlParameter("@CapacityPlanningColor",modulesSubAssembly.CapacityPlanningColor),
                    new SqlParameter("@Notes",modulesSubAssembly.Note),
                    new SqlParameter("@EngineeringPOC", modulesSubAssembly.EngineeringPOC),
                    new SqlParameter("@PilotMEApproved", modulesSubAssembly.PilotMEApproved),
                    new SqlParameter("@SOELink", modulesSubAssembly.SOELink),
                    new SqlParameter("@CommitedManufacturingComplete", modulesSubAssembly.CommitedManufacturingComplete),
                    new SqlParameter("@MfgApproved", modulesSubAssembly.MfgApproved),
                    new SqlParameter("@SubAssemblyTechnician", modulesSubAssembly.SubassemblyTechnician),
                    new SqlParameter("@TestTechnician", modulesSubAssembly.TestTechnician),
                    new SqlParameter("@TestBays", modulesSubAssembly.TestBays),
                    new SqlParameter("@PCFSShortageFreeAudit", modulesSubAssembly.PCFSShortageFreeAudit),
                    new SqlParameter("@Auditor", modulesSubAssembly.Auditor),
                    new SqlParameter("@DateDelivered", modulesSubAssembly.DateDelivered),
                    new SqlParameter("@KitReceivedDate", modulesSubAssembly.KitReceivedDate),
                    new SqlParameter("@SerialNum", modulesSubAssembly.SerialNum),
                    new SqlParameter("@TechBuild", modulesSubAssembly.TechBuild),
                    new SqlParameter("@TechTest", modulesSubAssembly.TechTest),
                    new SqlParameter("@CA10ShortageFree", modulesSubAssembly.CA10ShortageFree),
                    new SqlParameter("@ActualTestStart", modulesSubAssembly.ActualTestStart),
                    new SqlParameter("@ActualTestComplete", modulesSubAssembly.ActualTestComplete),
                    new SqlParameter("@AssemblySerialNumber", modulesSubAssembly.AssemblySerialNumber),
                    new SqlParameter("@InShipping", modulesSubAssembly.InShipping),
                    new SqlParameter("@SubAssemblyHours", modulesSubAssembly.SubassemblyBuildHours),
                    new SqlParameter("@TestHours", modulesSubAssembly.TestBuildHours),
                    new SqlParameter("@SubAssemblyBays", modulesSubAssembly.SubassemblyBays),
                    new SqlParameter("@PilotManufacturingCommitedShipDate", modulesSubAssembly.PilotCommit),
                    new SqlParameter("@ProductionOrderNum",modulesSubAssembly.ProductionOrderNum),
                    outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspAddSpecialSubAssy", param);



                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int SendWIPEmail(string connString, List<string> columns, int plantID, string host, SmtpMailHelper smtpMailHelper, string fromEmail, DateTime todaydate)
        {


            try
            {
                DataSet dataSet;
                DataTable dataTable;
                SqlParameter[] param = { new SqlParameter("@plantID", plantID) };

                Regex rg = new Regex(@"\d+");

                dataSet = SqlHelper.GetDataSet(connString, "USPGetModuleWIP", param); //if you add a column here, add in the Method - SendWIPEmail too, thanks :) 
                                                                                      //also add the column's name and the corresponding property name entry in the db table - WIPReportEmailColumnMapping, if not added the email send will fail. // do not duplicate the column name
                List<ModulesWIP> masterRecords = dataSet.Tables[0].AsEnumerable().Select(dtRow => new ModulesWIP()
                {
                    IsCritical = dtRow.Field<bool?>("IsCritical"),
                    IsGating = dtRow.Field<bool?>("IsGating"),
                    WIPPriority = dtRow.Field<string?>("WIPPriority"),
                    PilotRisk = dtRow.Field<string>("PilotRisk"),
                    URBPBuildTypeName = dtRow.Field<string>("URBPBuildTypeName"),
                    PilotProductID = Convert.ToInt32(dtRow["PilotProductID"]),
                    PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                    BEN = dtRow.Field<string>("BEN"),
                    CompletePerc = dtRow.Field<string>("CompletePerc"),
                    ToolType = dtRow.Field<string?>("ToolType"),
                    BuildType = dtRow.Field<string>("BuildType"),
                    PBOM = dtRow.Field<string>("PBOM"),
                    OpsApprovedForShift = dtRow.Field<string>("OpsApprovedForShift"),
                    DayShiftOnly = dtRow.Field<bool?>("DayShiftOnly"),

                    ActualLaunch = dtRow.Field<DateTime?>("ActualLaunch"),
                    PlannedLaunch = dtRow.Field<DateTime?>("PlannedLaunch"),
                    LaunchDelta = dtRow.Field<int?>("LaunchDelta"),
                    ActualLaunchHover = dtRow.Field<string>("ActualLaunchHover"),
                    PreviousUpdatePlannedLaunchHover = dtRow.Field<string>("PreviousUpdatePlannedLaunchHover"),
                    LastUpdatedPlannedLaunchHover = dtRow.Field<string>("LastUpdatedPlannedLaunchHover"),

                    ActualIntegrationStart = dtRow.Field<DateTime?>("ActualIntegrationStart"),
                    PlannedIntegrationStart = dtRow.Field<DateTime?>("PlannedIntegrationStart"),
                    IntegrationDelta = dtRow.Field<int?>("IntegrationDelta"),
                    ActualIntegrationStarthHover = dtRow.Field<string>("ActualIntegrationStarthHover"),
                    PreviousUpdatePlannedIntegrationStartHover = dtRow.Field<string>("PreviousUpdatePlannedIntegrationStartHover"),
                    LastUpdatedPlannedIntegrationStartHover = dtRow.Field<string>("LastUpdatedPlannedIntegrationStartHover"),

                    ActualTestStart = dtRow.Field<DateTime?>("ActualTestStart"),
                    PlannedTestStart = dtRow.Field<DateTime?>("PlannedTestStart"),
                    TestStartDelta = dtRow.Field<int?>("TestStartDelta"),
                    ActualTestStartHover = dtRow.Field<string>("ActualTestStartHover"),
                    PreviousUpdatePlannedTestStartHover = dtRow.Field<string>("PreviousUpdatePlannedTestStartHover"),
                    LastUpdatedPlannedTestStartHover = dtRow.Field<string>("LastUpdatedPlannedTestStartHover"),

                    ActualManufacturingComplete = dtRow.Field<DateTime?>("ActualManufacturingComplete"),
                    PlannedManufacturingComplete = dtRow.Field<DateTime?>("PlannedManufacturingComplete"),
                    ManufacturingCompleteDelta = dtRow.Field<int?>("ManufacturingCompleteDelta"),
                    ActualManufacturingCompletetHover = dtRow.Field<string>("ActualManufacturingCompletetHover"),
                    PreviousUpdatePlannedManufacturingCompleteHover = dtRow.Field<string>("PreviousUpdatePlannedManufacturingCompleteHover"),
                    LastUpdatedPlannedManufacturingCompleteHover = dtRow.Field<string>("LastUpdatedPlannedManufacturingCompleteHover"),

                    MCSD = dtRow.Field<DateTime?>("MCSD"),
                    MCSDDelta = dtRow.Field<int?>("MCSDDelta"),
                    CRD = dtRow.Field<DateTime?>("CRD"),
                    ShortagesAtLaunch = dtRow.Field<int?>("ShortagesAtLaunch"),
                    ProductType = dtRow.Field<string>("ProductType"),
                    Staffed = dtRow.Field<bool?>("Staffed"),
                    Idle = dtRow.Field<string>("Idle"),
                    FremontID = dtRow.Field<long?>("FremontID"),
                    FCID = dtRow.Field<string>("FCID"),
                    BuildStyle = dtRow.Field<string>("BuildStyle"),
                    Status = dtRow.Field<string>("Status"),
                    Comments = dtRow.Field<string>("Comments"),
                    Bldg = dtRow.Field<string>("Bldg"),
                    BuildingId = dtRow.Field<long?>("BuildingId"),
                    ActualTestComplete = dtRow.Field<DateTime?>("ActualTestComplete"),
                    IdleTestDay = dtRow.Field<int?>("IdleTestDay"),
                    PostTestDays = dtRow.Field<int?>("PostTestDays"),
                    TargetTestDays = dtRow.Field<int?>("TargetTestDays"),
                    ModulesInWIP = dtRow.Field<int?>("ModulesInWIP")
                }).ToList();

                List<ModuleOperationDateModels> operationDateModel = dataSet.Tables[1].AsEnumerable().Select(dtRow => new OperationDateModel()
                {
                    PilotProductID = dtRow.Field<long?>("PilotProductID"),
                    OperationID = dtRow.Field<long?>("OperationID"),
                    OPDescription = dtRow.Field<string>("OPDescription"),
                    OpOrder = string.IsNullOrEmpty(dtRow.Field<string>("OPDescription")) ? 99999 : string.IsNullOrEmpty(rg.Match(dtRow.Field<string>("OPDescription")).Value.Trim()) ? 99999 : Convert.ToInt32(rg.Match(dtRow.Field<string>("OPDescription")).Value),
                    ZoneID = dtRow.Field<long?>("ZoneID"),
                    ZoneDescription = dtRow.Field<string>("ZoneDescription"),
                    ZoneName = dtRow.Field<string>("ZoneName"),
                    ZoneOrder = string.IsNullOrEmpty(dtRow.Field<string>("ZoneDescription")) ? 99999 : string.IsNullOrEmpty(rg.Match(dtRow.Field<string>("ZoneDescription")).Value.Trim()) ? 99999 : Convert.ToInt32(rg.Match(dtRow.Field<string>("ZoneDescription")).Value),
                    ActualPlannedStartDate = dtRow.Field<DateTime?>("ActualStartDate"),
                    GatingDate = dtRow.Field<DateTime?>("GatingDate"),
                    CalculatedStandardTimeDays = dtRow.Field<decimal?>("CalculatedStandardTimeDays"),
                    ModuleProcess = dtRow.Field<string>("ModuleProcess"),
                    ActualPlannedLaunch = dtRow.Field<DateTime?>("ActualPlannedLaunch"),
                    NumberOfSteps = dtRow.Field<int?>("NumberofSteps"),
                    CompletedSteps = dtRow.Field<int?>("CompletedSteps"),
                    ModuleShiftHours = dtRow.Field<int?>("ModuleShiftHours"),
                    StandardTimeHours = dtRow.Field<double?>("StandardTimeHours"),
                    Plant = dtRow.Field<string>("Plant")
                }).GroupBy(x => x.PilotProductID).Select(z => new ModuleOperationDateModels() { PilotProductId = z.Key.Value, OperationDateModels = z.ToList() }).ToList();

                List<ModuleListOfModuleVFDWithName> moduleVFDs = dataSet.Tables[2].AsEnumerable().Select(dtRow => new ModuleVFDWithName()
                {
                    ModuleVFDId = dtRow.Field<long?>("ModuleVFDId"),
                    Assignable = dtRow.Field<bool?>("Assignable"),
                    BayName = dtRow.Field<string>("BayName"),
                    NumberOfDays = dtRow.Field<int?>("NumberOfDays"),
                    PilotProductId = dtRow.Field<long?>("PilotProductID"),
                    StatusId = dtRow.Field<long?>("StatusID"),
                    VFDZoneId = dtRow.Field<long?>("VFDZoneID"),
                    VFDZoneName = dtRow.Field<string>("VFDZoneName")
                }).GroupBy(x => x.PilotProductId).Select(z => new ModuleListOfModuleVFDWithName() { PilotProductId = z.Key.Value, ModuleVFDWithNames = z.ToList() }).ToList();

                List<ModuleListOfModuleVFDWithName> moduleVFDAssignable = dataSet.Tables[3].AsEnumerable().Select(dtRow => new ModuleVFDWithName()
                {
                    ModuleVFDId = dtRow.Field<long?>("ModuleVFDId"),
                    Assignable = dtRow.Field<bool?>("Assignable"),
                    BayName = dtRow.Field<string>("BayName"),
                    NumberOfDays = dtRow.Field<int?>("NumberOfDays"),
                    PilotProductId = dtRow.Field<long?>("PilotProductID"),
                    StatusId = dtRow.Field<long?>("StatusID"),
                    VFDZoneId = dtRow.Field<long?>("VFDZoneID"),
                    VFDZoneName = dtRow.Field<string>("VFDZoneName")
                }).GroupBy(x => x.PilotProductId).Select(z => new ModuleListOfModuleVFDWithName()
                { PilotProductId = z.Key.Value, ModuleVFDWithNames = z.ToList() }).ToList();

                foreach (ModuleOperationDateModels item in operationDateModel)
                {
                    ModulesWIP modulesWIP = masterRecords.FirstOrDefault(x => x.PilotProductID == item.PilotProductId);
                    List<ModuleVFDWithName> moduleVFDWithNames = new List<ModuleVFDWithName>();
                    List<ModuleVFDWithName> moduleVFDAssignableWithNames = new List<ModuleVFDWithName>();

                    if (moduleVFDs.Where(x => x.PilotProductId == item.PilotProductId).Count() > 0)
                    {
                        moduleVFDWithNames = moduleVFDs.FirstOrDefault(x => x.PilotProductId == item.PilotProductId).ModuleVFDWithNames;
                    }
                    if (moduleVFDAssignable.Where(x => x.PilotProductId == item.PilotProductId).Count() > 0)
                    {
                        moduleVFDAssignableWithNames = moduleVFDAssignable.FirstOrDefault(x => x.PilotProductId == item.PilotProductId).ModuleVFDWithNames;
                    }

                    List<OperationDateModel> dateModels = CommonHelper.SetDatesOfOperations(item.OperationDateModels, todaydate, moduleVFDWithNames, moduleVFDAssignableWithNames);


                    //whenever you change the logic in the below updation codes, change the login where else these lines are writtne e.g - GetEditModScheduledSummary of EditModuleHome.cs
                    modulesWIP.ActualIntegrationStartIsManual = modulesWIP.ActualIntegrationStart.HasValue;
                    if (dateModels.Where(x => x.ZoneDescription.ToLower().Contains("Final Integration".ToLower())).Count() > 0)
                    {
                        modulesWIP.ActualIntegrationStart = modulesWIP.ActualIntegrationStart
                            ?? dateModels.Where(x => x.ZoneDescription.ToLower().Contains("Final Integration".ToLower())).FirstOrDefault().ActualPlannedStartDate;
                    }

                    modulesWIP.ActualTestStartIsManual = modulesWIP.ActualTestStart.HasValue;
                    if (dateModels.Where(x => x.ModuleProcess == "Test").Count() > 0)
                    {
                        modulesWIP.ActualTestStart = modulesWIP.ActualTestStart
                                    ?? dateModels.Where(x => x.PilotProductID == item.PilotProductId && x.ModuleProcess == "Test").OrderBy(z => z.ActualPlannedStartDate).FirstOrDefault().ActualPlannedStartDate;
                    }

                    modulesWIP.ActualTestCompleteIsManual = modulesWIP.ActualTestComplete.HasValue;
                    modulesWIP.ActualTestComplete = modulesWIP.ActualTestStart.HasValue
                        ? modulesWIP.ActualTestStart.Value.AddDays(modulesWIP.TargetTestDays
                            ?? 0 + modulesWIP.IdleTestDay ?? 0) : modulesWIP.ActualTestComplete; // to keep it the same

                    modulesWIP.ActualManufacturingCompleteIsManual = modulesWIP.ActualManufacturingComplete.HasValue;
                    modulesWIP.ActualManufacturingComplete = modulesWIP.ActualTestComplete.HasValue
                        ? modulesWIP.ActualTestComplete.Value.AddDays(modulesWIP.PostTestDays ?? 1) : modulesWIP.ActualTestComplete;

                    modulesWIP.LaunchDelta = (modulesWIP.PlannedLaunch - modulesWIP.ActualLaunch).HasValue ? (modulesWIP.PlannedLaunch - modulesWIP.ActualLaunch).Value.Days : 99999;
                    modulesWIP.IntegrationDelta = (modulesWIP.PlannedIntegrationStart - modulesWIP.ActualIntegrationStart).HasValue ? (modulesWIP.PlannedIntegrationStart - modulesWIP.ActualIntegrationStart).Value.Days : 99999;
                    modulesWIP.TestStartDelta = (modulesWIP.PlannedTestStart - modulesWIP.ActualTestStart).HasValue ? (modulesWIP.PlannedTestStart - modulesWIP.ActualTestStart).Value.Days : 99999;
                    modulesWIP.ManufacturingCompleteDelta = (modulesWIP.PlannedManufacturingComplete - modulesWIP.ActualManufacturingComplete).HasValue ? (modulesWIP.PlannedManufacturingComplete - modulesWIP.ActualManufacturingComplete).Value.Days : 99999;
                    modulesWIP.MCSDDelta = (modulesWIP.MCSD - modulesWIP.ActualManufacturingComplete).HasValue ? (modulesWIP.MCSD - modulesWIP.ActualManufacturingComplete).Value.Days : 99999;
                }

                foreach (ModulesWIP modulesWIP in masterRecords)
                {
                    if (todaydate >= modulesWIP.ActualLaunch && todaydate <= modulesWIP.ActualIntegrationStart)
                    {
                        modulesWIP.CurrentStage = "Launch";
                    }
                    else if (todaydate >= modulesWIP.ActualIntegrationStart && todaydate <= modulesWIP.ActualTestStart)
                    {
                        modulesWIP.CurrentStage = "Integration";
                    }
                    else if (todaydate >= modulesWIP.ActualTestStart && todaydate <= modulesWIP.ActualManufacturingComplete)
                    {
                        modulesWIP.CurrentStage = "Test";
                    }
                    else if (todaydate >= modulesWIP.ActualManufacturingComplete)
                    {
                        modulesWIP.CurrentStage = "Mfg";
                    }
                }

                //new email changes here -> 
                SqlParameter[] paramEmail = { new SqlParameter("@plantID", plantID) };

                dataTable = SqlHelper.GetDataTable(connString, "USPGetEmailForWIPReport", paramEmail);

                var ToEmail = dataTable.AsEnumerable().Select(dtRow => new
                {
                    EmailAddressId = dtRow.Field<long?>("EmailAddressId"),
                    EmailAddress = dtRow.Field<string>("EmailAddress")
                }).ToList();

                //this is to fetch the property name and the column name to display in the WIP report - can contact Juhi regarding this.
                dataTable = SqlHelper.GetDataTable(connString, "uspGetWIPEmailColumnMappings");

                var columnMapping = dataTable.AsEnumerable().Select(dtRow => new
                {
                    PropertyName = dtRow.Field<string>("PropertyName"),
                    ColumnName = dtRow.Field<string>("ColumnName")
                }).ToList();

                //column Mappings
                List<KeyValuePair<string, string>> columnNameMappings = new List<KeyValuePair<string, string>>();

                foreach (var item in columnMapping)
                {
                    columnNameMappings.Add(new KeyValuePair<string, string>(item.PropertyName, item.ColumnName));
                }

                //write your email body here
                StringBuilder wipEmail = new StringBuilder();

                wipEmail.Append("<p>Click here to the WIP report in PMPM application.</p>"); //need to add a link

                StringBuilder tableHeader = new StringBuilder();
                StringBuilder tableBody = new StringBuilder();
                tableHeader.Append("<tr style=\"background-color: #dddddd;\">");
                foreach (string column in columns)
                {
                    tableHeader.Append("<th>" + column + "</th>");
                }
                tableHeader.Append("<tr>");

                foreach (ModulesWIP modulesWIP in masterRecords)
                {
                    tableBody.Append("<tr>" + GetTableDataWIPEmail(modulesWIP, columns, columnNameMappings, host) + "</tr>");
                }

                string linkHtml = $"<div><p>Click <a href=\"https://{host}/execution-and-tracking/WIPReport\">here</a> to see the WIP report in PMPM web application.</p></div>";

                string tableHTML = "<div><table style = \"width:100%\">" + tableHeader.ToString() + tableBody.ToString() + "</table></div>";

                string legalHTML = $"<div>" +
                            $"	<p style=\"font-size: 8px;\">LAM RESEARCH CONFIDENTIALITY NOTICE: This e-mail transmission, and any documents, files, or previous e-mail messages attached" +
                            $" to it, (collectively, \"E-mail Transmission\") may be subject to one or more of the following based on the associated sensitivity level: E-mail Transmission" +
                            $" (i) contains confidential information, (ii) is prohibited from distribution outside of Lam, and/or (iii) is intended solely for and restricted to the specified" +
                            $" recipient(s). If you are not the intended recipient, or a person responsible for delivering it to the intended recipient, you are hereby notified that any " +
                            $"disclosure, copying, distribution or use of any of the information contained in or attached to this message is STRICTLY PROHIBITED. If you have received this" +
                            $" transmission in error, please immediately notify the sender and destroy the original transmission and its attachments without reading them or saving them " +
                            $"to disk. Thank you.</p>" +
                            $"</div>";

                smtpMailHelper.Body = linkHtml + tableHTML + legalHTML;
                smtpMailHelper.Recipient = string.Join(';', ToEmail.Select(x => x.EmailAddress).ToList());
                smtpMailHelper.Sender = fromEmail;
                smtpMailHelper.Subject = $"WIP Report {todaydate:MM/dd/yyyy hh:mm tt}";

                smtpMailHelper.Send();

                return 1;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        private string GetTableDataWIPEmail(ModulesWIP modulesWIP, List<string> columns, List<KeyValuePair<string, string>> columnNameMappings, string host)
        {
            StringBuilder tdData = new StringBuilder();

            foreach (string col in columns)
            {
                string propertyName = columnNameMappings.Where(x => x.Value.Trim() == col.Trim()).FirstOrDefault().Key;
                string value = "";
                if (col == "Integration Commit")
                {
                    value = ""; //not integrated yet
                }
                else if (col == "C/G")
                {
                    List<string> cgValues = new List<string>();
                    if (modulesWIP.IsCritical.HasValue)
                    {
                        if (modulesWIP.IsCritical.Value)
                        {
                            cgValues.Add("C");
                        }
                    }
                    if (modulesWIP.IsGating.HasValue)
                    {
                        if (modulesWIP.IsGating.Value)
                        {
                            cgValues.Add("G");
                        }
                    }
                    value = string.Join("/", cgValues);
                }

                else if (col == "BEN" || col == "Pilot Serial Number")
                {
                    string URL = Uri.EscapeUriString($"https://{host}/edit-module/{modulesWIP.PilotProductID}/0");
                    string BENorPSN = modulesWIP.GetType().GetProperty(propertyName).GetValue(modulesWIP, null) == null ? "" : modulesWIP.GetType().GetProperty(propertyName).GetValue(modulesWIP, null).ToString();
                    value = $"<a href=\"{URL}\">{BENorPSN}</a>";
                }

                else if (col == "Day Shift Only")
                {
                    value = modulesWIP.DayShiftOnly.HasValue ? modulesWIP.DayShiftOnly.Value ? "Yes" : "No" : "No";
                }

                else if (col == "Staff")
                {
                    string isChecked = modulesWIP.Staffed.HasValue ? modulesWIP.Staffed.Value ? "checked" : "" : "";
                    value = $"<input type = \"checkbox\" disabled {isChecked} />";
                }

                else if (modulesWIP.GetType().GetProperty(propertyName).PropertyType == typeof(DateTime?))
                {
                    if (col == "MCSD")
                    {
                        value = modulesWIP.GetType().GetProperty(propertyName).GetValue(modulesWIP, null) == null ? ""
                        : Convert.ToDateTime(modulesWIP.GetType().GetProperty(propertyName).GetValue(modulesWIP, null)).ToString("M-d-yy");
                    }
                    else
                    {
                        value = modulesWIP.GetType().GetProperty(propertyName).GetValue(modulesWIP, null) == null ? ""
                        : Convert.ToDateTime(modulesWIP.GetType().GetProperty(propertyName).GetValue(modulesWIP, null)).ToString("M-d");
                    }

                }
                else
                {
                    if (col == "Launch Delta")
                    {
                        modulesWIP.LaunchDelta = modulesWIP.LaunchDelta == 99999 ? null : modulesWIP.LaunchDelta;
                    }
                    else if (col == "Integration Delta")
                    {
                        modulesWIP.IntegrationDelta = modulesWIP.IntegrationDelta == 99999 ? null : modulesWIP.IntegrationDelta;
                    }
                    else if (col == "Test Start Delta")
                    {
                        modulesWIP.TestStartDelta = modulesWIP.TestStartDelta == 99999 ? null : modulesWIP.TestStartDelta;
                    }
                    else if (col == "Mfg Complete Delta")
                    {
                        modulesWIP.ManufacturingCompleteDelta = modulesWIP.ManufacturingCompleteDelta == 99999 ? null : modulesWIP.ManufacturingCompleteDelta;
                    }
                    else if (col == "MCSD Delta")
                    {
                        modulesWIP.MCSDDelta = modulesWIP.MCSDDelta == 99999 ? null : modulesWIP.MCSDDelta;
                    }

                    value = modulesWIP.GetType().GetProperty(propertyName).GetValue(modulesWIP, null) == null ? ""
                    : modulesWIP.GetType().GetProperty(propertyName).GetValue(modulesWIP, null).ToString();

                }

                tdData.Append(value.Contains("<td") ? value : "<td style=\"border: 1px solid black;border-collapse: collapse;\">" + value + "</td>");
            }

            return tdData.ToString();
        }
        public List<ModulesSummary> GetOtherSAPModule(string connString, int plantID)//make return type string
        {
            DataTable dataTable;
            SqlParameter[] param = { new SqlParameter("@plantID", plantID) };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetOtherSAPModule", param);

            List<ModulesSummary> OtherSAPModule = dataTable.AsEnumerable().Select(dtRow => new ModulesSummary()
            {
                FCID = dtRow.Field<string>("FCID"),
                BEN = dtRow.Field<string>("BEN"),
                RecordType = dtRow.Field<string>("RecordType"),
                RevenueCode = dtRow.Field<string>("RevenueCode"),
                ProductGroupName = dtRow.Field<string>("ProductGroupName"),
                ProductGroupID = dtRow.Field<long?>("ProductGroupID"),
                ToolTypeName = dtRow.Field<string>("ToolTypeName"),
                ToolTypeID = dtRow.Field<long?>("ToolTypeID"),
                TSD = dtRow.Field<DateTime?>("TSD"),
                CRD = dtRow.Field<DateTime?>("CRD"),
                SRD = dtRow.Field<DateTime?>("SRD"),
                MCSD = dtRow.Field<DateTime?>("MCSD"),
                LPRID = dtRow.Field<string>("LPRID"),
            }).ToList();
            return OtherSAPModule;
        }

        public List<ModulesSummary> GetOtherSAPModuleSearch(string connString, int plantID, string searchText)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = {
                           new SqlParameter("@SearchText", searchText),
                          new SqlParameter("@plantID", plantID)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetOtherSAPModuleOnSearch", param);
                List<ModulesSummary> OtherSAPModuleSearch = dataTable.AsEnumerable().Select(dtRow => new ModulesSummary()
                {
                    FCID = dtRow.Field<string>("FCID"),
                    BEN = dtRow.Field<string>("BEN"),
                    RecordType = dtRow.Field<string>("RecordType"),
                    RevenueCode = dtRow.Field<string>("RevenueCode"),
                    ProductGroupName = dtRow.Field<string>("ProductGroupName"),
                    ProductGroupID = dtRow.Field<long?>("ProductGroupID"),
                    ToolTypeName = dtRow.Field<string>("ToolTypeName"),
                    ToolTypeID = dtRow.Field<long?>("ToolTypeID"),
                    TSD = dtRow.Field<DateTime?>("TSD"),
                    CRD = dtRow.Field<DateTime?>("CRD"),
                    SRD = dtRow.Field<DateTime?>("SRD"),
                    MCSD = dtRow.Field<DateTime?>("MCSD"),
                    LPRID = dtRow.Field<string>("LPRID"),
                }).ToList();
                return OtherSAPModuleSearch;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public int AddOtherSAPModule(string connString, Modules modules)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter[] param = {
                new SqlParameter("@ProductGroupID",modules.ProductGroupID),
                new SqlParameter("@ToolTypeID",modules.ToolTypeID),
                new SqlParameter("@FCID",modules.FCID),
                new SqlParameter("@BEN",modules.BEN),
                new SqlParameter("@RecordType",modules.RecordType),
                new SqlParameter("@RevenueType",modules.RevenueType),
                new SqlParameter("@PlantID",modules.PlantID),
                new SqlParameter("@CRD",modules.CRD),
                new SqlParameter("@TSD",modules.TSD),
                new SqlParameter("@SRD",modules.SRD),
                new SqlParameter("@MCSD",modules.MCSD),
                new SqlParameter("@LPRID", modules.LPRID),
                new SqlParameter("@ProductGroupName",modules.ProductGroupName),
              outParam
             };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspAddOtherSAPModule", param);
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public object GetSerializationNumbers(string connString, int plantId, int pilotproductid)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param = { new SqlParameter("@plantID", plantId), new SqlParameter("@pilotProductId", pilotproductid) };

                dataTable = SqlHelper.GetDataTable(connString, "uspGetSerializationNumbers", param);
                List<SerializationNumbers> masterRecords = dataTable.AsEnumerable().Select(dtRow => new SerializationNumbers()
                {
                    SerializationNumberToolsID = dtRow.Field<long>("SerializationNumberToolsID"),
                    Category = dtRow.Field<string>("Category"),
                    Zone = dtRow.Field<string>("Zone"),
                    ToolName = dtRow.Field<string>("ToolName"),
                    Active = dtRow.Field<bool?>("Active"),
                    PartNum = dtRow.Field<string>("PartNum"),
                    SerialNum = dtRow.Field<string>("SerialNum")
                }).ToList();


                var serialNumber = masterRecords.GroupBy(x => x.Category).ToList();

                return serialNumber;
            }
            catch (Exception ex)
            {

                throw new Exception(ex.ToString());
            }
        }

        public int UpdateSerializationNumbers(string connString, SerializationRequest[] serializationRequest)
        {
            var resultCount = 0;
            var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            try
            {
                foreach (var items in serializationRequest)
                {
                    if (items.PartNum == null)
                    {
                        items.PartNum = "";
                    }
                    if (items.SerialNum == null)
                    {
                        items.SerialNum = "";
                    }
                    SqlParameter[] param1 = {
                     new SqlParameter("@SerializationNumberToolsID", items.SerializationNumberToolsID),
                     new SqlParameter("@pilotproductid", items.Pilotproductid),
                     new SqlParameter("@PartNum", items.PartNum),
                     new SqlParameter("@SerialNum", items.SerialNum), outParam
                    };
                    resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateSerializationNumbers", param1);

                }
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
    }
}
