﻿using LAM.PMPM.DAL;
using LAM.PMPM.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace LAM.PMPM.BL
{
    public class RoleBL
    {
        DataTable dataTable;

        public List<Role> GetRoles(string connString)
        {
            try
            {
                dataTable = new DataTable();
                dataTable = SqlHelper.GetDataTable(connString, "uspGetRoles", null);
                List<Role> roleList = dataTable.AsEnumerable().Select(dtRow => new Role()
                {
                    RoleId = dtRow.Field<long?>("RoleID"),
                    RoleName = dtRow.Field<string>("RoleName"),
                    DisplayName = dtRow.Field<string>("DisplayName")
                }).ToList();
                return roleList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
    }
}
