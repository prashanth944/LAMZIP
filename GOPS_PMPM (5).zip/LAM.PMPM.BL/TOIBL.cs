﻿using LAM.PMPM.DAL;
using LAM.PMPM.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Text;
using System.Linq;
using LAM.PMPM.Model.ViewModel;

namespace LAM.PMPM.BL
{
    public class TOIBL
    {
        DataTable dataTable = null;

        public List<MasterRecords> GetTOIStatus(string connString)
        {
            try
            {
                dataTable = new DataTable();
                dataTable = SqlHelper.GetDataTable(connString, "uspGetTOIStatus", null);
                List<MasterRecords> StatusData = dataTable.AsEnumerable().Select(dtRow => new MasterRecords()
                {
                    MasterRecordID = dtRow.Field<Int64>("StatusID"),
                    MasterRecordName = dtRow.Field<string>("StatusName")
                }).ToList();
                return StatusData;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }



        public List<TOI> GetTOIDetails(string connString, string status, long PilotProductID)
        {
            dataTable = new DataTable();
            SqlParameter[] param = {
                    new SqlParameter("@status",status),
                new SqlParameter("@PilotProductID",PilotProductID),
                    };
            List<TOI> TOIData = new List<TOI>();
            dataTable = SqlHelper.GetDataTable(connString, "uspGetTOIByStatus", param);
            try
            {
                TOIData = dataTable.AsEnumerable().Select(dtRow => new TOI()
                {
                    TOIID = dtRow.Field<long?>("TOIID"),
                    PilotProductID = dtRow.Field<long>("PilotProductID"),
                    BEN = dtRow.Field<string>("BEN"),
                    Title = dtRow.Field<string>("Title"),
                    IssueDescription = dtRow.Field<string>("IssueDescription"),
                    Status = dtRow.Field<string>("Status"),
                    StatusID = dtRow.Field<int>("StatusID"),
                    IsCritical = dtRow.Field<bool>("IsCritical"),
                    IsGating = dtRow.Field<bool>("IsGating"),
                    Comments = dtRow.Field<string>("Comments"),
                    ExpectedCloseDate = dtRow.Field<DateTime?>("ExpectedCloseDate"),
                    GatingDate = dtRow.Field<DateTime?>("GatingDate"),
                    ZoneID = dtRow.Field<long?>("ZoneID"),
                    PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                    Files = dtRow.Field<string>("Files").Split("|").Where(x => !string.IsNullOrEmpty(x)).ToList(),
                    CreatedBy = dtRow.Field<string>("CreatedBy"),
                    CreatedById = dtRow.Field<long?>("CreatedById"),
                    CreatedOnDate = dtRow.Field<DateTime?>("CreatedOnDate"),
                    UpdatedBy = dtRow.Field<string>("UpdatedBy"),
                    UpdatedById = dtRow.Field<long?>("UpdatedById"),
                    UpdatedOnDate = dtRow.Field<DateTime?>("UpdatedOnDate")
                }).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            return TOIData;
        }
        public List<TOI> GetTOIView(string connString, int TOIID)
        {
            dataTable = new DataTable();
            SqlParameter[] param = {
                    new SqlParameter("@TOIID",TOIID),
                    };
            List<TOI> TOIData = new List<TOI>();
            dataTable = SqlHelper.GetDataTable(connString, "uspGetTOIEditView", param);
            try
            {

                TOIData = dataTable.AsEnumerable().Select(dtRow => new TOI()
                {
                    TOIID = dtRow.Field<long>("TOIID"),
                    PilotProductID = dtRow.Field<long>("PilotProductID"),
                    BEN = dtRow.Field<string>("BEN"),
                    Title = dtRow.Field<string>("Title"),
                    IssueDescription = dtRow.Field<string>("IssueDescription"),
                    Status = dtRow.Field<string>("Status"),
                    IsCritical = dtRow.Field<bool>("IsCritical"),
                    IsGating = dtRow.Field<bool>("IsGating"),
                    Comments = dtRow.Field<string>("Comments"),
                    Files = dtRow.Field<string>("Files").Split("|").Where(x => !string.IsNullOrEmpty(x)).ToList(),
                    ExpectedCloseDate = dtRow.Field<DateTime?>("ExpectedCloseDate"),
                    GatingDate = dtRow.Field<DateTime?>("GatingDate"),
                    PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                    ZoneID = dtRow.Field<long?>("ZoneID"),
                    ZoneName = dtRow.Field<string>("ZoneName"),
                    CreatedBy = dtRow.Field<string>("CreatedBy"),
                    CreatedById = dtRow.Field<long?>("CreatedById"),
                    CreatedOnDate = dtRow.Field<DateTime?>("CreatedOnDate"),
                    UpdatedBy = dtRow.Field<string>("UpdatedBy"),
                    UpdatedById = dtRow.Field<long?>("UpdatedById"),
                    UpdatedOnDate = dtRow.Field<DateTime?>("UpdatedOnDate")
                }).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            return TOIData;
        }

        public int AddTOI(string connString, TOI toi)
        {
            try
            {
                int resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter[] param = {
                        new SqlParameter("@pilotProductID", toi.PilotProductID),
                         new SqlParameter("@TOIID", toi.TOIID),
                        new SqlParameter("@Title", toi.Title),
                        new SqlParameter("@IssueDescription", toi.IssueDescription),
                        new SqlParameter("@statusid", toi.StatusID),
                        new SqlParameter("@IsCritical", toi.IsCritical),
                        new SqlParameter("@IsGating", toi.IsGating),
                        new SqlParameter("@comments", toi.Comments),
                        new SqlParameter("@files", null),
                        new SqlParameter("@ExpectedCloseDate", toi.ExpectedCloseDate),
                        new SqlParameter("@GatingDate", toi.GatingDate),
                        new SqlParameter("@ZoneID",toi.ZoneID),
                        new SqlParameter("@CreatedOnDate",toi.CreatedOnDate),
                        new SqlParameter("@UpdatedOnDate",toi.UpdatedOnDate),
                        new SqlParameter("@CreatedById",toi.CreatedById),
                        new SqlParameter("@UpdatedById",toi.UpdatedById),
                        outParam
                        };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspAddTOI", param);
                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<ZoneValueViewModel> GetTOIZone(string connString, long PilotProductID)
        {
            dataTable = new DataTable();
            SqlParameter[] param = {
                    new SqlParameter("@PilotProductID",PilotProductID),
                    };
            List<ZoneValueViewModel> ZoneData = new List<ZoneValueViewModel>();
            dataTable = SqlHelper.GetDataTable(connString, "uspGetZonesByPPId", param);
            try
            {
                ZoneData = dataTable.AsEnumerable().Select(dtRow => new ZoneValueViewModel()
                {
                    ZoneID = dtRow.Field<long?>("ZoneID"),
                    Description = dtRow.Field<string>("Description")
                }).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            return ZoneData;
        }
        public int UpdateTOIFile(string connString, int TOIID, string filename, int isAdd)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@TOIID", TOIID),
                    new SqlParameter("@FileName ", filename),
                    new SqlParameter("@Add ", isAdd)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateTOIFiles", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int DeleteFile(string connString, int TOIID, string azFilename, int isAdd)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@TOIID", TOIID),
                    new SqlParameter("@FileName ", azFilename),
                    new SqlParameter("@Add ", isAdd)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateTOIFiles", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public List<TOI> GetTOIDashboard(string connString, int PlanID)
        {
            dataTable = new DataTable();
            SqlParameter[] param = {
                    new SqlParameter("@PlanID", PlanID),
            };
            List<TOI> TOIDashboardData = new List<TOI>();
            dataTable = SqlHelper.GetDataTable(connString, "uspGetTOIs", param);
            try
            {
                TOIDashboardData = dataTable.AsEnumerable().Select(dtRow => new TOI()
                {
                    TOIID = dtRow.Field<long?>("TOIID"),
                    PilotProductID = dtRow.Field<long>("PilotProductID"),
                    Status = dtRow.Field<string>("Status"),
                    PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                    BEN = dtRow.Field<string>("BEN"),
                    IssueDescription = dtRow.Field<string>("IssueDescription"),
                    CriticalGating = dtRow.Field<string>("CriticalGating"),
                    Comments = dtRow.Field<string>("Comments"),
                    ExpectedCloseDate = dtRow.Field<DateTime?>("ExpectedCloseDate"),
                    CreatedBy = dtRow.Field<string>("CreatedBy"),
                    CreatedById = dtRow.Field<long?>("CreatedById"),
                    CreatedOnDate = dtRow.Field<DateTime?>("CreatedOnDate"),
                    UpdatedBy = dtRow.Field<string>("UpdatedBy"),
                    UpdatedById = dtRow.Field<long?>("UpdatedById"),
                    UpdatedOnDate = dtRow.Field<DateTime?>("UpdatedOnDate")
                }).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            return TOIDashboardData;
        }


    }
}
