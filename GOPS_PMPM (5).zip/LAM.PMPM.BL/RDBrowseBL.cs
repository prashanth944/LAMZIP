﻿using LAM.PMPM.DAL;
using LAM.PMPM.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Text;
using System.Linq;
using LAM.PMPM.Model.ViewModel;
namespace LAM.PMPM.BL
{
   public class RDBrowseBL
    {
        DataTable dataTable = null;
        public List<RDBrwoseView> GetBrowseData(string connString,int PlantID)
        {
            dataTable = new DataTable();
            SqlParameter[] param = {
                    new SqlParameter("@PlantID",PlantID),
                    };
            List<RDBrwoseView> DefaultData = new List<RDBrwoseView>();
            dataTable = SqlHelper.GetDataTable(connString, "uspGetReportsBrowse", param);
            try
            {
                DefaultData = dataTable.AsEnumerable().Select(dtRow => new RDBrwoseView()
                {
                    PlantID = dtRow.Field<int?>("PlantID"),
                    ReportName = dtRow.Field<string>("ReportName"),
                    Hyperlink = dtRow.Field<string>("Hyperlink"),
                    Description = dtRow.Field<string>("Description"),
                    ReportTypeName = dtRow.Field<string>("ReportTypeName"),
                    ReportType = dtRow.Field<long>("ReportType"),
                    ReportID = dtRow.Field<int?>("ReportID"),
                  
                }).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            return DefaultData;
        }

        public List<MasterRecords> GetReportTypeDLL(string connString)
        {
            try
            {
                DataTable dataTable;
              
                dataTable = SqlHelper.GetDataTable(connString, "uspGetBrowseReportTypeDDL", null);
                List<MasterRecords> recordList = dataTable.AsEnumerable().Select(dtRow => new MasterRecords()
                {
                    MasterRecordID = dtRow.Field<long>("MasterRecordID"),
                    MasterRecordName = dtRow.Field<string>("MasterRecordName")

                }).ToList();
                return recordList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int UpdateReportsBrowse(string connString, RDBrwoseView AD)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                     new SqlParameter("@PlantID",  AD.PlantID),
                    new SqlParameter("@ReportName", AD.ReportName),
                    new SqlParameter("@Hyperlink", AD.Hyperlink),
                    new SqlParameter("@Description", AD.Description),
                    new SqlParameter("@ReportType", AD.ReportType),
                    new SqlParameter("@ReportID", AD.ReportID)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateReportsBrowse", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public int DeleteReportsBrowse(string connString, RDBrwoseView AD)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                   
                    new SqlParameter("@ReportID", AD.ReportID)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspdeleteReportsBrowse", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

    }
}
