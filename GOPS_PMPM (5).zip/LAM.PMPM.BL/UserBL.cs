﻿using LAM.PMPM.DAL;
using LAM.PMPM.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace LAM.PMPM.BL
{
    public class UserBL
    {
        public UserModel GeUserById(string connString, string userId, DateTime? currenttime)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
               new SqlParameter("@Username", userId),
               new SqlParameter("@CurrentTime", currenttime),
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetUserById", param);

            UserModel masterRecords = dataTable.AsEnumerable().Select(dtRow => new UserModel()
            {
                UserId = dtRow.Field<long?>("UserId"),
                FacilityName = dtRow.Field<string>("FacilityName"),
                PlantId = dtRow.Field<long?>("PlantId"),
                Username = dtRow.Field<string>("Username"),
                Email = dtRow.Field<string>("Email"),
                FirstName = dtRow.Field<string>("FirstName"),
                LastName = dtRow.Field<string>("LastName"),
                ShiftID = dtRow.Field<long?>("ShiftID"),
                ShiftType = dtRow.Field<string>("ShiftType"),
                HoursPerDay = dtRow.Field<decimal?>("HoursPerDay"),
                LeadDirectPerc = dtRow.Field<int?>("LeadDirectPerc"),
                PASSDirectPerc = dtRow.Field<int?>("PASSDirectPerc"),
                LAMNTId = dtRow.Field<string>("LAMNTId"),
                EmployeeId = dtRow.Field<long?>("EmployeeId"),
                ShiftStartTime = dtRow.Field<TimeSpan?>("ShiftStartTime")
            }).FirstOrDefault();
            return masterRecords;
        }

        public object GetPlantOfNewUser(string connString, string email)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
               new SqlParameter("@Email", email)
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetEmployeeDataPlantIdByEmail", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new 
            {
                EmailAddress = dtRow.Field<string>("EmailAddress"),
                PlantID = dtRow.Field<long?>("PlantID")
            }).FirstOrDefault();
            return masterRecords;
        }

        public int UpdateInsertUser(string connString, UserModel userModel)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@Username", userModel.Username),
                    new SqlParameter("@Email",  userModel.Email),
                    new SqlParameter("@PlantId",  userModel.PlantId),
                    new SqlParameter("@FirstName",  userModel.FirstName),
                    new SqlParameter("@LastName",  userModel.LastName),
                    new SqlParameter("@LAMNTId",  userModel.LAMNTId),
                    new SqlParameter("@EmployeeId",  userModel.EmployeeId),
                    new SqlParameter("@Roles",  userModel.Roles)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateUserPlant", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public object GetAllPlants(string connString)
        {
            DataTable dataTable;
            
            dataTable = SqlHelper.GetDataTable(connString, "uspGetPlants");

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
            {
                PlantName = dtRow.Field<string>("FacilityName"),
                PlantId = dtRow.Field<long?>("PlantId")
            }).ToList();
            return masterRecords;
        }

        public UserRunningOperationModel GetRunningOperation(string connString, int userId, int? operationid)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
               new SqlParameter("@userId", userId),
               new SqlParameter("@OperationId", operationid)
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetRunningOperationOfUser", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new UserRunningOperationModel
            {
                WorkRecordID = dtRow.Field<long?>("WorkRecordID"),
                PilotProductID = dtRow.Field<long?>("PilotProductID"),
                OperationID = dtRow.Field<long?>("OperationID"),
                OperationDescription = dtRow.Field<string>("Description"),
                StartTimestamp = dtRow.Field<DateTime?>("StartTimestamp"),
                IsRework = dtRow.Field<bool?>("IsRework"),
                IsAudit = dtRow.Field<bool?>("IsAudit"),
                ZoneID = dtRow.Field<long?>("ZoneID"),
                PORIsBeingEdited = dtRow.Field<bool?>("IsBeingEdited")
            }).FirstOrDefault();
            return masterRecords;
        }
    }
}
