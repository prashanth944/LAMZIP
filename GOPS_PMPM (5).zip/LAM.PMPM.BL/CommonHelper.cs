﻿using LAM.PMPM.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LAM.PMPM.BL
{
    public static class CommonHelper
    {
        public static List<OperationDateModel> SetDatesOfOperations(List<OperationDateModel> operationDates, DateTime todaydate, List<ModuleVFDWithName> moduleVFDs, List<ModuleVFDWithName> moduleVFDAssignable)
        {
            //if you make a change in this region, make the same change in method - GetOPMGOperations in EditModule.cs and method - GetOPMGEngineerOperations in EditModule.cs
            //condition for gating date becuase if gating date is present and if its less than today then use today's date else use gating date
            //condition for actualLaunchdate because same as gating date if less than today then use today's date
            operationDates.GroupBy(x => x.ZoneID).ToList().ForEach(x =>
            {
                if (x.ToList().Count > 0)
                {
                    x.ToList().FirstOrDefault().FirstInZone = true;
                    x.ToList().LastOrDefault().DaysRemainingInZone = x.ToList().Sum(zz => (zz.StandardTimeHours - ((zz.StandardTimeHours / (zz.NumberOfSteps == 0 ? 1 : zz.NumberOfSteps)) * zz.CompletedSteps)) / zz.ModuleShiftHours);
                    x.ToList().LastOrDefault().LastInZone = true;
                }
            });

            if (operationDates.Count > 0)
            {
                if (!operationDates[0].ActualPlannedStartDate.HasValue)
                {
                    if (operationDates[0].ZoneName.ToLower() == "Chamber_SF Integration".ToLower())
                    {
                        //chamber in split because only need zone with chamber word
                        operationDates[0].ActualPlannedStartDate = (operationDates[0].GatingDate.HasValue ? (operationDates[0].GatingDate < todaydate ? todaydate : operationDates[0].GatingDate) : null) ?? (operationDates
                            .Where(x => x.ZoneName.ToLower() == "Chamber".ToLower() || x.ZoneName.ToLower() == "Sub Frame".ToLower())
                            .Count() > 0 ? operationDates
                            .Where(x => x.ZoneName.ToLower() == "Chamber".ToLower() || x.ZoneName.ToLower() == "Sub Frame".ToLower())
                            .Max(x => x.CalculatedFinish) : todaydate);
                        operationDates[0].CalculatedFinish = operationDates[0].ActualPlannedStartDate.Value.AddDays(operationDates[0].CalculatedStandardTimeDays.HasValue
                        ? Decimal.ToDouble(operationDates[0].CalculatedStandardTimeDays.Value) : 0);
                    }
                    else if (operationDates[0].ZoneName.ToLower() == "Chamber_Frame Integration".ToLower() && operationDates[0].Plant.ToLower() == "Fremont".ToLower())
                    {
                        //chamber in split because only need zone with chamber word
                        operationDates[0].ActualPlannedStartDate = (operationDates[0].GatingDate.HasValue ? (operationDates[0].GatingDate < todaydate ? todaydate : operationDates[0].GatingDate) : null) ?? (operationDates
                            .Where(x => x.ZoneName.ToLower() == "Chamber".ToLower() || x.ZoneName.ToLower() == "Frame".ToLower())
                            .Count() > 0 ? operationDates
                            .Where(x => x.ZoneName.ToLower() == "Chamber".ToLower() || x.ZoneName.ToLower() == "Frame".ToLower())
                            .Max(x => x.CalculatedFinish) : todaydate);
                        operationDates[0].CalculatedFinish = operationDates[0].ActualPlannedStartDate.Value.AddDays(operationDates[0].CalculatedStandardTimeDays.HasValue
                        ? Decimal.ToDouble(operationDates[0].CalculatedStandardTimeDays.Value) : 0);
                    }

                    else if (operationDates[0].ZoneName.ToLower() == "Enclosure_TP Integration".ToLower())
                    {
                        operationDates[0].ActualPlannedStartDate = (operationDates[0].GatingDate.HasValue ? (operationDates[0].GatingDate < todaydate ? todaydate : operationDates[0].GatingDate) : null) ?? (operationDates
                            .Where(x => x.ZoneName.ToLower() == "Enclosure".ToLower() || x.ZoneName.ToLower() == "Top Plate".ToLower())
                            .Count() > 0 ? operationDates
                            .Where(x => x.ZoneName.ToLower() == "Enclosure".ToLower() || x.ZoneName.ToLower() == "Top Plate".ToLower())
                            .Max(x => x.CalculatedFinish) : todaydate);
                        operationDates[0].CalculatedFinish = operationDates[0].ActualPlannedStartDate.Value.AddDays(operationDates[0].CalculatedStandardTimeDays.HasValue
                        ? Decimal.ToDouble(operationDates[0].CalculatedStandardTimeDays.Value) : 0);
                    }
                    else if (operationDates[0].ZoneName.ToLower() == "TP_Canopy Integration".ToLower() && operationDates[0].Plant.ToLower() == "Fremont".ToLower())
                    {
                        operationDates[0].ActualPlannedStartDate = (operationDates[0].GatingDate.HasValue ? (operationDates[0].GatingDate < todaydate ? todaydate : operationDates[0].GatingDate) : null) ?? (operationDates
                            .Where(x => x.ZoneName.ToLower() == "Canopy".ToLower() || x.ZoneName.ToLower() == "Top Plate".ToLower())
                            .Count() > 0 ? operationDates
                            .Where(x => x.ZoneName.ToLower() == "Canopy".ToLower() || x.ZoneName.ToLower() == "Top Plate".ToLower())
                            .Max(x => x.CalculatedFinish) : todaydate);
                        operationDates[0].CalculatedFinish = operationDates[0].ActualPlannedStartDate.Value.AddDays(operationDates[0].CalculatedStandardTimeDays.HasValue
                        ? Decimal.ToDouble(operationDates[0].CalculatedStandardTimeDays.Value) : 0);
                    }
                    else if (operationDates[0].ZoneName.ToLower() == "Final Integration".ToLower())
                    {
                        operationDates[0].ActualPlannedStartDate = (operationDates[0].GatingDate.HasValue ? (operationDates[0].GatingDate < todaydate ? todaydate : operationDates[0].GatingDate) : null) ?? (operationDates
                            .Where(x => x.ZoneName.ToLower() == "Chamber_SF Integration".ToLower() || x.ZoneName.ToLower() == "Enclosure_TP Integration".ToLower())
                            .Count() > 0 ? operationDates
                            .Where(x => x.ZoneName.ToLower() == "Chamber_SF Integration".ToLower() || x.ZoneName.ToLower() == "Enclosure_TP Integration".ToLower())
                            .Max(x => x.CalculatedFinish) : todaydate);
                        operationDates[0].CalculatedFinish = operationDates[0].ActualPlannedStartDate.Value.AddDays(operationDates[0].CalculatedStandardTimeDays.HasValue
                        ? Decimal.ToDouble(operationDates[0].CalculatedStandardTimeDays.Value) : 0);
                    }
                    else if (operationDates[0].ZoneName.ToLower() == "Final Integration".ToLower() && operationDates[0].Plant.ToLower() == "Fremont".ToLower())
                    {
                        operationDates[0].ActualPlannedStartDate = (operationDates[0].GatingDate.HasValue ? (operationDates[0].GatingDate < todaydate ? todaydate : operationDates[0].GatingDate) : null) ?? (operationDates
                            .Where(x => x.ZoneName.ToLower() == "Chamber_Frame Integration".ToLower() || x.ZoneName.ToLower() == "TP_Canopy Integration".ToLower())
                            .Count() > 0 ? operationDates
                            .Where(x => x.ZoneName.ToLower() == "Chamber_Frame Integration".ToLower() || x.ZoneName.ToLower() == "TP_Canopy Integration".ToLower())
                            .Max(x => x.CalculatedFinish) : todaydate);
                        operationDates[0].CalculatedFinish = operationDates[0].ActualPlannedStartDate.Value.AddDays(operationDates[0].CalculatedStandardTimeDays.HasValue
                        ? Decimal.ToDouble(operationDates[0].CalculatedStandardTimeDays.Value) : 0);
                    }
                    else if (operationDates[0].ZoneName.ToLower() == "Final Test".ToLower())
                    {
                        operationDates[0].ActualPlannedStartDate = (operationDates[0].GatingDate.HasValue ? (operationDates[0].GatingDate < todaydate ? todaydate : operationDates[0].GatingDate) : null) ?? (operationDates
                            .Where(x => x.ZoneName.ToLower() == "Final Integration".ToLower())
                            .Count() > 0 ? operationDates
                            .Where(x => x.ZoneName.ToLower() == "Final Integration".ToLower())
                            .Max(x => x.CalculatedFinish) : todaydate);

                        operationDates[0].CalculatedFinish = operationDates[0].ActualPlannedStartDate.Value.AddDays(operationDates[0].CalculatedStandardTimeDays.HasValue
                        ? Decimal.ToDouble(operationDates[0].CalculatedStandardTimeDays.Value) : 0);
                    }
                    else if (operationDates[0].ZoneName.ToLower() == "Preship".ToLower() || operationDates[0].ZoneName.ToLower() == "Pre-Ship".ToLower())
                    {
                        operationDates[0].ActualPlannedStartDate = (operationDates[0].GatingDate.HasValue ? (operationDates[0].GatingDate < todaydate ? todaydate : operationDates[0].GatingDate) : null) ?? (operationDates
                            .Where(x => x.ZoneName.ToLower() == "Final Test".ToLower())
                            .Count() > 0 ? operationDates
                            .Where(x => x.ZoneName.ToLower() == "Final Test".ToLower())
                            .Max(x => x.CalculatedFinish) : operationDates[0].LastInZone ? operationDates[0].CalculatedFinish.Value.AddDays(operationDates[0].DaysRemainingInZone ?? 0) : operationDates[0].CalculatedFinish.Value);

                        operationDates[0].CalculatedFinish = operationDates[0].ActualPlannedStartDate.Value.AddDays(operationDates[0].CalculatedStandardTimeDays.HasValue
                        ? Decimal.ToDouble(operationDates[0].CalculatedStandardTimeDays.Value) : 0);
                    }
                    else if (operationDates[0].ZoneName.ToLower() == "Feeder Line".ToLower())
                    {
                        operationDates[0].ActualPlannedStartDate = (operationDates[0].GatingDate.HasValue ? (operationDates[0].GatingDate < todaydate ? todaydate : operationDates[0].GatingDate) : null) ??
                      (operationDates[0].ActualPlannedLaunch.HasValue ?
                          (operationDates[0].ActualPlannedLaunch
                              < todaydate ?
                          todaydate : operationDates[0].ActualPlannedLaunch)
                              : todaydate);
                        operationDates[0].CalculatedFinish = operationDates[0].ActualPlannedStartDate.Value.AddDays(operationDates[0].CalculatedStandardTimeDays.HasValue
                        ? Decimal.ToDouble(operationDates[0].CalculatedStandardTimeDays.Value) : 0);

                    }
                    else if (moduleVFDAssignable.Where(x => x.VFDZoneName.ToLower() == operationDates[0].ZoneName.ToLower() && x.Assignable == true).Count() > 0)
                    {

                        operationDates[0].ActualPlannedStartDate = (operationDates[0].GatingDate.HasValue ? (operationDates[0].GatingDate < todaydate ? todaydate : operationDates[0].GatingDate) : null) ??
                           (operationDates[0].ActualPlannedLaunch.HasValue ?
                               (operationDates[0].ActualPlannedLaunch
                                   < todaydate ?
                               todaydate : operationDates[0].ActualPlannedLaunch)
                                   : todaydate);
                        operationDates[0].CalculatedFinish = operationDates[0].ActualPlannedStartDate.Value.AddDays(operationDates[0].CalculatedStandardTimeDays.HasValue
                        ? Decimal.ToDouble(operationDates[0].CalculatedStandardTimeDays.Value) : 0);
                    }
                    else if (moduleVFDAssignable.Where(x => x.VFDZoneName.ToLower().Contains("Frame".ToLower()) && operationDates[0].ZoneName.ToLower().Contains("Frame".ToLower()) && x.Assignable == true && operationDates[0].Plant.ToLower() == "Fremont".ToLower()).Count() > 0)
                    {

                        operationDates[0].ActualPlannedStartDate = (operationDates[0].GatingDate.HasValue ? (operationDates[0].GatingDate < todaydate ? todaydate : operationDates[0].GatingDate) : null) ??
                           (operationDates[0].ActualPlannedLaunch.HasValue ?
                               (operationDates[0].ActualPlannedLaunch
                                   < todaydate ?
                               todaydate : operationDates[0].ActualPlannedLaunch)
                                   : todaydate);
                        operationDates[0].CalculatedFinish = operationDates[0].ActualPlannedStartDate.Value.AddDays(operationDates[0].CalculatedStandardTimeDays.HasValue
                        ? Decimal.ToDouble(operationDates[0].CalculatedStandardTimeDays.Value) : 0);
                    }

                    else if (moduleVFDs.Where(x => x.VFDZoneName.ToLower() == operationDates[0].ZoneName.ToLower()).Count() > 0)
                    {
                        operationDates[0].ActualPlannedStartDate = (operationDates[0].GatingDate.HasValue ? (operationDates[0].GatingDate < todaydate ? todaydate : operationDates[0].GatingDate) : null) ??
                            (operationDates[0].ActualPlannedLaunch.HasValue ?
                                (operationDates[0].ActualPlannedLaunch.Value.AddDays(moduleVFDs.Where(x => x.VFDZoneName.ToLower() == operationDates[0].ZoneName.ToLower()).FirstOrDefault().NumberOfDays ?? 0)
                                    < todaydate ?
                                todaydate : operationDates[0].ActualPlannedLaunch.Value.AddDays(moduleVFDs.Where(x => x.VFDZoneName.ToLower() == operationDates[0].ZoneName.ToLower()).FirstOrDefault().NumberOfDays ?? 0))
                                    : todaydate);
                        operationDates[0].CalculatedFinish = operationDates[0].ActualPlannedStartDate.Value.AddDays(operationDates[0].CalculatedStandardTimeDays.HasValue
                        ? Decimal.ToDouble(operationDates[0].CalculatedStandardTimeDays.Value) : 0);
                    }
                    else if (moduleVFDs.Where(x => x.VFDZoneName.ToLower().Contains("Frame".ToLower()) && operationDates[0].ZoneName.ToLower().Contains("Frame".ToLower()) && operationDates[0].Plant.ToLower() == "Fremont".ToLower()).Count() > 0)
                    {
                        operationDates[0].ActualPlannedStartDate = (operationDates[0].GatingDate.HasValue ? (operationDates[0].GatingDate < todaydate ? todaydate : operationDates[0].GatingDate) : null) ??
                            (operationDates[0].ActualPlannedLaunch.HasValue ?
                                (operationDates[0].ActualPlannedLaunch.Value.AddDays(moduleVFDs.Where(x => x.VFDZoneName.ToLower().Contains("Frame".ToLower()) && operationDates[0].ZoneName.ToLower().Contains("Frame".ToLower())).FirstOrDefault().NumberOfDays ?? 0)
                                    < todaydate ?
                                todaydate : operationDates[0].ActualPlannedLaunch.Value.AddDays(moduleVFDs.Where(x => x.VFDZoneName.ToLower().Contains("Frame".ToLower()) && operationDates[0].ZoneName.ToLower().Contains("Frame".ToLower())).FirstOrDefault().NumberOfDays ?? 0))
                                    : todaydate);
                        operationDates[0].CalculatedFinish = operationDates[0].ActualPlannedStartDate.Value.AddDays(operationDates[0].CalculatedStandardTimeDays.HasValue
                        ? Decimal.ToDouble(operationDates[0].CalculatedStandardTimeDays.Value) : 0);
                    }

                    else
                    {
                        operationDates[0].ActualPlannedStartDate = (operationDates[0].GatingDate.HasValue ? (operationDates[0].GatingDate < todaydate ? todaydate : operationDates[0].GatingDate) : null) ?? todaydate;
                        operationDates[0].CalculatedFinish = operationDates[0].ActualPlannedStartDate.Value.AddDays(operationDates[0].CalculatedStandardTimeDays.HasValue
                            ? Decimal.ToDouble(operationDates[0].CalculatedStandardTimeDays.Value) : 0);
                    }
                }
                else
                {
                    operationDates[0].CalculatedFinish = operationDates[0].ActualPlannedStartDate.Value.AddDays(operationDates[0].CalculatedStandardTimeDays.HasValue
                       ? Decimal.ToDouble(operationDates[0].CalculatedStandardTimeDays.Value) : 0);
                }


                for (int i = 0; i < operationDates.Count - 1; i++)
                {

                    if (operationDates[i + 1].FirstInZone)
                    {
                        if (!operationDates[i + 1].ActualPlannedStartDate.HasValue)
                        {
                            if (operationDates[i + 1].ZoneName.ToLower() == "Chamber_SF Integration".ToLower())
                            {
                                operationDates[i + 1].ActualPlannedStartDate = (operationDates[i + 1].GatingDate.HasValue ? (operationDates[i + 1].GatingDate < todaydate ? todaydate : operationDates[i + 1].GatingDate) : null) ?? (operationDates
                                    .Where(x => x.ZoneName.ToLower() == "Chamber".ToLower() || x.ZoneName.ToLower() == "Sub Frame".ToLower())
                                    .Count() > 0 ? operationDates
                                    .Where(x => x.ZoneName.ToLower() == "Chamber".ToLower() || x.ZoneName.ToLower() == "Sub Frame".ToLower()) //chamber in split because only need zone with chamber word
                                    .Max(x => x.CalculatedFinish) : operationDates[i].LastInZone ? operationDates[i].CalculatedFinish.Value.AddDays(operationDates[i].DaysRemainingInZone ?? 0) : operationDates[i].CalculatedFinish.Value);

                                operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.HasValue ?
                                   (operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(
                                       operationDates[i + 1].CalculatedStandardTimeDays.HasValue ? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0)
                                   ) : operationDates[i + 1].ActualPlannedStartDate;
                            }
                            else if (operationDates[i + 1].ZoneName.ToLower() == "Chamber_Frame Integration".ToLower() && operationDates[i + 1].Plant.ToLower() == "Fremont".ToLower())
                            {
                                operationDates[i + 1].ActualPlannedStartDate = (operationDates[i + 1].GatingDate.HasValue ? (operationDates[i + 1].GatingDate < todaydate ? todaydate : operationDates[i + 1].GatingDate) : null) ?? (operationDates
                                    .Where(x => x.ZoneName.ToLower() == "Chamber".ToLower() || x.ZoneName.ToLower() == "Frame".ToLower())
                                    .Count() > 0 ? operationDates
                                    .Where(x => x.ZoneName.ToLower() == "Chamber".ToLower() || x.ZoneName.ToLower() == "Frame".ToLower()) //chamber in split because only need zone with chamber word
                                    .Max(x => x.CalculatedFinish) : operationDates[i].LastInZone ? operationDates[i].CalculatedFinish.Value.AddDays(operationDates[i].DaysRemainingInZone ?? 0) : operationDates[i].CalculatedFinish.Value);

                                operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.HasValue ?
                                   (operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(
                                       operationDates[i + 1].CalculatedStandardTimeDays.HasValue ? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0)
                                   ) : operationDates[i + 1].ActualPlannedStartDate;
                            }


                            else if (operationDates[i + 1].ZoneName.ToLower() == "Enclosure_TP Integration".ToLower())
                            {
                                operationDates[i + 1].ActualPlannedStartDate = (operationDates[i + 1].GatingDate.HasValue ? (operationDates[i + 1].GatingDate < todaydate ? todaydate : operationDates[i + 1].GatingDate) : null) ?? (operationDates
                                    .Where(x => x.ZoneName.ToLower() == "Enclosure".ToLower() || x.ZoneName.ToLower() == "Top Plate".ToLower())
                                    .Count() > 0 ? operationDates
                                    .Where(x => x.ZoneName.ToLower() == "Enclosure".ToLower() || x.ZoneName.ToLower() == "Top Plate".ToLower())
                                    .Max(x => x.CalculatedFinish) : operationDates[i].LastInZone ? operationDates[i].CalculatedFinish.Value.AddDays(operationDates[i].DaysRemainingInZone ?? 0) : operationDates[i].CalculatedFinish.Value);

                                operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.HasValue ?
                                   (operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(
                                       operationDates[i + 1].CalculatedStandardTimeDays.HasValue ? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0)
                                   ) : operationDates[i + 1].ActualPlannedStartDate;
                            }
                            else if (operationDates[i + 1].ZoneName.ToLower() == "TP_Canopy Integration".ToLower() && operationDates[i + 1].Plant.ToLower() == "Fremont".ToLower())
                            {
                                operationDates[i + 1].ActualPlannedStartDate = (operationDates[i + 1].GatingDate.HasValue ? (operationDates[i + 1].GatingDate < todaydate ? todaydate : operationDates[i + 1].GatingDate) : null) ?? (operationDates
                                    .Where(x => x.ZoneName.ToLower() == "Canopy".ToLower() || x.ZoneName.ToLower() == "Top Plate".ToLower())
                                    .Count() > 0 ? operationDates
                                    .Where(x => x.ZoneName.ToLower() == "Canopy".ToLower() || x.ZoneName.ToLower() == "Top Plate".ToLower())
                                    .Max(x => x.CalculatedFinish) : operationDates[i].LastInZone ? operationDates[i].CalculatedFinish.Value.AddDays(operationDates[i].DaysRemainingInZone ?? 0) : operationDates[i].CalculatedFinish.Value);

                                operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.HasValue ?
                                   (operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(
                                       operationDates[i + 1].CalculatedStandardTimeDays.HasValue ? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0)
                                   ) : operationDates[i + 1].ActualPlannedStartDate;
                            }

                            else if (operationDates[i + 1].ZoneName.ToLower() == "Final Integration".ToLower())
                            {
                                operationDates[i + 1].ActualPlannedStartDate = (operationDates[i + 1].GatingDate.HasValue ? (operationDates[i + 1].GatingDate < todaydate ? todaydate : operationDates[i + 1].GatingDate) : null) ?? (operationDates
                                    .Where(x => x.ZoneName.ToLower() == "Chamber_SF Integration".ToLower() || x.ZoneName.ToLower() == "Enclosure_TP Integration".ToLower())
                                    .Count() > 0 ? operationDates
                                    .Where(x => x.ZoneName.ToLower() == "Chamber_SF Integration".ToLower() || x.ZoneName.ToLower() == "Enclosure_TP Integration".ToLower())
                                    .Max(x => x.CalculatedFinish) : operationDates[i].LastInZone ? operationDates[i].CalculatedFinish.Value.AddDays(operationDates[i].DaysRemainingInZone ?? 0) : operationDates[i].CalculatedFinish.Value);

                                operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.HasValue ?
                                   (operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(
                                       operationDates[i + 1].CalculatedStandardTimeDays.HasValue ? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0)
                                   ) : operationDates[i + 1].ActualPlannedStartDate;
                            }
                            else if (operationDates[i + 1].ZoneName.ToLower() == "Final Integration".ToLower() && operationDates[0].Plant.ToLower() == "Fremont".ToLower())
                            {
                                operationDates[i + 1].ActualPlannedStartDate = (operationDates[i + 1].GatingDate.HasValue ? (operationDates[i + 1].GatingDate < todaydate ? todaydate : operationDates[i + 1].GatingDate) : null) ?? (operationDates
                                    .Where(x => x.ZoneName.ToLower() == "Chamber_Frame Integration".ToLower() || x.ZoneName.ToLower() == "TP_Canopy Integration".ToLower())
                                    .Count() > 0 ? operationDates
                                    .Where(x => x.ZoneName.ToLower() == "Chamber_Frame Integration".ToLower() || x.ZoneName.ToLower() == "TP_Canopy Integration".ToLower())
                                    .Max(x => x.CalculatedFinish) : operationDates[i].LastInZone ? operationDates[i].CalculatedFinish.Value.AddDays(operationDates[i].DaysRemainingInZone ?? 0) : operationDates[i].CalculatedFinish.Value);

                                operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.HasValue ?
                                   (operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(
                                       operationDates[i + 1].CalculatedStandardTimeDays.HasValue ? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0)
                                   ) : operationDates[i + 1].ActualPlannedStartDate;
                            }
                            #region Newly Added
                            /*Based on Final integration take latest finish date into Final test*/
                            else if (operationDates[i + 1].ZoneName.ToLower() == "Final Test".ToLower())
                            {
                                operationDates[i + 1].ActualPlannedStartDate = (operationDates[i + 1].GatingDate.HasValue ? (operationDates[i + 1].GatingDate < todaydate ? todaydate : operationDates[i + 1].GatingDate) : null) ?? (operationDates
                                    .Where(x => x.ZoneName.ToLower() == "Final Integration".ToLower())
                                    .Count() > 0 ? operationDates
                                    .Where(x => x.ZoneName.ToLower() == "Final Integration".ToLower())
                                    .Max(x => x.CalculatedFinish) : operationDates[i].LastInZone ? operationDates[i].CalculatedFinish.Value.AddDays(operationDates[i].DaysRemainingInZone ?? 0) : operationDates[i].CalculatedFinish.Value);

                                operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.HasValue ?
                                   (operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(
                                       operationDates[i + 1].CalculatedStandardTimeDays.HasValue ? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0)
                                   ) : operationDates[i + 1].ActualPlannedStartDate;
                            }

                            /*Based on Final test take latest finish date into Post- test*/
                            else if (operationDates[i + 1].ZoneName.ToLower() == "Preship".ToLower() || operationDates[i + 1].ZoneName.ToLower() == "Pre-Ship".ToLower())
                            {
                                operationDates[i + 1].ActualPlannedStartDate = (operationDates[i + 1].GatingDate.HasValue ? (operationDates[i + 1].GatingDate < todaydate ? todaydate : operationDates[i + 1].GatingDate) : null) ?? (operationDates
                                    .Where(x => x.ZoneName.ToLower() == "Final Test".ToLower())
                                    .Count() > 0 ? operationDates
                                    .Where(x => x.ZoneName.ToLower() == "Final Test".ToLower())
                                    .Max(x => x.CalculatedFinish) : operationDates[i].LastInZone ? operationDates[i].CalculatedFinish.Value.AddDays(operationDates[i].DaysRemainingInZone ?? 0) : operationDates[i].CalculatedFinish.Value);

                                operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.HasValue ?
                                    (operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(
                                        operationDates[i + 1].CalculatedStandardTimeDays.HasValue ? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0)
                                    ) : operationDates[i + 1].ActualPlannedStartDate;
                            }
                            /* WIP Release Actual launch date display in feeder line*/
                            else if (operationDates[i + 1].ZoneName.ToLower() == "Feeder Line".ToLower())
                            {
                                if (!operationDates[i + 1].ActualPlannedStartDate.HasValue)
                                {
                                    operationDates[i + 1].ActualPlannedStartDate = (operationDates[i + 1].GatingDate.HasValue ? (operationDates[i + 1].GatingDate < todaydate ? todaydate : operationDates[i + 1].GatingDate) : null) ??
                                                                           (operationDates[i + 1].ActualPlannedLaunch.HasValue ?
                                                                               (operationDates[i + 1].ActualPlannedLaunch
                                                                                   < todaydate ?
                                                                               todaydate : operationDates[i + 1].ActualPlannedLaunch)
                                                                                   : todaydate);
                                    operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.HasValue ?
                                   (operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(
                                       operationDates[i + 1].CalculatedStandardTimeDays.HasValue ? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0)
                                   ) : operationDates[i + 1].ActualPlannedStartDate;
                                }
                                else
                                {
                                    //operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(operationDates[i + 1].CalculatedStandardTimeDays.HasValue
                                    //                              ? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0);
                                    operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.HasValue ?
                                   (operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(
                                       operationDates[i + 1].CalculatedStandardTimeDays.HasValue ? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0)
                                   ) : operationDates[i + 1].ActualPlannedStartDate;
                                }
                            }

                            /* WIP Release Zone checked basis to display the Actual planned Lauch date*/
                            else if (moduleVFDAssignable.Where(x => x.VFDZoneName.ToLower() == operationDates[i + 1].ZoneName.ToLower() && x.Assignable == true).Count() > 0)
                            {
                                operationDates[i + 1].ActualPlannedStartDate = (operationDates[i + 1].GatingDate.HasValue ? (operationDates[i + 1].GatingDate < todaydate ? todaydate : operationDates[i + 1].GatingDate) : null) ??
                                   (operationDates[i + 1].ActualPlannedLaunch.HasValue ?
                                       (operationDates[i + 1].ActualPlannedLaunch
                                           < todaydate ?
                                       todaydate : operationDates[i + 1].ActualPlannedLaunch)
                                           : todaydate);
                                operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.HasValue ?
                                   (operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(
                                       operationDates[i + 1].CalculatedStandardTimeDays.HasValue ? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0)
                                   ) : operationDates[i + 1].ActualPlannedStartDate;
                            }
                            else if (moduleVFDAssignable.Where(x => x.VFDZoneName.ToLower().Contains("Frame".ToLower()) && operationDates[i + 1].ZoneName.ToLower().Contains("Frame".ToLower()) && x.Assignable == true && operationDates[i + 1].Plant.ToLower() == "Fremont".ToLower()).Count() > 0)
                            {
                                operationDates[i + 1].ActualPlannedStartDate = (operationDates[i + 1].GatingDate.HasValue ? (operationDates[i + 1].GatingDate < todaydate ? todaydate : operationDates[i + 1].GatingDate) : null) ??
                                   (operationDates[i + 1].ActualPlannedLaunch.HasValue ?
                                       (operationDates[i + 1].ActualPlannedLaunch
                                           < todaydate ?
                                       todaydate : operationDates[i + 1].ActualPlannedLaunch)
                                           : todaydate);
                                operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.HasValue ?
                                   (operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(
                                       operationDates[i + 1].CalculatedStandardTimeDays.HasValue ? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0)
                                   ) : operationDates[i + 1].ActualPlannedStartDate;
                            }
                            else if (moduleVFDAssignable.Where(x => x.VFDZoneName.ToLower().Contains("top plate") && operationDates[i + 1].ZoneName.ToLower().Contains("top plate") && x.Assignable == true && operationDates[i + 1].Plant.ToLower() == "Fremont".ToLower()).Count() > 0)
                            {
                                operationDates[i + 1].ActualPlannedStartDate = (operationDates[i + 1].GatingDate.HasValue ? (operationDates[i + 1].GatingDate < todaydate ? todaydate : operationDates[i + 1].GatingDate) : null) ??
                                   (operationDates[i + 1].ActualPlannedLaunch.HasValue ?
                                       (operationDates[i + 1].ActualPlannedLaunch
                                           < todaydate ?
                                       todaydate : operationDates[i + 1].ActualPlannedLaunch)
                                           : todaydate);
                                operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.HasValue ?
                                   (operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(
                                       operationDates[i + 1].CalculatedStandardTimeDays.HasValue ? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0)
                                   ) : operationDates[i + 1].ActualPlannedStartDate;
                            }
                            #endregion

                            else if (moduleVFDs.Where(x => x.VFDZoneName.ToLower() == operationDates[i + 1].ZoneName.ToLower()).Count() > 0)
                            {
                                operationDates[i + 1].ActualPlannedStartDate = (operationDates[i + 1].GatingDate.HasValue ? (operationDates[i + 1].GatingDate < todaydate ? todaydate : operationDates[i + 1].GatingDate) : null) ??
                                    (operationDates[i + 1].ActualPlannedLaunch.HasValue ?
                                        (operationDates[i + 1].ActualPlannedLaunch.Value.AddDays(moduleVFDs.Where(x => x.VFDZoneName.ToLower() == operationDates[i + 1].ZoneName.ToLower()).FirstOrDefault().NumberOfDays ?? 0)
                                            < todaydate ?
                                        todaydate : operationDates[i + 1].ActualPlannedLaunch.Value.AddDays(moduleVFDs.Where(x => x.VFDZoneName.ToLower() == operationDates[i + 1].ZoneName.ToLower()).FirstOrDefault().NumberOfDays ?? 0))
                                            : todaydate);
                                operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.HasValue ?
                                   (operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(
                                       operationDates[i + 1].CalculatedStandardTimeDays.HasValue ? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0)
                                   ) : operationDates[i + 1].ActualPlannedStartDate;
                            }
                            else if (moduleVFDs.Where(x => x.VFDZoneName.ToLower().Contains("top plate") && operationDates[i + 1].ZoneName.ToLower().Contains("top plate") && operationDates[i + 1].Plant.ToLower() == "fremont").Count() > 0)
                            {
                                operationDates[i + 1].ActualPlannedStartDate = (operationDates[i + 1].GatingDate.HasValue ? (operationDates[i + 1].GatingDate < todaydate ? todaydate : operationDates[i + 1].GatingDate) : null) ??
                                    (operationDates[i + 1].ActualPlannedLaunch.HasValue ?
                                        (operationDates[i + 1].ActualPlannedLaunch.Value.AddDays(moduleVFDs.Where(x => x.VFDZoneName.ToLower().Contains("top plate") && operationDates[i + 1].ZoneName.ToLower().Contains("top plate")).FirstOrDefault().NumberOfDays ?? 0)
                                            < todaydate ?
                                        todaydate : operationDates[i + 1].ActualPlannedLaunch.Value.AddDays(moduleVFDs.Where(x => x.VFDZoneName.ToLower().Contains("top plate") && operationDates[i + 1].ZoneName.ToLower().Contains("top plate")).FirstOrDefault().NumberOfDays ?? 0))
                                            : todaydate);
                                operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.HasValue ?
                                   (operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(
                                       operationDates[i + 1].CalculatedStandardTimeDays.HasValue ? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0)
                                   ) : operationDates[i + 1].ActualPlannedStartDate;
                            }
                            else if (moduleVFDs.Where(x => x.VFDZoneName.ToLower().Contains("Frame".ToLower()) && operationDates[i + 1].ZoneName.ToLower().Contains("Frame".ToLower()) && operationDates[i + 1].Plant.ToLower() == "Fremont".ToLower()).Count() > 0)
                            {
                                operationDates[i + 1].ActualPlannedStartDate = (operationDates[i + 1].GatingDate.HasValue ? (operationDates[i + 1].GatingDate < todaydate ? todaydate : operationDates[i + 1].GatingDate) : null) ??
                                    (operationDates[i + 1].ActualPlannedLaunch.HasValue ?
                                        (operationDates[i + 1].ActualPlannedLaunch.Value.AddDays(moduleVFDs.Where(x => x.VFDZoneName.ToLower().Contains("Frame".ToLower()) && operationDates[i + 1].ZoneName.ToLower().Contains("Frame".ToLower())).FirstOrDefault().NumberOfDays ?? 0)
                                            < todaydate ?
                                        todaydate : operationDates[i + 1].ActualPlannedLaunch.Value.AddDays(moduleVFDs.Where(x => x.VFDZoneName.ToLower().Contains("Frame".ToLower()) && operationDates[i + 1].ZoneName.ToLower().Contains("Frame".ToLower())).FirstOrDefault().NumberOfDays ?? 0))
                                            : todaydate);
                                operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.HasValue ?
                                   (operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(
                                       operationDates[i + 1].CalculatedStandardTimeDays.HasValue ? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0)
                                   ) : operationDates[i + 1].ActualPlannedStartDate;
                            }

                            else
                            {
                                operationDates[i + 1].ActualPlannedStartDate = (operationDates[i + 1].GatingDate.HasValue ? (operationDates[i + 1].GatingDate < todaydate ? todaydate : operationDates[i + 1].GatingDate) : null) ??
                                    (operationDates[i].LastInZone ?
                                    operationDates[i].CalculatedFinish.HasValue ?
                                    (operationDates[i].CalculatedFinish.Value.AddDays(operationDates[i].DaysRemainingInZone ?? 0)) : operationDates[i].CalculatedFinish.Value
                                    : operationDates[i].CalculatedFinish);
                                operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.HasValue ?
                                   (operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(
                                       operationDates[i + 1].CalculatedStandardTimeDays.HasValue ? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0)
                                   ) : operationDates[i + 1].ActualPlannedStartDate;
                            }


                        }
                        else if (moduleVFDAssignable.Where(x => x.VFDZoneName.ToLower() == operationDates[i + 1].ZoneName.ToLower() && x.Assignable == true && !operationDates[i + 1].ActualPlannedStartDate.HasValue && operationDates[i + 1].FirstInZone).Count() > 0)
                        {
                            operationDates[i + 1].ActualPlannedStartDate = (operationDates[i + 1].GatingDate.HasValue ? (operationDates[i + 1].GatingDate < todaydate ? todaydate : operationDates[i + 1].GatingDate) : null) ??
                                      (operationDates[i + 1].ActualPlannedLaunch.HasValue ?
                                          (operationDates[i + 1].ActualPlannedLaunch
                                              < todaydate ?
                                          todaydate : operationDates[i + 1].ActualPlannedLaunch)
                                              : todaydate);
                            //operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(operationDates[i + 1].CalculatedStandardTimeDays.HasValue
                            //? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0);
                            operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.HasValue ?
                                   (operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(
                                       operationDates[i + 1].CalculatedStandardTimeDays.HasValue ? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0)
                                   ) : operationDates[i + 1].ActualPlannedStartDate;
                        }
                        else if (operationDates[i + 1].ActualPlannedStartDate.HasValue)
                        {
                            //operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(operationDates[i + 1].CalculatedStandardTimeDays.HasValue
                            //? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0);
                            operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.HasValue ?
                                   (operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(
                                       operationDates[i + 1].CalculatedStandardTimeDays.HasValue ? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0)
                                   ) : operationDates[i + 1].ActualPlannedStartDate;
                        }
                    }
                    else
                    {
                        if (!operationDates[i + 1].ActualPlannedStartDate.HasValue && operationDates[i].CalculatedFinish.HasValue)
                        {
                            operationDates[i + 1].ActualPlannedStartDate = (operationDates[i].CalculatedFinish.Value < todaydate ? todaydate : operationDates[i].CalculatedFinish.Value);
                            //operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(operationDates[i + 1].CalculatedStandardTimeDays.HasValue
                            //    ? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0);
                            operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.HasValue ?
                                   (operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(
                                       operationDates[i + 1].CalculatedStandardTimeDays.HasValue ? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0)
                                   ) : operationDates[i + 1].ActualPlannedStartDate;
                        }
                        else if (operationDates[i + 1].ActualPlannedStartDate.HasValue)
                        {
                            //operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(operationDates[i + 1].CalculatedStandardTimeDays.HasValue
                            //? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0);
                            operationDates[i + 1].CalculatedFinish = operationDates[i + 1].ActualPlannedStartDate.HasValue ?
                                   (operationDates[i + 1].ActualPlannedStartDate.Value.AddDays(
                                       operationDates[i + 1].CalculatedStandardTimeDays.HasValue ? Decimal.ToDouble(operationDates[i + 1].CalculatedStandardTimeDays.Value) : 0)
                                   ) : operationDates[i + 1].ActualPlannedStartDate;
                        }
                    }

                }
            }

            return operationDates;
        }
    }
}
