﻿using LAM.PMPM.DAL;
using LAM.PMPM.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace LAM.PMPM.BL
{
    public class UserAccessRequestBL
    {
        public string CreateRequest(string connString, UserAccessRequestModel userAccessRequestModel)
        {
            try
            {
                var resultCount = "";

                SqlParameter[] param = {
                    new SqlParameter("@PlantId", userAccessRequestModel.PlantID),
                    new SqlParameter("@UserId", userAccessRequestModel.UserId),
                    new SqlParameter("@RoleId ", userAccessRequestModel.RoleId),
                    new SqlParameter("@UserMessage", userAccessRequestModel.UserMessage)
                };
                resultCount = SqlHelper.ExecuteScalar(connString, "uspInsertUserAccessRequest", param).ToString();

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public UserAccessRequestModel GetRequest(string connString, int userId)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
               new SqlParameter("@UserId", userId)
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetAccessRequestUser", param);

            UserAccessRequestModel masterRecords = dataTable.AsEnumerable().Select(dtRow => new UserAccessRequestModel
            {
                UserEmail = dtRow.Field<string>("Email"),
                PlantID = dtRow.Field<long?>("PlantID"),
                PlantName = dtRow.Field<string>("PlantName"),
                RoleId = dtRow.Field<long?>("RoleID"),
                RoleName = dtRow.Field<string>("RoleName"),
                UserMessage = dtRow.Field<string>("UserMessage"),
                UserAccessRequestStatusID = dtRow.Field<long?>("UserAccessRequestStatusID"),
                Status = dtRow.Field<string>("Status"),
                UserFullName = dtRow.Field<string>("FullName"),
                StatusMessage = dtRow.Field<string>("StatusMessage")
            }).FirstOrDefault();

            return masterRecords;
        }

        public object GetRequestByGUID(string connString, string guid)
        {
            DataTable dataTable;
            SqlParameter[] param =
            {
               new SqlParameter("@guid", guid)
            };
            dataTable = SqlHelper.GetDataTable(connString, "uspGetAccessRequestUserByGUID", param);

            UserAccessRequestModel masterRecords = dataTable.AsEnumerable().Select(dtRow => new UserAccessRequestModel
            {
                UserEmail = dtRow.Field<string>("Email"),
                PlantID = dtRow.Field<long?>("PlantID"),
                PlantName = dtRow.Field<string>("PlantName"),
                RoleId = dtRow.Field<long?>("RoleID"),
                RoleName = dtRow.Field<string>("RoleName"),
                UserMessage = dtRow.Field<string>("UserMessage"),
                UserAccessRequestStatusID = dtRow.Field<long?>("UserAccessRequestStatusID"),
                Status = dtRow.Field<string>("Status"),
                UserFullName = dtRow.Field<string>("FullName"),
                StatusMessage = dtRow.Field<string>("StatusMessage")
            }).FirstOrDefault();

            return masterRecords;
        }

        public object GetStatus(string connString)
        {
            DataTable dataTable;

            dataTable = SqlHelper.GetDataTable(connString, "uspGetAccessRequestStatus");

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new
            {
                Status = dtRow.Field<string>("Status"),
                StatusMessage = dtRow.Field<string>("StatusMessage"),
                UserAccessRequestStatusID = dtRow.Field<long?>("UserAccessRequestStatusID")
            }).ToList();

            return masterRecords;
        }

        public int UpdateRequest(string connString, UserAccessRequestModel userAccessRequestModel, string guid)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@guid", guid),
                    new SqlParameter("@UserAccessRequestStatusID", userAccessRequestModel.UserAccessRequestStatusID),
                    new SqlParameter("@StatusMessage ", userAccessRequestModel.StatusMessage),
                    new SqlParameter("@ModifiedBy ", userAccessRequestModel.ModifiedBy)
                    ,outParam
                };
                resultCount = SqlHelper.ExecuteNonQuery(connString, "uspUpdateUserAccessRequest", param);

                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public void SendUpdateEmail(string connString, UserAccessRequestModel userAccessRequestModel, SmtpMailHelper smtpMailHelper)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param =
                {
                    new SqlParameter("@guid", userAccessRequestModel.GUID),
                    new SqlParameter("@ModifiedBy", userAccessRequestModel.ModifiedBy)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetFromAndToUserAccessRequest", param);

                var objectStatus = dataTable.AsEnumerable().Select(dtRow => new
                {
                    FromEmail = dtRow.Field<string>("FromEmail"),
                    ToEmail = dtRow.Field<string>("ToEmail"),
                    Status = dtRow.Field<string>("Status"),
                    PlantName = dtRow.Field<string>("PlantName"),
                    RoleName = dtRow.Field<string>("RoleName"),
                    StatusMessage = dtRow.Field<string>("StatusMessage"),
                    FullName = dtRow.Field<string>("FullName"),
                    CCEmail = dtRow.Field<string>("CCEmail")
                }).FirstOrDefault();

                string url = objectStatus.Status == "Approved" ? $"Click <a href=\"https://{userAccessRequestModel.Host}\">here</a> to go to the application." : $"Click <a href=\"https://{userAccessRequestModel.Host}/home/access-request\">here</a> to see the request.";

                string body = "<!DOCTYPE html>" +
                        "<html>" +
                        "<body>" +
                        $"<h1>Your request got {objectStatus.Status}</h1>" +
                        $"<table style = \"width:100%\">" +
                        $"  <colgroup>" +
                        $"    <col style=\"width:20%\">" +
                        $"    <col span=\"2\" style=\"background-color:lightgray\" >" +
                        $"  </colgroup>" +
                        $"  <tr>" +
                        $"    <td>Site Name</td>" +
                        $"    <td style=\"border:1px solid;padding: 15px;\">{objectStatus.PlantName}</td>" +
                        $"    " +
                        $"  </tr>" +
                        $"  <tr>" +
                        $"    <td>Role Name</td>" +
                        $"    <td style=\"border:1px solid;padding: 15px;\">{objectStatus.RoleName}</td>" +
                        $"    " +
                        $"  </tr>" +
                        $"  <tr>" +
                        $"    <td>Message</td>" +
                        $"    <td style=\"border:1px solid;padding: 15px;\">{objectStatus.StatusMessage}</td>" +
                        $"    " +
                        $"  </tr>" +
                        $"</table>" +
                        $"<br />" +
                        url +
                        $"<div>" +
                        $"	<p style=\"font-size: 8px;\">LAM RESEARCH CONFIDENTIALITY NOTICE: This e-mail transmission, and any documents, files, or previous e-mail messages attached" +
                        $" to it, (collectively, \"E-mail Transmission\") may be subject to one or more of the following based on the associated sensitivity level: E-mail Transmission" +
                        $" (i) contains confidential information, (ii) is prohibited from distribution outside of Lam, and/or (iii) is intended solely for and restricted to the specified" +
                        $" recipient(s). If you are not the intended recipient, or a person responsible for delivering it to the intended recipient, you are hereby notified that any " +
                        $"disclosure, copying, distribution or use of any of the information contained in or attached to this message is STRICTLY PROHIBITED. If you have received this" +
                        $" transmission in error, please immediately notify the sender and destroy the original transmission and its attachments without reading them or saving them " +
                        $"to disk. Thank you.</p>" +
                        $"</div>" +
                        "</body>" +
                        "</html>";



                if (!string.IsNullOrEmpty(objectStatus.FromEmail) && !string.IsNullOrEmpty(objectStatus.ToEmail))
                {
                    smtpMailHelper.Body = body;
                    smtpMailHelper.Recipient = objectStatus.ToEmail;
                    smtpMailHelper.Sender = objectStatus.FromEmail;
                    smtpMailHelper.RecipientCC = objectStatus.CCEmail;
                    smtpMailHelper.Subject = $"PMPM Access Request for {objectStatus.FullName}, Role: {objectStatus.RoleName}";

                    smtpMailHelper.Send();
                }





            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        public void SendEmail(string connString, UserAccessRequestModel userAccessRequestModel, SmtpMailHelper smtpMailHelper)
        {
            try
            {
                DataTable dataTable;
                SqlParameter[] param =
                {
                    new SqlParameter("@UserAccessRequestGUID", userAccessRequestModel.GUID)
                };
                dataTable = SqlHelper.GetDataTable(connString, "uspGetAccessRequestOwner", param);

                var ownerEmailDb = dataTable.AsEnumerable().Select(dtRow => new
                {
                    Emails = dtRow.Field<string>("Emails")
                }).FirstOrDefault();

                string[] owneremails = ownerEmailDb.Emails.Split(";");

                string body = "<!DOCTYPE html>" +
                                "<html>" +
                                "<body>" +
                              $"<h1>PMPM Access Request</h1>" +
                              $"<table style = \"width:100%\">" +
                              $"  <colgroup>" +
                              $"    <col style=\"width:20%\">" +
                              $"    <col span=\"2\" style=\"background-color:lightgray\" >" +
                              $"  </colgroup>" +
                              $" <tr>" +
                              $"    <td>Requested By</td>" +
                              $"    <td style=\"border:1px solid;padding: 15px;\" >{userAccessRequestModel.UserFullName}</td>" +
                              $"    " +
                              $"  </tr>" +
                              $"  <tr>" +
                              $"    <td>Site Name</td>" +
                              $"    <td style=\"border:1px solid;padding: 15px;\">{userAccessRequestModel.PlantName}</td>" +
                              $"    " +
                              $"  </tr>" +
                              $"  <tr>" +
                              $"    <td>Role Name</td>" +
                              $"    <td style=\"border:1px solid;padding: 15px;\">{userAccessRequestModel.RoleName}</td>" +
                              $"    " +
                              $"  </tr>" +
                              $"  " +
                              $"  <tr>" +
                              $"    <td>Message</td>" +
                              $"    <td style=\"border:1px solid;padding: 15px;\">{userAccessRequestModel.UserMessage}</td>" +
                              $"    " +
                              $"  </tr>" +
                              $"</table>" +
                              $"<br />" +
                              $"Click <a href=\"https://{userAccessRequestModel.Host}/request-approval?guid={userAccessRequestModel.GUID}\">here</a> to see the request." +
                                $"<div>" +
                                $"	<p style=\"font-size: 8px;\">LAM RESEARCH CONFIDENTIALITY NOTICE: This e-mail transmission, and any documents, files, or previous e-mail messages attached" +
                                $" to it, (collectively, \"E-mail Transmission\") may be subject to one or more of the following based on the associated sensitivity level: E-mail Transmission" +
                                $" (i) contains confidential information, (ii) is prohibited from distribution outside of Lam, and/or (iii) is intended solely for and restricted to the specified" +
                                $" recipient(s). If you are not the intended recipient, or a person responsible for delivering it to the intended recipient, you are hereby notified that any " +
                                $"disclosure, copying, distribution or use of any of the information contained in or attached to this message is STRICTLY PROHIBITED. If you have received this" +
                                $" transmission in error, please immediately notify the sender and destroy the original transmission and its attachments without reading them or saving them " +
                                $"to disk. Thank you.</p>" +
                                $"</div>" +
                              "</body>" +
                              "</html>";


                foreach (string email in owneremails)
                {
                    if (!string.IsNullOrEmpty(email))
                    {
                        smtpMailHelper.Body = body;
                        smtpMailHelper.Recipient = email;
                        smtpMailHelper.Sender = userAccessRequestModel.UserEmail;
                        smtpMailHelper.Subject = $"PMPM Access Request for {userAccessRequestModel.UserFullName}, Role: {userAccessRequestModel.RoleName}";

                        smtpMailHelper.Send();
                    }


                }


            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
    }
}
