﻿using LAM.PMPM.DAL;
using LAM.PMPM.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace LAM.PMPM.BL
{
    public class PassdownBL
    {
        public List<PassdownTabs> GetPassdownTabs(string connString, int pilotproductid)
        {
            DataTable dataTable;
            

            SqlParameter[] param =
            {
                new SqlParameter("@PilotProductId", pilotproductid)
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetPassdownTabs", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new PassdownTabs
            {
                ZoneId = dtRow.Field<long?>("ZoneId"),
                TabName = dtRow.Field<string>("TabName"),
                Orders = dtRow.Field<int?>("Orders"),
            }).ToList();

            return masterRecords;
        }

        public PassdownZoneOperationDetail GetGeneratePassdownZonesDetail(string connString, int pilotproductid, int zoneid, int shiftid, int passdownid, DateTime currentTime)
        {
            DataSet dataSet;
            Regex rg = new Regex(@"\d+");

            SqlParameter[] param =
            {
                new SqlParameter("@PilotProductId", pilotproductid),
                new SqlParameter("@ZoneId", zoneid),
                new SqlParameter("@ShiftId", shiftid),
                new SqlParameter("@PassdownId", passdownid),
                new SqlParameter("@CurrentTime", currentTime)
            };

            dataSet = SqlHelper.GetDataSet(connString, "uspGetOrEditGeneratePassdownZonesDetail", param);
            //it will give 6 datasets in following order - do not change this or remove this comment
            //1. Operation Details,
            //2. Skipped Steps Details,
            //3. Audit Item Details,
            //4. Next Steps Details,
            //5. Rework Details,
            //6. ZoneDetails(two field -  other task to complete and Notes)

            DataTable operationDetails = dataSet.Tables[0];
            DataTable skippedStepsDetails = dataSet.Tables[1];
            DataTable auditItemsDetails = dataSet.Tables[2];
            DataTable nextStepDetails = dataSet.Tables[3];
            DataTable reworkDetails = dataSet.Tables[4];
            DataTable zoneDetails = dataSet.Tables[5];

            PassdownZoneOperationDetail passdownZoneOperationDetail = new PassdownZoneOperationDetail();

            List<PassdownOperation> passdownOperations = operationDetails.AsEnumerable().Select(dtRow => new PassdownOperation
            {
                OperationId = dtRow.Field<long?>("OperationID"),
                Description = dtRow.Field<string>("Description"),
                IsComplete = dtRow.Field<bool?>("IsComplete")
            }).ToList();

            List<PassdownOperationStep> passdownOperationSteps = skippedStepsDetails.AsEnumerable().Select(dtRow => new PassdownOperationStep
            {
                OperationId = dtRow.Field<long?>("OperationID"),
                Description = dtRow.Field<string>("Description"),
                SkippedStepNumber = dtRow.Field<int>("StepNo")
            }).ToList();

            List<PassdownAuditItem> passdownAuditItems = auditItemsDetails.AsEnumerable().Select(dtRow => new PassdownAuditItem
            {
                AuditItemId = dtRow.Field<long?>("AuditItemId"),
                Description = dtRow.Field<string>("Description")
            }).ToList();

            List<OperationDetail> nextOperationToComplete = nextStepDetails.AsEnumerable().Select(dtRow => new OperationDetail
            {
                OperationId = dtRow.Field<long?>("OperationID"),
                Description = dtRow.Field<string>("Description")
            }).ToList().OrderBy(x => string.IsNullOrEmpty(rg.Match(x.Description).Value.Trim()) ? 99999 : Convert.ToInt32(rg.Match(x.Description).Value)).ToList();

            List<PassdownRework> passdownReworks = reworkDetails.AsEnumerable().Select(dtRow => new PassdownRework
            {
                OperationId = dtRow.Field<long?>("OperationID"),
                Description = dtRow.Field<string>("Description"),
                ReworkDescription = dtRow.Field<string>("ReworkDescription")
            }).ToList();

            zoneDetails.AsEnumerable().ToList().ForEach(dtRow =>
            {
                passdownZoneOperationDetail.ZoneNotes = dtRow.Field<string>("ZoneNotes");
                passdownZoneOperationDetail.OtherTasksToComplete = dtRow.Field<string>("OtherTasksToComplete");
                passdownZoneOperationDetail.NextOperationToCompleteId = dtRow.Field<long?>("NextOpToCompleteId");
                passdownZoneOperationDetail.PassdownZoneOperationDetailId = dtRow.Field<long?>("PassdownZoneOperationDetailId");
                passdownZoneOperationDetail.PassdownId = dtRow.Field<long?>("PassdownId");
                passdownZoneOperationDetail.ZoneId = dtRow.Field<long?>("ZoneId");
            });

            passdownZoneOperationDetail.CompletedPassdownOperations = passdownOperations.Where(x => x.IsComplete == true).Count() > 0 ? passdownOperations.Where(x => x.IsComplete == true).ToList() : null;
            passdownZoneOperationDetail.ProgressedPassdownOperations = passdownOperations.Where(x => x.IsComplete == false).Count() > 0 ? passdownOperations.Where(x => x.IsComplete == false).ToList() : null;
            passdownZoneOperationDetail.PassdownOperationSteps = passdownOperationSteps;
            passdownZoneOperationDetail.PassdownAuditItems = passdownAuditItems;
            passdownZoneOperationDetail.NextOperationsToComplete = nextOperationToComplete;
            passdownZoneOperationDetail.PassdownReworks = passdownReworks;

            return passdownZoneOperationDetail;
        }

        public int CreateOrEditPassdown(string connString, PassdownGenerateOrEdit passdownGenerateOrEdit, DateTime currentTime, int passdownid = 0)
        {
            try
            {
                var resultCount = 0;
                var outParam = new SqlParameter("@rowCount", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                if (passdownid <= 0)
                {
                    SqlParameter[] param = {
                    new SqlParameter("@PassdownId", passdownGenerateOrEdit.PassdownId),
                    new SqlParameter("@PassdownDate",  passdownGenerateOrEdit.PassdownDate),
                    new SqlParameter("@PilotProductId",  passdownGenerateOrEdit.PilotProductId),
                    new SqlParameter("@ShiftId ",  passdownGenerateOrEdit.ShiftId),
                    new SqlParameter("@CreatedById",  passdownGenerateOrEdit.CreatedById),
                    new SqlParameter("@CreatedDate",  passdownGenerateOrEdit.CreatedOn),
                    new SqlParameter("@CurrentTime", currentTime),
                    new SqlParameter("@PassdownLOTO", GetPassdownLOTOTable(passdownGenerateOrEdit.PassdownLOTOs)),
                    new SqlParameter("@PassdownZoneOperationDetails",  GetPassdownZoneOperationTable(passdownGenerateOrEdit.PassdownZoneOperationTextDetails)),
                    new SqlParameter("@PassdownAssembly",  GetPassdownAssemblyTable(passdownGenerateOrEdit.PassdownAssemblyOperationDetail)),
                    new SqlParameter("@PassdownTest",  GetPassdownTestTable(passdownGenerateOrEdit.PassdownTestDetail)),
                    outParam
                    };
                    resultCount = SqlHelper.ExecuteNonQuery(connString, "uspCreateOrEditPassdown", param);
                }

                else
                {
                    SqlParameter[] param = {
                    new SqlParameter("@PassdownId", passdownid),
                    new SqlParameter("@PassdownDate",  passdownGenerateOrEdit.PassdownDate),
                    new SqlParameter("@PilotProductId",  passdownGenerateOrEdit.PilotProductId),
                    new SqlParameter("@ShiftId ",  passdownGenerateOrEdit.ShiftId),
                    new SqlParameter("@ModifiedById",  passdownGenerateOrEdit.ModifiedById),
                    new SqlParameter("@ModifiedDate",  passdownGenerateOrEdit.ModifiedOn),
                    new SqlParameter("@CurrentTime", currentTime),
                    new SqlParameter("@PassdownLOTO", GetPassdownLOTOTable(passdownGenerateOrEdit.PassdownLOTOs)),
                    new SqlParameter("@PassdownZoneOperationDetails",  GetPassdownZoneOperationTable(passdownGenerateOrEdit.PassdownZoneOperationTextDetails)),
                    new SqlParameter("@PassdownAssembly",  GetPassdownAssemblyTable(passdownGenerateOrEdit.PassdownAssemblyOperationDetail)),
                    new SqlParameter("@PassdownTest",  GetPassdownTestTable(passdownGenerateOrEdit.PassdownTestDetail)),
                    outParam
                    };
                    resultCount = SqlHelper.ExecuteNonQuery(connString, "uspCreateOrEditPassdown", param);
                }


                return resultCount;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public bool GetShowPassdownButtons(string connString, int shiftid, DateTime currentTime)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@ShiftId", shiftid),
                new SqlParameter("@CurrentTime", currentTime),
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetShowPassdownButtons", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new 
            {
                ShowAddEditButton = dtRow.Field<bool?>("ShowAddEditButton")
            }).FirstOrDefault();

            return masterRecords.ShowAddEditButton ?? false;
        }

        public List<PassdownListDetail> GetPassdownsByPPId(string connString, int pilotproductid, int shiftid, DateTime currentTime)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@PilotProductId", pilotproductid),
                new SqlParameter("@ShiftId", shiftid),
                new SqlParameter("@CurrentTime", currentTime),
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetPassdownsByPPId", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new PassdownListDetail
            {
                BEN = dtRow.Field<string>("BEN"),
                PilotSerialNumber = dtRow.Field<string>("PilotSerialNumber"),
                ToolTypeName = dtRow.Field<string>("ToolTypeName"),
                ProductName = dtRow.Field<string>("ProductName"),
                ShiftType = dtRow.Field<string>("ShiftType"),
                PassdownDate = dtRow.Field<DateTime?>("PassdownDate"),
                PassdownId = dtRow.Field<long?>("PassdownId"),
                ShiftId = dtRow.Field<long?>("ShiftId"),
                CreatedById = dtRow.Field<long?>("CreatedById"),
                CreatedBy = dtRow.Field<string>("CreatedBy"),
                IsEditable = dtRow.Field<bool?>("IsEditable")
            }).ToList();

            return masterRecords;
        }

        public PassdownDisplay GetDisplayPassdown(string connString, int pilotproductid, int shiftid, int passdownid, bool isEdit, DateTime currentTime)
        {
            DataSet dataSet;

            SqlParameter[] param =
            {
                new SqlParameter("@PilotProductId", pilotproductid),
                new SqlParameter("@ShiftId", shiftid),
                new SqlParameter("@PassdownId", passdownid),
                new SqlParameter("@IsEdit", isEdit),
                new SqlParameter("@CurrentTime", currentTime)
            };

            dataSet = SqlHelper.GetDataSet(connString, "uspGetDisplayPassdown", param);
            //it will give 13 datasets in following order - do not change this or remove this comment
            //1. PassdownLOTO,
            //2. TOIs,
            //3. IssueLogs,
            //4. NCIs,
            //5. OBC,
            //6. OperationDetails
            //7. Skipped Step Details
            //8. Audit Items By Zone
            //9. Rework Details
            //10. Passdown Zone Operation Details
            //11. Passdonw Assembly Details
            //12. Audit Items Without Zone
            //13. Passdonw Test

            DataTable LOTODetails = dataSet.Tables[0];
            DataTable TOIdetails = dataSet.Tables[1];
            DataTable issueLogsDetails = dataSet.Tables[2];
            DataTable NCIDetails = dataSet.Tables[3];
            DataTable OBCDetails = dataSet.Tables[4];
            DataTable operationDetails = dataSet.Tables[5];
            DataTable skippedStepDetails = dataSet.Tables[6];
            DataTable auditItemByZoneDetails = dataSet.Tables[7];
            DataTable reworkDetails = dataSet.Tables[8];
            DataTable zoneOperationDetails = dataSet.Tables[9];
            DataTable assemblyDetails = dataSet.Tables[10];
            DataTable auditItemsWithoutZoneDetails = dataSet.Tables[11];
            DataTable passdownTestDetails = dataSet.Tables[12];

            PassdownDisplay passdownDisplay = new PassdownDisplay();
            PassdownAssemblyOperationAuditItemsDetail passdownAssemblyOperationAuditItemsDetail = new PassdownAssemblyOperationAuditItemsDetail();
            PassdownTestDetail passdownTestDetail = new PassdownTestDetail();
            List<PassdownModuleProcess> moduleProcess = new List<PassdownModuleProcess>();

            List<PassdownLOTO> passdownLOTOs = LOTODetails.AsEnumerable().Select(dtRow => new PassdownLOTO
            {
                PassdownLOTOId = dtRow.Field<long?>("PassdownLOTOId"),
                PassdownId = dtRow.Field<long?>("PassdownId"),
                FacilityLock = dtRow.Field<bool?>("FacilityLock"),
                Description = dtRow.Field<string>("Description"),
                ReasonForLOTO = dtRow.Field<string>("ReasonForLOTO"),
                CreatedById = dtRow.Field<long?>("CreatedById"),
                CreatedBy = dtRow.Field<string>("CreatedBy")
            }).ToList();

            List<PassdownTOI> passdownTOIs = TOIdetails.AsEnumerable().Select(dtRow => new PassdownTOI
            {
                TOIId = dtRow.Field<long?>("TOIID"),
                CriticalOrGating = dtRow.Field<string>("CriticalOrGating"),
                Title = dtRow.Field<string>("Title"),
                IssueDescription = dtRow.Field<string>("IssueDescription"),
                Comments = dtRow.Field<string>("Comments"),
                StatusID = dtRow.Field<long?>("StatusID"),
                IsOpen = dtRow.Field<bool?>("IsOpen"),
                CreatedOnDate = dtRow.Field<DateTime?>("CreatedOnDate"),
                UpdatedOnDate = dtRow.Field<DateTime?>("UpdatedOnDate"),
                PassdownDate = dtRow.Field<DateTime?>("PassdownDate")
            }).ToList();

            List<PassdownIssueLog> passdownIssueLogs = issueLogsDetails.AsEnumerable().Select(dtRow => new PassdownIssueLog
            {
                DateModified = dtRow.Field<DateTime?>("DateModified"),
                IssueTitle = dtRow.Field<string>("IssueTitle"),
                RecID = dtRow.Field<int?>("RecId"),
                IssueLogNum = dtRow.Field<string>("IssueLogNum"),
                Status = dtRow.Field<string>("Status")
            }).ToList();

            List<PassdownNCI> passdownNCIs = NCIDetails.AsEnumerable().Select(dtRow => new PassdownNCI
            {
                Title = dtRow.Field<string>("Title"),
                Status = dtRow.Field<string>("Status"),
                IsClosed = dtRow.Field<bool?>("IsClosed"),
                IQMSId = dtRow.Field<int?>("iQMSId")
            }).ToList();

            List<PassdownOBC> passdownOBCs = OBCDetails.AsEnumerable().Select(dtRow => new PassdownOBC
            {
                RecId = dtRow.Field<int?>("RecId"),
                LineItemNumber = dtRow.Field<string>("LineItemNumber"),
                IsAddOrRemove = dtRow.Field<string>("IsAddOrRemove"),
                LongText = dtRow.Field<string>("LongText"),
                IsOpen = dtRow.Field<bool?>("IsOpen")
            }).ToList();

            //had to apply grouping to extract the same module process from different object and group them by module and zones
            List<PassdownOperationWithZone> passdownOperations = operationDetails.AsEnumerable().Select(dtRow => new PassdownOperationWithZone
            {
                OperationId = dtRow.Field<long?>("OperationID"),
                Description = dtRow.Field<string>("Description"),
                IsComplete = dtRow.Field<bool?>("IsComplete"),
                ZoneId = dtRow.Field<long?>("ZoneID"),
                Zone = dtRow.Field<string>("Zone"),
                ModuleProcess = dtRow.Field<string>("ModuleProcess")
            }).ToList();

            passdownOperations.GroupBy(mm => mm.ModuleProcess).Select(mm => new { mm.Key, PassdownOperationWithZone = mm.ToList() }).ToList().ForEach(inmm =>
            {
                if (moduleProcess.Where(mpnew => mpnew.ModuleProcess == inmm.Key).Count() <= 0)
                {
                    moduleProcess.Add(new PassdownModuleProcess()
                    {
                        ModuleProcess = inmm.Key
                    });
                }

                inmm.PassdownOperationWithZone.GroupBy(x => new { x.ZoneId, x.Zone, x.ModuleProcess }).Select(x => new
                {
                    x.Key,
                    PassdownOperationsgrouped = x.Select(pp => new PassdownOperation
                    {
                        Description = pp.Description,
                        IsComplete = pp.IsComplete,
                        OperationId = pp.OperationId
                    }).ToList()
                }).ToList().ForEach(zz =>
                {
                    var added = moduleProcess.Where(xx => xx.ModuleProcess == inmm.Key).FirstOrDefault();
                    if (added.PassdownZoneOperationDetailWithZones.Where(mp => mp.ZoneId == zz.Key.ZoneId && mp.Zone == zz.Key.Zone).Count() <= 0)
                    {
                        added.PassdownZoneOperationDetailWithZones.Add(new PassdownZoneOperationDetailWithZone()
                        {
                            Zone = zz.Key.Zone,
                            ZoneId = zz.Key.ZoneId,
                            CompletedPassdownOperations = zz.PassdownOperationsgrouped.Where(po => po.IsComplete == true).Count() > 0 ? zz.PassdownOperationsgrouped.Where(po => po.IsComplete == true).ToList() : null,
                            ProgressedPassdownOperations = zz.PassdownOperationsgrouped.Where(po => po.IsComplete == false).Count() > 0 ? zz.PassdownOperationsgrouped.Where(po => po.IsComplete == false).ToList() : null
                        });
                    }
                    else
                    {
                        added.PassdownZoneOperationDetailWithZones.Where(mp => mp.ZoneId == zz.Key.ZoneId && mp.Zone == zz.Key.Zone)
                            .FirstOrDefault().CompletedPassdownOperations = zz.PassdownOperationsgrouped.Where(po => po.IsComplete == true).Count() > 0 ? zz.PassdownOperationsgrouped.Where(po => po.IsComplete == true).ToList() : null;
                        added.PassdownZoneOperationDetailWithZones.Where(mp => mp.ZoneId == zz.Key.ZoneId && mp.Zone == zz.Key.Zone)
                            .FirstOrDefault().ProgressedPassdownOperations = zz.PassdownOperationsgrouped.Where(po => po.IsComplete == false).Count() > 0 ? zz.PassdownOperationsgrouped.Where(po => po.IsComplete == false).ToList() : null;
                    }
                });
            });

            List<PassdownOperationStepWithZone> passdownOperationSteps = skippedStepDetails.AsEnumerable().Select(dtRow => new PassdownOperationStepWithZone
            {
                OperationId = dtRow.Field<long?>("OperationID"),
                Description = dtRow.Field<string>("Description"),
                SkippedStepNumber = dtRow.Field<int>("StepNo"),
                ZoneId = dtRow.Field<long?>("ZoneID"),
                Zone = dtRow.Field<string>("Zone"),
                ModuleProcess = dtRow.Field<string>("ModuleProcess")
            }).ToList();

            passdownOperationSteps.GroupBy(mm => mm.ModuleProcess).Select(mm => new { mm.Key, PassdownOperationStepsWithZone = mm.ToList() }).ToList().ForEach(inmm =>
            {
                if (moduleProcess.Where(mpnew => mpnew.ModuleProcess == inmm.Key).Count() <= 0)
                {
                    moduleProcess.Add(new PassdownModuleProcess()
                    {
                        ModuleProcess = inmm.Key
                    });
                }

                inmm.PassdownOperationStepsWithZone.GroupBy(x => new { x.ZoneId, x.Zone, x.ModuleProcess }).Select(x => new
                {
                    x.Key,
                    PassdownOperationStepsgrouped = x.Select(pp => new PassdownOperationStep
                    {
                        Description = pp.Description,
                        SkippedStepNumber = pp.SkippedStepNumber,
                        OperationId = pp.OperationId
                    }).ToList()
                }).ToList().ForEach(zz =>
                {
                    var added = moduleProcess.Where(xx => xx.ModuleProcess == inmm.Key).FirstOrDefault();
                    if (added.PassdownZoneOperationDetailWithZones.Where(mp => mp.ZoneId == zz.Key.ZoneId && mp.Zone == zz.Key.Zone).Count() <= 0)
                    {
                        added.PassdownZoneOperationDetailWithZones.Add(new PassdownZoneOperationDetailWithZone()
                        {
                            Zone = zz.Key.Zone,
                            ZoneId = zz.Key.ZoneId,
                            PassdownOperationSteps = zz.PassdownOperationStepsgrouped
                        });
                    }
                    else
                    {
                        added.PassdownZoneOperationDetailWithZones.Where(mp => mp.ZoneId == zz.Key.ZoneId && mp.Zone == zz.Key.Zone)
                            .FirstOrDefault().PassdownOperationSteps = zz.PassdownOperationStepsgrouped;
                    }
                });
            });

            List<PassdownAuditItemWithZone> passdownAuditItemsByZone = auditItemByZoneDetails.AsEnumerable().Select(dtRow => new PassdownAuditItemWithZone
            {
                AuditItemId = dtRow.Field<long?>("AuditItemId"),
                Description = dtRow.Field<string>("Description"),
                ZoneId = dtRow.Field<long?>("ZoneID"),
                Zone = dtRow.Field<string>("Zone"),
                ModuleProcess = dtRow.Field<string>("ModuleProcess")
            }).ToList();

            passdownAuditItemsByZone.GroupBy(mm => mm.ModuleProcess).Select(mm => new { mm.Key, PassdownAuditItemnWithZone = mm.ToList() }).ToList().ForEach(inmm =>
            {
                if (moduleProcess.Where(mpnew => mpnew.ModuleProcess == inmm.Key).Count() <= 0)
                {
                    moduleProcess.Add(new PassdownModuleProcess()
                    {
                        ModuleProcess = inmm.Key
                    });
                }

                inmm.PassdownAuditItemnWithZone.GroupBy(x => new { x.ZoneId, x.Zone, x.ModuleProcess }).Select(x => new
                {
                    x.Key,
                    PassdownAuditItemsgrouped = x.Select(pp => new PassdownAuditItem
                    {
                        AuditItemId = pp.AuditItemId,
                        Description = pp.Description,
                    }).ToList()
                }).ToList().ForEach(zz =>
                {
                    var added = moduleProcess.Where(xx => xx.ModuleProcess == inmm.Key).FirstOrDefault();
                    if (added.PassdownZoneOperationDetailWithZones.Where(mp => mp.ZoneId == zz.Key.ZoneId && mp.Zone == zz.Key.Zone).Count() <= 0)
                    {
                        added.PassdownZoneOperationDetailWithZones.Add(new PassdownZoneOperationDetailWithZone()
                        {
                            Zone = zz.Key.Zone,
                            ZoneId = zz.Key.ZoneId,
                            PassdownAuditItems = zz.PassdownAuditItemsgrouped
                        });
                    }
                    else
                    {
                        added.PassdownZoneOperationDetailWithZones.Where(mp => mp.ZoneId == zz.Key.ZoneId && mp.Zone == zz.Key.Zone)
                            .FirstOrDefault().PassdownAuditItems = zz.PassdownAuditItemsgrouped;
                    }
                });
            });

            List<PassdownReworkWithZone> passdownReworks = reworkDetails.AsEnumerable().Select(dtRow => new PassdownReworkWithZone
            {
                OperationId = dtRow.Field<long?>("OperationID"),
                Description = dtRow.Field<string>("Description"),
                ReworkDescription = dtRow.Field<string>("ReworkDescription"),
                ZoneId = dtRow.Field<long?>("ZoneID"),
                Zone = dtRow.Field<string>("Zone"),
                ModuleProcess = dtRow.Field<string>("ModuleProcess")
            }).ToList();

            passdownReworks.GroupBy(mm => mm.ModuleProcess).Select(mm => new { mm.Key, PassdownReworkWithZone = mm.ToList() }).ToList().ForEach(inmm =>
            {
                if (moduleProcess.Where(mpnew => mpnew.ModuleProcess == inmm.Key).Count() <= 0)
                {
                    moduleProcess.Add(new PassdownModuleProcess()
                    {
                        ModuleProcess = inmm.Key
                    });
                }

                inmm.PassdownReworkWithZone.GroupBy(x => new { x.ZoneId, x.Zone, x.ModuleProcess }).Select(x => new
                {
                    x.Key,
                    PassdownReworksgrouped = x.Select(pp => new PassdownRework
                    {
                        OperationId = pp.OperationId,
                        Description = pp.Description,
                        ReworkDescription = pp.ReworkDescription
                    }).ToList()
                }).ToList().ForEach(zz =>
                {
                    var added = moduleProcess.Where(xx => xx.ModuleProcess == inmm.Key).FirstOrDefault();
                    if (added.PassdownZoneOperationDetailWithZones.Where(mp => mp.ZoneId == zz.Key.ZoneId && mp.Zone == zz.Key.Zone).Count() <= 0)
                    {
                        added.PassdownZoneOperationDetailWithZones.Add(new PassdownZoneOperationDetailWithZone()
                        {
                            Zone = zz.Key.Zone,
                            ZoneId = zz.Key.ZoneId,
                            PassdownReworks = zz.PassdownReworksgrouped
                        });
                    }
                    else
                    {
                        added.PassdownZoneOperationDetailWithZones.Where(mp => mp.ZoneId == zz.Key.ZoneId && mp.Zone == zz.Key.Zone)
                            .FirstOrDefault().PassdownReworks = zz.PassdownReworksgrouped;
                    }
                });
            });

            List<PassdownZoneOperationTextDetailWithZOne> passdownZoneOperationTextDetails = zoneOperationDetails.AsEnumerable().Select(dtRow => new PassdownZoneOperationTextDetailWithZOne
            {
                PassdownZoneOperationDetailId = dtRow.Field<long?>("PassdownZoneOperationDetailId"),
                PassdownId = dtRow.Field<long?>("PassdownId"),
                ZoneNotes = dtRow.Field<string>("ZoneNotes"),
                OtherTasksToComplete = dtRow.Field<string>("OtherTasksToComplete"),
                NextOperationToCompleteId = dtRow.Field<long?>("NextOpToCompleteId"),
                NextOpToComplete = dtRow.Field<string>("NextOpToComplete"),
                Zone = dtRow.Field<string>("Zone"),
                ZoneId = dtRow.Field<long?>("ZoneID"),
                ModuleProcess = dtRow.Field<string>("ModuleProcess")
            }).ToList();

            passdownZoneOperationTextDetails.GroupBy(mm => mm.ModuleProcess).Select(mm => new { mm.Key, PassdownZoneOperationTextDetailWithZOne = mm.ToList() }).ToList().ForEach(inmm =>
            {
                if (moduleProcess.Where(mpnew => mpnew.ModuleProcess == inmm.Key).Count() <= 0)
                {
                    moduleProcess.Add(new PassdownModuleProcess()
                    {
                        ModuleProcess = inmm.Key
                    });
                }

                inmm.PassdownZoneOperationTextDetailWithZOne.GroupBy(x => new { x.ZoneId, x.Zone, x.ModuleProcess }).Select(x => new
                {
                    x.Key,
                    PassdownZoneOperationTextDetailgrouped = x.Select(pp => new PassdownZoneOperationTextDetail
                    {
                        PassdownZoneOperationDetailId = pp.PassdownZoneOperationDetailId,
                        NextOperationToCompleteId = pp.NextOperationToCompleteId,
                        NextOpToComplete = pp.NextOpToComplete,
                        OtherTasksToComplete = pp.OtherTasksToComplete,
                        PassdownId = pp.PassdownId,
                        ZoneId = pp.ZoneId,
                        ZoneNotes = pp.ZoneNotes
                    }).ToList()
                }).ToList().ForEach(zz =>
                {
                    var added = moduleProcess.Where(xx => xx.ModuleProcess == inmm.Key).FirstOrDefault();
                    if (added.PassdownZoneOperationDetailWithZones.Where(mp => mp.ZoneId == zz.Key.ZoneId && mp.Zone == zz.Key.Zone).Count() <= 0)
                    {
                        added.PassdownZoneOperationDetailWithZones.Add(new PassdownZoneOperationDetailWithZone()
                        {
                            Zone = zz.Key.Zone,
                            ZoneId = zz.Key.ZoneId,
                            PassdownZoneOperationTextDetails = zz.PassdownZoneOperationTextDetailgrouped
                        });
                    }
                    else
                    {
                        added.PassdownZoneOperationDetailWithZones.Where(mp => mp.ZoneId == zz.Key.ZoneId && mp.Zone == zz.Key.Zone)
                            .FirstOrDefault().PassdownZoneOperationTextDetails = zz.PassdownZoneOperationTextDetailgrouped;
                    }
                });
            });

            assemblyDetails.AsEnumerable().ToList().ForEach(dtRow =>
            {
                passdownAssemblyOperationAuditItemsDetail.PassdownAssemblyId = dtRow.Field<long?>("PassdownAssemblyId");
                passdownAssemblyOperationAuditItemsDetail.PassdownId = dtRow.Field<long?>("PassdownId");
                passdownAssemblyOperationAuditItemsDetail.OpCompleted = dtRow.Field<string>("OpCompleted");
                passdownAssemblyOperationAuditItemsDetail.OpProgressed = dtRow.Field<string>("OpProgressed");
                passdownAssemblyOperationAuditItemsDetail.OpSkipped = dtRow.Field<string>("OpSkipped");
                passdownAssemblyOperationAuditItemsDetail.NextSteps = dtRow.Field<string>("NextSteps");
                passdownAssemblyOperationAuditItemsDetail.Rework = dtRow.Field<string>("Rework");
                passdownAssemblyOperationAuditItemsDetail.Notes = dtRow.Field<string>("Notes");
            });

            List<PassdownAuditItem> passdownAuditItems = auditItemsWithoutZoneDetails.AsEnumerable().Select(dtRow => new PassdownAuditItem
            {
                AuditItemId = dtRow.Field<long?>("AuditItemId"),
                Description = dtRow.Field<string>("Description")
            }).ToList();

            passdownTestDetails.AsEnumerable().ToList().ForEach(dtRow =>
            {
                passdownTestDetail.PassdownTestId = dtRow.Field<long?>("PassdownTestId");
                passdownTestDetail.PassdownId = dtRow.Field<long?>("PassdownId");
                passdownTestDetail.OpCompleted = dtRow.Field<string>("OpCompleted");
                passdownTestDetail.OpProgressed = dtRow.Field<string>("OpProgressed");
                passdownTestDetail.OpSkipped = dtRow.Field<string>("OpSkipped");
                passdownTestDetail.NextSteps = dtRow.Field<string>("NextSteps");
                passdownTestDetail.SpecialInstructions = dtRow.Field<string>("SpecialInstructions");
                passdownTestDetail.Notes = dtRow.Field<string>("Notes");
            });

            //Action Items
            passdownDisplay.Issues.PassdownLOTOs = passdownLOTOs;
            passdownDisplay.Issues.OpenCriticalGatingTOIs = passdownTOIs.Where(x => x.CriticalOrGating != null && x.IsOpen.Value).Count() > 0 ? passdownTOIs.Where(x => x.CriticalOrGating != null &&  x.IsOpen.Value).ToList() : null;
            if (isEdit)
            {
                passdownDisplay.Issues.OpenTOIs = passdownTOIs.Where(x => x.IsOpen.Value && ((x.CreatedOnDate != null && x.CreatedOnDate.Value.Date == currentTime.Date) || (x.UpdatedOnDate != null && x.UpdatedOnDate.Value.Date == currentTime.Date))).Count() > 0 ? passdownTOIs.Where(x => x.IsOpen.Value && ((x.CreatedOnDate != null && x.CreatedOnDate.Value.Date == currentTime.Date) || (x.UpdatedOnDate != null && x.UpdatedOnDate.Value.Date == currentTime.Date))).ToList() : null;
            } else
            {
                if(passdownid == 0)
                {
                    passdownDisplay.Issues.OpenTOIs = passdownTOIs.Where(x => x.IsOpen.Value && ((x.CreatedOnDate != null && x.CreatedOnDate.Value.Date == currentTime.Date) || (x.UpdatedOnDate != null && x.UpdatedOnDate.Value.Date == currentTime.Date))).Count() > 0 ? passdownTOIs.Where(x => x.IsOpen.Value && ((x.CreatedOnDate != null && x.CreatedOnDate.Value.Date == currentTime.Date) || (x.UpdatedOnDate != null && x.UpdatedOnDate.Value.Date == currentTime.Date))).ToList() : null;
                }
                else
                {
                    passdownDisplay.Issues.OpenTOIs = passdownTOIs.Where(x => x.IsOpen.Value && ((x.CreatedOnDate != null && x.PassdownDate != null && x.CreatedOnDate.Value.Date == x.PassdownDate.Value.Date) || (x.UpdatedOnDate != null && x.PassdownDate != null && x.UpdatedOnDate.Value.Date == x.PassdownDate.Value.Date))).Count() > 0 ? passdownTOIs.Where(x => x.IsOpen.Value && ((x.CreatedOnDate != null && x.PassdownDate != null && x.CreatedOnDate.Value.Date == x.PassdownDate.Value.Date) || (x.UpdatedOnDate != null && x.PassdownDate != null && x.UpdatedOnDate.Value.Date == x.PassdownDate.Value.Date))).ToList() : null;
                }
                
            }
            
            passdownDisplay.Issues.CloseTOIs = passdownTOIs.Where(x => !x.IsOpen.Value).Count() > 0 ? passdownTOIs.Where(x => !x.IsOpen.Value).ToList() : null;
            passdownDisplay.Issues.PassdownIssueLogs = passdownIssueLogs;
            passdownDisplay.Issues.OpenNCIs = passdownNCIs.Where(x => !x.IsClosed.Value).Count() > 0 ? passdownNCIs.Where(x => !x.IsClosed.Value).ToList() : null;
            passdownDisplay.Issues.ClosedNCIs = passdownNCIs.Where(x => x.IsClosed.Value).Count() > 0 ? passdownNCIs.Where(x => x.IsClosed.Value).ToList() : null;
            passdownDisplay.Issues.OpenOBCs = passdownOBCs.Where(x => x.IsOpen.Value).Count() > 0 ? passdownOBCs.Where(x => x.IsOpen.Value).ToList() : null;
            passdownDisplay.Issues.ClosedOBCs = passdownOBCs.Where(x => !x.IsOpen.Value).Count() > 0 ? passdownOBCs.Where(x => !x.IsOpen.Value).ToList() : null;

            //Zones Tabs
            passdownDisplay.ModuleProcesses = moduleProcess;

            //Assembly (no reconfig)
            passdownDisplay.PassdownAssemblyOperationAuditItemsDetail = passdownAssemblyOperationAuditItemsDetail;
            passdownDisplay.PassdownAssemblyOperationAuditItemsDetail.PassdownAuditItems = passdownAuditItems;

            //Test
            passdownDisplay.PassdownTestDetail = passdownTestDetail;

            return passdownDisplay;
        }

        private DataTable GetPassdownTestTable(PassdownTestDetail passdownTestDetail)
        {
            DataTable passdownTestDetails = new DataTable();

            passdownTestDetails.Columns.Add("PassdownTestId", typeof(long));
            passdownTestDetails.Columns.Add("PassdownId", typeof(long));
            passdownTestDetails.Columns.Add("OpCompleted", typeof(string));
            passdownTestDetails.Columns.Add("OpProgressed", typeof(string));
            passdownTestDetails.Columns.Add("OpSkipped", typeof(string));
            passdownTestDetails.Columns.Add("NextSteps", typeof(string));
            passdownTestDetails.Columns.Add("SpecialInstructions", typeof(string));
            passdownTestDetails.Columns.Add("Notes", typeof(string));

            if (passdownTestDetail != null)
            {
                passdownTestDetails.Rows.Add(passdownTestDetail.PassdownTestId, passdownTestDetail.PassdownId
                , passdownTestDetail.OpCompleted, passdownTestDetail.OpProgressed, passdownTestDetail.OpSkipped
                , passdownTestDetail.NextSteps, passdownTestDetail.SpecialInstructions, passdownTestDetail.Notes);
            }


            return passdownTestDetails;
        }

        private DataTable GetPassdownAssemblyTable(PassdownAssemblyOperationDetail passdownAssemblyOperationDetail)
        {
            DataTable passdownAssemblyOperationDetails = new DataTable();

            passdownAssemblyOperationDetails.Columns.Add("PassdownAssemblyId", typeof(long));
            passdownAssemblyOperationDetails.Columns.Add("PassdownId", typeof(long));
            passdownAssemblyOperationDetails.Columns.Add("OpCompleted", typeof(string));
            passdownAssemblyOperationDetails.Columns.Add("OpProgressed", typeof(string));
            passdownAssemblyOperationDetails.Columns.Add("OpSkipped", typeof(string));
            passdownAssemblyOperationDetails.Columns.Add("NextSteps", typeof(string));
            passdownAssemblyOperationDetails.Columns.Add("Rework", typeof(string));
            passdownAssemblyOperationDetails.Columns.Add("Notes", typeof(string));

            if (passdownAssemblyOperationDetail != null)
            {
                passdownAssemblyOperationDetails.Rows.Add(passdownAssemblyOperationDetail.PassdownAssemblyId, passdownAssemblyOperationDetail.PassdownId
                , passdownAssemblyOperationDetail.OpCompleted, passdownAssemblyOperationDetail.OpProgressed, passdownAssemblyOperationDetail.OpSkipped
                , passdownAssemblyOperationDetail.NextSteps, passdownAssemblyOperationDetail.Rework, passdownAssemblyOperationDetail.Notes);
            }


            return passdownAssemblyOperationDetails;
        }

        private DataTable GetPassdownZoneOperationTable(List<PassdownZoneOperationTextDetail> passdownZoneOperationTextDetails)
        {
            DataTable passdownOperationDetails = new DataTable();

            passdownOperationDetails.Columns.Add("PassdownZoneOperationDetailId", typeof(long));
            passdownOperationDetails.Columns.Add("PassdownId", typeof(long));
            passdownOperationDetails.Columns.Add("ZoneId", typeof(long));
            passdownOperationDetails.Columns.Add("OtherTasksToComplete", typeof(string));
            passdownOperationDetails.Columns.Add("ZoneNotes", typeof(string));
            passdownOperationDetails.Columns.Add("NextOpToCompleteId", typeof(long));

            foreach (PassdownZoneOperationTextDetail passdownZoneOperationText in passdownZoneOperationTextDetails)
            {
                passdownOperationDetails.Rows.Add(passdownZoneOperationText.PassdownZoneOperationDetailId, passdownZoneOperationText.PassdownId
                    , passdownZoneOperationText.ZoneId, passdownZoneOperationText.OtherTasksToComplete, passdownZoneOperationText.ZoneNotes
                    , passdownZoneOperationText.NextOperationToCompleteId);
            }

            return passdownOperationDetails;
        }

        private DataTable GetPassdownLOTOTable(List<PassdownLOTO> passdownLOTOs)
        {
            DataTable passdownLOTO = new DataTable();
            passdownLOTO.Columns.Add("PassdownLOTOId", typeof(long));
            passdownLOTO.Columns.Add("PassdownId", typeof(long));
            passdownLOTO.Columns.Add("FacilityLock", typeof(bool));
            passdownLOTO.Columns.Add("Description", typeof(string));
            passdownLOTO.Columns.Add("ReasonForLOTO", typeof(string));
            passdownLOTO.Columns.Add("CreatedBy", typeof(long));

            foreach (PassdownLOTO LOTO in passdownLOTOs)
            {
                passdownLOTO.Rows.Add(LOTO.PassdownLOTOId, LOTO.PassdownId, LOTO.FacilityLock, LOTO.Description, LOTO.ReasonForLOTO, LOTO.CreatedById);
            }

            return passdownLOTO;
        }

        public PassdownTestDetail GetPassdownTest(string connString, int passdownid)
        {
            DataTable dataTable;

            SqlParameter[] param =
            {
                new SqlParameter("@PassdownId", passdownid),
            };

            dataTable = SqlHelper.GetDataTable(connString, "uspGetPassdownTest", param);

            var masterRecords = dataTable.AsEnumerable().Select(dtRow => new PassdownTestDetail
            {
                OpCompleted = dtRow.Field<string>("OpCompleted"),
                OpProgressed = dtRow.Field<string>("OpProgressed"),
                OpSkipped = dtRow.Field<string>("OpSkipped"),
                NextSteps = dtRow.Field<string>("NextSteps"),
                SpecialInstructions = dtRow.Field<string>("SpecialInstructions"),
                Notes = dtRow.Field<string>("Notes"),
                PassdownTestId = dtRow.Field<long?>("PassdownTestId"),
                PassdownId = dtRow.Field<long?>("PassdownId"),
            }).FirstOrDefault();

            return masterRecords;
        }

        public PassdownAssemblyOperationDetail GetGeneratePassdownAssemblyOperations(string connString, int pilotproductid, int shiftid, int passdownid)
        {
            DataSet dataSet;

            SqlParameter[] param =
            {
                new SqlParameter("@PilotProductId", pilotproductid),
                new SqlParameter("@ShiftId", shiftid),
                new SqlParameter("@PassdownId", passdownid),
            };

            dataSet = SqlHelper.GetDataSet(connString, "uspGetOrEditPassdownAssemblyOperations", param);
            //it will give 2 datasets in following order - do not change this or remove this comment
            //1. OperationDetails - text values,
            //2. Completed AuditItems,

            DataTable assemblyOperationDetails = dataSet.Tables[0];
            DataTable auditItemsDetails = dataSet.Tables[1];

            PassdownAssemblyOperationAuditItemsDetail assdownAssemblyOperationAuditItemsDetail = new PassdownAssemblyOperationAuditItemsDetail();

            assemblyOperationDetails.AsEnumerable().ToList().ForEach(dtRow =>
            {
                assdownAssemblyOperationAuditItemsDetail.OpCompleted = dtRow.Field<string>("OpCompleted");
                assdownAssemblyOperationAuditItemsDetail.OpProgressed = dtRow.Field<string>("OpProgressed");
                assdownAssemblyOperationAuditItemsDetail.OpSkipped = dtRow.Field<string>("OpSkipped");
                assdownAssemblyOperationAuditItemsDetail.NextSteps = dtRow.Field<string>("NextSteps");
                assdownAssemblyOperationAuditItemsDetail.Rework = dtRow.Field<string>("Rework");
                assdownAssemblyOperationAuditItemsDetail.Notes = dtRow.Field<string>("Notes");
                assdownAssemblyOperationAuditItemsDetail.PassdownAssemblyId = dtRow.Field<long?>("PassdownAssemblyId");
                assdownAssemblyOperationAuditItemsDetail.PassdownId = dtRow.Field<long?>("PassdownId");

            });

            List<PassdownAuditItem> passdownAuditItems = auditItemsDetails.AsEnumerable().Select(dtRow => new PassdownAuditItem
            {
                AuditItemId = dtRow.Field<long?>("AuditItemId"),
                Description = dtRow.Field<string>("Description")
            }).ToList();

            assdownAssemblyOperationAuditItemsDetail.PassdownAuditItems = passdownAuditItems;

            return assdownAssemblyOperationAuditItemsDetail;
        }

        public PassdownActionItemsDetail GetGeneratePassdownActionItems(string connString, int pilotproductid, int shiftid, int passdownid, DateTime currentTime)
        {
            DataSet dataSet;

            SqlParameter[] param =
            {
                new SqlParameter("@PilotProductId", pilotproductid),
                new SqlParameter("@ShiftId", shiftid),
                new SqlParameter("@PassdownId", passdownid),
                new SqlParameter("@CurrentTime", currentTime)
            };

            dataSet = SqlHelper.GetDataSet(connString, "uspGetOrEditGeneratePassdownActionItems", param);
            //it will give 5 datasets in following order - do not change this or remove this comment
            //1. LOTO,
            //2. TOI,
            //3. Issue Logs,
            //4. NCI,
            //5. OBC,
            //6. BuildStyle

            DataTable OBCDetails = null;
            DataTable buildStyle = null;

            DataTable lotoDetails = dataSet.Tables[0];
            DataTable TOIDetails = dataSet.Tables[1];
            DataTable issueLogsDetails = dataSet.Tables[2];
            DataTable NCIDetails = dataSet.Tables[3];
            DataTable EditButtonOperation = dataSet.Tables[6];
            if (dataSet.Tables.Count > 4)
            {
                OBCDetails = dataSet.Tables[4];
                buildStyle = dataSet.Tables[5];
            }
            else
            {
                buildStyle = dataSet.Tables[4];
            }
            

            PassdownActionItemsDetail passdownActionItemsDetail = new PassdownActionItemsDetail();

            List<PassdownLOTO> passdownLOTOs = lotoDetails.AsEnumerable().Select(dtRow => new PassdownLOTO
            {
                PassdownLOTOId = dtRow.Field<long?>("PassdownLOTOId"),
                PassdownId = dtRow.Field<long?>("PassdownId"),
                FacilityLock = dtRow.Field<bool?>("FacilityLock"),
                Description = dtRow.Field<string>("Description"),
                ReasonForLOTO = dtRow.Field<string>("ReasonForLOTO"),
                CreatedById = dtRow.Field<long?>("CreatedById"),
                CreatedBy = dtRow.Field<string>("CreatedBy"),
            }).ToList();

            List<PassdownTOI> passdownTOIs = TOIDetails.AsEnumerable().Select(dtRow => new PassdownTOI
            {
                TOIId = dtRow.Field<long?>("TOIID"),
                CriticalOrGating = dtRow.Field<string>("CriticalOrGating"),
                Title = dtRow.Field<string>("Title"),
                IssueDescription = dtRow.Field<string>("IssueDescription"),
                Comments = dtRow.Field<string>("Comments"),
                StatusID = dtRow.Field<long?>("StatusID"),
                IsOpen = dtRow.Field<bool?>("IsOpen"),
                CreatedOnDate = dtRow.Field<DateTime?>("CreatedOnDate"),
                UpdatedOnDate = dtRow.Field<DateTime?>("UpdatedOnDate"),

            }).ToList();

            List<PassdownIssueLog> passdownIssueLogs = issueLogsDetails.AsEnumerable().Select(dtRow => new PassdownIssueLog
            {
                DateModified = dtRow.Field<DateTime?>("DateModified"),
                IssueTitle = dtRow.Field<string>("IssueTitle"),
                RecID = dtRow.Field<int?>("RecId"),
                IssueLogNum = dtRow.Field<string>("IssueLogNum"),
                Status = dtRow.Field<string>("Status")
            }).ToList();

            List<PassdownNCI> passdownNCIs = NCIDetails.AsEnumerable().Select(dtRow => new PassdownNCI
            {
                Title = dtRow.Field<string>("Title"),
                Status = dtRow.Field<string>("Status"),
                IsClosed = dtRow.Field<bool?>("IsClosed"),
                IQMSId = dtRow.Field<int?>("iQMSId")
            }).ToList();

            List<PassdownOBC> passdownOBCs = OBCDetails.AsEnumerable().Select(dtRow => new PassdownOBC
            {
                RecId = dtRow.Field<int?>("RecId"),
                LineItemNumber = dtRow.Field<string>("LineItemNumber"),
                IsAddOrRemove = dtRow.Field<string>("IsAddOrRemove"),
                LongText = dtRow.Field<string>("LongText"),
                IsOpen = dtRow.Field<bool?>("IsOpen"),
            }).ToList();

            BuildStyleDetail buildStyleDetail = buildStyle.AsEnumerable().Select(dtRow => new BuildStyleDetail
            {
                BuildStyleId = dtRow.Field<int?>("BuildStyleId"),
                BuildStyle = dtRow.Field<string>("BuildStyle")
            }).FirstOrDefault();
            EditButtonDetail editButtonDetail = EditButtonOperation.AsEnumerable().Select(dtRow => new EditButtonDetail
            {
                IsEditable = dtRow.Field<bool?>("IsEditable"),
              
            }).FirstOrDefault();

            passdownActionItemsDetail.PassdownLOTOs = passdownLOTOs;
            passdownActionItemsDetail.OpenCriticalGatingTOIs = passdownTOIs.Where(x => x.CriticalOrGating != null && x.IsOpen.Value).Count() > 0 ? passdownTOIs.Where(x => x.CriticalOrGating != null &&  x.IsOpen.Value).ToList() : null;
            passdownActionItemsDetail.OpenTOIs = passdownTOIs.Where(x => x.IsOpen.Value && ((x.CreatedOnDate != null && x.CreatedOnDate.Value.Date == currentTime.Date) || (x.UpdatedOnDate != null && x.UpdatedOnDate.Value.Date == currentTime.Date))).Count() > 0 ? passdownTOIs.Where(x => x.IsOpen.Value && ((x.CreatedOnDate != null && x.CreatedOnDate.Value.Date == currentTime.Date) || (x.UpdatedOnDate != null && x.UpdatedOnDate.Value.Date == currentTime.Date))).ToList() : null;
            passdownActionItemsDetail.CloseTOIs = passdownTOIs.Where(x => !x.IsOpen.Value).Count() > 0 ? passdownTOIs.Where(x => !x.IsOpen.Value).ToList() : null;
            passdownActionItemsDetail.PassdownIssueLogs = passdownIssueLogs;
            passdownActionItemsDetail.OpenNCIs = passdownNCIs.Where(x => !x.IsClosed.Value).Count() > 0 ? passdownNCIs.Where(x => !x.IsClosed.Value).ToList() : null;
            passdownActionItemsDetail.ClosedNCIs = passdownNCIs.Where(x => x.IsClosed.Value).Count() > 0 ? passdownNCIs.Where(x => x.IsClosed.Value).ToList() : null;
            passdownActionItemsDetail.OpenOBCs = passdownOBCs.Where(x => x.IsOpen.Value).Count() > 0 ? passdownOBCs.Where(x => x.IsOpen.Value).ToList() : null;
            passdownActionItemsDetail.ClosedOBCs = passdownOBCs.Where(x => !x.IsOpen.Value).Count() > 0 ? passdownOBCs.Where(x => !x.IsOpen.Value).ToList() : null;
            passdownActionItemsDetail.BuildStyleDetail = buildStyleDetail;
            passdownActionItemsDetail.EditButtonDetail = editButtonDetail;

            return passdownActionItemsDetail;
        }
    }
}


