﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
   public class Building
    {
        public int BuildingID { get; set; }
        public string BuildingName { get; set; }
    }
}
