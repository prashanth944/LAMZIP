﻿namespace LAM.PMPM.Model
{
    public class RTSStatusUpdate
    {
        public string Status { get; set; }
        public string Id { get; set; }
    }
}