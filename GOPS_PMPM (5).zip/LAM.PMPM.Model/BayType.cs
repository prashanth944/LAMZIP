﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
   public class BayType
    {
        public int BayTypeID { get; set; }
        public string BayTypeName { get; set; }
    }
}
