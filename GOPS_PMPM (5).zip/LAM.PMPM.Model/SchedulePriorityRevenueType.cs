﻿
namespace LAM.PMPM.Model
{
   public class SchedulePriorityRevenueType
    {
        public int SchedulePriorityRevenueTypeID { get; set; }
        public string RevenueType { get; set; }
        public int RevenueTypeID { get; set; }
    }
}
