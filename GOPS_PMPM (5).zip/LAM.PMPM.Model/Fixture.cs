﻿using System.ComponentModel.DataAnnotations;

namespace LAM.PMPM.Model
{
   public  class Fixture
    {
        public int FixtureID { get; set; }
        [Required(ErrorMessage ="Please enter Fixture Name")]
        public string FixtureName { get; set; }
        [Required(ErrorMessage = "Please enter Code")]
        public string Code { get; set; }
        public string AssetTagNo { get; set; }
    }
}
