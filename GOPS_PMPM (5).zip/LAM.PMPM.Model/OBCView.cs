﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model
{
   public class OBCView
    {
        public string Status { get; set; }
        public string ID { get; set; }
        public decimal PartCost { get; set; }
        public string MaterialDescription { get; set; }
        public string LineItemNumber { get; set; }
        public string Operation { get; set; }
        public decimal RequiredQty { get; set; }
        public decimal WithdrawnQty { get; set; }
        public decimal Variance { get; set; }
        public bool? ScrapVal { get; set; }
        public string LongText { get; set; }
        public DateTime? CompletionDate { get; set; }
        public string VarianceType { get; set; }
        public string Type { get; set; }
        public int? RecID { get; set; }

        public string PartNumber { get; set; }
        public string CompletionText { get; set; }
    }

    public class OBCDetails 
    
    { 
     public List<OBCView> OBCADD { get; set; }
      public List<OBCView> OBCRTS { get; set; }

    }

}
