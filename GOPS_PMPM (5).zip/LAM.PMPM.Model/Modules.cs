﻿

using System;

namespace LAM.PMPM.Model
{
    public class Modules
    {

        public int? ToolTypeID { get; set; }

        public int? ProductGroupID { get; set; }
        public string ProductGroupName { get; set; }
        public int? BuildStyleId { get; set; }
        public int? BuildScheduleId { get; set; }
        public int? BuildingID { get; set; }
        public string FCID { get; set; }
        public string PilotSerialNumber { get; set; }
        public int? BuildTypeID { get; set; }
        public int? BaysRequiredSubassembly { get; set; }
        public string CurrentPartNumber { get; set; }
        public decimal? TotalAssemblyHours { get; set; }
        public int? BaysRequiredIntegration { get; set; }
        public decimal? TotalIntegrationHours { get; set; }
        public int? BaysRequiredForTest { get; set; }
        public decimal? TotalTestHours { get; set; }
        public int? BaysRequiredPostTest { get; set; }
        public decimal? TotalPostTestHours { get; set; }
        public string CapacityPlanningColor { get; set; }
        public string ReworkPO { get; set; }
        public string NewPartNumber { get; set; }
        public string BEN { get; set; }

        public int? TechnicianRequiredSubassembly { get; set; }
        public int? TechnicianRequiredIntegration { get; set; }
        public int? TechnicianRequiredTest { get; set; }
        public int? TechnicianRequiredPostTest { get; set; }

        public DateTime? CommitLaunch { get; set; }
        public string POM { get; set; }
        public string AssociatedBEN { get; set; }
        public string ModuleProcessSubassembly { get; set; }
        public string ModuleProcessIntegration { get; set; }
        public string ModuleProcessTest { get; set; }
        public string ModuleProcessPostTest { get; set; }
        public string RecordType { get; set; }
        public string RevenueType { get; set; }
        public long? PlantID { get; set; }
        public DateTime? CRD { get; set; }
        public DateTime? POR { get; set; }
        public string AddPO { get; set; }
        public string DeletePO { get; set; }
        public string BENorPSNReconfiguredFrom { get; set; }
        public long? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }

        public string AssociatedPSN { get; set; }

        public DateTime? TSD { get; set; }
        public DateTime? SRD { get; set; }
        public DateTime? MCSD { get; set; }

        public string LPRID { get; set; }

        public string ProductionOrderNum { get; set; }


    }
}

