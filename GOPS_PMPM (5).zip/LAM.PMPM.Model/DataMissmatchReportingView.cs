﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model
{
   public class POMDataMissmatchReportingView
    {
       // public long? PilotProductID { get; set; }
        public string FCID { get; set; }
        public string BEN { get; set; }
        public string POM { get; set; }
        public string BuildingName { get; set; }
       
    }
    public class DateDataMissmatchReportingView
    {
      //  public long? PilotProductID { get; set; }
        public string FCID { get; set; }
        public string BEN { get; set; }
        public string PSN { get; set; }
        public DateTime? SAPLaunchDate { get; set; }
        public DateTime? PilotLaunchDate { get; set; }
        public DateTime? SAPMCSD { get; set; }
        public DateTime? PilotMCSD { get; set; }

    }
    public class DateOperationMissmatchReportingView
    {
        //  public long? PilotProductID { get; set; }
        public string ProductName { get; set; }
        public long? operationID { get; set; }
        public string OperationName { get; set; }
        public decimal? StandardTimeHours { get; set; }
        public decimal? AvgActualCycleTime { get; set; }
        public decimal? OveraOrUnderSDTime { get; set; }
        public string OperationNumber { get; set; }

    }
}
