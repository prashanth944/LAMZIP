﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model
{
   public class RDBrwoseView
    {
     
        public int? PlantID { get; set; }
        public string ReportName { get; set; }
        public string Hyperlink { get; set; }
        public string Description { get; set; }
        public long ReportType { get; set; }
        public int? ReportID { get; set; }

        public string ReportTypeName { get; set; }
    }
}
