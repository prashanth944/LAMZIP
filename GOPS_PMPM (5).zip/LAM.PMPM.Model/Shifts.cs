﻿using System;
using System.ComponentModel.DataAnnotations;


namespace LAM.PMPM.Model
{
    public class Shifts
    {
        public long? ShiftID { get; set; }
       // [Required(ErrorMessage = "Please enter Shift ID")]
        public string ShiftName { get; set; }
        // [Required(ErrorMessage = "Please enter Shift Type Name")]
        public int PlantID { get; set; }
        public int HoursPerDay { get; set; }
        public string Description { get; set; }
        public string ShortDescription { get; set; }
        public string Compression { get; set; }
        public string ShiftStartTime { get; set; }
        public string ShiftEndTime { get; set; }
        public string DayShiftType { get; set; }
        public string Time { get; set; }
        public int? Monday1 { get; set; }
        public int? Tuesday1 { get; set; }
        public int? Wednesday1 { get; set; }
        public int? Thursday1 { get; set; }
        public int? Friday1 { get; set; }
        public int? Saturday1 { get; set; }

        public int? Sunday1 { get; set; }

        public int? Monday2 { get; set; }
        public int? Tuesday2 { get; set; }
        public int? Wednesday2 { get; set; }
        public int? Thursday2 { get; set; }
        public int? Friday2 { get; set; }
        public int? Saturday2 { get; set; }
        public int? Sunday2 { get; set; }

        public int? Weeknum { get; set; }
        
    }
}
