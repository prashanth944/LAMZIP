﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model
{
   public class ScheduleModuleProcess
    {
        public int ModuleProcessID { get; set; }
        public string ModuleProcess { get; set; }
    }
}
