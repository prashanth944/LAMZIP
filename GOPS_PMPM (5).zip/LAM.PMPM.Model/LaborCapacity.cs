﻿using System;


namespace LAM.PMPM.Model
{
    public class LaborCapacity
    {
        public int LaborCapacityID { get; set; }
        public int LaborTypeID { get; set; }
        public int ShiftID { get; set; }
        public int TotalAvailableHours { get; set; }
        public int TotalAvailableOvertimeHours { get; set; }
        public DateTime LaborDate { get; set; }
        public char DayShiftOnly { get; set; }
        public char Assembly { get; set; }
        public char Test { get; set; }
        
    }
}
