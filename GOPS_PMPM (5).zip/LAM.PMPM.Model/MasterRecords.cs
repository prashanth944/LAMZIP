﻿using System;
using System.ComponentModel.DataAnnotations;


namespace LAM.PMPM.Model
{
  public   class MasterRecords
    {
        public long MasterRecordID { get; set; }
        [Required(ErrorMessage = "Please enter Name")] 
        public string MasterRecordName { get; set; }
        [Required(ErrorMessage = "Please enter Type")]
        public string Type { get; set; }
        public DateTime Created_Date { get; set; }
        public string Created_By { get; set; }

        public string Value { get; set; }
    }
}
