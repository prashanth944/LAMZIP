﻿

using System;

namespace LAM.PMPM.Model
{
    public class ScheduleCapacity
    {
        public DateTime? MinEarliestStartDate { get; set; }
        public DateTime? MaxProjectedDate { get; set; }
    }


}
