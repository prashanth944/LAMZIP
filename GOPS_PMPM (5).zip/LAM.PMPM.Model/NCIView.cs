﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model
{
   public class NCIView
    {
        public string Status { get; set; }
        public DateTime DateOpened { get; set; }
        public string Requestor { get; set; }
        public string Title { get; set; }
        public string PartNumber { get; set; }
        public string Impact { get; set; }
        public string POM { get; set; }
        public string POMDescripton { get; set; }
        public string Symptom { get; set; }
        public string SymptomDetail { get; set; }
        public int? ID { get; set; }
        public string ISClosed { get; set; }
        public int? RecID { get; set; }
        public string PartDescription { get; set; }
        public decimal Quantity { get; set; }
        public string reasonCode { get; set; }

        public string PurchOrd { get; set; }

        public DateTime CreDate { get; set; }
        public string LineDown { get; set; }
        public string InvestigationGroup { get; set; }
        public string InvestigationGroupDetail { get; set; }
        public string Resolution { get; set; }

        public string TechnicianNotes { get; set; }
        public string AddorRemoved { get; set; }
        public string MTTNo { get; set; }



    }
}
