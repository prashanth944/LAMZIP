﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model
{
    public class ModuleOnProductionPlan
    {
        public int ModuleOnProductionPlanID { get; set; }
        public long PilotProductID { get; set; }
        public long ProductionPlanID { get; set; }
    }
}
