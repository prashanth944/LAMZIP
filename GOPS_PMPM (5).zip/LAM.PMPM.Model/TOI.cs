﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace LAM.PMPM.Model
{
  public  class TOI
    {
        public long? TOIID { get; set; }
        public long PilotProductID { get; set; }
        public string BEN { get; set; }
        [Required(ErrorMessage = "Please Enter Title")]
        public string Title { get; set; }
        public string IssueDescription { get; set; }
        public int StatusID { get; set; }
        public string Status { get; set; }
        //public string CriticalOrGating { get; set; }
        public bool IsCritical { get; set; }
        public bool IsGating { get; set; }
        public string Comments { get; set; }
        public List<string> Files { get; set; }
        public DateTime? ExpectedCloseDate { get; set; }
        public DateTime? GatingDate { get; set; }
        public long? ZoneID { get; set; }
        public string ZoneName { get; set; }
        public string PilotSerialNumber { get; set; }
        public DateTime? CreatedOnDate { get; set; }
        public DateTime? UpdatedOnDate { get; set; }
        public  string CriticalGating { get; set; }
        public long? CreatedById { get; set; }
        public long? UpdatedById { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
    }
}
