﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
   public class ProductType
    {
        public int ProductGroupID { get; set; }
        public string ProductName { get; set; }
    }
}
