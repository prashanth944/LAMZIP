﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model
{
    public class TimeAndColorViewModel
    {
        public string ScheduleTimePeriod { get; set; } = null;
        public string ScheduleColorView { get; set; } = null;
    }
}
