﻿using System.ComponentModel.DataAnnotations;

namespace LAM.PMPM.Model
{
   public class BuildType
    {
        public long BuildTypeID { get; set; }
        [Required(ErrorMessage = "Please enter Build Type Name")]
        public string BuildTypeName { get; set; }
        [Required(ErrorMessage = "Please enter Labor Multiplier")]
        public string LaborMultiplier { get; set; }
        public decimal? MultiplierValue { get; set; }
    }
}
