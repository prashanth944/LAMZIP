﻿
namespace LAM.PMPM.Model
{
    public class SchedulePriorityRecordType
    {
        public int SchedulePriorityRecordTypeID { get; set; }
        public string RecordType { get; set; }
        public int RecordTypeID { get; set; }
    }
}
