﻿

namespace LAM.PMPM.Model
{
    public class SchedulePriority
    {
        public int SchedulePriorityID { get; set; }
        public string Priorities { get; set; }
    }
}
