﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model
{
    public class IssueLogView
    {   
        public string Status { get; set; }
        public int? RecID { get; set; }
        public string IssueLog { get; set; }
        public DateTime? DateCreated { get; set; }
        public string Urgency { get; set; }
        public string IssueType { get; set; }
        public string IssueTitle{ get; set; }
        public string Part { get; set; }
        public string IssueDetail { get; set; }
        public string IssueDisposition { get; set; }
        public string StatusforCount { get; set; }
        public int? Count { get; set; }
        public long? DivisionID { get; set; }
        public string DivisionName { get; set; }
    }
}
