﻿using System.ComponentModel.DataAnnotations;


namespace LAM.PMPM.Model
{
    public class ToolType
    {
        public int ToolTypeID { get; set; }
        [Required(ErrorMessage = "Please enter Tool Type Name")]
        public string ToolTypeName { get; set; }
    }
}
