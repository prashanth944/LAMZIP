﻿using System;
namespace LAM.PMPM.Model
{
    public class LaborManagementGroup
    {
        public LaborManagementGroup()
        {
            EfficencyFactor = 0;
            OvertimeAllowance = 0;
            UtilizationTarget = 0;
            PTOPercentage = 0;
        }
        public long LaborManagmentGroupID { get; set; }
        public string ManagementName { get; set; }
        public decimal? EfficencyFactor { get; set; }
        public decimal? OvertimeAllowance { get; set; }
        public decimal? UtilizationTarget { get; set; }
        public decimal? PTOPercentage { get; set; }
        public int PlantID { get; set; }
        public DateTime? CreatedOn { get; set; }
    }
}
