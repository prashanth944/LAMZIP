﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model
{
   public class ShortagesView
    {
       
        public string PartNumber { get; set; }
        public string Description { get; set; }
        public decimal? Qty { get; set; }
        public string Supplies { get; set; }
        public DateTime? DueDate { get; set; }
        public DateTime? NeedDate { get; set; }
        public string OP { get; set; }
      
    }
}
