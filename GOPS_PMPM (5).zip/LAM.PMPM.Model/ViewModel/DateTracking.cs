﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
    public class DateTracking
    {
        public long? PilotProductID { get; set; }
        public string FCID { get; set; }
        public string BEN { get; set; }
        public string PilotSerialNumber { get; set; }
        public string DateName { get; set; }
        public string Status { get; set; }
        public DateTime? PriorDate { get; set; }
        public DateTime? NewDate { get; set; }
        public int? DifferenceInDays { get; set; }
        public DateTime? LastUpdated { get; set; }
        public long? UpdatedByID { get; set; }
        public string UpdatedBy { get; set; }
    }
}
