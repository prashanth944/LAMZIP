﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
   public class MPSSummary
    {
        public int DescriptionCount { get; set; }
        public string Description { get; set; }
        public DateTime? DailyDate { get; set; }
        public string? WeekStart { get; set; }

        public string? Monthly { get; set; }
        public string? Quarterly { get; set; }
        public string? Annualy { get; set; }
    }
}
