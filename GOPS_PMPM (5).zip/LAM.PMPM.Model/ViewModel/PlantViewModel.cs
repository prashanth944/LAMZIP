namespace LAM.PMPM.Model.ViewModel
{
    public class PlantViewModel
    {
        public int? PlantId {get; set;}
        public string PlantName{get; set; }
        public string Code {get; set; }
    }
}