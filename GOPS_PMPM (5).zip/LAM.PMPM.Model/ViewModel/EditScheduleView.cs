﻿using System;

namespace LAM.PMPM.Model.ViewModel
{
   public class EditScheduleView
    {
        public int PilotProductID { get; set; }
        public bool NoCapacity { get; set; }
        public int TotalAssemblyHours { get; set; }
        public int TotalIntegrationHour { get; set; }
        public int TotalTestHour { get; set; }
        public int TotalPostTestHour { get; set; }
        public string Notes { get; set; }
        public DateTime ActualLaunch { get; set; }
        public DateTime ActualIntegrationStart { get; set; }
        public DateTime ActualTestStart { get; set; }
        public DateTime ActualManufacturingComplete { get; set; }
        public DateTime Earliestallowedlaunch { get; set; }
        public bool CrdEsc { get; set; }
        //public string MCSDRiskLevel { get; set; }
        public string PilotPriority { get; set; }

        public int CustomerID { get; set; }
        public Decimal CompleteATP { get; set; }
        public string SalesPriority { get; set; }
        public string ScheduleTimePeriod { get; set; }
        public int BuildTypeID { get; set; }
        public int ToolTypeID { get; set; }
        public string BuildName { get; set; }
        public string ToolTypeName { get; set; }

    }
}
