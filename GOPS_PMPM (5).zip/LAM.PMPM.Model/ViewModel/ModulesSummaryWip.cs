namespace LAM.PMPM.Model.ViewModel
{
    public class ModulesSummaryWip
    {
        public int pilotProductID { get; set; }
        public string pilotRisk { get; set; }
        public string comments { get; set; }
        public string status { get; set; }
        public string wipPriority { get; set; } = null;
        public bool? Staffed { get; set; }
        public string Shift { get; set; }
        public long? BuildingId { get; set; }
        public bool? CurrentDayShift { get; set; }
        public bool? LastDayShift { get; set; }
        public bool? CurrentNightShift { get; set; }
        public bool? LastNightShift { get; set; } 
    }
}