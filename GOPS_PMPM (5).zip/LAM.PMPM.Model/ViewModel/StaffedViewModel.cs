﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
    public class StaffedViewModel
    {
        public long? PilotProductID { get; set; }
        public bool Staffed { get; set; }
        public string Shift { get; set; }
    }
}
