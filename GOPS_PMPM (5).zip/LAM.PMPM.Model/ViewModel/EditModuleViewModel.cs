﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
    public class EditModuleViewModel
    {
        public string BEN { get; set; }
        public string MPSName { get; set; }
        public string ToolTypeName { get; set; }
        public string PilotToolType { get; set; }
        public string RecordType { get; set; }
        public string RevenueCode { get; set; }
        public string CapacityPlanningColor { get; set; }

        [Required]
        public long? PilotProductID { get; set; }
        public long? ToolTypeID { get; set; }
        public long? BuildTypeID { get; set; }
        public int? BuildStyleId { get; set; }
        public string BuildStyle { get; set; }
        public string PilotSerialNumber { get; set; }
        public string FCID { get; set; }
        public string PilotRiskLevel { get; set; }
        public string BuildTypeName { get; set; }
        public string ProductionStatus { get; set; }
        public long? ProductGroupId { get; set; }
        public string ProductName { get; set; }
        public string Customer { get; set; }
        public string ProductManager { get; set; }
        public string ProgramManager { get; set; }
        public string SystemProjectManager { get; set; }
        public string ManufacturingEngineer { get; set; }
        public string TestEngineer { get; set; }
        public string Note { get; set; }
        public string Scheduler { get; set; }
        public string PurchaseOrderNumber { get; set; }
        public string SalesOrderNumber { get; set; }
        public string BOMNumber { get; set; }
        public string Status { get; set; }
        public long? FremontID { get; set; }
        public DateTime? TestDate { get; set; }
        public bool? InWIP { get; set; }
        public string PO { get; set; }
        public long? DivisionID { get; set; }
        public string DivisionName { get; set; }


        //For Special Subassembly
        public string PartNumber { get; set; }
        public string SerialNum { get; set; }
        public int? Qty { get; set; }
        public long? DemandTypeID { get; set; }
        public string partDescription { get; set; }

        public bool? PCWOReleased { get; set; }
        public bool? hot { get; set; }
        public bool? Rework { get; set; }
        public bool? SpclProcess { get; set; }
        public string PlannerName { get; set; }
        public string EngineeringPOC { get; set; }
        public string TechBuild { get; set; }
        public string TechTest { get; set; }
        public string Auditor { get; set; }
        public string BENorPSNReconfiguredFrom { get; set; }
        public int? ProcessModule { get; set; }
        public long? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
    }
    //public class ReconfigEdit
    //{
    //    public List<ReconfigEditFields> ReconfigEditFields { get; set; }
    //}
    public class ReconfigEditFields
    {
        public string AddOrRTSProdOrder { get; set; }
        public string PartNumber { get; set; }
        public int? QtyAddedReturned { get; set; }
        public int? Status { get; set; }
        public string TechnicianComments { get; set; }

    }

    public class Reconfig
    {
        public string PartNumber { get; set; }
        public string Description { get; set; }
        public decimal? Qty { get; set; }
        public int? QtyAdded { get; set; }
        public string TechnicianComments { get; set; }
        public string Status { get; set; }
        public string AddOrRTSProdOrder { get; set; }
    }

    public class ReconfigData
    {
        public List<Reconfig> Reconfig { get; set; }
        public int? ProdOrderCount { get; set; }
    }
}
