﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace LAM.PMPM.Model.ViewModel
{
    public class EditModScheduleViewModel
    {
        public long? PilotProductID { get; set; }
        public DateTime? CommitLaunch { get; set; }
        public DateTime? CommittedIntegrationStart { get; set; }
        public DateTime? CommittedTestStart { get; set; }
        public DateTime? CommittedTestComplete { get; set; }
        public DateTime? PilotManufacturingCommitedShipDate { get; set; }
        public DateTime? PlannedLaunch { get; set; }
        public DateTime? PlannedManufacturingComplete { get; set; }
        public DateTime? PlannedIntegrationStart { get; set; }
        public DateTime? PlannedTestStart { get; set; }
        public DateTime? PlannedTestComplete { get; set; }
        public DateTime? PlannedCrateComplete { get; set; }

        public DateTime? ActualLaunch { get; set; }
        public DateTime? ActualIntegrationStart { get; set; }
        public DateTime? ActualIntegrationStartManual { get; set; }
        public bool ActualIntegrationStartIsManual { get; set; }
        public DateTime? ActualTestStart { get; set; }
        public DateTime? ActualTestStartManual { get; set; }
        public bool ActualTestStartIsManual { get; set; }
        public DateTime? ActualTestComplete { get; set; }
        public DateTime? ActualTestCompleteManual { get; set; }
        public bool ActualTestCompleteIsManual { get; set; }
        public DateTime? ActualManufacturingComplete { get; set; }
        public DateTime? ActualManufacturingCompleteManual { get; set; }
        public bool ActualManufacturingCompleteIsManual { get; set; }
        public DateTime? ActualCrateComplete { get; set; }
        public DateTime? TargetShipDateCommited { get; set; }
        public DateTime? MCSDCommited { get; set; }
        public DateTime? CRDCommited { get; set; }
        public DateTime? EarliestStartDate { get; set; }
        public int? TargetTestDays { get; set; }
        public int? IdleTestDay { get; set; }
        public int? PostTestDays { get; set; }
        public int? LaunchGapDays { get; set; }
        public int? IntegrationGapDays { get; set; }
        public int? TestStartGapDays { get; set; }
        public int? TestCompleteGapDays { get; set; }
        public int? PilotCompleteGapDays { get; set; }
        public int? CrateCompleteGapDays { get; set; }
        public DateTime? ManufacturingCommitedShipDate { get; set; }
        public DateTime? ProjectedManufacturingComplete { get; set; }
        public DateTime? TargetShipDate { get; set; }
        public DateTime? CustomerRequestDate { get; set; }
        public bool? InWIP { get; set; }
        public bool? NoCapacity { get; set; }
        public long? BuildScheduleId { get; set; }
        public string BuildScheduleName { get; set; }
        public string ProductionStatus { get; set; } = null;
        public DateTime? ProjectedLaunch { get; set; }
        public DateTime? ProjectedIntegrationStart { get; set; }
        public DateTime? ProjectedTestStart { get; set; }
        public DateTime? ProjectedTestComplete { get; set; }
        public DateTime? ProjectedCrateComplete { get; set; }
        public string LaunchMissCategory { get; set; } = null;
        public long? LaunchMissCategoryId { get; set; } = null;
        public string LaunchMissReason { get; set; } = null;
        public long? IntegrationMissCategoryId { get; set; } = null;
        public string IntegrationMissCategory { get; set; } = null;
        public string IntegrationMissReason { get; set; } = null;
        public long? TeststartMissCategoryId { get; set; } = null;
        public string TeststartMissCategory { get; set; } = null;
        public string TeststartMissReason { get; set; } = null;
        public long? TestCompleteMissCategoryId { get; set; } = null;
        public string TestCompleteMissCategory { get; set; } = null;
        public string TestCompleteMissReason { get; set; } = null;
        public string MfgCompleteMissCategory { get; set; } = null;
        public long? MfgCompleteMissCategoryId { get; set; } = null;
        public string MfgCompleteMissReason { get; set; } = null;
        public DateTime? TestDate { get; set; }
        public DateTime? CommitedManufacturingComplete { get; set; }
        public long? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
    }
}