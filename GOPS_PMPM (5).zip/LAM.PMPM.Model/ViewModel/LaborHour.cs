﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
    public class LaborHour
    {
        public long? LaborHourId { get; set; }
        public long? UserId { get; set; }
        public DateTime? LaborHourDate { get; set; }
        public DateTime? CreatedOn { get; set; }
        public long? CreatedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public long? ModifiedBy { get; set; }
        public DateTime? CurrentDate { get; set; }
        public long? LaborHourTypeId { get; set; }
        public long? LaborHourLoanToId { get; set; }
        public string BEN { get; set; }
        public string PSN { get; set; }
        public long? PlantId { get; set; }
    }

    public class LaborHourReworks
    {
        public string Phase { get; set; }
        public bool? BOMChange { get; set; }
        public string PilotOrSupplierCaused { get; set; }
        public long? ReworkCategoryId { get; set; }
        public string ReworkCategory { get; set; }
        public decimal? LaborHourValue { get; set; }
    }

    public class LaborHourValues : LaborHourReworks
    {
        public long? LaborHourValuesId { get; set; }
        public long? LaborHourId { get; set; }
        public int? LaborTypeId { get; set; }
        public long? LaborHourItemTypeId { get; set; }
        public long? SpecialSubAssemblyPilotProductId { get; set; }
        public bool? IsRework { get; set; }   
    }

    public class LaborHourModuleMapping
    {
        public long? LaborHourModuleMappingId { get; set; }
        public long? LaborHourId { get; set; }
        public long? PilotProductId { get; set; }
        public bool? IsSpecialSubAssembly { get; set; }
    }

    public class LaborHourAddDetails : LaborHour
    {
        public List<LaborHourValues> LaborHourValues { get; set; }
        public List<LaborHourModuleMapping> LaborHourModuleMappings { get; set; }
    }

    public class LaborHourTechWorkLog
    {
        public string BEN { get; set; }
        public string PilotSerialNumber { get; set; }
        public string OperationName { get; set; }
        public bool? IsRework { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public decimal? InterruptionHours { get; set; }
        public decimal? TotalHours { get; set; }

        public string Notes { get; set; }
        public string InterruptionCategory { get; set; }

        public string buildStyle { get; set; }
    }

    public class LaborHourTechDashBoard 
    {       
        public decimal? Working { get; set; }
        public decimal? Recorded { get; set; }
        public decimal? Direct { get; set; }
        public decimal? Interrupts { get; set; }
        public decimal? BreaksOrLunch { get; set; }
        public decimal? Rework { get; set; }
        public decimal? Total { get; set; }
        public bool? IsVerify { get; set; }
        public bool? IsSwitched { get; set; }
        public List<LaborHourTechDashBoardBENDetails> LaborTechBENDetails { get; set; } = new List<LaborHourTechDashBoardBENDetails>();
    }

    public class LaborHourTechDashBoardBENDetails
    {
        public long? PilotProductID { get; set; }
        public string BEN { get; set; }
        public string pilotSerialNumber { get; set; }

        public string buildStyle { get; set; }


    }

    public class LaborHourSupDashboardView
    {
        public long? LaborHourVerificationId { get; set; }
        public string UserName { get; set; }
        public decimal? WorkingHours { get; set; }
        public decimal? FinanceHours { get; set; }
        public decimal? Utilization { get; set; }
        public decimal? DirectCT { get; set; }
        public decimal? Interrupts { get; set; }
        public decimal? BreakLunchInterrupt { get; set; }
        public decimal? TotalReworkHours { get; set; }
        public decimal? Total { get; set; }
        public string Notes { get; set; }
        public string CalendarEvent { get; set; }
        public string CalendarEventStatus { get; set; }
        public long? UserId { get; set; }
        public string RowColor { get; set; }
        public string ShiftDescription { get; set; }
    }

    public class LaborHourManagerSummary : LaborHourSupDashboardView
    {
        public DateTime? LaborHourDate { get; set; }
        public TimeSpan? ShiftStartTime { get; set; }
        public decimal? RecordedHours { get; set; }
        public string ShiftShortDescription { get; set; }
        public string LamHoliday { get; set; }
    }

    public class LaborHourManagerDetails
    {
        public int? LamId { get; set; }
        public long? UserId { get; set; }
        public string Name { get; set; }
        public int? VerifiedApprovedCount { get; set; }
        public int? TotalCount { get; set; }
        public int? Percentage { get; set; }
        public List<LaborHourManagerSummary> LaborHourManagerSummary { get; set; }
    }

    public class LaborHourSubmitted
    {
        public long? LaborHourId { get; set; }
        public DateTime? LaborHourDate { get; set; }
        public decimal? TotalLaborHours { get; set; }
        public string BENorPSN { get; set; }
        public bool? IsEditable { get; set; }
    }

    public class LaborHourDashboard
    {
        public long? UserId { get; set; }
        public decimal? WorkingHours { get; set; }
        public decimal? RecordedHours { get; set; }
        public bool? IsVerified { get; set; }
    }

    public class LaborHourNotesViewModel
    {
        public long? LaborHourVerificationId { get; set; }
        public long? UserId { get; set; }
        public DateTime? CurrentDate { get; set; }
        public string Notes { get; set; }
    }

    public class LaborHourManagerData
    {
      
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public List<LaborHourManagerDataDetails> LaborHourManagerDataDetails { get; set; } = new List<LaborHourManagerDataDetails>();
    }
    public class LaborHourManagerDataDetails
    {
        public string Name { get; set; }
        public int? Percentage { get; set; }
        public int? LamId { get; set; }
        public long? UserId { get; set; }
    }

    public class LaborHourEditViewModel
    {
        public long? UserId { get; set; }
        public DateTime? LaborHourDate { get; set; }
        public string UserName { get; set; }
        public long? LaborHourId { get; set; }
        public int? LaborTypeId { get; set; }
        public long? LaborHourItemTypeId { get; set; }
        public decimal? LaborHourValue { get; set; }
        public long? SpecialSubAssemblyPilotProductId { get; set; }
        public bool? IsSpecialSubAssembly { get; set; }
        public bool? IsSingleModule { get; set; }
        public bool? IsMultiSelectModule { get; set; }
        public long? LaborHourTypeId { get; set; }        
        public long? PilotProductId { get; set; }
        public long? LaborHourValuesId { get; set; }
        public string WOPO { get; set; }
        public string BENorPSN { get; set; }
        public long? LaborHourLoanToId { get; set; }
        public string BENTextEntered { get; set; }
        public string PSNTextEntered { get; set; }
        public long? PlantId { get; set; }
        public bool? IsRework { get; set; }
        public bool? BOMChange { get; set; }
        public string PilotOrSupplierCaused { get; set; }
        public long? ReworkCategoryId { get; set; }
        public string ReworkCategory { get; set; }
        public string LaborTypeName { get; set; }
    }

    public class LaborHourEditUserDetail
    {
        public long? UserId { get; set; }   
        public string UserName { get; set; }
        public DateTime? LaborHourDate { get; set; }
        public long? LaborHourLoanToId { get; set; }
        public long? LaborHourTypeId { get; set; }
        public string BEN { get; set; }
        public string PSN { get; set; }
        public long? PlantId { get; set; }
    }

    public class LaborHourPilotProductIdEdit
    {
        public long? PilotProductId { get; set; }
        public string BENorPSN { get; set; }
    }

    public class LaborHourSpecialSubAssemblyPilotProductIdEdit
    {
        public long? SpecialSubAssemblyPilotProductId { get; set; }
        public string WOPO { get; set; }
    }

    public class LaborHourValueEdit : LaborHourValues
    {
        public string WOPO { get; set; }
    }

    public class LaborHourEditDisplayModel
    {
        public bool? IsSingleModule { get; set; }
        public bool? IsMultiSelectModule { get; set; }
        public bool? IsSpecialSubAssembly { get; set; }
        public LaborHourEditUserDetail LaborHourEditUserDetail { get; set; }
        public List<LaborHourPilotProductIdEdit> PilotProductId { get; set; }
        public List<LaborHourSpecialSubAssemblyPilotProductIdEdit> SpecialSubAssemblyPilotProductId { get; set; }
        public List<LaborHourValueEdit> LaborHourValueEdits { get; set; }
        public List<LaborHourReworks> LaborHourReworks { get; set; }
    }

    public class CycleTimeViewModel
    {
        public string WorkType { get; set; }
        public long? WorkRecordID { get; set; }
        public long? WorkRecordInterruptionId { get; set; }
        public long? PilotProductID { get; set; }
        public string BEN { get; set; }
        public string PilotSerialNumber { get; set; }
        public long? OperationID { get; set; }
        public string OPDescription { get; set; }
        public DateTime? StartTimestamp { get; set; }
        public DateTime? EndTimestamp { get; set; }
        public decimal? RecordedTime { get; set; }
        public decimal? ModifiedTime { get; set; }
        public bool? IsModified { get; set; }
    }

    public class CycleTimeUpdateViewModel
    {
        public long? WorkRecordId { get; set; }
        public long? WorkRecordInterruptionId { get; set; }
        public int? EndMinutes { get; set; }
    }
}
