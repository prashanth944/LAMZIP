﻿using System;
using System.Collections.Generic;
using System.Text;



namespace LAM.PMPM.Model.ViewModel
{
    public class ModuleSearch
    {
        public long? URBPID { get; set; }
        public long? PilotProductID { get; set; }
        public string FCID { get; set; }
        public string PilotSerialNumber { get; set; }
        public string ProductType { get; set; }
        public string ToolType { get; set; }
        public string RecordType { get; set; }
        public string RevenueType { get; set; }
        public string BuildName { get; set; }
        public string Customer { get; set; }
        public int? BuildTypeID { get; set; }
        public string BEN { get; set; }
        public string OnPOR { get; set; }
        public DateTime? PlanofRecord { get; set; }
        public DateTime? CustomerRequestDate { get; set; }
        public DateTime? ActualManufacturingComplete { get; set; }
        public long? ScheduleStatusId { get; set; }
        public string ScheduleStatus { get; set; }
    }
}