﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
    public class EditModuleViewModelStandard
    {
        public int? BuildStyleId { get; set; }
        public string BuildStyle { get; set; }
        public string PilotRiskLevel { get; set; }
        public long? BuildTypeID { get; set; }
        public string BuildTypeName { get; set; }
        public long? ProductGroupId { get; set; }
        public string ProductName { get; set; }
        public string Customer { get; set; }
        public string RecordType { get; set; }
    }
}
