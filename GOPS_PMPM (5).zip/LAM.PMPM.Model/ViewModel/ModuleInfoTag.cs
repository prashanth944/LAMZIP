﻿using System;

namespace LAM.PMPM.Model.ViewModel
{
    public class ModuleInfoTag
    {
        public string PurchaseOrderNumber { get; set; }
        public string SalesOrder { get; set; }
        public string BEN { get; set; }
        public string SalesOrderNumber { get; set; }
        public int? ProcessModule { get; set; }
        public string PilotSerialNumber { get; set; }
        public string ToolTypeName { get; set; }
        public string CapacityPlanningColor { get; set; }
        public DateTime? PlannedLaunch { get; set; }
        public DateTime? PlannedIntegrationStart { get; set; }
        public DateTime? PlannedTestStart { get; set; }
        public DateTime? PlannedTestComplete { get; set; }
        public DateTime? PlannedManufacturingComplete { get; set; }
        public DateTime? PlannedCrateComplete { get; set; }
        public DateTime? ActualLaunch { get; set; }
        public string FCID { get; set; }
        public DateTime? ActualIntegrationStart { get; set; }
        public DateTime? ActualIntegrationStartManual { get; set; }
        public bool ActualIntegrationStartIsManual { get; set; }
        public DateTime? ActualTestStart { get; set; }
        public DateTime? ActualTestStartManual { get; set; }
        public bool ActualTestStartIsManual { get; set; }
        public DateTime? ActualTestComplete { get; set; }
        public DateTime? ActualTestCompleteManual { get; set; }
        public bool ActualTestCompleteIsManual { get; set; }
        public DateTime? ActualManufacturingComplete { get; set; }
        public DateTime? ActualManufacturingCompleteManual { get; set; }
        public bool ActualManufacturingCompleteIsManual { get; set; }
        public DateTime? ActualCrateComplete { get; set; }
        public int? TargetTestDays { get; set; }
        public int? IdleTestDay { get; set; }
        public int? PostTestDays { get; set; }

    }
}