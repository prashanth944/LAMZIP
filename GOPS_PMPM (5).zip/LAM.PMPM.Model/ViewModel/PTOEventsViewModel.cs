﻿using System;
using System.ComponentModel.DataAnnotations;
namespace LAM.PMPM.Model.ViewModel
{
    public class PTOEventsViewModel
    {
        public int? employeeDataID{get; set; }
        public int? id{get; set; }
        public int? plantId{get; set; }
        public string groupName{get; set; }
        public string typeName{get; set; }
        public Boolean covidRelated{get; set; }
        public DateTime? StartDate{get; set; }
        public DateTime? EndDate{get; set; }
        public string comments {get; set; }
        public string statusLabel {get; set; }
        
        public string userEmail {get; set;}
    }
}