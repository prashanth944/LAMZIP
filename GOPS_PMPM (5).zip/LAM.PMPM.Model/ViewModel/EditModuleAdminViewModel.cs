﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
   public class EditModuleAdminViewModel
    {
        public long? PilotProductID { get; set; }
        public string PilotSerialNumber { get; set; }
        public bool? BuildPlanPacketLoaded { get; set; }
        
        public string Code { get; set; }
        public string POM { get; set; }
        public bool? ChamberReleased { get; set; }
        public bool? SubFrameReleased { get; set; }
        public bool? EnclosureReleased { get; set; }
        public bool? TopPlateReleased { get; set; }
        public string Status { get; set; }
        public string ProductionStatus { get; set; }
        public bool? InWip { get; set; }
    }
}
