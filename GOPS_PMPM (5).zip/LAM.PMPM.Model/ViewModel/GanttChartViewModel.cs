﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
   public class GanttChartViewModel
    {


       public  long? PilotProductID { get; set; }
       public  string FCID { get; set; }
       public string PilotSerialNumber { get; set; }
        public string BEN { get; set; }
        public long? FremontID { get; set; }
        public long? LPRID { get; set; }
        public string ProductionStatus { get; set; }
        public string PilotToolType { get; set; }
        public string Customer { get; set; }
        public DateTime? PriorityDate { get; set; }
        public bool? NoCapacity { get; set; }
        public string RecordType { get; set; }
        public string RevenueCode { get; set; }

        public long? BuildTypeID { get; set; }
        public string BuildTypeName { get; set; }
        public string ToolTypeName { get; set; }
        public string ProductGroupName { get; set; }
        public long? ToolTypeID { get; set; }
        public long? ProductGroupID { get; set; }
        
        public long? Building { get; set; }

        public string SalesOrderNumber { get; set; }
        public string SalesOrder { get; set; }
        public int? BOMNumber { get; set; }

        public bool? DayShiftOnly { get; set; }

        public int? BuildStyleId { get; set; }
        public int? BuildScheduleId { get; set; }
        public string POM { get; set; }



        public bool? CRDEsc { get; set; }
        //public string MCSDRiskLevel { get; set; } = null;
        public string SalesPriority { get; set; } = null;
        public string PurchaseOrderNumber { get; set; } = null;
        public string PilotRisk { get; set; } = null;
        public string LPRPercComplete { get; set; } = null;
        //public bool? PilotEsc { get; set; }
        public bool? InWIP { get; set; }
        public string PlannedRiskLevel { get; set; } = null;

        public string Status { get; set; } = null;
        public long? PlantID { get; set; }



        public DateTime? ProjectedMRPP08 { get; set; }
        public DateTime? MRPP08 { get; set; }
        public DateTime? LPRPlannedLaunchP09 { get; set; }
        public DateTime? ProjectedLaunch { get; set; }
        public DateTime? CommitLaunch { get; set; }

        public DateTime? ActualLaunch { get; set; }

        public DateTime? ProjectedIntegrationStart { get; set; }
        public DateTime? ActualIntegrationStart { get; set; }
        public DateTime? ProjectedTestStart { get; set; }
        public DateTime? ActualTestStart { get; set; }
        public DateTime? ProjectedTestComplete { get; set; }
        public DateTime? ActualTestComplete { get; set; }
        public DateTime? ProjectedManufacturingComplete { get; set; }

        public DateTime? CommitedManufacturingComplete { get; set; }
        public DateTime? ActualManufacturingComplete { get; set; }
        public DateTime? ManufacturingCommitedShipDate { get; set; }
        public DateTime? ProjectedCrateComplete { get; set; }
        public DateTime? ActualCrateComplete { get; set; }
        public DateTime? TargetShipDate { get; set; }

        public DateTime? SalesOpsRequestDate { get; set; }
        public DateTime? CustomerRequestDate { get; set; }
        public DateTime? EarliestStartDate { get; set; }
        public DateTime? PlannedDMRF { get; set; }
        public DateTime? ActualDMRF { get; set; }
        public DateTime? IdleTestDay { get; set; }

        public DateTime? PilotManufacturingCommitedShipDate { get; set; }
        public DateTime? PlanofRecord { get; set; }
        public DateTime? PlannedShipDate { get; set; }

        public DateTime? ActualShipDate { get; set; }
        public DateTime? PlannedManufacturingComplete { get; set; }
        public DateTime? PlannedTestStart { get; set; }
        public DateTime? PlannedCrateComplete { get; set; }
        public DateTime? LPRPlannedPilotLaunchP47 { get; set; }
        public DateTime? CommittedTestComplete { get; set; }
        public DateTime? CommittedTestStart { get; set; }
        public DateTime? CommittedIntegrationStart { get; set; }
        public bool? AlreadyScheduled { get; set; }
        public long? ProductionPlanID { get; set; }

        public DateTime? PlannedIntegrationStart { get; set; }
        public DateTime? PlannedTestComplete { get; set; }

        public DateTime? MaterialReadiness { get; set; }

        public decimal? SubAssemblyHours { get; set; }
        public decimal? IntegrationHours { get; set; }
        public decimal? TestHours { get; set; }
        public decimal? PosttestHours { get; set; }

    }
}
