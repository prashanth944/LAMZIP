﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
   public class EditModuleAdminVFDAssignmentTable
    {
        public long? PilotProductID { get; set; }
        public long? VFDZoneID { get; set; }
       
        public string ZoneName { get; set; }
        public long? VFDStatusID { get; set; }
        public string Status { get; set; }
        public string BayName { get; set; }
        public bool? Assignable { get; set; }
        public string  IsAssignable { get; set; }
        public string CapacityPlanningColor { get; set; }


    }
}
