﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
    public class Passdown
    {
        public long? PassdownId { get; set; }
        public DateTime? PassdownDate { get; set; }
        public long? PilotProductId { get; set; }
        public long? ShiftId { get; set; }
        public long? CreatedById { get; set; }
        public DateTime? CreatedOn { get; set; }
        public long? ModifiedById { get; set; }
        public DateTime? ModifiedOn { get; set; }
    }

    public class PassdownListDetail : Passdown
    {
        public string BEN { get; set; }
        public string PilotSerialNumber { get; set; }
        public string ToolTypeName { get; set; }
        public string ProductName { get; set; }
        public string ShiftType { get; set; }
        public string CreatedBy { get; set; } 
        public bool? IsEditable { get; set; }
    }

    public class PassdownTabs
    {
        public long? ZoneId { get; set; }
        public string TabName { get; set; }
        public int? Orders { get; set; }
    }

    public interface IZOneModuleProcess
    {
        public long? ZoneId { get; set; }
        public string Zone { get; set; }
        public string ModuleProcess { get; set; }
    }

    public class OperationDetail
    {
        public long? OperationId { get; set; }
        public string Description { get; set; }
    }

    public class BuildStyleDetail
    {
        public int? BuildStyleId { get; set; }
        public string BuildStyle { get; set; }
    }
    public class EditButtonDetail
    {
        public bool? IsEditable { get; set; }
    }
    public class PassdownOperation : OperationDetail
    {
        public bool? IsComplete { get; set; }
    }

    public class PassdownOperationWithZone : PassdownOperation, IZOneModuleProcess
    {
        public long? ZoneId { get; set; }
        public string Zone { get; set; }
        public string ModuleProcess { get; set; }
    }

    public class PassdownOperationStep : OperationDetail
    {
        public int SkippedStepNumber { get; set; }
    }

    public class PassdownOperationStepWithZone : PassdownOperationStep, IZOneModuleProcess
    {
        public long? ZoneId { get; set; }
        public string Zone { get; set; }
        public string ModuleProcess { get; set; }
    }

    public class PassdownAuditItem
    {
        public long? AuditItemId { get; set; }
        public string Description { get; set; }
    }

    public class PassdownAuditItemWithZone : PassdownAuditItem, IZOneModuleProcess
    {
        public long? ZoneId { get; set; }
        public string Zone { get; set; }
        public string ModuleProcess { get; set; }
    }

    public class PassdownRework : OperationDetail
    {
        public string ReworkDescription { get; set; }
    }

    public class PassdownReworkWithZone : PassdownRework, IZOneModuleProcess
    {
        public long? ZoneId { get; set; }
        public string Zone { get; set; }
        public string ModuleProcess { get; set; }
    }

    public class PassdownZoneOperationDetail : PassdownZoneOperationTextDetail
    {
        public List<PassdownOperation> CompletedPassdownOperations { get; set; }
        public List<PassdownOperation> ProgressedPassdownOperations { get; set; }
        public List<PassdownOperationStep> PassdownOperationSteps { get; set; }
        public List<PassdownAuditItem> PassdownAuditItems { get; set; }
        public List<OperationDetail> NextOperationsToComplete { get; set; }
        public List<PassdownRework> PassdownReworks { get; set; }
    }

    public class PassdownModuleProcess
    {
        public string ModuleProcess { get; set; }
        public List<PassdownZoneOperationDetailWithZone> PassdownZoneOperationDetailWithZones { get; set; } = new List<PassdownZoneOperationDetailWithZone>();
    }

    public class PassdownZoneOperationDetailWithZone 
    {
        public long? ZoneId { get; set; }
        public string Zone { get; set; }
        public List<PassdownOperation> CompletedPassdownOperations { get; set; } = new List<PassdownOperation>();
        public List<PassdownOperation> ProgressedPassdownOperations { get; set; } = new List<PassdownOperation>();
        public List<PassdownOperationStep> PassdownOperationSteps { get; set; } = new List<PassdownOperationStep>();
        public List<PassdownAuditItem> PassdownAuditItems { get; set; } = new List<PassdownAuditItem>();
        public List<PassdownRework> PassdownReworks { get; set; } = new List<PassdownRework>();
        public List<PassdownZoneOperationTextDetail> PassdownZoneOperationTextDetails { get; set; } = new List<PassdownZoneOperationTextDetail>();
    }


    public class PassdownZoneOperationTextDetail
    {
        public long? PassdownZoneOperationDetailId { get; set; }
        public long? PassdownId { get; set; }
        public long? ZoneId { get; set; }
        public string ZoneNotes { get; set; }
        public string OtherTasksToComplete { get; set; }
        public long? NextOperationToCompleteId { get; set; }
        public string NextOpToComplete { get; set; }
    }

    public class PassdownZoneOperationTextDetailWithZOne : PassdownZoneOperationTextDetail, IZOneModuleProcess
    {
        public long? ZoneId { get; set; }
        public string Zone { get; set; }
        public string ModuleProcess { get; set; }
    }

    public class PassdownLOTO
    {
        public long? PassdownLOTOId { get; set; }
        public long? PassdownId { get; set; }
        public bool? FacilityLock { get; set; }
        public string Description { get; set; }
        public string ReasonForLOTO { get; set; }
        public long? CreatedById { get; set; }
        public string CreatedBy { get; set; }
    }

    public class PassdownTOI
    {
        public long? TOIId { get; set; }
        public string CriticalOrGating { get; set; }
        public string Title { get; set; }
        public string IssueDescription { get; set; }
        public string Comments { get; set; }
        public long? StatusID { get; set; }
        public bool? IsOpen { get; set; }

        public DateTime? CreatedOnDate { get; set; }

        public DateTime? UpdatedOnDate { get; set; }

        public DateTime? PassdownDate { get; set; }
    }

    public class PassdownIssueLog
    {
        public DateTime? DateModified { get; set; }
        public string IssueTitle { get; set; }
        public int? RecID { get; set; }
        public string IssueLogNum { get; set; }
        public string Status { get; set; }
    }

    public class PassdownNCI
    {
        public string Title { get; set; }
        public string Status { get; set; }
        public bool? IsClosed { get; set; }
        public int? IQMSId { get; set; }
    }

    public class PassdownOBC
    {
        public int? RecId { get; set; }
        public string LineItemNumber { get; set; }
        public string IsAddOrRemove { get; set; }
        public string LongText { get; set; }
        public bool? IsOpen { get; set; }
    }

    public class PassdownActionItemsDetail
    {
        public List<PassdownLOTO> PassdownLOTOs { get; set; } = new List<PassdownLOTO>();
        public List<PassdownTOI> OpenCriticalGatingTOIs { get; set; } = new List<PassdownTOI>();
        public List<PassdownTOI> OpenTOIs { get; set; } = new List<PassdownTOI>();
        public List<PassdownTOI> CloseTOIs { get; set; } = new List<PassdownTOI>();
        public List<PassdownIssueLog> PassdownIssueLogs { get; set; } = new List<PassdownIssueLog>();
        public List<PassdownNCI> OpenNCIs { get; set; } = new List<PassdownNCI>();
        public List<PassdownNCI> ClosedNCIs { get; set; } = new List<PassdownNCI>();
        public List<PassdownOBC> OpenOBCs { get; set; } = new List<PassdownOBC>();
        public List<PassdownOBC> ClosedOBCs { get; set; } = new List<PassdownOBC>();
        public BuildStyleDetail BuildStyleDetail { get; set; }
        public EditButtonDetail EditButtonDetail { get; set; }
    }

    public class PassdownAssemblyOperationDetail
    {
        public long? PassdownAssemblyId { get; set; }
        public long? PassdownId { get; set; }
        public string OpCompleted { get; set; }
        public string OpProgressed { get; set; }
        public string OpSkipped { get; set; }
        public string NextSteps { get; set; }
        public string Rework { get; set; }
        public string Notes { get; set; }
    }

    public class PassdownAssemblyOperationAuditItemsDetail : PassdownAssemblyOperationDetail
    {
        public List<PassdownAuditItem> PassdownAuditItems { get; set; }
    }

    public class PassdownTestDetail
    {
        public string OpCompleted { get; set; }
        public string OpProgressed { get; set; }
        public string OpSkipped { get; set; }
        public string NextSteps { get; set; }
        public string SpecialInstructions { get; set; }
        public string Notes { get; set; }
        public long? PassdownTestId { get; set; }
        public long? PassdownId { get; set; }
    }

    public class PassdownGenerateOrEdit : Passdown
    {
        public List<PassdownLOTO> PassdownLOTOs { get; set; } = new List<PassdownLOTO>();
        public List<PassdownZoneOperationTextDetail> PassdownZoneOperationTextDetails { get; set; } = new List<PassdownZoneOperationTextDetail>();
        public PassdownAssemblyOperationDetail PassdownAssemblyOperationDetail { get; set; } = null;
        public PassdownTestDetail PassdownTestDetail { get; set; } = null;
    }

    public class PassdownDisplay
    {
        public PassdownActionItemsDetail Issues { get; set; } = new PassdownActionItemsDetail();
        public List<PassdownModuleProcess> ModuleProcesses { get; set; }
        public PassdownAssemblyOperationAuditItemsDetail PassdownAssemblyOperationAuditItemsDetail { get; set; }
        public PassdownTestDetail PassdownTestDetail { get; set; }

    }
}
