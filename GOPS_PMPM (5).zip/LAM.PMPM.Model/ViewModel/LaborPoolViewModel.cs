﻿using System;


namespace LAM.PMPM.Model.ViewModel
{
    public class LaborPoolViewModel
    {
        public LaborPoolViewModel()
        {
            Status = "";
        }
        public string Name { get; set; }
        public string Status { get; set; }
        public string Department { get; set; }
        public string ShiftName { get; set; }
        public string DayShiftOnly { get; set; }
        public DateTime Date { get; set; }
        public string AssemblyCount { get; set; }
        public string TestCount { get; set; }
        public string WeekStart { get; set; }
    }
}
