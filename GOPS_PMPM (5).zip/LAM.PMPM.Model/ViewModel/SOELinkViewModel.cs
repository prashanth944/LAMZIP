﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
   public class SOELinkViewModel
    {

     
        public long? ZoneID { get; set; }
        public long? ProductGroupID { get; set; }
        public string ProductName { get; set; }
        public string Description { get; set; }
    }
}
