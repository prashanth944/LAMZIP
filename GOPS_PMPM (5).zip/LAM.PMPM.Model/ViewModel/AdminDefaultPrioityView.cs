﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
   public class AdminDefaultPrioityView
    {
        public int? SchedulePriorityRevenueTypeID { get; set; }
        public string RevenueType { get; set; }
        public int? RevenueTypeID { get; set; }
        public int? RevenuePriorityLevel { get; set; }              
        public int? SchedulePriorityRecordTypeID { get; set; }        
        public string RecordType { get; set; }
        public int? RecordTypeID { get; set; }
        public int? RecordTypePriorityLevel { get; set; }
        public long PlantID { get; set; }
        public int? SchedulePriorityID { get; set; }
        public string ScheduleType { get; set; }
        public int? ScheduleTypePriorityLevel { get; set; }

        public class PriorityDetails

        {
            public List<AdminDefaultPrioityView> SchedulePriority { get; set; }
            public List<AdminDefaultPrioityView> RevenueTypePriority { get; set; }
            public List<AdminDefaultPrioityView> RecordTypePriority { get; set; }

        }
        public class LaborHourLoanTo
        {
            public bool IsActive { get; set; }
            public string OptionName { get; set; }
            public int LaborHourLoanToId { get; set; }
            public int PlantID { get; set; }
        }

    }
}
