﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
    public class AdjustScheduleViewModule
    {
        public long PilotProductID { get; set; }
        public bool LaborResourcesHardConstraint { get; set; }
        public bool BayResourcesHardConstraint { get; set; }
        public DateTime EarliestStartDate { get; set; }
        public int ProductionPlanID { get; set; }
        public long? PlantID { get; set; }
        public string PlantName { get; set; }
        public string PlanType { get; set; }
        public bool? DayShiftOnly { get; set; }
        public long UserID { get; set; }
        public string ModuleProcess { get; set; }
        public int NoOfDays { get; set; } = 0;
    }
}
