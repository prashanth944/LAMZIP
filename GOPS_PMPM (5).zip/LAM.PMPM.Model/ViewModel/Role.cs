﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
    public class Role
    {
        public long? RoleId { get; set; }
        public string RoleName { get; set; }
        public string DisplayName { get; set; }
    }
}
