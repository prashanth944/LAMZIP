﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
    public class SerializationNumbers
    {
        public long SerializationNumberToolsID { get; set; }
        public string Category { get; set; }
        public string Zone { get; set; }
        public string ToolName { get; set; }
        public bool? Active { get; set; }
        public string PartNum { get; set; }
        public string SerialNum { get; set; }
    }

    public class SerializationRequest
    {
        public int SerializationNumberToolsID { get; set; }
        public int Pilotproductid { get; set; }
        public string PartNum { get; set; }
        public string SerialNum { get; set; }
    }
}
