﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{



    public class BuildTypeMultiplierView
    {
        public long BuildTypeID { get; set; }
        //[Required(ErrorMessage = "Please enter Build Type Name")]
        public string BuildTypeName { get; set; }
        // [Required(ErrorMessage = "Please enter Labor Multiplier")]
        public string LaborMultiplier { get; set; }
        public decimal? MultiplierValue { get; set; }
        public int PlantID { get; set; }
    }
}