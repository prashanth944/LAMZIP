﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
    public class UserModel
    {
        public long? UserId { get; set; }
        public string Username { get; set; }
        public string FacilityName { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public long? PlantId { get; set; }
        public long? ShiftID { get; set; }
        public string ShiftType { get; set; }
        public decimal? HoursPerDay { get; set; }
        public int? LeadDirectPerc { get; set; }
        public int? PASSDirectPerc { get; set; }
        public long? EmployeeId { get; set; }
        public string LAMNTId { get; set; }
        public string Roles { get; set; }
        public TimeSpan? ShiftStartTime { get; set; }
    }

    public class UserRunningOperationModel
    {
        public long? WorkRecordID { get; set; }
        public long? PilotProductID { get; set; }
        public long? OperationID { get; set; }
        public string OperationDescription { get; set; }
        public DateTime? StartTimestamp { get; set; }
        public bool? IsRework { get; set; }
        public bool? IsAudit { get; set; }
        public long? ZoneID { get; set; }
        public bool? PORIsBeingEdited { get; set; }
    }
}
