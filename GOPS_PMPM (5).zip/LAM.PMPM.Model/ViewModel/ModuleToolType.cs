﻿using System;


namespace LAM.PMPM.Model.ViewModel
{
    public class ModuleToolType
    {
        public int ProductGroupID { get; set; }
        public string ProductName { get; set; }

        public long ToolTypeID { get; set; }
        public long ModuleProcessID { get; set; }
        public string ToolTypeName { get; set; }
        public string ModuleProcess { get; set; }

        
        public int? BayRequired { get; set; }
        public int? HourRequired { get; set; }
        public int? TechnicianRequired { get; set; }
        public DateTime? TransitionDate { get; set; }
        public DateTime? POABOMReleaseDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? LastUpdated { get; set; }

       
    }
}
