﻿

using System.Collections.Generic;

namespace LAM.PMPM.Model.ViewModel
{

    public class LaborManagementProductGroupViewModel
    {
        public long? LaborManagmentGroupID { get; set; }
        // public string Name { get; set; }
        public string ManagementName { get; set; }
        public long? LaborManagmentProductGroupID { get; set; }
        public long? LaborProductGroupID { get; set; }
        public long? ProductGroupID { get; set; }
        public string LaborProductName { get; set; }
        public string ProductName { get; set; }

    }
    public class LaborManagementProductGroupViewModelMapping
    {
        public long? LaborManagmentGroupID { get; set; }
        public long? ProductGroupID { get; set; }
        public string LaborProductName { get; set; }
        public string ProductName { get; set; }

    }
   

    public class LabourManagementGroupMapping
    {
        
        public long? LaborManagmentGroupID { get; set; }
        //public string Name { get; set; }
        public string ManagementName { get; set; }
        public long? LaborManagmentProductGroupID { get; set; }
        public long? LaborProductGroupID { get; set; }
        public List<LaborManagementProductGroupViewModelMapping> LaborMgmtGrpDetails { get; set; } = new List<LaborManagementProductGroupViewModelMapping>();
    }
}
