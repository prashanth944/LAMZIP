﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
   public class ScheduleLaborHours
    {
        public double TotalAvailableHour { get; set; }
        public double TotalConsumedHours { get; set; }
        public double TotalRemainingHour { get; set; }
        public string ManagementName { get; set; }
        public DateTime LaborDate { get; set; }
        public DateTime WeekStart { get; set; }
        public char Assembly { get; set; }
    }
}
