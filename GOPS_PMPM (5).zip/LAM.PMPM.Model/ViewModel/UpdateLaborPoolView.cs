﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
   public class UpdateLaborPoolView
    {
        public long? LaborManagmentGroupID { get; set; }
        public int Status { get; set; }
        public string Department { get; set; }
        public string DayShiftOnly { get; set; }
    }
}
