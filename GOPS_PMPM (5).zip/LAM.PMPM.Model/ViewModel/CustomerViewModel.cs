﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
  public class CustomerViewModel
    {

        public string Customer { get; set; }

         public string ProductionStatus { get; set; }

    }
}
