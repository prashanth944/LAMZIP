﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
    public class ProductionPlan
    {
        public long? ProductionPlanId { get; set; }
        public long? IsBeingEditedById { get; set; }
        public string IsBeingEditedBy { get; set; }
        public bool? IsBeingEdited { get; set; }
    }
}
