﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
    public class GenerateScheduleOutputViewModel
    {
        public int LaborAvail { get; set; } = 0;
        public int BayAvail { get; set; } = 0;
        public string errorMessageArr { get; set; }
        public string BENArr { get; set; }
        public string LBRArr { get; set; }
        public string PilotSer { get; set; }
        public int ModSuccess { get; set; }
        public int? rowCount { get; set; }
    }
}
