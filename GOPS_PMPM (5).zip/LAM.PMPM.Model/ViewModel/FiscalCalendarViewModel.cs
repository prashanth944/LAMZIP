﻿using System;
using System.ComponentModel.DataAnnotations;
namespace LAM.PMPM.Model.ViewModel
{
    public class FiscalCalendarViewModel
    {
        public int? id{get; set; }
        public int FiscalYear{get; set; }
        public int Quarter{get; set; }
        public DateTime? StartDate{get; set; }
        public DateTime? EndDate{get; set; }
        public int WWinQuarter{get; set; }
    }
}