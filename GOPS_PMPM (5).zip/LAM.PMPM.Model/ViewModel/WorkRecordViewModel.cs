﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
    public class WorkRecordViewModel
    {
        public long UserId { get; set; }
        public long? PilotProductID { get; set; }
        public long? OperationId { get; set; }
        public DateTime StartDateTime { get; set; }
        public DateTime EndDateTime { get; set; }
        public bool EndOrResume { get; set; }
        public bool IsRework { get; set; } = false;
        public bool? IsAudit { get; set; } = false;
        public long? AuditItemId { get; set; } = 0;
    }
}
