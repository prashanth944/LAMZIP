﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
    public class HomeRoleViewModel
    {

        public string UserName { get; set; } = null;
        public string Description { get; set; } = null;
        public string PilotSerialNumber { get; set; } = null;
        public DateTime? StartTimestamp { get; set; }
        public long? OperationID { get; set; }
        public long? UserId { get; set; }
        public long? PilotProductID { get; set; }
        public decimal? OperationPercent { get; set; }
        public string BEN { get; set; } = null;
        public long? WorkRecordID { get; set; }
        public bool? IsInterrupted { get; set; }

    }

    public class NextReleaseViewModel
    {

        public string BEN { get; set; } = null;
        public string FCID { get; set; } = null;
        public string SalesOrderNumber { get; set; } = null;
        public string SalesOrder { get; set; } = null;
        public int? ReworkPO { get; set; }
        public int? BOMNumber { get; set; }
        public string ProductName { get; set; } = null;
        public DateTime? PlannedShipDate { get; set; }
        public string DivisionName { get; set; }
        public long? DivisionID { get; set; }

    }

    public class WIPRelease
    {

        public long? PilotproductID { get; set; }
        public int BuildSchedule { get; set; }
        public DateTime? ActualLaunchDate { get; set; }
        public string ModuleColor { get; set; } = null;
        public int? TargetTestDays { get; set; }
        public List<ModuleVFDWithName> ModuleVFDs { get; set; }
        public DateTime? PlannedLaunchDate { get; set; }
        public bool? DayShiftOnly { get; set; }
        public int? CountOfShortages { get; set; }
        public string BuildStyle { get; set; }
        public long? BuildStyleID { get; set; }
        public string BuildType { get; set; }
        public long? BuildTypeID { get; set; }
        public string BENorPSNReconfiguredFrom { get; set; }
        public string ReworkPO { get; set; }
        public string AddPO { get; set; }
        public string DeletePO { get; set; }
        public string CurrentPartNumber { get; set; }
        public string NewPartNumber { get; set; }
        public long? BuildingID { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public long? ModifiedBy { get; set; }
        public int? ProcessModule { get; set; }
    }

    public class WIPReleaseUpdate : WIPRelease
    {
        public new List<ModuleVFD> ModuleVFDs { get; set; }
    }

    public class ModuleVFD
    {
        public long? ModuleVFDId { get; set; }
        public long? PilotProductId { get; set; }
        public long? VFDZoneId { get; set; }
        public long? StatusId { get; set; }
        public string BayName { get; set; }
        public bool? Assignable { get; set; }
        public int? NumberOfDays { get; set; }

        public string AddProdOrder { get; set; }
        public string DeleteProdOrder { get; set; }
    }

    public class ModuleVFDWithName : ModuleVFD
    {
        public string VFDZoneName { get; set; }
    }

    public class ModuleListOfModuleVFDWithName
    {
        public long? PilotProductId { get; set; }
        public List<ModuleVFDWithName> ModuleVFDWithNames { get; set; }
    }
    public class CriticalGatingIssueLogModel
    {
        public long PilotProductID { get; set; }
        public string PilotSerialNumber { get; set; }
        public string BEN { get; set; }
        public string ProductionOrderNum { get; set; }
        public string Urgency { get; set; }
        public string Title { get; set; }
        public string IssueDescription { get; set; }
        public DateTime? ExpectedCloseDate { get; set; }
        public DateTime? GatingDate { get; set; }
        public string Comments { get; set; }

    }

    public class SafetyLineDownIssueLogModel
    {
        public long? PilotProductID { get; set; }
        public DateTime? DateCreated { get; set; }
        public string Status { get; set; }
        public string Urgency { get; set; }
        public string IssueLogNum { get; set; }
        public string SerialNo { get; set; }
        public string BEN { get; set; }
        public string IssueTitle { get; set; }
        public string IssueType { get; set; }
        public string ProductDesignCategory { get; set; }
        public string ToolSerial { get; set; }
    }
}
