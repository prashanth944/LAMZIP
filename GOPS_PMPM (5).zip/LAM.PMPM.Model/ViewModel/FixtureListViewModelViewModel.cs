﻿using System.ComponentModel.DataAnnotations;


namespace LAM.PMPM.Model.ViewModel
{
    public class FixtureListViewModel
    {
        public int FixtureID { get; set; }
        [Required(ErrorMessage = "Please enter Fixture Name")]
        public string FixtureName { get; set; }
        public string AssetTagNo { get; set; }
        public int BEN { get; set; }

        public bool? Status { get; set; } = false;
        public int Quantity { get; set; }
        public int ProductType { get; set; }

        public string PilotSerialPartNumber { get; set; }
        public string ModuleProcess { get; set; }
    }
}
