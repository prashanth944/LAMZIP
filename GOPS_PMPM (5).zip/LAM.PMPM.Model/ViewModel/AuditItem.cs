﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
    public class AuditItem
    {
        public long? AuditItemId { get; set; }
        public string Description { get; set; }
        public long? UserId { get; set; }
        public DateTime? CreatedOn { get; set; }
        public long? AuditCategoryID { get; set; }
        public long? AuditCauseID { get; set; }
        [Required]

        public long? PilotProductID { get; set; }
        [Required]
        public long? ZoneID { get; set; }
        [Required]
        public long? OperationID { get; set; }
    }

    public class AuditItemDetails : AuditItem
    {
        public string AuditCategory { get; set; }
        public string AuditCause { get; set; }
        public string Action { get; set; }
        public bool? IsOpen { get; set; }
        public string OperationDescription { get; set; }
        public string ZoneDescription { get; set; }
        public string ZoneName { get; set; }
        public string CreatedBy { get; set; }
        public string CompletedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public long? WorkRecordID { get; set; }
        public long? UserId { get; set; }
        public List<string> BeforePicture { get; set; }
        public List<string> AfterPicture { get; set; }
        public DateTime? StartTimestamp { get; set; }

        public List<string> TempBeforePicture { get; set; }
        public List<string> TempAfterPicture { get; set; }
    }

    public class AuditItemViewModelNoZone
    {
        public List<AuditItemDetails> Open { get; set; }
        public List<AuditItemDetails> Close { get; set; }
        public long? WorkRecordID { get; set; }
        public long? UserId { get; set; }
    }


    public class AuditItemViewModelZone
    {
        public List<ZoneItems> Open { get; set; }
        public List<ZoneItems> Close { get; set; }
        public List<ZoneBrief> AllZones { get; set; }
        public long? WorkRecordID { get; set; }
        public long? UserId { get; set; }
    }

    public class ZoneItems
    {
        public long? ZoneID { get; set; }
        public string ZoneDescription { get; set; }
        public string ZoneName { get; set; }
        public List<AuditItemDetails> AuditItems { get; set; }
    }

    public class ZoneBrief
    {
        public long? ZoneID { get; set; }
        public string ZoneDescription { get; set; }
        public int TotalAuditItems { get; set; }
        public int TotalOpenItems { get; set; }
    }
}
