﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
    public class LogProgressView
    {

        public long StepNo { get; set; }
        public int? Completed { get; set; }
        public int? Skipped { get; set; }
        public int? Excluded { get; set; }

        public long UserID { get; set; }
        public string TechnicianNote { get; set; }
    }

    public class StepDetail
    {
        public long? StepRecordId { get; set; }
        public int? StepNo { get; set; }
        public bool? Completed { get; set; }
        public bool? Skipped { get; set; }
        public bool? Excluded { get; set; }
        public string CompletedBy { get; set; }
        public long? CompletedById { get; set; }
        public long? ReworkedById { get; set; }
        public long? SkippedById { get; set; }
        public long? ExcludedById { get; set; }
        public string TechnicianNotes { get; set; }
        public int NumberofSteps { get; set; }
        public long? OperationId { get; set; }
        public double? CycleTimeMinutes { get; set; }
        public long? PilotProductId { get; set; }
        public bool? Reworked { get; set; }
        public string ReworkedBy { get; set; }
        //public long? PreviousReworkedkById { get; set; }
        //public string PreviousReworkedkBy { get; set; }
        public bool? IsOnlyTechNote { get; set; }
        public bool? IsAllUpdate { get; set; }
    }

    public class OperationLogDetail
    {
        public long? OperationId { get; set; }
        public string Description { get; set; }
        public double? CycleTimeMinutes { get; set; }
        public DateTime? OriginalStartTime { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public bool? IsRunning { get; set; }
        public bool? IsInterrupted { get; set; }
        public DateTime? LatestInterruptionTime { get; set; }
        public int? TotalInterruptionMinutes { get; set; }
        public int? TotalInterruptionSeconds { get; set; }
        public int? NumberOfSteps { get; set; }
        public long? WorkRecordId { get; set; }
        public string OtherUserNotes { get; set; }
        public string Notes { get; set; }
        public string ExceptionCategory { get; set; }
        public long? StandardTimeExceptionCategoryId { get; set; }
        public string SOELink { get; set; }
        public string BEN { get; set; }
        public string PilotSerialNumber { get; set; }
        public List<string> BeforePicture { get; set; }
        public List<string> AfterPicture { get; set; }
        public long BuildStyleID { get; set; }
        //[Required(ErrorMessage = "Please enter Build Type Name")]
        public string BuildStyleName { get; set; }

    }

    public class OperationLogDetailGeneral
    {
        public string Description { get; set; }
        public string BEN { get; set; }
        public string PilotSerialNumber { get; set; }
        public int? TotalInterruptionMinutes { get; set; }
        public DateTime? MinStartTime { get; set; }
        public DateTime? LastEndTime { get; set; }
        public int? TotalDurationMinutes { get; set; }
    }

    public class InterruptionModel
    {
        public long? OperationId { get; set; }
        public long? PilotProductId { get; set; }
        public long? UserId { get; set; }
        public DateTime? InterruptionStartTime { get; set; }
        public DateTime? InterruptionEndTime { get; set; }
        public long? WorkRecordId { get; set; }
        public string Notes { get; set; }
        public long? InterruptionCategoryId { get; set; }
    }

    public class Interrupt
    {
        public long? InterruptionCategoryId { get; set; }
        public string InterruptionCategory { get; set; }
        public string Notes { get; set; }
        public int? InterruptTime { get; set; }
    }
    public class InterruptByOperation
    {
        public string Category { get; set; }
        public string UserName { get; set; }
        
        public DateTime? InterruptionStartTime { get; set; }
        public DateTime? InterruptionEndTime { get; set; }
        public int? InterruptionMinutes { get; set; }
        public string Notes { get; set; }
        
    }

    public class StandardTimeExceptionCategory
    {
        public long? StandardTimeExceptionCategoryId { get; set; }
        public string OptionName { get; set; }
    }

    public class InterruptionCategory
    {
        public long? InterruptionCategoryId { get; set; }
        public string OptionName { get; set; }
    }

    public class WorkRecordModel
    {
        public long? StandardTimeExceptionCategoryId { get; set; } = null;
        public long? WorkRecordId { get; set; }
        public string Notes { get; set; } = null;
        public DateTime EndTime { get; set; }
        public long? UserCancelledBy { get; set; } = null;
        public bool? IsUserCancelled { get; set; } = null;
    }

    public class WorkRecordReworkModel
    {
        public long? WorkRecordReworkId { get; set; }
        public long? OperationId { get; set; }
        public long? PilotProductId { get; set; }
        public string OperationDescription { get; set; }
        public string OperationNumber { get; set; }
        public long? WorkRecordId { get; set; }
        public bool? IsOBC { get; set; }
        public string PilotOrSupplier { get; set; }
        public long? ReworkCategoryId { get; set; }
        public string ReworkCategory { get; set; }
        public string ReworkDescription { get; set; }
        public List<string> BeforePicture { get; set; }
        public List<string> AfterPicture { get; set; }
        public int? ReworkNumber { get; set; }
        public string RWCause { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public bool IsRunning { get; set; }
        public string GUID { get; set; }
        public string ToEmail { get; set; }
        public string CCEmail { get; set; }
        public string ReworkBy { get; set; }
        public int InterruptionMinutes { get; set; }
        public string PSNOrBen { get; set; }
    }
}
