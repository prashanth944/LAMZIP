﻿

namespace LAM.PMPM.Model.ViewModel
{
   public class FixtureSummaryViewModel
    {
        public int FixtureID { get; set; }
        public string FixtureName { get; set; }
        public int FixtureQuantity { get; set; }
    }
}
