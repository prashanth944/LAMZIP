namespace LAM.PMPM.Model.ViewModel
{
    public class BuildingViewModel
    {
        public int? BuildingID { get; set; }
        public string BuildingName { get; set; }
        public string Code {get; set; }
        public int PlantID { get; set; }
    
    }
}