﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
   public class AdminDefaultsView
    {
       
        public long PlantID { get; set; }
        public int? MaxLaunchesInaWeekRed { get; set; }
        public int? MaxLaunchesInaWeekYellow { get; set; }
        public int? BayUsageWarningYellow { get; set; }
        public int? BayUsageWarningRed { get; set; }
        public int? LaborUsageWarningYellow { get; set; }
        public int? LaborUsageWarningRed { get; set; }
        public int? PlannedHighRiskMCSD { get; set; }
        public int? PlannedMedRiskMCSD { get; set; }
        public int? ScheduleBufferDays { get; set; }
        public int? EfficencyFactory { get; set; }
        public int? LaborUtilization { get; set; }
        public int? OvertimePerc { get; set; }
        public int? PTOPerc { get; set; }
        public int? LeadDirectPerc { get; set; }
        public int? PASSDirectPerc { get; set; }
        public string ScheduleTimePeriod { get; set; }
        public string ScheduleColorView { get; set; }
        public int? OpTimeSTELow { get; set; }
        public int? OpTimeSTEHigh { get; set; }
        public int? CycleTimeUtilization { get; set; }

    }
}
