using System;
using System.ComponentModel.DataAnnotations;
namespace LAM.PMPM.Model.ViewModel
{
    public class HolidayViewModel
    {
        public int? HolidayID{get; set; }
        public string Name{get; set; }
        public DateTime? HolidayDateDaily{get; set; }
        public Boolean FactoryShutDown{get; set; }
        public int PlantID{get; set; }
    }
}