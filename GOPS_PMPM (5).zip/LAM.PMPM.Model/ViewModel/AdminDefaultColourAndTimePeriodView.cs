﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
  public  class AdminDefaultColourAndTimePeriodView
    {
        public long PlantID { get; set; }
       
        public string ColorName { get; set; }
        public long ColorID { get; set; }
        public string TimePeriodName { get; set; }
        public long TimePeriodID { get; set; }
    }
}
