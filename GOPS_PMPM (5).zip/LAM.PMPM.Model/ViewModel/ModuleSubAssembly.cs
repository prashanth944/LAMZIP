﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
    public class ModuleSubAssembly
    {
        public int? PlantId { get; set; }
        public long? PilotProductID { get; set; }
        public string SpecialSubAssyType { get; set; } = null;
        public bool? Hot { get; set; }
        public string PurchaseOrderNumber { get; set; }
        public bool? PCWOReleased { get; set; }
        public bool? CA10ShortageFree { get; set; }
        public DateTime? DateDelivered { get; set; }
        public bool? MfgApproved { get; set; }
        public string PCFSAuditedBy { get; set; } = null;
        public int? Qty { get; set; }
        public string PlannerName { get; set; } = null;
        public string PartNumber { get; set; } = null;
        public string Description { get; set; }
        public DateTime? MaterialReadiness { get; set; }
        public DateTime? CRD { get; set; }
        public DateTime? CommitLaunch { get; set; }
        public DateTime? CommittedTestStart { get; set; }
        public DateTime? CommitedManufacturingComplete { get; set; }
        public DateTime? PilotCommit { get; set; }
        public string AssemblyTechnicianName { get; set; } = null;
        public string TestTechnicianName { get; set; } = null;
        public string MRPDemand { get; set; } = null;
        public long? MRPDemandID { get; set; } = null;
        public string CapacityPlanningColor { get; set; } = null;
        public string Note { get; set; } = null;
        public DateTime? CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public int? SubassemblyBays { get; set; }
        public int? TestBays { get; set; }
        public decimal? SubassemblyBuildHours { get; set; }
        public decimal? TestBuildHours { get; set; }
        public int? SubassemblyTechnician { get; set; }
        public int? TestTechnician { get; set; }
        public decimal? TotalLaborHour { get; set; }
        public string EngineeringPOC { get; set; }
        public bool? PilotMEApproved { get; set; }
        public string SOELink { get; set; }
        public bool? PCFSShortageFreeAudit { get; set; }
        public bool? Rework { get; set; }
        public bool? SpclProcess { get; set; }
        public int? EstimatedBuildTime { get; set; }
        public int? EstimatedTestTime { get; set; }
        public string Auditor { get; set; }
        public DateTime? KitReceivedDate { get; set; }
        public string SerialNum { get; set; }
        public string TechBuild { get; set; }
        public string TechTest { get; set; }
        public DateTime? ActualTestComplete { get; set; } // represents - Pilot Test Complete Date - https://dev.azure.com/LamCollection1/GOPS_PMPM/_boards/board/t/GOPS_PMPM%20Team/Stories/?workitem=27385
        public DateTime? ActualTestStart { get; set; } // Pilot Build Complete Date https://dev.azure.com/LamCollection1/GOPS_PMPM/_boards/board/t/GOPS_PMPM%20Team/Stories/?workitem=27385
        public string AssemblySerialNumber { get; set; }
        public bool? InShipping { get; set; }
        public string ProductionOrderNum { get; set; }
    }
}
