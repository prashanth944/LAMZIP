﻿using System;

namespace LAM.PMPM.Model.ViewModel
{
    public class EmailAdminViewModel
    {
        public int? PlantId {get; set;}
        public int? Id {get; set;}
        public string EmailAddress {get; set;}
        public Boolean? IncludeInWIPEmail {get; set;}
        
    }
}