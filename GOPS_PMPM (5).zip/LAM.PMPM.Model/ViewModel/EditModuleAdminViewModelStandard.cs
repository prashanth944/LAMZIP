﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
   public class EditModuleAdminViewModelStandard : EditModuleViewModelStandard
    {
        public long? pilotProductId { get; set; }
        public List<ModuleVFD> ModuleVFDs { get; set; }
    }
}
