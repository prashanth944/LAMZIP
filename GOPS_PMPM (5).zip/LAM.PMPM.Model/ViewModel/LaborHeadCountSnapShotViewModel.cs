﻿using System;


namespace LAM.PMPM.Model.ViewModel
{
    public class LaborHeadCountSnapShotViewModel
    {
        public string DayShiftOnly { get; set; }
        public int TotalAvailableHours { get; set; }
        public DateTime Date { get; set; }
        public string DayName { get; set; }
    }
}
