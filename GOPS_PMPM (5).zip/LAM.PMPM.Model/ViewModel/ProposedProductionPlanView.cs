﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
   public class ProposedProductionPlanView
    {

        public int Headcount { get; set; }
        public string? HeadCountType { get; set; }
        public DateTime? LaborDate { get; set; }
        public string? WeekStart { get; set; }

        public string? Monthly { get; set; }
        public string? Quarterly { get; set; }
        public string? Annualy { get; set; }
    }
}
