﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
    public class OperationViewModel
    {
        public string OPSDescription { get; set; }
        public long? UserId { get; set; }
        public long? PilotProductID { get; set; }
        public long? OperationId { get; set; }
        public int? NumberOfSteps { get; set; }
        public double? CycleTimeHours { get; set; }
        public decimal? OPPercent { get; set; }
        public string ModuleProcess { get; set; }
        public string ZoneDescription { get; set; }
        public string Action { get; set; }
        public long? WorkRecordId { get; set; }
        public double? StepsCompleteTime { get; set; }
        public double? TotalStepsTime { get; set; }
        public long? ZoneId { get; set; }
        public long? ModuleProcessId { get; set; }
        public int? ZoneOrder { get; set; }
        public bool? IsAudit { get; set; }
        public string DayNightApproved { get; set; }
        public string Status { get; set; }
        public double? TestPercent { get; set; }
        public double? PostTestPercent { get; set; }
    }

    public class OperationViewUIModel
    {
        public long? ModuleProcessId { get; set; }
        public string ModuleProcess { get; set; }
        public double? PercentComplete { get; set; }
        public List<Zone> Zones { get; set; }
    }

    public class Zone
    {
        public long? ZoneId { get; set; }
        public string ZoneDescription { get; set; }
        public List<Operation> Operations { get; set; }
        public double? CycleTimeMinutesSum { get; set; }
        public double? CycleTimeMinutesAvg { get; set; }
        public int? TotalSteps { get; set; }
        public double? ZoneOPPercent { get; set; }
        public int? ZoneOrder { get; set; }
    }

    public class Operation
    {
        public string OPSDescription { get; set; }
        public long? UserId { get; set; }
        public long? PilotProductID { get; set; }
        public long? OperationId { get; set; }
        public int? NumberOfSteps { get; set; }
        public double? CycleTimeMinutes { get; set; }
        public decimal? OPPercent { get; set; }
        public string Action { get; set; }
        public long? WorkRecordId { get; set; }
        public double? StepsCompleteTime { get; set; }
        public double? TotalStepsTime { get; set; }
        public int Order { get; set; }
        public bool? IsAudit { get; set; }
        public string DayNightApproved { get; set; }
        public string Status { get; set; }
    }

    public class OPSMGZoneCommon
    {
        public int Order { get; set; }
        public long? ZoneID { get; set; }
        public string Zone { get; set; }
    }

    public class OPSMGZone : OPSMGZoneCommon
    {
        public List<OPSMGOperation> OPSMGOperations { get; set; }
    }

    public class OPSMGZoneEngineer : OPSMGZoneCommon
    {
        public List<OPSMGOperationEngineer> OPSMGOperationsEngineer { get; set; }
        public decimal SumTotalDirectHours { get; set; }
        public decimal SumTotalRework { get; set; }
        public decimal SumTotalInterrupt { get; set; }
        public decimal AvgTotalCycleTime { get; set; }
    }

    public class OPSMGUIModelCommon
    {
        public long? ModuleProcessId { get; set; }
        public string ModuleProcess { get; set; }
        public bool? ModDayShiftOnly { get; set; }
    }

    public class OPSMGUIModel : OPSMGUIModelCommon
    {
        public List<OPSMGZone> OPSMGZones { get; set; }
    }

    public class OPSMGEngineerUIModel : OPSMGUIModelCommon
    {
        public List<OPSMGZoneEngineer> OPSMGZonesEngineer { get; set; }
    }

    public class OPSMGOperation : OPSMGOperationEditFields
    {

        public string DayNightApproved { get; set; }
        public bool? ModDayShiftOnly { get; set; }
        public string Status { get; set; }
        public decimal? OpPercent { get; set; }
        public string Description { get; set; }
        public DateTime? ActualPlannedStartDate { get; set; }
        public DateTime? CalculatedFinish { get; set; }
        public string STUpdatedBy { get; set; }
        public decimal? CalculatedStandardTimeDays { get; set; }
        public double? AverageCycleTimeHours { get; set; }
        public decimal? TotalCycleTimeHours { get; set; }
        public decimal? TotalReworkHours { get; set; }
        public long? ZoneID { get; set; }
        public string ZoneDescription { get; set; }
        public string ZoneName { get; set; }
        public int Order { get; set; }
        public int ZoneOrder { get; set; }
        public int HoursPerDay { get; set; }
        public long? ModuleProcessID { get; set; }
        public string ModuleProcess { get; set; }
        public DateTime? GatingDate { get; set; }
        public DateTime? ActualPlannedLaunch { get; set; }
        public bool FirstInZone { get; set; }
        public bool LastInZone { get; set; }
        public double? DaysRemainingInZone { get; set; }
        public int? NumberOfSteps { get; set; }
        public int? CompletedSteps { get; set; }
        public int? ModuleShiftHours { get; set; }
        public string Plant { get; set; }
    }

    public class OPSMGOperationEngineer
    {
        public long? PilotProductID { get; set; }
        public long? OperationID { get; set; }
        public string Status { get; set; }
        public decimal? OpPercent { get; set; }
        public string Description { get; set; }
        public DateTime? ActualPlannedStartDate { get; set; }
        public DateTime? CalculatedFinish { get; set; }
        public decimal? TotalDirectHours { get; set; }
        public decimal? TotalRework { get; set; }
        public decimal? TotalInterrupt { get; set; }
        public decimal? TotalCycleTime { get; set; }
        public long? ZoneID { get; set; }
        public string ZoneDescription { get; set; }
        public string ZoneName { get; set; }
        public decimal? CalculatedStandardTimeDays { get; set; }
        public int Order { get; set; }
        public int ZoneOrder { get; set; }
        public long? ModuleProcessID { get; set; }
        public string ModuleProcess { get; set; }
        public DateTime? GatingDate { get; set; }
        public DateTime? ActualPlannedLaunch { get; set; }
        public bool FirstInZone { get; set; }
        public bool LastInZone { get; set; }
        public double? DaysRemainingInZone { get; set; }
        public int? NumberOfSteps { get; set; }
        public int? CompletedSteps { get; set; }
        public int? ModuleShiftHours { get; set; }
        public double? StandardTimeHours { get; set; }
    }

    public class OPSMGOperationListForEngineer
    {
        public List<OPSMGOperationEngineer> OPSMGOperationsEngineer { get; set; }
        public decimal SumTotalDirectHours { get; set; }
        public decimal SumTotalRework { get; set; }
        public decimal SumTotalInterrupt { get; set; }
        public decimal AvgTotalCycleTime { get; set; }
    }

    public class ModulePercentage
    {
        public long? PilotProductID { get; set; }
        public double? AssemblyPercent { get; set; }
        public int? TestPercent { get; set; }
        public int? PostTestPercent { get; set; }
    }

    public class OPSMGOperationEditFields
    {
        public long? PilotProductID { get; set; }
        public long? OperationID { get; set; }
        public double? ManualOpPercent { get; set; }
        public bool? DayShiftOnly { get; set; }
        public bool? NightShiftOnly { get; set; }
        public double? StandardTimeHours { get; set; }
        public string STOverrideReason { get; set; }
        public long? STUpdatedById { get; set; }
    }

    public class OPSMGOperationEdit : ModulePercentage
    {
        public List<OPSMGOperationEditFields> OPSMGOperationEditFields { get; set; }
    }

    public class OPSSubassemblyModel
    {
        public long? PilotProductID { get; set; }
        public double? AssemblyPercent { get; set; }
        public int? TestPercent { get; set; }
        public int? PostTestPercent { get; set; }
        public decimal? SubassemblyBuildHours { get; set; }
        public decimal? TestBuildHours { get; set; }
        public long? ModuleProcessIdForSubassembly { get; set; }
        public long? ModuleProcessIdForTest { get; set; }
        public bool? PilotMEApproved { get; set; }
        public string SOELink { get; set; }
        public bool? MfgApproved { get; set; }
        public bool? CA10ShortageFree { get; set; }
        public string PercentType { get; set; }
        public bool? InWIP { get; set; }
    }

    public class ScheduleSubassemblyModel
    {
        public long? PilotProductID { get; set; }
        public DateTime? KitDateDelivered { get; set; }
        public DateTime? KitReceivedDate { get; set; }
        public DateTime? ActualTestStart { get; set; }
        public DateTime? ActualTestComplete { get; set; }
        public DateTime? CommitedManufacturingComplete { get; set; }
        public DateTime? PilotManufacturingCommitedShipDate { get; set; }
        public DateTime? CustomerRequestDate { get; set; }
        public bool? InWIP { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public long? ModifiedBy { get; set; }
    }

    public class OperationDateModel
    {
        public long? PilotProductID { get; set; }
        public long? OperationID { get; set; }
        public string OPDescription { get; set; }
        public int OpOrder { get; set; }
        public int ZoneOrder { get; set; }
        public long? ZoneID { get; set; }
        public string ZoneDescription { get; set; }
        public string ZoneName { get; set; }
        public DateTime? ActualPlannedStartDate { get; set; }
        public DateTime? CalculatedFinish { get; set; }
        public DateTime? GatingDate { get; set; }
        public decimal? CalculatedStandardTimeDays { get; set; }
        public string ModuleProcess { get; set; }
        public DateTime? ActualPlannedLaunch { get; set; }
        public bool LastInZone { get; set; }
        public bool FirstInZone { get; set; }
        public int? NumberOfSteps { get; set; }
        public int? CompletedSteps { get; set; }
        public int? ModuleShiftHours { get; set; }
        public double? StandardTimeHours { get; set; }
        public double? DaysRemainingInZone { get; set; }
        public string Plant { get; set; }
    }

    public class ModuleOperationDateModels
    {
        public long? PilotProductId { get; set; }
        public List<OperationDateModel> OperationDateModels { get; set; }
    }
}
