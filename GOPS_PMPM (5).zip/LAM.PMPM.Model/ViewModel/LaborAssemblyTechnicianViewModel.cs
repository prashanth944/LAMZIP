﻿using System;


namespace LAM.PMPM.Model.ViewModel
{
    public class LaborAssemblyTechnicianViewModel
    {
        public int ShiftID { get; set; }
        public int LaborCapacityID { get; set; }

        public int PlantID { get; set; }
        public string AssembleyTest { get; set; }
        public string Status { get; set; }
        public string ManagementGroup { get; set; }
        public char ShiftType { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime EndDate { get; set; }

        public string EffectiveDateString { get; set; }
        public string EndDateString { get; set; }
        public string LoanDeptFromTo { get; set; }
        public int HeadCount { get; set; }
    }
}

