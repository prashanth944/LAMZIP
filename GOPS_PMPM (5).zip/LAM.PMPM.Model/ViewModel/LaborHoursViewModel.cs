﻿using System;


namespace LAM.PMPM.Model.ViewModel
{
    public class LaborHoursViewModel
    {
        public string Name { get; set; }
        public bool Status { get; set; }
        public int TotalAvailableHours { get; set; }
        public string Assembly { get; set; }
        public DateTime Date { get; set; }
        public string WeekStart { get; set; }
    }
}
