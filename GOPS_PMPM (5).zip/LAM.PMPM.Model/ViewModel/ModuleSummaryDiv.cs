namespace LAM.PMPM.Model.ViewModel
{
    public class ModuleSummaryDiv
    {
        public string BEN { get; set; }
        public string FCID { get; set; }
        public string ProductType { get; set; }
    }
}