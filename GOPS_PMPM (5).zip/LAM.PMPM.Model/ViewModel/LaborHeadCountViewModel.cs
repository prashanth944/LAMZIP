﻿using System;


namespace LAM.PMPM.Model.ViewModel
{
    public class LaborHeadCountViewModel
    {
        public string Name { get; set; }
        public string HeadcountType { get; set; }
        public string Headcount { get; set; }
        public DateTime Date { get; set; }
        public string WeekStart { get; set; }
    }
}
