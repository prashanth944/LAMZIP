﻿

namespace LAM.PMPM.Model.ViewModel
{
    public class FixtureModuleMissing
    {
        public int PilotSerialNumber { get; set; }
        public string ProductType { get; set; }
    }
}
