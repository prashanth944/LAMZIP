﻿using System;
using System.Collections.Generic;

namespace LAM.PMPM.Model.ViewModel
{
    public class ModulesSummary
    {
        public string PlantName { get; set; }
        public long? PilotProductID { get; set; }
        public string FCID { get; set; }
        public string PilotSerialNumber { get; set; }
        public string PriorityDateDDl { get; set; }

        public DateTime? PriorityDate { get; set; } = null;
        public int? BuildStyleId { get; set; }
        public int? BuildScheduleId { get; set; }
        public bool? NoCapacity { get; set; }
        public bool? DayShiftOnly { get; set; }
        public string RecordType { get; set; } = null;
        public string RevenueCode { get; set; }
        public string ProductGroupName { get; set; } = null;
        public long? ProductGroupID { get; set; }
        public string ToolTypeName { get; set; } = null;

        public string CustomerID { get; set; } = null;
        public string CompleteATP { get; set; }

        public long? BuildTypeID { get; set; }
        public long? ToolTypeID { get; set; }
        public string BuildTypeName { get; set; } = null;
        public int? BaysRequired { get; set; }
        public int? BaysRequiredSubassembly { get; set; }
        public decimal? TotalAssemblyHours { get; set; }
        public int? BaysRequiredIntegration { get; set; }
        public decimal? TotalIntegrationHours { get; set; }
        public int? BaysRequiredForTest { get; set; }
        public decimal? TotalTestHours { get; set; }
        public int? BaysRequiredPostTest { get; set; }
        public decimal? TotalPostTestHours { get; set; }
        public decimal? TotalLaborHour { get; set; }
        public DateTime? EarliestStartDate { get; set; }
        public DateTime? MaterialReadiness { get; set; }
        public DateTime? ActualDMRF { get; set; } = null;
        public DateTime? TransitionDate { get; set; } = null;
        public DateTime? CommitLaunch { get; set; } = null;
        public DateTime? ActualIntegrationStart { get; set; } = null;
        public DateTime? CommittedIntegrationStart { get; set; }
        public DateTime? CommitTestStart { get; set; } = null;
        public DateTime? CommitManufacturingComplete { get; set; } = null;
        public DateTime? PilotCommit { get; set; } = null;
        public DateTime? CRD { get; set; } = null;
        public DateTime? SRD { get; set; } = null;
        public DateTime? TSD { get; set; } = null;
        public DateTime? MCSD { get; set; } = null;
        public string CapacityPlanningColor { get; set; } = null;
        public string SchedulingColor { get; set; } = null;
        
        public string Notes { get; set; } = null;
        public DateTime? ActualShipDate { get; set; }
        public DateTime? ManufacturingCommitedShipDate { get; set; }
        public string ScheduleTimePeriod { get; set; }
        //public string MCSDRiskLevel { get; set; } = null;
        public string SalesPriority { get; set; } = null;
        public string CRDGap { get; set; } = null;

        public int? CRDGapDays { get; set; } = null;

        public string MPSName { get; set; } = null;
        public bool? CRDEsc { get; set; }

        public DateTime? POABOMReleaseDate { get; set; }

        public int? TechnicianRequiredSubassembly { get; set; }
        public int? TechnicianRequiredIntegration { get; set; }
        public int? TechnicianRequiredTest { get; set; }
        public int? TechnicianRequiredPostTest { get; set; }

        public int? ModuleIdSubassembly { get; set; }
        public int? ModuleIdIntegration { get; set; }
        public int? ModuleIdTest { get; set; }
        public int? ModuleIdPostTest { get; set; }

        public string BEN { get; set; }
        public string POM { get; set; }

        public DateTime? PlannedDMRF { get; set; } = null;
        public int? TestBaysNeeded { get; set; }
        public string PilotRiskLevel { get; set; } = null;
        public string PlannedRiskLevel { get; set; } = null;
        public DateTime? CommitIntegrationStart { get; set; } = null;
        public List<ScheduleBuildHours> ScheduleBuildHours { get; set; }

        public string ModuleProcessSubassembly { get; set; }
        public string ModuleProcessIntegration { get; set; }
        public string ModuleProcessTest { get; set; }
        public string ModuleProcessPostTest { get; set; }

        public long? FremontID { get; set; }
        public DateTime? PilotManufacturingCommitedShipDate { get; set; }

        public bool? AlreadyScheduled { get; set; }

        public DateTime? PlanofRecord { get; set; }
        public string T09Comment { get; set; }

        public string PilotRisk { get; set; } = null;

        public int? ProductionPlanID { get; set; }

        public DateTime? PilotMCSD { get; set; }

        public DateTime? SapMCSD { get; set; }
        public long? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }

        public string URBPBuildTypeName { get; set; }
        public string PilotToolType { get; set; }

        public string LPRID { get; set; }
        public string OnPOR { get; set; }
        public string ScheduleStatus { get; set; }
        public long? ScheduleStatusId { get; set; }
        public int? BuildSchedule { get; set; }
        public int? CalendarDaysSubAssembly { get; set; }
        public int? CalendarDaysIntegration { get; set; }
        public int? CalendarDaysTest { get; set; }
        public int? CalendarDaysPostTest { get; set; }
    }


    public class ScheduleBuildHours
    {
        public string Interval { get; set; }

        public int PilotProductID { get; set; }
        public string Baysbuilhours { get; set; }
        public int? ModuleProcessID { get; set; } 
        public DateTime? Datedaily { get; set; } = null;
        public int? ProductionPlanID { get; set; }

    }

    public class ComparisonModel
    {
        public DateTime? WeekDate { get; set; }
        public string LaborType { get; set; }
        public int? LaborDifference { get; set; }
        public string HighRisk { get; set; }
        public int? HighRiskDifference { get; set; }

        public string MediumRisk { get; set; }
        public int? MediumRiskDifference { get; set; }
        public string LaunchingTool { get; set; }
        public int? LaunchingToolDifference { get; set; }
    }

    public class WeeklyDate
    {
        public DateTime? DateValue { get; set; }
        public int Value { get; set; }
    }

    public class ComparisonList
    {
        public string Description { get; set; }
        public List<WeeklyDate> WeeklyDates { get; set; }
    }

    public class ComparisonListWithDate
    {
        public List<DateTime> WeeklyDates { get; set; }
        public List<ComparisonList> ComparisonLists { get; set; }
    }
}
