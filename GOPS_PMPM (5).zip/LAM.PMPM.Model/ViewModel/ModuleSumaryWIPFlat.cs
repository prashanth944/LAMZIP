namespace LAM.PMPM.Model.ViewModel
{
    public class ModuleSumaryWIPFlat
    {
        public int pilotProductID { get; set; }
        
        public bool? wipFlat { get; set; } 
    }
}