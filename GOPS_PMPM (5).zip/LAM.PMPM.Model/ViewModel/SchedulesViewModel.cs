﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
    public class SchedulesViewModel
    {
        public long? PlantID { get; set; }
        public string PlantName { get; set; }
        public long? ProductionPlanID { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string PlanType { get; set; }
        public string PlanName { get; set; }
        public List<PriorityOrder> PriorityOrder { get; set; }
        public List<PriorityOrder> RecordTypePriorityOrder { get; set; }
        public List<PriorityOrder> RevenueTypePriorityOrder { get; set; }
        public List<ModulesSummary> ModulesLevelCp { get; set; }
        public string UserID { get; set; }
        public string Description { get; set; }
        public DateTime? DataRefreshDate { get; set; }
        public bool LaborResourcesHardConstraint { get; set; }
        public bool BayResourcesHardConstraint { get; set; }
        public bool FixtureResourcesHardConstraint { get; set; }
        public bool IsModLevel { get; set; }
        public long?[] PilotProductIds { get; set; }
        public DateTime? PushToProductionTime { get; set; }
        public bool? IsBeingEdited { get; set; }
        public string EditedBy { get; set; }
        public string ModifiedBy { get; set; }
        public long? ModifiedById { get; set; }
        public string IsBeingEditedBy { get; set; }
    }

    public class PriorityOrder
    {
        public int? SchedulePriorityID { get; set; }
        public string Priorities { get; set; }
      
    }




    public class ModulesLevelCp
    {
           
     public int? PilotProductID { get; set; }
    public int? PilotSerialNumber { get; set; }

    public string PriorityDateDDl { get; set; }


    public DateTime? PriorityDate { get; set; }
    public int? FCID { get; set; }
    //public string MCSDRiskLevel { get; set; }
    public string SalesPriority { get; set; }
    public bool? DayShiftOnly { get; set; }
    public bool? NoCapacity { get; set; }
    public int? ToolTypeID { get; set; }
    public string ToolTypeName { get; set; }
    public int? BuildTypeID { get; set; }
    public string BuildName { get; set; }
    public int? CustomerID { get; set; }
    public int? CompleteATP { get; set; }
    public decimal? TotalAssemblyHour { get; set; }
    public decimal? TotalIntegrationHour { get; set; }
    public decimal? TotalTestHour { get; set; }
    public decimal? TotalPostTestHour { get; set; }
    public DateTime? EarliestStartDate { get; set; }
    public int? TotalLaborHours { get; set; }
    public DateTime? ActualLaunch { get; set; }
    public DateTime? ActualIntegrationStart { get; set; }
    public DateTime? ActualTestStart { get; set; }
    public DateTime? ActualManufacturingComplete { get; set; }
    public DateTime? PilotManufacturingCommitedShipDate { get; set; }
    public DateTime? SalesOpsRequestDate { get; set; }
    public DateTime? ManufacturingCommitedShipDate { get; set; }
    public DateTime? CustomerRequestDate { get; set; }
    public int? CRDEsc { get; set; }
    public int? CRDGapDays { get; set; }
    public string Note { get; set; }
    public string ProductName { get; set; }
    public DateTime? POABOMReleaseDate { get; set; }
    public DateTime? TransitionDate { get; set; }
}

    public class CompareSummaryReport
    {
        public string Descriptions { get; set; }
        public string planAUtilization { get; set; }
        public string planBUtilization { get; set; }
        public string Comparison { get; set; }
    }
}

