﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace LAM.PMPM.Model.ViewModel
{
    public class BaySummaryViewModel
    {
        public int BayID { get; set; }
        [Required(ErrorMessage = "Please enter Bay Name")]
        public string BayName { get; set; }
        public string BuildingName { get; set; }
        public string BayTypeName { get; set; }
        public string Status { get; set; }
        public int StatusID { get;set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string ProductTypeGroupListID { get; set; }
        public int BuildingID { get; set; }
        public int BayTypeID { get; set; }
        public bool BaysAvailablity { get; set; }
        public string ProductName { get; set; }
        public DateTime WeekStart { get; set; }
        public DateTime BayDate { get; set; }
        public bool NoEndDate { get; set; }
    }

    public class BaySummaryByBaytype
    {
        public List<BayAssemblyIntegration> bayAssemblyIntegration { get; set; }
        public List<BayIntegration> bayIntegration { get; set; }
        public List<BayTest> bayTest { get; set; }
    }

    //public class BayAssemblyIntegrationTest
    //{
    //    public DateTime BayDate { get; set; }
    //    public decimal? BaysAvailablity { get; set; }
    //    //public int BuildingID { get; set; }
    //    //public string BayTypeName { get; set; }
    //    public string BayTypeName { get; set; }
    //}
    public class BayAssemblyIntegration
    {
        public DateTime? BayDate { get; set; }
        public decimal? BaysAvailablity { get; set; }
        //public int BuildingID { get; set; }
        //public string BayTypeName { get; set; }
        public string AssemblyIntegration { get; set; }
    }

    public class BayIntegration
    {
        public DateTime? BayDate { get; set; }
        public decimal? BaysAvailablity { get; set; }
        //public int BuildingID { get; set; }
        //public string BayTypeName { get; set; }
        public string Integration { get; set; }
    }

    public class BayTest
    {
        public DateTime? BayDate { get; set; }
        public decimal? BaysAvailablity { get; set; }
        public string BayName { get; set; }
        //public int BuildingID { get; set; }
        //public string BayTypeName { get; set; }
        public string Test { get; set; }
    }

}
