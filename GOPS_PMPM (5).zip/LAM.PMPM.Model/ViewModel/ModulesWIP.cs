using System;

namespace LAM.PMPM.Model.ViewModel
{
    public class ModulesWIP
    {
        public string BEN { get; set; }
        public int PilotProductID { get; set; }
        public string CompletePerc { get; set; }
        public string Bldg { get; set; }
        public string BuildType { get; set; }
        public string Comments { get; set; }
        public DateTime? CRD { get; set; }
        public DateTime? EarliestStartDate { get; set; }
        public string FCID { get; set; }
        public DateTime? IntegrationStart { get; set; }
        public string IntegrationStartInfo { get; set; }
        public DateTime? Launch { get; set; } = null;
        public string LaunchInfo { get; set; }
        public DateTime? LaunchCommit { get; set; }
        public int? LaunchDelta { get; set; }
        public string ManufacturingEngineer { get; set; }
        public DateTime? MCSD { get; set; }        
        //public string MCSDRiskLevel { get; set; }
        public int? MCSDDelta { get; set; }
        public string PilotRisk { get; set; }
        public DateTime? MFGCompleteCommit { get; set; }
        public DateTime? MFGComplete { get; set; }
        public string MFGCompleteInfo { get; set; }
        public int? MDGCompleteDelta { get; set; }
        public string PBOM { get; set; }
        public string? PilotSerialNumber { get; set; }
        public string WIPPriority { get; set; } = null;
        public string ProductType { get; set; }
        public DateTime? TestStart { get; set; }
        public string TestStartInfo { get; set; }
        public DateTime? TestStartComited { get; set; }
        public int? TestStartDelta { get; set; }
        public DateTime? TestComplete { get; set; }
        public string TestCompleteInfo { get; set; }
        public DateTime? TestCompleteCommit { get; set; }
        public string? TestEngineer { get; set; }
        public string? ToolType { get; set; }
        public DateTime? TSD { get; set; }
        public string Customer { get; set; }
        public string Status { get; set; }
        public bool? Staffed { get; set; }
        public string Shift { get; set; }
        public long? FremontID { get; set; }
        public string Idle { get; set; }
        public bool? IsCritical { get; set; }
        public bool? IsGating { get; set; }
        public string BuildStyle { get; set; }
        public bool? DayShiftOnly { get; set; }
        public string URBPBuildTypeName { get; set; }
        public string OpsApprovedForShift { get; set; }
        public string PilotToolType { get; set; }
        public long? BuildingId { get; set; }
        public DateTime? CommittedIntegrationStart { get; set; }
        public int? IntegrationDelta { get; set; }
        public int? ShortagesAtLaunch { get; set; }
        public bool ActualIntegrationStartIsManual { get; set; }
        public DateTime? ActualIntegrationStartManual { get; set; }
        public bool ActualTestStartIsManual { get; set; }
        public DateTime? ActualTestStartManual { get; set; }
        public DateTime? ActualLaunch { get; set; }
        public DateTime? PlannedLaunch { get; set; }
        public DateTime? ActualIntegrationStart { get; set; }
        public DateTime? PlannedIntegrationStart { get; set; }
        public DateTime? ActualTestStart { get; set; }
        public DateTime? PlannedTestStart { get; set; }
        public DateTime? ActualManufacturingComplete { get; set; }
        public DateTime? PlannedManufacturingComplete { get; set; }
        public int? ManufacturingCompleteDelta { get; set; }
        public bool ActualManufacturingCompleteIsManual { get; set; }
        public object ActualTestCompleteIsManual { get; set; }
        public DateTime? ActualTestComplete { get; set; }
        public DateTime? PlannedTestComplete { get; set; }
        public int? IdleTestDay { get; set; }
        public int? PostTestDays { get; set; }
        public int? TargetTestDays { get; set; }
        public string ActualLaunchHover { get; set; }
        public string PreviousUpdatePlannedLaunchHover { get; set; }
        public string LastUpdatedPlannedLaunchHover { get; set; }
        public string ActualIntegrationStarthHover { get; set; }
        public string PreviousUpdatePlannedIntegrationStartHover { get; set; }
        public string LastUpdatedPlannedIntegrationStartHover { get; set; }
        public string ActualTestStartHover { get; set; }
        public string PreviousUpdatePlannedTestStartHover { get; set; }
        public string LastUpdatedPlannedTestStartHover { get; set; }
        public string ActualManufacturingCompletetHover { get; set; }
        public string PreviousUpdatePlannedManufacturingCompleteHover { get; set; }
        public string LastUpdatedPlannedManufacturingCompleteHover { get; set; }
        public string CurrentStage { get; set; }
        public int? ModulesInWIP { get; set; }
        public bool? CurrentDayShift { get; set; }
        public bool? LastDayShift { get; set; }
        public bool? CurrentNightShift { get; set; }
        public bool? LastNightShift { get; set; }
        public int? ProcessModule { get; set; }

    }
}