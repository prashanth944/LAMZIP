﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
   public class ZoneValueViewModel
    {
        public long? ZoneID { get; set; }
        public string Description { get; set; }
        public long? PilotProductID { get; set; }
    }
}
