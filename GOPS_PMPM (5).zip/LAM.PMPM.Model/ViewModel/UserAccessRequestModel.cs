﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAM.PMPM.Model.ViewModel
{
    public class UserAccessRequestModel
    {
        public long? UserAccessRequestId { get; set; }
        public long? PlantID { get; set; }
        public string PlantName { get; set; }
        public long? UserId { get; set; }
        public long? RoleId { get; set; }
        public string RoleName { get; set; }
        public string UserFullName { get; set; }
        public string UserEmail { get; set; }
        public long? UserAccessRequestStatusID { get; set; }
        public string Status { get; set; }
        public string StatusMessage { get; set; }
        public long? ModifiedBy { get; set; }
        public string GUID { get; set; }
        public string UserMessage { get; set; }
        public string Host { get; set; }
    }
}
