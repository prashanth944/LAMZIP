﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace LAM.PMPM.DAL
{
    public static class SqlHelper
    {

        public static DataTable GetDataTable(string connString, string procedureName, params SqlParameter[] commandParameters)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;
                    cmd.CommandText = procedureName;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 0;
                    cmd.Parameters.Clear();
                    if (commandParameters != null)
                    {
                        cmd.Parameters.AddRange(commandParameters);
                    }
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {

                dt.Dispose();
            }
            return dt;
        }


        public static DataSet GetDataSet(string connString, string procedureName, params SqlParameter[] commandParameters)
        {
            DataSet dataSet = new DataSet();
            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;
                    cmd.CommandText = procedureName;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 0;
                    cmd.Parameters.Clear();
                    if (commandParameters != null)
                    {
                        cmd.Parameters.AddRange(commandParameters);
                    }
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dataSet);
                    }
                }
            }
            catch (Exception ex)
            {
                dataSet = null;
                throw new Exception(ex.ToString());
            }
            finally
            {
                if (dataSet != null)
                    dataSet.Dispose();
            }
            return dataSet;
        }
        // INSERT,UPDATE, DELETE
        public static int ExecuteNonQuery(string connString, string procedureName, params SqlParameter[] commandParameters)
        {
            int result = -1;
            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;
                    cmd.CommandText = procedureName;
                    cmd.CommandType =  CommandType.StoredProcedure;
                    cmd.CommandTimeout = 0;
                    if (commandParameters != null)
                    {
                        cmd.Parameters.AddRange( commandParameters);
                    }
                    cmd.ExecuteNonQuery();
                    if (cmd.Parameters["@rowCount"].Value != null)
                        result = Convert.ToInt32(cmd.Parameters["@rowCount"].Value);
                    cmd.Parameters.Clear();
                }
            }
            catch (Exception ex)
            {
                result = -1;
                throw new Exception(ex.ToString());
            }
            return result;
        }
        
        // INSERT,UPDATE, DELETE
        public static string ExecuteNonQueryWithTwoOutParam(string connString, string procedureName, params SqlParameter[] commandParameters)
        {
            string strResult = "";
            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;
                    cmd.CommandText = procedureName;
                    cmd.CommandType =  CommandType.StoredProcedure;
                    cmd.CommandTimeout = 0;
                    if (commandParameters != null)
                    {
                        cmd.Parameters.AddRange( commandParameters);
                    }
                    cmd.ExecuteNonQuery();
                    if (cmd.Parameters["@rowCount"].Value != null)
                        strResult = (Convert.ToInt32(cmd.Parameters["@rowCount"].Value)).ToString();
                     if (cmd.Parameters["@errorMessage"].Value != null)
                        strResult = strResult + ',' + Convert.ToString(cmd.Parameters["@errorMessage"].Value);
                    cmd.Parameters.Clear();
                }
            }
            catch (Exception ex)
            {
                strResult = ",";
                throw new Exception(ex.ToString());
            }
            return strResult;
        }
        public static string ExecuteNonQueryWithOneOutParam(string connString, string procedureName, params SqlParameter[] commandParameters)
        {
            string strResult = "";
            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;
                    cmd.CommandText = procedureName;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 0;
                    if (commandParameters != null)
                    {
                        cmd.Parameters.AddRange(commandParameters);
                    }
                    cmd.ExecuteNonQuery();
                   if (cmd.Parameters["@Message"].Value != null)
                        strResult = strResult + ',' + Convert.ToString(cmd.Parameters["@Message"].Value);
                    cmd.Parameters.Clear();
                }
            }
            catch (Exception ex)
            {
                strResult = ",";
                throw new Exception(ex.ToString());
            }
            return strResult;
        }
        // INSERT,UPDATE, DELETE without count output 
        public static int ExecuteNonQueryNoOutParam(string connString, string procedureName, params SqlParameter[] commandParameters)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;
                    cmd.CommandText = procedureName;
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Clear();
                    if (commandParameters != null)
                    {
                        cmd.Parameters.AddRange(commandParameters);
                    }
                    return cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        //Execute Insert, Update, Delete and Returns Single value string
        public static object ExecuteScalar(string connString, string procName,
            params SqlParameter[] paramters)
        {
            try
            {
                object obj;
                using (var sqlConnection = new SqlConnection(connString))
                {
                    using (var command = sqlConnection.CreateCommand())
                    {
                        command.CommandType = System.Data.CommandType.StoredProcedure;
                        command.CommandText = procName;
                        if (paramters != null)
                        {
                            command.Parameters.AddRange(paramters);
                        }
                        sqlConnection.Open();
                        obj = command.ExecuteScalar();
                    }
                }
                return obj;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
        public static int ExecuteProcedureReturnInt(string connString, string procName,
            params SqlParameter[] paramters)
        {
            try
            {
                int result = -1;
                using (var sqlConnection = new SqlConnection(connString))
                {
                    using (var command = sqlConnection.CreateCommand())
                    {
                        command.CommandType = System.Data.CommandType.StoredProcedure;
                        command.CommandText = procName;
                        if (paramters != null)
                        {
                            command.Parameters.AddRange(paramters);
                        }
                        sqlConnection.Open();
                        var ret = command.ExecuteScalar();
                        if (ret != null)
                            result = Convert.ToInt32(ret);
                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        // INSERT,UPDATE, DELETE
        public static string ExecuteNonQueryWithSevenOutParam(string connString, string procedureName, params SqlParameter[] commandParameters)
        {
            string strResult = "";
            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;
                    cmd.CommandText = procedureName;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 0;
                    if (commandParameters != null)
                    {
                        cmd.Parameters.AddRange(commandParameters);
                    }
                    cmd.ExecuteNonQuery();
                    if (cmd.Parameters["@rowCount"].Value != null)
                        strResult = (Convert.ToInt32(cmd.Parameters["@rowCount"].Value)).ToString();
                    if (cmd.Parameters["@errorMessage"].Value != null)
                        strResult = strResult + ',' + cmd.Parameters["@errorMessage"].Value;
                    if (cmd.Parameters["@outParamBEN"].Value != null)
                        strResult = strResult + ',' + (cmd.Parameters["@outParamBEN"].Value);
                    if (cmd.Parameters["@outParamPilotSer"].Value != null)
                        strResult = strResult + ',' + cmd.Parameters["@outParamPilotSer"].Value;

                    if (cmd.Parameters["@outParamBayAvail"].Value != null)
                        strResult = strResult + ',' + cmd.Parameters["@outParamBayAvail"].Value;

                    //1,,,,1,1,1
                    if (cmd.Parameters["@outParamLaborAvail"].Value != null)
                        strResult = strResult + ',' + (cmd.Parameters["@outParamLaborAvail"].Value);
                    if (cmd.Parameters["@outParamModSuccess"].Value != null)
                        strResult = strResult + ',' + cmd.Parameters["@outParamModSuccess"].Value;
                    cmd.Parameters.Clear();
                }
            }
            catch (Exception ex)
            {
                strResult = ",";
                throw new Exception(ex.ToString());
            }
            return strResult;
        }

    }
}
